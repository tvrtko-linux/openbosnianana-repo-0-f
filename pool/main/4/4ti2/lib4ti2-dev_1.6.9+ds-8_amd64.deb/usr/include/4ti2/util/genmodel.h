int genmodel_main(int, char**);

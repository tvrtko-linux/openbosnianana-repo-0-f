int output_main(int, char**);
listVector* readListVector(int*, char*);
listVector* extractNonDominatedVectors(listVector*, listVector*, int);

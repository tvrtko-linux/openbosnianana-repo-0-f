'''\"	TMAC.M @(#)tmacs.src	1.7
.if n .so /usr/share/9base/troff/tmac/mmn
.if t .so /usr/share/9base/troff/tmac/mmt

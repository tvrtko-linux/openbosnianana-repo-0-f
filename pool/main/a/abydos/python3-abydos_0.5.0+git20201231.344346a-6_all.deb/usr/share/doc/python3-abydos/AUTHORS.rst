
Creator & Maintainer
````````````````````

- Christopher C. Little (`@chrislit <https://github.com/chrislit>`_) <chrisclittle+abydos@gmail.com>


Contributors
````````````

- Szolár Balázs (`@LEFTazs <https://github.com/LEFTazs>`_)

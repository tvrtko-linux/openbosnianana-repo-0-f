This directory contains the 'Kestrel Books', a collection of ACL2 books
contributed mainly by Kestrel Institute (http://www.kestrel.edu). Copyright,
author, and license information is provided in the individual files and
subdirectories.

The Kestrel Books are documented in the manual at:
http://www.cs.utexas.edu/users/moore/acl2/manuals/latest/?topic=ACL2____KESTREL-BOOKS

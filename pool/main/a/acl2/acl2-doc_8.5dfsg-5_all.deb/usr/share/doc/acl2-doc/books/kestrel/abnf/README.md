This directory contains a library for ABNF (Augmented Backus-Naur Form).

This ABNF library is documented in the manual at:
http://www.cs.utexas.edu/users/moore/acl2/manuals/latest/?topic=ABNF____ABNF

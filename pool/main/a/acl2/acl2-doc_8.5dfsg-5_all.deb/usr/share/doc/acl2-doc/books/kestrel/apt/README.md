This directory contains APT (Automated Program Transformations), a library of
tools to transform programs and program specifications with automated support.

APT is documented in the manual at:
http://www.cs.utexas.edu/users/moore/acl2/manuals/latest/?topic=APT____APT

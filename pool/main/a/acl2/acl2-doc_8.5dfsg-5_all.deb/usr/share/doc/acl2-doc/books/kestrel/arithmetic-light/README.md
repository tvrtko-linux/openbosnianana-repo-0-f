This directory contains a lightweight arithmetic library written in a
minimalist style to give users fine-grained control over what parts of
it they include.

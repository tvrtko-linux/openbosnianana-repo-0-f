The file popcount-macho-64.executable was created by doing:
gcc popcount.c -o popcount-macho-64.executable
on a Mac where 'gcc --version' includes:
Apple LLVM version 9.0.0 (clang-900.0.39.2)

This directory contains tools for analyzing ACL2 books (e.g., the
Community Books) as a scientific dataset worthy of study in its own
right.

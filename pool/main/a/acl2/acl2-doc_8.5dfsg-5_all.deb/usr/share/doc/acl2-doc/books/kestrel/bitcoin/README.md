This directory contains a library for Bitcoin.

This Bitcoin library is documented in the manual at:
http://www.cs.utexas.edu/users/moore/acl2/manuals/latest/?topic=BITCOIN____BITCOIN

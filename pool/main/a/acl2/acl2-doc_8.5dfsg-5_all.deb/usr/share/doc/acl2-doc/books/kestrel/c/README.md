This directory contains a library for C.

This C library is documented in the manual at:
https://www.cs.utexas.edu/users/moore/acl2/manuals/latest/index.html?topic=C____C

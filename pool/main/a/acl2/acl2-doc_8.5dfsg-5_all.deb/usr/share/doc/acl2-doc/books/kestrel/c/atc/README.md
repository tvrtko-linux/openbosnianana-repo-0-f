This directory contains ATC (ACL2 To C),
a proof-generating C code generator for ACL2.

ATC is documented in the manual at:
https://www.cs.utexas.edu/users/moore/acl2/manuals/latest/index.html?topic=C____ATC

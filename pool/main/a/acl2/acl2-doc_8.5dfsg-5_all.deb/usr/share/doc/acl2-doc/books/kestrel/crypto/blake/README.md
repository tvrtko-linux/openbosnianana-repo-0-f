Formal specification of the BLAKE-256 and BLAKE2s hash functions.

Test vectors are from:
https://raw.githubusercontent.com/BLAKE2/BLAKE2/master/testvectors/blake2-kat.json

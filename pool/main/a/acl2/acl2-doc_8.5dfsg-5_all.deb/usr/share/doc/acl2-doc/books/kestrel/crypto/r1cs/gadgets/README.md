This directory contains rules to recognize R1CS gadgets phrased in
terms of prime field operations.  See also ../sparse/gadgets/ for
utilities to make gadgets.

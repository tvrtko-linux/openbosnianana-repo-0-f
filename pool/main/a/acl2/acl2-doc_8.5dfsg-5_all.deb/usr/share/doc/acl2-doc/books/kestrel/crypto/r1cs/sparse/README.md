This directory contains a formalization or R1CSes (Rank-1 Constraint Systems) in sparse form.

See the documentation at:
https://www.cs.utexas.edu/users/moore/acl2/manuals/latest/index.html?topic=R1CS____R1CS
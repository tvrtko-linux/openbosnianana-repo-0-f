This directory contains verified generators for R1CS gadgets in sparse form.
See also ../../gadgets/ for rules to recognize gadgets phrased in
terms of prime field operations.

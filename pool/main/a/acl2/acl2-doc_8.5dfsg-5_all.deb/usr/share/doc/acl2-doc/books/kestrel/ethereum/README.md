This directory contains a library for Ethereum.

This Ethereum library is documented in the manual at:
http://www.cs.utexas.edu/users/moore/acl2/manuals/latest/?topic=ETHEREUM____ETHEREUM

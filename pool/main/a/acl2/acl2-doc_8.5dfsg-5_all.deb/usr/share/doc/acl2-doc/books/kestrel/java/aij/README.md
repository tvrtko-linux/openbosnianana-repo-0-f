This directory contains AIJ (ACL2 In Java), an embedding of ACL2 into Java.

AIJ is documented in the manual at:
https://www.cs.utexas.edu/users/moore/acl2/manuals/latest/index.html?topic=JAVA____AIJ

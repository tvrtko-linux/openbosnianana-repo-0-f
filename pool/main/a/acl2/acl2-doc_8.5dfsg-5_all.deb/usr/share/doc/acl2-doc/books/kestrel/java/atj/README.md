This directory contains ATJ (ACL2 To Java), a Java code generator for ACL2.

ATJ is documented in the manual at:
https://www.cs.utexas.edu/users/moore/acl2/manuals/latest/index.html?topic=JAVA____ATJ

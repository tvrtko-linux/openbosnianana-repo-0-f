This directory contains Kestrel's JVM model.

See also ../axe/x86/.

This directory contains SOFT (Second-Order Functions and Theorems), a tool to
mimic second-order functions and theorems in the first-order logic of ACL2.

SOFT is documented in the manual at:
http://www.cs.utexas.edu/users/moore/acl2/manuals/latest/?topic=SOFT____SOFT

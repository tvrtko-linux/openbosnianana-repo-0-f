This directory contains utilities that are part of the Kestrel Books.

These utilities are documented in the manual at:
http://www.cs.utexas.edu/users/moore/acl2/manuals/latest/?topic=ACL2____KESTREL-UTILITIES

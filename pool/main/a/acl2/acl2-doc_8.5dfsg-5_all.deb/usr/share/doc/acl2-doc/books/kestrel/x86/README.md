This directory contains machinery developed by Kestrel for reasoning about x86 programs.

See also ../axe/x86/.
This directory contains a library for Zcash.

This Zcash library is documented in the manual at:
http://acl2.org/manual?topic=ZCASH____ZCASH

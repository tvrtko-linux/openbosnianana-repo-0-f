This directory contains various R1CS gadgets relevant to Zcash, together with specifications and proofs of several of them.

File names in this directory correspond to sections (mostly from the Appendix) of a particular version of the ZCash Protocol Specification.
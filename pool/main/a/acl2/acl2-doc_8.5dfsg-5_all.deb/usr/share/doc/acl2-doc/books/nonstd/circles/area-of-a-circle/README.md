This is an applicaion of integration by substitution in ACL2(r)(books/nonstd/integrals/u-substitution.lisp)

area-of-a-circle-2.lisp is the continuation of area-of-a-circle-1.lisp.
[![Build Status](https://travis-ci.org/osicat/osicat.svg?branch=master)](https://travis-ci.org/osicat/osicat)

Osicat is a lightweight operating system interface for Common Lisp
on Unix-platforms. It is not a POSIX-style API, but rather a simple
lispy accompaniment to the standard ANSI facilities.

Osicat homepage: <http://www.common-lisp.net/project/osicat/>

## About Pathname-Utils
This is a collection of common tests and operations to help handling pathnames. It does not actually deal in handling the accessing of files on the underlying system however.

## How To
Since this is a purely utility/toolkit library, simply having a look at the symbol index should give you the best idea of what is offered.

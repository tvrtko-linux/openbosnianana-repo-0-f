salza2 can compress data in the ZLIB and DEFLATE data formats. It is
available under a BSD-like license.

For documentation, see the doc/ directory.

For any questions or comments, please email Zach Beane
<xach@xach.com>.

Tagging Scripts
===============

Most everyone should just ignore these scripts.

There are too many Lisps and OSes to test by hand.  Instead these scripts let
me run all of the Lisps that work on a particular OS, and tag that the tests
have been run against a particular Git version.


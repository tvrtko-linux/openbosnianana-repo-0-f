This directory contains tests that exercise potential issues in the
early loading of compiled files by include-book (see the Essay on Hash
Table Support for Compilation in the ACL2 sources).  These tests were
introduced when modifying ACL2 in mid-February, 2021 to deal with such
issues, as described below.  Many of the tests deal with issues
involving honsing and fast alists.

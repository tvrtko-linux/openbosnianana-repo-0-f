The current implementation of the simplify tool is in community books
directory books/kestrel/apt/, including file simplify.lisp as well as
related books that support the implementation, testing, and
documentation.

For the 2017 ACL2 Workshop version, see support/README.txt.

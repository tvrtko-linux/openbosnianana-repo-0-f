This directory contains some files that are intended to allow the
ACL2s interface to work better with ACL2s. These can be certified from
the root directory of this repository using the command `make
acl2s-utils-cert`, or by running `cert.pl top.lisp` inside this
directory.

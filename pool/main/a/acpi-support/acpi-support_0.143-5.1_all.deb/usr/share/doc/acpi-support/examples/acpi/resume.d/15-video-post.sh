#!/bin/sh

# Post the video card
if [ x$POST_VIDEO = xtrue ]; then
  vbetool post
fi


#!/bin/sh
. /usr/share/acpi-support/state-funcs
setLEDThinkpadSuspending 0

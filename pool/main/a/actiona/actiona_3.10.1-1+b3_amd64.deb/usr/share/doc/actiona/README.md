[![AppVeyor](https://img.shields.io/appveyor/build/Jmgr/actiona?label=ubuntu-gcc-build&logo=appveyor)](https://ci.appveyor.com/project/Jmgr/actiona)
[![AppVeyor](https://img.shields.io/appveyor/build/Jmgr/actiona-hhhwb?label=windows-msvc-build&logo=appveyor)](https://ci.appveyor.com/project/Jmgr/actiona-hhhwb)
[![AppVeyor](https://img.shields.io/appveyor/build/Jmgr/actiona-9331s?label=windows-gcc-build&logo=appveyor)](https://ci.appveyor.com/project/Jmgr/actiona-9331s)
![License: GPLv3](https://img.shields.io/badge/license-GPLv3-blue)

Actiona
======

Actiona is an application that allows you to execute many actions on your
computer such as emulating mouse clicks, key presses, showing message boxes,
editing text files, etc. Tasks can be created using a simple editor or using
the EcmaScript (JavaScript) programming language for more customization.
Actiona is cross-platform.

Please visit http://actiona.tools for more information.

// This header only exists to make transition to CAF 0.18 easier by not having
// to use #ifdef blocks for includes.

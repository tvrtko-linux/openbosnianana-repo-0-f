// AddressView.h (this is -*- ObjC -*-)
// 
// Author: Bj�rn Giesler <giesler@ira.uka.de>
// 
// Address View Framework for GNUstep

#import <Addresses/Addresses.h>


#import <AddressView/ADPersonView.h>
#import <AddressView/ADSinglePropertyView.h>

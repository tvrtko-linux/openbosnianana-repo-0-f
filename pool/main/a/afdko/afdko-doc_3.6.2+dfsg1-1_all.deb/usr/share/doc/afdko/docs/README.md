##### • [Adobe Font Development Kit for OpenType (AFDKO) Overview](./AFDKO-Overview.md)
##### • [OpenType Feature File Specification](./OpenTypeFeatureFileSpecification.md)
---
##### • [MakeOTF v2.5 User Guide](./MakeOTFUserGuide.md)
##### • [Command Line How-To](./CommandLineHowTo.md)
---
##### • [Issues with OpenType/CFF and TrueType fonts in MS Font Validator](./MSFontValidatorIssues.md)
##### • [Practical issues in weight setting and style linking (Windows only)](./WinWeights.md)
---
##### • [FDK Build Notes](./FDK_Build_Notes.md)

"""
XML-RPC Protocol for ``asyncio``
"""
import pkg_resources

__version__ = pkg_resources.get_distribution("aioxmlrpc").version

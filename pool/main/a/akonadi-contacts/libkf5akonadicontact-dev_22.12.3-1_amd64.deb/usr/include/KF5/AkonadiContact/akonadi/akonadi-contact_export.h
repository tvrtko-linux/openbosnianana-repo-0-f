
#ifndef AKONADI_CONTACT_EXPORT_H
#define AKONADI_CONTACT_EXPORT_H

#ifdef AKONADI_CONTACT_STATIC_DEFINE
#  define AKONADI_CONTACT_EXPORT
#  define AKONADI_CONTACT_NO_EXPORT
#else
#  ifndef AKONADI_CONTACT_EXPORT
#    ifdef KF5AkonadiContact_EXPORTS
        /* We are building this library */
#      define AKONADI_CONTACT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define AKONADI_CONTACT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef AKONADI_CONTACT_NO_EXPORT
#    define AKONADI_CONTACT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef AKONADI_CONTACT_DEPRECATED
#  define AKONADI_CONTACT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef AKONADI_CONTACT_DEPRECATED_EXPORT
#  define AKONADI_CONTACT_DEPRECATED_EXPORT AKONADI_CONTACT_EXPORT AKONADI_CONTACT_DEPRECATED
#endif

#ifndef AKONADI_CONTACT_DEPRECATED_NO_EXPORT
#  define AKONADI_CONTACT_DEPRECATED_NO_EXPORT AKONADI_CONTACT_NO_EXPORT AKONADI_CONTACT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef AKONADI_CONTACT_NO_DEPRECATED
#    define AKONADI_CONTACT_NO_DEPRECATED
#  endif
#endif

#endif /* AKONADI_CONTACT_EXPORT_H */

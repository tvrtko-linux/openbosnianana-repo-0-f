
#ifndef LIBIMPORTWIZARD_EXPORT_H
#define LIBIMPORTWIZARD_EXPORT_H

#ifdef LIBIMPORTWIZARD_STATIC_DEFINE
#  define LIBIMPORTWIZARD_EXPORT
#  define LIBIMPORTWIZARD_NO_EXPORT
#else
#  ifndef LIBIMPORTWIZARD_EXPORT
#    ifdef KPimImportWizard_EXPORTS
        /* We are building this library */
#      define LIBIMPORTWIZARD_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBIMPORTWIZARD_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBIMPORTWIZARD_NO_EXPORT
#    define LIBIMPORTWIZARD_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBIMPORTWIZARD_DEPRECATED
#  define LIBIMPORTWIZARD_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LIBIMPORTWIZARD_DEPRECATED_EXPORT
#  define LIBIMPORTWIZARD_DEPRECATED_EXPORT LIBIMPORTWIZARD_EXPORT LIBIMPORTWIZARD_DEPRECATED
#endif

#ifndef LIBIMPORTWIZARD_DEPRECATED_NO_EXPORT
#  define LIBIMPORTWIZARD_DEPRECATED_NO_EXPORT LIBIMPORTWIZARD_NO_EXPORT LIBIMPORTWIZARD_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIBIMPORTWIZARD_NO_DEPRECATED
#    define LIBIMPORTWIZARD_NO_DEPRECATED
#  endif
#endif

#endif /* LIBIMPORTWIZARD_EXPORT_H */

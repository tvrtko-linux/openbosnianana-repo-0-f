
#ifndef AKONADI_MIME_EXPORT_H
#define AKONADI_MIME_EXPORT_H

#ifdef AKONADI_MIME_STATIC_DEFINE
#  define AKONADI_MIME_EXPORT
#  define AKONADI_MIME_NO_EXPORT
#else
#  ifndef AKONADI_MIME_EXPORT
#    ifdef KF5AkonadiMime_EXPORTS
        /* We are building this library */
#      define AKONADI_MIME_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define AKONADI_MIME_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef AKONADI_MIME_NO_EXPORT
#    define AKONADI_MIME_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef AKONADI_MIME_DEPRECATED
#  define AKONADI_MIME_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef AKONADI_MIME_DEPRECATED_EXPORT
#  define AKONADI_MIME_DEPRECATED_EXPORT AKONADI_MIME_EXPORT AKONADI_MIME_DEPRECATED
#endif

#ifndef AKONADI_MIME_DEPRECATED_NO_EXPORT
#  define AKONADI_MIME_DEPRECATED_NO_EXPORT AKONADI_MIME_NO_EXPORT AKONADI_MIME_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef AKONADI_MIME_NO_DEPRECATED
#    define AKONADI_MIME_NO_DEPRECATED
#  endif
#endif

#endif /* AKONADI_MIME_EXPORT_H */

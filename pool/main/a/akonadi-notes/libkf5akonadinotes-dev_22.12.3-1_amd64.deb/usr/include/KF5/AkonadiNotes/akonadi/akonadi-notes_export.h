
#ifndef AKONADI_NOTES_EXPORT_H
#define AKONADI_NOTES_EXPORT_H

#ifdef AKONADI_NOTES_STATIC_DEFINE
#  define AKONADI_NOTES_EXPORT
#  define AKONADI_NOTES_NO_EXPORT
#else
#  ifndef AKONADI_NOTES_EXPORT
#    ifdef KF5AkonadiNotes_EXPORTS
        /* We are building this library */
#      define AKONADI_NOTES_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define AKONADI_NOTES_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef AKONADI_NOTES_NO_EXPORT
#    define AKONADI_NOTES_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef AKONADI_NOTES_DEPRECATED
#  define AKONADI_NOTES_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef AKONADI_NOTES_DEPRECATED_EXPORT
#  define AKONADI_NOTES_DEPRECATED_EXPORT AKONADI_NOTES_EXPORT AKONADI_NOTES_DEPRECATED
#endif

#ifndef AKONADI_NOTES_DEPRECATED_NO_EXPORT
#  define AKONADI_NOTES_DEPRECATED_NO_EXPORT AKONADI_NOTES_NO_EXPORT AKONADI_NOTES_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef AKONADI_NOTES_NO_DEPRECATED
#    define AKONADI_NOTES_NO_DEPRECATED
#  endif
#endif

#endif /* AKONADI_NOTES_EXPORT_H */

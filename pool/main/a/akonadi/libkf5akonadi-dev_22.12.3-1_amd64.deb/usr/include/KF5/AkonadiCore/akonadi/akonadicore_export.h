
#ifndef AKONADICORE_EXPORT_H
#define AKONADICORE_EXPORT_H

#ifdef AKONADICORE_STATIC_DEFINE
#  define AKONADICORE_EXPORT
#  define AKONADICORE_NO_EXPORT
#else
#  ifndef AKONADICORE_EXPORT
#    ifdef KF5AkonadiCore_EXPORTS
        /* We are building this library */
#      define AKONADICORE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define AKONADICORE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef AKONADICORE_NO_EXPORT
#    define AKONADICORE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef AKONADICORE_DEPRECATED
#  define AKONADICORE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef AKONADICORE_DEPRECATED_EXPORT
#  define AKONADICORE_DEPRECATED_EXPORT AKONADICORE_EXPORT AKONADICORE_DEPRECATED
#endif

#ifndef AKONADICORE_DEPRECATED_NO_EXPORT
#  define AKONADICORE_DEPRECATED_NO_EXPORT AKONADICORE_NO_EXPORT AKONADICORE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef AKONADICORE_NO_DEPRECATED
#    define AKONADICORE_NO_DEPRECATED
#  endif
#endif

#endif /* AKONADICORE_EXPORT_H */

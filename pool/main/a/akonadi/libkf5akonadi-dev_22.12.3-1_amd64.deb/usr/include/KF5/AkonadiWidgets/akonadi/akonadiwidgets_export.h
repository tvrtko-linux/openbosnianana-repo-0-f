
#ifndef AKONADIWIDGETS_EXPORT_H
#define AKONADIWIDGETS_EXPORT_H

#ifdef AKONADIWIDGETS_STATIC_DEFINE
#  define AKONADIWIDGETS_EXPORT
#  define AKONADIWIDGETS_NO_EXPORT
#else
#  ifndef AKONADIWIDGETS_EXPORT
#    ifdef KF5AkonadiWidgets_EXPORTS
        /* We are building this library */
#      define AKONADIWIDGETS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define AKONADIWIDGETS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef AKONADIWIDGETS_NO_EXPORT
#    define AKONADIWIDGETS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef AKONADIWIDGETS_DEPRECATED
#  define AKONADIWIDGETS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef AKONADIWIDGETS_DEPRECATED_EXPORT
#  define AKONADIWIDGETS_DEPRECATED_EXPORT AKONADIWIDGETS_EXPORT AKONADIWIDGETS_DEPRECATED
#endif

#ifndef AKONADIWIDGETS_DEPRECATED_NO_EXPORT
#  define AKONADIWIDGETS_DEPRECATED_NO_EXPORT AKONADIWIDGETS_NO_EXPORT AKONADIWIDGETS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef AKONADIWIDGETS_NO_DEPRECATED
#    define AKONADIWIDGETS_NO_DEPRECATED
#  endif
#endif

#endif /* AKONADIWIDGETS_EXPORT_H */

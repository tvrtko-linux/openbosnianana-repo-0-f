
#ifndef AKONADIPRIVATE_EXPORT_H
#define AKONADIPRIVATE_EXPORT_H

#ifdef AKONADIPRIVATE_STATIC_DEFINE
#  define AKONADIPRIVATE_EXPORT
#  define AKONADIPRIVATE_NO_EXPORT
#else
#  ifndef AKONADIPRIVATE_EXPORT
#    ifdef KF5AkonadiPrivate_EXPORTS
        /* We are building this library */
#      define AKONADIPRIVATE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define AKONADIPRIVATE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef AKONADIPRIVATE_NO_EXPORT
#    define AKONADIPRIVATE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef AKONADIPRIVATE_DEPRECATED
#  define AKONADIPRIVATE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef AKONADIPRIVATE_DEPRECATED_EXPORT
#  define AKONADIPRIVATE_DEPRECATED_EXPORT AKONADIPRIVATE_EXPORT AKONADIPRIVATE_DEPRECATED
#endif

#ifndef AKONADIPRIVATE_DEPRECATED_NO_EXPORT
#  define AKONADIPRIVATE_DEPRECATED_NO_EXPORT AKONADIPRIVATE_NO_EXPORT AKONADIPRIVATE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef AKONADIPRIVATE_NO_DEPRECATED
#    define AKONADIPRIVATE_NO_DEPRECATED
#  endif
#endif

#endif /* AKONADIPRIVATE_EXPORT_H */

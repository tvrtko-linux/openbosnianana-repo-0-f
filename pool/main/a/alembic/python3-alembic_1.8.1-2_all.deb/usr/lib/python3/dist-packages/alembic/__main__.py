from .config import main

if __name__ == "__main__":
    main(prog="alembic")

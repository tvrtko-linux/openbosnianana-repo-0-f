<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- <base href = "http://localhost/~ckhung/"> -->

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta name="generator"
  content="HTML Tidy for Linux/x86 (vers 1st March 2003), see www.w3.org" />
  <?php include "../../i/meta.php" ?>

  <title>Hints for Algorithm Writers</title>
</head>

<body>
  
<?php include "header.en.php" ?>
<div id="content">

  <h1>Hints for Algorithm Writers</h1>
  <hr />

  <p>The programming interface is still in a state of flux :-)</p>

  
<?php include "footer.php" ?>
</div>
<?php include "$top[fs]/i/navigator.php" ?>

</body>
</html>

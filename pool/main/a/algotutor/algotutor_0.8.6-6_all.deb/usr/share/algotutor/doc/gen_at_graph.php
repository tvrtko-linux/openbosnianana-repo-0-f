<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>gen_at_graph - generates a random graph for use in algotutor.</title>
<link rev="made" href="mailto:root@localhost" />
</head>

<body style="background-color: white">

<p><a name="__index__"></a></p>
<!-- INDEX BEGIN -->

<ul>

	<li><a href="#name">NAME</a></li>
	<li><a href="#synopsis">SYNOPSIS</a></li>
	<li><a href="#description">DESCRIPTION</a></li>
	<li><a href="#options">OPTIONS</a></li>
	<li><a href="#license">LICENSE</a></li>
	<li><a href="#author">AUTHOR</a></li>
	<li><a href="#see_also">SEE ALSO</a></li>
</ul>
<!-- INDEX END -->

<hr />
<p>
</p>
<h1><a name="name">NAME</a></h1>
<p>gen_at_graph - generates a random graph for use in algotutor.</p>
<p>
</p>
<hr />
<h1><a name="synopsis">SYNOPSIS</a></h1>
<p><strong>gen_at_graph</strong> [<em>OPTION</em>] ...</p>
<p>
</p>
<hr />
<h1><a name="description">DESCRIPTION</a></h1>
<p>gen_at_graph generates a random graph for use in algotutor. Currently
the only type of graph it can generate is a rectangular grid of
vertices. Each vertex is connected to at most 8 adjacent vertices
around it.</p>
<p>
</p>
<hr />
<h1><a name="options">OPTIONS</a></h1>
<dl>
<dt><strong><a name="item__2dr_rows"><strong>-r</strong> <em>ROWS</em></a></strong><br />
</dt>
<dd>
generate ROWS rows of vertices
</dd>
<p></p>
<dt><strong><a name="item__2dc_cols"><strong>-c</strong> <em>COLS</em></a></strong><br />
</dt>
<dd>
generate COLS columns of vertices
</dd>
<p></p>
<dt><strong><a name="item__2dw_width"><strong>-w</strong> <em>WIDTH</em></a></strong><br />
</dt>
<dd>
make each grid cell WIDTH pixel wide
</dd>
<p></p>
<dt><strong><a name="item__2dh_height"><strong>-h</strong> <em>HEIGHT</em></a></strong><br />
</dt>
<dd>
make each grid cell HEIGHT pixel high
</dd>
<p></p>
<dt><strong><a name="item__2dl_lower"><strong>-l</strong> <em>LOWER</em></a></strong><br />
</dt>
<dd>
make all random numbers greater than or equal to LOWER
</dd>
<p></p>
<dt><strong><a name="item__2du_upper"><strong>-u</strong> <em>UPPER</em></a></strong><br />
</dt>
<dd>
make all random numbers less than (but never equal to) UPPER
</dd>
<p></p>
<dt><strong><a name="item__2dd_pattern"><strong>-d</strong> <em>PATTERN</em></a></strong><br />
</dt>
<dd>
specify the probability of generating each diagonal
</dd>
<p></p></dl>
<p>
</p>
<hr />
<h1><a name="license">LICENSE</a></h1>
<p>This code is distributed under the GNU General Public License</p>
<p>
</p>
<hr />
<h1><a name="author">AUTHOR</a></h1>
<p><strong>Chao-Kuei Hung</strong> ckhung AT cyut DOT edu DOT tw</p>
<p>
</p>
<hr />
<h1><a name="see_also">SEE ALSO</a></h1>
<p>Please see /usr/share/doc/algotutor/doc/ for the full set of documentations.</p>

</body>

</html>

<?php include "0.php" ?>

<p align="right" class="noprint">
<a class="em" href="<?= $top["url"] ?>/a/c051.php">
Ugly disply</a> <br /> on left?! </p>


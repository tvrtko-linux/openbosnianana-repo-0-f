<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- <base href = "http://localhost/~ckhung/"> -->

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta name="generator"
  content="HTML Tidy for Linux/x86 (vers 1st March 2003), see www.w3.org" />
  <?php include "../../i/meta.php" ?>

  <title>Algotutor -- 資料結構與演算法的家庭教師</title>
</head>

<body>
  
<?php include "../../i/header.php" ?>
<div id="content">

  <h1>Algotutor -- 資料結構與演算法的家庭教師</h1>
  <hr />

  <p>目前只有 <a href="index.en.php">英文版</a> 文件</p>

  
<?php include "footer.php" ?>
</div>
<?php include "$top[fs]/i/navigator.php" ?>

</body>
</html>

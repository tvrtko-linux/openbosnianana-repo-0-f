
#ifndef ALK_EXPORT_H
#define ALK_EXPORT_H

#ifdef ALK_STATIC_DEFINE
#  define ALK_EXPORT
#  define ALK_NO_EXPORT
#else
#  ifndef ALK_EXPORT
#    ifdef alkimia_EXPORTS
        /* We are building this library */
#      define ALK_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define ALK_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef ALK_NO_EXPORT
#    define ALK_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef ALK_DEPRECATED
#  define ALK_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef ALK_DEPRECATED_EXPORT
#  define ALK_DEPRECATED_EXPORT ALK_EXPORT ALK_DEPRECATED
#endif

#ifndef ALK_DEPRECATED_NO_EXPORT
#  define ALK_DEPRECATED_NO_EXPORT ALK_NO_EXPORT ALK_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef ALK_NO_DEPRECATED
#    define ALK_NO_DEPRECATED
#  endif
#endif

#endif /* ALK_EXPORT_H */

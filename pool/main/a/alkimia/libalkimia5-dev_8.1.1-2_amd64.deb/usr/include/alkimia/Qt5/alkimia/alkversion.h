/*
    SPDX-FileCopyrightText: 2021 Ralf Habacker ralf.habacker @freenet.de

    This file is part of libalkimia.

    SPDX-License-Identifier: GPL-2.0-or-later
*/

#ifndef ALK_VERSION_H
#define ALK_VERSION_H

#define ALK_VERSION_STRING "8.1.1"
#define ALK_VERSION_MAJOR 8
#define ALK_VERSION_MINOR 1
#define ALK_VERSION_PATCH 1
#define ALK_VERSION ALK_VERSION_CHECK(8, 1, 1)
/*
   can be used like #if (ALK_VERSION >= ALK_VERSION_CHECK(8, 1, 0))
*/
#define ALK_VERSION_CHECK(major, minor, patch) ((major<<16)|(minor<<8)|(patch))

#endif

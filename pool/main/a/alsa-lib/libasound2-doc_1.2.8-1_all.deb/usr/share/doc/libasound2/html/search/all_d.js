var searchData=
[
  ['off_5fvelocity_0',['off_velocity',['../structsnd__seq__ev__note__t.html#a94d2280005b5ddfceb76bd07317b87b2',1,'snd_seq_ev_note_t']]],
  ['ops_1',['ops',['../group__topology.html#gab717044852e6fe75883956a9a99d0493',1,'snd_tplg_ctl_template']]],
  ['output_20interface_2',['Output Interface',['../group___output.html',1,'']]],
  ['output_2ec_3',['output.c',['../output_8c.html',1,'']]],
  ['output_2eh_4',['output.h',['../output_8h.html',1,'']]]
];

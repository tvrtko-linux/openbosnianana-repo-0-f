var searchData=
[
  ['configuration_20interface_0',['Configuration Interface',['../group___config.html',1,'']]],
  ['constants_20for_20digital_20audio_20interfaces_1',['Constants for Digital Audio Interfaces',['../group___digital___audio___interface.html',1,'']]],
  ['constants_20for_20midi_20v1_2e0_2',['Constants for MIDI v1.0',['../group___m_i_d_i___interface.html',1,'']]],
  ['control_20interface_3',['Control Interface',['../group___control.html',1,'']]]
];

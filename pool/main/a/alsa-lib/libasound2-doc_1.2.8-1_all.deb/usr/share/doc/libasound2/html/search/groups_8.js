var searchData=
[
  ['midi_20commands_0',['MIDI Commands',['../group___m_i_d_i___commands.html',1,'']]],
  ['midi_20controllers_1',['MIDI Controllers',['../group___m_i_d_i___controllers.html',1,'']]],
  ['midi_20sequencer_2',['MIDI Sequencer',['../group___sequencer.html',1,'']]],
  ['mixer_20interface_3',['Mixer Interface',['../group___mixer.html',1,'']]]
];

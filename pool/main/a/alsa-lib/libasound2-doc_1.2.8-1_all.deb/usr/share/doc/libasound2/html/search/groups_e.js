var searchData=
[
  ['use_20case_20configuration_0',['Use Case Configuration',['../group__ucm__conf.html',1,'']]],
  ['use_20case_20interface_1',['Use Case Interface',['../group__ucm.html',1,'']]]
];

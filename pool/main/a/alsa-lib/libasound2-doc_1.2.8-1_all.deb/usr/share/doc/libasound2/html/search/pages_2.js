var searchData=
[
  ['configuration_20files_0',['Configuration files',['../conf.html',1,'index']]],
  ['control_20interface_1',['Control interface',['../control.html',1,'index']]]
];

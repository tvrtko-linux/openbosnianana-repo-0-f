var searchData=
[
  ['index_2c_20preamble_20and_20license_0',['Index, Preamble and License',['../index.html',1,'']]]
];

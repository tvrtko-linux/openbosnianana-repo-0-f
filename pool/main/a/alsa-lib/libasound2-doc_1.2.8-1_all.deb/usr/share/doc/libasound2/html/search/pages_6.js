var searchData=
[
  ['mixer_20interface_0',['Mixer interface',['../mixer.html',1,'index']]]
];

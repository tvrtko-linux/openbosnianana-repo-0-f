var indexSectionsWithContent =
{
  0: "_abcdefghilmnopqrstuvw",
  1: "aclst",
  2: "acdeghimnoprstu",
  3: "_s",
  4: "abcdefghilmnopqrstuvw",
  5: "s",
  6: "_s",
  7: "s",
  8: "a",
  9: "acdefghimoprstu",
  10: "abcdhimprst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};


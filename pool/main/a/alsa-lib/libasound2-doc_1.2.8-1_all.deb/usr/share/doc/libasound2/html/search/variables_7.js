var searchData=
[
  ['handle_0',['handle',['../structsnd__ctl__ext.html#af014c69147bee94eaddca82d6916326f',1,'snd_ctl_ext']]],
  ['hdr_1',['hdr',['../group__topology.html#ga1ffcf8621a8e6cc663f42355f619be1c',1,'snd_tplg_tlv_dbscale_template::hdr()'],['../group__topology.html#ga47753d107c983bcaa5f45d7b3394acf3',1,'snd_tplg_mixer_template::hdr()'],['../group__topology.html#ga480256cd2b82f47087f109bd8e939a76',1,'snd_tplg_enum_template::hdr()'],['../group__topology.html#ga3550150a1ee6e26abeab4bc0da5d0da1',1,'snd_tplg_bytes_template::hdr()']]],
  ['hw_5fconfig_2',['hw_config',['../group__topology.html#ga0c8c9d7a828ab74e896ffcdd8d4b1dc3',1,'snd_tplg_link_template']]],
  ['hw_5ffree_3',['hw_free',['../structsnd__pcm__extplug__callback.html#ad4d8fe041ed09e8b855c5ca45cb6899e',1,'snd_pcm_extplug_callback::hw_free()'],['../structsnd__pcm__ioplug__callback.html#aaf77cc71c899d58b9a9348c5efeab72f',1,'snd_pcm_ioplug_callback::hw_free()']]],
  ['hw_5fparams_4',['hw_params',['../structsnd__pcm__extplug__callback.html#ab25bf52043d5e06885b6edcdb8269776',1,'snd_pcm_extplug_callback::hw_params()'],['../structsnd__pcm__ioplug__callback.html#a57381783ffd6f0cea8836a151b0eaa87',1,'snd_pcm_ioplug_callback::hw_params()']]],
  ['hw_5fptr_5',['hw_ptr',['../structsnd__pcm__ioplug.html#aa314200db67b8cc9ad89cd53f6102f26',1,'snd_pcm_ioplug']]]
];


#ifndef ANALITZA_EXPORT_H
#define ANALITZA_EXPORT_H

#ifdef ANALITZA_STATIC_DEFINE
#  define ANALITZA_EXPORT
#  define ANALITZA_NO_EXPORT
#else
#  ifndef ANALITZA_EXPORT
#    ifdef Analitza_EXPORTS
        /* We are building this library */
#      define ANALITZA_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define ANALITZA_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef ANALITZA_NO_EXPORT
#    define ANALITZA_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef ANALITZA_DEPRECATED
#  define ANALITZA_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef ANALITZA_DEPRECATED_EXPORT
#  define ANALITZA_DEPRECATED_EXPORT ANALITZA_EXPORT ANALITZA_DEPRECATED
#endif

#ifndef ANALITZA_DEPRECATED_NO_EXPORT
#  define ANALITZA_DEPRECATED_NO_EXPORT ANALITZA_NO_EXPORT ANALITZA_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef ANALITZA_NO_DEPRECATED
#    define ANALITZA_NO_DEPRECATED
#  endif
#endif

#endif /* ANALITZA_EXPORT_H */

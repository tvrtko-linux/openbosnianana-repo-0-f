
#ifndef ANALITZAGUI_EXPORT_H
#define ANALITZAGUI_EXPORT_H

#ifdef ANALITZAGUI_STATIC_DEFINE
#  define ANALITZAGUI_EXPORT
#  define ANALITZAGUI_NO_EXPORT
#else
#  ifndef ANALITZAGUI_EXPORT
#    ifdef AnalitzaGui_EXPORTS
        /* We are building this library */
#      define ANALITZAGUI_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define ANALITZAGUI_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef ANALITZAGUI_NO_EXPORT
#    define ANALITZAGUI_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef ANALITZAGUI_DEPRECATED
#  define ANALITZAGUI_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef ANALITZAGUI_DEPRECATED_EXPORT
#  define ANALITZAGUI_DEPRECATED_EXPORT ANALITZAGUI_EXPORT ANALITZAGUI_DEPRECATED
#endif

#ifndef ANALITZAGUI_DEPRECATED_NO_EXPORT
#  define ANALITZAGUI_DEPRECATED_NO_EXPORT ANALITZAGUI_NO_EXPORT ANALITZAGUI_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef ANALITZAGUI_NO_DEPRECATED
#    define ANALITZAGUI_NO_DEPRECATED
#  endif
#endif

#endif /* ANALITZAGUI_EXPORT_H */

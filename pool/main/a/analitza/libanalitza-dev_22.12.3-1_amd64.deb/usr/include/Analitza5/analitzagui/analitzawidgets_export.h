
#ifndef ANALITZAWIDGETS_EXPORT_H
#define ANALITZAWIDGETS_EXPORT_H

#ifdef ANALITZAWIDGETS_STATIC_DEFINE
#  define ANALITZAWIDGETS_EXPORT
#  define ANALITZAWIDGETS_NO_EXPORT
#else
#  ifndef ANALITZAWIDGETS_EXPORT
#    ifdef AnalitzaWidgets_EXPORTS
        /* We are building this library */
#      define ANALITZAWIDGETS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define ANALITZAWIDGETS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef ANALITZAWIDGETS_NO_EXPORT
#    define ANALITZAWIDGETS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef ANALITZAWIDGETS_DEPRECATED
#  define ANALITZAWIDGETS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef ANALITZAWIDGETS_DEPRECATED_EXPORT
#  define ANALITZAWIDGETS_DEPRECATED_EXPORT ANALITZAWIDGETS_EXPORT ANALITZAWIDGETS_DEPRECATED
#endif

#ifndef ANALITZAWIDGETS_DEPRECATED_NO_EXPORT
#  define ANALITZAWIDGETS_DEPRECATED_NO_EXPORT ANALITZAWIDGETS_NO_EXPORT ANALITZAWIDGETS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef ANALITZAWIDGETS_NO_DEPRECATED
#    define ANALITZAWIDGETS_NO_DEPRECATED
#  endif
#endif

#endif /* ANALITZAWIDGETS_EXPORT_H */

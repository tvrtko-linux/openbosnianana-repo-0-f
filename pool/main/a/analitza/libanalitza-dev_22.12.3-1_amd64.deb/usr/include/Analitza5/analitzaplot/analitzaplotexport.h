
#ifndef ANALITZAPLOT_EXPORT_H
#define ANALITZAPLOT_EXPORT_H

#ifdef ANALITZAPLOT_STATIC_DEFINE
#  define ANALITZAPLOT_EXPORT
#  define ANALITZAPLOT_NO_EXPORT
#else
#  ifndef ANALITZAPLOT_EXPORT
#    ifdef AnalitzaPlot_EXPORTS
        /* We are building this library */
#      define ANALITZAPLOT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define ANALITZAPLOT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef ANALITZAPLOT_NO_EXPORT
#    define ANALITZAPLOT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef ANALITZAPLOT_DEPRECATED
#  define ANALITZAPLOT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef ANALITZAPLOT_DEPRECATED_EXPORT
#  define ANALITZAPLOT_DEPRECATED_EXPORT ANALITZAPLOT_EXPORT ANALITZAPLOT_DEPRECATED
#endif

#ifndef ANALITZAPLOT_DEPRECATED_NO_EXPORT
#  define ANALITZAPLOT_DEPRECATED_NO_EXPORT ANALITZAPLOT_NO_EXPORT ANALITZAPLOT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef ANALITZAPLOT_NO_DEPRECATED
#    define ANALITZAPLOT_NO_DEPRECATED
#  endif
#endif

#endif /* ANALITZAPLOT_EXPORT_H */

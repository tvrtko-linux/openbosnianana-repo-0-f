abstract class FourLeggedAnimal
{
    public abstract string Describe();
}
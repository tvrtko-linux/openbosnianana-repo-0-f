#ifndef _MAMMAL_H_
#define _MAMMAL_H_

#include "animal.h"

class Mammal: public Animal {
  virtual ~Mammal() = 0;
};

#endif

public abstract class Animal {
  public abstract string name();
}

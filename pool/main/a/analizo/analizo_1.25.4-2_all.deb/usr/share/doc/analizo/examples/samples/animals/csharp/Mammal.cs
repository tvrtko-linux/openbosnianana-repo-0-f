public abstract class Mammal : Animal {
  public virtual void close() {}
}

public abstract class Mammal extends Animal {
  public abstract void close();
}

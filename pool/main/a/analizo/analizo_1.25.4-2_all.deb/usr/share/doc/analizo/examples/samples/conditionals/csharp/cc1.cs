using System;

public void cc1() {
  Console.WriteLine("ok\n");
}
using System;

public void cc2() {
  if (something) {
    Console.WriteLine("ok\n");
  } else {
    Console.WriteLine("nope\n");
  }
}

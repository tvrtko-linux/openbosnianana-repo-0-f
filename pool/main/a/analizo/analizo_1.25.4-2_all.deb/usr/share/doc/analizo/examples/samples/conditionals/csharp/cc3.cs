using System;

public void cc3() {
  if (something) {
    Console.WriteLine("ok\n");
  } else {
      if (otherthing) {
        Console.WriteLine("nope\n");
      }
    }
}

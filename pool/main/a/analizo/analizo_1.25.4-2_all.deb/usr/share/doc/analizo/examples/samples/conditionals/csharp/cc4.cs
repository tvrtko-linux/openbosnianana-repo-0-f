using System;

public void cc4() {
  if (something) {
    Console.WriteLine("ok\n");
  } else {
      if (otherthing) {
        if (someotherthing) {
          Console.WriteLine("Something\n");
        } else {
            Console.WriteLine("Some other thing\n");
          }
        Console.WriteLine("nope\n");
      }
    }
}

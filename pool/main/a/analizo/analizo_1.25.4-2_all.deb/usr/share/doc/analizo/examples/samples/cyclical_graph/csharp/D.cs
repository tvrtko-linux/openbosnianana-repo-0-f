using System;

namespace d {

  public class D {
    private string _name;

    public D(string name) {
      this._name = name;
    }

    public string name() {
      return this._name;
    }
  }

}

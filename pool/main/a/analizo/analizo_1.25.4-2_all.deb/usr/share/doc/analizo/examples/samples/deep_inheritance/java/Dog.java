class Dog {
    String name;
    Human owner;

    public Human getOwner(){
        return owner;
    }
}

class DogFirstGreatGrandson extends DogGrandson {
    String noses;
}

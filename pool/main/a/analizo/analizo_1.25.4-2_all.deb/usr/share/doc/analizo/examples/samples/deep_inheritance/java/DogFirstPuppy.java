class DogFirstPuppy extends Dog {
    String color;
}

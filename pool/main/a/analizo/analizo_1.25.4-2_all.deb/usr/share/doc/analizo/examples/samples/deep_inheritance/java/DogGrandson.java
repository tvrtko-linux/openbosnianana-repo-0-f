class DogGrandson extends DogFirstPuppy {
    String number_of_eyes;
}

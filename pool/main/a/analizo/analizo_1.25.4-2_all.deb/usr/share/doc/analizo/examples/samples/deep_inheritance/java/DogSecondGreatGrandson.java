class DogSecondGreatGrandson extends DogGrandson {
    String arms;
}

class DogSecondPuppy extends Dog {
    String age;
}

class DogSuperYoung extends DogFirstGreatGrandson {
    String accs;
}

class Human {
    String name;
    Dog pet;

    public Dog getPetName(){
        return pet.name;
    }
}

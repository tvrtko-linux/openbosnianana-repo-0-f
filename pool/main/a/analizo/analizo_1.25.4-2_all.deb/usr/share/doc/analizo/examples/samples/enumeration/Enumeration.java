public enum Enumeration {
  ONE, TWO, THREE, FOUR
}

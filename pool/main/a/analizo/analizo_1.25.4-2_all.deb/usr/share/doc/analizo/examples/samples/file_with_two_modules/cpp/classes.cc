#include "classes.h"

void Class1::say() {
  // don't say nothing, actually
}

void Class2::say() {
  // don't say nothing, actually
}

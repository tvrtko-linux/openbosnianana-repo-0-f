#ifndef _CLASSES_H_
#define _CLASSES_H_

class Class1 {
  public:
    void say();
};

class Class2 {
  public:
    void say();
};

#endif // _CLASSES_H_

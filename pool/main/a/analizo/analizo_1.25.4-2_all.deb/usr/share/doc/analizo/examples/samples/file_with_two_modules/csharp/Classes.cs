namespace classes {

  public class Class1 {
    public void say() {
      // don't say nothing, actually
    }
  }

  public class Class2 {
    public void say() {
      // don't say nothing, actually
    }
  }

}

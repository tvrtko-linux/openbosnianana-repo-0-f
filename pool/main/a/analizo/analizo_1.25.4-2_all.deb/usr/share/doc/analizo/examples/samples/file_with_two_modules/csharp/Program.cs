using classes;

public class Program {

  static void Main(string[] args) {
    Class1 c1 = new Class1();
    Class2 c2 = new Class2();
    c1.say();
    c2.say();
  }

}

#include <stdio.h>

SOME_EXTERNAL_MACRO(1);

int main(int argc, char **argv);

using System;

class CSharp_Backend {
  public void ProcessRequest() {
    // Anything...
  }
}

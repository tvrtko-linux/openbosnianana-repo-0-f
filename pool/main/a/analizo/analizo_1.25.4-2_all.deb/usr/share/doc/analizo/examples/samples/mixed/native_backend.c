#include <stdio.h>

void process_request() {
  // ... whatever
}

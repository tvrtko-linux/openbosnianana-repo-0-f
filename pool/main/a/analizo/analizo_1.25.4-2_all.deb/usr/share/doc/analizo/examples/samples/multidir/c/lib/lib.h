#ifndef _LIB_H_
#define _LIB_H_

void say_hello();

#endif // _LIB_H_

#include <stdio.h>
#include "lib.h"

void say_hello() {
  printf("Hello, world!\n");
}

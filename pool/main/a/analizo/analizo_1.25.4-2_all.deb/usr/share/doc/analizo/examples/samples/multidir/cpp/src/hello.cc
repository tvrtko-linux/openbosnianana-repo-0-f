#include "hello.h"

using namespace std;

string HelloWorld::message() {
  return "Hello, world";
}

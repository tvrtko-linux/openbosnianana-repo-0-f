using System;

public class main {

  static public int Main() {
    HelloWorld hello = new HelloWorld();
    Console.WriteLine(hello.message());
    return 0;
  }

}

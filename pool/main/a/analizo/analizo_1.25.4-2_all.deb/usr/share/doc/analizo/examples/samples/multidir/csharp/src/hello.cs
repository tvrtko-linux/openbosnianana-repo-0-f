public class HelloWorld {
  public string message() {
    return "Hello, world";
  }
}

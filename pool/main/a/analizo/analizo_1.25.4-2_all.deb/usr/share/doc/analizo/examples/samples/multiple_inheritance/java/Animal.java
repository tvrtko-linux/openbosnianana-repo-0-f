abstract class Animal {
  private Integer hp = 0;
  public void eat() {
    hp++;
  }
}

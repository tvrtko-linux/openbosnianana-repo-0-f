class Bird extends Animal implements Flying {
  @Override
  public void fly() {
    //Do something useful
  }
}

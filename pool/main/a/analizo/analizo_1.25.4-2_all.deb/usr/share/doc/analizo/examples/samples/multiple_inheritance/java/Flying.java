interface Flying {
  public void fly();
}

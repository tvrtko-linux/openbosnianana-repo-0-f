class Horse extends Animal {
  @Override
  public void eat() {
    hp+=2;
  }
}

class Pegasus extends Horse implements Flying {
  //now every time when your Pegasus eats, will receive +2 hp
  @Override
  public void fly() {
    //Do something useful
  }
}

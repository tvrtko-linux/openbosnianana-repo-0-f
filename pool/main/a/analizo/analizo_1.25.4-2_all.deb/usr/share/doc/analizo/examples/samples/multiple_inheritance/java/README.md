This source-code was inspired by the András Iványi reply on Stack Overflow
thread below:

* https://stackoverflow.com/questions/21824402/java-multiple-inheritance

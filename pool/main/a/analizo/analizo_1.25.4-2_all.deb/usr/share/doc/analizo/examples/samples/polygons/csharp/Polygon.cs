using System;

abstract class Polygon {
  protected int width, heigth;

  public abstract int Area();
  public abstract int Perimeter();
}

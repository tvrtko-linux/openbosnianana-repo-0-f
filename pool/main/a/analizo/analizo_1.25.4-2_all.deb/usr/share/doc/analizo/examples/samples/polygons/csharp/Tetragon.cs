using System;

abstract class Tetragon : Polygon {
  public abstract override int Area();
  public abstract override int Perimeter();
}

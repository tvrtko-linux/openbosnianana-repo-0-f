public class Triangle extends Polygon {
  public int area () { 
    return (width * height/2); 
  }
}

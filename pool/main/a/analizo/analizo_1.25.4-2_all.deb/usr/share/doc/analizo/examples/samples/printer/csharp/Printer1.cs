using System;

class Printer1 {
  private string message;

  public Printer1(string msg) {
    this.message = msg;
  }
}

using System;

class Printer2 {
  private string message;

  public Printer2(string msg) {
    this.message = msg;
  }
}

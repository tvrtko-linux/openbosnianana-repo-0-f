using System;

class Program {
  static void Main() {
    Printer1 print1 = new Printer1("one");
    Printer2 print2 = new Printer2("two");
  }
}

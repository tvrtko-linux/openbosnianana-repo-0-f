class Printer2 {
  private String message;
  Printer2(String msg) {
    this.message = msg;
  }
}

#ifndef _MODULE3_H_
#define _MODULE3_H_

extern int variable;

void callback();

#endif // _MODULE3_H_

using System;

class Module1 {
  public static void SayHello() {
    Console.WriteLine("Hello, world");
  }

  public static void SayBye() {
    Console.WriteLine("Byem cruel world");
  }
}

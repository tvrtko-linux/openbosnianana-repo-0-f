using System;

class Module2 {
  public static int variable = 15;

  public static void Callback() {
    Console.WriteLine("this is callback function");
  }
}

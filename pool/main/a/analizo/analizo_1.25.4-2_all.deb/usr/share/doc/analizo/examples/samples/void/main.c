#include <stdio.h>

int main(void) {
  printf("main(void) has no args\n");
  return 0;
}

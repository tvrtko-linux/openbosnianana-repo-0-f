public class GenericClass<T> {
  public void print(){
    System.out.print(T.class);
  }
}

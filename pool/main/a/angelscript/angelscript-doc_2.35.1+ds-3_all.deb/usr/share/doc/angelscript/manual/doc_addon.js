var doc_addon =
[
    [ "Application modules", "doc_addon_application.html", "doc_addon_application" ],
    [ "Script extensions", "doc_addon_script.html", "doc_addon_script" ]
];
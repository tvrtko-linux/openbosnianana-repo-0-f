var group__api__auxiliary__interfaces =
[
    [ "asIBinaryStream", "classas_i_binary_stream.html", [
      [ "Read", "classas_i_binary_stream.html#a8bbd68cea1f96b42c723f9732ac19140", null ],
      [ "Write", "classas_i_binary_stream.html#a57724f9cd63a625a843bf97e7704d9a7", null ]
    ] ],
    [ "asILockableSharedBool", "classas_i_lockable_shared_bool.html", [
      [ "AddRef", "classas_i_lockable_shared_bool.html#a1183742552ce6b952cc3742bd456d787", null ],
      [ "Get", "classas_i_lockable_shared_bool.html#abab39fc60f00ae8941423258ffc2c3c6", null ],
      [ "Lock", "classas_i_lockable_shared_bool.html#aef12cc309395d682aa138da5eea9d82b", null ],
      [ "Release", "classas_i_lockable_shared_bool.html#a1dae71f6f1141b5b16520232a9ea5fb2", null ],
      [ "Set", "classas_i_lockable_shared_bool.html#aa29488ac2f1c38788d5e79545fdfc8c7", null ],
      [ "Unlock", "classas_i_lockable_shared_bool.html#a863984c1b271df84f71fb5ba978ce2b8", null ]
    ] ],
    [ "asIJITCompiler", "classas_i_j_i_t_compiler.html", [
      [ "CompileFunction", "classas_i_j_i_t_compiler.html#aa6270727e61d8708d651a0f5faada695", null ],
      [ "ReleaseJITFunction", "classas_i_j_i_t_compiler.html#afbf9390868269c9224df85d49aabd451", null ]
    ] ]
];
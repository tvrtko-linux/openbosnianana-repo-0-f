var group__api__memory__functions =
[
    [ "asAllocMem", "group__api__memory__functions.html#ga54a201f99d19e648526abf30ae31e466", null ],
    [ "asFreeMem", "group__api__memory__functions.html#ga9da61275bbfd5f7bd55ed411d05fe103", null ],
    [ "asResetGlobalMemoryFunctions", "group__api__memory__functions.html#ga9267c4ad35aceaf7cc0961cd42147ee7", null ],
    [ "asSetGlobalMemoryFunctions", "group__api__memory__functions.html#ga527ab125defc58aa40cc151a25582a31", null ]
];
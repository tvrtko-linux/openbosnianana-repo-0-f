var group__api__principal__functions =
[
    [ "asCreateScriptEngine", "group__api__principal__functions.html#gacb6a62345d9cca6c9b5a3dac67d80d0b", null ],
    [ "asGetActiveContext", "group__api__principal__functions.html#gad3a20dc58093b92a5a44c7b6ada34a10", null ],
    [ "asGetTypeTraits", "group__api__principal__functions.html#ga863f2a1e60e6c19eea9c6b34690dcc00", null ]
];
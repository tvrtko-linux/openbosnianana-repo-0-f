var modules =
[
    [ "Principal interfaces", "group__api__principal__interfaces.html", "group__api__principal__interfaces" ],
    [ "Secondary interfaces", "group__api__secondary__interfaces.html", "group__api__secondary__interfaces" ],
    [ "Auxiliary interfaces", "group__api__auxiliary__interfaces.html", "group__api__auxiliary__interfaces" ],
    [ "Principal functions", "group__api__principal__functions.html", "group__api__principal__functions" ],
    [ "Memory functions", "group__api__memory__functions.html", "group__api__memory__functions" ],
    [ "Multi-thread support functions", "group__api__multithread__functions.html", "group__api__multithread__functions" ],
    [ "Auxiliary functions", "group__api__auxiliary__functions.html", "group__api__auxiliary__functions" ]
];
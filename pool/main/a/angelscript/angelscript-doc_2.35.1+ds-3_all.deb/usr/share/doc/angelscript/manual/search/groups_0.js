var searchData=
[
  ['auxiliary_20functions_1721',['Auxiliary functions',['../group__api__auxiliary__functions.html',1,'']]],
  ['auxiliary_20interfaces_1722',['Auxiliary interfaces',['../group__api__auxiliary__interfaces.html',1,'']]]
];

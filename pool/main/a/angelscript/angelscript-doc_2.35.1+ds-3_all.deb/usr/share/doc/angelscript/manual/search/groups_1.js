var searchData=
[
  ['memory_20functions_1723',['Memory functions',['../group__api__memory__functions.html',1,'']]],
  ['multi_2dthread_20support_20functions_1724',['Multi-thread support functions',['../group__api__multithread__functions.html',1,'']]]
];

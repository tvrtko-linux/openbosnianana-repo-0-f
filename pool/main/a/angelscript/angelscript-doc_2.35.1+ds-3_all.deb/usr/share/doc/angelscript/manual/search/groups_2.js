var searchData=
[
  ['principal_20functions_1725',['Principal functions',['../group__api__principal__functions.html',1,'']]],
  ['principal_20interfaces_1726',['Principal interfaces',['../group__api__principal__interfaces.html',1,'']]]
];

var searchData=
[
  ['secondary_20interfaces_1727',['Secondary interfaces',['../group__api__secondary__interfaces.html',1,'']]]
];

var searchData=
[
  ['byte_20code_20instructions_1740',['Byte code instructions',['../doc_adv_jit_1.html',1,'doc_adv_jit_topic']]]
];

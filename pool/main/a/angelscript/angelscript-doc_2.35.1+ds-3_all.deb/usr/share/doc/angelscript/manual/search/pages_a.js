var searchData=
[
  ['license_1804',['License',['../doc_license.html',1,'main_topics']]]
];

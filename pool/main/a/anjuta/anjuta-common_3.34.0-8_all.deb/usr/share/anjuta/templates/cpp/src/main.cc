[+ autogen5 template +]
[+INCLUDE (string-append "licenses/" (get "License") ".tpl") \+]
[+INCLUDE (string-append "indent.tpl") \+]
/* [+INVOKE EMACS-MODELINE MODE="C" \+] */
[+INVOKE START-INDENT\+]
/*
 * main.cc
 * Copyright (C) [+(shell "date +%Y")+] [+Author+][+IF (get "Email")+] <[+Email+]>[+ENDIF+]
 * 
[+INVOKE LICENSE-DESCRIPTION PFX=" * " PROGRAM=(get "Name") OWNER=(get "Author") \+]
 */

#include <iostream>

int main()
{
	std::cout << "Hello world!" << std::endl;
	return 0;
}
[+INVOKE END-INDENT\+]

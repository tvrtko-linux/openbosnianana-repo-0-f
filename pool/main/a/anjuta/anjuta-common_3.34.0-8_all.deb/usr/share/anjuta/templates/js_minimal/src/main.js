#!/usr/bin/gjs

const GLib = imports.gi.GLib;

print("Hello World!");

[+ autogen5 template +]
[+INCLUDE (string-append "licenses/" (get "License") ".tpl") \+]
[+INCLUDE (string-append "indent.tpl") \+]
/* [+INVOKE EMACS-MODELINE MODE="C" \+] */
[+INVOKE START-INDENT\+]
/*
 * lib.h
 * Copyright (C) [+(shell "date +%Y")+] [+Author+][+IF (get "Email")+] <[+Email+]>[+ENDIF+]
 * 
[+INVOKE LICENSE-DESCRIPTION PFX=" * " PROGRAM=(get "Name") OWNER=(get "Author") \+]
 */

int [+NameCLower+]_func (void);
[+INVOKE END-INDENT\+]

'''
anorack's private modules
'''

type(lambda: (yield from []))  # Python >= 3.3 is required

# vim:ts=4 sts=4 sw=4 et

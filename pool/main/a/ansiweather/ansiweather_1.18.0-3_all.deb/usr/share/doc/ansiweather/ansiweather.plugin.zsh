export PATH=${PATH}:$(dirname $0)

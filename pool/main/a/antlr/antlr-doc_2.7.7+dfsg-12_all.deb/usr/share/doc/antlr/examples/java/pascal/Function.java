public class Function extends Symbol {
	public Function(String name) {
		super(name);
	}
}

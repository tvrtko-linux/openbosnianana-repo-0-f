import java.io.*;

public class Procedure extends Symbol implements Serializable {
	public Procedure(String name) {
		super(name);
	}
}

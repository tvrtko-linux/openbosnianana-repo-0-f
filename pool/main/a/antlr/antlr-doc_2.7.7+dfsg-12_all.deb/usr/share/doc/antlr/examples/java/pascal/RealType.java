/** Predefined Real Pascal type */
import java.io.*;

public class RealType extends TypeSpecifier implements Serializable {
	public String toString() {
		return "real";
	}
}
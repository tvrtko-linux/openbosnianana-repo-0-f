var aom__decoder_8h =
[
    [ "AOM_DECODER_ABI_VERSION", "group__decoder.html#ga23378c7ca8c361c097181aaaa2a5a734", null ],
    [ "AOM_CODEC_CAP_EXTERNAL_FRAME_BUFFER", "group__decoder.html#gabd11df9f35d52ea76de2c8d32aa36963", null ],
    [ "aom_codec_dec_init", "group__decoder.html#gafdbfca65b19ab1f6d72b32cd01753b9b", null ],
    [ "aom_codec_stream_info_t", "group__decoder.html#ga67b2d2d0bfa394bbbd1c5ce4876ed48c", null ],
    [ "aom_codec_dec_cfg_t", "group__decoder.html#gab456f6df8429a23dce32438f0a570ef6", null ],
    [ "aom_codec_dec_init_ver", "group__decoder.html#gab2bfd2f5517b9452d2c71b7c2b2e8e8d", null ],
    [ "aom_codec_peek_stream_info", "group__decoder.html#ga2544bac9fdc439f0effd6b1b14df54be", null ],
    [ "aom_codec_get_stream_info", "group__decoder.html#ga2b456cf67b1b64dabed370c5d7514b29", null ],
    [ "aom_codec_decode", "group__decoder.html#gab03fdb999d1f83a5896869a3ba5f68f7", null ],
    [ "aom_codec_get_frame", "group__decoder.html#ga9ee6dac1fc46ab5c254395eea5469d5d", null ],
    [ "aom_codec_set_frame_buffer_functions", "group__cap__external__frame__buffer.html#ga1818a812e4d1e70eeafbe5b0ee538d6e", null ]
];
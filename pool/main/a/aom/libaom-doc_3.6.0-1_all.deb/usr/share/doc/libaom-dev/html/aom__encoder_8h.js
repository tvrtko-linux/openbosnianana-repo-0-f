var aom__encoder_8h =
[
    [ "AOM_ENCODER_ABI_VERSION", "group__encoder.html#gae4af664f2049d5b7d7b644d9a61d497c", null ],
    [ "AOM_CODEC_CAP_PSNR", "group__encoder.html#gaaf72058c11fcf006c41662114997e12c", null ],
    [ "AOM_CODEC_CAP_HIGHBITDEPTH", "group__encoder.html#ga608725216f15096fa209d30fef121c1c", null ],
    [ "AOM_CODEC_USE_PSNR", "group__encoder.html#gae722c9f9ba9b4ca8dba6bbe7c0692024", null ],
    [ "AOM_CODEC_USE_HIGHBITDEPTH", "group__encoder.html#gae30bbbdef18e9da3631b69c170533e92", null ],
    [ "AOM_ERROR_RESILIENT_DEFAULT", "group__encoder.html#ga4118658e1fc1590f72fec38478ae230d", null ],
    [ "AOM_EFLAG_FORCE_KF", "group__encoder.html#ga86a6a9053205149cccc98481b5460337", null ],
    [ "MAX_TILE_WIDTHS", "aom__encoder_8h.html#a3ec4904ea175471a03d10705f384d07c", null ],
    [ "MAX_TILE_HEIGHTS", "aom__encoder_8h.html#a446aae868ff07f3971d9e84b6602a890", null ],
    [ "aom_codec_enc_init", "group__encoder.html#gaade68a7d33d30f97dc9a596aa5e065d8", null ],
    [ "AOM_USAGE_GOOD_QUALITY", "group__encoder.html#ga03ca3defc61e1d70c34e9d94e7cee823", null ],
    [ "AOM_USAGE_REALTIME", "group__encoder.html#gae2cc24d3083099df8eb60ad65f81c62f", null ],
    [ "AOM_USAGE_ALL_INTRA", "group__encoder.html#ga264a9b5466698e980b8c37d133ae6043", null ],
    [ "aom_fixed_buf_t", "group__encoder.html#gaab769c729ea1273fe722dbfbff9d4c9c", null ],
    [ "aom_codec_er_flags_t", "group__encoder.html#ga5f326af84993f371bb165883bb5a5a59", null ],
    [ "aom_codec_cx_pkt_t", "group__encoder.html#ga54cbc3acf8791a8809139b101ae68a1b", null ],
    [ "aom_rational_t", "group__encoder.html#gaa937bad4eb45a2533c7d7801c4d975a1", null ],
    [ "cfg_options_t", "group__encoder.html#gabf8173fa6a1419e7e6798df8493fc562", null ],
    [ "aom_enc_frame_flags_t", "group__encoder.html#gacbef92200b831adb94283f84128f83de", null ],
    [ "aom_codec_enc_cfg_t", "group__encoder.html#gade71d5d928a6a975bcc6e404d652cba4", null ],
    [ "aom_codec_cx_pkt_kind", "group__encoder.html#gafeb69da4a9649a54e805f59c26d8dfed", [
      [ "AOM_CODEC_CX_FRAME_PKT", "group__encoder.html#ggafeb69da4a9649a54e805f59c26d8dfeda793165d0f219812342f69d5fd9b2b9c8", null ],
      [ "AOM_CODEC_STATS_PKT", "group__encoder.html#ggafeb69da4a9649a54e805f59c26d8dfeda7dcdcb6c401cac64ca98b51f52de8d4b", null ],
      [ "AOM_CODEC_FPMB_STATS_PKT", "group__encoder.html#ggafeb69da4a9649a54e805f59c26d8dfedaaa76df44da4c92b08150b8a5326f5ebe", null ],
      [ "AOM_CODEC_PSNR_PKT", "group__encoder.html#ggafeb69da4a9649a54e805f59c26d8dfeda3293bb764f30c11e9583510029578b75", null ],
      [ "AOM_CODEC_CUSTOM_PKT", "group__encoder.html#ggafeb69da4a9649a54e805f59c26d8dfeda476a2ac59be68d61662824316bd57a8e", null ]
    ] ],
    [ "aom_enc_pass", "group__encoder.html#ga92b6709b58dc3435e3ba652da562eda1", [
      [ "AOM_RC_ONE_PASS", "group__encoder.html#gga92b6709b58dc3435e3ba652da562eda1a1b4b8ee9c1910fc59ac9dfd9700f3f02", null ],
      [ "AOM_RC_FIRST_PASS", "group__encoder.html#gga92b6709b58dc3435e3ba652da562eda1ad342b33a290482c20238bfde5d9bea1e", null ],
      [ "AOM_RC_SECOND_PASS", "group__encoder.html#gga92b6709b58dc3435e3ba652da562eda1a606e695b3dd96b1875bdae681ba6313d", null ],
      [ "AOM_RC_THIRD_PASS", "group__encoder.html#gga92b6709b58dc3435e3ba652da562eda1a89ebdde284dd2568df883658bdf3f8f7", null ],
      [ "AOM_RC_LAST_PASS", "group__encoder.html#gga92b6709b58dc3435e3ba652da562eda1a621c3f07937527618dc06e962425f6cc", null ]
    ] ],
    [ "aom_rc_mode", "group__encoder.html#ga7c084d3ecef569aad166ce70b0e8a957", [
      [ "AOM_VBR", "group__encoder.html#gga7c084d3ecef569aad166ce70b0e8a957a7d3a2574737ea63d0f160ffdbd7f0110", null ],
      [ "AOM_CBR", "group__encoder.html#gga7c084d3ecef569aad166ce70b0e8a957a14b6057d61c61e6117f5af16dcf89b0c", null ],
      [ "AOM_CQ", "group__encoder.html#gga7c084d3ecef569aad166ce70b0e8a957a70aa1f15e91f6576ba3e63879947be64", null ],
      [ "AOM_Q", "group__encoder.html#gga7c084d3ecef569aad166ce70b0e8a957aff3bbd4fe870b4b946c2093e59eb14e5", null ]
    ] ],
    [ "aom_kf_mode", "group__encoder.html#gac0498fc02cd368e6d9675cdb0bab5a84", [
      [ "AOM_KF_FIXED", "group__encoder.html#ggac0498fc02cd368e6d9675cdb0bab5a84a8d6f57a670b8bd8f11dae3e89acedb1d", null ],
      [ "AOM_KF_AUTO", "group__encoder.html#ggac0498fc02cd368e6d9675cdb0bab5a84aea1965a235dea1b99d2b52145be35d4e", null ],
      [ "AOM_KF_DISABLED", "group__encoder.html#ggac0498fc02cd368e6d9675cdb0bab5a84af81473ffe0169271763f9c9d05393405", null ]
    ] ],
    [ "aom_superres_mode", "group__encoder.html#ga10e276f2fa8fe789b69c029404e6ed15", [
      [ "AOM_SUPERRES_NONE", "group__encoder.html#gga10e276f2fa8fe789b69c029404e6ed15acf501f7a5d8673fa7546aa891c357ed3", null ],
      [ "AOM_SUPERRES_FIXED", "group__encoder.html#gga10e276f2fa8fe789b69c029404e6ed15aee3c6d6fa67efdaa571a59a6ac531dcc", null ],
      [ "AOM_SUPERRES_RANDOM", "group__encoder.html#gga10e276f2fa8fe789b69c029404e6ed15a2f3d27caf9b7e9686f087b5f3b0d713a", null ],
      [ "AOM_SUPERRES_QTHRESH", "group__encoder.html#gga10e276f2fa8fe789b69c029404e6ed15a3197eacb02a2d3842f4b04bc86207f7a", null ],
      [ "AOM_SUPERRES_AUTO", "group__encoder.html#gga10e276f2fa8fe789b69c029404e6ed15a6e8402341ecd5dcd6e710089a3db4513", null ]
    ] ],
    [ "aom_codec_enc_init_ver", "group__encoder.html#ga205cf6f9460f4b4a842872012ef6fb0c", null ],
    [ "aom_codec_enc_config_default", "group__encoder.html#gabe40293fd7d1aaa2a642c41716c26f68", null ],
    [ "aom_codec_enc_config_set", "group__encoder.html#gaf4a4c3c3c91dd92c960990f6e534271d", null ],
    [ "aom_codec_get_global_headers", "group__encoder.html#gaccf857f83c29408e5aff2c918c464ba4", null ],
    [ "aom_codec_encode", "group__encoder.html#ga6f4a777de5389771e783df7ff1f116d4", null ],
    [ "aom_codec_set_cx_data_buf", "group__encoder.html#ga67b338974dd0a21cefec71d152dd5f51", null ],
    [ "aom_codec_get_cx_data", "group__encoder.html#ga45654d08fa4708e374af8aae73c943ac", null ],
    [ "aom_codec_get_preview_frame", "group__encoder.html#ga7e32e8290b36ed5be2ecf6ef09a94973", null ]
];
var aom__external__partition_8h =
[
    [ "AOM_EXT_PART_ABI_VERSION", "group__aom__encoder.html#ga5a44302260efb45ebf560f7fb0b4352b", null ],
    [ "AOM_EXT_PART_SIZE_DIRECT_SPLIT", "group__aom__encoder.html#gae5ea047136d781f9d7eb4c342121b41a", null ],
    [ "AOM_EXT_PART_SIZE_PRUNE_PART", "group__aom__encoder.html#ga29427094de00e8d1883207afcc28b22c", null ],
    [ "AOM_EXT_PART_SIZE_PRUNE_NONE", "group__aom__encoder.html#gaf8d9d8acde0c4a982e80d1dec78ba8ad", null ],
    [ "AOM_EXT_PART_SIZE_TERM_NONE", "group__aom__encoder.html#ga28cc21cd9c9fc1f02818e90772a0baf6", null ],
    [ "AOM_EXT_PART_SIZE_TERM_SPLIT", "group__aom__encoder.html#gaff93c6de790dccd2faaa6556130d0b3b", null ],
    [ "AOM_EXT_PART_SIZE_PRUNE_RECT", "group__aom__encoder.html#ga6ee5804fef84710679f46bb77895aa90", null ],
    [ "AOM_EXT_PART_SIZE_PRUNE_AB", "group__aom__encoder.html#gae2d6be6f94a6e0342f990d45826f9d4e", null ],
    [ "AOM_EXT_PART_SIZE_PRUNE_4_WAY", "group__aom__encoder.html#ga23f13860556f8879c2cef2565b8182a8", null ],
    [ "aom_ext_part_model_t", "group__aom__encoder.html#ga8ac829090566737c469a7147207e8855", null ],
    [ "aom_ext_part_decision_mode_t", "group__aom__encoder.html#gaca3421fd8424ed3ab48704748a12c9d1", null ],
    [ "aom_ext_part_config_t", "group__aom__encoder.html#ga88539c1f9e72d6ab6f8802ff265539dd", null ],
    [ "aom_partition_features_before_none_t", "group__aom__encoder.html#ga45f71361ba7598dbb347d6f8de8f37b6", null ],
    [ "aom_partition_features_none_t", "group__aom__encoder.html#gaeb906a5b059249c051cb0d2f853aff6c", null ],
    [ "aom_partition_features_split_t", "group__aom__encoder.html#ga00f4961195d6d1d53c045d9675bb4d78", null ],
    [ "aom_partition_features_rect_t", "group__aom__encoder.html#gad09f5b034137ba0981dd5f2dc075b27f", null ],
    [ "aom_partition_features_ab_t", "group__aom__encoder.html#ga0713a9137d099e441bd6b7ed10be1b0d", null ],
    [ "aom_sb_tpl_features_t", "group__aom__encoder.html#gadb34e02e5b029504370f99a886371710", null ],
    [ "aom_sb_simple_motion_features_t", "group__aom__encoder.html#ga790f05ad7832f2614a13fd60bd3430fe", null ],
    [ "aom_sb_features_t", "group__aom__encoder.html#gacfd479b87a0dc8cb0602268f9dca37ce", null ],
    [ "aom_partition_features_t", "group__aom__encoder.html#ga2d4ad2535544500d48ac6ce6605cdf0c", null ],
    [ "aom_partition_decision_t", "group__aom__encoder.html#gae9645fe5bb80ebb66970f85bdfc81d5f", null ],
    [ "aom_partition_stats_t", "group__aom__encoder.html#gab9478e27301dfb5581f8bdf9efb40f3e", null ],
    [ "aom_ext_part_status_t", "group__aom__encoder.html#ga4af3be5d269421964fc8b3e8681121dd", null ],
    [ "aom_ext_part_create_model_fn_t", "group__aom__encoder.html#ga1a11077df0999ffba72a6fbfc8fe3331", null ],
    [ "aom_ext_part_send_features_fn_t", "group__aom__encoder.html#ga8a09d2e568a6727f6dcfa189dcb64dc0", null ],
    [ "aom_ext_part_get_decision_fn_t", "group__aom__encoder.html#gaf0c953c3c35d72df3e4bace498773be8", null ],
    [ "aom_ext_part_send_partition_stats_fn_t", "group__aom__encoder.html#ga2c864d073d251c0ed7fe8d2b71c26417", null ],
    [ "aom_ext_part_delete_model_fn_t", "group__aom__encoder.html#ga900ebe22eaa0f9296c4a876316fd4d82", null ],
    [ "aom_ext_part_funcs_t", "group__aom__encoder.html#gac18e4b6e5fd6cb617a2674cf3de3f57e", null ],
    [ "aom_ext_part_decision_mode", "group__aom__encoder.html#ga7543b396ff2eef24d90b8edd094a9148", [
      [ "AOM_EXT_PART_WHOLE_TREE", "group__aom__encoder.html#gga7543b396ff2eef24d90b8edd094a9148a5a7d15606a5c9329bac1dfc151b9d435", null ],
      [ "AOM_EXT_PART_RECURSIVE", "group__aom__encoder.html#gga7543b396ff2eef24d90b8edd094a9148a8d0b63296dd567f81a43633ef05cfbca", null ]
    ] ],
    [ "AOM_EXT_PART_FEATURE_ID", "group__aom__encoder.html#ga241e62c4cf0d5f31f56e6be63df8e566", [
      [ "AOM_EXT_PART_FEATURE_BEFORE_NONE", "group__aom__encoder.html#gga241e62c4cf0d5f31f56e6be63df8e566ac2f4b053c43e13f26013b390d512e564", null ],
      [ "AOM_EXT_PART_FEATURE_BEFORE_NONE_PART2", "group__aom__encoder.html#gga241e62c4cf0d5f31f56e6be63df8e566ac7c358447d52d472e4eebc459f59cdd2", null ],
      [ "AOM_EXT_PART_FEATURE_AFTER_NONE", "group__aom__encoder.html#gga241e62c4cf0d5f31f56e6be63df8e566a5c530dd2301b7656a20354c57bbaee3c", null ],
      [ "AOM_EXT_PART_FEATURE_AFTER_NONE_PART2", "group__aom__encoder.html#gga241e62c4cf0d5f31f56e6be63df8e566ad632ccd3d223aa42429ab0ab72cdd17c", null ],
      [ "AOM_EXT_PART_FEATURE_AFTER_SPLIT", "group__aom__encoder.html#gga241e62c4cf0d5f31f56e6be63df8e566a564c8ee9f1b421daac16dd6a5165bd94", null ],
      [ "AOM_EXT_PART_FEATURE_AFTER_SPLIT_PART2", "group__aom__encoder.html#gga241e62c4cf0d5f31f56e6be63df8e566a8ef0e6c1c345c3da7bdda39ef68d7f31", null ],
      [ "AOM_EXT_PART_FEATURE_AFTER_RECT", "group__aom__encoder.html#gga241e62c4cf0d5f31f56e6be63df8e566a16d6ff7ef37d39ccf7840208fafa6159", null ],
      [ "AOM_EXT_PART_FEATURE_AFTER_AB", "group__aom__encoder.html#gga241e62c4cf0d5f31f56e6be63df8e566a8ad6c2101634fb6755bcf38299a3dd7a", null ]
    ] ],
    [ "aom_ext_part_status", "group__aom__encoder.html#ga4b28cbe3036a6f1c5753fa461facc192", [
      [ "AOM_EXT_PART_OK", "group__aom__encoder.html#gga4b28cbe3036a6f1c5753fa461facc192aee3c61f0f0cf4c7338084ae7b8368aa0", null ],
      [ "AOM_EXT_PART_ERROR", "group__aom__encoder.html#gga4b28cbe3036a6f1c5753fa461facc192a54c9174dd39c05769a23572ccebe8108", null ],
      [ "AOM_EXT_PART_TEST", "group__aom__encoder.html#gga4b28cbe3036a6f1c5753fa461facc192a31af37ff758f79b82a0d4a65ba7aa0cf", null ]
    ] ]
];
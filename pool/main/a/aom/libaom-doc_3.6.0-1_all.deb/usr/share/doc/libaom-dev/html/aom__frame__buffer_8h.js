var aom__frame__buffer_8h =
[
    [ "aom_codec_frame_buffer", "structaom__codec__frame__buffer.html", "structaom__codec__frame__buffer" ],
    [ "AOM_MAXIMUM_WORK_BUFFERS", "aom__frame__buffer_8h.html#a9470ef667d6ce967e93d9e528d523919", null ],
    [ "AOM_MAXIMUM_REF_BUFFERS", "aom__frame__buffer_8h.html#ae4e6b2da21b594cbea52e2927d1efbeb", null ],
    [ "aom_codec_frame_buffer_t", "aom__frame__buffer_8h.html#aa61b60e9ccca38ff4aef31d5c684c236", null ],
    [ "aom_get_frame_buffer_cb_fn_t", "aom__frame__buffer_8h.html#a01fdfbbc9be8b320437a49d3de07814d", null ],
    [ "aom_release_frame_buffer_cb_fn_t", "aom__frame__buffer_8h.html#a1803cd0766dc297d88172f174fbb6ab5", null ]
];
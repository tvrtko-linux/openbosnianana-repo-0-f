var encode__strategy_8h =
[
    [ "av1_encode_strategy", "group__high__level__algo.html#ga6b56870ab498cf798e1e16c38b4c197c", null ]
];
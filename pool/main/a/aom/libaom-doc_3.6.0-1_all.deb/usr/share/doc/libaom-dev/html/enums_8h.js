var enums_8h =
[
    [ "RestorationType", "enums_8h.html#ac8a22acdb7400608ded8cc8d83187acf", [
      [ "RESTORE_NONE", "enums_8h.html#ac8a22acdb7400608ded8cc8d83187acfa1937ae1cdacb6966fadd207ab57d61d5", null ],
      [ "RESTORE_WIENER", "enums_8h.html#ac8a22acdb7400608ded8cc8d83187acfac64b3c61c2aa8431f7d686aba5d1ee12", null ],
      [ "RESTORE_SGRPROJ", "enums_8h.html#ac8a22acdb7400608ded8cc8d83187acfac2c86f008a1cafeaeb362b8673687780", null ],
      [ "RESTORE_SWITCHABLE", "enums_8h.html#ac8a22acdb7400608ded8cc8d83187acfa8dc0118ab1758e185d3c5e8924f5e449", null ],
      [ "RESTORE_SWITCHABLE_TYPES", "enums_8h.html#ac8a22acdb7400608ded8cc8d83187acfa6ab780013b48741f824c2357aa5c9c0a", null ],
      [ "RESTORE_TYPES", "enums_8h.html#ac8a22acdb7400608ded8cc8d83187acfac01ffda44bc889f506f7b3f5f8e9ebe3", null ]
    ] ]
];
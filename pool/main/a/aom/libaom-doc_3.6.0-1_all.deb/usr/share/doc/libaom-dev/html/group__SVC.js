var group__SVC =
[
    [ "LAYER_CONTEXT", "structLAYER__CONTEXT.html", [
      [ "sb_index", "structLAYER__CONTEXT.html#a4ff0c1a06b8fd96f5ff37bf2aa98b9d3", null ],
      [ "map", "structLAYER__CONTEXT.html#af1c6b09cc85e7314d989aae83a7b28d5", null ],
      [ "actual_num_seg1_blocks", "structLAYER__CONTEXT.html#a1d897dac3039f8c548df285f6c59b9a9", null ],
      [ "actual_num_seg2_blocks", "structLAYER__CONTEXT.html#a73f7772f35adac06e7f0a0fa76e3e2e8", null ],
      [ "counter_encode_maxq_scene_change", "structLAYER__CONTEXT.html#a5aa14c130d362a8f686211b292b5bbed", null ],
      [ "speed", "structLAYER__CONTEXT.html#a69214df6581b337c578998038451c57a", null ],
      [ "group_index", "structLAYER__CONTEXT.html#ac84886e42f345445136e78d701fec643", null ],
      [ "is_key_frame", "structLAYER__CONTEXT.html#ab1a9c759d6a221c6acafcde147e08a7b", null ],
      [ "max_mv_magnitude", "structLAYER__CONTEXT.html#aa271730c1338c86af854946a694329bc", null ]
    ] ],
    [ "SVC", "structSVC.html", [
      [ "layer_context", "structSVC.html#aa3e631ea2ce977be0e961d39edcb6f38", null ],
      [ "num_allocated_layers", "structSVC.html#a2493ea615aa6f28be5155b46447c8eee", null ],
      [ "downsample_filter_type", "structSVC.html#aad10b3ea5e0a29a90c4f8c2f733ae019", null ],
      [ "downsample_filter_phase", "structSVC.html#ab4e774da4a9f8763447f5e9ea894dbdc", null ],
      [ "force_zero_mode_spatial_ref", "structSVC.html#a6575ed590fb285550e6624cf19835990", null ]
    ] ],
    [ "SVC", "group__SVC.html#gab71c263f4405fb913e3936da9bbd4f0c", null ],
    [ "av1_init_layer_context", "group__SVC.html#ga8fd7af0cfb7a8a1031a11e391ce56b7b", null ],
    [ "av1_alloc_layer_context", "group__SVC.html#ga851225444c51cbd64e23e6aac4086d46", null ],
    [ "av1_update_layer_context_change_config", "group__SVC.html#gaf68d8ebe20cd4f5d244e1cfd57517971", null ],
    [ "av1_update_temporal_layer_framerate", "group__SVC.html#ga5dd7109b02e80cc7d843c94ae7c47e58", null ],
    [ "av1_restore_layer_context", "group__SVC.html#ga653e04e3b1fe8ab04c663673e45f3a16", null ],
    [ "av1_save_layer_context", "group__SVC.html#ga814c2aa58e2ca79dedfd0d9872316586", null ],
    [ "av1_free_svc_cyclic_refresh", "group__SVC.html#gac3591bba20df432db53410504e3cbf42", null ],
    [ "av1_svc_reset_temporal_layers", "group__SVC.html#ga5f92b5ac15dcde4004d6f35586d4773b", null ],
    [ "av1_one_pass_cbr_svc_start_layer", "group__SVC.html#gaf1d134bde262a8dde127bdd6b97a9d24", null ],
    [ "av1_svc_primary_ref_frame", "group__SVC.html#ga2794fc40366548624954f66b967e8632", null ],
    [ "av1_get_layer_resolution", "group__SVC.html#gaf592ef7e4ef34c2b94806e5c9d65b19c", null ]
];
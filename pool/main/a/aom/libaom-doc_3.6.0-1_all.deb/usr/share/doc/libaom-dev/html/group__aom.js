var group__aom =
[
    [ "AOMedia AOM/AV1 Encoder", "group__aom__encoder.html", "group__aom__encoder" ],
    [ "AOMedia AOM/AV1 Decoder", "group__aom__decoder.html", "group__aom__decoder" ],
    [ "aom.h", "aom_8h.html", null ],
    [ "av1_ref_frame", "structav1__ref__frame.html", [
      [ "idx", "structav1__ref__frame.html#a7c6fcaba58f514985448cb2e2245345c", null ],
      [ "use_external_ref", "structav1__ref__frame.html#a33749c5c20033cc5f7582d0ec1c34ff0", null ],
      [ "img", "structav1__ref__frame.html#a55a09db9e1acdd73e656b01fa01283b3", null ]
    ] ],
    [ "av1_ref_frame_t", "group__aom.html#ga48948a6e11f6b314f66a3387aee9d5df", null ],
    [ "aom_com_control_id", "group__aom.html#ga9421a1fa78c0d9587ae5aa6c1cb3d659", [
      [ "AV1_GET_REFERENCE", "group__aom.html#gga9421a1fa78c0d9587ae5aa6c1cb3d659a4b8bcdaae4f4ff2e78d2e9d53090e13b", null ],
      [ "AV1_SET_REFERENCE", "group__aom.html#gga9421a1fa78c0d9587ae5aa6c1cb3d659a51ad4467b4dc318406cceb257e2daa41", null ],
      [ "AV1_COPY_REFERENCE", "group__aom.html#gga9421a1fa78c0d9587ae5aa6c1cb3d659af5c56c3dbccf31fca7621e8327ba7354", null ],
      [ "AV1_GET_NEW_FRAME_IMAGE", "group__aom.html#gga9421a1fa78c0d9587ae5aa6c1cb3d659a410c706a34f5295996658cc5044a700f", null ],
      [ "AV1_COPY_NEW_FRAME_IMAGE", "group__aom.html#gga9421a1fa78c0d9587ae5aa6c1cb3d659ae41763622ee33cd99e23ca8f78a3f8fa", null ],
      [ "AOM_DECODER_CTRL_ID_START", "group__aom.html#gga9421a1fa78c0d9587ae5aa6c1cb3d659a155fc3906e61acda15149129136ab8cd", null ]
    ] ]
];
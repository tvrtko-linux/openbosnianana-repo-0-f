var group__aom__decoder =
[
    [ "aomdx.h", "aomdx_8h.html", null ],
    [ "aom_inspect_init", "structaom__inspect__init.html", [
      [ "inspect_cb", "structaom__inspect__init.html#a3a51c5f8c524cec7564fae85e047750b", null ],
      [ "inspect_ctx", "structaom__inspect__init.html#a26c618c754d4b278fb636353e6b9d96d", null ]
    ] ],
    [ "Av1DecodeReturn", "structAv1DecodeReturn.html", [
      [ "buf", "structAv1DecodeReturn.html#aab2b7d54d778b8d5ef5b475b4460ee9f", null ],
      [ "idx", "structAv1DecodeReturn.html#aeefcb8b1f412902428fa86ea066e4414", null ],
      [ "show_existing", "structAv1DecodeReturn.html#ac95f1cc492f7bb172dc1d9132674c3ec", null ]
    ] ],
    [ "aom_tile_data", "structaom__tile__data.html", [
      [ "coded_tile_data_size", "structaom__tile__data.html#a4451b0bcd81b4959484745df35a9fbba", null ],
      [ "coded_tile_data", "structaom__tile__data.html#a05898249ddaf5ba799dd471113b0e51e", null ],
      [ "extra_size", "structaom__tile__data.html#a936851e515bcea0af38d2d091f5adf65", null ]
    ] ],
    [ "aom_tile_info", "structaom__tile__info.html", [
      [ "tile_columns", "structaom__tile__info.html#ac716eef568917a4b6a732770ded5cf05", null ],
      [ "tile_rows", "structaom__tile__info.html#aa96ac10b2d2f66802ad0ee6f4162ae00", null ],
      [ "tile_widths", "structaom__tile__info.html#ae5e232f0c7eefd35667df50564aac4ad", null ],
      [ "tile_heights", "structaom__tile__info.html#aa7a5b13049292fc4bb89a3377785f42b", null ],
      [ "num_tile_groups", "structaom__tile__info.html#ac9bc925f5f021f34b6fa200aba99a9f0", null ]
    ] ],
    [ "aom_still_picture_info", "structaom__still__picture__info.html", [
      [ "is_still_picture", "structaom__still__picture__info.html#aee2d5137261eae631a9c9061293ec74a", null ],
      [ "is_reduced_still_picture_hdr", "structaom__still__picture__info.html#a36ca334c167a149174a7323eaa67e61e", null ]
    ] ],
    [ "aom_s_frame_info", "structaom__s__frame__info.html", [
      [ "is_s_frame", "structaom__s__frame__info.html#a6c6bc6fdd7ba0da4dae5142a5f5288eb", null ],
      [ "is_s_frame_at_altref", "structaom__s__frame__info.html#a589b2fa70e546023fea1510c2973116a", null ]
    ] ],
    [ "aom_screen_content_tools_info", "structaom__screen__content__tools__info.html", [
      [ "allow_screen_content_tools", "structaom__screen__content__tools__info.html#a9a824f254e939a2f51d8a027861daa2a", null ],
      [ "allow_intrabc", "structaom__screen__content__tools__info.html#a98ae54aebdde33bb37680ef25ae21b6e", null ],
      [ "force_integer_mv", "structaom__screen__content__tools__info.html#a7bee79b0440c1ba3f67202f237182e4e", null ]
    ] ],
    [ "av1_ext_ref_frame", "structav1__ext__ref__frame.html", [
      [ "img", "structav1__ext__ref__frame.html#af511f04e9cb8a571b3516eee61414f85", null ],
      [ "num", "structav1__ext__ref__frame.html#a2d249bb9aee60c4b6c67e64b1694bc2f", null ]
    ] ],
    [ "AOM_MAX_TILE_COLS", "group__aom__decoder.html#gaa7df1f59e745188fcd02dbdd8018893b", null ],
    [ "AOM_MAX_TILE_ROWS", "group__aom__decoder.html#ga8b5b92c20edb29173182b5e30edd55d2", null ],
    [ "Accounting", "group__aom__decoder.html#ga4e755ba2db79154311994183ad9e4b28", null ],
    [ "aom_inspect_cb", "group__aom__decoder.html#ga1b37b4b76004e5a2776c2e2f16b052cd", null ],
    [ "aom_inspect_init", "group__aom__decoder.html#gace99b38e5d18359cfba3e0d769511ea9", null ],
    [ "aom_tile_data", "group__aom__decoder.html#gafaa2418e0318a2490ed892695b41e374", null ],
    [ "aom_tile_info", "group__aom__decoder.html#gac65dc901d702e0094dc72f04e7448913", null ],
    [ "aom_still_picture_info", "group__aom__decoder.html#ga6c42dc93877dd6ffbf24e7a3560de6cc", null ],
    [ "aom_s_frame_info", "group__aom__decoder.html#gab05eb9e558015080eb8ec694c984fff6", null ],
    [ "aom_screen_content_tools_info", "group__aom__decoder.html#ga108f7f2ff3f450ad1fb574cecd15fd72", null ],
    [ "av1_ext_ref_frame_t", "group__aom__decoder.html#gaf33ade89af86db481078ef1c405bbee8", null ],
    [ "aom_dec_control_id", "group__aom__decoder.html#ga3865fd4b3192489baa9a5c3632ebe97b", [
      [ "AOMD_GET_LAST_REF_UPDATES", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97babab96509cdce01ed1cf027185da4d874", null ],
      [ "AOMD_GET_FRAME_CORRUPTED", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba159ddb748cb69956226b7c13e3890ff6", null ],
      [ "AOMD_GET_LAST_REF_USED", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba03f15fd9a3044ca1a1707e12b6a4588b", null ],
      [ "AV1D_GET_FRAME_SIZE", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba175c454a7adf2d3927a0e979b4a2b07b", null ],
      [ "AV1D_GET_DISPLAY_SIZE", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba592a5d1390204d743ddfe7bfe8ef177c", null ],
      [ "AV1D_GET_BIT_DEPTH", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97bace55b4f6d152f2f0d29f70ab918cba4f", null ],
      [ "AV1D_GET_IMG_FORMAT", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97bacd7229e5fb766670fe995739931c2ee3", null ],
      [ "AV1D_GET_TILE_SIZE", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba4d9799d9e520785870b8d1f73a19c3c4", null ],
      [ "AV1D_GET_TILE_COUNT", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba242d7dba47ef646f51f9795e2fa92f91", null ],
      [ "AV1_SET_BYTE_ALIGNMENT", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97babb0f1c97c6092ebed96ca9800e05157e", null ],
      [ "AV1_INVERT_TILE_DECODE_ORDER", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97bac19ffcb187b1e1b5eee18499a97f69d2", null ],
      [ "AV1_SET_SKIP_LOOP_FILTER", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba45b658bd6518cfd30c56b13e98ab168a", null ],
      [ "AV1_GET_ACCOUNTING", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97bab7332818193596356a580c83ecb12a66", null ],
      [ "AOMD_GET_LAST_QUANTIZER", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97baa984acc8b42df9c7d18fc3556a14fd29", null ],
      [ "AV1_SET_DECODE_TILE_ROW", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97bac056b4cf80427fd05e3c4c9fc46edb78", null ],
      [ "AV1_SET_TILE_MODE", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba0795d8084ae8c78528c01587198df9e2", null ],
      [ "AV1D_GET_FRAME_HEADER_INFO", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97baed16ed4514ea1bd2847e607ca880b246", null ],
      [ "AV1D_GET_TILE_DATA", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97badf1e96275f692bc97ddb4ce2fbdb456e", null ],
      [ "AV1D_SET_EXT_REF_PTR", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97badfbe6c1ebe4039bfef4d2cfd98755add", null ],
      [ "AV1D_EXT_TILE_DEBUG", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97baffdaca91296725bd16142a33f3cc6522", null ],
      [ "AV1D_SET_ROW_MT", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba4784af3a10d73a36f739cb1c99caf876", null ],
      [ "AV1D_SET_IS_ANNEXB", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba1fb269c5c5913d9995b6c35d28e2a788", null ],
      [ "AV1D_SET_OPERATING_POINT", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97baa8b955fc5a2f6e33c6dad858d7c15f67", null ],
      [ "AV1D_SET_OUTPUT_ALL_LAYERS", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba8d51f96b8877b665225f5cfaa73ded8e", null ],
      [ "AV1_SET_INSPECTION_CALLBACK", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97bae02fd57774db8c30e49b083fa51b6236", null ],
      [ "AV1D_SET_SKIP_FILM_GRAIN", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba17fa09c9ce1ae4a68eae21efd219418b", null ],
      [ "AOMD_GET_FWD_KF_PRESENT", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97bad1036f9d92ad1f0afa51e33150354585", null ],
      [ "AOMD_GET_FRAME_FLAGS", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97bab41a1ef60d33d804b8aabbce0b5f706f", null ],
      [ "AOMD_GET_ALTREF_PRESENT", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba41756871003a7d391f00a11673c38769", null ],
      [ "AOMD_GET_TILE_INFO", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba1c3836ef68ecfb7f92b198b454fec4d7", null ],
      [ "AOMD_GET_SCREEN_CONTENT_TOOLS_INFO", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba9bc290107ed0adac808a674b09741ba7", null ],
      [ "AOMD_GET_STILL_PICTURE", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97bac4e9db108f3257dece09f167ec6aac5f", null ],
      [ "AOMD_GET_SB_SIZE", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba294a62ae333661906ff55b04086675c7", null ],
      [ "AOMD_GET_SHOW_EXISTING_FRAME_FLAG", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba306a4eb7c886f509a94ea3054794c288", null ],
      [ "AOMD_GET_S_FRAME_INFO", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97bad35d0b5df17dc5465d62b602d62458d1", null ],
      [ "AOMD_GET_SHOW_FRAME_FLAG", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba441d4d82094aced6570face51368ca23", null ],
      [ "AOMD_GET_BASE_Q_IDX", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba27d139da59a2c76783d7ea0918c95a9a", null ],
      [ "AOMD_GET_ORDER_HINT", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97ba3fae4dd7641d3f53723d9a6672758e0c", null ],
      [ "AV1D_GET_MI_INFO", "group__aom__decoder.html#gga3865fd4b3192489baa9a5c3632ebe97baad96ac15f7a0999d74e9a6b281563104", null ]
    ] ],
    [ "aom_codec_av1_dx", "group__aom__decoder.html#ga535cbd802e32dbe437bda8e8c30614c9", null ],
    [ "aom_codec_av1_dx_algo", "group__aom__decoder.html#ga3747f3c9af0ff0dfc68196b00efd7771", null ]
];
var group__cap__external__frame__buffer =
[
    [ "aom_codec_set_frame_buffer_functions", "group__cap__external__frame__buffer.html#ga1818a812e4d1e70eeafbe5b0ee538d6e", null ]
];
var group__coefficient__coding =
[
    [ "av1_alloc_txb_buf", "group__coefficient__coding.html#ga1f9147fbeb6681f1f2ffd99806c93526", null ],
    [ "av1_free_txb_buf", "group__coefficient__coding.html#gabb195b5ee31923fbd15fe4caaf466278", null ],
    [ "av1_write_coeffs_txb", "group__coefficient__coding.html#ga2afb7e8b3781bec12c44908fc5eaff51", null ],
    [ "av1_write_intra_coeffs_mb", "group__coefficient__coding.html#ga24b28c5ec4bc705cc58a7655c8218e4d", null ],
    [ "av1_get_txb_entropy_context", "group__coefficient__coding.html#ga0076c2c06ae74fd7b00193d4aa2f1d46", null ],
    [ "av1_update_intra_mb_txb_context", "group__coefficient__coding.html#ga50e1752ad80721912848f6087b7b1025", null ],
    [ "av1_update_and_record_txb_context", "group__coefficient__coding.html#gad0c28d34dad6636237409bf2e1ee2014", null ],
    [ "av1_record_txb_context", "group__coefficient__coding.html#ga4bd51731afdd25275377807e067c9d12", null ],
    [ "av1_get_cb_coeff_buffer", "group__coefficient__coding.html#gae0b8d3b37b0b43f1cfbd0f91cc4cc991", null ],
    [ "av1_cost_skip_txb", "group__coefficient__coding.html#gab27521d24faa93e58a1ce487b1e8f626", null ],
    [ "av1_optimize_txb", "group__coefficient__coding.html#ga8bc502fea9846765fba7de6a8fd90279", null ],
    [ "av1_cost_coeffs_txb", "group__coefficient__coding.html#ga99f06925f4adb19ffb5fcbc12745ab94", null ],
    [ "av1_cost_coeffs_txb_laplacian", "group__coefficient__coding.html#ga225614c4ff1863904ee8a80e0d971cc4", null ],
    [ "av1_cost_coeffs_txb_estimate", "group__coefficient__coding.html#ga1618c5468421234169f9b285bc70a59c", null ]
];
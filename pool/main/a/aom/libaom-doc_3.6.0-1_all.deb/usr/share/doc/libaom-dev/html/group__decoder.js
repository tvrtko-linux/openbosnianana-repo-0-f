var group__decoder =
[
    [ "External Frame Buffer Functions", "group__cap__external__frame__buffer.html", "group__cap__external__frame__buffer" ],
    [ "aom_decoder.h", "aom__decoder_8h.html", null ],
    [ "aom_codec_stream_info", "structaom__codec__stream__info.html", [
      [ "w", "structaom__codec__stream__info.html#add84a2752fefd706f893fbc41ba6b9f2", null ],
      [ "h", "structaom__codec__stream__info.html#a2f1c33e3b980b274176545340b474e34", null ],
      [ "is_kf", "structaom__codec__stream__info.html#a0264e63c333ff05b2afd6df478ed807c", null ],
      [ "number_spatial_layers", "structaom__codec__stream__info.html#af7487a0e56b6919f94a7e426abd44eac", null ],
      [ "number_temporal_layers", "structaom__codec__stream__info.html#a8845a384d9d0b3d8670b8ad98b720c0e", null ],
      [ "is_annexb", "structaom__codec__stream__info.html#a1572ce7a1105c1db0a9dd43acb77b6c4", null ]
    ] ],
    [ "aom_codec_dec_cfg", "structaom__codec__dec__cfg.html", [
      [ "threads", "structaom__codec__dec__cfg.html#a48c68337e1071e2aee36c649e579f189", null ],
      [ "w", "structaom__codec__dec__cfg.html#a107d66882f85eaaee59e59ea23d974d6", null ],
      [ "h", "structaom__codec__dec__cfg.html#a441611a22188289243eafa7df433e85f", null ],
      [ "allow_lowbitdepth", "structaom__codec__dec__cfg.html#afe4d704d679b943d566dcd4fd2276851", null ]
    ] ],
    [ "AOM_DECODER_ABI_VERSION", "group__decoder.html#ga23378c7ca8c361c097181aaaa2a5a734", null ],
    [ "AOM_CODEC_CAP_EXTERNAL_FRAME_BUFFER", "group__decoder.html#gabd11df9f35d52ea76de2c8d32aa36963", null ],
    [ "aom_codec_dec_init", "group__decoder.html#gafdbfca65b19ab1f6d72b32cd01753b9b", null ],
    [ "aom_codec_stream_info_t", "group__decoder.html#ga67b2d2d0bfa394bbbd1c5ce4876ed48c", null ],
    [ "aom_codec_dec_cfg_t", "group__decoder.html#gab456f6df8429a23dce32438f0a570ef6", null ],
    [ "aom_codec_dec_init_ver", "group__decoder.html#gab2bfd2f5517b9452d2c71b7c2b2e8e8d", null ],
    [ "aom_codec_peek_stream_info", "group__decoder.html#ga2544bac9fdc439f0effd6b1b14df54be", null ],
    [ "aom_codec_get_stream_info", "group__decoder.html#ga2b456cf67b1b64dabed370c5d7514b29", null ],
    [ "aom_codec_decode", "group__decoder.html#gab03fdb999d1f83a5896869a3ba5f68f7", null ],
    [ "aom_codec_get_frame", "group__decoder.html#ga9ee6dac1fc46ab5c254395eea5469d5d", null ]
];
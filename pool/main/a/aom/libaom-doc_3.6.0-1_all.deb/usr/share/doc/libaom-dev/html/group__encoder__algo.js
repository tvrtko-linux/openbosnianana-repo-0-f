var group__encoder__algo =
[
    [ "High-level Algorithm", "group__high__level__algo.html", "group__high__level__algo" ],
    [ "Partition Search", "group__partition__search.html", "group__partition__search" ],
    [ "Intra Mode Search", "group__intra__mode__search.html", "group__intra__mode__search" ],
    [ "Inter Mode Search", "group__inter__mode__search.html", "group__inter__mode__search" ],
    [ "Transform Search", "group__transform__search.html", "group__transform__search" ],
    [ "Transform Coefficient Coding and Optimization", "group__coefficient__coding.html", "group__coefficient__coding" ],
    [ "In-loop Filter", "group__in__loop__filter.html", "group__in__loop__filter" ],
    [ "CDEF", "group__in__loop__cdef.html", "group__in__loop__cdef" ],
    [ "Loop Restoration", "group__in__loop__restoration.html", "group__in__loop__restoration" ],
    [ "Cyclic Refresh", "group__cyclic__refresh.html", "group__cyclic__refresh" ],
    [ "Scalable Video Coding", "group__SVC.html", "group__SVC" ],
    [ "Variance Partition", "group__variance__partition.html", "group__variance__partition" ],
    [ "NonRD Optimized Mode Search", "group__nonrd__mode__search.html", "group__nonrd__mode__search" ]
];
var group__gf__group__algo =
[
    [ "calculate_gf_length", "group__gf__group__algo.html#ga294931863e7bb9104cdab552e06dbbd9", null ],
    [ "define_gf_group_pass0", "group__gf__group__algo.html#ga89a0a5ad12dd9a8d35030ab51d5c4fe5", null ],
    [ "define_gf_group", "group__gf__group__algo.html#ga9b50f914d4997b65c3945a185393fe82", null ],
    [ "define_gf_group_pass3", "group__gf__group__algo.html#ga4cb741db8437bc066db6bf8eeb8f7128", null ],
    [ "define_kf_interval", "group__gf__group__algo.html#ga67628538a2f36718ec7c924ce5328de2", null ],
    [ "find_next_key_frame", "group__gf__group__algo.html#ga9aa97f1bc97fd44160e858d375c0c20f", null ]
];
var group__high__level__algo =
[
    [ "Speed vs Quality Trade Off", "group__speed__features.html", "group__speed__features" ],
    [ "Source Frame Processing", "group__src__frame__proc.html", "group__src__frame__proc" ],
    [ "Rate Control", "group__rate__control.html", "group__rate__control" ],
    [ "Temporal Dependency Modelling", "group__tpl__modelling.html", "group__tpl__modelling" ],
    [ "Two Pass Mode", "group__two__pass__algo.html", "group__two__pass__algo" ],
    [ "The Look-Ahead Buffer", "group__look__ahead__buffer.html", null ],
    [ "Golden Frame Group", "group__gf__group__algo.html", "group__gf__group__algo" ],
    [ "av1_pack_bitstream", "group__high__level__algo.html#ga29eed659e71f7b8e1aef31d8cb4bb9ea", null ],
    [ "av1_encode_strategy", "group__high__level__algo.html#ga6b56870ab498cf798e1e16c38b4c197c", null ],
    [ "encode_frame_internal", "group__high__level__algo.html#ga7c707e2dc0a45e03ee9cd81f97552a0b", null ],
    [ "av1_encode_frame", "group__high__level__algo.html#ga9f2d93e66cde2eccb5f4dcd5d08c6d6a", null ],
    [ "cdef_restoration_frame", "group__high__level__algo.html#gafca3ffd2882283c32dbb6f958a7c6e04", null ],
    [ "loopfilter_frame", "group__high__level__algo.html#ga0f59145ac0765033ee267ba203baed23", null ],
    [ "encode_without_recode", "group__high__level__algo.html#ga87fccf520455ff9a41aa381b40b8862c", null ],
    [ "encode_with_recode_loop", "group__high__level__algo.html#gac237dcb6e36d4dbff616e618ab4985a6", null ],
    [ "encode_with_recode_loop_and_filter", "group__high__level__algo.html#gaec07a41d07f7cd08a258531cd8935c68", null ],
    [ "encode_frame_to_data_rate", "group__high__level__algo.html#ga0d530935e53f27ab76f0dada5a8b94b6", null ],
    [ "av1_receive_raw_frame", "group__high__level__algo.html#ga681c10fbb05a4c91b4536107f3342c37", null ],
    [ "av1_get_compressed_data", "group__high__level__algo.html#ga4017ec9e9cfd7bd461775266c80ff46d", null ],
    [ "av1_encode", "group__high__level__algo.html#gad4f93a0174051f16f9010f332f6c9bc7", null ]
];
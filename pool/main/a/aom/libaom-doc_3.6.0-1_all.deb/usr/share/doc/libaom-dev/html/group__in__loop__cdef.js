var group__in__loop__cdef =
[
    [ "av1_cdef_frame", "group__in__loop__cdef.html#ga954983bebf726d3c6a4977410dfc607f", null ],
    [ "av1_cdef_search", "group__in__loop__cdef.html#ga930c781dbd8d604fe8b4a3e76b075b8e", null ]
];
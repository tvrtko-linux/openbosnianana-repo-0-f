var group__in__loop__restoration =
[
    [ "av1_loop_restoration_filter_unit", "group__in__loop__restoration.html#gab2102fa7b1b4fff4ba450c9713858cef", null ],
    [ "av1_loop_restoration_filter_frame", "group__in__loop__restoration.html#ga65482f59379cfb1236341521d4c99391", null ],
    [ "av1_pick_filter_restoration", "group__in__loop__restoration.html#ga476124fb6e4f853a2705bb32a56432b2", null ]
];
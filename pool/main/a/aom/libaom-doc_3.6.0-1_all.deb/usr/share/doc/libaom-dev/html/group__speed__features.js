var group__speed__features =
[
    [ "av1_set_speed_features_framesize_independent", "group__speed__features.html#ga375df45f353341a53823feb529182b2a", null ],
    [ "av1_set_speed_features_framesize_dependent", "group__speed__features.html#ga95ee4b0969a41da950b5c23909d142c4", null ],
    [ "av1_set_speed_features_qindex_dependent", "group__speed__features.html#ga643ab0df2f1abcad7bcd6a612fdbc8a2", null ]
];
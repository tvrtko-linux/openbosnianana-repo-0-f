var group__tpl__modelling =
[
    [ "setup_delta_q", "group__tpl__modelling.html#ga3d123b0f3781dcb06c5f4d053ac3655b", null ],
    [ "av1_tpl_setup_stats", "group__tpl__modelling.html#gacb25270842c5ab92d1d90a211df955e5", null ]
];
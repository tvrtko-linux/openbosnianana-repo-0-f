var group__transform__search =
[
    [ "av1_uniform_txfm_yrd", "group__transform__search.html#gae30648a789cd8ef5cb98e0210db2371f", null ],
    [ "av1_pick_recursive_tx_size_type_yrd", "group__transform__search.html#ga4bdb6bc7b2510fc58a4e63212e811412", null ],
    [ "av1_pick_uniform_tx_size_type_yrd", "group__transform__search.html#ga96f1b74712969cad39e8759642341ea3", null ],
    [ "av1_txfm_uvrd", "group__transform__search.html#ga6de2388a03e84841b43096d324e3ac26", null ],
    [ "av1_txfm_rd_in_plane", "group__transform__search.html#gaaad15ac6f5882d95c5daded8b167841c", null ],
    [ "av1_txfm_search", "group__transform__search.html#gab98eb8666e56c4f697af7e04e9ed8759", null ]
];
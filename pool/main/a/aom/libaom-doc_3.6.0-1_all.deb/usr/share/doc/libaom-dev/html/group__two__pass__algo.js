var group__two__pass__algo =
[
    [ "has_no_stats_stage", "group__two__pass__algo.html#ga737bbff8d05e931b73b4321a0fa35d0e", null ]
];
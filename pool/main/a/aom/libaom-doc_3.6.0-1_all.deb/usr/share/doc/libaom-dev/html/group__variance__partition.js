var group__variance__partition =
[
    [ "av1_set_variance_partition_thresholds", "group__variance__partition.html#ga2a5965e60efd6f575542f55a48feb022", null ],
    [ "av1_choose_var_based_partitioning", "group__variance__partition.html#gae61ad7df0f818c5d89adfc8e139359df", null ]
];
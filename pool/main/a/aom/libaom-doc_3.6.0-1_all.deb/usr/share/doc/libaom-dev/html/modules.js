var modules =
[
    [ "Common Algorithm Interface", "group__codec.html", "group__codec" ],
    [ "Supported Codecs", "group__codecs.html", "group__codecs" ],
    [ "Encoder Algorithm", "group__encoder__algo.html", "group__encoder__algo" ]
];
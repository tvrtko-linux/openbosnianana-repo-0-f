/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "AOMedia AV1 Codec", "index.html", [
    [ "AOMedia Codec SDK", "index.html#aom_sdk", [
      [ "Introduction", "index.html#main_intro", null ],
      [ "Starting Points", "index.html#main_startpoints", null ]
    ] ],
    [ "AV1 Developer's Guide", "index.html#av1_guide", null ],
    [ "Support Options & FAQ", "index.html#main_support", null ],
    [ "RFC2119 Keywords", "rfc2119.html", [
      [ "MUST", "rfc2119.html#MUST", null ],
      [ "MUST NOT", "rfc2119.html#MUSTNOT", null ],
      [ "SHOULD", "rfc2119.html#SHOULD", null ],
      [ "SHOULD NOT", "rfc2119.html#SHOULDNOT", null ],
      [ "MAY", "rfc2119.html#MAY", null ]
    ] ],
    [ "CHANGELOG", "changelog.html", null ],
    [ "README.md", "readme.html", null ],
    [ "Usage", "usage.html", "usage" ],
    [ "AV1 DECODER GUIDE", "decoder_guide.html", null ],
    [ "AV1 ENCODER GUIDE", "encoder_guide.html", [
      [ "Introduction", "encoder_guide.html#architecture_introduction", [
        [ "Generic Block Transform Based Codecs", "encoder_guide.html#architecture_gencodecs", null ],
        [ "AV1 Structure and Complexity", "encoder_guide.html#architecture_av1_structure", null ]
      ] ],
      [ "The Libaom Command Line Interface", "encoder_guide.html#architecture_command_line", null ],
      [ "Main Encoder Data Structures", "encoder_guide.html#architecture_enc_data_structures", null ],
      [ "Encoder Use Cases", "encoder_guide.html#architecture_enc_use_cases", null ],
      [ "Speed vs Quality Trade Off", "encoder_guide.html#architecture_enc_speed_quality", null ],
      [ "Source Frame Processing", "encoder_guide.html#architecture_enc_src_proc", [
        [ "Main Data Structures", "encoder_guide.html#architecture_enc_frame_proc_data", null ],
        [ "Frame Ingest / Coding Pipeline", "encoder_guide.html#architecture_enc_frame_proc_ingest", null ],
        [ "Temporal Filtering", "encoder_guide.html#architecture_enc_frame_proc_tf", [
          [ "Overview", "encoder_guide.html#architecture_enc_frame_proc_tf_overview", null ],
          [ "Temporal Filtering Algorithm", "encoder_guide.html#architecture_enc_frame_proc_tf_algo", null ],
          [ "Temporal Filter Functions", "encoder_guide.html#architecture_enc_frame_proc_tf_funcs", null ]
        ] ],
        [ "Film Grain Modelling", "encoder_guide.html#architecture_enc_frame_proc_film", null ]
      ] ],
      [ "Rate Control", "encoder_guide.html#architecture_enc_rate_ctrl", [
        [ "Main Data Structures", "encoder_guide.html#architecture_enc_rate_ctrl_data", null ],
        [ "Supported Rate Control Options", "encoder_guide.html#architecture_enc_rate_ctrl_options", null ],
        [ "Variable Bitrate (VBR) Encoding", "encoder_guide.html#architecture_enc_vbr", [
          [ "1 Pass VBR Encoding", "encoder_guide.html#architecture_enc_1pass_vbr", null ],
          [ "2 Pass VBR Encoding", "encoder_guide.html#architecture_enc_2pass_vbr", null ],
          [ "1 Pass Lagged VBR Encoding", "encoder_guide.html#architecture_enc_1pass_lagged", null ]
        ] ],
        [ "The Main Rate Control Loop", "encoder_guide.html#architecture_enc_rc_loop", null ],
        [ "Fixed Q Mode", "encoder_guide.html#architecture_enc_fixed_q", null ]
      ] ],
      [ "GF/ ARF Frame Groups & Hierarchical Coding", "encoder_guide.html#architecture_enc_frame_groups", [
        [ "Main Data Structures", "encoder_guide.html#architecture_enc_frame_groups_data", null ],
        [ "Frame Groups", "encoder_guide.html#architecture_enc_frame_groups_groups", null ],
        [ "GF / ARF Group Length Determination", "encoder_guide.html#architecture_enc_gf_length", null ],
        [ "Defining a GF Group's Structure", "encoder_guide.html#architecture_enc_gf_structure", null ],
        [ "Key Frame Groups", "encoder_guide.html#architecture_enc_kf_groups", null ]
      ] ],
      [ "Temporal Dependency Modelling", "encoder_guide.html#architecture_enc_tpl", [
        [ "Configurations", "encoder_guide.html#architecture_enc_tpl_config", null ],
        [ "Algorithms", "encoder_guide.html#architecture_enc_tpl_algoritms", null ],
        [ "Key Functions and data structures", "encoder_guide.html#architecture_enc_tpl_keyfun", null ]
      ] ],
      [ "Block Partition Search", "encoder_guide.html#architecture_enc_partitions", null ],
      [ "Intra Mode Search", "encoder_guide.html#architecture_enc_intra_modes", null ],
      [ "Inter Prediction Mode Search", "encoder_guide.html#architecture_enc_inter_modes", null ],
      [ "Transform Search", "encoder_guide.html#architecture_enc_tx_search", null ],
      [ "Post Encode Loop Filtering", "encoder_guide.html#architecture_post_enc_filt", null ],
      [ "Entropy Coding", "encoder_guide.html#architecture_entropy", [
        [ "Arithmetic Coder", "encoder_guide.html#architecture_entropy_aritmetic", null ],
        [ "Transform Coefficient Coding and Optimization", "encoder_guide.html#architecture_entropy_coef", [
          [ "Transform coefficient coding", "encoder_guide.html#architecture_entropy_coef_what", [
            [ "Preparation - transform and quantize", "encoder_guide.html#architecture_entropy_coef_prepare", null ],
            [ "The coding process", "encoder_guide.html#architecture_entropy_coef_coding", null ],
            [ "Context information", "encoder_guide.html#architecture_entropy_coef_context", null ]
          ] ],
          [ "RD optimization", "encoder_guide.html#architecture_entropy_coef_rd", [
            [ "Entropy cost", "encoder_guide.html#architecture_entropy_coef_cost", null ],
            [ "Quantized level optimization", "encoder_guide.html#architecture_entropy_coef_opt", null ]
          ] ]
        ] ]
      ] ]
    ] ],
    [ "Sample Code", "samples.html", "samples" ],
    [ "README.md", "LREADME.html", [
      [ "AV1 Codec Library", "LREADME.html#autotoc_md0", [
        [ "Contents", "LREADME.html#autotoc_md1", null ],
        [ "Building the library and applications", "LREADME.html#building-the-library-and-applications", [
          [ "Prerequisites", "LREADME.html#prerequisites", null ],
          [ "Get the code", "LREADME.html#get-the-code", null ],
          [ "Basic build", "LREADME.html#basic-build", null ],
          [ "Configuration options", "LREADME.html#configuration-options", null ],
          [ "Dylib builds", "LREADME.html#dylib-builds", null ],
          [ "Debugging", "LREADME.html#debugging", null ],
          [ "Cross compiling", "LREADME.html#cross-compiling", null ],
          [ "Sanitizers", "LREADME.html#sanitizers", null ],
          [ "Microsoft Visual Studio builds", "LREADME.html#microsoft-visual-studio-builds", null ],
          [ "Xcode builds", "LREADME.html#xcode-builds", null ],
          [ "Emscripten builds", "LREADME.html#emscripten-builds", null ],
          [ "Extra build flags", "LREADME.html#extra-build-flags", null ],
          [ "Build with VMAF support", "LREADME.html#build-with-vmaf", null ]
        ] ],
        [ "Testing the AV1 codec", "LREADME.html#testing-the-av1-codec", [
          [ "Testing basics", "LREADME.html#testing-basics", [
            [ "1. Unit tests:", "LREADME.html#unit-tests", null ],
            [ "2. Example tests:", "LREADME.html#example-tests", null ],
            [ "3. Encoder tests:", "LREADME.html#encoder-tests", null ]
          ] ],
          [ "IDE hosted tests", "LREADME.html#ide-hosted-tests", null ],
          [ "Downloading the test data", "LREADME.html#downloading-the-test-data", null ],
          [ "Adding a new test data file", "LREADME.html#adding-a-new-test-data-file", null ],
          [ "Additional test data", "LREADME.html#additional-test-data", null ],
          [ "Sharded testing", "LREADME.html#sharded-testing", [
            [ "1. Running test_libaom directly:", "LREADME.html#running-test_libaom-directly", null ],
            [ "2. Running the tests via the CMake build:", "LREADME.html#running-the-tests-via-the-cmake-build", null ]
          ] ]
        ] ],
        [ "Coding style", "LREADME.html#coding-style", null ],
        [ "Submitting patches", "LREADME.html#submitting-patches", [
          [ "Login cookie", "LREADME.html#login-cookie", null ],
          [ "Contributor agreement", "LREADME.html#contributor-agreement", null ],
          [ "Testing your code", "LREADME.html#testing-your-code", null ],
          [ "Commit message hook", "LREADME.html#commit-message-hook", null ],
          [ "Upload your change", "LREADME.html#upload-your-change", null ],
          [ "Incorporating reviewer comments", "LREADME.html#incorporating-reviewer-comments", null ],
          [ "Submitting your change", "LREADME.html#submitting-your-change", null ],
          [ "Viewing the status of uploaded changes", "LREADME.html#viewing-the-status-of-uploaded-changes", null ]
        ] ],
        [ "Support", "LREADME.html#support", null ],
        [ "Bug reports", "LREADME.html#bug-reports", null ]
      ] ]
    ] ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"LREADME.html",
"encoder_guide.html#architecture_enc_intra_modes",
"group__aom__encoder.html#ga790f05ad7832f2614a13fd60bd3430fe",
"group__codec.html#ggac34a24f7c6c0fef7518aed0da4425f61a5abd24080a18d4f7e33217d93a73e968",
"group__transform__search.html#ga96f1b74712969cad39e8759642341ea3",
"structAV1__COMP.html#aa3403fc90f89d25b1b18ed11e14384c1",
"structCompoundTypeCfg.html#a6f8296d512aa11644fd517139f16819a",
"structMB__MODE__INFO__EXT__FRAME.html#a430fd9e49f38ceae3aec0ec8f80bd700",
"structSuperBlockEnc.html#a11ec5173d2e6f78607276a6770fe180f",
"structaom__image.html#ab986419a1f0fff93a2dc505f47194988",
"structmacroblock.html#a764c3f23fd2e1d581a1265bad933c196"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';
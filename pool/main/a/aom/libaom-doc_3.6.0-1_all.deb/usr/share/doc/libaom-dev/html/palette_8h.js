var palette_8h =
[
    [ "av1_calc_indices", "group__palette__mode__search.html#gab8813de381028651eb53216b019430b9", null ],
    [ "av1_k_means", "group__palette__mode__search.html#gab303c97534cd091ada24b034289a21a4", null ],
    [ "av1_remove_duplicates", "group__palette__mode__search.html#gaf6eaf3e49c594d167c458e7cced8bd50", null ],
    [ "av1_index_color_cache", "group__palette__mode__search.html#ga3ef821348e6d88fc171a8af5d070a5ca", null ],
    [ "av1_get_palette_delta_bits_v", "group__palette__mode__search.html#gaa6a39d9de82e0e5cd963473067334e17", null ],
    [ "av1_palette_color_cost_y", "group__palette__mode__search.html#ga2cb9b1049cdc0060881083633ccee68f", null ],
    [ "av1_palette_color_cost_uv", "group__palette__mode__search.html#gab9bf846634be27493a882c390fd7bc55", null ],
    [ "av1_rd_pick_palette_intra_sby", "group__palette__mode__search.html#gafab99f1ec2dfb2267b7396f474ecfaf0", null ],
    [ "av1_rd_pick_palette_intra_sbuv", "group__palette__mode__search.html#ga80f626349d4e58b164c7a57fefbcd83a", null ],
    [ "av1_restore_uv_color_map", "palette_8h.html#a4a74357844cac7dba9020e29c704da37", null ]
];
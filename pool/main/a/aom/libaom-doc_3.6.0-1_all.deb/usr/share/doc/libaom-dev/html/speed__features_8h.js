var speed__features_8h =
[
    [ "HIGH_LEVEL_SPEED_FEATURES", "structHIGH__LEVEL__SPEED__FEATURES.html", "structHIGH__LEVEL__SPEED__FEATURES" ],
    [ "FIRST_PASS_SPEED_FEATURES", "structFIRST__PASS__SPEED__FEATURES.html", "structFIRST__PASS__SPEED__FEATURES" ],
    [ "SPEED_FEATURES", "structSPEED__FEATURES.html", "structSPEED__FEATURES" ],
    [ "HIGH_LEVEL_SPEED_FEATURES", "speed__features_8h.html#a803e1c508d00021beeeb1663d68d00b3", null ],
    [ "FIRST_PASS_SPEED_FEATURES", "speed__features_8h.html#a99e299de837a3574beb3334509cfb2c9", null ],
    [ "SPEED_FEATURES", "speed__features_8h.html#a4a1fdb5ea677281c3604e8f99ef1d33b", null ],
    [ "CDEF_PICK_METHOD", "speed__features_8h.html#af0531e26369694f61a1d06bad088cb38", [
      [ "CDEF_FULL_SEARCH", "speed__features_8h.html#af0531e26369694f61a1d06bad088cb38a4f856e769829192cd8ec449baeec2012", null ],
      [ "CDEF_FAST_SEARCH_LVL1", "speed__features_8h.html#af0531e26369694f61a1d06bad088cb38a2fa63007cc3a58f498c748c53fb87158", null ],
      [ "CDEF_FAST_SEARCH_LVL2", "speed__features_8h.html#af0531e26369694f61a1d06bad088cb38a19fe571caa99298b7ef9e9562697802e", null ],
      [ "CDEF_FAST_SEARCH_LVL3", "speed__features_8h.html#af0531e26369694f61a1d06bad088cb38aefb133e7b51a2554188fb32820b17cb7", null ],
      [ "CDEF_FAST_SEARCH_LVL4", "speed__features_8h.html#af0531e26369694f61a1d06bad088cb38addd2ae3f38d50ef46c4e34309b691a29", null ],
      [ "CDEF_FAST_SEARCH_LVL5", "speed__features_8h.html#af0531e26369694f61a1d06bad088cb38a1f389774142308f63a77addf2cee9051", null ],
      [ "CDEF_PICK_FROM_Q", "speed__features_8h.html#af0531e26369694f61a1d06bad088cb38a981856d684f25f09bbc7d48ae85c627e", null ],
      [ "CDEF_PICK_METHODS", "speed__features_8h.html#af0531e26369694f61a1d06bad088cb38a54ec658a3a10c249a81c092b0bbfb38c", null ]
    ] ],
    [ "INTERNAL_COST_UPDATE_TYPE", "speed__features_8h.html#a15215de986649ea6e79616020fcaa05e", [
      [ "INTERNAL_COST_UPD_OFF", "speed__features_8h.html#a15215de986649ea6e79616020fcaa05ea71c4d449501909a68c7a4dd0eff51c73", null ],
      [ "INTERNAL_COST_UPD_TILE", "speed__features_8h.html#a15215de986649ea6e79616020fcaa05eaed4cca1add2f2aa6f089eee12d0eefc5", null ],
      [ "INTERNAL_COST_UPD_SBROW_SET", "speed__features_8h.html#a15215de986649ea6e79616020fcaa05ea9471e8a394b564da6e83380542a101cd", null ],
      [ "INTERNAL_COST_UPD_SBROW", "speed__features_8h.html#a15215de986649ea6e79616020fcaa05eaaadd43dbe5acff18cf31d400c5060de1", null ],
      [ "INTERNAL_COST_UPD_SB", "speed__features_8h.html#a15215de986649ea6e79616020fcaa05eaca097aaff2e966e9bf5dfa7afb3ac375", null ]
    ] ],
    [ "SIMPLE_MOTION_SEARCH_PRUNE_LEVEL", "speed__features_8h.html#a3198df635f8eabad8275fb4b00933730", [
      [ "NO_PRUNING", "speed__features_8h.html#a3198df635f8eabad8275fb4b00933730a6ab366342a7c0bb4277e34abd5c87c05", null ],
      [ "SIMPLE_AGG_LVL0", "speed__features_8h.html#a3198df635f8eabad8275fb4b00933730a62c6529e25df544e36ee7a236ccfe782", null ],
      [ "SIMPLE_AGG_LVL1", "speed__features_8h.html#a3198df635f8eabad8275fb4b00933730a5e5254bcb9eabae8d6283a5c5145a51d", null ],
      [ "SIMPLE_AGG_LVL2", "speed__features_8h.html#a3198df635f8eabad8275fb4b00933730ad09d4be2b6532f7de44afc18d1497f19", null ],
      [ "SIMPLE_AGG_LVL3", "speed__features_8h.html#a3198df635f8eabad8275fb4b00933730a1b9a2c3e18747a0447ef9bc1c15d393a", null ],
      [ "QIDX_BASED_AGG_LVL1", "speed__features_8h.html#a3198df635f8eabad8275fb4b00933730a0ba0ae7adee5684521c4202ebf2f41b3", null ],
      [ "TOTAL_SIMPLE_AGG_LVLS", "speed__features_8h.html#a3198df635f8eabad8275fb4b00933730a58e541f3e6e9f8de46311a9d5a559f7b", null ],
      [ "TOTAL_QINDEX_BASED_AGG_LVLS", "speed__features_8h.html#a3198df635f8eabad8275fb4b00933730afe1e40d7fb099b9f60f806b0688c1653", null ],
      [ "TOTAL_AGG_LVLS", "speed__features_8h.html#a3198df635f8eabad8275fb4b00933730a923100bd1f971d803a5c1ffc6450968d", null ]
    ] ],
    [ "PRUNE_MESH_SEARCH_LEVEL", "speed__features_8h.html#a68e4e895427312c378498eba3f625de5", [
      [ "PRUNE_MESH_SEARCH_DISABLED", "speed__features_8h.html#a68e4e895427312c378498eba3f625de5adf08aa6505034483c40cdaa3b3e9f8f9", null ],
      [ "PRUNE_MESH_SEARCH_LVL_1", "speed__features_8h.html#a68e4e895427312c378498eba3f625de5a12114b73706fd58592288e138d89d0f9", null ],
      [ "PRUNE_MESH_SEARCH_LVL_2", "speed__features_8h.html#a68e4e895427312c378498eba3f625de5a46339242cf13e6620b95cb539d14e3ad", null ]
    ] ],
    [ "INTER_SEARCH_EARLY_TERM_IDX", "speed__features_8h.html#a19b61f41d5d888d8b1b2efd454bdd495", [
      [ "EARLY_TERM_DISABLED", "speed__features_8h.html#a19b61f41d5d888d8b1b2efd454bdd495aae0692eaee1dde8a0ae6f88dfacca834", null ],
      [ "EARLY_TERM_IDX_1", "speed__features_8h.html#a19b61f41d5d888d8b1b2efd454bdd495a586c6b1af4a592574d772eb920f82f55", null ],
      [ "EARLY_TERM_IDX_2", "speed__features_8h.html#a19b61f41d5d888d8b1b2efd454bdd495a83d78767f47c83824b03c74f25662550", null ],
      [ "EARLY_TERM_IDX_3", "speed__features_8h.html#a19b61f41d5d888d8b1b2efd454bdd495afc7a87f9b1259a2dbceba6cf1268373e", null ],
      [ "EARLY_TERM_IDX_4", "speed__features_8h.html#a19b61f41d5d888d8b1b2efd454bdd495a6ab205a5189c7b4f5fb9d45fa5557588", null ],
      [ "EARLY_TERM_INDICES", "speed__features_8h.html#a19b61f41d5d888d8b1b2efd454bdd495a4420d4ba9f307d67316cac5803d46c01", null ]
    ] ],
    [ "av1_set_speed_features_framesize_independent", "group__speed__features.html#ga375df45f353341a53823feb529182b2a", null ],
    [ "av1_set_speed_features_framesize_dependent", "group__speed__features.html#ga95ee4b0969a41da950b5c23909d142c4", null ],
    [ "av1_set_speed_features_qindex_dependent", "group__speed__features.html#ga643ab0df2f1abcad7bcd6a612fdbc8a2", null ]
];
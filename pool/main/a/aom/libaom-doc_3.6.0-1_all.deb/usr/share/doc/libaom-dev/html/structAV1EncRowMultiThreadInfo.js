var structAV1EncRowMultiThreadInfo =
[
    [ "allocated_tile_rows", "structAV1EncRowMultiThreadInfo.html#aa10709bc0f6142a12c251eecaa4b314d", null ],
    [ "allocated_tile_cols", "structAV1EncRowMultiThreadInfo.html#a213a5e74fa6a18d962ce9f02d239c4d0", null ],
    [ "allocated_rows", "structAV1EncRowMultiThreadInfo.html#ab27d0af6d3f8d8d41b4fede58b34568f", null ],
    [ "allocated_cols", "structAV1EncRowMultiThreadInfo.html#a3f2230694d5d397932846fa1f954100e", null ],
    [ "thread_id_to_tile_id", "structAV1EncRowMultiThreadInfo.html#a6cc17f3d021b76ca9b9a31c5dfd27ca3", null ],
    [ "num_tile_cols_done", "structAV1EncRowMultiThreadInfo.html#abb182b4a6ad3e5cbaaebe590d5fef37d", null ],
    [ "allocated_sb_rows", "structAV1EncRowMultiThreadInfo.html#a025fcc14804ab0cc9473132b0c137b45", null ],
    [ "mutex_", "structAV1EncRowMultiThreadInfo.html#a09006c90727207130513fc54a48457ad", null ],
    [ "cond_", "structAV1EncRowMultiThreadInfo.html#a86644ff077b93cf17b8b513f290f26f5", null ],
    [ "sync_read_ptr", "structAV1EncRowMultiThreadInfo.html#afc6fec4a038c014edfc197040ce1b95a", null ],
    [ "sync_write_ptr", "structAV1EncRowMultiThreadInfo.html#a7c76b9cb599ff702d8bfd006ce24bd7f", null ]
];
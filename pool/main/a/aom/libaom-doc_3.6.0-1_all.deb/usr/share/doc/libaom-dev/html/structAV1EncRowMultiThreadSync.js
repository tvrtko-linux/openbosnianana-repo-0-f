var structAV1EncRowMultiThreadSync =
[
    [ "mutex_", "structAV1EncRowMultiThreadSync.html#a7af24d4fe7bd5ef0b6157c981fffbd1b", null ],
    [ "cond_", "structAV1EncRowMultiThreadSync.html#ab63c34f9e64e029c843f7f10d1283582", null ],
    [ "num_finished_cols", "structAV1EncRowMultiThreadSync.html#a67a7ae03c1e8790abb9bcecb85e3d5f4", null ],
    [ "sync_range", "structAV1EncRowMultiThreadSync.html#a27dd9c10fa352ad6d8786ea7f93b1c60", null ],
    [ "intrabc_extra_top_right_sb_delay", "structAV1EncRowMultiThreadSync.html#a62095f676de80c171347f3aaf27d310a", null ],
    [ "rows", "structAV1EncRowMultiThreadSync.html#a2148918de3031f58c1963944dd4c7a06", null ],
    [ "next_mi_row", "structAV1EncRowMultiThreadSync.html#a6359be164c36fab8d7be213922b04c51", null ],
    [ "num_threads_working", "structAV1EncRowMultiThreadSync.html#ae78573c796e8635af9587dd131fce2f3", null ]
];
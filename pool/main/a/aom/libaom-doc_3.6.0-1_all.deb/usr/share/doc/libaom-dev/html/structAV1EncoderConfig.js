var structAV1EncoderConfig =
[
    [ "algo_cfg", "structAV1EncoderConfig.html#af115e9bf7e78e78979373b69433f6627", null ],
    [ "kf_cfg", "structAV1EncoderConfig.html#a938b41049fb5152ced9e2bee046a60bb", null ],
    [ "rc_cfg", "structAV1EncoderConfig.html#a8ca4aedef69a67ec4ab721880deb1d01", null ],
    [ "twopass_stats_in", "structAV1EncoderConfig.html#af52aa21eb45f6e5034365352accb6a92", null ],
    [ "pass", "structAV1EncoderConfig.html#aa7ee8fa3d9aba1bcc66fa53e67f6f431", null ]
];
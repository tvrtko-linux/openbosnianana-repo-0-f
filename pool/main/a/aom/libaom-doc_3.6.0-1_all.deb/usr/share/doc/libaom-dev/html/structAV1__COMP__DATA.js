var structAV1__COMP__DATA =
[
    [ "cx_data", "structAV1__COMP__DATA.html#a7eceaa9acbe84ded227d46d76b81b2cf", null ],
    [ "cx_data_sz", "structAV1__COMP__DATA.html#a8b121a19fa5662ccd07a077fd8577d88", null ],
    [ "frame_size", "structAV1__COMP__DATA.html#af847b50bfbb7ac434321113ce5eb8c44", null ],
    [ "lib_flags", "structAV1__COMP__DATA.html#af3e70471d853389cc0cab73c1c010f94", null ],
    [ "ts_frame_start", "structAV1__COMP__DATA.html#a537383e0e0bcb2c177a37ed9d8c9134f", null ],
    [ "ts_frame_end", "structAV1__COMP__DATA.html#a0ca075795f0c17d6bbb961195a3a27d8", null ],
    [ "flush", "structAV1__COMP__DATA.html#a9e30bb6f95c7ab4a35d9fff4ea71db2d", null ],
    [ "timestamp_ratio", "structAV1__COMP__DATA.html#aff89c99a55845a0489681ad33c7647ea", null ],
    [ "pop_lookahead", "structAV1__COMP__DATA.html#a4ae975d8841d40f3f9c4eba18e49dad3", null ],
    [ "frame_display_order_hint", "structAV1__COMP__DATA.html#aec84bbb9c78a22a4be5a0ff14ea680b2", null ]
];
var structAlgoCfg =
[
    [ "sharpness", "structAlgoCfg.html#a08091a815363ac52b51cf804aac83cc4", null ],
    [ "disable_trellis_quant", "structAlgoCfg.html#a0319da427a9d8c4cb93b35cf5f8101fa", null ],
    [ "arnr_max_frames", "structAlgoCfg.html#a21d3da5ab6d952bf4c176a6851df151c", null ],
    [ "arnr_strength", "structAlgoCfg.html#ae98f441d83ede7c70252685c4834e7a1", null ],
    [ "cdf_update_mode", "structAlgoCfg.html#ad2dee9a0a7975cfce76cf1983f3e0a70", null ],
    [ "enable_tpl_model", "structAlgoCfg.html#a552398f991ba34fb6813672ec6c8c6b0", null ],
    [ "enable_overlay", "structAlgoCfg.html#ad5709f3414d178956045cf42eed82f34", null ],
    [ "loopfilter_control", "structAlgoCfg.html#ac19ca5a288a0f46381a8ab7f91133206", null ],
    [ "skip_postproc_filtering", "structAlgoCfg.html#a1d3f1274f4314f6179094d337380f445", null ]
];
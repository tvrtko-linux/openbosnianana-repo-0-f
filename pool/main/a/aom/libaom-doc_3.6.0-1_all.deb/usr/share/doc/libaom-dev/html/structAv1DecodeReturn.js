var structAv1DecodeReturn =
[
    [ "buf", "structAv1DecodeReturn.html#aab2b7d54d778b8d5ef5b475b4460ee9f", null ],
    [ "idx", "structAv1DecodeReturn.html#aeefcb8b1f412902428fa86ea066e4414", null ],
    [ "show_existing", "structAv1DecodeReturn.html#ac95f1cc492f7bb172dc1d9132674c3ec", null ]
];
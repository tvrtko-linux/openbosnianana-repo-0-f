var structCB__COEFF__BUFFER =
[
    [ "tcoeff", "structCB__COEFF__BUFFER.html#ab46d9c426ce409bd819e8e85707550bc", null ],
    [ "eobs", "structCB__COEFF__BUFFER.html#a7c8fd243688fcb9d8039a8dbc3b90499", null ],
    [ "entropy_ctx", "structCB__COEFF__BUFFER.html#a67894d997256030d9357a997a0a68da9", null ]
];
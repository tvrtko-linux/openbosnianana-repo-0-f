var structCOMP__RD__STATS =
[
    [ "rate", "structCOMP__RD__STATS.html#a595385f4435ba53b0a4cddc7f2406a01", null ],
    [ "dist", "structCOMP__RD__STATS.html#a4452b7387196bb4c689b8568b7595598", null ],
    [ "model_rate", "structCOMP__RD__STATS.html#a961a8e50b2c1260936f4a44c87ed348f", null ],
    [ "model_dist", "structCOMP__RD__STATS.html#a0180a3d9fe639a244d2f0f4e7ab015db", null ],
    [ "comp_rs2", "structCOMP__RD__STATS.html#a2e458dbc4ea99b9af00d73524408bcaf", null ],
    [ "mv", "structCOMP__RD__STATS.html#a901af9a52d332d23c0e63f5096dc6b86", null ],
    [ "ref_frames", "structCOMP__RD__STATS.html#a9606c8d33733cefddf418a0b7a4bd7e6", null ],
    [ "mode", "structCOMP__RD__STATS.html#a483c89ae8f480b8315056c9c2fffc935", null ],
    [ "filter", "structCOMP__RD__STATS.html#a21781d988675fd14d2476fe18a66ea2c", null ],
    [ "ref_mv_idx", "structCOMP__RD__STATS.html#ac969603c69501775a83c07d25772d9db", null ],
    [ "is_global", "structCOMP__RD__STATS.html#a4d3a8cd6d01bcbddca9e6be35791ed9c", null ],
    [ "interinter_comp", "structCOMP__RD__STATS.html#a3ca315bd64b98d43a8e4cfe9fa351248", null ]
];
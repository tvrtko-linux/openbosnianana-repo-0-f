var structCYCLIC__REFRESH =
[
    [ "percent_refresh", "structCYCLIC__REFRESH.html#ae315bcaf369b95ab1162f2d1271263de", null ],
    [ "percent_refresh_adjustment", "structCYCLIC__REFRESH.html#ad8b57361f650ec0720a5fff2367602e4", null ],
    [ "max_qdelta_perc", "structCYCLIC__REFRESH.html#a441d4805353c603874ae7f356a649cd3", null ],
    [ "sb_index", "structCYCLIC__REFRESH.html#ad45cfe66fc5d1ab8aecee9bc1ef72f44", null ],
    [ "time_for_refresh", "structCYCLIC__REFRESH.html#a14a2e1c9b9ca6a36bb29ccd9a0e02002", null ],
    [ "target_num_seg_blocks", "structCYCLIC__REFRESH.html#ac79bf4f50ebef3b6e6fd91e25af9a2c6", null ],
    [ "actual_num_seg1_blocks", "structCYCLIC__REFRESH.html#aebf6363e9a037324981bd3739cdce960", null ],
    [ "actual_num_seg2_blocks", "structCYCLIC__REFRESH.html#a7b30c416581337161479c00e08fed8ea", null ],
    [ "rdmult", "structCYCLIC__REFRESH.html#a383b90c4a87340a91580aac8a537aee6", null ],
    [ "map", "structCYCLIC__REFRESH.html#a5034d2e9cba349dd451d41f6362dc6f9", null ],
    [ "thresh_rate_sb", "structCYCLIC__REFRESH.html#a11f1a950d76b9908606d234eab0d8b2b", null ],
    [ "thresh_dist_sb", "structCYCLIC__REFRESH.html#a74276b39125b068743f0b6dc2ba0f36a", null ],
    [ "motion_thresh", "structCYCLIC__REFRESH.html#a08162f2bd6028160d470024577dfcec6", null ],
    [ "rate_ratio_qdelta", "structCYCLIC__REFRESH.html#afe7bf45e2c31665d7d64254c23fdaf6c", null ],
    [ "rate_ratio_qdelta_adjustment", "structCYCLIC__REFRESH.html#aab71afb9e2f97492ee5b8072ebffc743", null ],
    [ "rate_boost_fac", "structCYCLIC__REFRESH.html#ae0966dda4b2470d422129ed473e39d4c", null ]
];
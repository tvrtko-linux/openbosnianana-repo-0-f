var structCdefBlockInfo =
[
    [ "src", "structCdefBlockInfo.html#a75147d724dd5cee22b77566c7230fcfa", null ],
    [ "top_linebuf", "structCdefBlockInfo.html#ad419a52b965eb5e75429720aaa91486b", null ],
    [ "bot_linebuf", "structCdefBlockInfo.html#ab2a26ead9996c38cd81f4ba2877b8785", null ],
    [ "dst", "structCdefBlockInfo.html#afa85936528686696f0b9014001ebc327", null ],
    [ "dlist", "structCdefBlockInfo.html#a4ad2988b2695001d9374b1a7fd4b35d6", null ],
    [ "xdec", "structCdefBlockInfo.html#a7c8a68ad17f4bf4b56b9683bf3218487", null ],
    [ "ydec", "structCdefBlockInfo.html#a44eca63603d29b43c01ea111fe123f55", null ],
    [ "mi_wide_l2", "structCdefBlockInfo.html#aaa9d07e701b17178f2df56008ba2c63d", null ],
    [ "mi_high_l2", "structCdefBlockInfo.html#ab38dbe4223608daf783ac784c3d29b62", null ],
    [ "frame_boundary", "structCdefBlockInfo.html#a02095b6a7c1fa710fba74e8f9562e7a2", null ],
    [ "damping", "structCdefBlockInfo.html#a476ae103e6c83f771304636eec4200a3", null ],
    [ "coeff_shift", "structCdefBlockInfo.html#a4fb787e5e4c30260886e8b596a57d19d", null ],
    [ "level", "structCdefBlockInfo.html#ac68a85cbd440da5e647bf7c3939da779", null ],
    [ "sec_strength", "structCdefBlockInfo.html#a1533527e34ad01e9e3d5c00826b3d8ae", null ],
    [ "cdef_count", "structCdefBlockInfo.html#a03652fa705d9a4958a854e15c235ba78", null ],
    [ "dir", "structCdefBlockInfo.html#a5a27f3ff7d50bea82711643c0c62fffc", null ],
    [ "var", "structCdefBlockInfo.html#ad2e35c122fe7b4c7f37b76226a01ed31", null ],
    [ "dst_stride", "structCdefBlockInfo.html#a926a8fe3dbea617f31ecc6a4e6abf82e", null ],
    [ "coffset", "structCdefBlockInfo.html#ac347fc11ca0ee0dc9fd1d6526468841f", null ],
    [ "roffset", "structCdefBlockInfo.html#a3d92d0f2b678ea20dff439493c2f0797", null ]
];
var structCdefInfo =
[
    [ "colbuf", "structCdefInfo.html#a688b869e45574d7933f14728c54a1a27", null ],
    [ "linebuf", "structCdefInfo.html#a3ff65d3ad7aa8603bb21a532f98b42aa", null ],
    [ "srcbuf", "structCdefInfo.html#ad3b8532c622ffab5e31f919d1c2e00bd", null ],
    [ "allocated_colbuf_size", "structCdefInfo.html#a81e585de83fa81dbea71993c7061d6d4", null ],
    [ "allocated_linebuf_size", "structCdefInfo.html#a173064f005e6fdc10e0f24122420a030", null ],
    [ "allocated_srcbuf_size", "structCdefInfo.html#a6f2ba9146b250e7ef94f4797a2372e22", null ],
    [ "cdef_damping", "structCdefInfo.html#ad0b176e6eabbcdd3595996d65f4ab2c0", null ],
    [ "nb_cdef_strengths", "structCdefInfo.html#a9db68a90b507cdd5318fd04315b74f91", null ],
    [ "cdef_strengths", "structCdefInfo.html#a738e5a64a2444172242657a1d4f38da2", null ],
    [ "cdef_uv_strengths", "structCdefInfo.html#a4eaec31c37f21425a3ea8628962e7c48", null ],
    [ "cdef_bits", "structCdefInfo.html#a37fd9da5a079772b44f46304e6734f5a", null ],
    [ "allocated_mi_rows", "structCdefInfo.html#a3955d1b6756a604a80a0b215f662cdb2", null ],
    [ "allocated_num_workers", "structCdefInfo.html#a470cff70a4416668b028ec12a986c7a1", null ]
];
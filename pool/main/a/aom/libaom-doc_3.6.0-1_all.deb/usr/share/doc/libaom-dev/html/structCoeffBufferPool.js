var structCoeffBufferPool =
[
    [ "tcoeff", "structCoeffBufferPool.html#ae5818314131a73cd0812538b6660e078", null ],
    [ "eobs", "structCoeffBufferPool.html#aee110677e0c17ae1baaff823c7d18286", null ],
    [ "entropy_ctx", "structCoeffBufferPool.html#aad961bd59217b79cdb1cfab09de12d4d", null ]
];
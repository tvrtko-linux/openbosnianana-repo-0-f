var structCoeffCosts =
[
    [ "coeff_costs", "structCoeffCosts.html#af990465822bc644c743c5129d8d6d039", null ],
    [ "eob_costs", "structCoeffCosts.html#ae8afc618945a082c26412e9c1e90fbde", null ]
];
var structColorCount =
[
    [ "index", "structColorCount.html#ac569609b9a11dbe3915915d1e2def8d4", null ],
    [ "count", "structColorCount.html#a1732c20ac192fe0d777f1d8502f2ceeb", null ]
];
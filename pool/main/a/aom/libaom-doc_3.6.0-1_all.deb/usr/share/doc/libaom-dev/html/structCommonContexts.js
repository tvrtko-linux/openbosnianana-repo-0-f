var structCommonContexts =
[
    [ "partition", "structCommonContexts.html#a065431a5259fddc51bceec4f22233419", null ],
    [ "entropy", "structCommonContexts.html#a8d9c8b0840bdb4969f101ad6eb124c2f", null ],
    [ "txfm", "structCommonContexts.html#af17097fb0b2d4a6d13cf59b423251d4a", null ],
    [ "num_planes", "structCommonContexts.html#a1a56ca1f3a6aac2c924b2cbba039646a", null ],
    [ "num_tile_rows", "structCommonContexts.html#aae9be789112f0df7ba36a3eec9d5638a", null ],
    [ "num_mi_cols", "structCommonContexts.html#aded39732de8b98e105ddcb3b71658fdc", null ]
];
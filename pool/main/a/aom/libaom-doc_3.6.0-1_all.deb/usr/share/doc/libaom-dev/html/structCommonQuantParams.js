var structCommonQuantParams =
[
    [ "base_qindex", "structCommonQuantParams.html#a7a9038020ad4b2a837f75c964e9cbd40", null ],
    [ "y_dc_delta_q", "structCommonQuantParams.html#ae6b10a492cbf8dd0501129c7d264ee6d", null ],
    [ "u_dc_delta_q", "structCommonQuantParams.html#a6825895b20499860191f94b908be2f39", null ],
    [ "v_dc_delta_q", "structCommonQuantParams.html#ade3a29210ea7504fcba1c4bcacd1e692", null ],
    [ "u_ac_delta_q", "structCommonQuantParams.html#a01d6e6e663e708fd230dfa8a4d771320", null ],
    [ "v_ac_delta_q", "structCommonQuantParams.html#a5770765a82200e84a9e621f1632b3f5d", null ],
    [ "y_dequant_QTX", "structCommonQuantParams.html#ad5a34dbb0ead83ec6d2ef1a598ed832d", null ],
    [ "u_dequant_QTX", "structCommonQuantParams.html#a357284012595df64bd5d687fa667825e", null ],
    [ "v_dequant_QTX", "structCommonQuantParams.html#a966913d34df3a5909feb612e714bd6b3", null ],
    [ "giqmatrix", "structCommonQuantParams.html#a2ad05f39cabcdd12d9bd34136788793a", null ],
    [ "gqmatrix", "structCommonQuantParams.html#afae3f12fc3aa940840f9a04b05fdd387", null ],
    [ "y_iqmatrix", "structCommonQuantParams.html#a4f9755f8ced8ec35d3dc0986c4c3ce3b", null ],
    [ "u_iqmatrix", "structCommonQuantParams.html#a0bec28af02aa55ca9f2d44e212fff445", null ],
    [ "v_iqmatrix", "structCommonQuantParams.html#aaeafbb83ee5df9c8fbba96f3cd250338", null ],
    [ "using_qmatrix", "structCommonQuantParams.html#a5a12ee629649c8c1958238cd238b36bc", null ],
    [ "qmatrix_level_y", "structCommonQuantParams.html#a5285812982f35c7324e2a071bde7baad", null ],
    [ "qmatrix_level_u", "structCommonQuantParams.html#a69949db8cd0b812e3c8485e0585d6da2", null ],
    [ "qmatrix_level_v", "structCommonQuantParams.html#a184dcbe8f484a0d1d224f367224a5379", null ]
];
var structCommonTileParams =
[
    [ "cols", "structCommonTileParams.html#a8842e296add2a242e4aaf0fcae574f9b", null ],
    [ "rows", "structCommonTileParams.html#ae02a00791e102b0535e98618b33f8437", null ],
    [ "max_width_sb", "structCommonTileParams.html#a1141ae4079cca997c2cdd98e7eeca115", null ],
    [ "max_height_sb", "structCommonTileParams.html#a9d06ed0c420a1571838df00f89603ba7", null ],
    [ "min_inner_width", "structCommonTileParams.html#aeabe8ddc050f14b323346dcb9d02019d", null ],
    [ "uniform_spacing", "structCommonTileParams.html#a001b6543ac7a848ede198dc1ff7e4a28", null ],
    [ "log2_cols", "structCommonTileParams.html#ad8043d38fd14939030a7b120e4804f08", null ],
    [ "log2_rows", "structCommonTileParams.html#a30ee31c09c895fe2a590359e197b85c5", null ],
    [ "width", "structCommonTileParams.html#a44b107256e3a2e527c5d47b74af43951", null ],
    [ "height", "structCommonTileParams.html#afffc1013b0412ac1c16b92ab8de624b5", null ],
    [ "min_log2_cols", "structCommonTileParams.html#af2c6303c1673d5f8be2f7ef69e49eea5", null ],
    [ "min_log2_rows", "structCommonTileParams.html#a32574d672c09b5b98a4ae9d3645c980b", null ],
    [ "max_log2_cols", "structCommonTileParams.html#ac9c29974db76e6d01bbe23be00487613", null ],
    [ "max_log2_rows", "structCommonTileParams.html#a5f6b00965abc83409350b6c77169fbbb", null ],
    [ "min_log2", "structCommonTileParams.html#adf531cc5778117db62b32d0c535a5ce5", null ],
    [ "col_start_sb", "structCommonTileParams.html#af81e2bd60ef46e68290116f08018d25a", null ],
    [ "row_start_sb", "structCommonTileParams.html#a68c8e416df2344d1338ebc6959651b0d", null ],
    [ "large_scale", "structCommonTileParams.html#aa268beca2c5cb66be43cf6f9ab3d81fd", null ],
    [ "single_tile_decoding", "structCommonTileParams.html#ab00658e6a613f237ebe25cd533da2f2b", null ]
];
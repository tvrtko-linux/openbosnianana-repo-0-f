var structCompoundTypeCfg =
[
    [ "enable_dist_wtd_comp", "structCompoundTypeCfg.html#ace2f9377877c3e510259c2bc4e8afbf4", null ],
    [ "enable_masked_comp", "structCompoundTypeCfg.html#a420af7613723576d34b92387e603709a", null ],
    [ "enable_smooth_interintra", "structCompoundTypeCfg.html#a6f8296d512aa11644fd517139f16819a", null ],
    [ "enable_diff_wtd_comp", "structCompoundTypeCfg.html#a621023e8fe22d73d491dab01a6913c28", null ],
    [ "enable_interinter_wedge", "structCompoundTypeCfg.html#ab91203bbbfd6d719a6da37a15f19cc7e", null ],
    [ "enable_interintra_wedge", "structCompoundTypeCfg.html#a8da9b483349b77e70f47bacd1bd7463f", null ]
];
var structCompoundTypeRdBuffers =
[
    [ "pred0", "structCompoundTypeRdBuffers.html#a874ef6c91bef8040c15aa3f7106477d7", null ],
    [ "pred1", "structCompoundTypeRdBuffers.html#a2dfbf90a18fd1306d52a111cd483b48c", null ],
    [ "residual1", "structCompoundTypeRdBuffers.html#a725351355f36a815edf46e3c639fc651", null ],
    [ "diff10", "structCompoundTypeRdBuffers.html#a2d0eb88fa21e850fa63747151d123814", null ],
    [ "tmp_best_mask_buf", "structCompoundTypeRdBuffers.html#af0d98489d93f491478e9f01680f7422e", null ]
];
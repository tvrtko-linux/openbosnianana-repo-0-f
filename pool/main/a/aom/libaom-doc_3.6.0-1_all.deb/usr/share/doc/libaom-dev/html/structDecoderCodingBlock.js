var structDecoderCodingBlock =
[
    [ "xd", "structDecoderCodingBlock.html#aaa2c5c84f79dbca65924def9d610bbe8", null ],
    [ "corrupted", "structDecoderCodingBlock.html#a666b768547398c156010633738c3c7fe", null ],
    [ "mc_buf", "structDecoderCodingBlock.html#a3d7878f4f44f6440ac585deac7e930fd", null ],
    [ "dqcoeff_block", "structDecoderCodingBlock.html#a467a9cfa1fbea81573608c3eaa616888", null ],
    [ "cb_offset", "structDecoderCodingBlock.html#ad5e1140103a21db1a81b155c4e3712c4", null ],
    [ "eob_data", "structDecoderCodingBlock.html#a33c770033e288ec4831795780234a2df", null ],
    [ "txb_offset", "structDecoderCodingBlock.html#a60cd7244dd36bf4ee11e56729e09961b", null ],
    [ "ref_mv_count", "structDecoderCodingBlock.html#aae7bede7a95c3b6602c1acfd63843c8d", null ]
];
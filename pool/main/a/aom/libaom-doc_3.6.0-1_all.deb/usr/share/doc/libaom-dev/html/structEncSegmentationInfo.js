var structEncSegmentationInfo =
[
    [ "map", "structEncSegmentationInfo.html#a86a55ad3351e10d83946ed1ad27f5304", null ],
    [ "has_lossless_segment", "structEncSegmentationInfo.html#ad294db91c291f8041efdd9b8050252f2", null ]
];
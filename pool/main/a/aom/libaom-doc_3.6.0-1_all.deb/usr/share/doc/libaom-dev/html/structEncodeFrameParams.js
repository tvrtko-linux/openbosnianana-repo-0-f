var structEncodeFrameParams =
[
    [ "error_resilient_mode", "structEncodeFrameParams.html#a08eccb7c4660439d8db6cbbd6300469d", null ],
    [ "frame_type", "structEncodeFrameParams.html#ab81000812fb9f43ead937a587bb1361a", null ],
    [ "show_frame", "structEncodeFrameParams.html#abdc3eb71775a8a6558d18e6d5a7133f0", null ],
    [ "ref_frame_flags", "structEncodeFrameParams.html#a31ed2c1e63e5ac5d7579bb34921e920c", null ],
    [ "remapped_ref_idx", "structEncodeFrameParams.html#a3191b2abb6a0033d2021b8e67fac115b", null ],
    [ "refresh_frame", "structEncodeFrameParams.html#afaccaa8bebb3d9d833c0bb682b0a000f", null ],
    [ "speed", "structEncodeFrameParams.html#a5f46f249fa048c23d8eb54a485c46afc", null ]
];
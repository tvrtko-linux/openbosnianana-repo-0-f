var structExtRefreshFrameFlagsInfo =
[
    [ "last_frame", "structExtRefreshFrameFlagsInfo.html#a8354900ef16154a82130360282aa69b7", null ],
    [ "golden_frame", "structExtRefreshFrameFlagsInfo.html#a28e2d4f515d0a75030bd6a130077ac74", null ],
    [ "bwd_ref_frame", "structExtRefreshFrameFlagsInfo.html#a2942b5150e250dded18b3d9fc646371b", null ],
    [ "alt2_ref_frame", "structExtRefreshFrameFlagsInfo.html#a98d8b8f9d3a019c845052335f1e09cbd", null ],
    [ "alt_ref_frame", "structExtRefreshFrameFlagsInfo.html#a976ce63f79f15bdc5cfea13dccb74185", null ],
    [ "update_pending", "structExtRefreshFrameFlagsInfo.html#a2e976f554b36c4008b3130564168455a", null ]
];
var structExternalFlags =
[
    [ "ref_frame_flags", "structExternalFlags.html#a8e24f96f899e8a177ff5980fe0c8af01", null ],
    [ "refresh_frame", "structExternalFlags.html#a762ea58a7c4d3d54d3dca9500a730dcc", null ],
    [ "refresh_frame_context", "structExternalFlags.html#ab15381907aee07adbf1734f9744a0440", null ],
    [ "refresh_frame_context_pending", "structExternalFlags.html#ac3e082f752e9ee5aeb610ca0b7640511", null ],
    [ "use_ref_frame_mvs", "structExternalFlags.html#a70257b3dfe1926b755885cc93e8af411", null ],
    [ "use_error_resilient", "structExternalFlags.html#a995887e2bd1ecfa0182288491e5761ce", null ],
    [ "use_s_frame", "structExternalFlags.html#aab0e066796e4e14dd816bbbaf4e5474e", null ],
    [ "use_primary_ref_none", "structExternalFlags.html#a586307d4b7ec546c47a7e1b8acbc6d37", null ]
];
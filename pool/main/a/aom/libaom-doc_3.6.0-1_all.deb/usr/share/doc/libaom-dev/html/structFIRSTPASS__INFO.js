var structFIRSTPASS__INFO =
[
    [ "static_stats_buf", "structFIRSTPASS__INFO.html#a50cf9d3363ae09efb3ba5827beb22eb2", null ],
    [ "stats_buf", "structFIRSTPASS__INFO.html#afb6e9f9cce82b62f53a0f038bdea3cbd", null ],
    [ "stats_buf_size", "structFIRSTPASS__INFO.html#a9fbac08fbb591865fd4ecbfb44fe7505", null ],
    [ "start_index", "structFIRSTPASS__INFO.html#acf7935cccc12f9408a254919dbce7059", null ],
    [ "stats_count", "structFIRSTPASS__INFO.html#ae82b1335e6ffd0df281264702946f1d9", null ],
    [ "cur_index", "structFIRSTPASS__INFO.html#a13a682830f15eb5ad80c20541d1ffba5", null ],
    [ "future_stats_count", "structFIRSTPASS__INFO.html#a98b02ddacc1149ec363e152881d7fffe", null ],
    [ "past_stats_count", "structFIRSTPASS__INFO.html#a79971ac2f41950e2330721078f55cafd", null ],
    [ "total_stats", "structFIRSTPASS__INFO.html#ab917a53344d2c52e6691ef214726bb8c", null ]
];
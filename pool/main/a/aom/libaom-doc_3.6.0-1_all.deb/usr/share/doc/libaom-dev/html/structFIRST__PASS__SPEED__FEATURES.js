var structFIRST__PASS__SPEED__FEATURES =
[
    [ "reduce_mv_step_param", "structFIRST__PASS__SPEED__FEATURES.html#a3447a2efd6a276e1bafa7da5a733d74b", null ],
    [ "skip_motion_search_threshold", "structFIRST__PASS__SPEED__FEATURES.html#a87aef1c4c7085753180ff6cf08a94987", null ],
    [ "disable_recon", "structFIRST__PASS__SPEED__FEATURES.html#a0df81b8e8c6df2f5ab6ed901b055316b", null ],
    [ "skip_zeromv_motion_search", "structFIRST__PASS__SPEED__FEATURES.html#a665f9333f729077b7ee01ae71af4eb5b", null ]
];
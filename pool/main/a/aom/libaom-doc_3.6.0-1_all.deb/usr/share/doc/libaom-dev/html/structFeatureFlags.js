var structFeatureFlags =
[
    [ "disable_cdf_update", "structFeatureFlags.html#acbaf1190df86611d7649102986c76ac8", null ],
    [ "allow_high_precision_mv", "structFeatureFlags.html#ae863ba15714165a46d41ec1725e5e918", null ],
    [ "cur_frame_force_integer_mv", "structFeatureFlags.html#af1ad3f5d83f9a7689bd72a56ed79b66a", null ],
    [ "allow_screen_content_tools", "structFeatureFlags.html#a4673a95785cbbd4567c2d46568e76b81", null ],
    [ "allow_intrabc", "structFeatureFlags.html#a719fee45243189c854242e69cacedb1c", null ],
    [ "allow_warped_motion", "structFeatureFlags.html#a3bbc83ef1c0c5bd255ee434a811869fc", null ],
    [ "allow_ref_frame_mvs", "structFeatureFlags.html#a0c21a03bb577bcbce30141581a269208", null ],
    [ "coded_lossless", "structFeatureFlags.html#a91115671a1effbdc6f91e75bc6953632", null ],
    [ "all_lossless", "structFeatureFlags.html#af2d1193760dcb1a07797de6a0917f487", null ],
    [ "reduced_tx_set_used", "structFeatureFlags.html#a704004163b955deb759a8b16ff6c6521", null ],
    [ "error_resilient_mode", "structFeatureFlags.html#ab0a9b67122fddf662c5712caf28d1b7d", null ],
    [ "switchable_motion_mode", "structFeatureFlags.html#a6376fc46351651e3f1712cd85edd6f37", null ],
    [ "tx_mode", "structFeatureFlags.html#a6b370f2d339ad08651a280a03e447460", null ],
    [ "interp_filter", "structFeatureFlags.html#a091813e431220a2cefb5b24c0a443cd2", null ],
    [ "primary_ref_frame", "structFeatureFlags.html#ab4e44099be4a9d71cc65feffa59f766d", null ],
    [ "byte_alignment", "structFeatureFlags.html#a72c466f1bb434211a32a8fc1444cc3e3", null ],
    [ "refresh_frame_context", "structFeatureFlags.html#a986b810980c3a1952063a93b8d115b3e", null ]
];
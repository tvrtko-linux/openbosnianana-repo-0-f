var structFrameProbInfo =
[
    [ "obmc_probs", "structFrameProbInfo.html#ad1dc4eed12e9bde876d50e2987eb952c", null ],
    [ "warped_probs", "structFrameProbInfo.html#af4a4295f91820d2a72e573c4d704facc", null ],
    [ "tx_type_probs", "structFrameProbInfo.html#af660c52ea798b90c2ec15ca8d2c865bd", null ],
    [ "switchable_interp_probs", "structFrameProbInfo.html#a98526738c09cfa584d0d3b32a07db1a5", null ]
];
var structGlobalMotionInfo =
[
    [ "search_done", "structGlobalMotionInfo.html#a2e9defee1184b55efb4550b82c2d151c", null ],
    [ "ref_buf", "structGlobalMotionInfo.html#ad59456490baa5300bd4e08d944d2004c", null ],
    [ "src_buffer", "structGlobalMotionInfo.html#adfcad46db897acc7843dfff50be8843c", null ],
    [ "num_ref_frames", "structGlobalMotionInfo.html#a603f9dd649a1311c84bf21af2495a512", null ],
    [ "reference_frames", "structGlobalMotionInfo.html#a148f4be74c0bf981d92cf0d75741e09e", null ],
    [ "segment_map_w", "structGlobalMotionInfo.html#af73dc485cfca0d36c621860baf27a389", null ],
    [ "segment_map_h", "structGlobalMotionInfo.html#a4c5cd88a16cf7cfb15887ab1f590b2cc", null ],
    [ "num_src_corners", "structGlobalMotionInfo.html#accb25b3711a2441e2c6ff5df2d516f73", null ],
    [ "src_corners", "structGlobalMotionInfo.html#a5df623fba51144015bb18bd396432bb0", null ]
];
var structHIGH__LEVEL__SPEED__FEATURES =
[
    [ "frame_parameter_update", "structHIGH__LEVEL__SPEED__FEATURES.html#a41468d08f44a61dc5c27c0b9ad9b3660", null ],
    [ "recode_loop", "structHIGH__LEVEL__SPEED__FEATURES.html#ae5ac0472be257e6c45626e00c7eefe6b", null ],
    [ "recode_tolerance", "structHIGH__LEVEL__SPEED__FEATURES.html#aac96ea2df7979b40eaa8f6dc4ba62821", null ],
    [ "high_precision_mv_usage", "structHIGH__LEVEL__SPEED__FEATURES.html#a63ad9d9f3faabf5779ea94d3a62718b7", null ],
    [ "static_segmentation", "structHIGH__LEVEL__SPEED__FEATURES.html#abbc8b917d795abbee76fa2fc9efe8c85", null ],
    [ "superres_auto_search_type", "structHIGH__LEVEL__SPEED__FEATURES.html#ab0d822dd440fca06dadbd042fa749881", null ],
    [ "disable_extra_sc_testing", "structHIGH__LEVEL__SPEED__FEATURES.html#a93f9d17662d20445b49262ef01880a6b", null ],
    [ "second_alt_ref_filtering", "structHIGH__LEVEL__SPEED__FEATURES.html#a1f5862490fb7b03317b66f8578271a30", null ],
    [ "num_frames_used_in_tf", "structHIGH__LEVEL__SPEED__FEATURES.html#ae274fdbc21d1f9709514e2c6a77eab5b", null ],
    [ "accurate_bit_estimate", "structHIGH__LEVEL__SPEED__FEATURES.html#ad4e0881065dd85ccb05b27099c3d8386", null ]
];
var structInitialDimensions =
[
    [ "width", "structInitialDimensions.html#af3b072e04b30ea79a207e250de4c9973", null ],
    [ "height", "structInitialDimensions.html#ae7bb3f40ad679389312c89fe5e917af3", null ]
];
var structInterpSearchFlags =
[
    [ "default_interp_skip_flags", "structInterpSearchFlags.html#a1720ff86680c7e8e7b2f77d4a23d5790", null ],
    [ "interp_filter_search_mask", "structInterpSearchFlags.html#a92fde19334f66058b6eac0efa041cf34", null ]
];
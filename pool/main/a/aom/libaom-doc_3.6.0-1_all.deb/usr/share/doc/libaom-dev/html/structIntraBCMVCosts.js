var structIntraBCMVCosts =
[
    [ "joint_mv", "structIntraBCMVCosts.html#ae77e28c15cf4f18cd35ea8406d9b1fd4", null ],
    [ "dv_costs_alloc", "structIntraBCMVCosts.html#a7f8582d04ace4eeee99a3deb3b8771d8", null ],
    [ "dv_costs", "structIntraBCMVCosts.html#a110357a01a87108133fccf1afefa389b", null ]
];
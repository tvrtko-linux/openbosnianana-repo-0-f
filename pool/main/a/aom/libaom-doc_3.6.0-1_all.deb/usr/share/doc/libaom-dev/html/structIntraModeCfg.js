var structIntraModeCfg =
[
    [ "enable_intra_edge_filter", "structIntraModeCfg.html#ae0e684b32d3501867663070f6e1c22f2", null ],
    [ "enable_filter_intra", "structIntraModeCfg.html#a5907afc4c7e63e9f64c2ab56600c3e77", null ],
    [ "enable_smooth_intra", "structIntraModeCfg.html#a21efde3a70fba9fd93db0ea8229b15d6", null ],
    [ "enable_paeth_intra", "structIntraModeCfg.html#aaf15940fb88791de54e8260a9d4b6e0a", null ],
    [ "enable_cfl_intra", "structIntraModeCfg.html#aef6743e8fee9ca35c38da19091b9ee47", null ],
    [ "enable_directional_intra", "structIntraModeCfg.html#a99fb2a4f0aafc9bd5ac17905e614f83c", null ],
    [ "enable_diagonal_intra", "structIntraModeCfg.html#a09f1535b47b58079a6818ed31f636e92", null ],
    [ "enable_angle_delta", "structIntraModeCfg.html#af939ab8fb5755b0f563c3d6537c5529e", null ],
    [ "auto_intra_tools_off", "structIntraModeCfg.html#a25e90d1483c243b3f1d68babc5006cc9", null ]
];
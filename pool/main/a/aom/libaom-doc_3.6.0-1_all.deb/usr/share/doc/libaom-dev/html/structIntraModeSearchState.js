var structIntraModeSearchState =
[
    [ "best_intra_mode", "structIntraModeSearchState.html#a0472a732c8f9c98c8ea9b2acb37f5fd9", null ],
    [ "skip_intra_modes", "structIntraModeSearchState.html#a1ce417682bbc1abf5875b22ea2635406", null ],
    [ "directional_mode_skip_mask", "structIntraModeSearchState.html#ad4f5d3f5504e7966368abcc986bc41da", null ],
    [ "dir_mode_skip_mask_ready", "structIntraModeSearchState.html#a19c96626ab27bf6a702757073552502f", null ],
    [ "rate_uv_intra", "structIntraModeSearchState.html#a4bc60f4372773e7c91b3277eb0023b3a", null ],
    [ "rate_uv_tokenonly", "structIntraModeSearchState.html#af2d8182817636c922c43c7322872e2a7", null ],
    [ "dist_uvs", "structIntraModeSearchState.html#a391cabca7041c920c348ba012a9476c6", null ],
    [ "skip_uvs", "structIntraModeSearchState.html#a9371207d24e8c4b01a06b10592015ffc", null ],
    [ "mode_uv", "structIntraModeSearchState.html#ad8f4c6456f23dde3054a96dec02f7ea9", null ],
    [ "pmi_uv", "structIntraModeSearchState.html#ad44eee52248ba01975d56b5bcb3484d1", null ],
    [ "uv_angle_delta", "structIntraModeSearchState.html#af5816d3b8649ea51b3aa66f0cd9931a8", null ]
];
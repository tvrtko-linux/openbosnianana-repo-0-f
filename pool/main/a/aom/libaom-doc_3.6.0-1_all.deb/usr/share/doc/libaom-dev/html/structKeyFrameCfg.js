var structKeyFrameCfg =
[
    [ "key_freq_min", "structKeyFrameCfg.html#af2b0389436084c2a46d7c8b73c44d907", null ],
    [ "key_freq_max", "structKeyFrameCfg.html#a0b8987c023f9e94b419195ebf81bc6a4", null ],
    [ "enable_keyframe_filtering", "structKeyFrameCfg.html#aaf3754dc88c530c69a547af1a12964c2", null ],
    [ "sframe_dist", "structKeyFrameCfg.html#a8d78931dc6f1292aea5a43f1a69d1b2d", null ],
    [ "sframe_mode", "structKeyFrameCfg.html#a0d2de52e26a39ca0d06271272c94ab7a", null ],
    [ "auto_key", "structKeyFrameCfg.html#a4557b10d7f6d7cfb4df3c99876f97591", null ],
    [ "fwd_kf_dist", "structKeyFrameCfg.html#ae5a2f1eb074f8cfb6a49c710f90cbb9b", null ],
    [ "fwd_kf_enabled", "structKeyFrameCfg.html#af7bf324347fcf8476270fe208ddfc252", null ],
    [ "enable_sframe", "structKeyFrameCfg.html#a917d99dd621257b6f2fc124ea9ca9381", null ],
    [ "enable_intrabc", "structKeyFrameCfg.html#a8c40a607b58692a1b0cac05d60422ec5", null ]
];
var structLAYER__CONTEXT =
[
    [ "sb_index", "structLAYER__CONTEXT.html#a4ff0c1a06b8fd96f5ff37bf2aa98b9d3", null ],
    [ "map", "structLAYER__CONTEXT.html#af1c6b09cc85e7314d989aae83a7b28d5", null ],
    [ "actual_num_seg1_blocks", "structLAYER__CONTEXT.html#a1d897dac3039f8c548df285f6c59b9a9", null ],
    [ "actual_num_seg2_blocks", "structLAYER__CONTEXT.html#a73f7772f35adac06e7f0a0fa76e3e2e8", null ],
    [ "counter_encode_maxq_scene_change", "structLAYER__CONTEXT.html#a5aa14c130d362a8f686211b292b5bbed", null ],
    [ "speed", "structLAYER__CONTEXT.html#a69214df6581b337c578998038451c57a", null ],
    [ "group_index", "structLAYER__CONTEXT.html#ac84886e42f345445136e78d701fec643", null ],
    [ "is_key_frame", "structLAYER__CONTEXT.html#ab1a9c759d6a221c6acafcde147e08a7b", null ],
    [ "max_mv_magnitude", "structLAYER__CONTEXT.html#aa271730c1338c86af854946a694329bc", null ]
];
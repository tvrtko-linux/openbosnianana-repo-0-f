var structLV__MAP__COEFF__COST =
[
    [ "txb_skip_cost", "structLV__MAP__COEFF__COST.html#a3b1604ef5cdf5ef6d5f80b1a2eff97c9", null ],
    [ "base_eob_cost", "structLV__MAP__COEFF__COST.html#ad30ba41c53bce80c8f4c06a966a71204", null ],
    [ "base_cost", "structLV__MAP__COEFF__COST.html#adbc5eac44e6077ce1a59d92736a0cb1f", null ],
    [ "eob_extra_cost", "structLV__MAP__COEFF__COST.html#ac13625e52afc8b9f56490d9b4e3763c8", null ],
    [ "dc_sign_cost", "structLV__MAP__COEFF__COST.html#a524b66066193b2d558d701569a309cd2", null ],
    [ "lps_cost", "structLV__MAP__COEFF__COST.html#a21ff28247f7c01445252cf0d4d157726", null ]
];
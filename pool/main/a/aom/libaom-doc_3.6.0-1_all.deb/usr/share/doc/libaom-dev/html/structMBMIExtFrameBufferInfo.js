var structMBMIExtFrameBufferInfo =
[
    [ "frame_base", "structMBMIExtFrameBufferInfo.html#aa3e1931e2edbe5ee3460688502a4dad6", null ],
    [ "alloc_size", "structMBMIExtFrameBufferInfo.html#a4f34405dd12aa6f0fe1415c4f08b7823", null ],
    [ "stride", "structMBMIExtFrameBufferInfo.html#a774a8b281d7f026cbb5fd5889062d2c5", null ]
];
var structMB__MODE__INFO__EXT =
[
    [ "ref_mv_stack", "structMB__MODE__INFO__EXT.html#a5b2f9171de25fed8a69f12c21298b2cd", null ],
    [ "weight", "structMB__MODE__INFO__EXT.html#abd01fdad400184551ea9a307123e5edf", null ],
    [ "ref_mv_count", "structMB__MODE__INFO__EXT.html#ae02af8b74159f7ed6bdd21ac97bd7dca", null ],
    [ "global_mvs", "structMB__MODE__INFO__EXT.html#a2e556ef31d0033bb56245fec7101e20f", null ],
    [ "mode_context", "structMB__MODE__INFO__EXT.html#ad0f1b39ea6e4492c12447504c9e6490b", null ]
];
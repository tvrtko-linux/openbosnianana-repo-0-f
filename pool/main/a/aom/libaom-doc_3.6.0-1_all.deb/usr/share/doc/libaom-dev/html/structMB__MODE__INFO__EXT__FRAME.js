var structMB__MODE__INFO__EXT__FRAME =
[
    [ "ref_mv_stack", "structMB__MODE__INFO__EXT__FRAME.html#a67ad9fc68a18eb2bae3fd63a320a4545", null ],
    [ "weight", "structMB__MODE__INFO__EXT__FRAME.html#a46fb1fef61dac3d025a3eb94c34412dd", null ],
    [ "ref_mv_count", "structMB__MODE__INFO__EXT__FRAME.html#a430fd9e49f38ceae3aec0ec8f80bd700", null ],
    [ "global_mvs", "structMB__MODE__INFO__EXT__FRAME.html#ae584de8d6df60a7458abc8a4bee1d8a3", null ],
    [ "mode_context", "structMB__MODE__INFO__EXT__FRAME.html#ab07532ee60503635fded8dbde66f50f3", null ],
    [ "cb_offset", "structMB__MODE__INFO__EXT__FRAME.html#a07feda8d681fd3cd26db686a9fb6d90d", null ]
];
var structMB__RD__INFO =
[
    [ "tx_size", "structMB__RD__INFO.html#a270210ea83f2d3a0a4b145ae5132ac61", null ],
    [ "inter_tx_size", "structMB__RD__INFO.html#ac5cba34cc357674cdf69384eaaefbd6b", null ],
    [ "blk_skip", "structMB__RD__INFO.html#a097789d8450d8a321d1dafb0d18ca5ac", null ],
    [ "tx_type_map", "structMB__RD__INFO.html#a2a4d37d1fbcdff7da3e2bce0f265d2c9", null ],
    [ "rd_stats", "structMB__RD__INFO.html#a94354104e2722964184ca29c43576baf", null ],
    [ "hash_value", "structMB__RD__INFO.html#a3dea9a590a8dcdd6e0c25d590d160115", null ]
];
var structMotionVectorSearchParams =
[
    [ "max_mv_magnitude", "structMotionVectorSearchParams.html#a4de1a057aafec3df2fe5fde174ded842", null ],
    [ "mv_step_param", "structMotionVectorSearchParams.html#ab65dca777bec3562d3eaf0c44d8f93ba", null ],
    [ "find_fractional_mv_step", "structMotionVectorSearchParams.html#aa20141b4917fffeede698ff3bc3cfc42", null ],
    [ "search_site_cfg", "structMotionVectorSearchParams.html#addf9d3eccefa816e1c730bc1c1165b0b", null ]
];
var structMultiThreadInfo =
[
    [ "num_workers", "structMultiThreadInfo.html#a6a9afb33f804f3d05a95c2c6293876b4", null ],
    [ "num_mod_workers", "structMultiThreadInfo.html#a4cfb092072ea63dba9687b7c01710b91", null ],
    [ "workers", "structMultiThreadInfo.html#a8cb3f9e110b3a6da79df5a6511fad62c", null ],
    [ "tile_thr_data", "structMultiThreadInfo.html#a2b42428a58f2156b1de62ce86433f8fc", null ],
    [ "row_mt_enabled", "structMultiThreadInfo.html#aa36d5dc7aedc2878868367b5855f6882", null ],
    [ "pack_bs_mt_enabled", "structMultiThreadInfo.html#aa01c72ca6b37180ff6463ccf4d97c004", null ],
    [ "enc_row_mt", "structMultiThreadInfo.html#a443b0d3a75a31c67a5b75a4b11b9f2fb", null ],
    [ "tpl_row_mt", "structMultiThreadInfo.html#a38989d63e9269a85134d00852df10c94", null ],
    [ "lf_row_sync", "structMultiThreadInfo.html#a4bf3911993b18169add61be10b6316cf", null ],
    [ "lr_row_sync", "structMultiThreadInfo.html#a26e9e2c6fff05ed599cca17ad531cf33", null ],
    [ "pack_bs_sync", "structMultiThreadInfo.html#a3f61c23bcf10b729b004cdd659de716f", null ],
    [ "gm_sync", "structMultiThreadInfo.html#ad464c86982e3a1b95043563537dc352c", null ],
    [ "tf_sync", "structMultiThreadInfo.html#ac9e21840e1d3d46bb90468002563a6d1", null ],
    [ "cdef_sync", "structMultiThreadInfo.html#a4c5a8262265dc49360e838ca94774482", null ],
    [ "cdef_worker", "structMultiThreadInfo.html#a1d6db43c99a605ffc0ef85bf473326b9", null ],
    [ "restore_state_buf", "structMultiThreadInfo.html#a1537ad4651a2468ff32830ff7c27b603", null ],
    [ "pipeline_lpf_mt_with_enc", "structMultiThreadInfo.html#a8bb3e266b979cf08d9024d9763ea1c59", null ]
];
var structOBMCBuffer =
[
    [ "wsrc", "structOBMCBuffer.html#a3fdfb37ad334b998b6f402e882aa67fe", null ],
    [ "mask", "structOBMCBuffer.html#aaf59f9ba7c144349a9695816816f3061", null ],
    [ "above_pred", "structOBMCBuffer.html#ad9b67a03a28826a626dc92e13c6c2c79", null ],
    [ "left_pred", "structOBMCBuffer.html#a2b40831af5be195b40236e8730e09bc3", null ]
];
var structPALETTE__BUFFER =
[
    [ "best_palette_color_map", "structPALETTE__BUFFER.html#a5e1756d5ed3656de519815acc7febd71", null ],
    [ "kmeans_data_buf", "structPALETTE__BUFFER.html#a1c60df85535af65422300a0012c90e59", null ]
];
var structPartitionCfg =
[
    [ "enable_rect_partitions", "structPartitionCfg.html#a0f9007ce288ae9ffcdfd77bd613ba2c8", null ],
    [ "enable_ab_partitions", "structPartitionCfg.html#aeb45eeb5a04edd0905e6b282ed7658c0", null ],
    [ "enable_1to4_partitions", "structPartitionCfg.html#a39a1b0016386309c2137eeb37dd9e0e6", null ],
    [ "min_partition_size", "structPartitionCfg.html#af359af222f9c2e0d9aea5e490977a459", null ],
    [ "max_partition_size", "structPartitionCfg.html#a5c7ce817f3cca6d70c0e94aba171922d", null ]
];
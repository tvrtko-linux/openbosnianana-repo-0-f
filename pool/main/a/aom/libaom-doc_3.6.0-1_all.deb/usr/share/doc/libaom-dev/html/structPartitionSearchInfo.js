var structPartitionSearchInfo =
[
    [ "quad_tree_idx", "structPartitionSearchInfo.html#aea112761e4ed10296179a2b6c9c9511c", null ],
    [ "cnn_output_valid", "structPartitionSearchInfo.html#a5b92846b6a3fdb3c4bce089abbe11939", null ],
    [ "cnn_buffer", "structPartitionSearchInfo.html#a03feb51af5b1c374f0e7987930492cda", null ],
    [ "log_q", "structPartitionSearchInfo.html#acc860fffb0304f4414b23de78d400aac", null ],
    [ "variance_low", "structPartitionSearchInfo.html#a37f5ada12e7edcb033d447d66711a4da", null ]
];
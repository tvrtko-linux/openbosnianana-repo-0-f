var structPrimaryMultiThreadInfo =
[
    [ "num_workers", "structPrimaryMultiThreadInfo.html#a822426b6d5ca069c0669ee257ae5130a", null ],
    [ "num_mod_workers", "structPrimaryMultiThreadInfo.html#adc8861100130563962912158a36aca49", null ],
    [ "workers", "structPrimaryMultiThreadInfo.html#a882d41d6bea0b7ede21b66619867d519", null ],
    [ "tile_thr_data", "structPrimaryMultiThreadInfo.html#a6494f42ca4102a605f2918a304258d69", null ],
    [ "cdef_worker", "structPrimaryMultiThreadInfo.html#a649d4b8472abb57bc3e63dd1500ccc3e", null ],
    [ "p_workers", "structPrimaryMultiThreadInfo.html#a892dc2ef5c9c196a09c5421d3711f66c", null ],
    [ "p_num_workers", "structPrimaryMultiThreadInfo.html#ab4afd254b42199d2aa7019c6755a5e03", null ]
];
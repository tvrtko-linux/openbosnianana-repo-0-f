var structPruneInfoFromTpl =
[
    [ "best_inter_cost", "structPruneInfoFromTpl.html#a6757f3879e1905c031b860f002734ec8", null ],
    [ "ref_inter_cost", "structPruneInfoFromTpl.html#aedb66f540555692d10559f6371807ff3", null ]
];
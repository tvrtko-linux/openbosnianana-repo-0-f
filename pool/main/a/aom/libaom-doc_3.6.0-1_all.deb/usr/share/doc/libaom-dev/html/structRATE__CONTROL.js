var structRATE__CONTROL =
[
    [ "base_frame_target", "structRATE__CONTROL.html#a416adf8aa3d7dbf976e0b6ef8be8d8e7", null ],
    [ "this_frame_target", "structRATE__CONTROL.html#a2ce9bf5c6c543d22bd009ae1117f4cbd", null ],
    [ "projected_frame_size", "structRATE__CONTROL.html#a49fe57f348659fdadc8042000c526f34", null ],
    [ "coefficient_size", "structRATE__CONTROL.html#acedb2db37691fc134744018f840ae84e", null ],
    [ "sb64_target_rate", "structRATE__CONTROL.html#aa2e85ede8e0ac11dd729f8d2e2d9c939", null ],
    [ "frames_since_golden", "structRATE__CONTROL.html#aea83a4e26d11dddaa63b948152777095", null ],
    [ "frames_till_gf_update_due", "structRATE__CONTROL.html#af7c89118b237a443da307366e8cfdb18", null ],
    [ "intervals_till_gf_calculate_due", "structRATE__CONTROL.html#a1b3f84c2664208d21703b5af652a95f6", null ],
    [ "frames_to_key", "structRATE__CONTROL.html#a2cf43504ee8a3e7570fe477f1f09ebe1", null ],
    [ "worst_quality", "structRATE__CONTROL.html#a863b80282b28c697c5299d24ed8c66d1", null ],
    [ "best_quality", "structRATE__CONTROL.html#a02ea508e423ac0ccfac56ac1941cc7b8", null ],
    [ "active_worst_quality", "structRATE__CONTROL.html#ad3be5f1d1ec116a8d661e915f5ca3f53", null ]
];
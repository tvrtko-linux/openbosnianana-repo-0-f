var structRateControlCfg =
[
    [ "starting_buffer_level_ms", "structRateControlCfg.html#ad68d50f3297bc20648f9875ae3804fe4", null ],
    [ "optimal_buffer_level_ms", "structRateControlCfg.html#ae85fef9531436afe2e0cff3534ca5aa2", null ],
    [ "maximum_buffer_size_ms", "structRateControlCfg.html#a84b4d4494d2f12a98fd4ce19c0705cf4", null ],
    [ "target_bandwidth", "structRateControlCfg.html#ae4e7c69ac7953cd0b3a163c78ab63b10", null ],
    [ "vbr_corpus_complexity_lap", "structRateControlCfg.html#aad5f6c5460396bac864104d259c881ab", null ],
    [ "max_intra_bitrate_pct", "structRateControlCfg.html#a3ac7cb9b5858e0ddde6daa99b266f31f", null ],
    [ "max_inter_bitrate_pct", "structRateControlCfg.html#ad16374c14dc126a48203218eb37e4ec9", null ],
    [ "gf_cbr_boost_pct", "structRateControlCfg.html#ac23a9405f6062c40865f8d663f0d9988", null ],
    [ "min_cr", "structRateControlCfg.html#ab72d969fbe8c5d5bf12a28a5ce65a75d", null ],
    [ "drop_frames_water_mark", "structRateControlCfg.html#a52f9ec528bd34cb6a47dd35ad84e684f", null ],
    [ "under_shoot_pct", "structRateControlCfg.html#ae47c57035f349625892846ecaa963f7a", null ],
    [ "over_shoot_pct", "structRateControlCfg.html#a2a4a63fa0ffab9e07d22dc6358e82aeb", null ],
    [ "worst_allowed_q", "structRateControlCfg.html#a1a63e4cdfb828d565bd5b6186dba06f5", null ],
    [ "best_allowed_q", "structRateControlCfg.html#ae14bcf62c04a99909d185c14dffdfbba", null ],
    [ "cq_level", "structRateControlCfg.html#af6b5df24567a9e027c89453d0ad69c8e", null ],
    [ "mode", "structRateControlCfg.html#ace800761e330b4232c9de58c0999b32e", null ],
    [ "vbrbias", "structRateControlCfg.html#ac0a1ea76036611bbb69b7266f8d818f5", null ],
    [ "vbrmin_section", "structRateControlCfg.html#ac5449b521f590df024dee3d084a487a0", null ],
    [ "vbrmax_section", "structRateControlCfg.html#a59b9ae349f79f214c92aa8592831d146", null ]
];
var structRefFrameDistanceInfo =
[
    [ "ref_relative_dist", "structRefFrameDistanceInfo.html#a53603328aeae19b47fe58a1c60815c5e", null ],
    [ "nearest_past_ref", "structRefFrameDistanceInfo.html#a082be36edbce04471e4f23dd608ae7af", null ],
    [ "nearest_future_ref", "structRefFrameDistanceInfo.html#ad397d77c07284ccfd9abe68fbceed020", null ]
];
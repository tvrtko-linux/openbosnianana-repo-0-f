var structRefreshFrameInfo =
[
    [ "golden_frame", "structRefreshFrameInfo.html#abda267747d6fc4a0be09eaa6b43f636c", null ],
    [ "bwd_ref_frame", "structRefreshFrameInfo.html#aad657d56c2e3c9cb3f54a3aa9c9e1ea2", null ],
    [ "alt_ref_frame", "structRefreshFrameInfo.html#af43c353c062e7a0046486cce3d82fa5f", null ]
];
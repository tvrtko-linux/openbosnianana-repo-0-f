var structResizeCfg =
[
    [ "resize_mode", "structResizeCfg.html#adb8460d8997975048cd64a44b37fb1ea", null ],
    [ "resize_scale_denominator", "structResizeCfg.html#a648d5bb8effb5ece1b5e7abcd4f2a197", null ],
    [ "resize_kf_scale_denominator", "structResizeCfg.html#a88f92c8f849f948f7794ba230ed52a25", null ]
];
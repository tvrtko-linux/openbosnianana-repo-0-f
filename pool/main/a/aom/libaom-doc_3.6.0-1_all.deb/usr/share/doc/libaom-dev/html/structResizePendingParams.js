var structResizePendingParams =
[
    [ "width", "structResizePendingParams.html#a32ee46e7d8f1b44501c388351cbb93c1", null ],
    [ "height", "structResizePendingParams.html#a51e85984e709e2268fc76acc7505dcd1", null ]
];
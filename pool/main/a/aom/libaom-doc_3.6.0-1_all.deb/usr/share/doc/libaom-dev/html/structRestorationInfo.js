var structRestorationInfo =
[
    [ "frame_restoration_type", "structRestorationInfo.html#ab51ef60a545502eae4f83651d7b27e7d", null ],
    [ "restoration_unit_size", "structRestorationInfo.html#ac8390bea21b413a0dd3df43cdc56ebd8", null ],
    [ "units_per_tile", "structRestorationInfo.html#af7eddb7b02d6924bb4bd2227f397b8e7", null ],
    [ "vert_units_per_tile", "structRestorationInfo.html#a9733d8dceaf5ca8417a005a167c4894c", null ],
    [ "horz_units_per_tile", "structRestorationInfo.html#acb2295ae7750a03b7f6fc65aa6126fb3", null ],
    [ "unit_info", "structRestorationInfo.html#a6b8daa3388a9cacec495eb2d8ab88436", null ],
    [ "boundaries", "structRestorationInfo.html#a352d6b38c82cc89e1c4dcc4d6d8f07d1", null ],
    [ "optimized_lr", "structRestorationInfo.html#ac7cc27ede6885c0903e9da08ff913c79", null ]
];
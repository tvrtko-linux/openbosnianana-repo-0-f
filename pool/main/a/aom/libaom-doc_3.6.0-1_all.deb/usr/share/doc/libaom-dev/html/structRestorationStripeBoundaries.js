var structRestorationStripeBoundaries =
[
    [ "stripe_boundary_above", "structRestorationStripeBoundaries.html#a9f78dc5baeba654922d5f95712a3253f", null ],
    [ "stripe_boundary_below", "structRestorationStripeBoundaries.html#af177d903974ae93eb18f63031dd54e4b", null ],
    [ "stripe_boundary_stride", "structRestorationStripeBoundaries.html#a0ca68efb4bcd84c9424965bb9ccfa3d7", null ],
    [ "stripe_boundary_size", "structRestorationStripeBoundaries.html#a6e6a1b28994e51bec5cacb29c1b29324", null ]
];
var structRestorationUnitInfo =
[
    [ "restoration_type", "structRestorationUnitInfo.html#a9ba41b1ead7ccc8883316017471f05e8", null ],
    [ "wiener_info", "structRestorationUnitInfo.html#a73da35da69600403433e36e2ec21e274", null ],
    [ "sgrproj_info", "structRestorationUnitInfo.html#ac0f1e8bf804a5db5a6b38027e9bdb4f4", null ]
];
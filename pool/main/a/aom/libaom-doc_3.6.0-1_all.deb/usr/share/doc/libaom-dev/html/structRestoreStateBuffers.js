var structRestoreStateBuffers =
[
    [ "cdef_srcbuf", "structRestoreStateBuffers.html#af114c9cedf3049f5a4c5bd0a311fdbbc", null ],
    [ "cdef_colbuf", "structRestoreStateBuffers.html#aadb2d9d48721ca9260d00f1d23ec2def", null ],
    [ "rst_tmpbuf", "structRestoreStateBuffers.html#a1f8ba72c9c56b926e854c82b4aa929df", null ],
    [ "rlbs", "structRestoreStateBuffers.html#aa709b1ba3f98fc970f3386a3518ea824", null ]
];
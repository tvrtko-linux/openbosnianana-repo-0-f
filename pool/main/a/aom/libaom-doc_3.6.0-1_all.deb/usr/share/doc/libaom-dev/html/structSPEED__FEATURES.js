var structSPEED__FEATURES =
[
    [ "hl_sf", "structSPEED__FEATURES.html#acef5f36678cfa7ba395dd4c08ab686cf", null ],
    [ "fp_sf", "structSPEED__FEATURES.html#a9045ad13714e68a417764d4f6ad59f07", null ],
    [ "tpl_sf", "structSPEED__FEATURES.html#a052d7f783e319c7e8c861fdfa1fe0921", null ],
    [ "gm_sf", "structSPEED__FEATURES.html#a898da304de833c82e361cc8d36d22427", null ],
    [ "part_sf", "structSPEED__FEATURES.html#a71966051b9ea3000ed7029eb56613466", null ],
    [ "mv_sf", "structSPEED__FEATURES.html#a027c787152c7d4e6689384e440c556a3", null ],
    [ "inter_sf", "structSPEED__FEATURES.html#a566a10c850b8f4e0802ad586d9615034", null ],
    [ "interp_sf", "structSPEED__FEATURES.html#a8bea7292a388e81be7d0581afecc845a", null ],
    [ "intra_sf", "structSPEED__FEATURES.html#a93c42db4fbfe6f191ed5c1c50a7c702d", null ],
    [ "tx_sf", "structSPEED__FEATURES.html#a52da3c0679eb53e3da1df22fa32e93df", null ],
    [ "rd_sf", "structSPEED__FEATURES.html#a5969cf37280061a09cb51c955990355a", null ],
    [ "winner_mode_sf", "structSPEED__FEATURES.html#a97ce09be01c99f120eb55513367457ee", null ],
    [ "lpf_sf", "structSPEED__FEATURES.html#a489c3a3b71fb8b79cbdc6d5a6c8f4057", null ],
    [ "rt_sf", "structSPEED__FEATURES.html#aa39b8f3e80c80b394414625a1ff0376e", null ]
];
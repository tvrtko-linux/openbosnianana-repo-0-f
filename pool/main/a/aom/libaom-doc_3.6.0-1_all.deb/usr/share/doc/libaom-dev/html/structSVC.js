var structSVC =
[
    [ "layer_context", "structSVC.html#aa3e631ea2ce977be0e961d39edcb6f38", null ],
    [ "num_allocated_layers", "structSVC.html#a2493ea615aa6f28be5155b46447c8eee", null ],
    [ "downsample_filter_type", "structSVC.html#aad10b3ea5e0a29a90c4f8c2f733ae019", null ],
    [ "downsample_filter_phase", "structSVC.html#ab4e774da4a9f8763447f5e9ea894dbdc", null ],
    [ "force_zero_mode_spatial_ref", "structSVC.html#a6575ed590fb285550e6624cf19835990", null ]
];
var structSgrprojInfo =
[
    [ "ep", "structSgrprojInfo.html#a403c814385e826b519ec252acf8db85a", null ],
    [ "xqd", "structSgrprojInfo.html#a654c647c017614714b2ed760ed5418b3", null ]
];
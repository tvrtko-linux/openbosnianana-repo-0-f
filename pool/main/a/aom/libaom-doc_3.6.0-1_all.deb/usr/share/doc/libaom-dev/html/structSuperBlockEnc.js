var structSuperBlockEnc =
[
    [ "min_partition_size", "structSuperBlockEnc.html#a11ec5173d2e6f78607276a6770fe180f", null ],
    [ "max_partition_size", "structSuperBlockEnc.html#a9685e81f8473b97e9ad9c914636c3491", null ],
    [ "tpl_data_count", "structSuperBlockEnc.html#ae6343d8d5c683e41892bc7fc2fc1c889", null ],
    [ "tpl_inter_cost", "structSuperBlockEnc.html#a506e7a810f22ac941b5db9c9aadfed6d", null ],
    [ "tpl_intra_cost", "structSuperBlockEnc.html#a63edc5d6736244f8c76b359ea5777693", null ],
    [ "tpl_mv", "structSuperBlockEnc.html#abb0a2583a3e84c9c08dcdfc7928a6fde", null ],
    [ "tpl_stride", "structSuperBlockEnc.html#ac05e1c9eb1bd5a0b90d9b56437c697a7", null ]
];
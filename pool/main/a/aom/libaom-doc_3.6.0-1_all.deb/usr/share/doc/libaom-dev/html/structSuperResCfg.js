var structSuperResCfg =
[
    [ "superres_qthresh", "structSuperResCfg.html#afccf20ef8083bd5f6aa1220828c98485", null ],
    [ "superres_kf_qthresh", "structSuperResCfg.html#a6d9367dd91daec7147822da774dec029", null ],
    [ "superres_scale_denominator", "structSuperResCfg.html#ad6b91942d00f7594aae2f026ccdca5d0", null ],
    [ "superres_kf_scale_denominator", "structSuperResCfg.html#a2c8bec3f18e60f3febe3dc96ccb67b00", null ],
    [ "superres_mode", "structSuperResCfg.html#a31680bac7b2797e8fd61404f2327c207", null ],
    [ "enable_superres", "structSuperResCfg.html#ac9d438b37c34ea4935f334b93f0f25a2", null ]
];
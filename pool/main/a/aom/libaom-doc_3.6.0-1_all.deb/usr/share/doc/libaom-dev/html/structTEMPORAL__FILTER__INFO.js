var structTEMPORAL__FILTER__INFO =
[
    [ "is_temporal_filter_on", "structTEMPORAL__FILTER__INFO.html#abd10edc97677f12b9fe94aba9fde5a40", null ],
    [ "tf_buf", "structTEMPORAL__FILTER__INFO.html#a4820bf13b930aede42e71d0b48ac9837", null ],
    [ "tf_buf_second_arf", "structTEMPORAL__FILTER__INFO.html#aeccc2b0775d30edb087f5842d16a6cc7", null ],
    [ "frame_diff", "structTEMPORAL__FILTER__INFO.html#a82efe379eda812a3eb14b68633661c99", null ],
    [ "tf_buf_gf_index", "structTEMPORAL__FILTER__INFO.html#a670d21de5c6f34e88e668b704edb7c50", null ],
    [ "tf_buf_display_index_offset", "structTEMPORAL__FILTER__INFO.html#a39e0efa000a1a5132833e82d3c186a2e", null ],
    [ "tf_buf_valid", "structTEMPORAL__FILTER__INFO.html#ac38f336c49ab21049203a7af816e5839", null ]
];
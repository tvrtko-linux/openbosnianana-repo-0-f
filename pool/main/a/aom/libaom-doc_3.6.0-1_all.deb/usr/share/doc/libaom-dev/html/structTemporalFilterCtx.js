var structTemporalFilterCtx =
[
    [ "frames", "structTemporalFilterCtx.html#a82da7e78b479e140e64c0ac795dcd2a1", null ],
    [ "num_frames", "structTemporalFilterCtx.html#a4c3b2eccd0df1fce9eca33f3cf4c2272", null ],
    [ "output_frame", "structTemporalFilterCtx.html#a2ad087c9734377a53f2fb7013a67cfde", null ],
    [ "filter_frame_idx", "structTemporalFilterCtx.html#a7d32694faa138c67b396549281e1ea83", null ],
    [ "compute_frame_diff", "structTemporalFilterCtx.html#a626366292ad94c3216ec00aa34e5d3dc", null ],
    [ "sf", "structTemporalFilterCtx.html#a1774b0136e710c99f9f5c1c8a9cb452f", null ],
    [ "noise_levels", "structTemporalFilterCtx.html#a6e6a1cd163ccc2b6ac59e8ee0f619620", null ],
    [ "num_pels", "structTemporalFilterCtx.html#a4749a95d8b2540a178dbc1934f0711a0", null ],
    [ "mb_rows", "structTemporalFilterCtx.html#a647647a5ff6835621f505c6ec5cf45e6", null ],
    [ "mb_cols", "structTemporalFilterCtx.html#a648b6cd56d5d6754b5084412a5566ab7", null ],
    [ "is_highbitdepth", "structTemporalFilterCtx.html#a76bd2f43313149f61a73c4ea25f2d7fe", null ],
    [ "q_factor", "structTemporalFilterCtx.html#a2e489be8476011aca15384ca918c2988", null ]
];
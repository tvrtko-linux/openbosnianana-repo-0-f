var structTimeStamps =
[
    [ "prev_ts_start", "structTimeStamps.html#a5f25644e4435546213094069ea8b7712", null ],
    [ "prev_ts_end", "structTimeStamps.html#afcf791ba21e3ca6e9bb90f4bd7af0f39", null ],
    [ "first_ts_start", "structTimeStamps.html#ab33c836d72be08a4bd420e69e662e569", null ]
];
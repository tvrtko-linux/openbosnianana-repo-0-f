var structTplParams =
[
    [ "ready", "structTplParams.html#a20988b1a967a3fbbf613712295d7d29e", null ],
    [ "tpl_stats_block_mis_log2", "structTplParams.html#abb396c56b98bfa5987f2e438df7eeb9d", null ],
    [ "tpl_bsize_1d", "structTplParams.html#a563c55068499c5d22446b65a6cf2708c", null ],
    [ "tpl_stats_buffer", "structTplParams.html#a3e7a639e1352ae358bb44862744e7383", null ],
    [ "tpl_stats_pool", "structTplParams.html#a9e99b9e69cc551d8cd621aaf1cf19417", null ],
    [ "txfm_stats_list", "structTplParams.html#aa2cd4a102360f2c92a16d4bba850a985", null ],
    [ "tpl_rec_pool", "structTplParams.html#aa7309ac0c8b84f0dd419a8ecc393ebad", null ],
    [ "tpl_frame", "structTplParams.html#a604d1a4f0d8416a6f9f2c925108a1af2", null ],
    [ "sf", "structTplParams.html#a1e670d20221cb9797f29aaeae6e8ac10", null ],
    [ "frame_idx", "structTplParams.html#ac13f2daba693ab17cd2fc32aa1564d8b", null ],
    [ "src_ref_frame", "structTplParams.html#a0df19e4c6859e886d653eafb1deb6fc5", null ],
    [ "ref_frame", "structTplParams.html#afbb8768ff7a4e0d87dc72fa0122a6ec4", null ],
    [ "tpl_mt_sync", "structTplParams.html#a5c1a2778d685c998fa7045b00070c0b9", null ],
    [ "border_in_pixels", "structTplParams.html#a710006b5c6067d97bd8768f65982146b", null ]
];
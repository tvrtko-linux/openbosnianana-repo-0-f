var structTxfmSearchInfo =
[
    [ "skip_txfm", "structTxfmSearchInfo.html#ae01009056bc45bbed512d42436c951a9", null ],
    [ "blk_skip", "structTxfmSearchInfo.html#a9a35a9f03205ad7eba4e401b8aa815c7", null ],
    [ "tx_type_map_", "structTxfmSearchInfo.html#ada5ddf21369150234bbb3074523a8769", null ],
    [ "mb_rd_record", "structTxfmSearchInfo.html#aa7c9c1401ec3193a2080710034a8167c", null ],
    [ "txb_split_count", "structTxfmSearchInfo.html#a689915d02103c193a5f0c2d75d17c979", null ]
];
var structTxfmSearchParams =
[
    [ "use_default_intra_tx_type", "structTxfmSearchParams.html#a2a670398ff20a845fafe0e387102ed7e", null ],
    [ "default_inter_tx_type_prob_thresh", "structTxfmSearchParams.html#aaebeafdec9c037c3f2f25b3d71016b91", null ],
    [ "prune_2d_txfm_mode", "structTxfmSearchParams.html#a3585052421cfb381fa37d64d3ea43d23", null ],
    [ "coeff_opt_thresholds", "structTxfmSearchParams.html#a6b1c633a765b3dba0d713c45ae7b51f6", null ],
    [ "tx_domain_dist_threshold", "structTxfmSearchParams.html#acfb369ca7bb53e6e803d857913278a67", null ],
    [ "tx_size_search_method", "structTxfmSearchParams.html#aaaa0c520fc2c0903f979b71c6e84e760", null ],
    [ "use_transform_domain_distortion", "structTxfmSearchParams.html#afdabb2b5e9a7098bb16b2efb82e26e28", null ],
    [ "skip_txfm_level", "structTxfmSearchParams.html#ae943654f70826e70a3b4fa40b2286666", null ],
    [ "tx_mode_search_type", "structTxfmSearchParams.html#aa6c96481c00edeb80b13a646f10163c1", null ],
    [ "predict_dc_level", "structTxfmSearchParams.html#abff3753cd270ccbc514fec7d980acd34", null ],
    [ "use_qm_dist_metric", "structTxfmSearchParams.html#a210a81de10bb50583102176c150c49a2", null ],
    [ "mode_eval_type", "structTxfmSearchParams.html#a1617eece5f0347a7e30f2664521b5a01", null ],
    [ "nn_prune_depths_for_intra_tx", "structTxfmSearchParams.html#afa3da46e103ec60cce0e96e8b31dccec", null ],
    [ "enable_nn_prune_intra_tx_depths", "structTxfmSearchParams.html#a4fb7b33cff2f7a88b5efa70102493d90", null ]
];
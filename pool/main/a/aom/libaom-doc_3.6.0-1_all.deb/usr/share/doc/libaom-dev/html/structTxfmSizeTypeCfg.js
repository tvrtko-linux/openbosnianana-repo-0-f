var structTxfmSizeTypeCfg =
[
    [ "enable_tx64", "structTxfmSizeTypeCfg.html#a0ba9edc5f15dc45d50c18f7d0918a505", null ],
    [ "enable_flip_idtx", "structTxfmSizeTypeCfg.html#a7d57afcd15c2fe48b3ec94271d5e16d2", null ],
    [ "enable_rect_tx", "structTxfmSizeTypeCfg.html#abadcc764ae21ea9a97f519161bb8bb1f", null ],
    [ "reduced_tx_type_set", "structTxfmSizeTypeCfg.html#ae83b6b71ea05a2b73d128d7b6e5d467b", null ],
    [ "use_intra_dct_only", "structTxfmSizeTypeCfg.html#ab6c7ea92d2b7edc4ac202032dba22e24", null ],
    [ "use_inter_dct_only", "structTxfmSizeTypeCfg.html#a674ac7eff399a947d6df840b5663aaae", null ],
    [ "use_intra_default_tx_only", "structTxfmSizeTypeCfg.html#a8da169615ca045de1cafd4fe36b7f4df", null ],
    [ "enable_tx_size_search", "structTxfmSizeTypeCfg.html#ae869c067d3c304a9880ffb9b031b9439", null ]
];
var structVarBasedPartitionInfo =
[
    [ "thresholds", "structVarBasedPartitionInfo.html#a5dead67f23333009d6b5cc8c24aa89ab", null ],
    [ "threshold_minmax", "structVarBasedPartitionInfo.html#af24b4f6e15d8d9e9ee597dfed6b637fc", null ]
];
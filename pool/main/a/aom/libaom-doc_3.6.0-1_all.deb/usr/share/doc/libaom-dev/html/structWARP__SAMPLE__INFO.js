var structWARP__SAMPLE__INFO =
[
    [ "num", "structWARP__SAMPLE__INFO.html#ae06cc57c63d75c45dad87e4e63493153", null ],
    [ "pts", "structWARP__SAMPLE__INFO.html#acb99285937a571d34b4fc4ac5f4f8cc6", null ],
    [ "pts_inref", "structWARP__SAMPLE__INFO.html#afe9f7bd4ee7f4fc37a644951ea8a8c1c", null ]
];
var structWienerInfo =
[
    [ "vfilter", "structWienerInfo.html#aee73ec6f222a3d7f7b34570d1d7f66e4", null ],
    [ "hfilter", "structWienerInfo.html#a5b0f8eea67810824b378a44d88161dc4", null ]
];
var structWinnerModeParams =
[
    [ "coeff_opt_thresholds", "structWinnerModeParams.html#aa35aaf67064abafd716619304a29f1c3", null ],
    [ "tx_size_search_methods", "structWinnerModeParams.html#a9328b4481846ae0922f3a34bff64317c", null ],
    [ "use_transform_domain_distortion", "structWinnerModeParams.html#a59294a686151cc1f20fc3e62eacb9b7d", null ],
    [ "tx_domain_dist_threshold", "structWinnerModeParams.html#aa958e7346df1c5f9ac5cdcc0dd4961c3", null ],
    [ "skip_txfm_level", "structWinnerModeParams.html#a972dfef5620ffd9feb9e25ff68c1ce7d", null ],
    [ "predict_dc_level", "structWinnerModeParams.html#acd6a73b26dfebf998c72a6b62ba6a1e6", null ]
];
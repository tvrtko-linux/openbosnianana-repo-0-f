var structWinnerModeStats =
[
    [ "mbmi", "structWinnerModeStats.html#ab9d35193247d7ef6e477df30e4380dae", null ],
    [ "rd_cost", "structWinnerModeStats.html#ab195adf772acac8f021ca0ec79d11886", null ],
    [ "rd", "structWinnerModeStats.html#ad97a8cc811dd59640e3b2075c9e71c7d", null ],
    [ "rate_y", "structWinnerModeStats.html#a08623dbd506d8786c49161ab256b9beb", null ],
    [ "rate_uv", "structWinnerModeStats.html#acaa5f5f567248576d9b843afca045eb3", null ],
    [ "color_index_map", "structWinnerModeStats.html#a8fc38db2a0749f5abe424fc794a5b160", null ],
    [ "mode_index", "structWinnerModeStats.html#abfc5ceaa5576f7387b4f5aebb9d3629e", null ]
];
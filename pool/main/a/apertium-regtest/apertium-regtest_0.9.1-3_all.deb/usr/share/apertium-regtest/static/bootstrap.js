/* Not needed for cmdline use, but can be fetched from https://cdn.jsdelivr.net/npm/bootstrap@5.1/dist/js/bootstrap.min.js */

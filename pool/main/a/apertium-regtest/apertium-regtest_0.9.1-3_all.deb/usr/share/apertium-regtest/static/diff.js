/* Not needed for cmdline use, but can be fetched from https://cdn.jsdelivr.net/npm/diff@4.0/dist/diff.min.js */

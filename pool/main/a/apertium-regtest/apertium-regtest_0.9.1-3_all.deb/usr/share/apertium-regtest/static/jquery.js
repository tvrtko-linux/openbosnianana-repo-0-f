/* Not needed for cmdline use, but can be fetched from https://cdn.jsdelivr.net/npm/jquery@3.6/dist/jquery.min.js */

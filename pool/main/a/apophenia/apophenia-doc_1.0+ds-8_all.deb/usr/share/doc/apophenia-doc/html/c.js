var c =
[
    [ "Errors, logging, debugging and stopping", "c.html#debugging", null ],
    [ "Verbosity level and logging", "c.html#verbsec", null ],
    [ "Stopping", "c.html#Stopping", null ],
    [ "Legible output", "c.html#Legi", null ],
    [ "About SQL, the syntax for querying databases", "c.html#sqlsec", null ],
    [ "Threading", "c.html#threads", null ],
    [ "Designated initializers", "designated.html", null ]
];
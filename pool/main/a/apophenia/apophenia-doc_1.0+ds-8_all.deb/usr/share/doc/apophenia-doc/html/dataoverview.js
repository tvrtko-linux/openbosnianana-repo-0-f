var dataoverview =
[
    [ "Pages", "dataoverview.html#pps", null ],
    [ "Functions for using apop_data sets", "dataoverview.html#datafns", [
      [ "Reading from text files", "dataoverview.html#readin", null ]
    ] ],
    [ "Alloc/free", "dataoverview.html#datalloc", null ],
    [ "Using views", "dataoverview.html#gslviews", null ],
    [ "Set/get", "dataoverview.html#data_set_get", null ],
    [ "Map/apply", "dataoverview.html#mapply", null ],
    [ "Basic Math", "dataoverview.html#matrixmathtwo", null ],
    [ "Matrix math", "dataoverview.html#matrixmath", null ],
    [ "Summary stats", "dataoverview.html#sumstats", null ],
    [ "Moments", "dataoverview.html#moments", null ],
    [ "Conversion among types", "dataoverview.html#convsec", null ],
    [ "Name handling", "dataoverview.html#names", null ],
    [ "Text data", "dataoverview.html#textsec", [
      [ "Generating factors", "dataoverview.html#fact", null ]
    ] ],
    [ "Input text file formatting", "text_format.html", null ]
];
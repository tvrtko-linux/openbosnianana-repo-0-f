var modelsec =
[
    [ "Parameterizing or initializing a model", "modelsec.html#modelparameterization", null ],
    [ "Filtering & updating", "modelsec.html#transformsec", null ],
    [ "Model methods", "modelsec.html#mathmethods", null ],
    [ "Settings groups", "modelsec.html#modelsettings", null ],
    [ "Data format for regression-type models", "dataones.html", null ]
];
var outline =
[
    [ "Data sets", "dataoverview.html", "dataoverview" ],
    [ "Databases", "dbs.html", [
      [ "Extracting data from the database", "dbs.html#edftd", null ],
      [ "Writing data to the database", "dbs.html#wdttd", null ],
      [ "Command-line utilities", "dbs.html#cmdline", null ],
      [ "Database moments (plus pow()!)", "dbs.html#db_moments", null ]
    ] ],
    [ "Models", "modelsec.html", "modelsec" ],
    [ "Tests & diagnostics", "testpage.html", null ],
    [ "Optimization", "maxipage.html", [
      [ "Setting Constraints", "maxipage.html#constr", null ],
      [ "Notes on simulated annealing", "maxipage.html#simanneal", null ],
      [ "Useful functions", "maxipage.html#mlfns", null ]
    ] ],
    [ "Assorted", "moreasst.html", null ]
];
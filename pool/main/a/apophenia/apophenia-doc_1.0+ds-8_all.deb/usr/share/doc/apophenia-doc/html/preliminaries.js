var preliminaries =
[
    [ "A quick overview", "gentle.html", [
      [ "apop_data", "gentle.html#apop_data", null ],
      [ "apop_model", "gentle.html#gentle_model", null ],
      [ "Conclusion", "gentle.html#gentle_end", null ]
    ] ],
    [ "Setting up", "setup.html", "setup" ],
    [ "Some examples", "eg.html", null ],
    [ "References and extensions", "refstatusext.html", "refstatusext" ]
];
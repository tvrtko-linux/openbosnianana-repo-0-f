var refstatusext =
[
    [ "The book version", "refstatusext.html#mwd", null ],
    [ "How do I write extensions?", "refstatusext.html#ext", null ],
    [ "Further references", "refstatusext.html#links", null ],
    [ "C, SQL and coding utilities", "c.html", "c" ]
];
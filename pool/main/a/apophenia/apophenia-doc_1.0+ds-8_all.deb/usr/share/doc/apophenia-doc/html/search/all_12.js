var searchData=
[
  ['verbose',['verbose',['../structapop__opts__type.html#aa76e9237ed45c77bc883b428c3217a66',1,'apop_opts_type::verbose()']]]
];

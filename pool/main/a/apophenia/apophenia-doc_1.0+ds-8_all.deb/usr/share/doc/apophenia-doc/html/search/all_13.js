var searchData=
[
  ['welcome',['Welcome',['../index.html',1,'']]],
  ['writing_20new_20models',['Writing new models',['../modeldetails.html',1,'']]],
  ['want_5fcov',['want_cov',['../structapop__lm__settings.html#a2f62fede3aec4c7fe461e8ee39c1bcff',1,'apop_lm_settings']]],
  ['want_5fexpected_5fvalue',['want_expected_value',['../structapop__lm__settings.html#ae6b8c6ca335b895ee91c182c8b9ed6e1',1,'apop_lm_settings']]],
  ['want_5fpredict_5fci',['want_predict_ci',['../structapop__loess__settings.html#a0c8cc70a4be852404cc7cf1bd54e6008',1,'apop_loess_settings']]],
  ['weights',['weights',['../structapop__mixture__settings.html#af06728d5618bb4c903e6f871b504d4e3',1,'apop_mixture_settings']]],
  ['windows',['Windows',['../windows.html',1,'setup']]]
];

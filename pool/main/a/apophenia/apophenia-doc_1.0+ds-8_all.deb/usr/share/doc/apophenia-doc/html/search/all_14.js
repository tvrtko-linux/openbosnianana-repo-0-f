var searchData=
[
  ['xinit',['xinit',['../structapop__arms__settings.html#ac75adcea3cfe99ddc3408fffaa1dbfa6',1,'apop_arms_settings']]],
  ['xl',['xl',['../structapop__arms__settings.html#a0677eaab084f07f5f5ecc690124980be',1,'apop_arms_settings']]],
  ['xprev',['xprev',['../structapop__arms__settings.html#a040d22cb543f58ce882c2d9a7cdd4d80',1,'apop_arms_settings']]],
  ['xr',['xr',['../structapop__arms__settings.html#a845179acca7b0bdcb730cacc232bc4d0',1,'apop_arms_settings']]]
];

var searchData=
[
  ['data_20format_20for_20regression_2dtype_20models',['Data format for regression-type models',['../dataones.html',1,'modelsec']]],
  ['data_20sets',['Data sets',['../dataoverview.html',1,'outline']]],
  ['db_5fengine',['db_engine',['../structapop__opts__type.html#a9c128a43c2e53c7639ce4ddb0cef92f6',1,'apop_opts_type']]],
  ['db_5fname_5fcolumn',['db_name_column',['../structapop__opts__type.html#add132a622f0bade19869a3671e13e27c',1,'apop_opts_type']]],
  ['db_5fpass',['db_pass',['../structapop__opts__type.html#a726b1d316e036ab1971ca7aacba6b678',1,'apop_opts_type']]],
  ['db_5fuser',['db_user',['../structapop__opts__type.html#a5bdd7da78ca8e8246e9efca89fd6c2a8',1,'apop_opts_type']]],
  ['databases',['Databases',['../dbs.html',1,'outline']]],
  ['designated_20initializers',['Designated initializers',['../designated.html',1,'c']]],
  ['destroy_5fdata',['destroy_data',['../structapop__lm__settings.html#a6ecfd91942cfb4965dba9382f5947ef5',1,'apop_lm_settings']]],
  ['dim_5fcycle_5ftolerance',['dim_cycle_tolerance',['../structapop__mle__settings.html#a6a69a61ef4b6245e2f6a9063f200f44b',1,'apop_mle_settings']]],
  ['do_5fmetro',['do_metro',['../structapop__arms__settings.html#aedd47a0a4ff37b0b371d3731b1938f9c',1,'apop_arms_settings']]],
  ['draw_5fct',['draw_ct',['../structapop__dconstrain__settings.html#aa0b65f2e67e9446526415ce0692bb3ba',1,'apop_dconstrain_settings']]],
  ['draw_5findex',['draw_index',['../structapop__pmf__settings.html#a8e878300e25018c0124acf2379f52db2',1,'apop_pmf_settings']]],
  ['draws',['draws',['../structapop__cdf__settings.html#afeb0823350485ca80fe0e094e58ff8ce',1,'apop_cdf_settings']]],
  ['draws_5fmade',['draws_made',['../structapop__cdf__settings.html#a3ce6fa2317850c1118df87d4a19b110d',1,'apop_cdf_settings']]],
  ['draws_5frefcount',['draws_refcount',['../structapop__cdf__settings.html#a838ff279029752654cc7100067d57c91',1,'apop_cdf_settings']]]
];

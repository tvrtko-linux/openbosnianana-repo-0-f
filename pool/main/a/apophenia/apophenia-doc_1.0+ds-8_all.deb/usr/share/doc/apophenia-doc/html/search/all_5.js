var searchData=
[
  ['gibbs_5fchunks',['gibbs_chunks',['../structapop__mcmc__settings.html#a3b1ce772db565366881f6dadcfc79e4b',1,'apop_mcmc_settings']]],
  ['getting_20started',['Getting started',['../preliminaries.html',1,'']]]
];

var searchData=
[
  ['kernel',['kernel',['../structapop__kernel__density__settings.html#ab9eb46f59bc01dcb0715a156ba860e26',1,'apop_kernel_density_settings']]]
];

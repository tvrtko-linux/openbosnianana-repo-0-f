var searchData=
[
  ['coeff_5fstruct',['coeff_struct',['../structcoeff__struct.html',1,'']]]
];

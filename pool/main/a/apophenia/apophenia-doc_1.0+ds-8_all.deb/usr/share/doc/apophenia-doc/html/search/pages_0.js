var searchData=
[
  ['a_20quick_20overview',['A quick overview',['../gentle.html',1,'preliminaries']]],
  ['assorted',['Assorted',['../moreasst.html',1,'outline']]],
  ['an_20outline_20of_20the_20library',['An outline of the library',['../outline.html',1,'']]]
];

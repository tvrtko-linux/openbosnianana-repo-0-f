var searchData=
[
  ['c_2c_20sql_20and_20coding_20utilities',['C, SQL and coding utilities',['../c.html',1,'refstatusext']]]
];

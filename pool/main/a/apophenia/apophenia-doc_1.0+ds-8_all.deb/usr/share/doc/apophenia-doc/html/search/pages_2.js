var searchData=
[
  ['data_20format_20for_20regression_2dtype_20models',['Data format for regression-type models',['../dataones.html',1,'modelsec']]],
  ['data_20sets',['Data sets',['../dataoverview.html',1,'outline']]],
  ['databases',['Databases',['../dbs.html',1,'outline']]],
  ['designated_20initializers',['Designated initializers',['../designated.html',1,'c']]]
];

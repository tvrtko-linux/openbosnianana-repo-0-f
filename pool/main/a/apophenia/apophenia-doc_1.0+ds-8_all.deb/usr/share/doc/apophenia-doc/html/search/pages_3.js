var searchData=
[
  ['empirical_20distributions_20and_20pmfs_20_28probability_20mass_20functions_29',['Empirical distributions and PMFs (probability mass functions)',['../histosec.html',1,'']]]
];

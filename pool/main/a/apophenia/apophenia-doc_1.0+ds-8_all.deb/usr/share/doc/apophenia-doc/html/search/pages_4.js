var searchData=
[
  ['getting_20started',['Getting started',['../preliminaries.html',1,'']]]
];

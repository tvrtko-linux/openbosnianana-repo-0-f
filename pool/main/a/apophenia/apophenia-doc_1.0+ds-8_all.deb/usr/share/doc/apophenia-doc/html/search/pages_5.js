var searchData=
[
  ['input_20text_20file_20formatting',['Input text file formatting',['../text_format.html',1,'dataoverview']]]
];

var searchData=
[
  ['not_20root_3f',['Not root?',['../notroot.html',1,'setup']]]
];

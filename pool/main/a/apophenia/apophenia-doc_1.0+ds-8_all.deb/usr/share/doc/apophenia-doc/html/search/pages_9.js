var searchData=
[
  ['references_20and_20extensions',['References and extensions',['../refstatusext.html',1,'preliminaries']]]
];

var searchData=
[
  ['some_20examples',['Some examples',['../eg.html',1,'preliminaries']]],
  ['setting_20up',['Setting up',['../setup.html',1,'preliminaries']]]
];

var indexSectionsWithContent =
{
  0: "abcdeghijklmnoprstvwx",
  1: "ac",
  2: "a",
  3: "abcdghijklmnoprstvwx",
  4: "a",
  5: "ceinprs",
  6: "mp",
  7: "acdegimnorstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "enumvalues",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions",
  3: "Variables",
  4: "Enumerations",
  5: "Enumerator",
  6: "Modules",
  7: "Pages"
};


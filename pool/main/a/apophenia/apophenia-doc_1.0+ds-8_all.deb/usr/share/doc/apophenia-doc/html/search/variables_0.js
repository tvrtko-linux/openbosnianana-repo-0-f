var searchData=
[
  ['accept_5fcount',['accept_count',['../structapop__mcmc__settings.html#a4b6c42b5d194856ef14c0dfc651b8602',1,'apop_mcmc_settings']]],
  ['adapt_5ffn',['adapt_fn',['../structapop__mcmc__proposal__s.html#a1b174018f698676a3cba42dcacf28615',1,'apop_mcmc_proposal_s']]],
  ['apop_5fopts',['apop_opts',['../group__all__public.html#ga7975faa07196cf463ec261ff0ddc3ccc',1,'apop_opts():&#160;apop.h']]]
];

var searchData=
[
  ['input_5fdelimiters',['input_delimiters',['../structapop__opts__type.html#a4847a549c668ec81207663032874bd49',1,'apop_opts_type']]],
  ['input_5fdistribution',['input_distribution',['../structapop__lm__settings.html#aabc2f0277f6500c27ad4d3729e12b219',1,'apop_lm_settings']]],
  ['instruments',['instruments',['../structapop__lm__settings.html#ac15f9930a7e9d081a88d8fd389d5708f',1,'apop_lm_settings']]]
];

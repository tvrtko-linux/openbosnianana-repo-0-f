var searchData=
[
  ['max_5fiterations',['max_iterations',['../structapop__mle__settings.html#a0cebe8768a542ec220f16531c9010f5d',1,'apop_mle_settings']]],
  ['method',['method',['../structapop__mle__settings.html#af222fa7c4d6f08083d5a87ceb5b3c82f',1,'apop_mle_settings']]],
  ['model',['model',['../structapop__arms__settings.html#afed3a60f1f5cec8f01ddc610cb08ab5f',1,'apop_arms_settings']]],
  ['model1',['model1',['../structapop__cross__settings.html#a24434a5b38a3483dece53be6a76fa5b0',1,'apop_cross_settings']]],
  ['model2',['model2',['../structapop__cross__settings.html#a3e664969f8549fed957b9d9e7ea79ca3',1,'apop_cross_settings']]],
  ['model_5flist',['model_list',['../structapop__mixture__settings.html#aa8b997e7173017144a89e9eb2e3c6f01',1,'apop_mixture_settings']]]
];

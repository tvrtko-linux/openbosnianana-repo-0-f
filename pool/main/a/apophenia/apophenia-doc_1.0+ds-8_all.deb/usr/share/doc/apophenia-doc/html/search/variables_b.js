var searchData=
[
  ['nan_5fstring',['nan_string',['../structapop__opts__type.html#a6f8139378a237e77d123747fc6952924',1,'apop_opts_type']]],
  ['neval',['neval',['../structapop__arms__settings.html#a79ea448f38bf9339a6adf350c406720b',1,'apop_arms_settings']]],
  ['ninit',['ninit',['../structapop__arms__settings.html#a1d01a0b27137d6c2c02f1829aca20915',1,'apop_arms_settings']]],
  ['npoint',['npoint',['../structapop__arms__settings.html#af73cebea0280bf908c2ebd6c059c134f',1,'apop_arms_settings']]]
];

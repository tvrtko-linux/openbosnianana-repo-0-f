var searchData=
[
  ['output_5fdelimiter',['output_delimiter',['../structapop__opts__type.html#af42fdd88aa587a9cd5e267f34fb2eab7',1,'apop_opts_type']]],
  ['own_5fkernel',['own_kernel',['../structapop__kernel__density__settings.html#a93d16f1ad5b02a21543a557d3541adc2',1,'apop_kernel_density_settings']]]
];

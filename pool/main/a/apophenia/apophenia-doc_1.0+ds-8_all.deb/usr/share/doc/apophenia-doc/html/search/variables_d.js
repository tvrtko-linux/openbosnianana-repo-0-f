var searchData=
[
  ['param_5fsizes',['param_sizes',['../structapop__mixture__settings.html#a1d3d10403e43a7debebccdcddc913a31',1,'apop_mixture_settings']]],
  ['path',['path',['../structapop__mle__settings.html#a577fd17105adc99e026ff03bbaff2ba8',1,'apop_mle_settings']]],
  ['periods',['periods',['../structapop__mcmc__settings.html#a2d45abb2f9ece60029b4f6d11511d41e',1,'apop_mcmc_settings']]],
  ['pmf',['pmf',['../structapop__mcmc__settings.html#a98ab11c08f76807e02d3550259df413d',1,'apop_mcmc_settings']]],
  ['proposal',['proposal',['../structapop__mcmc__proposal__s.html#a43d46dac50936adcd9c90905909b434f',1,'apop_mcmc_proposal_s']]],
  ['proposal_5fcount',['proposal_count',['../structapop__mcmc__settings.html#a04bcdda00a32350ca4b0ba782d3afc3c',1,'apop_mcmc_settings']]],
  ['proposal_5fis_5fcp',['proposal_is_cp',['../structapop__mcmc__settings.html#aa36620e7fd246c8c34ec9fef7ab45faf',1,'apop_mcmc_settings']]],
  ['proposals',['proposals',['../structapop__mcmc__settings.html#a7d9ba8d3ba0ef05364619adb2d988ed0',1,'apop_mcmc_settings']]]
];

var searchData=
[
  ['reject_5fcount',['reject_count',['../structapop__mcmc__proposal__s.html#a192618b78d9a36670c3ba5081916df29',1,'apop_mcmc_proposal_s::reject_count()']]],
  ['rng',['rng',['../structapop__cdf__settings.html#a21fee6ad1f5fafe54eddf9449051efba',1,'apop_cdf_settings::rng()']]]
];

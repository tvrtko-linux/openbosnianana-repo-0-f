var setup =
[
    [ "The supporting cast", "setup.html#cast", null ],
    [ "Not root?", "notroot.html", null ],
    [ "Makefile", "makefile.html", null ],
    [ "Windows", "windows.html", "windows" ]
];
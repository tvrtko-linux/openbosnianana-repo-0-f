var structapop__arms__settings =
[
    [ "convex", "structapop__arms__settings.html#a85e13f4fb666d93db985a9dd4c904be4", null ],
    [ "do_metro", "structapop__arms__settings.html#aedd47a0a4ff37b0b371d3731b1938f9c", null ],
    [ "model", "structapop__arms__settings.html#afed3a60f1f5cec8f01ddc610cb08ab5f", null ],
    [ "neval", "structapop__arms__settings.html#a79ea448f38bf9339a6adf350c406720b", null ],
    [ "ninit", "structapop__arms__settings.html#a1d01a0b27137d6c2c02f1829aca20915", null ],
    [ "npoint", "structapop__arms__settings.html#af73cebea0280bf908c2ebd6c059c134f", null ],
    [ "state", "structapop__arms__settings.html#a16761d29095421ffe78038ea3b9b9acb", null ],
    [ "xinit", "structapop__arms__settings.html#ac75adcea3cfe99ddc3408fffaa1dbfa6", null ],
    [ "xl", "structapop__arms__settings.html#a0677eaab084f07f5f5ecc690124980be", null ],
    [ "xprev", "structapop__arms__settings.html#a040d22cb543f58ce882c2d9a7cdd4d80", null ],
    [ "xr", "structapop__arms__settings.html#a845179acca7b0bdcb730cacc232bc4d0", null ]
];
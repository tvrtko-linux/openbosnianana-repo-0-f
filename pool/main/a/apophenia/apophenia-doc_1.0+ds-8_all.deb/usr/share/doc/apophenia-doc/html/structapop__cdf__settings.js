var structapop__cdf__settings =
[
    [ "draws", "structapop__cdf__settings.html#afeb0823350485ca80fe0e094e58ff8ce", null ],
    [ "draws_made", "structapop__cdf__settings.html#a3ce6fa2317850c1118df87d4a19b110d", null ],
    [ "draws_refcount", "structapop__cdf__settings.html#a838ff279029752654cc7100067d57c91", null ],
    [ "rng", "structapop__cdf__settings.html#a21fee6ad1f5fafe54eddf9449051efba", null ]
];
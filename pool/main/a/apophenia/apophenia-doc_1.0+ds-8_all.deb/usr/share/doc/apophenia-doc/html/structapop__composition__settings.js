var structapop__composition__settings =
[
    [ "draw_ct", "structapop__composition__settings.html#aaa361b95c977efec92cae2ec2be97efd", null ],
    [ "generator_m", "structapop__composition__settings.html#a40fe4ff98635f7ee7909f0ce6cb1a1f7", null ],
    [ "ll_m", "structapop__composition__settings.html#af461a69c830707b4f07721d553b59714", null ]
];
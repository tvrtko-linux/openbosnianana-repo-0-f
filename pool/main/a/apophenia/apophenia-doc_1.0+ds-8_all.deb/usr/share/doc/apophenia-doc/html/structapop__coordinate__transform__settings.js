var structapop__coordinate__transform__settings =
[
    [ "base_model", "structapop__coordinate__transform__settings.html#aa0cc1621ee105ae573a46b58a67f7078", null ],
    [ "base_to_transformed", "structapop__coordinate__transform__settings.html#a3f60d732b9252c365196aa2a105eb529", null ],
    [ "jacobian_to_base", "structapop__coordinate__transform__settings.html#a6b2bd2447fe1cb1caaa5a44c6c01f3c5", null ],
    [ "transformed_to_base", "structapop__coordinate__transform__settings.html#a46cbd57a750ca30f7cce39b3e6d35616", null ]
];
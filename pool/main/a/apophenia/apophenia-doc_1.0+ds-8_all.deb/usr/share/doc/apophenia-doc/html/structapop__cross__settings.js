var structapop__cross__settings =
[
    [ "model1", "structapop__cross__settings.html#a24434a5b38a3483dece53be6a76fa5b0", null ],
    [ "model2", "structapop__cross__settings.html#a3e664969f8549fed957b9d9e7ea79ca3", null ],
    [ "splitpage", "structapop__cross__settings.html#abcb0f389e1bf66424938b5daa85a3180", null ]
];
var structapop__data =
[
    [ "error", "structapop__data.html#a13f8f84c2ada3b5c8efee1c43057aad7", null ],
    [ "matrix", "structapop__data.html#a7a570510198f665f3effa6f7d18cfe89", null ],
    [ "more", "structapop__data.html#ac729aca3fdc7ced5c69684741d58bd65", null ],
    [ "names", "structapop__data.html#aae158ed457d0f1f0a70a9f24105481e8", null ],
    [ "text", "structapop__data.html#a8602d5c470f0168ad4c5c27c1a3473ff", null ],
    [ "textsize", "structapop__data.html#a52317f11b4d5d8a987d0773c9c1bc656", null ],
    [ "vector", "structapop__data.html#af46ebaf49867139f0e9c9cc5610b0a99", null ],
    [ "weights", "structapop__data.html#a7a19e6bfc64096b2107bafc8a802a2f4", null ]
];
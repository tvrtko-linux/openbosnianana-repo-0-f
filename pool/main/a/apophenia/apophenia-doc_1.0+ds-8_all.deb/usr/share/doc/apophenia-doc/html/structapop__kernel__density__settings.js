var structapop__kernel__density__settings =
[
    [ "base_data", "structapop__kernel__density__settings.html#a81f22716b3a6ef5c69378e16e274f742", null ],
    [ "base_pmf", "structapop__kernel__density__settings.html#ae171931cab7613bd16006d5baf324ce4", null ],
    [ "kernel", "structapop__kernel__density__settings.html#ab9eb46f59bc01dcb0715a156ba860e26", null ],
    [ "own_kernel", "structapop__kernel__density__settings.html#a93d16f1ad5b02a21543a557d3541adc2", null ],
    [ "own_pmf", "structapop__kernel__density__settings.html#a962ea94b353a87d2700cbf080a265a5e", null ],
    [ "set_fn", "structapop__kernel__density__settings.html#a645ce1a7f00e3a4dce575df9aacad52c", null ]
];
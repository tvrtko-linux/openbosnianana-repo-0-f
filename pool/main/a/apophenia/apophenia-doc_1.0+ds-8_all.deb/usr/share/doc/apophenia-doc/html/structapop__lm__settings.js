var structapop__lm__settings =
[
    [ "destroy_data", "structapop__lm__settings.html#a6ecfd91942cfb4965dba9382f5947ef5", null ],
    [ "input_distribution", "structapop__lm__settings.html#aabc2f0277f6500c27ad4d3729e12b219", null ],
    [ "instruments", "structapop__lm__settings.html#ac15f9930a7e9d081a88d8fd389d5708f", null ],
    [ "want_cov", "structapop__lm__settings.html#a2f62fede3aec4c7fe461e8ee39c1bcff", null ],
    [ "want_expected_value", "structapop__lm__settings.html#ae6b8c6ca335b895ee91c182c8b9ed6e1", null ]
];
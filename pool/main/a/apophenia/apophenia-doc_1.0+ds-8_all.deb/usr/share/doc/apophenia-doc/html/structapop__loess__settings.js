var structapop__loess__settings =
[
    [ "ci_level", "structapop__loess__settings.html#ace7009d9ce26d3af9d7bd9c12baa7bcf", null ],
    [ "data", "structapop__loess__settings.html#a7b5559d8b8fd57dcded49d2c0cfbcbdb", null ],
    [ "lo_s", "structapop__loess__settings.html#ab59e07d7477389bc90a8fe727acf9a3c", null ],
    [ "want_predict_ci", "structapop__loess__settings.html#a0c8cc70a4be852404cc7cf1bd54e6008", null ]
];
var structapop__mcmc__proposal__s =
[
    [ "accept_count", "structapop__mcmc__proposal__s.html#a7a6d6bb7aeeb12ba4eb98abaeb676748", null ],
    [ "adapt_fn", "structapop__mcmc__proposal__s.html#a1b174018f698676a3cba42dcacf28615", null ],
    [ "proposal", "structapop__mcmc__proposal__s.html#a43d46dac50936adcd9c90905909b434f", null ],
    [ "reject_count", "structapop__mcmc__proposal__s.html#a192618b78d9a36670c3ba5081916df29", null ],
    [ "step_fn", "structapop__mcmc__proposal__s.html#ab9c381250e636bf50aed7db3664166f0", null ]
];
var structapop__mcmc__settings =
[
    [ "accept_count", "structapop__mcmc__settings.html#a4b6c42b5d194856ef14c0dfc651b8602", null ],
    [ "base_adapt_fn", "structapop__mcmc__settings.html#af0b3a768ea4d032294932c450c31db15", null ],
    [ "base_model", "structapop__mcmc__settings.html#a6f038a951747f4bf534814a70ecdd547", null ],
    [ "base_step_fn", "structapop__mcmc__settings.html#ae8bb5cbb3e35e3c9519775b8bdead17b", null ],
    [ "block_count", "structapop__mcmc__settings.html#a26489894697f5c753730b4867151b4b6", null ],
    [ "block_starts", "structapop__mcmc__settings.html#a378402aa7038d613dbfec59d3cceda21", null ],
    [ "burnin", "structapop__mcmc__settings.html#a7c60f0929a17f4c2b2582e9d14a7c030", null ],
    [ "data", "structapop__mcmc__settings.html#a578b5e3ba671e28c79ce18eeb871a942", null ],
    [ "gibbs_chunks", "structapop__mcmc__settings.html#a3b1ce772db565366881f6dadcfc79e4b", null ],
    [ "histosegments", "structapop__mcmc__settings.html#adcb3ad4825157cda798f4df246476f5c", null ],
    [ "last_ll", "structapop__mcmc__settings.html#a8f27658bcc0438f69f5600aa3420502f", null ],
    [ "periods", "structapop__mcmc__settings.html#a2d45abb2f9ece60029b4f6d11511d41e", null ],
    [ "pmf", "structapop__mcmc__settings.html#a98ab11c08f76807e02d3550259df413d", null ],
    [ "proposal_count", "structapop__mcmc__settings.html#a04bcdda00a32350ca4b0ba782d3afc3c", null ],
    [ "proposal_is_cp", "structapop__mcmc__settings.html#aa36620e7fd246c8c34ec9fef7ab45faf", null ],
    [ "proposals", "structapop__mcmc__settings.html#a7d9ba8d3ba0ef05364619adb2d988ed0", null ],
    [ "reject_count", "structapop__mcmc__settings.html#acfd8cd3fa2e0b97710567312f5a398fa", null ],
    [ "start_at", "structapop__mcmc__settings.html#a43b77e37d7b78fe9832867bc979ba3c9", null ],
    [ "target_accept_rate", "structapop__mcmc__settings.html#a73b0c05c15cb9d17da372650e3caa1ff", null ]
];
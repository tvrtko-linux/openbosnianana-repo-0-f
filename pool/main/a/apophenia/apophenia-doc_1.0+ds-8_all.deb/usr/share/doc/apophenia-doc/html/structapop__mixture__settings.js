var structapop__mixture__settings =
[
    [ "cmf", "structapop__mixture__settings.html#a2a1f3f319b7216f85cb06fb32dbb6d4f", null ],
    [ "cmf_refct", "structapop__mixture__settings.html#a0c5022b34acc67ebed6e8d8045cb8497", null ],
    [ "model_count", "structapop__mixture__settings.html#a97e96fdd675fc395442075be0e13baec", null ],
    [ "model_list", "structapop__mixture__settings.html#aa8b997e7173017144a89e9eb2e3c6f01", null ],
    [ "param_sizes", "structapop__mixture__settings.html#a1d3d10403e43a7debebccdcddc913a31", null ],
    [ "weights", "structapop__mixture__settings.html#af06728d5618bb4c903e6f871b504d4e3", null ]
];
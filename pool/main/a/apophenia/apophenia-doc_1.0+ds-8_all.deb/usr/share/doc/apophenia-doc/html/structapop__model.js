var structapop__model =
[
    [ "cdf", "structapop__model.html#ae2bfc30a58ee7bc3bbf593f861e2a7e2", null ],
    [ "constraint", "structapop__model.html#a90daf05974c6cea5a540412118349c1f", null ],
    [ "data", "structapop__model.html#a8d563ee7d22dfefea7ede665056892d7", null ],
    [ "draw", "structapop__model.html#af961c0e752b7557f6bb37ef4ada44856", null ],
    [ "dsize", "structapop__model.html#a5e31343782fe36a70e60e6d0808c64b5", null ],
    [ "error", "structapop__model.html#a3a4d2f9ae17f6f0884ccb365eedc7321", null ],
    [ "estimate", "structapop__model.html#a18a9f6d5a1092f22b221d315a0771069", null ],
    [ "info", "structapop__model.html#aa47b7b6e52fb1c9112d6231a38e25bab", null ],
    [ "log_likelihood", "structapop__model.html#a6a098bc488ce578e0f9009f68a670cd3", null ],
    [ "more", "structapop__model.html#a2b3b6d4670c3b6d3480d242f487edde1", null ],
    [ "more_size", "structapop__model.html#aa0a6e874b1f1b8941bfc5e26fe697a57", null ],
    [ "msize1", "structapop__model.html#a8c1407dfcbe48d8a47c9772980dacb93", null ],
    [ "msize2", "structapop__model.html#a4434fd3332628959195bc17e3d8f2df8", null ],
    [ "name", "structapop__model.html#a3aba8fd0c8430100abaef67060470d9b", null ],
    [ "p", "structapop__model.html#a8d730b2ceb3c6edea8e63827b3be525d", null ],
    [ "parameters", "structapop__model.html#a5961aa1fe6993d0e9a9eae4715f2c213", null ],
    [ "prep", "structapop__model.html#a29428d84dea70d60dbbc68f41d738898", null ],
    [ "settings", "structapop__model.html#a3b935452a2a1f2a4bd3876fd70013e57", null ],
    [ "vsize", "structapop__model.html#a3ca571f9d98007e5332c799c66b1a03b", null ]
];
var structapop__name =
[
    [ "col", "structapop__name.html#abbf3e28cb7703cf1b419f793883c81fd", null ],
    [ "colct", "structapop__name.html#a6ce1f304942b019ced193d88f0bf7a0d", null ],
    [ "row", "structapop__name.html#a9218b225c5e65b18f5c7550623c5dead", null ],
    [ "rowct", "structapop__name.html#a9cbde6027520738362cdb9f84a2f3f3c", null ],
    [ "text", "structapop__name.html#a0588f0500798fae526cccd92f8ddb062", null ],
    [ "textct", "structapop__name.html#a0d065d0e239af245983fc133d68ea7c0", null ],
    [ "title", "structapop__name.html#a87facb597b7848beda69185a02fdf242", null ],
    [ "vector", "structapop__name.html#a658ae9b372ad21c413f2f9d13a4e12f1", null ]
];
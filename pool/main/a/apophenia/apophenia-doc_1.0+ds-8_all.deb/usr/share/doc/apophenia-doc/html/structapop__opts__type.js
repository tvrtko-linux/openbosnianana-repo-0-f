var structapop__opts__type =
[
    [ "db_engine", "structapop__opts__type.html#a9c128a43c2e53c7639ce4ddb0cef92f6", null ],
    [ "db_name_column", "structapop__opts__type.html#add132a622f0bade19869a3671e13e27c", null ],
    [ "db_pass", "structapop__opts__type.html#a726b1d316e036ab1971ca7aacba6b678", null ],
    [ "db_user", "structapop__opts__type.html#a5bdd7da78ca8e8246e9efca89fd6c2a8", null ],
    [ "input_delimiters", "structapop__opts__type.html#a4847a549c668ec81207663032874bd49", null ],
    [ "log_file", "structapop__opts__type.html#af3172488ebca98724b8e62841294eb6d", null ],
    [ "nan_string", "structapop__opts__type.html#a6f8139378a237e77d123747fc6952924", null ],
    [ "output_delimiter", "structapop__opts__type.html#af42fdd88aa587a9cd5e267f34fb2eab7", null ],
    [ "rng_seed", "structapop__opts__type.html#a3946960c4345bd9bdc96642952d1009c", null ],
    [ "stop_on_warning", "structapop__opts__type.html#a7b3c6c9e58241b7e69db4fdfc6ee96a2", null ],
    [ "verbose", "structapop__opts__type.html#aa76e9237ed45c77bc883b428c3217a66", null ],
    [ "version", "structapop__opts__type.html#aab14468fa780adff742623a2b148101f", null ]
];
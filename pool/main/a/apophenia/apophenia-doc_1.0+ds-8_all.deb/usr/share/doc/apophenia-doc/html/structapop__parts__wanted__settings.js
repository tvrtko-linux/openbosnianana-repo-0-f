var structapop__parts__wanted__settings =
[
    [ "covariance", "structapop__parts__wanted__settings.html#a6856418f42da34620836f877708d3471", null ],
    [ "info", "structapop__parts__wanted__settings.html#aac592a38dd0471e90592c034b3788298", null ],
    [ "predicted", "structapop__parts__wanted__settings.html#a7472676f49fe12f5d3f3dd022260feea", null ],
    [ "tests", "structapop__parts__wanted__settings.html#a44d3569f2c9e5d5cb86e033bfb4cee7d", null ]
];
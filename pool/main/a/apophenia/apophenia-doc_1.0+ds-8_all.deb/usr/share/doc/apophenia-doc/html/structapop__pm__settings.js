var structapop__pm__settings =
[
    [ "base", "structapop__pm__settings.html#a25f334019a88d3f4e990fb64d99b2e49", null ],
    [ "draws", "structapop__pm__settings.html#a931e912635b015bf3ca6ee912805c10c", null ],
    [ "index", "structapop__pm__settings.html#a79072b5caa6b33ba58a9e5751760380d", null ],
    [ "rng", "structapop__pm__settings.html#af371f9fff2c44523f5c7a88ac928f26c", null ]
];
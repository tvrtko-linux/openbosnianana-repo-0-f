var structapop__pmf__settings =
[
    [ "cmf", "structapop__pmf__settings.html#a65dbe2785f142cbf313a22fbb1e6034e", null ],
    [ "cmf_refct", "structapop__pmf__settings.html#a7ff75136602b5fb8229de089b5d9f75b", null ],
    [ "draw_index", "structapop__pmf__settings.html#a8e878300e25018c0124acf2379f52db2", null ],
    [ "total_weight", "structapop__pmf__settings.html#a94c6f1dfbd4096ad2bef8f1676595e0f", null ]
];
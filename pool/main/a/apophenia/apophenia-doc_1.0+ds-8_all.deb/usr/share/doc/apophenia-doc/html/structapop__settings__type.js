var structapop__settings__type =
[
    [ "copy", "structapop__settings__type.html#ac7fbeb4365ff8f39adb212847fc1534b", null ],
    [ "free", "structapop__settings__type.html#af788e5e0c2cf935ef5df3f2b525edfa4", null ],
    [ "name", "structapop__settings__type.html#a27d082715e7de49fd30b9ee7062d08c5", null ],
    [ "name_hash", "structapop__settings__type.html#acf32308ed6c0ec67bc068e994b6045cd", null ],
    [ "setting_group", "structapop__settings__type.html#aeb51d5c1b3916dca7c76a27d4b58f488", null ]
];
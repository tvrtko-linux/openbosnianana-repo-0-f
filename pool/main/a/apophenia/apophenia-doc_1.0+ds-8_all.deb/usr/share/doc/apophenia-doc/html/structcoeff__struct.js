var structcoeff__struct =
[
    [ "scaling", "structcoeff__struct.html#a662ee04aa8defc97250fe96fb3612b0b", null ]
];
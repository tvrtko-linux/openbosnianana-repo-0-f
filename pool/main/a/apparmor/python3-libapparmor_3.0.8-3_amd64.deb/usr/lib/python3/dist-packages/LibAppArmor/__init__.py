import sys

if sys.version_info[0] >= 3:
    from LibAppArmor.LibAppArmor import *
else:
    from .LibAppArmor import *

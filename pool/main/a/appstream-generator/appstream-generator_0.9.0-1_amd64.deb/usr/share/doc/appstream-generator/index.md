# AppStream Generator Docs

For general information check out the [README file](../README.md)

See [usage.md](usage.md) for general usage information.

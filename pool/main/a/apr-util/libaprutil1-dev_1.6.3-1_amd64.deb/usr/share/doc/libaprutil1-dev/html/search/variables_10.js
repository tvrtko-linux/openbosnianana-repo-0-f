var searchData=
[
  ['read_0',['read',['../structapr__bucket__type__t.html#a4e6befb63427ae39290fe146b1b4e510',1,'apr_bucket_type_t']]],
  ['read_5fsize_1',['read_size',['../structapr__bucket__file.html#a81c7e6646352fa03d4fb5a346dde4105',1,'apr_bucket_file']]],
  ['readpool_2',['readpool',['../structapr__bucket__file.html#a61b5603482215f6c9ace7b26fa12b884',1,'apr_bucket_file']]],
  ['refcount_3',['refcount',['../structapr__bucket__refcount.html#a75040af03e3ad3c722bccea1048e3dae',1,'apr_bucket_refcount::refcount()'],['../structapr__bucket__heap.html#ab87003dea25caef69aa3b30a1948024e',1,'apr_bucket_heap::refcount()'],['../structapr__bucket__mmap.html#a99f201622002479f4f84ea10598a013c',1,'apr_bucket_mmap::refcount()'],['../structapr__bucket__file.html#ab0c123f34b85a07b601dc9794f8eed09',1,'apr_bucket_file::refcount()']]],
  ['rejected_5fconnections_4',['rejected_connections',['../structapr__redis__stats__t.html#ac5ca0364702ee29c56f9969e03a581e2',1,'apr_redis_stats_t']]],
  ['role_5',['role',['../structapr__redis__stats__t.html#a94c0c6bed9844279c60d7fb0840fb24d',1,'apr_redis_stats_t']]],
  ['root_6',['root',['../structapr__xml__doc.html#a9385ccf062ed6997d2d59d80cda28a71',1,'apr_xml_doc']]],
  ['rusage_5fsystem_7',['rusage_system',['../structapr__memcache__stats__t.html#a2eff9899b9cb4ee704fae93af4c5bf76',1,'apr_memcache_stats_t']]],
  ['rusage_5fuser_8',['rusage_user',['../structapr__memcache__stats__t.html#a4e43e96550407edd29e81ba59706c5b5',1,'apr_memcache_stats_t']]],
  ['rw_9',['rw',['../unionapr__anylock__t_1_1apr__anylock__u__t.html#a7d876bf9eda2835ba357a25c98b095b2',1,'apr_anylock_t::apr_anylock_u_t']]]
];

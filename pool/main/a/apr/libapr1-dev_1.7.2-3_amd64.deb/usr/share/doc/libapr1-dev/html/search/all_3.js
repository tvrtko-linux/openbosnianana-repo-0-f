var searchData=
[
  ['deprecated_20list_0',['Deprecated List',['../deprecated.html',1,'']]],
  ['desc_1',['desc',['../structapr__pollfd__t.html#ad63baa71bb91f80513d33482e28fb967',1,'apr_pollfd_t']]],
  ['desc_5ftype_2',['desc_type',['../structapr__pollfd__t.html#acfafd260241a874745f49ba2df246c53',1,'apr_pollfd_t']]],
  ['description_3',['description',['../structapr__getopt__option__t.html#a8fd515c0a9e621f6c0d058772429ab98',1,'apr_getopt_option_t']]],
  ['device_4',['device',['../structapr__finfo__t.html#a38cbfbff641284065481f5907d59c8bf',1,'apr_finfo_t']]],
  ['directory_20manipulation_20functions_5',['Directory Manipulation Functions',['../group__apr__dir.html',1,'']]],
  ['dso_20_28dynamic_20loading_29_20portability_20routines_6',['DSO (Dynamic Loading) Portability Routines',['../group__apr__os__dso.html',1,'']]],
  ['dynamic_20object_20handling_7',['Dynamic Object Handling',['../group__apr__dso.html',1,'']]]
];

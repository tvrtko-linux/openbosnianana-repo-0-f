var searchData=
[
  ['user_20and_20group_20id_20services_0',['User and Group ID Services',['../group__apr__user.html',1,'']]]
];

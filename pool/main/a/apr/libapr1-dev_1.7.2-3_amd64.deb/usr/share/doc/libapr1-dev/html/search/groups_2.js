var searchData=
[
  ['c_20_28posix_29_20locale_20string_20functions_0',['C (POSIX) locale string functions',['../group__apr__cstr.html',1,'']]],
  ['command_20argument_20parsing_1',['Command Argument Parsing',['../group__apr__getopt.html',1,'']]],
  ['condition_20variable_20routines_2',['Condition Variable Routines',['../group__apr__thread__cond.html',1,'']]],
  ['ctype_20functions_3',['ctype functions',['../group__apr__ctype.html',1,'']]]
];

var searchData=
[
  ['object_20permission_20set_20functions_0',['Object permission set functions',['../group__apr__perms__set.html',1,'']]],
  ['other_20child_20flags_1',['Other Child Flags',['../group___a_p_r___o_c.html',1,'']]]
];

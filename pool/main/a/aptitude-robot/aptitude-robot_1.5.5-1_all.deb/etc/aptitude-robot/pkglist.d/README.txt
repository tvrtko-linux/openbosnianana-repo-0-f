Place package lists in this directory.  Files with periods in their name are
ignored.  If no package list file is placed here, aptitude-robot will perform
`aptitude install ~U`.

Scripts in this directory are executed before aptitude is run.  Files with
periods in their name are ignored.  If in doubt do not place a script here.
It would be executed every time aptitude-robot is run.

#!/usr/bin/perl
# Copyright 2007-2017
# Frank Terbeck <ft@bewatermyfriend.org>, All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#   1. Redistributions of source code must retain the above
#      copyright notice, this list of conditions and the following
#      disclaimer.
#   2. Redistributions in binary form must reproduce the above
#      copyright notice, this list of conditions and the following
#      disclaimer in the documentation and/or other materials
#      provided with the distribution.
#
#  THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
#  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
#  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#  DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS OF THE
#  PROJECT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
#  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
#  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
#  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
#  OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

package ARename;
use warnings;
use strict;

# modules

# These are commonly installed along with Perl:
use Readonly;
use Carp;
use Data::Dumper;
use English '-no_match_vars';
use Getopt::Long;
use File::Basename;
use File::Copy;
use Cwd;
use Cwd 'abs_path';
use Term::ANSIColor qw(:constants);

# This one is not. But it's available via CPAN and - if you're lucky - via your
# OS's packaging system.
use Audio::Scan;

# So, how does all of this work? Well, the main entry point is
# `process_file()', which is called from the executable script for every file,
# we're about to work on. The `process_file()' function doesn't take an
# argument. The name of the current file is provided by calling `set_file()'.
#
# Then `process_file()' does the following:
#
#   - Check if the file is readable and not a symlink.
#   - Possibly canonicalise the file name.
#   - Check if the file appears to be supported.
#   - Gather tag information (you may want to check the `%infomap' comment
#     for information on how this works).
#   - Call the post processing function (which is `arename()' by default).
#
# When `arename()' takes over, here's its basic functionality:
#
#   - Apply default values to the data hash.
#   - Choose the right template for the current file.
#   - Expand the chosen template based on the data in the data hash.
#   - Make sure the old and new name are not the same (in which case there
#     would be nothing further to do).
#   - Make sure there is no file that goes by the generated new name.
#   - Make sure the destination directory exists.
#   - Finally (depending on the active mode) rename or copy the old to the
#     new file name.
#
# And that's all there is to it really. All that is salted with a number of
# options and hooks to ensure flexibility and extensibility.
#
# The rest of the code is output functions, configuration file handling,
# command line options parsing, hook file handling and utility functions.

# variables
my (
    %aliasmap, %cmdline_protect, %conf, %defaults, %hooks, %parsers, %profiles,
    %opts, %sectconf, %sets, %typemap, %infomap, %defaultmap, %lsets,
    $__arename_file, $postproc, $sect,
    @cmdline_profiles, @localizables, @settables, @supported_tags,
);
our ( $NAME, $VERSION ) = qw( unset unset );

# a helper for the testsuite
sub data_reset {
    undef %conf;
    undef %defaults;
    undef %hooks;
    undef %parsers;
    undef %profiles;
    undef %opts;
    undef %sectconf;
    undef %sets;
    undef @cmdline_profiles;
    undef @localizables;
    undef @settables;
    undef @supported_tags;

    $conf{verbosity} = 5;
    return 1;
}

# Audio::Scan uses a certain set of names for file types. It seems to
# be aiming for three letter names. `arename' however uses "flac" for
# flac files, not "flc". Therefore we need to map Audio::Scan names to
# arename names. And that is what is being done here.
#
# The wavepack name is mapped from "wvp" to "wv". The latter is the
# more common file extension, which makes sense when using the
# `usetypeasextension' option - and that is the default behaviour.
%typemap = (
    'aac' => 'aac',
    'ape' => 'ape',
    'asf' => 'asf',
    'flc' => 'flac',
    'mp3' => 'mp3',
    'mp4' => 'mp4',
    'mpc' => 'mpc',
    'ogg' => 'ogg',
    'wav' => 'wav',
    'wvp' => 'wv',
);

# This maps certain tags to default values. Any tag, that is not
# listed here will not get a default value (unless the user defines
# such a value in his/her configuration file).
%defaultmap = (
    bitrate    => 0,
    channels   => 1,
    length_ms  => 0,
    samplerate => 0,
);

# Many tags are available via shorter names if the `template_aliases'
# option is enabled (which it is *not* by default). This hash maps
# alias names to their longer counterparts.
%aliasmap = (
    al   => 'album',
    ar   => 'artist',
    br   => 'bitrate',
    ch   => 'channels',
    cmp  => 'compilation',
    gn   => 'genre',
    kbr  => 'kbitrate',
    ksr  => 'ksamplerate',
    ln   => 'length_ms',
    ls   => 'length_sec',
    sr   => 'samplerate',
    tn   => 'tracknumber',
    tt   => 'tracktitle',
    yr   => 'year',
);

# This hash maps infomation from Audio::Scan to our internal data hash. Take
# a look at the `flac' and `mp3' entries for specific information. The overall
# idea is to have a set of tags that are supported for every file type and a
# few which are file type specific. `fill_data()' is responsible for putting
# all this together.
%infomap = (
    aac => {
            bitrate         => [ qw( info bitrate ) ],
            channels        => [ qw( info stereo ) ],
            length_ms       => [ qw( info song_length_ms ) ],
            samplerate      => [ qw( info samplerate ) ],

            album           => [ qw( tags TALB ) ],
            artist          => [ qw( tags TPE1 ) ],
            compilation     => [ qw( tags TPE2 ) ],
            genre           => [ qw( tags TCON ) ],
            tracknumber     => [ qw( tags TRCK ) ],
            tracktitle      => [ qw( tags TIT2 ) ],
            year            => [ qw( tags TDRC ) ],
    },
    ape => {
            bitrate         => [ qw( info bitrate ) ],
            channels        => [ qw( info channels ) ],
            length_ms       => [ qw( info song_length_ms ) ],
            samplerate      => [ qw( info samplerate ) ],

            album           => [ qw( tags ALBUM ) ],
            artist          => [ qw( tags ARTIST ) ],
            compilation     => [ qw( tags ALBUMARTIST ) ],
            genre           => [ qw( tags GENRE ) ],
            tracknumber     => [ qw( tags TRACK ) ],
            tracktitle      => [ qw( tags TITLE ) ],
            year            => [ qw( tags YEAR ) ],
    },
    asf => {
            # `bitrate', `channels', and `samplerate' are very likely
            # wrong (or non-existant, in which case the default is used).
            # I don't care much about `asf' at all, so this will have to
            # do. Also, I guess this will probably only work properly on
            # audio-files (wma). I don't know. If you want this to work
            # better, send patches.
            bitrate         => [ qw( info bitrate ) ],
            channels        => [ qw( info channels ) ],
            length_ms       => [ qw( info play_duration_ms ) ],
            samplerate      => [ qw( info samplerate ) ],

            album           => [ qw( tags WM/AlbumTitle ) ],
            artist          => [ qw( tags Author ) ],
            compilation     => [ qw( tags WM/AlbumArtist ) ],
            genre           => [ qw( tags WM/Genre ) ],
            tracknumber     => [ qw( tags WM/TrackNumber ) ],
            tracktitle      => [ qw( tags Title ) ],
            year            => [ qw( tags WM/Year ) ],
    },
    flac => {
            # first, file type specific tags; their names always start
            # in "$type"_; tag_supported relies on it.
            flac_wordsize   => [ qw( info bits_per_sample ) ],

            # next come all common tags. *Every* file needs to support
            # these. tag_supported checks the 'flac' entry to check if
            # a common tag is supported, all other types must follow.
            bitrate         => [ qw( info bitrate ) ],
            channels        => [ qw( info channels ) ],
            length_ms       => [ qw( info song_length_ms ) ],
            samplerate      => [ qw( info samplerate ) ],

            album           => [ qw( tags ALBUM ) ],
            artist          => [ qw( tags ARTIST ) ],
            compilation     => [ qw( tags ALBUMARTIST ) ],
            genre           => [ qw( tags GENRE ) ],
            tracknumber     => [ qw( tags TRACKNUMBER ) ],
            tracktitle      => [ qw( tags TITLE ) ],
            year            => [ qw( tags DATE ) ],
    },
    mp3 => {
            mp3_id3_version => [ qw( info id3_version ) ],

            bitrate         => [ qw( info bitrate ) ],
            # there is no channels entity in id3 meta information, but
            # there is a stereo entity, which is 1 for 2 channels and 0 for
            # 1 (mono). that information cannot be dealt with in a simple
            # map, so we're handling it in fill_data_mp3().
            channels        => [ qw( info stereo ) ],
            length_ms       => [ qw( info song_length_ms ) ],
            samplerate      => [ qw( info samplerate ) ],

            album           => [ qw( tags TALB ) ],
            artist          => [ qw( tags TPE1 ) ],
            compilation     => [ qw( tags TPE2 ) ],
            genre           => [ qw( tags TCON ) ],
            tracknumber     => [ qw( tags TRCK ) ],
            tracktitle      => [ qw( tags TIT2 ) ],
            year            => [ qw( tags TDRC ) ],

            # a dedicated function called after the data was filled initially.
            # fill_function is not a valid tag name and tag_supported will return
            # 0 (false) for it, if asked.
            fill_function   => \&fill_data_mp3,
    },
    mp4 => {
            bitrate         => [ qw( info avg_bitrate ) ],
            channels        => [ qw( info channels ) ],
            length_ms       => [ qw( info song_length_ms ) ],
            samplerate      => [ qw( info samplerate ) ],

            album           => [ qw( tags ALB ) ],
            artist          => [ qw( tags ART ) ],
            compilation     => [ qw( tags AART ) ],
            genre           => [ qw( tags GNRE ) ],
            tracknumber     => [ qw( tags TRKN ) ],
            tracktitle      => [ qw( tags NAM ) ],
            year            => [ qw( tags DAY ) ],
    },
    mpc => {
            bitrate         => [ qw( info bitrate ) ],
            channels        => [ qw( info channels ) ],
            length_ms       => [ qw( info song_length_ms ) ],
            samplerate      => [ qw( info samplerate ) ],

            album           => [ qw( tags ALBUM ) ],
            artist          => [ qw( tags ARTIST ) ],
            compilation     => [ qw( tags ALBUMARTIST ) ],
            genre           => [ qw( tags GENRE ) ],
            tracknumber     => [ qw( tags TRACK ) ],
            tracktitle      => [ qw( tags TITLE ) ],
            year            => [ qw( tags YEAR ) ],
    },
    ogg => {
            bitrate         => [ qw( info bitrate_nominal ) ],
            channels        => [ qw( info channels ) ],
            length_ms       => [ qw( info song_length_ms ) ],
            samplerate      => [ qw( info samplerate ) ],

            album           => [ qw( tags ALBUM ) ],
            artist          => [ qw( tags ARTIST ) ],
            compilation     => [ qw( tags ALBUMARTIST ) ],
            genre           => [ qw( tags GENRE ) ],
            tracknumber     => [ qw( tags TRACKNUMBER ) ],
            tracktitle      => [ qw( tags TITLE ) ],
            year            => [ qw( tags DATE ) ],
    },
    wav => {
            wav_id3_version => [ qw( info id3_version ) ],

            bitrate         => [ qw( info bitrate ) ],
            channels        => [ qw( info channels ) ],
            length_ms       => [ qw( info song_length_ms ) ],
            samplerate      => [ qw( info samplerate ) ],

            album           => [ qw( tags TALB ) ],
            artist          => [ qw( tags TPE1 ) ],
            compilation     => [ qw( tags TPE2 ) ],
            genre           => [ qw( tags TCON ) ],
            tracknumber     => [ qw( tags TRCK ) ],
            tracktitle      => [ qw( tags TIT2 ) ],
            year            => [ qw( tags TDRC ) ],
    },
    wv => {
            bitrate         => [ qw( info bitrate ) ],
            channels        => [ qw( info channels ) ],
            length_ms       => [ qw( info song_length_ms ) ],
            samplerate      => [ qw( info samplerate ) ],

            album           => [ qw( tags ALBUM ) ],
            artist          => [ qw( tags ARTIST ) ],
            compilation     => [ qw( tags ALBUMARTIST ) ],
            genre           => [ qw( tags GENRE ) ],
            tracknumber     => [ qw( tags TRACK ) ],
            tracktitle      => [ qw( tags TITLE ) ],
            year            => [ qw( tags YEAR ) ],
    },
);

# settings that may occur in [sections]
@localizables = qw(
    ambiguoususefirst
    copymode
    force
    prefix
    sepreplace
    template_aliases
    tnpad
    comp_template
    suppress_skips
    template
);

# This is a helper list, that is used only in `dump_config()'. If a
# variable is missing from this list, `dump_config()' will not list
# it.
@settables = qw(
    ambiguoususefirst
    canonicalize checkprofilerc checktemplatesinitially comp_template
    debug
    hookerrfatal
    prefix
    sepreplace
    template template_aliases tnpad
    usehooks uselocalhooks uselocalrc useprofiles
    warningsautodryrun
);

$postproc = \&arename;

# high level code

sub arename {
    my ($datref, $ext) = @_;
    my ($t, $newname, $eq);

    my $file = get_file();
    my $printable = get_file_printable();

    run_hook('pre_apply_defaults', $datref, \$ext);

    apply_defaults($datref);

    run_hook('pre_template', $datref, \$ext);

    $t = choose_template($datref);
    $newname = expand_template($t, $datref);
    return if not defined $newname;
    $newname = get_opt("prefix") . "/$newname.$ext";

    run_hook('post_template', $datref, \$ext, \$newname);

    $eq = file_eq($newname, $file);
    if (!$eq || !get_opt('suppress_skips')) {
        arename_verbosity($datref);
    }
    if ($eq && !get_opt('suppress_skips')) {
        op('skip-same', $printable) or op('skip', $printable);
    }

    return if ($eq);

    if (-e $newname && !get_opt("force")) {
        op('target-exists-twoline', $newname) or op('target-exists', $newname);
        return 0;
    }

    ensure_dir(dirname($newname));

    run_hook('post_ensure_dir', $datref, \$ext, \$newname);

    do {
        my ($mode);
        if (get_opt("copymode")) {
            $mode = 'cp';
        } else {
            $mode = 'mv';
        }
        op('rename', $mode, $printable, $newname)
            or op('quoted-file',
                  sub {
                      my ($ret) = @_;
                      $ret =~ s,','\\'',g;
                      return $ret;}->($newname));
    };

    if (!get_opt("dryrun")) {
        if (!get_opt("copymode")) {
            xrename($file, $newname);
        } else {
            xcopy($file, $newname);
        }
    }

    run_hook('post_rename', $datref, \$ext, \$newname);

    return 1;
}

sub apply_defaults {
    my ($datref) = @_;
    my ($value);

    foreach my $key (get_default_keys()) {
        if (!defined $datref->{$key}) {
            run_hook('apply_defaults', $datref, \$key);

            $value = get_defaults($key);
            op('default-set-value', $key, $value);
            $datref->{$key} = $value;
        }
    }

    return 1;
}

sub tag_aliased {
    my ($tag) = @_;

    return 1 if (defined $aliasmap{$tag});
    return 0;
}

sub tag_supported {
    my ($tag) = @_;

    return 0 if ($tag eq 'fill_function');
    foreach my $sup (grep { !/^flac_/ } keys %{ $infomap{'flac'} }) {
        return 1 if ($tag eq $sup);
    }
    foreach my $type (keys %infomap) {
        foreach my $sup (grep { /^$type(_)/ } keys %{ $infomap{$type} }) {
            return 2 if ($tag eq $sup);
        }
    }

    return 0;
}

sub arename_verbosity {
    my ($datref) = @_;

    return 0 if (get_opt('verbosity') < 10);
    my $out = sub {
        my ($thing) = @_;
        my $name = ucfirst $thing;
        op('tag-list', $name, getdat($datref, $thing));
    };

    $out->('artist');
    $out->('compilation');
    $out->('album');
    $out->('tracktitle');
    $out->('tracknumber');
    $out->('genre');
    $out->('year');

    return 1;
}

sub getdat {
    my ($datref, $tag) = @_;

    return defined $datref->{$tag} ? q{"} . $datref->{$tag} . q{"} : "(undefined)";
}

sub fill_data_mp3 {
    # $rd is a hash reference
    my ($rd, $datref) = @_;

    if ($rd->{'info'}->{'stereo'} eq '1') {
        $datref->{'channels'} = 2;
    } else {
        $datref->{'channels'} = 1;
    }
    return 0;
}

sub fill_default {
    my ($datref, $key, $default) = @_;

    if (!defined $datref->{$key} || $datref->{$key} eq q{}) {
        $datref->{$key} = $default;
    }

    return 0;
}

sub fill_data_sanitize {
    my ($datref) = @_;

    foreach my $d (keys %defaultmap) {
        fill_default($datref, $d, $defaultmap{$d});
    }

    return 0;
}

sub fill_data_additional {
    my ($datref) = @_;

    # others would be length_minsec, length_hourminsec
    $datref->{'length_sec'} = $datref->{'length_ms'} / 1000;
    $datref->{'kbitrate'} = $datref->{'bitrate'} / 1000;
    $datref->{'ksamplerate'} = $datref->{'samplerate'} / 1000;

    return 0;
}

sub __fill_data {
    my ($type, $info, $mapref, $rd, $datref) = @_;
    my ($value);

    return 0 if ($info eq 'fill_function');
    $value = $rd->{$mapref->[0]}->{$mapref->[1]};
    return 0 if (!defined $value);
    if (ref($value) eq 'ARRAY') {
        run_hook('ambiguoustag', \$info, \$value, $datref, $rd);
    }
    if (ref($value) eq 'ARRAY') {
        if (get_opt('ambiguoususefirst')) {
            $value = $value->[0];
        } else {
            op('more-than-one-tag', get_file(), $info);
            foreach my $val (@{ $value }) {
                op('more-than-one-tag-value', $val);
            }
            return -1;
        }
    }
    if ($info eq 'tracknumber') {
        my ($max);
        if ($value =~ m@/@) {
            $value =~ s@/(.*)$@@;
            $max = $1; ## no critic (ProhibitCaptureWithoutTest)
            $datref->{tracknummax} = $max;
        }
    }
    $datref->{$info} = $value;

    return 1;
}

sub fill_data {
    # Like $datref, $rd is a hash reference (for the raw data from
    # Audio::Scan->scan()..
    my ($rd, $datref, $type) = @_;
    my ($errout);

    $errout = 0;
    foreach my $info (sort keys %{ $infomap{$type} }) {
        if (__fill_data($type, $info, $infomap{$type}{$info}, $rd, $datref) < 0)
        {
            $errout = 1;
        }
    }
    return 0 if ($errout);
    fill_data_sanitize($datref);
    fill_data_additional($datref);
    if (defined $infomap{$type}{'fill_function'}) {
        $infomap{$type}{'fill_function'}->($rd, $datref, $type);
    }

    return 1;
}

sub filetype_supported {
     my ($file) = @_;
     my ($ext, $type);

     ($ext) = $file =~ m/[.]([^.]+)$/;
     return if (!defined $ext);
     $type = Audio::Scan->type_for($ext);
     return if (!defined $type);

     foreach my $t (keys %typemap) {
         return ($typemap{$t}, $ext) if ($t eq $type);
     }
     return;
}

sub scan_file {
    my ($datref, $type) = @_;
    my $file = get_file();
    my ($rc, $rd);

    return 0 if (!defined $file);
    run_hook('pre_scan', \$type);
    local $ENV{AUDIO_SCAN_NO_ARTWORK} = 1;
    $rd = Audio::Scan->scan($file);
    run_hook('post_scan', \$type, $rd);

    $rc = fill_data($rd, $datref, $type);
    run_hook('post_fill', \$rc, \$type, $rd, $datref);
    return $rc;
}

sub process_warn {
    op('no-method', get_file_printable());
    return 1;
}

sub process_file {
    # process_file() assumes, that set_file() was used to tell
    # ARename.pm which file to work on currently.
    my (%data, $file, $printable, $type, $ext);

    $file = get_file();
    $printable = get_file_printable();

    run_hook('next_file_early');

    op('processing-file', $printable);
    if (-l $file) {
        op('skip-symlink', $printable);
        return 0;
    }
    if (! -r $file) {
        op('file-read-error', $printable, $ERRNO);
        return 0;
    }

    if (get_opt('canonicalize')) {
        my $f = abs_path($file);
        run_hook('canonicalize', \$f);
        set_file($f);
    }

    run_hook('next_file_late');

    ($type, $ext) = filetype_supported($file);
    if (!defined $type) {
        run_hook('filetype_unknown');
        process_warn();
        return 0;
    }
    run_hook('filetype_known', \$ext, \$type);
    if (get_opt('usetypeasextension')) {
        $ext = $type;
    }

    if (!scan_file(\%data, $type)) {
        op('warnings-while-scanning-file');
        return 0;
    }
    run_hook('pre_rename', \$type, \$ext, \%data);
    $postproc->(\%data, $ext);

    run_hook('file_done');
    return 1;
}

sub get_profile_list {
    my @list = ();
    my $wd = getcwd();
    my %seen = ();

    # make sure $wd ends in *one* slash
    $wd =~ s/\/+$//;
    $wd .= q{/};

    foreach my $profile (sort keys %profiles) {
        op('debug',qq{get_profile_list(): Checking "$profile" patterns...\n});

        foreach my $pat (@{ $profiles{$profile} }) {
            op('debug', "get_profile_list(): ($wd) =~ ($pat)...\n");

            if ($wd =~ m/^$pat/) {
                op('debug', "get_profile_list(): MATCHED.\n");
                push @list, $profile;
                last;
            }

        }
    }

    @list = sort grep { ! $seen{ $_ }++ } (@list, @cmdline_profiles);
    op('debug', "get_profile_list(): (" . join(q{,}, @list) . ")\n");
    return @list;
}

sub set_default_options {
    if (defined $ENV{'ARENAME_LOAD_QUIET'}
        && $ENV{'ARENAME_LOAD_QUIET'} eq '1')
    {
        set_opt("load_quiet",       1);
    } else {
        set_opt("load_quiet",       0);
    }
    set_opt("ambiguoususefirst",    0);
    set_opt("canonicalize",         0);
    set_opt("copymode",             0);
    set_opt("checkprofilerc",       1);
    set_opt("checktemplatesinitially", 1);
    set_opt("dryrun",               0);
    set_opt("force",                0);
    set_opt("hookerrfatal",         1);
    set_opt("prefix" ,              q{.});
    set_opt("readstdin",            0);
    set_opt("sepreplace",           q{_});
    set_opt("suppress_skips",       0);
    set_opt("template_aliases",     0);
    set_opt("tnpad",                2);
    set_opt("usehooks",             1);
    set_opt("uselocalhooks",        0);
    set_opt("uselocalrc",           0);
    set_opt("usetypeasextension",   1);
    set_opt("useprofiles",          1);
    set_opt("warningsautodryrun",   1);
    set_opt("comp_template",
            q{va/&album/&tracknumber - &artist - &tracktitle});
    set_opt("template",
            q{&artist[1]/&artist/&album/&tracknumber - &tracktitle});

    return 1;
}

sub set_nameversion {
    my ($n, $v) = @_;

    $NAME    = $n;
    ## no critic (RequireConstantVersion)
    $VERSION = $v;
    ## use critic
    return 1;
}

sub set_postproc {
    my ($p) = @_;

    $postproc = $p;
    return 1;
}

sub usage {
    print " Usage:\n  $NAME [OPTION(s)] FILE(s)...\n\n";
    print "    --ambiguous-use-first        If a tag has multiple values, use the 1st one.\n";
    print "    --compare-versions           Compare versions of script and module.\n";
    print "    --copy, -c                   Copy files, rather than renaming.\n";
    print "    --debug                      Enable debugging output.\n";
    print "    --disable-hooks, -H          Disable *all* hooks.\n";
    print "    --disable-profiles, -N       Deactivate all profiles.\n";
    print "    --dryrun, -d                 Go into dryrun mode.\n";
    print "    --enable-hooks               Enable hooks, if the configuration disabled\n";
    print "                                 them.\n";
    print "    --force, -f                  Overwrite files if needed.\n";
    print "    --help, -h                   Display this help text.\n";
    print "    --list-cfg, -L               List current configuration.\n";
    print "    --list-file-types            List all supported file types.\n";
    print "    --list-exts-for-type <type>  List extensions recognised as <type>.\n";
    print "    --list-profiles, -S          Show a list of defined profiles\n";
    print "    --read-local, -l             Read local rc, if it exists.\n";
    print "    --stdin, -s                  Read file names from stdin.\n";
    print "    --suppress-skips, -Q         Don't display data of skipped files\n";
    print "    --verbosity <level>          Set verbosity of arename's output.\n";
    print "    --version, -V                Display version infomation.\n";
    print "\n";
    print "    --rc <file>                  Read file instead of ~/.arenamerc.\n";
    print "    --post-rc <file>             Read file after ~/.arenamerc.\n";
    print "\n";
    print "    --prefix, -p <prefix>        Define a prefix for destination files.\n";
    print "    --profile, -P <prof(s),...>  Comma separated list of profiles to activate\n";
    print "                                 forcibly.\n";
    print "\n";
    print "    --compilation-template -T <template>\n";
    print "                                 Define a compilation template.\n";
    print "    --template, -t <template>    Define a generic template.\n";
    print "\n";
    print "    --userset, -u <var=value...> Set a user variable.\n";
    print "\n";

    return 1;
}

# template handling

sub choose_template {
    my ($datref) = @_;

    if (defined $datref->{compilation}
        && $datref->{compilation} ne $datref->{artist}) {

        return get_opt("comp_template");
    } else {
        return get_opt("template");
    }
}

sub __tokverify {
    my ($label, $name, $set, $unset) = @_;
    my ($rc);

    $rc = 1;
    if ($label eq 'CPLXDEFAULT') {
        $rc = 0 if (!defined $name || !defined $unset);
    } else {
        # ...CPLXSETUNSET...
        $rc = 0 if (!defined $name || !defined $unset || !defined $set);
    }

    return $rc;
}

sub __tokenize_sized {
    my ($in) = @_;

    my ($name, $size);

    if (($name, $size) = $in =~ m/^([\w\d]+)\[(\d+)\]$/) {
        my $data = {};
        $data->{name} = $name;
        $data->{size} = $size;
        return $data;
    }

    return;
}

sub __tokenize_complex {
    my ($label, $name, $set, $unset) = @_;
    my ($data);

    $data = {};
    $data->{name} = $name;

    if ($label eq 'CPLXDEFAULT') {
        $data->{default} = $unset;
        $data->{defaulttokens} = __tokenize_template($unset);
    } else {
        # ...CPLXSETUNSET...
        $data->{set} = $set;
        $data->{settokens} = __tokenize_template($set);
        $data->{default} = $unset;
        $data->{defaulttokens} = __tokenize_template($unset);
    }

    return $data;
}

sub __tokenize_check {
    my ($dat) = @_;

    # Tokenising stops as soon as a definite error is detected. Therefore,
    # we just need to take a look at $dat->[0]->[0] and see whether that's
    # an error message.
    return 0 if (defined $dat->[0]->[0] && $dat->[0]->[0] eq 'ERROR');
    return 1;
}

# Okay, here's how the data structure, created by the tokenizing process
# looks like:
#
# $result -> AoA
#            [ 'LABEL', $string, <<optional:more>> ],
#            ...
#
# where `LABEL' is one of:
#     - LITERAL
#     - TRIVIAL
#     - SIZED
#     - CPLXDEFAULT
#     - CPLXSETUNSET
#
# more -> hash
#     name:            name of the tag, which we're working on.
#     size:            if a size parameter was given, this is it.
#     default:         the string, which needs to be lexed, if `name' is unset.
#     set:             the string, which needs to be lexed, if `name' is set.
#     defaulttokens:   AoA of the lexed `default' string.
#     settokens:       AoA of the lexed `set' string.
## no critic (ProhibitExcessComplexity)
sub __tokenize_template {
    my ($in) = @_;
    my ($buf, $nest, $label, $out, $pos);
    my ($cplxbuf, $cplxset, $cplxunset, $seenunsetmark, $cplxname);
    my $EMPTY = q{};

    # Let's deal with empty strings at once.
    if ($in eq q{}) {
        return [ [ 'LITERAL', q{} ] ];
    }

    $buf = $EMPTY;
    $cplxbuf = $EMPTY;
    $cplxname = $EMPTY;
    $label = $EMPTY;
    $out = [];
    $nest = 0;
    $seenunsetmark = 0;
    pos($in) = (defined $pos) ? $pos : 0;

    while (pos($in) < length($in)) {
        # First we'll need to see if a backslash (our quotation mark) is
        # quoted itself by another backslash.
        if ($in =~ m/\G\\\\/gc) {
            $buf .= ($nest) ? q{\\\\} : q{\\};
            $cplxbuf .= ($nest) ? q{\\\\} : q{\\};

        # Since quoted backslashes are gone now, let's look at quoted
        # ampersands; that way, ampersands may be used in templates.
        } elsif ($in =~ m/\G\\\&/gc) {
            $buf .= ($nest) ? q{\\&} : q{&};
            $cplxbuf .= ($nest) ? q{\\&} : q{&};

        # If we've decided, that we're looking at a `CPLXSETUNSET' expansion,
        # we need to find the point where the "set" and the "unset" parts
        # are separated. That would be an unquoted exclamation mark. If we
        # haven't found the mark yet, a quoted exclamation mark should insert
        # an unquoted one.
        } elsif ($nest == 1 && $seenunsetmark
                 && $label eq 'CPLXSETUNSET' && $in =~ m/\G\\!/gc)
        {
            $buf .= q{!};
            $cplxbuf .= q{\\!};

        # Okay, here it is, an unquoted exclamation mark. Found the beginning
        # of the unset expression.
        } elsif ($nest == 1 && $label eq 'CPLXSETUNSET' && $in =~ m/\G!/gc) {
            $seenunsetmark = 1;
            $cplxset = $buf;
            $buf = $EMPTY;
            $cplxbuf .= q{!};

        # Now for stuff we can read at once:

        # The complex and simple sized expression types.
        } elsif (!$nest && ($in =~ m/\G\&[{]([\d\w]+\[\d+\])[}]/gc ||
                            $in =~ m/\G\&([\d\w]+\[\d+\])/gc))
        {
            my ($match, $more) = ($1, $EMPTY);
            push @{ $out }, [ 'LITERAL', $buf ] if ($buf ne $EMPTY);
            $more = __tokenize_sized($match);
            if (!defined $more) {
                return [ [ 'ERROR',
                           [ "Broken sized expression (at '$match')." ] ] ];
            }
            push @{ $out }, [ 'SIZED', $match, $more ];
            $buf = $EMPTY;

        # The trivial expression (the complex-looking one and the real deal).
        } elsif (!$nest && ($in =~ m/\G\&[{]([\d\w]+)[}]/gc ||
                            $in =~ m/\G\&([\d\w]+)/gc))
        {
            push @{ $out }, [ 'LITERAL', $buf ] if ($buf ne $EMPTY);
            push @{ $out }, [ 'TRIVIAL', $1 ];
            $buf = $EMPTY;

        # "&{" starts a "complex" tag expansion. Everything from
        # here on out needs to be copied literally until the matching
        # "}" is found. That is why the token-handling above looks
        # at `$nest', too.
        } elsif (!$nest && $in =~ m/\G\&[{]/gc) {
            $nest++;
            push @{ $out }, [ 'LITERAL', $buf ] if ($buf ne $EMPTY);
            $buf = $EMPTY;

        # When we're looking at a nested expression already, we need
        # to read the "&{" literally.
        } elsif ($nest && $in =~ m/\G\&[{]/gc) {
            $nest++;
            $buf .= q<&{>;
            $cplxbuf .= q<&{>;

        # A quoted curly brace (no matter where) needs to be read as
        # "}" and leave the nesting level in `$nest' untouched.
        } elsif ($in =~ m/\G\\}/gc) {
            $buf .= q<}>;

        # When we're looking at a nested expression, and we encounter
        # an unquoted "}", that means the nesting level needs to be
        # decreased. When we're reaching "$nest == 0", we just found the
        # matching brace for the "&{" which initially opened the
        # complex tag expression.
        } elsif ($nest && $in =~ m/\G}/gc) {
            $nest--;
            if ($nest == 0) {
                my ($more);
                $cplxunset = $buf;
                # Okay then. Found the matching closing curly brace. The
                # information is split already into `$cplxname', `$cplxset'
                # and `$cplxunset'. Let's verify everything looks sane...
                if (!__tokverify($label, $cplxname, $cplxset, $cplxunset)) {
                    return [ [ 'ERROR',
                               [ "Broken " .
                                 ($label ne q{} ? $label : 'generic') .
                                 " expression (at '$buf')." ] ] ];
                }

                # Recurse...
                $more = __tokenize_complex(
                    $label, $cplxname, $cplxset, $cplxunset);
                if (get_opt('verbosity') >= 10_000) {
                    $Data::Dumper::Indent = 3;
                    print Dumper($more);
                }
                my ($chk) = (0);
                if (!__tokenize_check($more->{settokens})) {
                    $out = [ [ 'ERROR', [ ] ] ];
                    push @{ $out->[0]->[1] },
                         @{ $more->{settokens}->[0]->[1] };
                    $chk++;
                }
                if (!__tokenize_check($more->{defaulttokens})) {
                    if ($chk == 0) {
                        $out = [ [ 'ERROR', [ ] ] ];
                    }
                    push @{ $out->[0]->[1] },
                         @{ $more->{defaulttokens}->[0]->[1] };
                    $chk++;
                }
                if ($chk > 0) {
                    push @{ $out->[0]->[1] }, "Broken $label expansion " .
                                            "(at '$buf').";
                    return $out;
                }

                # Reassemble the original expression for completeness.
                #$buf = __toktext($label, $cplxname, $cplxset, $cplxunset);
                push @{ $out }, [ $label, $cplxbuf, $more ];

                # Reset everything.
                $buf = $EMPTY;
                $label = $EMPTY;
                undef $cplxname;
                undef $cplxset;
                undef $cplxunset;
            } else {
                $buf .= q<}>;
                $cplxbuf .= q<}>;
            }

        # If `$label' is set already (meaning, we decided what type of
        # expression we're looking at - like `CPLXDEFAULT' or `LITERAL')
        # and `$nest' is set (which means we're looking at "CPLX*"), we
        # need to copy everything that wasn't handled above untouched.
        } elsif ($nest && $label ne $EMPTY && $in =~ m/\G(.)/gc) {
            $buf .= $1;
            $cplxbuf .= $1;

        # Alright, we're "complex", and after the tag-name there is a
        # colon. So that's `CPLXDEFAULT'.
        } elsif ($nest && $in =~ m/\G([\d\w]+):/gc) {
            $buf .= $1;
            $cplxbuf .= $1 . q<:>;
            $cplxname = $buf;
            $buf = $EMPTY;
            $label = "CPLXDEFAULT";

        # Like before, but since there's a `?' this is `CPLXSETUNSET'.
        } elsif ($nest && $in =~ m/\G([\d\w]+)[?]/gc) {
            $buf .= $1;
            $cplxbuf .= $1 . q<?>;
            $cplxname = $buf;
            $buf = $EMPTY;
            $label = "CPLXSETUNSET";

        # Anything quoted that's left now should go in without the quote,
        # because it doesn't bear any special meaning.
        } elsif ($in =~ m/\G\\(.)/gc) {
            $buf .= $1;

        # When we are here, we're not looking at anything special. So
        # just copy anything that doesn't look special into the current
        # token buffer.
        } elsif ($in =~ m/\G([^\\\&]*)/gc) {
            $buf .= $1;

        # Eat the rest, if we dropped until this point. Something is wrong.
        } else {
            $in =~ m/\G(.*)$/gc;
            push @{ $out }, [ 'ERROR', "REST: ($1)" ];
        }
    }

    if ($nest) {
        if (get_opt('verbosity') >= 10_000) {
            $Data::Dumper::Indent = 3;
            print Dumper($out);
        }
        if ($cplxname ne $EMPTY) {
            return [ [ 'ERROR',
                       [ "Broken complex expression (at '$cplxname).",
                         "Broken template! (at '$buf')" ] ] ];
        }
        return [ [ 'ERROR',
                   [ "Broken template! (at '$buf')" ] ] ];
    }
    push @{ $out }, [ 'LITERAL', $buf ] if ($buf ne $EMPTY);
    return $out;
}
## use critic

sub __tag_expand {
    my ($tag, $dat) = @_;
    my ($retval);

    run_hook('expand_template_pre_expand_tag', \$tag, $dat);
    if (get_opt('template_aliases') && defined $aliasmap{$tag}) {
        $tag = $aliasmap{$tag};
    }
    $retval = $dat->{$tag};
    if (!defined $retval) {
        run_hook('expand_template_unknown_tag', \$retval, \$tag, $dat);
    }
    return if (!defined $retval);
    __template_separator_replace($tag, \$retval);
    if ($tag eq 'tracknumber') {
        my ($pad);
        $pad = get_opt('tnpad');
        $retval = sprintf q{%0} . ($pad ne q{0} ? "$pad" : q{}) . q{d}, $retval;
    }
    run_hook('expand_template_post_expand_tag', \$retval, \$tag, $dat);

    return $retval;
}

sub __template_separator_replace {
    my ($tag, $strref) = @_;
    my ($sr);

    if ($ { $strref } =~ m{/}) {
        $sr = get_opt("sepreplace");
        op('template-found-separator', $tag, $sr);
        ${ $strref } =~ s{/}{$sr}g;
    }

    return 1;
}

# This traverses the data structure created by `__tokenize_template()' and
# actually expands the tag-expressions as needed.
sub __expand_tokens {
    my ($tok, $dat) = @_;
    my ($buf, $rtype, $tmp, $required);
    my $EMPTY = q{};

    $buf = $EMPTY;
    $required = sub {
        my ($tag) = @_;
        return "`$tag' not defined, but required by template.";
    };
    $rtype = 'DONE';
    TOKEN: foreach my $token (@{ $tok }) {
        my $type = $token->[0];
        if ($type eq 'ERROR') {
            $buf = [];
            push @{$buf},
                 '__expand_tokens(): BUG: ERROR should not be set here. ' .
                 'Was: (' . $token->[1] . ')';
            $rtype = 'ERROR';
            last TOKEN;

        } elsif ($type eq 'LITERAL') {
            $buf .= $token->[1];

        } elsif ($type eq 'TRIVIAL') {
            $tmp = __tag_expand($token->[1], $dat);;
            if (!defined $tmp) {
                $buf = [];
                push @{ $buf }, $required->($token->[1]);
                $rtype = 'ERROR';
                last TOKEN;
            }
            $buf .= $tmp;

        } elsif ($type eq 'SIZED') {
            my $name = $token->[2]->{name};
            $tmp = __tag_expand($name, $dat);;
            if (!defined $tmp) {
                $buf = [];
                push @{ $buf }, $required->($token->[1]);
                $rtype = 'ERROR';
                last TOKEN;
            }
            $buf .= substr $tmp, 0, $token->[2]->{size};

        } elsif ($type eq 'CPLXDEFAULT') {
            my ($rv);
            $tmp = __tag_expand($token->[2]->{name}, $dat);;
            if (defined $tmp) {
                $buf .= $tmp;
            } else {
                $rv = __expand_tokens($token->[2]->{defaulttokens}, $dat);
                if ($rv->[0] eq 'ERROR') {
                    $rtype = 'ERROR';
                    $buf = [];
                    push @{ $buf }, 'Error expanding ' . $token->[2]->{default};
                    last TOKEN;
                }
                $buf .= $rv->[1];
            }

        } elsif ($type eq 'CPLXSETUNSET') {
            my ($rv, $str, $strtok);
            $tmp = __tag_expand($token->[2]->{name}, $dat);;
            if (defined $tmp) {
                $str = $token->[2]->{set};
                $strtok = $token->[2]->{settokens};
            } else {
                $strtok = $token->[2]->{defaulttokens};
            }
            $rv = __expand_tokens($strtok, $dat);
            if ($rv->[0] eq 'ERROR') {
                $rtype = 'ERROR';
                $buf = [];
                push @{ $buf }, 'Error expanding ' . $str;
                last TOKEN;
            }
            $buf .= $rv->[1];
        } else {
            $buf = [];
            push @{ $buf }, 'Unknown token-type: ', $type;
            last TOKEN;
        }
    }
    return [ $rtype, $buf ]
}

sub __tokenize_error {
    my ($data) = @_;

    if (!__tokenize_check($data)) {
        foreach my $err (@{ $data->[0]->[1] }) {
            op('tokenize-error', $err);
        }
        return 1;
    }
    return 0;
}

sub expand_template {
    my ($template, $datref) = @_;
    my ($data, $retval, $expanded);

    run_hook('pre_expand_template', \$template, $datref);

    $data = __tokenize_template($template);
    if (get_opt('verbosity') >= 10_000) {
        $Data::Dumper::Indent = 3;
        print Dumper($data);
    }
    return if (__tokenize_error($data));
    $retval = __expand_tokens($data, $datref);
    if ($retval->[0] eq 'ERROR') {
        op('expand-template-file', get_file_printable());
        foreach my $err (@{ $retval->[1] }) {
            op('expand-template-error', $err);
        }
        return;
    }
    $expanded = $retval->[1];

    run_hook('post_expand_template', \$expanded, $datref);

    return $expanded;
}

sub __template_tag_cant_work {
    my ($tag) = @_;
    my ($ta, $opt);

    $ta = tag_aliased($tag);
    $opt = get_opt('template_aliases');
    if ($ta && !$opt) {
        op('tag-alias-without-option', $tag, $aliasmap{$tag});
        return 1;
    } elsif ($ta && $opt) {
        return 0;
    }
    if (!tag_supported($tag)) {
        op('unknown-tag', $tag);
        return 1;
    }
    return 0;
}

sub __template_deep_inspect {
    my ($data) = @_;
    my ($ret);

    $ret = 1;
    TOKEN: foreach my $token (@{ $data }) {
        my $type = $token->[0];
        my ($tag);

        if (defined $token->[2]->{name}) {
            $tag = $token->[2]->{name};
        } else {
            $tag = $token->[1];
        }
        if ($type eq 'ERROR') {
            op('bug', '__template_deep_inspect(): ' .
                      'BUG: ERROR should not be set. ' .
                      'here. Was: (' . $token->[1] . ')');
            exit 1;
        } elsif ($type eq 'LITERAL') {
            # Cannot fail. Yes, I've said it. :)
            next TOKEN;
        } elsif ($type eq 'TRIVIAL' || $type eq 'SIZED') {
            if (__template_tag_cant_work($tag)) {
                op('deep-inspect-fail');
                $ret = 0;
                next TOKEN;
            }
        } elsif ($type eq 'CPLXDEFAULT') {
            if (__template_tag_cant_work($tag)) {
                op('deep-inspect-always', 'default');
                $ret = 0;
            }
            if (!__template_deep_inspect($token->[2]->{defaulttokens})) {
                $ret = 0;
            }
        } elsif ($type eq 'CPLXSETUNSET') {
            if (__template_tag_cant_work($tag)) {
                op('deep-inspect-always', 'unset');
                $ret = 0;
            }
            if (!__template_deep_inspect($token->[2]->{settokens})) {
                $ret = 0;
            }
            if (!__template_deep_inspect($token->[2]->{defaulttokens})) {
                $ret = 0;
            }
        } else {
            op('deep-inspect-unknown-token', $type);
            $ret = 0;;
        }
    }

    return $ret;
}

sub template_deep_inspect {
    my ($template) = @_;
    my ($data, $retval);

    $data = __tokenize_template($template);
    return -1 if (__tokenize_error($data));
    return 0 if (!__template_deep_inspect($data));
    return 1;
}

# output subroutines

sub make_format {
    my (@args) = @_;
    my ($ret);

    $ret = q{};
    foreach my $part (@args) {
        my $str = shift @{ $part };
        my $attr = join q{}, @{ $part };
        $ret .= $attr . $str;
    }

    return $ret;
}

my (%formats, $op_last_format);
BEGIN {
    # $ANSI_COLORS_DISABLED needs to be set before any Term::ANSIColor
    # procedures have been used. So, let's do it here, as early as possible.
    if (defined $ENV{'ARENAME_SUPPRESS_COLOURS'}
        && $ENV{'ARENAME_SUPPRESS_COLOURS'} eq '1')
    {
        ## Need to disable perlcritic here, because we really don't
        ## want to have to `local' `%ENV' here.
        ## no critic (RequireLocalizedPunctuationVars)
        $ENV{'ANSI_COLORS_DISABLED'} = q{yes};
        ## use critic
        $conf{suppress_colours} = 1;
    } else {
        $conf{suppress_colours} = 0;
    }

    # We need to set `verbosity' very very early so everything can output stuff
    # very early, too, without Perl warnings.
    $conf{verbosity} = 10;
    $op_last_format = 'newline';

    # `%formats' also needs to be assigned from within "BEGIN", because we are
    # using actual code to set the `format' keys. And thed needs to be executed
    # by force.
    %formats = (
        "bug" => {
            verbosity => -1,
            argn => 2,
            format => make_format(
                [ q{ -!- }, BOLD, WHITE ],
                [ q{BUG: }, BOLD, RED ],
                [ q{%s }, RESET ],
                [ q{%s}, MAGENTA ],
                [ qq{\n}, RESET ]),
        },
        "mkdir" => {
            verbosity => 20,
            argn => 1,
            format => make_format(
                [ q{mkdir "}, RESET ],
                [ q{%s}, CYAN ],
                [ qq{"\n}, RESET ]),
        },
        "mkdir-fail" => {
            verbosity => 5,
            argn => 2,
            format => make_format(
                [ qq{Could not mkdir(%s).\n}, RED ],
                [ qq{Reason: %s\n}, RESET ]),
        },
        "debug" => {
            verbosity => 10_000,
            argn => 1,
            format => make_format(
                [ q{DEBUG:}, BOLD, RED],
                [ q{ }, RESET ],
                [ q{%s}, RED ],
                [ qq{}, RESET ]),
        },
        "rename" => {
            verbosity => 20,
            argn => 3,
            format => make_format(
                [ q{%s}, YELLOW ],
                [ q{ '}, RESET ],
                [ q{%s}, BOLD, BLUE ],
                [ q{' }, RESET ],
                [ qq{\\\n   }, RESET ],
                [ q{'}, RESET ],
                [ q{%s}, GREEN ],
                [ qq{'\n}, RESET ]),
        },
        "skip" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Skipping:}, YELLOW ],
                [ q{ '}, RESET ],
                [ q{%s}, BOLD, BLUE ],
                [ qq{'\n}, RESET ]),
        },
        "skip-same" => {
            verbosity => 20,
            argn => 1,
            format => make_format(
                [ q{'} ],
                [ q{%s}, BOLD, BLUE ],
                [ qq{'\n      }, RESET ],
                [ qq{would stay the way it is, skipping.\n} ]
            ),
        },
        "tag-alias-without-option" => {
            verbosity => 5,
            argn => 2,
            format => make_format(
                [ q{`}, RESET ],
                [ q{%s}, GREEN ],
                [ q{' is an alias for `}, RESET ],
                [ q{%s}, GREEN ],
                [ q{' but `}, RESET ],
                [ q{template_aliases}, CYAN ],
                [ qq{' is disabled.\n}, RESET ]),
        },
        "tag-list" => {
            verbosity => 20,
            argn => 2,
            format => make_format(
                [ qq{%12s: %s\n}, RESET ]
            ),
        },
        "deprecated-variable" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{DEPRECATED OPTION: }, RED ],
                [ q{`}, RESET ],
                [ q{%s}, BOLD, RED ],
                [ qq{'\n}, RESET ],
[ qq{   This option does nothing and will be removed in a later release.\n},
  RESET ],
[ qq{   See the UPGRADING file for details.\n},
  RESET ])},
        "deprecated-function" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Using deprecated function: }, RED ],
                [ q{%s}, CYAN ],
                [ qq{\n}, RESET ],
                [ qq{This function will be removed in an upcoming release.\n} ]),
        },
        # options
        "auto-dry-run" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Encountered warnings in }, RESET ],
                [ q{%s}, CYAN ],
                [ qq{, enabling `dryrun'.\n}, RESET ],
                [ qq{  (See `warningsautodryrun' option for details.)\n} ]),
        },
        "copymode" => {
            verbosity => 5,
            argn => 0,
            format => make_format(
                [ q{+++}, BOLD, GREEN ],
                [ qq{ copymode enabled\n}, RESET ]),
        },
        "readstdin" => {
            verbosity => 5,
            argn => 0,
            format => make_format(
                [ q{+++}, BOLD, GREEN ],
                [ qq{ reading stdin for filenames (after \@ARGV)\n}, RESET ]),
        },
        "skip-symlink" => {
            verbosity => 10,
            argn => 1,
            format => make_format(
                [ q{Refusing to handle symbolic links: "}, RESET ],
                [ q{%s}, RED ],
                [ qq{"\n}, RESET ]),
        },
        "suppress-skips" => {
            verbosity => 5,
            argn => 0,
            format => make_format(
                [ q{+++}, BOLD, GREEN ],
                [ qq{ suppressing unchanged file skips\n}, RESET ]),
        },
        "verbosity" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{+++}, BOLD, GREEN ],
                [ q{ verbosity is at }, RESET ],
                [ q{%s}, GREEN ],
                [ qq{.\n}, RESET ]),
        },
        # cmdline handling
        "cmdline-missing-arg" => {
            verbosity => 0,
            argn => 1,
            format => make_format(
                [ q{-}, RESET ],
                [ q{%s}, GREEN ],
                [ qq{ requires a string argument.\n}, RESET ]
            ),
        },
        "cmdline-opt-req-int" => {
            verbosity => 0,
            argn => 2,
            format => make_format(
                [ q{The `%s' option requires an integer argument.}, RESET ],
                [ q{ (Got "%s")}, RED ],
                [ qq{\n}, RESET ]),
        },
        # extension code messages
        "version-mismatch" => {
            verbosity => 0,
            argn => 4,
            format => make_format(
                [ q{Version mismatch between `}, RESET ],
                [ q{%s}, RED ],
                [ q{' and }, RESET ],
                [ q{ARename}, RED ],
                [ qq{.\n}, RESET ],
                [ q{  %s}, YELLOW ],
                [ qq{: ARename::VERSION\n}, RESET ],
                [ q{  %s}, YELLOW ],
                [ q{: %s}, RESET ],
                [ qq{\n}, RESET ]),
        },
        # input file processing
        "quoted-file" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ qq{'%s'\n}, RESET ]),
        },
        "file-read-error" => {
            verbosity => 5,
            argn => 2,
            format => make_format(
                [ q{Can't read "%s": }, RESET ],
                [ q{%s}, RED ],
                [ qq{\n}, RESET ]
            ),
        },
        "processing-file" => {
            verbosity => 20,
            argn => 1,
            format => make_format(
                [ q{Processing:}, MAGENTA ],
                [ q{ "}, RESET ],
                [ q{%s}, YELLOW ],
                [ qq{"\n}, RESET ]),
        },
        "target-exists" => {
            verbosity => 10,
            argn => 1,
            format => make_format(
                [ q{%s}, CYAN ],
                [ qq{ exists. Use -f to force overriding.\n}, RESET ]),
        },
        "target-exists-twoline" => {
            verbosity => 10,
            argn => 1,
            format => make_format(
                [ q{%s}, CYAN ],
                [ qq{ exists.\n    Use -f to force overriding.\n}, RESET ]),
        },
        "template-found-separator" => {
            verbosity => 20,
            argn => 2,
            format => make_format(
                [ q{Found directory separator in `}, RESET ],
                [ q{%s}, CYAN ],
                [ qq{'.\nReplacing with "}, RESET ],
                [ q{%s}, BOLD, BLUE ],
                [ qq{".\n}, RESET ]),
        },
        "no-method" => {
            verbosity => 10,
            argn => 1,
            format => make_format(
                [ q{No method for handling `}, RESET ],
                [ q{%s}, RED ],
                [ qq{'\n}, RESET ]),
        },
        # template expansion
        "check-template" => {
            verbosity => 20,
            argn => 1,
            format => make_format(
                [ q{Checking template "}, RESET ],
                [ q{%s}, GREEN ],
                [ qq{"\n}, RESET ]),
        },
        "check-comp-template" => {
            verbosity => 20,
            argn => 1,
            format => make_format(
                [ q{Checking compilation template "}, RESET ],
                [ q{%s}, GREEN ],
                [ qq{"\n}, RESET ]),
        },
        "deep-inspect-always" => {
            verbosity => 10,
            argn => 1,
            format => make_format(
                [ q{This expansion will always use the `}, RESET ],
                [ q{%s}, CYAN ],
                [ qq{' value.\n}, RESET ]
            ),
        },
        "deep-inspect-fail" => {
            verbosity => 10,
            argn => 0,
            format => make_format(
                [ qq{This expansion will fail everytime.\n}, RESET ]
            ),
        },
        "deep-inspect-unknown-token" => {
            verbosity => 10,
            argn => 1,
            format => make_format(
                [ q{Unknown token-type: `}, RESET ],
                [ q{%s}, RED ],
                [ qq{' value.\n}, RESET ]
            ),
        },
        "error-any-template" => {
            verbosity => 5,
            argn => 0,
            format => make_format(
                [ qq{Inspecting a template failed. Giving up.\n}, RESET ]
            ),
        },
        "error-comp-template" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Error(s) inspecting comp_template: }, RESET ],
                [ q{%s}, CYAN ],
                [ qq{\n}, RESET ]
            ),
        },
        "error-template" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Error(s) inspecting template: }, RESET ],
                [ q{%s}, CYAN ],
                [ qq{\n}, RESET ]
            ),
        },
        "expand-template-file" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ qq{Error expanding template:\n}, YELLOW, BOLD, ON_BLACK ],
                [ q{File}, RESET, RED ],
                [ q{: %s (}, RESET ],
                [ qq{Skipping}, YELLOW, ON_BLACK ],
                [ qq{)\n}, RESET ]),
        },
        "expand-template-error" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Expansion-error:}, YELLOW, ON_BLACK ],
                [ qq{ %s}, MAGENTA ],
                [ qq{\n}, RESET ]),
        },
        "more-than-one-tag" => {
            verbosity => 10,
            argn => 2,
            format => make_format(
                [ q{%s has more than one `}, RESET ],
                [ q{%s}, CYAN ],
                [ qq{' tag:\n}, RESET]),
        },
        "more-than-one-tag-value" => {
            verbosity => 10,
            argn => 1,
            format => make_format(
                [ qq{'    %s\n}, RESET]),
        },
        "tokenize-error" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ qq{%s\n}, RESET ]),
        },
        "unknown-tag" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Unknown tag: `}, RESET ],
                [ q{%s}, RED ],
                [ qq{'\n}, RESET ]),
        },
        "warnings-while-scanning-file" => {
            verbosity => 5,
            argn => 0,
            format => make_format(
                [ qq{Warnings while gathering data. Skipping file.\n}, YELLOW ],
                [ qq{\n}, RESET ]),
        },
        # rcfile loading
        "default-set-value" => {
            verbosity => 20,
            argn => 2,
            format => make_format(
                [ q{Setting "}, RESET ],
                [ q{%s}, CYAN ],
                [ q{" to "}, RESET ],
                [ q{%s}, BOLD, GREEN ],
                [ qq{"\n}, RESET ]
            ),
        },
        "dryrun" => {
            verbosity => 5,
            argn => 0,
            format => make_format(
                [ q{+++}, BOLD, GREEN ],
                [ qq{ dryrun mode enabled\n}, RESET ]
            ),
        },
        "no-configuration" => {
            verbosity => 20,
            argn => 0,
            format => make_format(
                [ qq{Main configuration not found. Using defaults.\n}, RESET ]),
        },
        "rcload-error-abort" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Error(s) in %s. }, RESET ],
                [ q{Aborting.}, RED ],
                [ qq{\n}, RESET ]),
        },
        "rcload-error-warn" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ qq{Error opening configuration file "%s".\n}, RESET ]),
        },
        "rcload-close-fail" => {
            verbosity => 5,
            argn => 2,
            format => make_format(
                [ q{Failed to close %s}, RED ],
                [ qq{.\n}, RESET ],
                [ qq{Reason: %s\n}, RESET ]),
        },
        "rcload-open-fail" => {
            verbosity => 5,
            argn => 3,
            format => make_format(
                [ q{Failed to read %s }, RED ],
                [ q{(}, RESET ],
                [ q{%s}, CYAN ],
                [ qq{).\n}, RESET ],
                [ qq{Reason: %s\n}, RESET ]),
        },
        "rcload-reading" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Reading `%s'...}, RESET ],
                [ qq{\n}, RESET ]),
        },
        "rcload-stats" => {
            verbosity => 5,
            argn => 2,
            format => make_format(
                [ q{Read }, RESET ],
                [ q{%s}, CYAN ],
                [ qq{.\n}, RESET ],
                [ q{%s}, GREEN ],
                [ qq{ valid items.\n}, RESET]),
        },
        "rcload-warnings" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{%s}, YELLOW ],
                [ qq{ warnings.\n}, RESET]),
        },
        "rc-invalid-line" => {
            verbosity => 5,
            argn => 3,
            format => make_format(
                [ qq{%s,%s: invalid line: %s\n}, RESET ]),
        },
        "rc-unknown-line" => {
            verbosity => 5,
            argn => 3,
            format => make_format(
                [ qq{unknown-line:%s,%s: %s\n}, RESET ]),
        },
        "rc-line-warning" => {
            verbosity => 5,
            argn => 3,
            format => make_format(
                [ qq{warning:%s,%s: %s\n}, RESET ]),
        },
        "rc-opt-not-localizable" => {
            verbosity => 5,
            argn => 2,
            format => make_format(
                [ q{`}, RESET ],
                [ q{%s}, CYAN ],
                [ q{' cannot be used in sections }, RESET ],
                [ q{(it will not be set to "}, RESET ],
                [ q{%s}, BOLD, BLUE ],
                [ qq{").\n}, RESET ]),
        },
        "rc-overridden-by-cmdline" => {
            verbosity => 10,
            argn => 1,
            format => make_format(
                [ q{`}, RESET ],
                [ q{%s}, CYAN ],
                [ qq{' was set on the command line. Not overriding.\n}, RESET]),
        },
        "rc-profile-missing" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Profile "}, RESET ],
                [ q{%s}, CYAN ],
                [ qq{" active, but no configuration found.\n}, RESET ]),
        },
        "rc-switch-section" => {
            verbosity => 20,
            argn => 1,
            format => make_format(
                [ q{Switching section: `}, RESET ],
                [ q{%s}, MAGENTA ],
                [ qq{'\n}, RESET ]),
        },
        "parse-boolean-print" => {
            verbosity => 20,
            argn => 2,
            format => make_format(
                [ q{Boolean option "}, RESET ],
                [ q{%s}, CYAN ],
                [ q{" = `}, RESET ],
                [ q{%s}, BOLD, GREEN ],
                [ qq{'\n}, RESET ]),
        },
        "parse-default-unknown-tag" => {
            verbosity => 5,
            argn => 3,
            format => make_format(
                [ q{%s,%s: Default for unsupported tag found: `}, RESET ],
                [ q{%s}, RED ],
                [ qq{'\n}, RESET ]),
        },
        "parse-default-tag-print" => {
            verbosity => 20,
            argn => 2,
            format => make_format(
                [ q{Default for "}, RESET ],
                [ q{%s}, CYAN ],
                [ q{" = "}, RESET ],
                [ q{%s}, BOLD, GREEN ],
                [ qq{"\n}, RESET ]),
        },
        "parse-bool-broken" => {
            verbosity => 5,
            argn => 4,
            format => make_format(
                [ q{%s,%s: }, RESET ],
                [ q{Broken boolean for `%s': "}, RESET ],
                [ q{%s}, RED ],
                [ qq{"\n}, RESET ]),
        },
        "parse-int-broken" => {
            verbosity => 5,
            argn => 4,
            format => make_format(
                [ q{%s,%s: }, RESET ],
                [ q{Broken integer for `%s': "}, RESET ],
                [ q{%s}, RED ],
                [ qq{"\n}, RESET ]),
        },
        "parse-int-print" => {
            verbosity => 20,
            argn => 2,
            format => make_format(
                [ q{Integer option "}, RESET ],
                [ q{%s}, CYAN ],
                [ q{" = "}, RESET ],
                [ q{%s}, BOLD, GREEN ],
                [ qq{"\n}, RESET ]),
        },
        "parse-string-print" => {
            verbosity => 20,
            argn => 2,
            format => make_format(
                [ q{String option "}, RESET ],
                [ q{%s}, CYAN ],
                [ q{" = "}, RESET ],
                [ q{%s}, BOLD, GREEN ],
                [ qq{"\n}, RESET ]),
        },
        "parse-userset-print" => {
            verbosity => 20,
            argn => 2,
            format => make_format(
                [ q{User-defined setting}, BOLD, BLUE ],
                [ q{: "}, RESET ],
                [ q{%s}, CYAN ],
                [ q{" = "}, RESET ],
                [ q{%s}, BOLD, GREEN ],
                [ qq{"\n}, RESET ]),
        },
        "profile-add-pattern" => {
            verbosity => 20,
            argn => 2,
            format => make_format(
                [ q{Adding pattern "}, RESET ],
                [ q{%s}, CYAN ],
                [ q{" to profile `}, RESET ],
                [ q{%s}, BOLD, GREEN ],
                [ qq{'.\n}, RESET ]),
        },
        "profile-disallowed-chars" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Disallowed characters in profile name: "}, RESET ],
                [ q{%s}, RED ],
                [ qq{"\n}, RESET ]),
        },
        "profile-parse-fail" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Could not find config file for profile `}, RESET ],
                [ q{%s}, CYAN ],
                [ qq{'.\n}, RESET ]),
        },
        "profile-missing-config" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Could not parse profile value "}, RESET ],
                [ q{%s}, RED ],
                [ qq{".\n}, RESET ]),
        },
        "section-broken-start" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Broken section start: "}, RESET ],
                [ q{%s}, RED ],
                [ qq{"\n}, RESET ]),
        },
        "user-setting-broken" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Broken user setting: "}, RESET ],
                [ q{%s}, RED ],
                [ qq{"\n}, RESET ]),
        },
        # hook files
        "hooks-file-parse-error" => {
            verbosity => 5,
            argn => 2,
            format => make_format(
                [ q{Could not parse hooks file }, RED ],
                [ qq{`}, RESET ],
                [ q{%s}, BOLD, RED ],
                [ qq{':\n}, RESET ],
                [ qq{  - %s\n}, RESET ]),
        },
        "hooks-file-read-error" => {
            verbosity => 5,
            argn => 2,
            format => make_format(
                [ q{Could not read hooks file }, RED ],
                [ qq{`}, RESET ],
                [ q{%s}, BOLD, RED ],
                [ qq{':\n}, RESET ],
                [ qq{  - %s\n}, RESET ]),
        },
        "hooks-non-true" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Reading hooks file "%s" did }, RESET ],
                [ q{NOT}, RED ],
                [ qq{ return 1.\n}, RED ],
[ qq{  While this is not a fatal problem, it is good practice, to let\n},
  RESET ],
[ qq{  perl script files return 1. Just put a '1;' into the last line\n},
  RESET ],
[ qq{  of this file to get rid of this warning. Subroutines like\n},
  RESET ],
[ qq{  register_hook() and remove_hook() return 1 by default, so sticking\n},
  RESET ],
[ qq{  them into the last line of the file will do the trick, too.\n},
  RESET ]),
        },
        "hooks-no-such-file" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Hook file }, RESET ],
                [ q{not found}, RED ],
                [ qq{: %s\n}, RESET ]),
        },
        "hooks-file-read" => {
            verbosity => 20,
            argn => 1,
            format => make_format(
                [ q{Hook file read ("}, RESET ],
                [ q{%s}, CYAN ],
                [ qq{").\n}, RESET ]),
        },
        "hooks-register-undefined" => {
            verbosity => 5,
            argn => 1,
            format => make_format(
                [ q{Trying to register }, RESET ],
                [ q{undefined subroutine}, RED ],
                [ q{ in namespace `}, RESET ],
                [ q{%s}, CYAN ],
                [ q{'.}, RESET ],
                [ q{ Ignoring}, YELLOW ],
                [ qq{\n}, RESET ]),
        },
        "newline" => {
            verbosity => 5,
            argn => 0,
            format => make_format( [ qq{\n}, RESET ] ),
        },
    );
}

sub got_format {
    my ($fname) = @_;
    return 0 if (!defined $formats{$fname});
    return 1;
}

sub op {
    # op('debug', "Oh crap, something just hit the fan.");
    my ($type, @args) = @_;
    my ($argn, $fmt);

    if (!defined $formats{$type}) {
        # `bug' type better be available. :)
        op('bug', 'Undefined format', $type);
        return 0;
    }

    $argn = $formats{$type}->{argn};
    $fmt = $formats{$type}->{format};
    if ($argn != ($#args + 1)) {
        op('bug', 'Wrong number of arguments',
           "expected " . $argn . ", got " . ($#args + 1));
        return 0;
    }
    return 0 if ($op_last_format eq 'newline' && $type eq 'newline');
    if (!defined $formats{$type}->{verbosity}) {
        op('bug', "Missing verbosity tag in format entry", "$type");
        return 0;
    }
    return 0 if ($conf{verbosity} < $formats{$type}->{verbosity});
    $op_last_format = $type;
    printf $fmt, @args;
    return 1;
}

sub oprint {
    my ($string) = @_;

    op('deprecated-function', 'oprint');
    print $string;
    return 1;
}

sub owarn {
    my ($string) = @_;

    op('deprecated-function', 'owarn');
    warn($string);
    return 1;
}

# config file processing

Readonly::Scalar my $FIND_RC => 0;              # find .arenamerc
Readonly::Scalar my $FIND_HOOKS => 1;           # find .arename.hooks
Readonly::Scalar my $FIND_PROFRC => 2;          # find .arename.profilename
Readonly::Scalar my $FIND_PROFHOOKS => 3;       # find .arename.profilename.hooks
Readonly::Scalar my $FIND_NONAME => q{};        # file name to find not further specified

sub __home_find_file {
    # TODO: Someone should clean this up. Seriously.
    my ($home, $name, $dotname) = @_;
    my ($etcdir, $dotdir, $fn, $xdg);

    $etcdir = "$home/etc/arename";
    $dotdir = "$home/.arename";

    # Support for $XDG_CONFIG_HOME.
    if (defined $ENV{'XDG_CONFIG_HOME'}) {
        $xdg= $ENV{'XDG_CONFIG_HOME'} . '/arename';
        if (-d $xdg) {
            op('debug', qq{__home_find_file() using "$xdg"\n});
            $fn = "$xdg/$name";

            if (-e $fn) {
                return $fn;
            } else {
                goto ERROR;
            }
        }
    }
    $xdg = "$home/.config/arename";

    # If $XDG_CONFIG_HOME didn't stick, use the old ways:
    # if ~/etc/arename/ exists, we read *everything* from there.
    # if not, but ~/.arename/, we read everything from there.
    # if both are not there, we're looking for stuff like ~/.arenamerc.
    if (-d $etcdir) {
        op('debug', qq{__home_find_file() using "$etcdir"\n});
        $fn = "$etcdir/$name";

        if (-e $fn) {
            return $fn;
        }
    } elsif (-d $xdg) {
        op('debug', qq{__home_find_file() using "$xdg"\n});
        $fn = "$xdg/$name";

        if (-e $fn) {
            return $fn;
        }
    } elsif (-d $dotdir) {
        op('debug', qq{__home_find_file() using "$dotdir"\n});
        $fn = "$dotdir/$name";

        if (-e $fn) {
            return $fn;
        }
    } else {
        op('debug', qq{__home_find_file() using "$home"\n});
        $fn = "$home/$dotname";

        if (-e $fn) {
            return $fn;
        }
    }

ERROR:
    return q{};
}

sub home_find_file {
    my ($code, $spec) = @_;
    my ($name, $home);

    $home = $ENV{'HOME'};
    $home =~ s/\/+$//;

    if ($code == $FIND_RC) {
        $name = __home_find_file($home, 'rc', '.arenamerc');
    } elsif ($code == $FIND_HOOKS) {
        $name = __home_find_file($home, 'hooks', '.arename.hooks');
    } elsif ($code == $FIND_PROFRC) {
        $name = __home_find_file(
            $home,
            sprintf('profile.%s', $spec),
            sprintf('.arename.%s', $spec)
        );
    } elsif ($code == $FIND_PROFHOOKS) {
        $name = __home_find_file(
            $home,
            sprintf('profile.%s.hooks', $spec),
            sprintf('.arename.%s.hooks', $spec)
        );
    } else {
        op('bug', "home_find_file(): unknown code ($code). Please report!\n");
    }

    op('debug', qq{home_find_file($code, "$spec") returning ($name)\n});
    return $name;
}

sub __is_comment_or_blank {
    my ($string) = @_;

    if ($string =~ m/^\s*#/ || $string =~ m/^\s*$/) {
        return 1;
    }

    return 0;
}

sub __remove_leading_backslash {
    my ($strref) = @_;

    if (defined ${ $strref }) {
        ${ $strref } =~ s/^\\//;
    }
    return 1;
}

sub __remove_leading_whitespace {
    my ($strref) = @_;

    ${ $strref } =~ s/^\s*//;
    return 1;
}

sub __rcload_stats {
    my ($desc, $count, $warnings) = @_;

    if (!get_opt('load_quiet')) {
        op('rcload-stats', $desc, $count);
    }
    if ($warnings > 0) {
        op('rcload-warnings', $warnings);
        if (get_opt('warningsautodryrun') && !get_opt('dryrun')) {
            op('auto-dry-run', $desc);
            set_opt('dryrun', 1);
        }
    }

    return 1;
}

sub __rcload {
    my ($file, $desc) = @_;
    my ($fh, $retval);
    my ($count, $warnings, $lnum) = (0, 0, 0);

    if (!open($fh, q{<}, $file)) {    ## no critic (RequireBriefOpen)
        ## use critic
        op('rcload-open-fail', $desc, $file, $ERRNO);
        return 1;
    }

    op('rcload-reading', $file) if (!get_opt('load_quiet'));

    while (my $line = <$fh>) {
        chomp $line;
        $lnum++;

        if (__is_comment_or_blank($line)) {
            next;
        }

        __remove_leading_whitespace(\$line);

        my ($key,$val) = split /\s+/, $line, 2;

        __remove_leading_backslash(\$val);

        $retval = parse($file, $lnum, $count, $key, $val);
        if ($retval < 0) {
            op('rc-invalid-line', $file, $lnum, $line);
            return -1;
        } elsif ($retval > 1) {
            op('rc-unknown-line', $file, $lnum, $line);
            $warnings++;
        } elsif ($retval > 0) {
            op('rc-line-warning', $file, $lnum, $line);
            $warnings++;
        } else {
            $count++;
        }
    }
    close $fh or op('rcload-close-fail', $file, $ERRNO);

    sect_reset();
    __rcload_stats($desc, $count, $warnings);

    return 0;
}

sub rcload {
    my ($rc, $desc) = @_;
    my ($retval);

    $retval = __rcload($rc, $desc);

    if ($retval < 0) {
        op('rcload-error-abort', $rc);
        exit(1);
    } elsif ($retval > 0) {
        op('rcload-error-warn', $rc);
    }

    return 1;
}

sub read_rcs {
    my ($rc);

    if (cmdopts("rc")) {
        $rc = cmdoptstr("rc");
    } else {
        $rc = home_find_file($FIND_RC, $FIND_NONAME);
    }

    if ($rc eq q{}) {
        op('no-configuration');
    } else {
        rcload($rc, "main configuration");
    }

    if (cmdopts("post-rc")) {
        $rc = cmdoptstr("post-rc");
        rcload($rc, "additional configuration");
    }

    if (get_opt('useprofiles')) {
        foreach my $profile (get_profile_list()) {
            $rc = home_find_file($FIND_PROFRC, $profile);
            if ($rc ne q{}) {
                rcload($rc, qq{configuration for profile "$profile"});
            } else {
                op('rc-profile-missing', $profile);
            }
        }
    }

    if (get_opt('uselocalrc') && -r "./.arename.local") {
        $rc = "./.arename.local";
        rcload($rc, "local configuration");
    }

    return 1;
}

%parsers = (
    '^\s*\[.*\]\s*$'        => \&parse_new_section,
    '^ambiguoususefirst$'   => \&parse_bool,
    '^canonicalize$'        => \&parse_bool,
    '^copymode$'            => \&parse_bool,
    '^checkprofilerc$'      => \&parse_bool,
    '^checktemplatesinitially$' => \&parse_bool,
    '^comp_template$'       => \&parse_string,
    '^default_.*$'          => \&parse_defaultvalues,
    '^debug$'               => \&parse_deprecate_off,
    '^hookerrfatal$'        => \&parse_bool,
    '^prefix$'              => \&parse_string,
    '^profile$'             => \&parse_profile,
    '^quiet$'               => \&parse_deprecate_off,
    '^quiet_skip$'          => \&parse_deprecate_off,
    '^suppress_skips$'      => \&parse_bool,
    '^sepreplace$'          => \&parse_string,
    '^set$'                 => \&parse_set,
    '^template$'            => \&parse_string,
    '^template_aliases$'    => \&parse_bool,
    '^tnpad$'               => \&parse_integer,
    '^usehooks$'            => \&parse_bool,
    '^uselocalhooks$'       => \&parse_bool,
    '^uselocalrc$'          => \&parse_bool,
    '^usetypeasextension$'  => \&parse_bool,
    '^useprofiles$'         => \&parse_bool,
    '^verbose$'             => \&parse_deprecate_off,
    '^verbosity$'           => \&parse_integer,
    '^warningsautodryrun$'  => \&parse_bool,
);

sub parse {
    my ($file, $lnum, $count, $key, $val) = @_;

    foreach my $pattern (sort keys %parsers) {
        if ($key =~ m/$pattern/) {

            return $parsers{$pattern}->(
                        $file, $lnum, $count,
                        $key, (defined $val ? $val : q{})
                   );
        }
    }

    # return 2, to tell __rcload() that we had no parser, which matched
    # this line, unknown lines should be warnings, not fatal error.
    return 2;
}

# parser sub functions
#   return values:
#       all okay: =0
#       warning : >0
#       fatal   : <0

sub parse_deprecate_off {
    my ($file, $lnum, $count, $key, $val) = @_;
    op('deprecated-variable', $key);
    return 1;
}

sub bool_is_true {
    my ($val) = @_;

    return 1 if (defined $val && ($val =~ m/^true$/i
                               || $val eq q{1}));
    return 0;
}

sub bool_is_false {
    my ($val) = @_;

    return 1 if (defined $val && ($val =~ m/^false$/i
                               || $val eq q{0}));
    return 0;
}

sub bool_value {
    my ($file, $lnum, $key, $val) = @_;

    if (!defined $val || $val eq q{} || bool_is_true($val)) {
        return 1;
    } elsif (bool_is_false($val)) {
        return 0;
    } else {
        op('parse-bool-broken', $file, $lnum, $key, $val);
        return -1
    }
}
sub parse_bool {
    my ($file, $lnum, $count, $key, $val) = @_;

    $val = bool_value($file, $lnum, $key, $val);
    return -1 if ($val < 0);
    op('parse-boolean-print', $key, ($val ? 'true' : 'false'));
    set_opt($key, $val);
    return 0;
}

sub parse_defaultvalues {
    my ($file, $lnum, $count, $key, $val) = @_;

    $key =~ s/^default_//;

    if (!tag_supported($key)) {
        op('parse-default-unknown-tag', $file, $lnum, $key);
        return -1;
    }

    op('parse-default-tag-print', $key, $val);
    set_defaults($key, $val);
    return 0;
}

sub parse_integer {
    my ($file, $lnum, $count, $key, $val) = @_;

    if ($val eq q{} || $val !~ m/^\d+$/) {
        op('parse-int-broken', $file, $lnum, $key, $val);
        return -1;
    }

    $val = 0 if ($val eq q{});
    op('parse-int-print', $key, $val);
    set_opt($key, $val);
    return 0;
}

sub parse_profile {
    my ($file, $lnum, $count, $key, $val) = @_;
    my ($name, $pat, $home);

    ($name, $pat) = $val =~ m/(\S+)\s+(.*)/;
    if (!defined $name || !defined $pat || $name eq q{} || $pat eq q{}) {
        op('profile-parse-fail', $val);
        return 1;
    }

    if ($name =~ m/[^\w\d-]/) {
        op('profile-disallowed-chars', $name);
        return 1;
    }

    if (get_opt('checkprofilerc')
       && home_find_file($FIND_PROFRC, $name) eq q{})
    {
        op('profile-missing-config', $name);
        return 1;
    }

    $home = $ENV{'HOME'};
    $home =~ s/\/+$//;
    $home .= q{/};

    $pat =~ s/^\\//;        # throw away a leading backslash
    $pat =~ s/^~\//$home/;  # ~/ -> $HOME

    op('profile-add-pattern', $pat, $name);
    push @{ $profiles{$name} }, $pat;
    return 0;
}

sub parse_string {
    my ($file, $lnum, $count, $key, $val) = @_;

    op('parse-string-print', $key, $val);
    set_opt($key, $val);
    return 0;
}

sub parse_new_section {
    my ($file, $lnum, $count, $key, $val) = @_;

    my ($s) = $key =~ m/^\s*\[(.*)\]\s*$/;

    if (!defined $s) {
        op('section-broken-start', $key);
        return -1;
    }

    $s =~ s/^~\//$ENV{HOME}\//;
    sect_set($s);
    op('rc-switch-section', $s);
    return 0;
}

sub parse_set {
    my ($file, $lnum, $count, $key, $val) = @_;

    my ($name, $value) = $val =~ m/\s*(\w+)\s*=\s*\\?(.*)/;
    if (!defined $name || !defined $value) {
        op('user-setting-broken', $val);
        return 1;
    }

    op('parse-userset-print', $name, $value);
    user_set($name, $value);
    return 0;
}

# handling commandline options
Readonly::Scalar my $CMDLINE_PROTECT => 1;

sub __list_ext_for_type {
    # This assumes its argument is valid.
    my ($type) = @_;

    foreach my $ext (@{ Audio::Scan->extensions_for($type) }) {
        print "$ext\n";
    }
    return 1;
}

sub __list_extensions {
    my ($arg) = @_;
    my (@types, $rc);

    @types = split /,/, $arg;
    $rc = 1;

 T: foreach my $type (@types) {
        foreach my $t (keys %typemap) {
            if ($type eq $typemap{$t}) {
                __list_ext_for_type($t);
                next T;
            }
        }
        $rc = 0;
        warn "Unknown type `$type'.\n";
    }

    return $rc;
}

sub __list_file_types {
    foreach my $t (sort keys %typemap) {
        print "$typemap{$t}\n";
    }

    return 1;
}

sub checkstropts {
    my (@o) = @_;

    foreach my $opt (@o) {
        if (exists $opts{$opt} && !defined $opts{$opt}) {
            op('cmdline-missing-arg', $opt);
        }
    }

    return 1;
}

sub cmdopts {
    my (@args) = @_;

    foreach my $opt (@args) {
        return 0 if (!defined $opts{$opt});
    }

    op('debug', "@args options given!\n");
    return 1;
}

sub cmdopts_or {
    my (@args) = @_;

    foreach my $opt (@args) {
        return 1 if (defined $opts{$opt});
    }

    return 0;
}

sub cmdoptint {
    my ($opt) = @_;

    return $opts{$opt} if ($opts{$opt} =~ m/^-?\d+$/);
    op('cmdline-opt-req-int', $opt, $opts{$opt});
    exit 1;
}

sub cmdoptstr {
    my ($opt) = @_;

    return $opts{$opt};
}

sub __handle_options {
    my ($opt, $key, $val) = @_;

    if (!defined $val) {
        op('debug', "$opt: \"$key\"\n");
    } else {
        op('debug', "$opt: \"$key\" ($val)\n");
    }

    if ($opt eq 'userset') {
        $sets{$key} = $val;
    } else {
        $opts{$opt} = $key;
    }

    return 0;
}

sub read_cmdline_options {
    my ($tmp, $rc);

    if ($#main::ARGV == -1) {
        $opts{'help'} = 1;
    } else {
        Getopt::Long::Configure('require_order', 'no_gnu_compat',
            'auto_abbrev', 'no_ignore_case', 'bundling');

        $rc = GetOptions(
            "ambiguous-use-first" => \&__handle_options,
            "compare-versions" => \&__handle_options,
            "copy|c" => \&__handle_options,
            "debug" => \&__handle_options,
            "disable-hooks|H" => \&__handle_options,
            "disable-profiles|N" => \&__handle_options,
            "dryrun|d" => \&__handle_options,
            "enable-hooks" => \&__handle_options,
            "force|f" => \&__handle_options,
            "help|h" => \&__handle_options,
            "list-cfg|L" => \&__handle_options,
            "list-file-types" => \&__handle_options,
            "list-exts-for-type=s" => \&__handle_options,
            "list-profiles|S" => \&__handle_options,
            "quiet" => \&__handle_options,
            "read-local|l" => \&__handle_options,
            "stdin|s" => \&__handle_options,
            "uber-quiet" => \&__handle_options,
            "suppress-skips|Q" => \&__handle_options,
            "verbose" => \&__handle_options,
            "verbosity|v=i" => \&__handle_options,
            "version|V" => \&__handle_options,
            "rc=s" => \&__handle_options,
            "post-rc=s" => \&__handle_options,
            "prefix|p=s" => \&__handle_options,
            "profile|P=s" => \&__handle_options,
            "compilation-template|T=s" => \&__handle_options,
            "template|t=s" => \&__handle_options,
            "userset|u=s%" => \&__handle_options,
        );
        if (!$rc) {
            croak("    Try $NAME -h\n");
        }
    }

    # turn on debugging early
    set_opt("verbosity", 10_000, $CMDLINE_PROTECT)
        if (cmdopts("debug"));
    set_opt("verbosity", 20, $CMDLINE_PROTECT)
        if (cmdopts("verbose"));
    set_opt("verbosity", 10, $CMDLINE_PROTECT)
        if (cmdopts_or("quiet"));
    set_opt("verbosity", 5, $CMDLINE_PROTECT)
        if (cmdopts("uber-quiet"));
    set_opt("verbosity", cmdoptint("verbosity"), $CMDLINE_PROTECT)
        if (cmdopts("verbosity"));

    set_opt('verbosity', -1, $CMDLINE_PROTECT)
        if (cmdopts("list-cfg") || cmdopts("list-profiles"));

    if (cmdopts("help")) {
        usage();
        exit 0;
    }

    if (cmdopts("version")) {
        print "$NAME $VERSION\n";
        exit 0;
    }

    if (cmdopts("compare-versions")) {
        print "scriptver : $VERSION\n";
        show_version();
        exit 0;
    }

    if (cmdopts("list-file-types")) {
        __list_file_types();
        exit 0;
    }

    if ($tmp = cmdoptstr("list-exts-for-type")) {
        if (__list_extensions($tmp)) {
            exit 0;
        } else {
            exit 1;
        }
    }

    $tmp = cmdoptstr("profile");
    if (defined $tmp && $tmp ne q{}) {
        @cmdline_profiles = split /,/, $tmp;
    }
    set_opt("useprofiles", 0, $CMDLINE_PROTECT)
        if (cmdopts("disable-profiles"));
    set_opt("readstdin", 1, $CMDLINE_PROTECT)
        if (cmdopts("stdin"));
    set_opt("uselocalrc", 1, $CMDLINE_PROTECT)
        if (cmdopts("read-local"));

    if ($#main::ARGV < 0 && !cmdopts("list-cfg")
        && !cmdopts("list-profiles") && !get_opt('readstdin')) {
        croak("No input files given; try $NAME -h.\n");
    }

    return 1;
}

sub read_cmdline_options_late {
    set_opt("force", 1, $CMDLINE_PROTECT)
        if (cmdopts("force"));
    set_opt("dryrun", 1, $CMDLINE_PROTECT)
        if (cmdopts("dryrun"));
    set_opt("copymode", 1, $CMDLINE_PROTECT)
        if (cmdopts("copy"));
    set_opt("suppress_skips", 1, $CMDLINE_PROTECT)
        if (cmdopts("suppress-skips"));
    set_opt("template", cmdoptstr("template"), $CMDLINE_PROTECT)
        if (cmdopts("template"));
    set_opt("comp_template", cmdoptstr("compilation-template"),
              $CMDLINE_PROTECT)
        if (cmdopts("compilation-template"));
    set_opt("prefix", cmdoptstr("prefix"), $CMDLINE_PROTECT)
        if (cmdopts("prefix"));
    set_opt("ambiguoususefirst", 1, $CMDLINE_PROTECT)
        if (cmdopts("ambiguous-use-first"));
    disable_hooks() if (cmdopts("disable-hooks"));
    enable_hooks() if (cmdopts("enable-hooks"));
    if (cmdopts("list-profiles")) {
        dump_profiles();
        exit 0;
    }
    if (cmdopts("list-cfg")) {
        dump_config();
        exit 0;
    }

    return 1;
}

# file system related code

sub ensure_dir {
    # think: mkdir -p /foo/bar/baz
    my ($wantdir) = @_;
    my (@parts, $sofar);

    if (-d $wantdir) {
        return 1;
    }

    if ($wantdir =~ q{^/}) {
        $sofar = q{/};
    } else {
        $sofar = q{};
    }

    @parts = split /\//, $wantdir;
    foreach my $part (@parts) {
        if ($part eq q{}) {
            next;
        }
        $sofar = (
                  $sofar eq q{}
                    ? $part
                    : (
                        $sofar eq q{/}
                          ? q{/} . $part
                          : $sofar . q{/} . $part
                      )
                 );

        if (!-d $sofar) {
            if (get_opt("dryrun")) {
                op('mkdir', $sofar);
            } else {
                mkdir $sofar or do { op('mkdir-fail', $sofar, $ERRNO);
                                     exit 1; }
            }
        }
    }

    return 1;
}

sub xstat {
    my ($file) = @_;
    my @ret = stat $file;
    croak("Could not stat($file): $ERRNO\n") if ($#ret == -1);
    return @ret;
}

sub file_eq {
    my ($f0, $f1) = @_;
    my (@stat0, @stat1);

    if (!-e $f0 || !-e $f1) {
        # one of the two doesn't even exist, can't be the same then.
        return 0;
    }

    @stat0 = xstat($f0);
    @stat1 = xstat($f1);

    if ($stat0[0] == $stat1[0] && $stat0[1] == $stat1[1]) {
        # device and inode are the same. same file.
        return 1;
    }

    return 0;
}

sub xrename {
    # a rename() replacement, that implements renames across
    # filesystems via File::copy() + unlink().
    # This assumes, that source and destination directory are
    # there, because it stat()s them, to check if it can use
    # rename().
    my ($src, $dest) = @_;
    my (@stat0, @stat1, $d0, $d1, $cause);

    $d0 = dirname($src);
    $d1 = dirname($dest);
    @stat0 = xstat($d0);
    @stat1 = xstat($d1);

    if ($stat0[0] == $stat1[0]) {
        $cause = 'rename';
        rename $src, $dest or goto ERR;
    } else {
        $cause = 'copy';
        copy($src, $dest) or goto ERR;
        $cause = 'unlink';
        unlink $src or goto dir;
    }

    return 0;

ERR:
    croak("Could not rename($src, $dest);\n" .
          "Reason: $cause(): $ERRNO\n");
}

sub xcopy {
    my ($src, $dest) = @_;

    if (!copy($src, $dest)) {
        croak("Could not copy($src, $dest): $ERRNO\n");
    }

    return 1;
}

# {get,set}_opt() API

sub get_opt_from_everywhere {
    my ($opt) = @_;
    my (@ret);

    push @ret, $conf{$opt};
    if (is_locopt($opt)) {
        foreach my $s (sort keys %sectconf) {
            if (defined $sectconf{$s}{$opt}) {
                push @ret, $sectconf{$s}{$opt};
            }
        }
    }
    return @ret;
}

sub get_opt {
    my ($opt) = @_;
    my ($section) = (undef);

    op('debug', "GET OPTION ($opt)\n");
    if (defined $cmdline_protect{$opt} && $cmdline_protect{$opt} eq 'yes') {
        return $conf{$opt};
    }

    if (is_locopt($opt)) {
        $section = section_matches(get_file());
    }

    if (defined $section && $sectconf{$section}{$opt}) {
        op('debug', "returning $conf{$opt} (section: $section)\n");
        return $sectconf{$section}{$opt};
    } else {
        if (defined $conf{$opt}) {
            op('debug', "returning $conf{$opt}\n");
        }
        return $conf{$opt};
    }
}

sub set_opt {
    my ($opt, $val, $protect) = @_;

    my $s = sect_get();

    if (defined $s && !is_locopt($opt)) {
        op('rc-opt-not-localizable', $opt, $val);
        return 0;
    }

    if ((!defined $protect || $protect == 0)
        && defined $cmdline_protect{$opt} && $cmdline_protect{$opt} eq 'yes')
    {
        op('rc-overridden-by-cmdline', $opt);
        return 0;
    }

    if (!defined $s) {
        op('debug', "set_opt() ($opt) = ($val)\n");
        $conf{$opt} = $val;
    } else {
        op('debug', "set_opt() ($opt) = ($val) [$s]\n");
        $sectconf{$s}{$opt} = $val;
    }
    if (defined $protect && $protect > 0) {
        op('debug', "Protecting $opt from being overidden later.\n");
        $cmdline_protect{$opt} = 'yes';
    }

    return 1;
}

# accessing the currently processed audio file's name

sub get_file {
    return $__arename_file;
}

sub get_file_printable {
    if (utf8::valid($__arename_file)) {
        my $new = $__arename_file;
        utf8::decode($new);
        return $new;
    }
    return $__arename_file;
}

sub set_file {
    my ($fname) = @_;

    $__arename_file = $fname;
    return 1;
}

# default_* code

sub get_defaults {
    my ($key) = @_;

    return $defaults{$key};
}

sub get_default_keys {
    my @keys = sort keys %defaults;
    return @keys;
}

sub set_defaults {
    my ($key, $val) = @_;

    $defaults{$key} = $val;
    return 1;
}

# user-defined-variable API

sub user_get {
    my ($opt) = @_;
    my ($s);

    $s = section_matches(get_file());
    if (defined $s) {
        op('debug', "returning user setting $lsets{$s}{$opt} (section: $s)\n");
        return $lsets{$s}{$opt};
    }
    return $sets{$opt}
}

sub user_set {
    my ($opt, $val) = @_;
    my ($s);

    $s = sect_get();
    if (defined $s) {
        op('debug', "Localised user setting ($opt) section($s).\n");
        $lsets{$s}{$opt} = $val;
    } else {
        $sets{$opt} = $val;
    }
    return 1;
}

# section handling code

sub is_locopt {
    my ($opt) = @_;

    foreach my $lo (@localizables) {
        if ($lo eq $opt) {
            return 1;
        }
    }

    return 0;
}

sub section_matches {
    my ($filename) = @_;
    my (@k);

    if (!defined $filename) {
        return;
    }

    push @k, keys %sectconf;
    push @k, keys %lsets;

    # The block in the sort call makes sure we always get the longest
    # section names first; that way /foo/bar/ supersedes /foo/.
    foreach my $section (sort { length $b <=> length $a } @k) {
        my $substring = substr $filename, 0, length $section;
        op('debug',
           "<$section> ($filename) eq "
           . "[generated from $filename] ($substring)\n");

        if ($substring eq $section) {
            op('debug', "$section MATCHED! returning it.\n");
            return $section;
        }
    }

    return;
}

sub sect_get {
    return $sect;
}

sub sect_set {
    my ($section) = @_;

    $sect = $section;
    return 1;
}

sub sect_reset {
    $sect = undef;
    return 1;
}

# hooks code

sub enable_hooks {
    set_opt("usehooks", 1);
    set_opt("uselocalhooks", 1);

    return 1;
}

sub disable_hooks {
    set_opt("usehooks", 0);
    set_opt("uselocalhooks", 0);

    return 1;
}

sub __read_hook_file {
    my ($file) = @_;
    my ($rc);

    if ($file eq q{}) {
        return 1;
    }

    if (! -e $file) {
        op('hooks-no-such-file', $file);
        return 1;
    }

    $rc = do $file;

    if (!defined $rc && $EVAL_ERROR) {
        op('hooks-file-parse-error', $file, $EVAL_ERROR);
        if (get_opt("hookerrfatal")) {
            exit 1;
        } else {
            return 0;
        }
    } elsif (!defined $rc) {
        op('hooks-file-read-error', $file, $EVAL_ERROR);
        if (get_opt("hookerrfatal")) {
            exit 1;
        } else {
            return 0;
        }
    } elsif ($rc != 1 && !get_opt('load_quiet')) {
        op('hooks-non-true', $file);
    }

    op('hooks-file-read', $file) if (!get_opt('load_quiet'));
    return 1;
}

sub read_hook_files {
    if (get_opt("usehooks")) {
        __read_hook_file( home_find_file($FIND_HOOKS, $FIND_NONAME) );
    }

    if (get_opt('useprofiles')) {
        foreach my $profile (get_profile_list()) {
            __read_hook_file( home_find_file($FIND_PROFHOOKS, $profile) );
        }
    }

    if (get_opt("uselocalhooks")) {
        __read_hook_file("./.arename.hooks.local");
    }

    return 1;
}

sub register_hook {
    my ($namespace, $funref) = @_;

    if (!defined &{ $funref }) {
        op('hooks-register-undefined', $namespace);
        return 1;
    }
    push @{ $hooks{$namespace} }, $funref;

    return 1;
}

sub remove_hook {
    my ($namespace, $funref) = @_;

    for my $i (0 .. scalar @{ $hooks{$namespace} } - 1) {
        if ($funref == $hooks{$namespace}[$i]) {
            # found; remove and rerun ourself to be sure
            # the coderef is not registered more than once
            # in this namespace.
            splice @{ $hooks{$namespace} }, $i, 1;
            remove_hook($namespace, $funref);
            return 1;
        }
    }
    return 1;
}

sub run_hook {
    my ($ns, @args) = @_;

    my $namespace = $ns;
    shift;

    if (!defined $hooks{$namespace} || scalar @{ $hooks{$namespace} } == 0) {
        return 0;
    }

    foreach my $funref (@{ $hooks{$namespace} }) {
        $funref->($namespace, @args);
    }

    return 1
}

sub startup_hook {
    return run_hook(
                'startup',
                \$NAME, \$VERSION,
                \%conf,
                \@supported_tags, \@main::ARGV
           );
}

# configuration dumping code

sub dump_string {
    my ($s) = @_;

    if ($s =~ m/^\s/) {
        return "\\$s";
    } else {
        return "$s";
    }
}

sub __dump_config {
    my (
        $formatfull, $formatnoval,
        $hashref,
        $keylistref, $excludelistref
    ) = @_;

    KEYLOOP: foreach my $key (sort @{ $keylistref }) {
        foreach my $exclude (sort @{ $excludelistref }) {
            if ($key eq $exclude) {
                next KEYLOOP;
            }
        }

        if (!exists ${ $hashref }{$key } && !defined ${ $hashref }{$key}) {
            next KEYLOOP;
        }

        my $val = dump_string(${ $hashref }{$key});

        if ($val eq q{}) {
            printf "$formatnoval", $key;
        } else {
            printf "$formatfull", $key, $val;
        }
    }

    return 1;
}

sub __dump_config_print {
    my ($hashref, $string) = @_;

    if (%{ $hashref }) {
        print "$string";
    }

    return 1;
}

sub dump_config {
    my ($vffull, $vfnoval) = ( "%-18s   %s\n", "%s\n");
    my ($tffull, $tfnoval) = ( "%-13s   %s\n", "%s\n");

    __dump_config($vffull, $vfnoval, \%conf, \@settables, [ "comp_template", "template" ]);
    print "\n";
    __dump_config($tffull, $tfnoval, \%conf, [ "comp_template", "template" ], [ ]);

    __dump_config_print(\%defaults, "\n# default values for missing tags\n\n");
    __dump_config("default_%s %s\n", "default_%s\n", \%defaults, [ keys %defaults ], [ ]);

    __dump_config_print(\%sets, "\n# user defined settings (see manual for details)\n\n");
    __dump_config("set %s = %s\n", "set %s =\n", \%sets, [ keys %sets ], [ ]);

    __dump_config_print(\%profiles, "\n# profile definitions (commented out on purpose)\n\n");
    foreach my $key (sort keys %profiles) {
        foreach my $pat (@{ $profiles{$key} }) {
            print "#profile $key $pat\n";
        }
    }

    __dump_config_print(\%sectconf, "\n# section definition(s)\n");
    foreach my $sect (sort keys %sectconf) {
        print "\n[$sect]\n";

        __dump_config($vffull, $vfnoval, \%{ $sectconf{$sect} },
            [ keys %{ $sectconf{$sect} } ], [ "comp_template", "template" ]);
        __dump_config($tffull, $tfnoval, \%{ $sectconf{$sect} },
            [ "comp_template", "template" ], [ ]);
    }

    exit 0;
}

sub dump_profiles {
    foreach my $profile (sort keys %profiles) {
        print "$profile\n";
    }

    return 1;
}

sub show_version {
    ## no critic (RequireInterpolationOfMetachars)
    print 'ARename.pm: 4.1' . "\n";
    ## use critic
    return 1;
}

1;

var searchData=
[
  ['qsort_0',['qsort',['http://en.cppreference.com/w/cpp/algorithm/qsort.html',1,'std']]],
  ['queue_1',['queue',['http://en.cppreference.com/w/cpp/container/queue/queue.html',1,'std::queue::queue()'],['http://en.cppreference.com/w/cpp/container/queue.html',1,'std::queue&lt; T &gt;']]],
  ['quick_5fexit_2',['quick_exit',['http://en.cppreference.com/w/cpp/utility/program/quick_exit.html',1,'std']]],
  ['quiet_5fnan_3',['quiet_NaN',['http://en.cppreference.com/w/cpp/types/numeric_limits/quiet_NaN.html',1,'std::numeric_limits']]]
];

var searchData=
[
  ['queue_0',['queue',['http://en.cppreference.com/w/cpp/container/queue.html',1,'std']]]
];

var searchData=
[
  ['has_5fvirtual_5fdestructor_0',['has_virtual_destructor',['http://en.cppreference.com/w/cpp/types/has_virtual_destructor.html',1,'std']]],
  ['hash_1',['hash',['http://en.cppreference.com/w/cpp/utility/hash.html',1,'std']]],
  ['hecto_2',['hecto',['http://en.cppreference.com/w/cpp/numeric/ratio/ratio.html',1,'std']]],
  ['high_5fresolution_5fclock_3',['high_resolution_clock',['http://en.cppreference.com/w/cpp/chrono/high_resolution_clock.html',1,'std::chrono']]],
  ['hours_4',['hours',['http://en.cppreference.com/w/cpp/chrono/duration.html',1,'std::chrono']]]
];

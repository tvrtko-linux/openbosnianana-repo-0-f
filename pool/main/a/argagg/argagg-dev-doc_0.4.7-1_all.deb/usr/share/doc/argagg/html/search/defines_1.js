var searchData=
[
  ['define_5fconversion_5ffrom_5flong_5f_0',['DEFINE_CONVERSION_FROM_LONG_',['../argagg_8hpp.html#a504e64d4a54babb408ff3b999f6e2185',1,'argagg.hpp']]],
  ['define_5fconversion_5ffrom_5flong_5flong_5f_1',['DEFINE_CONVERSION_FROM_LONG_LONG_',['../argagg_8hpp.html#a0191d1a4f98481f2ae008b7cf1df0335',1,'argagg.hpp']]]
];

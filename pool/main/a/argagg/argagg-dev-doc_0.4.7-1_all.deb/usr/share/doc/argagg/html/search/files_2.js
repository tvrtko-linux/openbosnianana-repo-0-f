var searchData=
[
  ['opencv_2ehpp_0',['opencv.hpp',['../opencv_8hpp.html',1,'']]]
];

var searchData=
[
  ['root_2emd_0',['root.md',['../root_8md.html',1,'']]]
];

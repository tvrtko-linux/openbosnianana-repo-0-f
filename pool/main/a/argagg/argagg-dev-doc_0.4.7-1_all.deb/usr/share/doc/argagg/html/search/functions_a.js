var searchData=
[
  ['join_0',['join',['http://en.cppreference.com/w/cpp/thread/thread/join.html',1,'std::thread']]],
  ['joinable_1',['joinable',['http://en.cppreference.com/w/cpp/thread/thread/joinable.html',1,'std::thread']]]
];

var searchData=
[
  ['name_0',['name',['../structargagg_1_1definition.html#aa643462790e7ab53d6117c2379623fac',1,'argagg::definition']]],
  ['num_5fargs_1',['num_args',['../structargagg_1_1definition.html#aea9f1067d6254e6d440777851791aedb',1,'argagg::definition']]]
];

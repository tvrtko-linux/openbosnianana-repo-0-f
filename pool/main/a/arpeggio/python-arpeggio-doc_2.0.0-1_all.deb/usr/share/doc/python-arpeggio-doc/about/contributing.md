# Contributions

If you want to contribute to the Arpeggio project please see the [contribution
guide](https://github.com/textX/textX/Arpeggio/master/CONTRIBUTING.md).



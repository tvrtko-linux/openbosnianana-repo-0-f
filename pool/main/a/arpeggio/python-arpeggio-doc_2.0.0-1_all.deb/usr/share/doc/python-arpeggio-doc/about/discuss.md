# Discuss, ask questions

If you want to get help or involve in the community.

---

For bug reports, general discussion and help please use [GitHub issue
tracker](https://github.com/textX/Arpeggio/issues).

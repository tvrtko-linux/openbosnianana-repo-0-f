#!/bin/sh

sed -i '/^X[A-Z]*-Testsuite:/d' debian/control

# Running Examples

To run an example, call

    aspcud `<example>.cudf` solution.cudf paranoid

Run

    aspcud --help

to get further information how to run aspcud.


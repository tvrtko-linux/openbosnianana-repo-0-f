#ifndef __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#define __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#define __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_CCSyntax_h__
#ifndef __ac_have_predefined_includes__
#define __ac_have_predefined_includes__
#endif // __ac_have_predefined_includes__

#ifndef __ac_h_
#define __ac_h_
#ifdef __cplusplus
namespace AC {
  typedef const char* Type;
  enum JPType { CALL = 262144, EXECUTION = 16777216, CONSTRUCTION = 33554432, DESTRUCTION = 67108864 };
  enum Protection { PROT_NONE, PROT_PRIVATE, PROT_PROTECTED, PROT_PUBLIC };
  enum Specifiers { SPEC_NONE = 0x0 , SPEC_STATIC = 0x1, SPEC_MUTABLE = 0x2, SPEC_VIRTUAL = 0x4 };
  struct Action {
    void **_args; void *_result; void *_entity; void *_target; void *_that; void *_fptr;
    void (*_wrapper)(Action &);
    inline void trigger () { _wrapper (*this); }
  };
  template <typename T> struct ResultBuffer {
    char _data[sizeof (T)];
    void operator = (const T& t) { *this = (const ResultBuffer &)t; }
  };
  template <typename T, typename N> struct TL {
    typedef T type; typedef N next; enum { ARGS = next::ARGS + 1 };
  };
  struct TLE { enum { ARGS = 0 }; };
  template <typename T> struct Referred { typedef T type; };
  template <typename T> struct Referred<T &> { typedef T type; };
  template <typename TL, int I> struct Arg {
    typedef typename Arg<typename TL::next, I - 1>::Type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename TL> struct Arg<TL, 0> {
    typedef typename TL::type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename T> int ttest(...);
  template <typename T> char ttest(typename T::__TI const volatile *);
  template<typename T> struct HasTypeInfo {
    enum { RET=((sizeof(ttest<T>(0))==1)?1:0) };
  };
  template<typename T, int HAVE = HasTypeInfo<T>::RET> struct TypeInfo {
    enum { AVAILABLE = 0, BASECLASSES = 0, MEMBERS = 0, FUNCTIONS = 0,
           CONSTRUCTORS = 0, DESTRUCTORS = 0 };
    typedef T That;
  };
  template<typename T> struct TypeInfo<T, 1> : T::__TI {
    enum { AVAILABLE = 1 };
  };
  template<typename T> struct RT {};
  template<typename T> RT<T> rt_deduce (const T&) { return RT<T>(); }
  template<typename T> RT<T> rt_deduce (const volatile T&) { return RT<T>(); }
  struct Cnv { template<typename T> operator RT<T>() const { return RT<T>(); }};
  #define __AC_TYPEOF(expr) (1?AC::Cnv():AC::rt_deduce(expr))
  template <class Aspect, int Index>
  struct CFlow {
    static int &instance () {
      static int counter = 0;
      return counter;
    }
    CFlow () { instance ()++; }
    ~CFlow () { instance ()--; }
    static bool active () { return instance () > 0; }
  };
}
#endif // __cplusplus
#endif // __ac_h_
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACTree;
class ExtGnu;
class ExtGnuCTree;
class ExtGnuKeywords;
class PragmaOnceUnitState;
class PragmaOnce;
#endif // __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#line 99 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

#ifndef __ac_fwd_WinAsm__
#define __ac_fwd_WinAsm__
class WinAsm;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinAsm_WinAsm__a0_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#endif

#ifndef __ac_fwd_WinFriend__
#define __ac_fwd_WinFriend__
class WinFriend;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinFriend_WinFriend__a0_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#endif

#ifndef __ac_fwd_WinMemberExplSpec__
#define __ac_fwd_WinMemberExplSpec__
class WinMemberExplSpec;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinMemberExplSpec_WinMemberExplSpec__a0_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#endif

#ifndef __ac_fwd_WinDeclSpecs__
#define __ac_fwd_WinDeclSpecs__
class WinDeclSpecs;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs__a0_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs__a1_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs__a2_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs__a3_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#endif

#ifndef __ac_fwd_WinTypeKeywords__
#define __ac_fwd_WinTypeKeywords__
class WinTypeKeywords;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinTypeKeywords_WinTypeKeywords__a0_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#endif

#ifndef __ac_fwd_CCLookAhead__
#define __ac_fwd_CCLookAhead__
class CCLookAhead;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCLookAhead_CCLookAhead__a0_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#endif

#ifndef __ac_fwd_CCSemBinding__
#define __ac_fwd_CCSemBinding__
class CCSemBinding;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a0_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a1_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a2_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a3_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a4_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a5_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a6_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a7_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a8_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a9_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a10_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a11_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a12_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a13_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a14_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a15_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a16_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a17_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a18_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a19_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a20_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a21_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a22_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a23_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a24_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a25_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a26_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a27_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a28_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a29_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a30_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a31_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a32_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a33_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a34_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a35_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a36_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a37_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a38_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a39_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a40_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a41_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a42_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a43_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a44_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a45_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a46_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a47_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a48_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a49_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a50_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a51_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a52_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a53_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a54_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a55_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a56_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a57_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a58_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CCSemBinding_CCSemBinding__a59_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#endif

#ifndef __ac_fwd_LookAhead__
#define __ac_fwd_LookAhead__
class LookAhead;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_LookAhead_LookAhead__a0_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#endif

#ifndef __ac_fwd_ExtGnu__
#define __ac_fwd_ExtGnu__
class ExtGnu;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a0_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a1_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a2_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a3_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a4_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a5_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a6_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a7_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a8_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a9_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a10_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a11_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a12_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a13_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a14_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a15_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a16_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a17_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a18_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a19_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a20_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a21_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a22_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a23_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a24_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a25_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a26_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a27_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a28_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a29_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a30_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a31_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a32_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a33_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a34_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a35_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a36_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a37_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a38_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a39_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a40_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a41_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a42_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a43_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a44_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a45_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a46_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a47_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a48_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a49_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a50_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a51_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a52_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a53_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a54_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a55_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a56_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a57_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a58_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a59_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#endif

#line 1 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 1 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
// This file is part of PUMA.
// Copyright (C) 1999-2003  The PUMA developer team.
//                                                                
// This program is free software;  you can redistribute it and/or 
// modify it under the terms of the GNU General Public License as 
// published by the Free Software Foundation; either version 2 of 
// the License, or (at your option) any later version.            
//                                                                
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
// GNU General Public License for more details.                   
//                                                                
// You should have received a copy of the GNU General Public      
// License along with this program; if not, write to the Free     
// Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
// MA  02111-1307  USA                                            

#ifndef __CCSyntax_h__
#define __CCSyntax_h__

// Parser for the C++ programming language

#include "Puma/CSyntax.h"

namespace Puma {


class CCSemantic;
class CCBuilder;
class CStructure;

#line 495 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 505 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 515 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 525 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 535 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 545 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 555 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 565 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 575 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 585 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 595 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 605 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 615 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 625 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 635 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 645 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 655 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 665 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 675 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 685 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 695 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 705 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 715 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 725 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 735 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 745 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 755 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 765 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 775 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 785 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 795 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 805 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 815 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 825 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 835 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 845 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 855 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 865 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 875 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 885 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 895 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 905 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 915 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 925 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 935 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 945 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 955 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 965 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 975 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 985 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 995 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1005 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1015 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1025 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1035 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1045 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1055 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1065 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1075 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1085 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1095 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1105 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1115 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1125 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1135 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1145 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1155 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1165 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1175 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1185 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1195 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1205 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1215 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1225 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1235 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1245 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1255 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1265 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1275 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1285 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1295 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1305 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1315 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1325 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1335 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1345 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1355 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1365 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1375 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1385 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1405 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1415 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1435 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1445 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1455 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1465 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1475 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1485 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1495 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1505 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1515 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1525 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1535 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1545 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1555 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1565 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1575 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1585 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1595 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1605 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1615 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1625 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1635 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1645 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1655 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1665 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1675 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1685 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1695 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1705 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1715 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1725 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1735 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1745 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1755 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1765 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1775 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1785 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1795 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1805 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1815 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1825 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1835 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1845 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1855 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1865 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1875 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1885 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1895 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1905 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1915 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1925 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1935 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1945 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1955 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1965 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1975 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1985 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 1995 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2005 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2015 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2025 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2035 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2045 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2055 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2065 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2075 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2085 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2095 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2105 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2115 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2125 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2135 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2145 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2155 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
class CCSyntax : public CSyntax {
#line 2168 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntaxE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntaxE;
private:
#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

  friend class CCSemantic;
  int _skip_bodies;
  
  enum {
    SKIP_BODIES_NONE               = 0x0,  // don't skip function bodies
    SKIP_BODIES_ALL                = 0x1,  // skip all function bodies
    SKIP_BODIES_TPL                = 0x2,  // skip function bodies of templates
    SKIP_BODIES_NON_PRJ            = 0x4,  // skip bodies of non-project functions
    SKIP_BODIES_NON_PRIM           = 0x8   // skip bodies in non-primary files
  };

public:
  CCSyntax (CCBuilder &, CCSemantic &);
  
  virtual Grammar grammar () const { return GRAMMAR_CPLUSPLUS; }

  
#line 2194 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline void __exec_old_configure(::Puma::Config &);

#line 50 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 50 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
virtual void configure (Config &);
  
  void config_skip_fct_body (bool s) { 
    if (s) _skip_bodies |= SKIP_BODIES_ALL; 
    else   _skip_bodies ^= (_skip_bodies & SKIP_BODIES_ALL); 
  }

protected:
  CCBuilder &builder () const;
  CCSemantic &semantic () const;

  // TODO: no idea why this can't be introduce by CCLookAhead.ah
  // Specific look-ahead functions
  virtual bool is_fct_def ();
  virtual bool is_nested_name ();
  virtual bool is_class_def ();
  virtual bool is_tpl_id ();
  virtual bool is_tpl_declarator_id ();
  virtual bool is_ptr_to_fct ();
  virtual bool is_nested (State);
  virtual bool is_ass_expr ();

  
#line 2223 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline void __exec_old_init_prim_types();
protected:

#line 72 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 72 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
virtual void init_prim_types ();
  
#line 2232 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline void __exec_old_init_cv_quals();
protected:

#line 73 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 73 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
virtual void init_cv_quals ();
  
  virtual void init_explicit_instantiation ();
  virtual void init_explicit_specialization ();
  virtual void init_access_spec ();
  virtual void init_oper_fct_id ();
  virtual void init_template_key ();
  virtual void init_template_id ();
  virtual void init_class_template_id ();

  // Grammar rules
public:

  // A.1 Keywords
  struct ClassName {
#line 2254 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax9ClassNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax9ClassNameE;
#line 87 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 87 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 2263 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax9ClassName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9ClassName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::ClassName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 88 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 88 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 2301 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9ClassName5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::ClassName, ::Puma::CCSyntax::ClassName, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 88 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 88 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.class_name (); }
    static inline bool parse (CCSyntax &);
  
#line 2319 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef ClassName CCClassNameBuilder; public :
#line 2321 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax9ClassName5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9ClassName5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 2351 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 2353 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9ClassName5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::ClassName, ::Puma::CCSyntax::ClassName, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a0_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 2365 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_name ( ) ;
}
#line 90 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2370 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _class_name_1 ) ;
}
#line 90 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 2376 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 90 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 90 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool class_name ();

  struct EnumName {
#line 2413 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax8EnumNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax8EnumNameE;
#line 93 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 93 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 2422 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax8EnumName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8EnumName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::EnumName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 94 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 94 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 2460 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8EnumName5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::EnumName, ::Puma::CCSyntax::EnumName, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 94 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 94 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.enum_name (); }
    static inline bool parse (CCSyntax &);
  
#line 2478 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef EnumName CCEnumNameBuilder; public :
#line 2480 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax8EnumName5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8EnumName5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 2510 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 2512 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8EnumName5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::EnumName, ::Puma::CCSyntax::EnumName, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a1_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 2524 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_name ( ) ;
}
#line 96 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2529 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _enum_name_1 ) ;
}
#line 96 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 2535 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 96 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 96 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool enum_name ();

  struct TemplateName {
#line 2572 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax12TemplateNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax12TemplateNameE;
#line 99 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 99 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 2581 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax12TemplateName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12TemplateName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::TemplateName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 100 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 100 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 2619 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12TemplateName5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::TemplateName, ::Puma::CCSyntax::TemplateName, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 100 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 100 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.template_name (); }
    static inline bool parse (CCSyntax &);
  
#line 2637 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef TemplateName CCTemplateNameBuilder; public :
#line 2639 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax12TemplateName5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12TemplateName5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 2669 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 2671 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12TemplateName5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::TemplateName, ::Puma::CCSyntax::TemplateName, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a2_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 2683 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_name ( ) ;
}
#line 102 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2688 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _template_name_1 ) ;
}
#line 102 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 2694 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 102 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 102 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool template_name ();

  struct ClassTemplateName {
#line 2731 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax17ClassTemplateNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax17ClassTemplateNameE;
#line 105 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 105 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 2740 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax17ClassTemplateName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax17ClassTemplateName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::ClassTemplateName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 106 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 106 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 2778 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax17ClassTemplateName5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::ClassTemplateName, ::Puma::CCSyntax::ClassTemplateName, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 106 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 106 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.class_template_name (); }
    static inline bool parse (CCSyntax &);
  
#line 2796 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef ClassTemplateName CCClassTemplateNameBuilder; public :
#line 2798 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax17ClassTemplateName5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax17ClassTemplateName5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 2828 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 2830 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax17ClassTemplateName5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::ClassTemplateName, ::Puma::CCSyntax::ClassTemplateName, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a2_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 2842 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_name ( ) ;
}
#line 108 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2847 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _class_template_name_1 ) ;
}
#line 108 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 2853 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 108 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 108 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool class_template_name ();

  struct NamespaceName {
#line 2890 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax13NamespaceNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax13NamespaceNameE;
#line 111 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 111 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 2899 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax13NamespaceName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13NamespaceName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::NamespaceName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 112 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 112 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 2937 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13NamespaceName5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::NamespaceName, ::Puma::CCSyntax::NamespaceName, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 112 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 112 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.namespace_name (); }
    static inline bool parse (CCSyntax &);
  
#line 2955 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef NamespaceName CCNamespaceNameBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . namespace_name ( ) ;
}
#line 114 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 2961 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _namespace_name_1 ) ;
}
#line 114 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 2967 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 114 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 114 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool namespace_name ();

  struct OriginalNsName {
#line 3004 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax14OriginalNsNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax14OriginalNsNameE;
#line 117 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 117 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3013 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14OriginalNsName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::OriginalNsName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 118 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 118 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 3051 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsName5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::OriginalNsName, ::Puma::CCSyntax::OriginalNsName, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 118 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 118 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.original_ns_name (); }
    static inline bool parse (CCSyntax &);
  
#line 3069 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef OriginalNsName CCOriginalNsNameBuilder; public :
#line 3071 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14OriginalNsName5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsName5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 3101 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 3103 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsName5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::OriginalNsName, ::Puma::CCSyntax::OriginalNsName, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a3_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 3115 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_name ( ) ;
}
#line 120 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 3120 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _original_ns_name_1 ) ;
}
#line 120 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 3126 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 120 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 120 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool original_ns_name ();

  struct NamespaceAlias {
#line 3163 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax14NamespaceAliasE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax14NamespaceAliasE;
#line 123 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 123 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3172 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14NamespaceAlias5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14NamespaceAlias5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::NamespaceAlias::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 3210 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14NamespaceAlias5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::NamespaceAlias, ::Puma::CCSyntax::NamespaceAlias, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.namespace_alias (); }
    static inline bool parse (CCSyntax &);
  
#line 3228 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef NamespaceAlias CCNamespaceAliasBuilder; public :
#line 3230 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14NamespaceAlias5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14NamespaceAlias5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 3260 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 3262 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14NamespaceAlias5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::NamespaceAlias, ::Puma::CCSyntax::NamespaceAlias, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a4_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 3274 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_name ( ) ;
}
#line 126 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 3279 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _namespace_alias_1 ) ;
}
#line 126 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 3285 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 126 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 126 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool namespace_alias ();
  
  // A.2 Lexical conventions
  struct Literal {
#line 3323 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax7LiteralE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax7LiteralE;
#line 130 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 130 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3332 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax7Literal5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7Literal5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::Literal::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 131 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 131 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 3370 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7Literal5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::Literal, ::Puma::CCSyntax::Literal, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 131 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 131 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.literal (); }
    static inline bool parse (CCSyntax &);
  
#line 3388 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef Literal CCLiteralBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . literal ( ) ;
}
#line 133 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 3394 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _literal_1 ) ;
}
#line 133 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 3400 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 133 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 133 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool literal ();

  // A.4 Expression
  struct PrimExpr {
#line 3438 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax8PrimExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax8PrimExprE;
#line 137 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 137 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3447 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax8PrimExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8PrimExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::PrimExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 138 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 138 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 3485 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8PrimExpr5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::PrimExpr, ::Puma::CCSyntax::PrimExpr, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 138 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 138 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.prim_expr (); }
    static inline bool parse (CCSyntax &);
  
#line 3503 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef PrimExpr CCPrimExprBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . prim_expr ( ) ;
}
#line 140 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 3509 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _prim_expr_1 ) ;
}
#line 140 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 3515 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 140 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 140 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool prim_expr ();

  struct IdExpr {
#line 3552 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax6IdExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax6IdExprE;
#line 143 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 143 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3561 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax6IdExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax6IdExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::IdExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 144 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 144 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 3599 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax6IdExpr5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::IdExpr, ::Puma::CCSyntax::IdExpr, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 144 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 144 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.id_expr (); }
    static inline bool parse (CCSyntax &);
  
#line 3617 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef IdExpr CCIdExprBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . id_expr ( ) ;
}
#line 146 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 3623 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _id_expr_1 ) ;
}
#line 146 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 3629 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 146 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 146 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool id_expr ();

  struct QualId {
#line 3666 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax6QualIdE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax6QualIdE;
#line 149 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 149 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3675 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax6QualId5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax6QualId5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::QualId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 150 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 150 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 3713 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax6QualId5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::QualId, ::Puma::CCSyntax::QualId, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 150 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 150 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.qual_id (); }
    static inline bool parse (CCSyntax &);
  
#line 3731 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef QualId CCQualIdBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . qual_id ( ) ;
}
#line 152 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 3737 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _qual_id_1 ) ;
}
#line 152 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 3743 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 152 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 152 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool qual_id ();

  struct UnqualId {
#line 3780 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax8UnqualIdE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax8UnqualIdE;
#line 155 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 155 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3789 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax8UnqualId5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8UnqualId5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::UnqualId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 156 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 156 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 3827 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8UnqualId5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::UnqualId, ::Puma::CCSyntax::UnqualId, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 156 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 156 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.unqual_id (); }
    static inline bool parse (CCSyntax &);
  
#line 3845 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef UnqualId CCUnqualIdBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . unqual_id ( ) ;
}
#line 158 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 3851 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _unqual_id_1 ) ;
}
#line 158 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 3857 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 158 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 158 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool unqual_id ();

  struct ColonColon {
#line 3894 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax10ColonColonE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax10ColonColonE;
#line 161 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 161 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 3903 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10ColonColon5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10ColonColon5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::ColonColon::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 162 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 162 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 3941 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10ColonColon5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::ColonColon, ::Puma::CCSyntax::ColonColon, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 162 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 162 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.colon_colon (); }
    static inline bool parse (CCSyntax &);
  
#line 3959 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef ColonColon CCColonColonBuilder; public :
#line 3961 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10ColonColon5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10ColonColon5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 3991 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 3993 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10ColonColon5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::ColonColon, ::Puma::CCSyntax::ColonColon, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a5_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 4005 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . get_node ( ) ;
}
#line 164 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 4010 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _colon_colon_1 ) ;
}
#line 164 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 4016 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 164 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 164 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool colon_colon ();

  struct NestedNameSpec {
#line 4053 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax14NestedNameSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax14NestedNameSpecE;
#line 167 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 167 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 4062 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14NestedNameSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14NestedNameSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::NestedNameSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 168 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 168 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 4100 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14NestedNameSpec5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::NestedNameSpec, ::Puma::CCSyntax::NestedNameSpec, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 168 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 168 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.nested_name_spec (); }
    
#line 4117 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 169 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 169 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 4125 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef NestedNameSpec CCNestedNameSpecBuilder; public :
#line 4127 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14NestedNameSpec5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14NestedNameSpec5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 4157 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 4159 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14NestedNameSpec5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::NestedNameSpec, ::Puma::CCSyntax::NestedNameSpec, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a6_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 4171 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . nested_name_spec ( ) ;
}
#line 170 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 4176 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> is_nested_name ( ) ;
}
#line 170 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 4182 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 170 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 170 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool nested_name_spec ();

  struct NestedNameSpec1 {
#line 4219 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax15NestedNameSpec1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax15NestedNameSpec1E;
#line 173 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 173 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 4228 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax15NestedNameSpec15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax15NestedNameSpec15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::NestedNameSpec1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 174 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 174 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 4266 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax15NestedNameSpec15checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::NestedNameSpec1, ::Puma::CCSyntax::NestedNameSpec1, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 174 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 174 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.nested_name_spec1 (); }
    static inline bool parse (CCSyntax &);
  
#line 4284 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef NestedNameSpec1 CCNestedNameSpec1Builder; public :
#line 4286 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax15NestedNameSpec15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax15NestedNameSpec15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 4316 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 4318 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax15NestedNameSpec15buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::NestedNameSpec1, ::Puma::CCSyntax::NestedNameSpec1, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a8_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 4330 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . nested_name_spec1 ( ) ;
}
#line 176 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 4335 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> is_nested_name ( ) ;
}
#line 176 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 4341 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 176 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 176 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool nested_name_spec1 ();

  struct ClassOrNsName {
#line 4378 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax13ClassOrNsNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax13ClassOrNsNameE;
#line 179 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 179 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 4387 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax13ClassOrNsName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13ClassOrNsName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::ClassOrNsName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 180 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 180 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 4425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13ClassOrNsName5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::ClassOrNsName, ::Puma::CCSyntax::ClassOrNsName, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 180 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 180 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.class_or_ns_name (); }
    static inline bool parse (CCSyntax &);
  
#line 4443 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef ClassOrNsName CCClassOrNsNameBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . class_or_ns_name ( ) ;
}
#line 182 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 4449 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _class_or_ns_name_1 ) ;
}
#line 182 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 4455 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 182 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 182 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool class_or_ns_name ();

  struct PostfixExpr {
#line 4492 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax11PostfixExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax11PostfixExprE;
#line 185 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 185 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 4501 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax11PostfixExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax11PostfixExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::PostfixExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 186 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 186 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 4539 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax11PostfixExpr5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::PostfixExpr, ::Puma::CCSyntax::PostfixExpr, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 186 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 186 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.postfix_expr (); }
    static inline bool parse (CCSyntax &);
  
#line 4557 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef PostfixExpr CCPostfixExprBuilder; public :
#line 4559 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax11PostfixExpr5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax11PostfixExpr5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 4589 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 4591 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax11PostfixExpr5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::PostfixExpr, ::Puma::CCSyntax::PostfixExpr, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a11_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 4603 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{

return s . builder ( ) . postfix_expr ( ) ;
}
#line 188 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 4610 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 188 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 188 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool postfix_expr ();

  struct PostfixExpr1 {
#line 4647 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax12PostfixExpr1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax12PostfixExpr1E;
#line 191 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 191 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 4656 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax12PostfixExpr15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::PostfixExpr1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 192 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 192 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 4694 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr15checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::PostfixExpr1, ::Puma::CCSyntax::PostfixExpr1, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 192 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 192 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.postfix_expr1 (); }
    
#line 4711 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 4719 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef PostfixExpr1 CCPostfixExpr1Builder; public :
#line 4721 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax12PostfixExpr15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 4751 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 4753 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr15buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::PostfixExpr1, ::Puma::CCSyntax::PostfixExpr1, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a12_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 4765 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . postfix_expr1 ( ) ;
}
#line 194 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 4770 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _postfix_expr1_1 ) ;
}
#line 194 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 4776 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 194 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 194 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool postfix_expr1 ();

  struct PostfixExpr2 {
#line 4813 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax12PostfixExpr2E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax12PostfixExpr2E;
#line 197 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 197 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 4822 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax12PostfixExpr25checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr25checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::PostfixExpr2::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 198 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 198 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 4860 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr25checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::PostfixExpr2, ::Puma::CCSyntax::PostfixExpr2, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 198 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 198 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.postfix_expr2 (); }
    static inline bool parse (CCSyntax &);
  
#line 4878 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef PostfixExpr2 CCPostfixExpr2Builder; public :
#line 4880 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax12PostfixExpr25buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr25buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 4910 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 4912 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12PostfixExpr25buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::PostfixExpr2, ::Puma::CCSyntax::PostfixExpr2, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a14_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 4924 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . postfix_expr2 ( ) ;
}
#line 200 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 4930 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 200 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 200 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool postfix_expr2 ();

  struct ConstructExpr {
#line 4967 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax13ConstructExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax13ConstructExprE;
#line 203 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 203 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 4976 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax13ConstructExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13ConstructExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::ConstructExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 204 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 204 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 5014 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13ConstructExpr5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::ConstructExpr, ::Puma::CCSyntax::ConstructExpr, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 204 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 204 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.construct_expr (); }
    static inline bool parse (CCSyntax &);
  
#line 5032 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef ConstructExpr CCConstructExprBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . construct_expr ( ) ;
}
#line 206 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 5038 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _construct_expr_1 ) ;
}
#line 206 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 5044 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 206 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 206 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool construct_expr ();

  struct PseudoDtorName {
#line 5081 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax14PseudoDtorNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax14PseudoDtorNameE;
#line 209 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 209 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 5090 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14PseudoDtorName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14PseudoDtorName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::PseudoDtorName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 210 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 210 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 5128 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14PseudoDtorName5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::PseudoDtorName, ::Puma::CCSyntax::PseudoDtorName, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 210 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 210 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.pseudo_dtor_name (); }
    static inline bool parse (CCSyntax &);
  
#line 5146 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef PseudoDtorName CCPseudoDtorNameBuilder; public :
#line 5148 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14PseudoDtorName5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14PseudoDtorName5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 5178 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 5180 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14PseudoDtorName5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::PseudoDtorName, ::Puma::CCSyntax::PseudoDtorName, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a15_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 5192 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . pseudo_dtor_name ( ) ;
}
#line 212 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 5198 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 212 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 212 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool pseudo_dtor_name ();

  struct UnaryExpr {
#line 5235 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax9UnaryExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax9UnaryExprE;
#line 215 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 215 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 5244 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax9UnaryExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9UnaryExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::UnaryExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 216 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 216 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 5282 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9UnaryExpr5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::UnaryExpr, ::Puma::CCSyntax::UnaryExpr, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 216 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 216 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.unary_expr (); }
    
#line 5299 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 217 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 217 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 5307 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef UnaryExpr CCUnaryExprBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . unary_expr ( ) ;
}
#line 218 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 5314 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 218 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 218 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool unary_expr ();

  struct TypeTraitExpr {
#line 5351 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax13TypeTraitExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax13TypeTraitExprE;
#line 221 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 221 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 5360 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax13TypeTraitExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13TypeTraitExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::TypeTraitExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 222 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 222 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 5398 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13TypeTraitExpr5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::TypeTraitExpr, ::Puma::CCSyntax::TypeTraitExpr, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 222 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 222 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.type_trait_expr (); }
    static inline bool parse (CCSyntax &);
  
#line 5416 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef TypeTraitExpr CCTypeTraitExprBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . type_trait_expr ( ) ;
}
#line 224 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 5422 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _type_trait_expr_1 ) ;
}
#line 224 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 5428 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 224 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 224 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool type_trait_expr ();

  struct NewExpr {
#line 5465 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax7NewExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax7NewExprE;
#line 227 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 227 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 5474 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax7NewExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7NewExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::NewExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 228 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 228 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 5512 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7NewExpr5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::NewExpr, ::Puma::CCSyntax::NewExpr, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 228 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 228 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.new_expr (); }
    static inline bool parse (CCSyntax &);
  
#line 5530 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef NewExpr CCNewExprBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . new_expr ( ) ;
}
#line 230 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 5536 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _new_expr_1 ) ;
}
#line 230 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 5542 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 230 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 230 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool new_expr ();

  struct NewPlacement {
#line 5579 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax12NewPlacementE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax12NewPlacementE;
#line 233 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 233 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 5588 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax12NewPlacement5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12NewPlacement5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::NewPlacement::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 234 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 234 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 5626 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12NewPlacement5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::NewPlacement, ::Puma::CCSyntax::NewPlacement, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 234 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 234 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.new_placement (); }
    static inline bool parse (CCSyntax &);
  
#line 5644 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef NewPlacement CCNewPlacementBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . new_placement ( ) ;
}
#line 236 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 5650 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _new_placement_1 ) ;
}
#line 236 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 5656 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 236 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 236 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool new_placement ();

  struct NewTypeId {
#line 5693 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax9NewTypeIdE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax9NewTypeIdE;
#line 239 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 239 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 5702 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax9NewTypeId5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9NewTypeId5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::NewTypeId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 240 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 240 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 5740 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9NewTypeId5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::NewTypeId, ::Puma::CCSyntax::NewTypeId, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 240 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 240 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.new_type_id (); }
    
#line 5757 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 241 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 241 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 5765 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef NewTypeId CCNewTypeIdBuilder; public :
#line 5767 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax9NewTypeId5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9NewTypeId5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 5797 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 5799 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9NewTypeId5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::NewTypeId, ::Puma::CCSyntax::NewTypeId, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a16_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 5811 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . type_id ( ) ;
}
#line 242 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 5817 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 242 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 242 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool new_type_id ();

  struct NewDeclarator {
#line 5854 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax13NewDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax13NewDeclaratorE;
#line 245 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 245 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 5863 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax13NewDeclarator5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13NewDeclarator5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::NewDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 246 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 246 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 5901 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13NewDeclarator5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::NewDeclarator, ::Puma::CCSyntax::NewDeclarator, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 246 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 246 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.new_declarator (); }
    static inline bool parse (CCSyntax &);
  
#line 5919 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef NewDeclarator CCNewDeclaratorBuilder; public :
#line 5921 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax13NewDeclarator5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13NewDeclarator5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 5951 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 5953 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13NewDeclarator5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::NewDeclarator, ::Puma::CCSyntax::NewDeclarator, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a18_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 5965 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . abst_declarator ( ) ;
}
#line 248 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 5971 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 248 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 248 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool new_declarator ();

  struct DirectNewDeclarator {
#line 6008 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax19DirectNewDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax19DirectNewDeclaratorE;
#line 251 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 251 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6017 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax19DirectNewDeclarator5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax19DirectNewDeclarator5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::DirectNewDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 252 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 252 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 6055 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax19DirectNewDeclarator5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::DirectNewDeclarator, ::Puma::CCSyntax::DirectNewDeclarator, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 252 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 252 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.direct_new_declarator (); }
    static inline bool parse (CCSyntax &);
  
#line 6073 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef DirectNewDeclarator CCDirectNewDeclaratorBuilder; public :
#line 6075 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax19DirectNewDeclarator5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax19DirectNewDeclarator5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 6105 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 6107 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax19DirectNewDeclarator5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::DirectNewDeclarator, ::Puma::CCSyntax::DirectNewDeclarator, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a19_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 6119 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . direct_new_declarator ( ) ;
}
#line 254 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 6124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _direct_new_declarator_1 ) ;
}
#line 254 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 6130 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 254 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 254 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool direct_new_declarator ();

  struct DirectNewDeclarator1 {
#line 6167 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax20DirectNewDeclarator1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax20DirectNewDeclarator1E;
#line 257 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 257 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6176 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax20DirectNewDeclarator15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax20DirectNewDeclarator15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::DirectNewDeclarator1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 258 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 258 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 6214 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax20DirectNewDeclarator15checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::DirectNewDeclarator1, ::Puma::CCSyntax::DirectNewDeclarator1, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 258 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 258 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.direct_new_declarator1 (); }
    static inline bool parse (CCSyntax &);
  
#line 6232 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef DirectNewDeclarator1 CCDirectNewDeclarator1Builder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . direct_new_declarator1 ( ) ;
}
#line 260 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 6238 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _direct_new_declarator1_1 ) ;
}
#line 260 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 6244 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 260 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 260 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool direct_new_declarator1 ();
  
  struct NewInit {
#line 6281 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax7NewInitE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax7NewInitE;
#line 263 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 263 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6290 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax7NewInit5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7NewInit5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::NewInit::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 264 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 264 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 6328 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7NewInit5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::NewInit, ::Puma::CCSyntax::NewInit, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 264 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 264 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.new_init (); }
    static inline bool parse (CCSyntax &);
  
#line 6346 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef NewInit CCNewInitBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . new_init ( ) ;
}
#line 266 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 6352 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _new_init_1 ) ;
}
#line 266 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 6358 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 266 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 266 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool new_init ();

  struct DeleteExpr {
#line 6395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax10DeleteExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax10DeleteExprE;
#line 269 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 269 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6404 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10DeleteExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10DeleteExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::DeleteExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 270 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 270 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 6442 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10DeleteExpr5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::DeleteExpr, ::Puma::CCSyntax::DeleteExpr, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 270 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 270 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.delete_expr (); }
    static inline bool parse (CCSyntax &);
  
#line 6460 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef DeleteExpr CCDeleteExprBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . delete_expr ( ) ;
}
#line 272 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 6466 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _delete_expr_1 ) ;
}
#line 272 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 6472 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 272 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 272 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool delete_expr ();

  struct PmExpr {
#line 6509 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax6PmExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax6PmExprE;
#line 275 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 275 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6518 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax6PmExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax6PmExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::PmExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 276 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 276 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 6556 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax6PmExpr5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::PmExpr, ::Puma::CCSyntax::PmExpr, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 276 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 276 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.pm_expr (); }
    static inline bool parse (CCSyntax &);
  
#line 6574 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef PmExpr CCPmExprBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . pm_expr ( ) ;
}
#line 278 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 6581 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 278 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 278 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool pm_expr ();

  struct MulExpr {
#line 6618 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax7MulExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax7MulExprE;
#line 281 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 281 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6627 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax7MulExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7MulExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::MulExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 282 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 282 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 6665 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7MulExpr5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::MulExpr, ::Puma::CCSyntax::MulExpr, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 282 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 282 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.mul_expr (); }
    static inline bool parse (CCSyntax &);
  
#line 6683 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef MulExpr CCMulExprBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . mul_expr ( ) ;
}
#line 284 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 6690 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 284 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 284 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool mul_expr ();

  struct RelExpr {
#line 6727 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax7RelExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax7RelExprE;
#line 287 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 287 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6736 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax7RelExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7RelExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::RelExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 288 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 288 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 6774 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7RelExpr5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::RelExpr, ::Puma::CCSyntax::RelExpr, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 288 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 288 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.rel_expr (); }
    static inline bool parse (CCSyntax &);
  
#line 6792 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef RelExpr CCRelExprBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . rel_expr ( ) ;
}
#line 290 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 6799 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 290 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 290 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool rel_expr ();

  struct CondExpr {
#line 6836 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax8CondExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax8CondExprE;
#line 293 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 293 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6845 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax8CondExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8CondExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::CondExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 294 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 294 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 6883 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8CondExpr5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::CondExpr, ::Puma::CCSyntax::CondExpr, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 294 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 294 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.cond_expr (); }
    static inline bool parse (CCSyntax &);
  
#line 6901 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef CondExpr CCCondExprBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . cond_expr ( ) ;
}
#line 296 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 6908 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 296 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 296 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool cond_expr ();

  struct AssExpr {
#line 6945 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax7AssExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax7AssExprE;
#line 299 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 299 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 6954 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax7AssExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7AssExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::AssExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 300 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 300 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 6992 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7AssExpr5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::AssExpr, ::Puma::CCSyntax::AssExpr, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 300 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 300 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.ass_expr (); }
    
#line 7009 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 301 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 301 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 7017 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef AssExpr CCAssExprBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . ass_expr ( ) ;
}
#line 302 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 7024 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 302 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 302 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool ass_expr ();

  struct AssExpr1 {
#line 7061 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax8AssExpr1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax8AssExpr1E;
#line 305 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 305 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7070 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax8AssExpr15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8AssExpr15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::AssExpr1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 306 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 306 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 7108 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8AssExpr15checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::AssExpr1, ::Puma::CCSyntax::AssExpr1, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 306 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 306 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.ass_expr1 (); }
    static inline bool parse (CCSyntax &);
  
#line 7126 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef AssExpr1 CCAssExpr1Builder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . ass_expr1 ( ) ;
}
#line 308 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 7133 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 308 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 308 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool ass_expr1 ();

  struct ConstExpr {
#line 7170 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax9ConstExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax9ConstExprE;
#line 311 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 311 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7179 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax9ConstExpr5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9ConstExpr5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::ConstExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 312 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 312 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 7217 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9ConstExpr5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::ConstExpr, ::Puma::CCSyntax::ConstExpr, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 312 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 312 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.const_expr (); }
    
#line 7234 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 313 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 313 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 7242 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef ConstExpr CCConstExprBuilder; public :
#line 7244 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax9ConstExpr5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9ConstExpr5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 7274 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 7276 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9ConstExpr5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::ConstExpr, ::Puma::CCSyntax::ConstExpr, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a21_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 7288 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . const_expr ( ) ;
}
#line 314 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 7294 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 314 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 314 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool const_expr ();

  // A.5 Statements
  struct Stmt {
#line 7332 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax4StmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax4StmtE;
#line 318 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 318 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7341 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax4Stmt5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax4Stmt5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::Stmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 319 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 319 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 7379 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax4Stmt5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::Stmt, ::Puma::CCSyntax::Stmt, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 319 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 319 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.stmt (); }
    static inline bool parse (CCSyntax &);
  
#line 7397 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef Stmt CCStmtBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . stmt ( ) ;
}
#line 321 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 7404 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 321 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 321 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  
#line 7439 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline bool __exec_old_stmt();

#line 322 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 322 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
virtual bool stmt ();

  struct StmtSeq {
#line 7448 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax7StmtSeqE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax7StmtSeqE;
#line 324 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 324 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7457 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax7StmtSeq5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7StmtSeq5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::StmtSeq::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 325 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 325 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 7495 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7StmtSeq5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::StmtSeq, ::Puma::CCSyntax::StmtSeq, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 325 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 325 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.stmt_seq (); }
    
#line 7512 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 326 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 326 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 7520 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef StmtSeq CCStmtSeqBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . stmt_seq ( ) ;
}
#line 327 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 7527 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 327 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 327 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool stmt_seq ();

  struct SubStmt {
#line 7564 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax7SubStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax7SubStmtE;
#line 330 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 330 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7573 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax7SubStmt5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7SubStmt5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::SubStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 331 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 331 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 7611 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7SubStmt5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::SubStmt, ::Puma::CCSyntax::SubStmt, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 331 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 331 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.sub_stmt (); }
    static inline bool parse (CCSyntax &);
  
#line 7629 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef SubStmt CCSubStmtBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . sub_stmt ( ) ;
}
#line 333 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 7636 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 333 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 333 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool sub_stmt ();

  struct Condition {
#line 7673 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax9ConditionE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax9ConditionE;
#line 336 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 336 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7682 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax9Condition5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9Condition5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::Condition::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 337 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 337 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 7720 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9Condition5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::Condition, ::Puma::CCSyntax::Condition, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 337 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 337 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.condition (); }
    static inline bool parse (CCSyntax &);
  
#line 7738 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef Condition CCConditionBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . condition ( ) ;
}
#line 339 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 7745 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 339 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 339 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool condition ();

  struct Condition1 {
#line 7782 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax10Condition1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax10Condition1E;
#line 342 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 342 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7791 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10Condition15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10Condition15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::Condition1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 7829 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10Condition15checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::Condition1, ::Puma::CCSyntax::Condition1, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.condition1 (); }
    
#line 7846 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 344 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 344 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 7854 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef Condition1 CCCondition1Builder; public :
#line 7856 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10Condition15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10Condition15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 7886 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 7888 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10Condition15buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::Condition1, ::Puma::CCSyntax::Condition1, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a23_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 7900 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . condition ( ) ;
}
#line 345 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 7906 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 345 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 345 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool condition1 ();

  struct Condition2 {
#line 7943 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax10Condition2E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax10Condition2E;
#line 348 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 348 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 7952 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10Condition25checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10Condition25checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::Condition2::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 349 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 349 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 7990 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10Condition25checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::Condition2, ::Puma::CCSyntax::Condition2, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 349 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 349 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.condition2 (); }
    static inline bool parse (CCSyntax &);
  
#line 8008 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef Condition2 CCCondition2Builder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . condition ( ) ;
}
#line 351 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 8015 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 351 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 351 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool condition2 ();

  struct DeclStmt {
#line 8052 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax8DeclStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax8DeclStmtE;
#line 354 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 354 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8061 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax8DeclStmt5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8DeclStmt5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::DeclStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 355 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 355 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 8099 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8DeclStmt5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::DeclStmt, ::Puma::CCSyntax::DeclStmt, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 355 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 355 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.decl_stmt (); }
    static inline bool parse (CCSyntax &);
  
#line 8117 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef DeclStmt CCDeclStmtBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . decl_stmt ( ) ;
}
#line 357 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 8124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 357 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 357 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool decl_stmt ();

  // A.6 Declarations
  
  struct Decl {
#line 8163 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax4DeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax4DeclE;
#line 362 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 362 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8172 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax4Decl5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax4Decl5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::Decl::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 363 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 363 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 8210 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax4Decl5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::Decl, ::Puma::CCSyntax::Decl, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 363 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 363 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.decl (); }
    static inline bool parse (CCSyntax &);
  
#line 8228 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef Decl CCDeclBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . decl ( ) ;
}
#line 365 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 8235 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 365 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 365 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool decl ();
  // helper function, which is needed, because ac++ can't weave in templates :-(
  virtual bool decl_check ();

  struct BlockDecl {
#line 8274 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax9BlockDeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax9BlockDeclE;
#line 370 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 370 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8283 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax9BlockDecl5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9BlockDecl5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::BlockDecl::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 371 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 371 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 8321 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9BlockDecl5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::BlockDecl, ::Puma::CCSyntax::BlockDecl, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 371 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 371 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.block_decl (); }
    static inline bool parse (CCSyntax &);
  
#line 8339 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef BlockDecl CCBlockDeclBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . block_decl ( ) ;
}
#line 373 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 8346 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 373 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 373 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool block_decl ();

  struct SimpleDecl {
#line 8383 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax10SimpleDeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax10SimpleDeclE;
#line 376 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 376 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8392 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10SimpleDecl5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10SimpleDecl5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::SimpleDecl::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 377 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 377 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 8430 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10SimpleDecl5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::SimpleDecl, ::Puma::CCSyntax::SimpleDecl, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 377 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 377 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.simple_decl (); }
    static inline bool parse (CCSyntax &);
  
#line 8448 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef SimpleDecl CCSimpleDeclBuilder; public :
#line 8450 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10SimpleDecl5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10SimpleDecl5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 8480 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 8482 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10SimpleDecl5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::SimpleDecl, ::Puma::CCSyntax::SimpleDecl, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  __result_buffer = ::Puma::CCSyntax::SimpleDecl::__exec_old_build(s);
  AC::invoke_CCSemBinding_CCSemBinding__a24_after<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 8495 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_decl ( ) ;
}
#line 379 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 8501 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 379 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 379 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool simple_decl ();

  struct DeclSpecSeq1 {
#line 8538 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax12DeclSpecSeq1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax12DeclSpecSeq1E;
#line 382 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 382 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8547 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax12DeclSpecSeq15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12DeclSpecSeq15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::DeclSpecSeq1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 383 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 383 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 8585 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12DeclSpecSeq15checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::DeclSpecSeq1, ::Puma::CCSyntax::DeclSpecSeq1, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 383 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 383 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.decl_spec_seq1 (); }
    static inline bool parse (CCSyntax &);
  
#line 8603 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef DeclSpecSeq1 CCDeclSpecSeq1Builder; public :
#line 8605 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax12DeclSpecSeq15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12DeclSpecSeq15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 8635 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 8637 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12DeclSpecSeq15buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::DeclSpecSeq1, ::Puma::CCSyntax::DeclSpecSeq1, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a25_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 8649 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . decl_spec_seq1 ( ) ;
}
#line 385 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 8655 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 385 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 385 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool decl_spec_seq1 ();

  struct MiscSpec {
#line 8692 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax8MiscSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax8MiscSpecE;
#line 388 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 388 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8701 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax8MiscSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8MiscSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::MiscSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 389 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 389 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 8739 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8MiscSpec5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::MiscSpec, ::Puma::CCSyntax::MiscSpec, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 389 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 389 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.misc_spec (); }
    static inline bool parse (CCSyntax &);
  
#line 8757 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef MiscSpec CCMiscSpecBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . misc_spec ( ) ;
}
#line 391 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 8763 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _misc_spec_1 ) ;
}
#line 391 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 8769 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 391 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 391 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool misc_spec ();

  struct StorageClassSpec {
#line 8806 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax16StorageClassSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax16StorageClassSpecE;
#line 394 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 394 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8815 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax16StorageClassSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax16StorageClassSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::StorageClassSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 8853 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax16StorageClassSpec5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::StorageClassSpec, ::Puma::CCSyntax::StorageClassSpec, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.storage_class_spec (); }
    static inline bool parse (CCSyntax &);
  
#line 8871 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef StorageClassSpec CCStorageClassSpecBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . storage_class_spec ( ) ;
}
#line 397 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 8877 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _storage_class_spec_1 ) ;
}
#line 397 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 8883 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 397 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 397 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool storage_class_spec ();

  struct FctSpec {
#line 8920 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax7FctSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax7FctSpecE;
#line 400 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 400 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 8929 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax7FctSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax7FctSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::FctSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 401 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 401 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 8967 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax7FctSpec5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::FctSpec, ::Puma::CCSyntax::FctSpec, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 401 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 401 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.fct_spec (); }
    static inline bool parse (CCSyntax &);
  
#line 8985 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef FctSpec CCFctSpecBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . fct_spec ( ) ;
}
#line 403 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 8991 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _fct_spec_1 ) ;
}
#line 403 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 8997 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 403 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 403 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool fct_spec ();

  struct SimpleTypeSpec {
#line 9034 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax14SimpleTypeSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax14SimpleTypeSpecE;
#line 406 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 406 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9043 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14SimpleTypeSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14SimpleTypeSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::SimpleTypeSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 407 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 407 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 9081 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14SimpleTypeSpec5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::SimpleTypeSpec, ::Puma::CCSyntax::SimpleTypeSpec, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 407 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 407 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.simple_type_spec (); }
    
#line 9098 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 408 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 408 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 9106 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef SimpleTypeSpec CCSimpleTypeSpecBuilder; public :
#line 9108 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14SimpleTypeSpec5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14SimpleTypeSpec5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 9138 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 9140 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14SimpleTypeSpec5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::SimpleTypeSpec, ::Puma::CCSyntax::SimpleTypeSpec, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a27_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 9152 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . simple_type_spec ( ) ;
}
#line 409 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 9158 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 409 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 409 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool simple_type_spec ();

  struct TypeName {
#line 9195 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax8TypeNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax8TypeNameE;
#line 412 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 412 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9204 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax8TypeName5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax8TypeName5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::TypeName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 413 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 413 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 9242 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax8TypeName5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::TypeName, ::Puma::CCSyntax::TypeName, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 413 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 413 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.type_name (); }
    static inline bool parse (CCSyntax &);
  
#line 9260 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef TypeName CCTypeNameBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . type_name ( ) ;
}
#line 415 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 9266 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _type_name_1 ) ;
}
#line 415 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 9272 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 415 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 415 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool type_name ();

  struct ElaboratedTypeSpec {
#line 9309 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax18ElaboratedTypeSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax18ElaboratedTypeSpecE;
#line 418 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 418 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9318 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax18ElaboratedTypeSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax18ElaboratedTypeSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::ElaboratedTypeSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 419 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 419 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 9356 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax18ElaboratedTypeSpec5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::ElaboratedTypeSpec, ::Puma::CCSyntax::ElaboratedTypeSpec, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 419 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 419 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.elaborated_type_spec (); }
    
#line 9373 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 420 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 420 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 9381 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef ElaboratedTypeSpec CCElaboratedTypeSpecBuilder; public :
#line 9383 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax18ElaboratedTypeSpec5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax18ElaboratedTypeSpec5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 9413 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 9415 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax18ElaboratedTypeSpec5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::ElaboratedTypeSpec, ::Puma::CCSyntax::ElaboratedTypeSpec, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a29_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 9427 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . elaborated_type_spec ( ) ;
}
#line 421 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 9432 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _elaborated_type_spec_1 ) ;
}
#line 421 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 9438 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 421 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 421 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool elaborated_type_spec ();

  struct EnumeratorList {
#line 9475 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax14EnumeratorListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax14EnumeratorListE;
#line 424 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 424 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9484 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14EnumeratorList5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14EnumeratorList5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::EnumeratorList::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 9522 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14EnumeratorList5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::EnumeratorList, ::Puma::CCSyntax::EnumeratorList, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.enumerator_list (); }
    static inline bool parse (CCSyntax &);
  
#line 9540 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef EnumeratorList CCEnumeratorListBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . enumerator_list ( ) ;
}
#line 427 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 9547 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 427 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 427 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool enumerator_list ();

  struct EnumeratorDef {
#line 9584 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax13EnumeratorDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax13EnumeratorDefE;
#line 430 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 430 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9593 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax13EnumeratorDef5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13EnumeratorDef5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::EnumeratorDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 431 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 431 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 9631 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13EnumeratorDef5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::EnumeratorDef, ::Puma::CCSyntax::EnumeratorDef, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 431 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 431 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.enumerator_def (); }
    static inline bool parse (CCSyntax &);
  
#line 9649 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef EnumeratorDef CCEnumeratorDefBuilder; public :
#line 9651 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax13EnumeratorDef5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13EnumeratorDef5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 9681 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 9683 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13EnumeratorDef5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::EnumeratorDef, ::Puma::CCSyntax::EnumeratorDef, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a30_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 9695 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . enumerator_def ( ) ;
}
#line 433 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 9701 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 433 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 433 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool enumerator_def ();

  struct LinkageSpec {
#line 9738 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax11LinkageSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax11LinkageSpecE;
#line 436 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 436 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9747 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax11LinkageSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax11LinkageSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::LinkageSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 437 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 437 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 9785 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax11LinkageSpec5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::LinkageSpec, ::Puma::CCSyntax::LinkageSpec, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 437 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 437 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.linkage_spec (); }
    static inline bool parse (CCSyntax &);
  
#line 9803 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef LinkageSpec CCLinkageSpecBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . linkage_spec ( ) ;
}
#line 439 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 9810 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 439 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 439 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool linkage_spec ();

  // A.6.1 Namespaces
  struct NamespaceDef {
#line 9848 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax12NamespaceDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax12NamespaceDefE;
#line 443 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 443 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9857 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax12NamespaceDef5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12NamespaceDef5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::NamespaceDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 444 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 444 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 9895 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12NamespaceDef5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::NamespaceDef, ::Puma::CCSyntax::NamespaceDef, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 444 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 444 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.namespace_def (); }
    static inline bool parse (CCSyntax &);
  
#line 9913 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef NamespaceDef CCNamespaceDefBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . namespace_def ( ) ;
}
#line 446 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 9919 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _namespace_def_1 ) ;
}
#line 446 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 9925 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 446 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 446 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool namespace_def ();

  struct NamedNsDef {
#line 9962 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax10NamedNsDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax10NamedNsDefE;
#line 449 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 449 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 9971 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10NamedNsDef5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10NamedNsDef5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::NamedNsDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 450 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 450 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 10009 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10NamedNsDef5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::NamedNsDef, ::Puma::CCSyntax::NamedNsDef, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 450 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 450 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.named_ns_def (); }
    static inline bool parse (CCSyntax &);
  
#line 10027 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef NamedNsDef CCNamedNsDefBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . named_ns_def ( ) ;
}
#line 452 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 10033 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _named_ns_def_1 ) ;
}
#line 452 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 10039 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 452 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 452 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool named_ns_def ();

  struct OriginalNsDef {
#line 10076 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax13OriginalNsDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax13OriginalNsDefE;
#line 455 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 455 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 10085 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax13OriginalNsDef5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13OriginalNsDef5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::OriginalNsDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 456 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 456 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 10123 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13OriginalNsDef5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::OriginalNsDef, ::Puma::CCSyntax::OriginalNsDef, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 456 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 456 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.original_ns_def (); }
    static inline bool parse (CCSyntax &);
  
#line 10141 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef OriginalNsDef CCOriginalNsDefBuilder; public :
#line 10143 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax13OriginalNsDef5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13OriginalNsDef5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 10173 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 10175 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13OriginalNsDef5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::OriginalNsDef, ::Puma::CCSyntax::OriginalNsDef, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a33_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 10187 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . orig_namespace_def ( ) ;
}
#line 458 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 10192 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _original_ns_def_1 ) ;
}
#line 458 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 10198 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 458 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 458 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool original_ns_def ();

  struct OriginalNsDef1 {
#line 10235 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax14OriginalNsDef1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax14OriginalNsDef1E;
#line 461 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 461 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 10244 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14OriginalNsDef15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsDef15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::OriginalNsDef1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 462 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 462 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 10282 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsDef15checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::OriginalNsDef1, ::Puma::CCSyntax::OriginalNsDef1, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 462 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 462 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.original_ns_def1 (); }
    static inline bool parse (CCSyntax &);
  
#line 10300 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef OriginalNsDef1 CCOriginalNsDef1Builder; public :
#line 10302 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14OriginalNsDef15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsDef15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 10332 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 10334 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14OriginalNsDef15buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::OriginalNsDef1, ::Puma::CCSyntax::OriginalNsDef1, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a35_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 10346 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . orig_namespace_def1 ( ) ;
}
#line 464 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 10352 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 464 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 464 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool original_ns_def1 ();

  struct ExtensionNsDef {
#line 10389 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax14ExtensionNsDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax14ExtensionNsDefE;
#line 467 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 467 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 10398 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14ExtensionNsDef5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14ExtensionNsDef5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::ExtensionNsDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 468 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 468 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 10436 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14ExtensionNsDef5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::ExtensionNsDef, ::Puma::CCSyntax::ExtensionNsDef, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 468 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 468 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.extension_ns_def (); }
    static inline bool parse (CCSyntax &);
  
#line 10454 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef ExtensionNsDef CCExtensionNsDefBuilder; public :
#line 10456 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14ExtensionNsDef5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14ExtensionNsDef5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 10486 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 10488 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14ExtensionNsDef5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::ExtensionNsDef, ::Puma::CCSyntax::ExtensionNsDef, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a33_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 10500 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . orig_namespace_def ( ) ;
}
#line 470 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 10505 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _extension_ns_def_1 ) ;
}
#line 470 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 10511 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 470 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 470 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool extension_ns_def ();

  struct ExtensionNsDef1 {
#line 10548 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax15ExtensionNsDef1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax15ExtensionNsDef1E;
#line 473 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 473 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 10557 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax15ExtensionNsDef15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax15ExtensionNsDef15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::ExtensionNsDef1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 474 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 474 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 10595 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax15ExtensionNsDef15checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::ExtensionNsDef1, ::Puma::CCSyntax::ExtensionNsDef1, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 474 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 474 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.extension_ns_def1 (); }
    static inline bool parse (CCSyntax &);
  
#line 10613 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef ExtensionNsDef1 CCExtensionNsDef1Builder; public :
#line 10615 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax15ExtensionNsDef15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax15ExtensionNsDef15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 10645 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 10647 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax15ExtensionNsDef15buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::ExtensionNsDef1, ::Puma::CCSyntax::ExtensionNsDef1, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a36_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 10659 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . orig_namespace_def1 ( ) ;
}
#line 476 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 10665 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 476 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 476 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool extension_ns_def1 ();

  struct UnnamedNsDef {
#line 10702 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax12UnnamedNsDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax12UnnamedNsDefE;
#line 479 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 479 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 10711 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax12UnnamedNsDef5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12UnnamedNsDef5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::UnnamedNsDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 480 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 480 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 10749 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12UnnamedNsDef5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::UnnamedNsDef, ::Puma::CCSyntax::UnnamedNsDef, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 480 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 480 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.unnamed_ns_def (); }
    static inline bool parse (CCSyntax &);
  
#line 10767 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef UnnamedNsDef CCUnnamedNsDefBuilder; public :
#line 10769 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax12UnnamedNsDef5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12UnnamedNsDef5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 10799 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 10801 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12UnnamedNsDef5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::UnnamedNsDef, ::Puma::CCSyntax::UnnamedNsDef, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a33_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 10813 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . orig_namespace_def ( ) ;
}
#line 482 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 10818 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _unnamed_ns_def_1 ) ;
}
#line 482 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 10824 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 482 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 482 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool unnamed_ns_def ();

  struct UnnamedNsDef1 {
#line 10861 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax13UnnamedNsDef1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax13UnnamedNsDef1E;
#line 485 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 485 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 10870 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax13UnnamedNsDef15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13UnnamedNsDef15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::UnnamedNsDef1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 486 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 486 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 10908 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13UnnamedNsDef15checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::UnnamedNsDef1, ::Puma::CCSyntax::UnnamedNsDef1, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 486 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 486 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.unnamed_ns_def1 (); }
    static inline bool parse (CCSyntax &);
  
#line 10926 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef UnnamedNsDef1 CCUnnamedNsDef1Builder; public :
#line 10928 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax13UnnamedNsDef15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13UnnamedNsDef15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 10958 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 10960 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13UnnamedNsDef15buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::UnnamedNsDef1, ::Puma::CCSyntax::UnnamedNsDef1, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a37_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 10972 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . orig_namespace_def1 ( ) ;
}
#line 488 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 10978 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 488 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 488 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool unnamed_ns_def1 ();

  struct NamespaceBody {
#line 11015 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax13NamespaceBodyE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax13NamespaceBodyE;
#line 491 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 491 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 11024 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax13NamespaceBody5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax13NamespaceBody5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::NamespaceBody::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 492 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 492 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 11062 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax13NamespaceBody5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::NamespaceBody, ::Puma::CCSyntax::NamespaceBody, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 492 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 492 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.namespace_body (); }
    static inline bool parse (CCSyntax &);
  
#line 11080 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef NamespaceBody CCNamespaceBodyBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . namespace_body ( ) ;
}
#line 494 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 11087 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 494 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 494 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool namespace_body ();

  struct NsAliasDef {
#line 11124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax10NsAliasDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax10NsAliasDefE;
#line 497 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 497 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 11133 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10NsAliasDef5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10NsAliasDef5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::NsAliasDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 498 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 498 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 11171 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10NsAliasDef5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::NsAliasDef, ::Puma::CCSyntax::NsAliasDef, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 498 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 498 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.ns_alias_def (); }
    static inline bool parse (CCSyntax &);
  
#line 11189 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef NsAliasDef CCNsAliasDefBuilder; public :
#line 11191 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10NsAliasDef5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10NsAliasDef5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 11221 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 11223 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10NsAliasDef5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::NsAliasDef, ::Puma::CCSyntax::NsAliasDef, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a38_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 11235 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . ns_alias_def ( ) ;
}
#line 500 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 11241 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 500 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 500 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool ns_alias_def ();

  struct QualNsSpec {
#line 11278 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax10QualNsSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax10QualNsSpecE;
#line 503 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 503 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 11287 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10QualNsSpec5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10QualNsSpec5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::QualNsSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 504 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 504 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 11325 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10QualNsSpec5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::QualNsSpec, ::Puma::CCSyntax::QualNsSpec, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 504 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 504 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.qual_ns_spec (); }
    
#line 11342 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 505 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 505 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 11350 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef QualNsSpec CCQualNsSpecBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . qual_ns_spec ( ) ;
}
#line 506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 11357 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool qual_ns_spec ();

  struct UsingDecl {
#line 11394 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax9UsingDeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax9UsingDeclE;
#line 509 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 509 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 11403 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax9UsingDecl5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9UsingDecl5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::UsingDecl::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 510 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 510 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 11441 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9UsingDecl5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::UsingDecl, ::Puma::CCSyntax::UsingDecl, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 510 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 510 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.using_decl (); }
    
#line 11458 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 511 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 511 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 11466 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef UsingDecl CCUsingDeclBuilder; public :
#line 11468 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax9UsingDecl5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9UsingDecl5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 11498 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 11500 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9UsingDecl5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::UsingDecl, ::Puma::CCSyntax::UsingDecl, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a41_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 11512 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . using_decl ( ) ;
}
#line 512 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 11518 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 512 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 512 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool using_decl ();

  struct UsingDirective {
#line 11555 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax14UsingDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax14UsingDirectiveE;
#line 515 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 515 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 11564 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14UsingDirective5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14UsingDirective5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::UsingDirective::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 516 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 516 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 11602 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14UsingDirective5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::UsingDirective, ::Puma::CCSyntax::UsingDirective, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 516 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 516 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.using_directive (); }
    
#line 11619 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 517 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 517 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 11627 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef UsingDirective CCUsingDirectiveBuilder; public :
#line 11629 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14UsingDirective5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14UsingDirective5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 11659 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 11661 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14UsingDirective5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::UsingDirective, ::Puma::CCSyntax::UsingDirective, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a43_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 11673 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . using_directive ( ) ;
}
#line 518 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 11679 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 518 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 518 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool using_directive ();

  // A.7 Declarators
  struct InitDeclarator {
#line 11717 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax14InitDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax14InitDeclaratorE;
#line 522 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 522 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 11726 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14InitDeclarator5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14InitDeclarator5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::InitDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 523 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 523 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 11764 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14InitDeclarator5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::InitDeclarator, ::Puma::CCSyntax::InitDeclarator, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 523 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 523 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.init_declarator (); }
    
#line 11781 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 524 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 524 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 11789 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef InitDeclarator CCInitDeclaratorBuilder; public :
#line 11791 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14InitDeclarator5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax14InitDeclarator5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 11821 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 11823 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14InitDeclarator5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::InitDeclarator, ::Puma::CCSyntax::InitDeclarator, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a45_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 11835 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . init_declarator ( ) ;
}
#line 525 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 11841 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 525 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 525 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool init_declarator ();

  struct DirectDeclarator1 {
#line 11878 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax17DirectDeclarator1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax17DirectDeclarator1E;
#line 528 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 528 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 11887 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax17DirectDeclarator15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax17DirectDeclarator15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::DirectDeclarator1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 529 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 529 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 11925 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax17DirectDeclarator15checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::DirectDeclarator1, ::Puma::CCSyntax::DirectDeclarator1, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 529 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 529 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.direct_declarator1 (); }
    static inline bool parse (CCSyntax &);
  
#line 11943 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef DirectDeclarator1 CCDirectDeclarator1Builder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . direct_declarator1 ( ) ;
}
#line 531 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 11949 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _direct_declarator1_1 ) ;
}
#line 531 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 11955 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 531 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 531 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool direct_declarator1 ();

  struct ArrayDelim {
#line 11992 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax10ArrayDelimE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax10ArrayDelimE;
#line 534 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 534 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 12001 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10ArrayDelim5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10ArrayDelim5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::ArrayDelim::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 535 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 535 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 12039 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10ArrayDelim5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::ArrayDelim, ::Puma::CCSyntax::ArrayDelim, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 535 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 535 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.array_delim (); }
    
#line 12056 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 536 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 536 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 12064 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef ArrayDelim CCArrayDelimBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . array_delim ( ) ;
}
#line 537 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 12071 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 537 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 537 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool array_delim ();

  struct PtrOperator {
#line 12108 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax11PtrOperatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax11PtrOperatorE;
#line 540 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 540 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 12117 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax11PtrOperator5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax11PtrOperator5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::PtrOperator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 12155 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax11PtrOperator5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::PtrOperator, ::Puma::CCSyntax::PtrOperator, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.ptr_operator (); }
    
#line 12172 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 542 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 542 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 12180 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef PtrOperator CCPtrOperatorBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . ptr_operator ( ) ;
}
#line 543 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 12187 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 543 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 543 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool ptr_operator ();

  struct DeclaratorId {
#line 12224 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax12DeclaratorIdE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax12DeclaratorIdE;
#line 546 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 546 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 12233 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax12DeclaratorId5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax12DeclaratorId5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::DeclaratorId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 547 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 547 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 12271 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax12DeclaratorId5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::DeclaratorId, ::Puma::CCSyntax::DeclaratorId, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 547 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 547 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.declarator_id (); }
    
#line 12288 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 548 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 548 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 12296 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef DeclaratorId CCDeclaratorIdBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . declarator_id ( ) ;
}
#line 549 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 12303 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 549 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 549 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool declarator_id ();

  struct DirectAbstDeclarator {
#line 12340 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax20DirectAbstDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax20DirectAbstDeclaratorE;
#line 552 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 552 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 12349 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax20DirectAbstDeclarator5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax20DirectAbstDeclarator5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::DirectAbstDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 553 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 553 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 12387 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax20DirectAbstDeclarator5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::DirectAbstDeclarator, ::Puma::CCSyntax::DirectAbstDeclarator, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 553 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 553 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.direct_abst_declarator (); }
    static inline bool parse (CCSyntax &);
  
#line 12405 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef DirectAbstDeclarator CCDirectAbstDeclaratorBuilder; public :
#line 12407 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax20DirectAbstDeclarator5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax20DirectAbstDeclarator5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 12437 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 12439 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax20DirectAbstDeclarator5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::DirectAbstDeclarator, ::Puma::CCSyntax::DirectAbstDeclarator, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a50_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 12451 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . direct_abst_declarator ( ) ;
}
#line 555 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 12457 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 555 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 555 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool direct_abst_declarator ();

  struct ParamDeclClause {
#line 12494 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax15ParamDeclClauseE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax15ParamDeclClauseE;
#line 558 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 558 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 12503 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax15ParamDeclClause5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax15ParamDeclClause5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::ParamDeclClause::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 559 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 559 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 12541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax15ParamDeclClause5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::ParamDeclClause, ::Puma::CCSyntax::ParamDeclClause, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 559 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 559 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.param_decl_clause (); }
    
#line 12558 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 560 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 560 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 12566 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef ParamDeclClause CCParamDeclClauseBuilder; public :
#line 12568 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax15ParamDeclClause5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax15ParamDeclClause5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 12598 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 12600 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax15ParamDeclClause5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::ParamDeclClause, ::Puma::CCSyntax::ParamDeclClause, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a52_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 12612 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . param_decl_clause ( ) ;
}
#line 561 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 12618 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 561 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 561 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool param_decl_clause ();

  CTree * rule_param_decl ();
  virtual bool param_decl ();
  CTree * rule_param_init ();
  virtual bool param_init ();
  CTree * rule_fct_def ();
  
#line 12660 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline bool __exec_old_fct_def();

#line 569 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 569 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
virtual bool fct_def ();
  CTree * rule_skipped_fct_body ();
  virtual bool skipped_fct_body ();
  CTree * rule_fct_body ();
  virtual bool fct_body ();
  CTree * rule_init ();
  virtual bool init ();
  CTree * rule_init_clause ();
  virtual bool init_clause ();

  // A.8 Classes
  CTree *rule_class_spec ();
  virtual bool class_spec ();

  struct ClassHead {
#line 12681 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax9ClassHeadE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax9ClassHeadE;
#line 583 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 583 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 12690 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax9ClassHead5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9ClassHead5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::ClassHead::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 584 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 584 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 12728 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9ClassHead5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::ClassHead, ::Puma::CCSyntax::ClassHead, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 584 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 584 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.class_head (); }
    static inline bool parse (CCSyntax &);
  
#line 12746 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef ClassHead CCClassHeadBuilder; public :
#line 12748 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax9ClassHead5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9ClassHead5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 12778 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 12780 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9ClassHead5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::ClassHead, ::Puma::CCSyntax::ClassHead, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a53_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 12792 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . class_head ( ) ;
}
#line 586 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 12797 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _class_head_1 ) ;
}
#line 586 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 12803 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 586 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 586 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool class_head ();

  struct ClassHead1 {
#line 12840 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax10ClassHead1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax10ClassHead1E;
#line 589 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 589 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 12849 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10ClassHead15checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10ClassHead15checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::ClassHead1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 590 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 590 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 12887 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10ClassHead15checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::ClassHead1, ::Puma::CCSyntax::ClassHead1, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 590 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 590 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.class_head1 (); }
    static inline bool parse (CCSyntax &);
  
#line 12905 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef ClassHead1 CCClassHead1Builder; public :
#line 12907 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10ClassHead15buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10ClassHead15buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 12937 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 12939 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10ClassHead15buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::ClassHead1, ::Puma::CCSyntax::ClassHead1, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a55_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 12951 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . class_head1 ( ) ;
}
#line 592 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 12957 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 592 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 592 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool class_head1 ();

  
#line 12994 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree *__exec_old_rule_member_decl();

#line 595 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 595 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
CTree * rule_member_decl ();
  virtual bool member_decl ();
  
#line 13003 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree *__exec_old_rule_member_decl1();

#line 597 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 597 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
CTree * rule_member_decl1 ();
  virtual bool member_decl1 ();
  CTree * rule_access_decl ();
  virtual bool access_decl ();
  
#line 13014 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree *__exec_old_rule_member_declarator();

#line 601 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 601 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
CTree * rule_member_declarator ();
  virtual bool member_declarator ();
  CTree * rule_pure_spec ();
  virtual bool pure_spec ();
  CTree * rule_const_init ();
  virtual bool const_init ();

  // A.9 Derived classes
  CTree * rule_base_clause ();
  virtual bool base_clause ();
  CTree * rule_base_spec_list ();
  virtual bool base_spec_list ();
  CTree * rule_base_spec ();
  virtual bool base_spec ();
  CTree * rule_access_spec ();
  virtual bool access_spec ();

  // A.10 Special member functions
  struct ConvFctId {
#line 13039 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax9ConvFctIdE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax9ConvFctIdE;
#line 619 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 619 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 13048 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax9ConvFctId5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax9ConvFctId5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::ConvFctId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 620 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 620 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 13086 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax9ConvFctId5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::ConvFctId, ::Puma::CCSyntax::ConvFctId, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 620 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 620 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.conv_fct_id (); }
    
#line 13103 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CCSyntax &);

#line 621 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 621 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool parse (CCSyntax &);
  
#line 13111 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef ConvFctId CCConvFctIdBuilder; public :
static CTree * build ( Puma :: CCSyntax & s ) {
return s . builder ( ) . conv_fct_id ( ) ;
}
#line 622 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 13117 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( CCSyntax * s ) {
return s -> predict_1 ( s -> _conv_fct_id_1 ) ;
}
#line 622 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 13123 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 622 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 622 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool conv_fct_id ();

  struct ConvTypeId {
#line 13160 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax10ConvTypeIdE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax10ConvTypeIdE;
#line 625 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 625 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

    
#line 13169 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10ConvTypeId5checkERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10ConvTypeId5checkERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CCSyntax::ConvTypeId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 626 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 626 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
static inline bool check (CCSyntax &s) 
#line 13207 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10ConvTypeId5checkERN4PumaE8CCSyntax_0< bool, ::Puma::CCSyntax::ConvTypeId, ::Puma::CCSyntax::ConvTypeId, bool (Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CCSyntax &s)
#line 626 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 626 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
{ return s.conv_type_id (); }
    static inline bool parse (CCSyntax &);
  
#line 13225 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef ConvTypeId CCConvTypeIdBuilder; public :
#line 13227 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax10ConvTypeId5buildERN4PumaE8CCSyntax_0 {
  typedef TJP__ZN4Puma8CCSyntax10ConvTypeId5buildERN4PumaE8CCSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 13257 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
static CTree * build ( Puma :: CCSyntax & s ) 
#line 13259 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax10ConvTypeId5buildERN4PumaE8CCSyntax_0< ::Puma::CTree *, ::Puma::CCSyntax::ConvTypeId, ::Puma::CCSyntax::ConvTypeId, Puma::CTree *(Puma::CCSyntax &),  AC::TL< ::Puma::CCSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CCSemBinding_CCSemBinding__a59_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CCSyntax &s)
#line 13271 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
return s . builder ( ) . type_id ( ) ;
}
#line 628 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
  public: static inline bool lookahead ( void * ) { return true ; }
#line 13277 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 628 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 628 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  virtual bool conv_type_id ();

  CTree * rule_conv_declarator ();
  virtual bool conv_declarator ();
  CTree * rule_ctor_init ();
  virtual bool ctor_init ();
  CTree * rule_mem_init_list ();
  virtual bool mem_init_list ();
  CTree * rule_mem_init ();
  virtual bool mem_init ();
  CTree * rule_mem_init_id ();
  virtual bool mem_init_id ();

  // A.11 Overloading
  CTree *rule_oper_fct_id ();
  virtual bool oper_fct_id ();

  // A.12 Templates
  CTree * rule_template_key (); 
  virtual bool template_key (); 
  CTree * rule_template_decl (); 
  
#line 13333 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline bool __exec_old_template_decl();

#line 650 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 650 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
virtual bool template_decl (); 
  
#line 13341 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree *__exec_old_rule_member_template_decl();

#line 651 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 651 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
CTree * rule_member_template_decl (); 
  
#line 13349 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline bool __exec_old_member_template_decl();

#line 652 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 652 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
virtual bool member_template_decl (); 
  CTree * rule_template_param_list (); 
  virtual bool template_param_list (); 
  CTree * rule_template_param (); 
  virtual bool template_param (); 
  CTree * rule_type_param (); 
  virtual bool type_param (); 
  CTree * rule_non_type_param (); 
  virtual bool non_type_param (); 
  CTree *rule_template_id (); 
  virtual bool template_id ();
  CTree *rule_class_template_id (); 
  virtual bool class_template_id ();
  CTree * rule_template_arg_list (); 
  virtual bool template_arg_list (); 
  CTree * rule_template_arg (); 
  virtual bool template_arg (); 
  CTree * rule_template_type_arg (); 
  virtual bool template_type_arg (); 
  CTree * rule_template_non_type_arg (); 
  virtual bool template_non_type_arg (); 
  CTree * rule_template_template_arg (); 
  virtual bool template_template_arg (); 
  CTree * rule_explicit_instantiation (); 
  
#line 13380 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline bool __exec_old_explicit_instantiation();

#line 676 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 676 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
virtual bool explicit_instantiation (); 
  CTree * rule_explicit_specialization (); 
  
#line 13389 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
public: __attribute__((always_inline)) inline bool __exec_old_explicit_specialization();

#line 678 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 678 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
virtual bool explicit_specialization (); 

  // A.13 Exception handling
  CTree * rule_try_block ();
  virtual bool try_block ();
  CTree * rule_fct_try_block ();
  virtual bool fct_try_block ();
  CTree * rule_handler_seq ();
  virtual bool handler_seq ();
  CTree * rule_handler ();
  virtual bool handler ();
  CTree * rule_exception_decl ();
  virtual bool exception_decl ();
  CTree * rule_throw_expr ();
  virtual bool throw_expr ();
  CTree * rule_exception_spec ();
  virtual bool exception_spec ();
  CTree * rule_type_id_list (); 
  virtual bool type_id_list (); 

protected:
  void skip_param_init ();
  void skip_ctor_init ();
  void skip_fct_body ();
  void skip_fct_try_block ();
  void skip_const_expr ();
  void skip_const_init ();

protected:
  struct SearchScope {
#line 13425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma8CCSyntax11SearchScopeE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CCSyntax11SearchScopeE;
#line 707 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 707 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
 CStructure *scope, *last_scope; bool dep;   public: static inline bool lookahead ( void * ) { return true ; }
#line 13433 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 707 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 707 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};
  void get_search_scope (SearchScope &);
  void set_search_scope (SearchScope &);
#line 13469 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  public: protected :


tokenset _class_name_1 ;
tokenset _enum_name_1 ;
tokenset _template_name_1 ;
tokenset _class_template_name_1 ;
tokenset _namespace_name_1 ;
tokenset _original_ns_name_1 ;
tokenset _namespace_alias_1 ;
tokenset _qual_id_1 ;
tokenset _unqual_id_1 ;
tokenset _colon_colon_1 ;
tokenset _nested_name_spec_1 ;
tokenset _nested_name_spec1_1 ;
tokenset _class_or_ns_name_1 ;
tokenset _construct_expr_1 ;
tokenset _type_trait_expr_1 ;
tokenset _new_expr_1 ;
tokenset _new_placement_1 ;
tokenset _direct_new_declarator_1 ;
tokenset _direct_new_declarator1_1 ;
tokenset _new_init_1 ;
tokenset _delete_expr_1 ;
tokenset _namespace_def_1 ;
tokenset _named_ns_def_1 ;
tokenset _original_ns_def_1 ;

tokenset _explicit_instantiation_1 ;
tokenset _explicit_specialization_1 ;
tokenset _access_spec_1 ;
tokenset _conv_fct_id_1 ;
tokenset _oper_fct_id_1 ;
tokenset _template_key_1 ;
tokenset _template_id_1 ;
tokenset _extension_ns_def_1 ;
tokenset _unnamed_ns_def_1 ;

virtual void init_class_name ( ) {
init_class_template_id ( ) ;
_class_name_1 = _template_id_1 ;
_class_name_1 . set ( TOK_ID ) ;
}

virtual void init_enum_name ( ) {
_enum_name_1 . set ( TOK_ID ) ;
}

virtual void init_template_name ( ) {
_template_name_1 . set ( TOK_ID ) ;
}

virtual void init_class_template_name ( ) {
_class_template_name_1 . set ( TOK_ID ) ;
}

virtual void init_namespace_name ( ) {
init_original_ns_name ( ) ;
init_namespace_alias ( ) ;
_namespace_name_1 = _original_ns_name_1 ;
_namespace_name_1 |= _namespace_alias_1 ;
}

virtual void init_original_ns_name ( ) {
_original_ns_name_1 . set ( TOK_ID ) ;
}

virtual void init_namespace_alias ( ) {
_namespace_alias_1 . set ( TOK_ID ) ;
}

virtual void init_literal ( ) {
CSyntax :: init_literal ( ) ;
_literal_1 . set ( TOK_BOOL_VAL ) ;
}

virtual void init_prim_expr ( ) {
CSyntax :: init_prim_expr ( ) ;
_prim_expr_1 . set ( TOK_THIS ) ;
}

virtual void init_id_expr ( ) {

init_qual_id ( ) ;
init_unqual_id ( ) ;
_id_expr_1 = _qual_id_1 ;
_id_expr_1 |= _unqual_id_1 ;
}

virtual void init_qual_id ( ) {
init_colon_colon ( ) ;
init_nested_name_spec ( ) ;
_qual_id_1 = _colon_colon_1 ;
_qual_id_1 |= _nested_name_spec_1 ;
}

virtual void init_unqual_id ( ) {
init_identifier ( ) ;
init_oper_fct_id ( ) ;
init_conv_fct_id ( ) ;
init_template_id ( ) ;
_unqual_id_1 = _identifier_1 ;
_unqual_id_1 |= _oper_fct_id_1 ;
_unqual_id_1 |= _conv_fct_id_1 ;
_unqual_id_1 |= _template_id_1 ;
_unqual_id_1 . set ( TOK_TILDE ) ;
}

virtual void init_colon_colon ( ) {
_colon_colon_1 . set ( TOK_COLON_COLON ) ;
}

virtual void init_nested_name_spec ( ) {
init_nested_name_spec1 ( ) ;
_nested_name_spec_1 = _nested_name_spec1_1 ;
}

virtual void init_nested_name_spec1 ( ) {
init_class_or_ns_name ( ) ,
init_template_key ( ) ;
_nested_name_spec1_1 = _class_or_ns_name_1 ;
_nested_name_spec1_1 |= _template_key_1 ;
}

virtual void init_class_or_ns_name ( ) {
init_class_name ( ) ;
init_namespace_name ( ) ;
_class_or_ns_name_1 = _class_name_1 ;
_class_or_ns_name_1 |= _namespace_name_1 ;
}

virtual void init_postfix_expr1 ( ) {
CSyntax :: init_postfix_expr1 ( ) ;
}

#line 13605 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax21init_simple_type_specEv_0 {
  typedef TJP__ZN4Puma8CCSyntax21init_simple_type_specEv_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef TEntity TTarget::* MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};

#line 13630 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
virtual void init_simple_type_spec ( ) 
#line 13632 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax21init_simple_type_specEv_0< void, ::Puma::CCSyntax, ::Puma::CCSyntax, void (),  AC::TLE > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
  this->__exec_old_init_simple_type_spec();
  AC::invoke_ExtGnu_ExtGnu__a38_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_init_simple_type_spec()
#line 13642 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
init_prim_types ( ) ;
init_type_name ( ) ;
init_nested_name_spec ( ) ;
init_colon_colon ( ) ;
_simple_type_spec_1 = _prim_types ;
_simple_type_spec_1 |= _type_name_1 ;
_simple_type_spec_1 |= _nested_name_spec_1 ;
_simple_type_spec_1 |= _colon_colon_1 ;
}

virtual void init_construct_expr ( ) {
init_simple_type_spec ( ) ;
_construct_expr_1 = _simple_type_spec_1 ;
_construct_expr_1 . set ( TOK_TYPENAME ) ;
}

virtual void init_type_trait_expr ( ) {
_type_trait_expr_1 . set ( TOK_HAS_NOTHROW_ASSIGN ) ;
_type_trait_expr_1 . set ( TOK_HAS_NOTHROW_COPY ) ;
_type_trait_expr_1 . set ( TOK_HAS_NOTHROW_CTOR ) ;
_type_trait_expr_1 . set ( TOK_HAS_TRIVIAL_ASSIGN ) ;
_type_trait_expr_1 . set ( TOK_HAS_TRIVIAL_COPY ) ;
_type_trait_expr_1 . set ( TOK_HAS_TRIVIAL_CTOR ) ;
_type_trait_expr_1 . set ( TOK_HAS_TRIVIAL_DTOR ) ;
_type_trait_expr_1 . set ( TOK_HAS_VIRTUAL_DTOR ) ;
_type_trait_expr_1 . set ( TOK_IS_ABSTRACT ) ;
_type_trait_expr_1 . set ( TOK_IS_CLASS ) ;
_type_trait_expr_1 . set ( TOK_IS_EMPTY ) ;
_type_trait_expr_1 . set ( TOK_IS_ENUM ) ;
_type_trait_expr_1 . set ( TOK_IS_POD ) ;
_type_trait_expr_1 . set ( TOK_IS_TRIVIAL ) ;
_type_trait_expr_1 . set ( TOK_IS_POLYMORPHIC ) ;
_type_trait_expr_1 . set ( TOK_IS_UNION ) ;
_type_trait_expr_1 . set ( TOK_IS_BASE_OF ) ;
}

virtual void init_new_expr ( ) {
_new_expr_1 . set ( TOK_NEW ) ;
_new_expr_1 . set ( TOK_COLON_COLON ) ;
}

virtual void init_new_placement ( ) {
_new_placement_1 . set ( TOK_OPEN_ROUND ) ;
}

virtual void init_direct_new_declarator ( ) {
_direct_new_declarator_1 . set ( TOK_OPEN_SQUARE ) ;
}

virtual void init_direct_new_declarator1 ( ) {
_direct_new_declarator1_1 . set ( TOK_OPEN_SQUARE ) ;
}

virtual void init_new_init ( ) {
_new_init_1 . set ( TOK_OPEN_ROUND ) ;
}

virtual void init_delete_expr ( ) {
_delete_expr_1 . set ( TOK_DELETE ) ;
_delete_expr_1 . set ( TOK_COLON_COLON ) ;
}

#line 13706 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax14init_misc_specEv_0 {
  typedef TJP__ZN4Puma8CCSyntax14init_misc_specEv_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef TEntity TTarget::* MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};

#line 13731 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
virtual void init_misc_spec ( ) 
#line 13733 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax14init_misc_specEv_0< void, ::Puma::CCSyntax, ::Puma::CCSyntax, void (),  AC::TLE > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
  this->__exec_old_init_misc_spec();
  AC::invoke_WinDeclSpecs_WinDeclSpecs__a0_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_init_misc_spec()
#line 13743 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
CSyntax :: init_misc_spec ( ) ;
_misc_spec_1 . set ( TOK_FRIEND ) ;
}

#line 13749 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma8CCSyntax23init_storage_class_specEv_0 {
  typedef TJP__ZN4Puma8CCSyntax23init_storage_class_specEv_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef TEntity TTarget::* MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};

#line 13774 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
virtual void init_storage_class_spec ( ) 
#line 13776 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
  typedef TJP__ZN4Puma8CCSyntax23init_storage_class_specEv_0< void, ::Puma::CCSyntax, ::Puma::CCSyntax, void (),  AC::TLE > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
  this->__exec_old_init_storage_class_spec();
  AC::invoke_ExtGnu_ExtGnu__a36_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_init_storage_class_spec()
#line 13786 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
{
CSyntax :: init_storage_class_spec ( ) ;
_storage_class_spec_1 . set ( TOK_MUTABLE ) ;
}

virtual void init_fct_spec ( ) {
CSyntax :: init_fct_spec ( ) ;
_fct_spec_1 . set ( TOK_VIRTUAL ) ;
_fct_spec_1 . set ( TOK_EXPLICIT ) ;
}

virtual void init_type_name ( ) {
init_class_name ( ) ;
init_enum_name ( ) ;
init_typedef_name ( ) ;
_type_name_1 = _class_name_1 ;
_type_name_1 |= _enum_name_1 ;
_type_name_1 |= _typedef_name_1 ;
}

virtual void init_elaborated_type_spec ( ) {
init_class_key ( ) ;
_elaborated_type_spec_1 = _class_key_1 ;
_elaborated_type_spec_1 . set ( TOK_ENUM ) ;
_elaborated_type_spec_1 . set ( TOK_TYPENAME ) ;
}

virtual void init_namespace_def ( ) {
init_named_ns_def ( ) ;
init_unnamed_ns_def ( ) ;
_namespace_def_1 = _named_ns_def_1 ;
_namespace_def_1 |= _unnamed_ns_def_1 ;
}

virtual void init_named_ns_def ( ) {
init_original_ns_def ( ) ;
init_extension_ns_def ( ) ;
_named_ns_def_1 = _original_ns_def_1 ;
_named_ns_def_1 |= _extension_ns_def_1 ;
}


virtual void init_original_ns_def ( ) {
_original_ns_def_1 . set ( TOK_NAMESPACE ) ;
_original_ns_def_1 . set ( TOK_INLINE ) ;
}


virtual void init_extension_ns_def ( ) {
_extension_ns_def_1 . set ( TOK_NAMESPACE ) ;
_extension_ns_def_1 . set ( TOK_INLINE ) ;
}


virtual void init_unnamed_ns_def ( ) {
_unnamed_ns_def_1 . set ( TOK_NAMESPACE ) ;
_unnamed_ns_def_1 . set ( TOK_INLINE ) ;
}

virtual void init_class_key ( ) {
CSyntax :: init_class_key ( ) ;
_class_key_1 . set ( TOK_CLASS ) ;
}

virtual void init_conv_fct_id ( ) {
_conv_fct_id_1 . set ( TOK_OPERATOR ) ;
}
#line 710 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 13855 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"
  private: typedef CCSyntax WinMemberExplSpecSyntax; CTree * rule_member_explicit_specialization ( ) ;
virtual bool member_explicit_specialization ( ) ;
#line 710 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
#line 13859 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CCSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 710 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"

#line 710 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CCSyntax.h"
};


} // namespace Puma

#endif /* __CCSyntax_h__ */

#ifdef __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_CCSyntax_h__
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#include "Puma/CCExprResolveCC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#include "Puma/CExprResolveCC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#include "Puma/SyntaxState.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#include "Puma/CCSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#include "Puma/WinIfExists.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#include "Puma/WinImportHandler.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#include "Puma/WinMacros.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#include "Puma/ExtGnuCInfos.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#include "Puma/ExtGnuCSemantic.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#include "Puma/ExtGnuCSemExpr.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#include "Puma/ExtGnuCSemDeclSpecs.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#include "Puma/PragmaOnce.ah"
#endif
#endif
#undef __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#undef __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_CCSyntax_h__
#endif // __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_CCSyntax_h__

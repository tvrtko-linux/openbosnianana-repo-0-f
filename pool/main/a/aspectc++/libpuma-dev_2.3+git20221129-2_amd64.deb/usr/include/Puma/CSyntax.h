#ifndef __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#define __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#define __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_CSyntax_h__
#ifndef __ac_have_predefined_includes__
#define __ac_have_predefined_includes__
#endif // __ac_have_predefined_includes__

#ifndef __ac_h_
#define __ac_h_
#ifdef __cplusplus
namespace AC {
  typedef const char* Type;
  enum JPType { CALL = 262144, EXECUTION = 16777216, CONSTRUCTION = 33554432, DESTRUCTION = 67108864 };
  enum Protection { PROT_NONE, PROT_PRIVATE, PROT_PROTECTED, PROT_PUBLIC };
  enum Specifiers { SPEC_NONE = 0x0 , SPEC_STATIC = 0x1, SPEC_MUTABLE = 0x2, SPEC_VIRTUAL = 0x4 };
  struct Action {
    void **_args; void *_result; void *_entity; void *_target; void *_that; void *_fptr;
    void (*_wrapper)(Action &);
    inline void trigger () { _wrapper (*this); }
  };
  template <typename T> struct ResultBuffer {
    char _data[sizeof (T)];
    void operator = (const T& t) { *this = (const ResultBuffer &)t; }
  };
  template <typename T, typename N> struct TL {
    typedef T type; typedef N next; enum { ARGS = next::ARGS + 1 };
  };
  struct TLE { enum { ARGS = 0 }; };
  template <typename T> struct Referred { typedef T type; };
  template <typename T> struct Referred<T &> { typedef T type; };
  template <typename TL, int I> struct Arg {
    typedef typename Arg<typename TL::next, I - 1>::Type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename TL> struct Arg<TL, 0> {
    typedef typename TL::type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename T> int ttest(...);
  template <typename T> char ttest(typename T::__TI const volatile *);
  template<typename T> struct HasTypeInfo {
    enum { RET=((sizeof(ttest<T>(0))==1)?1:0) };
  };
  template<typename T, int HAVE = HasTypeInfo<T>::RET> struct TypeInfo {
    enum { AVAILABLE = 0, BASECLASSES = 0, MEMBERS = 0, FUNCTIONS = 0,
           CONSTRUCTORS = 0, DESTRUCTORS = 0 };
    typedef T That;
  };
  template<typename T> struct TypeInfo<T, 1> : T::__TI {
    enum { AVAILABLE = 1 };
  };
  template<typename T> struct RT {};
  template<typename T> RT<T> rt_deduce (const T&) { return RT<T>(); }
  template<typename T> RT<T> rt_deduce (const volatile T&) { return RT<T>(); }
  struct Cnv { template<typename T> operator RT<T>() const { return RT<T>(); }};
  #define __AC_TYPEOF(expr) (1?AC::Cnv():AC::rt_deduce(expr))
  template <class Aspect, int Index>
  struct CFlow {
    static int &instance () {
      static int counter = 0;
      return counter;
    }
    CFlow () { instance ()++; }
    ~CFlow () { instance ()--; }
    static bool active () { return instance () > 0; }
  };
}
#endif // __cplusplus
#endif // __ac_h_
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACTree;
class ExtGnu;
class ExtGnuCTree;
class ExtGnuKeywords;
class PragmaOnceUnitState;
class PragmaOnce;
#endif // __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#line 99 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

#ifndef __ac_fwd_CLookAhead__
#define __ac_fwd_CLookAhead__
class CLookAhead;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CLookAhead_CLookAhead__a0_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#endif

#ifndef __ac_fwd_WinAsm__
#define __ac_fwd_WinAsm__
class WinAsm;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinAsm_WinAsm__a0_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#endif

#ifndef __ac_fwd_WinDeclSpecs__
#define __ac_fwd_WinDeclSpecs__
class WinDeclSpecs;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs__a0_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs__a1_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs__a2_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinDeclSpecs_WinDeclSpecs__a3_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#endif

#ifndef __ac_fwd_WinTypeKeywords__
#define __ac_fwd_WinTypeKeywords__
class WinTypeKeywords;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_WinTypeKeywords_WinTypeKeywords__a0_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#endif

#ifndef __ac_fwd_LookAhead__
#define __ac_fwd_LookAhead__
class LookAhead;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_LookAhead_LookAhead__a0_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#endif

#ifndef __ac_fwd_CSemBinding__
#define __ac_fwd_CSemBinding__
class CSemBinding;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a0_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a1_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a2_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a3_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a4_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a5_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a6_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a7_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a8_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a9_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a10_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a11_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a12_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a13_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a14_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a15_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a16_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a17_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a18_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a19_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a20_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a21_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a22_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a23_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a24_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a25_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a26_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a27_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a28_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a29_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a30_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_CSemBinding_CSemBinding__a31_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#endif

#ifndef __ac_fwd_ExtGnu__
#define __ac_fwd_ExtGnu__
class ExtGnu;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a0_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a1_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a2_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a3_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a4_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a5_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a6_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a7_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a8_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a9_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a10_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a11_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a12_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a13_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a14_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a15_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a16_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a17_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a18_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a19_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a20_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a21_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a22_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a23_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a24_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a25_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a26_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a27_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a28_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a29_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a30_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a31_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a32_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a33_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a34_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a35_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a36_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a37_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a38_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a39_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a40_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a41_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a42_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a43_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a44_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a45_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a46_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a47_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a48_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a49_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a50_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a51_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a52_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a53_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a54_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a55_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a56_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a57_before (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a58_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnu_ExtGnu__a59_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#endif

#line 1 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 1 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
// This file is part of PUMA.
// Copyright (C) 1999-2003  The PUMA developer team.
//                                                                
// This program is free software;  you can redistribute it and/or 
// modify it under the terms of the GNU General Public License as 
// published by the Free Software Foundation; either version 2 of 
// the License, or (at your option) any later version.            
//                                                                
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
// GNU General Public License for more details.                   
//                                                                
// You should have received a copy of the GNU General Public      
// License along with this program; if not, write to the Free     
// Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
// MA  02111-1307  USA                                            

#ifndef __CSyntax_h__
#define __CSyntax_h__

/** \file 
 *  Parser for the C programming language (C99). */

#include "Puma/Syntax.h"
#include "Puma/CBuilder.h"
#include "Puma/CSemantic.h"
#include "Puma/CTokens.h"

namespace Puma {


#line 413 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 423 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 433 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 443 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 453 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 463 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 473 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 483 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 493 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 503 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 513 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 523 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 533 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 543 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 553 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 563 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 573 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 583 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 593 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 603 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 613 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 623 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 633 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 643 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 653 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 663 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 673 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 683 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 693 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 703 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 713 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 723 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 733 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 743 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 753 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 763 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 773 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 783 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 793 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 803 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 813 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 823 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 833 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 843 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 853 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 863 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 873 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 883 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 893 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 903 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 913 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 923 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 933 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 943 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 953 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 963 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 973 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 983 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 993 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1003 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1013 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1023 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1033 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1043 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1053 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1063 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1073 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1083 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1093 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1103 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1113 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1123 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1133 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1143 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1153 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1163 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1173 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1183 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1203 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1213 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1223 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1233 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1243 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1253 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1263 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1273 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1283 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1293 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1303 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1313 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1323 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1333 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1353 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1363 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1373 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1383 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1393 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1403 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1413 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1423 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1433 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1443 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1453 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1463 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1473 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1483 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1493 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1503 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1513 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1523 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1533 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1543 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1553 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1563 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1573 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1583 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1593 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1603 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1613 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1623 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1633 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1643 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1653 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1663 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1673 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1683 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1693 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1703 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1713 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1723 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1733 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1743 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1753 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1763 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1773 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1783 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1793 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1803 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1813 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1823 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1833 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1843 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1853 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1863 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1873 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1883 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1893 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1903 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1913 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1923 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1933 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1943 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1953 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1963 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1973 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1983 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 1993 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2003 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2013 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2023 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2033 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2043 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2053 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2063 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2073 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2083 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2093 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2103 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2113 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2123 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2133 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2143 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2153 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2163 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2173 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2183 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2203 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2213 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2223 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2233 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2243 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2253 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2263 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2273 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2283 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2293 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2303 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2313 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2323 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
namespace Puma {

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
class CSyntax : public Syntax {
#line 2336 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntaxE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntaxE;
private:
#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 33 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

public:
  CSyntax (CBuilder &, CSemantic &);
  
#line 2348 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline void __exec_old_configure(::Puma::Config &);

#line 36 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 36 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
virtual void configure (Config &);

  enum Grammar { GRAMMAR_C, GRAMMAR_CPLUSPLUS };
  virtual Grammar grammar () const { return GRAMMAR_C; }

private:
  CBuilder &builder () const { return (CBuilder&)Syntax::builder (); }
  CSemantic &semantic () const { return (CSemantic&)Syntax::semantic (); }

protected:
  // Faster check for primitive types
  tokenset _prim_types;
  
#line 2367 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline void __exec_old_init_prim_types();
protected:

#line 48 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 48 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
virtual void init_prim_types ();
  bool is_prim_type () { return _prim_types[look_ahead ()]; }

  // Faster check for cv qualifiers
  tokenset _cv_quals;
  
#line 2380 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline void __exec_old_init_cv_quals();
protected:

#line 53 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 53 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
virtual void init_cv_quals ();
  bool is_cv_qual () { return _cv_quals[look_ahead ()]; }

  // FIRST and FOLLOW sets
  tokenset _class_spec_1;

  // FIRST and FOLLOW initialization
  virtual void init_class_spec ();

  // result cache!
  Token *last_look_ahead_token;
  bool last_look_ahead_result;

  // Grammar rules

public:
  // A.1 Keywords

  struct TypedefName {
#line 2406 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax11TypedefNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax11TypedefNameE;
#line 71 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 71 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 2415 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax11TypedefName5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11TypedefName5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::TypedefName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 72 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 72 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 2453 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11TypedefName5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::TypedefName, ::Puma::CSyntax::TypedefName, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 72 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 72 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.typedef_name (); }
    static inline bool parse (CSyntax &);
  
#line 2471 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef TypedefName CTypedefNameBuilder; public :
#line 2473 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax11TypedefName5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11TypedefName5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 2503 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 2505 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11TypedefName5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::TypedefName, ::Puma::CSyntax::TypedefName, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a1_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 2517 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . semantic ( ) . typedef_name ( ) ;
}
#line 74 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2522 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _typedef_name_1 ) ;
}
#line 74 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 2528 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 74 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 74 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool typedef_name ();

  struct PrivateName {
#line 2565 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax11PrivateNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax11PrivateNameE;
#line 77 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 77 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 2574 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax11PrivateName5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11PrivateName5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::PrivateName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 78 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 78 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 2612 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11PrivateName5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::PrivateName, ::Puma::CSyntax::PrivateName, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 78 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 78 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.private_name (); }
    static inline bool parse (CSyntax &);
  
#line 2630 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef PrivateName CPrivateNameBuilder; public :
#line 2632 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax11PrivateName5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11PrivateName5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 2662 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 2664 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11PrivateName5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::PrivateName, ::Puma::CSyntax::PrivateName, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a0_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 2676 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . semantic ( ) . PrivateName ( ) ;
}
#line 80 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 2682 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 80 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 80 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool private_name ();

  // A.2 Lexical conventions

  struct Identifier {
#line 2721 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax10IdentifierE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax10IdentifierE;
#line 85 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 85 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 2730 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10Identifier5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10Identifier5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::Identifier::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 86 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 86 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 2768 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10Identifier5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::Identifier, ::Puma::CSyntax::Identifier, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 86 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 86 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.identifier (); }
    static inline bool parse (CSyntax &);
  
#line 2786 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef Identifier CIdentifierBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . simple_name ( ) ;
}
#line 88 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2792 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _identifier_1 ) ;
}
#line 88 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 2798 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 88 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 88 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool identifier ();
  
  struct Literal {
#line 2835 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax7LiteralE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax7LiteralE;
#line 91 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 91 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 2844 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax7Literal5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7Literal5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::Literal::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 92 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 92 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 2882 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7Literal5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::Literal, ::Puma::CSyntax::Literal, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 92 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 92 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.literal (); }
    static bool parse (CSyntax &);
  
#line 2900 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef Literal CLiteralBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . literal ( ) ;
}
#line 94 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 2906 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _literal_1 ) ;
}
#line 94 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 2912 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 94 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 94 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool literal ();
  
  struct CmpdStr {
#line 2949 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax7CmpdStrE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax7CmpdStrE;
#line 97 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 97 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 2958 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax7CmpdStr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7CmpdStr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::CmpdStr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 98 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 98 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 2996 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7CmpdStr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::CmpdStr, ::Puma::CSyntax::CmpdStr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 98 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 98 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cmpd_str (); }
    static inline bool parse (CSyntax &);
  
#line 3014 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef CmpdStr CCmpdStrBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cmpd_str ( ) ;
}
#line 100 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 3020 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _cmpd_str_1 ) ;
}
#line 100 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 3026 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 100 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 100 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool cmpd_str ();
  
  struct StrLiteral {
#line 3063 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax10StrLiteralE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax10StrLiteralE;
#line 103 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 103 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3072 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10StrLiteral5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10StrLiteral5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::StrLiteral::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 104 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 104 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 3110 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10StrLiteral5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::StrLiteral, ::Puma::CSyntax::StrLiteral, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 104 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 104 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.str_literal (); }
    static inline bool parse (CSyntax &);
  
#line 3128 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef StrLiteral CStrLiteralBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . str_literal ( ) ;
}
#line 106 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 3134 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _str_literal_1 ) ;
}
#line 106 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 3140 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 106 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 106 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool str_literal ();
  
  // A.3 Basic concepts 

  struct TransUnit {
#line 3179 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax9TransUnitE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax9TransUnitE;
#line 111 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 111 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3188 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9TransUnit5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9TransUnit5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::TransUnit::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 112 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 112 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 3226 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9TransUnit5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::TransUnit, ::Puma::CSyntax::TransUnit, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 112 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 112 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.trans_unit (); }
    static inline bool parse (CSyntax &);
  
#line 3244 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef TransUnit CTransUnitBuilder; public :
#line 3246 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9TransUnit5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9TransUnit5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 3276 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 3278 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9TransUnit5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::TransUnit, ::Puma::CSyntax::TransUnit, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a2_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 3290 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . trans_unit ( ) ;
}
#line 114 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 3296 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 114 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 114 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool trans_unit ();

  // A.4 Expression
  struct PrimExpr {
#line 3334 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax8PrimExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax8PrimExprE;
#line 118 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 118 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8PrimExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8PrimExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::PrimExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 119 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 119 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 3381 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8PrimExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::PrimExpr, ::Puma::CSyntax::PrimExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 119 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 119 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.prim_expr (); }
    
#line 3398 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax &);

#line 120 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 120 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static bool parse (CSyntax &);
  
#line 3406 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef PrimExpr CPrimExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . prim_expr ( ) ;
}
#line 121 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 3412 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _prim_expr_1 ) ;
}
#line 121 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 3418 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 121 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 121 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool prim_expr ();

  struct IdExpr {
#line 3455 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax6IdExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax6IdExprE;
#line 124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3464 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax6IdExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax6IdExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::IdExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 125 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 125 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 3502 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax6IdExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::IdExpr, ::Puma::CSyntax::IdExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 125 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 125 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.id_expr (); }
    static inline bool parse (CSyntax &);
  
#line 3520 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef IdExpr CIdExprBuilder; public :
#line 3522 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax6IdExpr5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax6IdExpr5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 3552 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 3554 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax6IdExpr5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::IdExpr, ::Puma::CSyntax::IdExpr, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a3_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 3566 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . simple_name ( ) ;
}
#line 127 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 3571 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _id_expr_1 ) ;
}
#line 127 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 3577 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 127 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 127 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool id_expr ();

  struct CmpdLiteral {
#line 3614 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax11CmpdLiteralE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax11CmpdLiteralE;
#line 130 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 130 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3623 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax11CmpdLiteral5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11CmpdLiteral5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::CmpdLiteral::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 131 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 131 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 3661 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11CmpdLiteral5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::CmpdLiteral, ::Puma::CSyntax::CmpdLiteral, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 131 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 131 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cmpd_literal (); }
    static inline bool parse (CSyntax &);
  
#line 3679 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef CmpdLiteral CCmpdLiteralBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cmpd_literal ( ) ;
}
#line 133 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 3686 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 133 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 133 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool cmpd_literal ();

  struct PostfixExpr {
#line 3723 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax11PostfixExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax11PostfixExprE;
#line 136 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 136 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3732 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax11PostfixExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11PostfixExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::PostfixExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 137 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 137 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 3770 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11PostfixExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::PostfixExpr, ::Puma::CSyntax::PostfixExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 137 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 137 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.postfix_expr (); }
    static inline bool parse (CSyntax &);
  
#line 3788 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef PostfixExpr CPostfixExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . postfix_expr ( ) ;
}
#line 139 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 3794 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _postfix_expr_1 ) ;
}
#line 139 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 3800 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 139 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 139 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool postfix_expr ();

  struct PostfixExpr1 {
#line 3837 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax12PostfixExpr1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax12PostfixExpr1E;
#line 142 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 142 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3846 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax12PostfixExpr15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12PostfixExpr15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::PostfixExpr1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 143 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 143 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 3884 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12PostfixExpr15checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::PostfixExpr1, ::Puma::CSyntax::PostfixExpr1, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 143 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 143 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.postfix_expr1 (); }
    static inline bool parse (CSyntax &);
  
#line 3902 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef PostfixExpr1 CPostfixExpr1Builder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . postfix_expr1 ( ) ;
}
#line 145 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 3908 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _postfix_expr1_1 ) ;
}
#line 145 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 3914 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 145 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 145 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool postfix_expr1 ();

  struct ExprList {
#line 3951 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax8ExprListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax8ExprListE;
#line 148 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 148 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 3960 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8ExprList5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8ExprList5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::ExprList::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 149 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 149 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 3998 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8ExprList5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::ExprList, ::Puma::CSyntax::ExprList, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 149 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 149 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.expr_list (); }
    static inline bool parse (CSyntax &);
  
#line 4016 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef ExprList CExprListBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . expr_list ( ) ;
}
#line 151 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 4023 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 151 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 151 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool expr_list ();

  struct UnaryExpr {
#line 4060 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax9UnaryExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax9UnaryExprE;
#line 154 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 154 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4069 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9UnaryExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9UnaryExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::UnaryExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 155 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 155 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 4107 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9UnaryExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::UnaryExpr, ::Puma::CSyntax::UnaryExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 155 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 155 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.unary_expr (); }
    
#line 4124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax &);

#line 156 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 156 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
  
#line 4132 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef UnaryExpr CUnaryExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . unary_expr ( ) ;
}
#line 157 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 4139 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 157 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 157 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool unary_expr ();

  struct UnaryExpr1 {
#line 4176 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax10UnaryExpr1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax10UnaryExpr1E;
#line 160 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 160 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4185 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10UnaryExpr15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10UnaryExpr15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::UnaryExpr1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 161 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 161 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 4223 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10UnaryExpr15checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::UnaryExpr1, ::Puma::CSyntax::UnaryExpr1, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 161 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 161 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.unary_expr1 (); }
    static inline bool parse (CSyntax &);
  
#line 4241 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef UnaryExpr1 CUnaryExpr1Builder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . unary_expr1 ( ) ;
}
#line 163 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 4248 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 163 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 163 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool unary_expr1 ();

  struct CastExpr {
#line 4285 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax8CastExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax8CastExprE;
#line 166 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 166 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4294 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8CastExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8CastExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::CastExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 167 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 167 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 4332 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8CastExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::CastExpr, ::Puma::CSyntax::CastExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 167 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 167 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cast_expr (); }
    static inline bool parse (CSyntax &);
  
#line 4350 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef CastExpr CCastExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cast_expr ( ) ;
}
#line 169 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 4357 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 169 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 169 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool cast_expr ();

  struct CastExpr1 {
#line 4394 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax9CastExpr1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax9CastExpr1E;
#line 172 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 172 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4403 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9CastExpr15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9CastExpr15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::CastExpr1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 173 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 173 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 4441 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9CastExpr15checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::CastExpr1, ::Puma::CSyntax::CastExpr1, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 173 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 173 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cast_expr1 (); }
    static inline bool parse (CSyntax &);
  
#line 4459 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef CastExpr1 CCastExpr1Builder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cast_expr1 ( ) ;
}
#line 175 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 4465 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _cast_expr1_1 ) ;
}
#line 175 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 4471 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 175 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 175 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool cast_expr1 ();

  struct CastExpr2 {
#line 4508 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax9CastExpr2E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax9CastExpr2E;
#line 178 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 178 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4517 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9CastExpr25checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9CastExpr25checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::CastExpr2::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 179 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 179 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 4555 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9CastExpr25checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::CastExpr2, ::Puma::CSyntax::CastExpr2, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 179 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 179 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cast_expr2 (); }
    static inline bool parse (CSyntax &);
  
#line 4573 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef CastExpr2 CCastExpr2Builder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cast_expr2 ( ) ;
}
#line 181 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 4579 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _cast_expr2_1 ) ;
}
#line 181 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 4585 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 181 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 181 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool cast_expr2 ();

  struct OffsetofExpr {
#line 4622 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax12OffsetofExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax12OffsetofExprE;
#line 184 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 184 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4631 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax12OffsetofExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12OffsetofExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::OffsetofExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 185 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 185 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 4669 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12OffsetofExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::OffsetofExpr, ::Puma::CSyntax::OffsetofExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 185 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 185 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.offsetof_expr (); }
    static inline bool parse (CSyntax &);
  
#line 4687 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef OffsetofExpr COffsetofExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . offsetof_expr ( ) ;
}
#line 187 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 4694 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 187 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 187 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool offsetof_expr ();

  struct MembDesignator {
#line 4731 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax14MembDesignatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax14MembDesignatorE;
#line 190 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 190 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4740 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax14MembDesignator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14MembDesignator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::MembDesignator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 191 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 191 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 4778 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14MembDesignator5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::MembDesignator, ::Puma::CSyntax::MembDesignator, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 191 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 191 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.memb_designator (); }
    static inline bool parse (CSyntax &);
  
#line 4796 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef MembDesignator CMembDesignatorBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . memb_designator ( ) ;
}
#line 193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 4803 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool memb_designator ();

  struct MulExpr {
#line 4840 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax7MulExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax7MulExprE;
#line 196 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 196 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4849 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax7MulExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7MulExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::MulExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 197 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 197 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 4887 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7MulExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::MulExpr, ::Puma::CSyntax::MulExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 197 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 197 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.mul_expr (); }
    static inline bool parse (CSyntax &);
  
#line 4905 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef MulExpr CMulExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . mul_expr ( ) ;
}
#line 199 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 4912 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 199 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 199 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool mul_expr ();

  struct AddExpr {
#line 4949 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax7AddExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax7AddExprE;
#line 202 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 202 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 4958 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax7AddExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7AddExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::AddExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 203 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 203 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 4996 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7AddExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::AddExpr, ::Puma::CSyntax::AddExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 203 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 203 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.add_expr (); }
    static inline bool parse (CSyntax &);
  
#line 5014 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef AddExpr CAddExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . add_expr ( ) ;
}
#line 205 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 5021 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 205 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 205 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool add_expr ();

  struct ShiftExpr {
#line 5058 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax9ShiftExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax9ShiftExprE;
#line 208 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 208 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5067 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9ShiftExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9ShiftExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::ShiftExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 209 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 209 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 5105 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9ShiftExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::ShiftExpr, ::Puma::CSyntax::ShiftExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 209 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 209 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.shift_expr (); }
    static inline bool parse (CSyntax &);
  
#line 5123 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef ShiftExpr CShiftExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . shift_expr ( ) ;
}
#line 211 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 5130 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 211 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 211 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool shift_expr ();

  struct RelExpr {
#line 5167 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax7RelExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax7RelExprE;
#line 214 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 214 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5176 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax7RelExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7RelExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::RelExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 215 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 215 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 5214 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7RelExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::RelExpr, ::Puma::CSyntax::RelExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 215 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 215 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.rel_expr (); }
    static inline bool parse (CSyntax &);
  
#line 5232 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef RelExpr CRelExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . rel_expr ( ) ;
}
#line 217 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 5239 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 217 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 217 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool rel_expr ();

  struct EquExpr {
#line 5276 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax7EquExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax7EquExprE;
#line 220 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 220 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5285 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax7EquExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7EquExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::EquExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 221 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 221 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 5323 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7EquExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::EquExpr, ::Puma::CSyntax::EquExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 221 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 221 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.equ_expr (); }
    static inline bool parse (CSyntax &);
  
#line 5341 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef EquExpr CEquExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . equ_expr ( ) ;
}
#line 223 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 5348 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 223 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 223 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool equ_expr ();

  struct AndExpr {
#line 5385 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax7AndExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax7AndExprE;
#line 226 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 226 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5394 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax7AndExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7AndExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::AndExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 227 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 227 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 5432 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7AndExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::AndExpr, ::Puma::CSyntax::AndExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 227 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 227 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.and_expr (); }
    static inline bool parse (CSyntax &);
  
#line 5450 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef AndExpr CAndExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . and_expr ( ) ;
}
#line 229 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 5457 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 229 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 229 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool and_expr ();

  struct ExclOrExpr {
#line 5494 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax10ExclOrExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax10ExclOrExprE;
#line 232 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 232 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5503 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10ExclOrExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10ExclOrExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::ExclOrExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 233 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 233 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 5541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10ExclOrExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::ExclOrExpr, ::Puma::CSyntax::ExclOrExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 233 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 233 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.excl_or_expr (); }
    static inline bool parse (CSyntax &);
  
#line 5559 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef ExclOrExpr CExclOrExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . excl_or_expr ( ) ;
}
#line 235 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 5566 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 235 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 235 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool excl_or_expr ();

  struct InclOrExpr {
#line 5603 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax10InclOrExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax10InclOrExprE;
#line 238 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 238 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5612 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10InclOrExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10InclOrExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::InclOrExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 239 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 239 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 5650 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10InclOrExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::InclOrExpr, ::Puma::CSyntax::InclOrExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 239 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 239 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.incl_or_expr (); }
    static inline bool parse (CSyntax &);
  
#line 5668 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef InclOrExpr CInclOrExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . incl_or_expr ( ) ;
}
#line 241 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 5675 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 241 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 241 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool incl_or_expr ();

  struct LogAndExpr {
#line 5712 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax10LogAndExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax10LogAndExprE;
#line 244 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 244 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5721 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10LogAndExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10LogAndExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::LogAndExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 245 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 245 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 5759 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10LogAndExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::LogAndExpr, ::Puma::CSyntax::LogAndExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 245 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 245 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.log_and_expr (); }
    static inline bool parse (CSyntax &);
  
#line 5777 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef LogAndExpr CLogAndExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . log_and_expr ( ) ;
}
#line 247 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 5784 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 247 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 247 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool log_and_expr ();

  struct LogOrExpr {
#line 5821 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax9LogOrExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax9LogOrExprE;
#line 250 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 250 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5830 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9LogOrExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9LogOrExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::LogOrExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 251 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 251 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 5868 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9LogOrExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::LogOrExpr, ::Puma::CSyntax::LogOrExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 251 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 251 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.log_or_expr (); }
    static inline bool parse (CSyntax &);
  
#line 5886 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef LogOrExpr CLogOrExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . log_or_expr ( ) ;
}
#line 253 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 5893 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 253 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 253 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool log_or_expr ();

  struct CondExpr {
#line 5930 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax8CondExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax8CondExprE;
#line 256 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 256 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 5939 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8CondExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8CondExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::CondExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 257 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 257 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 5977 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8CondExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::CondExpr, ::Puma::CSyntax::CondExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 257 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 257 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cond_expr (); }
    static inline bool parse (CSyntax &);
  
#line 5995 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef CondExpr CCondExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cond_expr ( ) ;
}
#line 259 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 6002 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 259 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 259 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool cond_expr ();

  struct AssExpr {
#line 6039 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax7AssExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax7AssExprE;
#line 262 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 262 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6048 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax7AssExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7AssExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::AssExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 263 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 263 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 6086 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7AssExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::AssExpr, ::Puma::CSyntax::AssExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 263 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 263 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.ass_expr (); }
    static inline bool parse (CSyntax &);
  
#line 6104 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef AssExpr CAssExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . ass_expr ( ) ;
}
#line 265 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 6111 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 265 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 265 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool ass_expr ();

  struct AssExpr1 {
#line 6148 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax8AssExpr1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax8AssExpr1E;
#line 268 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 268 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6157 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8AssExpr15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8AssExpr15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::AssExpr1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 269 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 269 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 6195 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8AssExpr15checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::AssExpr1, ::Puma::CSyntax::AssExpr1, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 269 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 269 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.ass_expr1 (); }
    static inline bool parse (CSyntax &);
  
#line 6213 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef AssExpr1 CAssExpr1Builder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . ass_expr1 ( ) ;
}
#line 271 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 6219 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> is_ass_expr ( ) ;
}
#line 271 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 6225 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 271 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 271 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool ass_expr1 ();

  struct Expr {
#line 6262 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax4ExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax4ExprE;
#line 274 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 274 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6271 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax4Expr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax4Expr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::Expr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 275 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 275 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 6309 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax4Expr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::Expr, ::Puma::CSyntax::Expr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 275 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 275 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.expr (); }
    static inline bool parse (CSyntax &);
  
#line 6327 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef Expr CExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . expr ( ) ;
}
#line 277 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 6334 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 277 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 277 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool expr ();

  struct ConstExpr {
#line 6371 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax9ConstExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax9ConstExprE;
#line 280 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 280 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6380 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9ConstExpr5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9ConstExpr5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::ConstExpr::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 281 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 281 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 6418 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9ConstExpr5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::ConstExpr, ::Puma::CSyntax::ConstExpr, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 281 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 281 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.const_expr (); }
    static inline bool parse (CSyntax &);
  
#line 6436 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef ConstExpr CConstExprBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . const_expr ( ) ;
}
#line 283 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 6443 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 283 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 283 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool const_expr ();

  // A.5 Statements

  struct Stmt {
#line 6482 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax4StmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax4StmtE;
#line 288 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 288 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6491 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax4Stmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax4Stmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::Stmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 289 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 289 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 6529 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax4Stmt5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::Stmt, ::Puma::CSyntax::Stmt, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 289 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 289 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.stmt (); }
    static inline bool parse (CSyntax &);
  
#line 6547 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef Stmt CStmtBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . stmt ( ) ;
}
#line 291 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 6554 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 291 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 291 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  
#line 6589 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline bool __exec_old_stmt();

#line 292 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 292 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
virtual bool stmt ();

  struct LabelStmt {
#line 6598 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax9LabelStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax9LabelStmtE;
#line 294 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 294 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6607 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9LabelStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9LabelStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::LabelStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 295 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 295 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 6645 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9LabelStmt5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::LabelStmt, ::Puma::CSyntax::LabelStmt, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 295 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 295 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.label_stmt (); }
    static inline bool parse (CSyntax &);
  
#line 6663 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef LabelStmt CLabelStmtBuilder; public :
#line 6665 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9LabelStmt5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9LabelStmt5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 6695 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 6697 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9LabelStmt5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::LabelStmt, ::Puma::CSyntax::LabelStmt, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  __result_buffer = ::Puma::CSyntax::LabelStmt::__exec_old_build(s);
  AC::invoke_CSemBinding_CSemBinding__a4_after<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 6710 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . label_stmt ( ) ;
}
#line 297 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 6715 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _label_stmt_1 ) ;
}
#line 297 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 6721 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 297 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 297 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool label_stmt ();

  struct ExprStmt {
#line 6758 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax8ExprStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax8ExprStmtE;
#line 300 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 300 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6767 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8ExprStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8ExprStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::ExprStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 301 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 301 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 6805 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8ExprStmt5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::ExprStmt, ::Puma::CSyntax::ExprStmt, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 301 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 301 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.expr_stmt (); }
    static inline bool parse (CSyntax &);
  
#line 6823 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef ExprStmt CExprStmtBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . expr_stmt ( ) ;
}
#line 303 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 6830 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 303 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 303 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool expr_stmt ();

  struct CmpdStmt {
#line 6867 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax8CmpdStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax8CmpdStmtE;
#line 306 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 306 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 6876 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8CmpdStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8CmpdStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::CmpdStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 307 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 307 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 6914 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8CmpdStmt5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::CmpdStmt, ::Puma::CSyntax::CmpdStmt, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 307 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 307 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cmpd_stmt (); }
    static inline bool parse (CSyntax &);
  
#line 6932 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef CmpdStmt CCmpdStmtBuilder; public :
#line 6934 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8CmpdStmt5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8CmpdStmt5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 6964 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 6966 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8CmpdStmt5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::CmpdStmt, ::Puma::CSyntax::CmpdStmt, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a5_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 6978 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . cmpd_stmt ( ) ;
}
#line 309 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 6983 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _cmpd_stmt_1 ) ;
}
#line 309 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 6989 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 309 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 309 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool cmpd_stmt ();

  struct StmtSeq {
#line 7026 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax7StmtSeqE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax7StmtSeqE;
#line 312 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 312 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7035 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax7StmtSeq5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7StmtSeq5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::StmtSeq::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 313 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 313 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 7073 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7StmtSeq5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::StmtSeq, ::Puma::CSyntax::StmtSeq, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 313 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 313 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.stmt_seq (); }
    
#line 7090 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax &);

#line 314 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 314 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
  
#line 7098 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef StmtSeq CStmtSeqBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . stmt_seq ( ) ;
}
#line 315 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 7105 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 315 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 315 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool stmt_seq ();

  struct SelectStmt {
#line 7142 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax10SelectStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax10SelectStmtE;
#line 318 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 318 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7151 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10SelectStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10SelectStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::SelectStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 319 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 319 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 7189 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10SelectStmt5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::SelectStmt, ::Puma::CSyntax::SelectStmt, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 319 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 319 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.select_stmt (); }
    static inline bool parse (CSyntax &);
  
#line 7207 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef SelectStmt CSelectStmtBuilder; public :
#line 7209 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10SelectStmt5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10SelectStmt5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 7239 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 7241 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10SelectStmt5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::SelectStmt, ::Puma::CSyntax::SelectStmt, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a6_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 7253 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . select_stmt ( ) ;
}
#line 321 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 7258 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _select_stmt_1 ) ;
}
#line 321 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 7264 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 321 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 321 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool select_stmt ();

  struct SubStmt {
#line 7301 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax7SubStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax7SubStmtE;
#line 324 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 324 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7310 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax7SubStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7SubStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::SubStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 325 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 325 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 7348 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7SubStmt5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::SubStmt, ::Puma::CSyntax::SubStmt, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 325 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 325 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.sub_stmt (); }
    static inline bool parse (CSyntax &);
  
#line 7366 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef SubStmt CSubStmtBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . sub_stmt ( ) ;
}
#line 327 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 7373 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 327 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 327 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool sub_stmt ();

  struct Condition {
#line 7410 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax9ConditionE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax9ConditionE;
#line 330 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 330 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7419 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9Condition5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9Condition5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::Condition::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 331 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 331 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 7457 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9Condition5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::Condition, ::Puma::CSyntax::Condition, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 331 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 331 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.condition (); }
    static inline bool parse (CSyntax &);
  
#line 7475 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef Condition CConditionBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . condition ( ) ;
}
#line 333 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 7482 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 333 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 333 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool condition ();

  struct IterStmt {
#line 7519 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax8IterStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax8IterStmtE;
#line 336 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 336 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7528 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8IterStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8IterStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::IterStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 337 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 337 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 7566 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8IterStmt5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::IterStmt, ::Puma::CSyntax::IterStmt, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 337 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 337 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.iter_stmt (); }
    static inline bool parse (CSyntax &);
  
#line 7584 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef IterStmt CIterStmtBuilder; public :
#line 7586 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8IterStmt5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8IterStmt5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 7616 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 7618 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8IterStmt5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::IterStmt, ::Puma::CSyntax::IterStmt, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a7_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 7630 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . iter_stmt ( ) ;
}
#line 339 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 7635 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _iter_stmt_1 ) ;
}
#line 339 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 7641 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 339 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 339 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool iter_stmt ();
  
  struct ForInitStmt {
#line 7678 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax11ForInitStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax11ForInitStmtE;
#line 342 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 342 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7687 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax11ForInitStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11ForInitStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::ForInitStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 7725 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11ForInitStmt5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::ForInitStmt, ::Puma::CSyntax::ForInitStmt, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.for_init_stmt (); }
    static inline bool parse (CSyntax &);
  
#line 7743 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef ForInitStmt CForInitStmtBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . for_init_stmt ( ) ;
}
#line 345 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 7750 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 345 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 345 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool for_init_stmt ();
  
  struct JumpStmt {
#line 7787 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax8JumpStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax8JumpStmtE;
#line 348 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 348 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7796 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8JumpStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8JumpStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::JumpStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 349 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 349 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 7834 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8JumpStmt5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::JumpStmt, ::Puma::CSyntax::JumpStmt, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 349 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 349 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.jump_stmt (); }
    
#line 7851 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax &);

#line 350 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 350 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
  
#line 7859 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef JumpStmt CJumpStmtBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . jump_stmt ( ) ;
}
#line 351 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 7865 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _jump_stmt_1 ) ;
}
#line 351 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 7871 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 351 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 351 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool jump_stmt ();
      
  // A.6 Declarations

  struct DeclSeq {
#line 7910 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax7DeclSeqE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax7DeclSeqE;
#line 356 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 356 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 7919 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax7DeclSeq5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7DeclSeq5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::DeclSeq::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 357 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 357 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 7957 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7DeclSeq5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::DeclSeq, ::Puma::CSyntax::DeclSeq, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 357 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 357 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.decl_seq (); }
    static inline bool parse (CSyntax &);
  
#line 7975 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef DeclSeq CDeclSeqBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . decl_seq ( ) ;
}
#line 359 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 7982 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 359 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 359 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool decl_seq ();

  struct Decl {
#line 8019 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax4DeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax4DeclE;
#line 362 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 362 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8028 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax4Decl5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax4Decl5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::Decl::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 363 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 363 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 8066 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax4Decl5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::Decl, ::Puma::CSyntax::Decl, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 363 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 363 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.decl (); }
    static inline bool parse (CSyntax &);
  
#line 8084 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef Decl CDeclBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . decl ( ) ;
}
#line 365 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 8091 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 365 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 365 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool decl ();
  // helper function, which is needed, because ac++ can't weave in templates :-(
  virtual bool decl_check ();

  struct BlockDecl {
#line 8130 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax9BlockDeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax9BlockDeclE;
#line 370 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 370 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8139 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9BlockDecl5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9BlockDecl5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::BlockDecl::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 371 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 371 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 8177 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9BlockDecl5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::BlockDecl, ::Puma::CSyntax::BlockDecl, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 371 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 371 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.block_decl (); }
    static inline bool parse (CSyntax &);
  
#line 8195 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef BlockDecl CBlockDeclBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . block_decl ( ) ;
}
#line 373 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 8202 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 373 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 373 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool block_decl ();

  struct SimpleDecl {
#line 8239 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax10SimpleDeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax10SimpleDeclE;
#line 376 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 376 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8248 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10SimpleDecl5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10SimpleDecl5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::SimpleDecl::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 377 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 377 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 8286 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10SimpleDecl5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::SimpleDecl, ::Puma::CSyntax::SimpleDecl, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 377 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 377 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.simple_decl (); }
    static bool parse (CSyntax &);
  
#line 8304 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef SimpleDecl CSimpleDeclBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . simple_decl ( ) ;
}
#line 379 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 8311 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 379 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 379 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool simple_decl ();

  struct DeclSpec {
#line 8348 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax8DeclSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax8DeclSpecE;
#line 382 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 382 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8357 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8DeclSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8DeclSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::DeclSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 383 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 383 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 8395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8DeclSpec5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::DeclSpec, ::Puma::CSyntax::DeclSpec, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 383 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 383 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.decl_spec (); }
    static inline bool parse (CSyntax &);
  
#line 8413 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef DeclSpec CDeclSpecBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . decl_spec ( ) ;
}
#line 385 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 8419 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _decl_spec_1 ) ;
}
#line 385 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 8425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 385 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 385 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool decl_spec ();

  struct DeclSpecSeq {
#line 8462 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax11DeclSpecSeqE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax11DeclSpecSeqE;
#line 388 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 388 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8471 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax11DeclSpecSeq5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11DeclSpecSeq5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::DeclSpecSeq::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 389 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 389 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 8509 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11DeclSpecSeq5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::DeclSpecSeq, ::Puma::CSyntax::DeclSpecSeq, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 389 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 389 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.decl_spec_seq (); }
    
#line 8526 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax &);

#line 390 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 390 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static bool parse (CSyntax &);
  
#line 8534 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef DeclSpecSeq CDeclSpecSeqBuilder; public :
#line 8536 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax11DeclSpecSeq5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11DeclSpecSeq5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 8566 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 8568 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11DeclSpecSeq5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::DeclSpecSeq, ::Puma::CSyntax::DeclSpecSeq, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a8_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 8580 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return 0 ;
}
#line 391 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 8586 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 391 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 391 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool decl_spec_seq ();

  struct DeclSpecSeq1 {
#line 8623 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax12DeclSpecSeq1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax12DeclSpecSeq1E;
#line 394 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 394 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8632 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax12DeclSpecSeq15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12DeclSpecSeq15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::DeclSpecSeq1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 8670 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12DeclSpecSeq15checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::DeclSpecSeq1, ::Puma::CSyntax::DeclSpecSeq1, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.decl_spec_seq1 (); }
    static bool parse (CSyntax &);
  
#line 8688 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef DeclSpecSeq1 CDeclSpecSeq1Builder; public :
#line 8690 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax12DeclSpecSeq15buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12DeclSpecSeq15buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 8720 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 8722 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12DeclSpecSeq15buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::DeclSpecSeq1, ::Puma::CSyntax::DeclSpecSeq1, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a10_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 8734 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . decl_spec_seq1 ( ) ;
}
#line 397 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 8740 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 397 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 397 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool decl_spec_seq1 ();

  struct MiscSpec {
#line 8777 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax8MiscSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax8MiscSpecE;
#line 400 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 400 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8786 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8MiscSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8MiscSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::MiscSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 401 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 401 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 8824 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8MiscSpec5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::MiscSpec, ::Puma::CSyntax::MiscSpec, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 401 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 401 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.misc_spec (); }
    static bool parse (CSyntax &);
  
#line 8842 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef MiscSpec CMiscSpecBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . misc_spec ( ) ;
}
#line 403 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 8848 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _misc_spec_1 ) ;
}
#line 403 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 8854 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 403 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 403 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool misc_spec ();

  struct StorageClassSpec {
#line 8891 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax16StorageClassSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax16StorageClassSpecE;
#line 406 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 406 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 8900 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax16StorageClassSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax16StorageClassSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::StorageClassSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 407 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 407 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 8938 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax16StorageClassSpec5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::StorageClassSpec, ::Puma::CSyntax::StorageClassSpec, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 407 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 407 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.storage_class_spec (); }
    
#line 8955 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax &);

#line 408 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 408 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static bool parse (CSyntax &);
  
#line 8963 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef StorageClassSpec CStorageClassSpecBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . storage_class_spec ( ) ;
}
#line 409 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 8969 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _storage_class_spec_1 ) ;
}
#line 409 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 8975 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 409 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 409 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool storage_class_spec ();

  struct FctSpec {
#line 9012 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax7FctSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax7FctSpecE;
#line 412 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 412 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9021 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax7FctSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7FctSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::FctSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 413 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 413 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 9059 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7FctSpec5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::FctSpec, ::Puma::CSyntax::FctSpec, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 413 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 413 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.fct_spec (); }
    static bool parse (CSyntax &);
  
#line 9077 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef FctSpec CFctSpecBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . fct_spec ( ) ;
}
#line 415 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 9083 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _fct_spec_1 ) ;
}
#line 415 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 9089 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 415 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 415 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool fct_spec ();

  struct TypeSpec {
#line 9126 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax8TypeSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax8TypeSpecE;
#line 418 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 418 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9135 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8TypeSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8TypeSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::TypeSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 419 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 419 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 9173 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8TypeSpec5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::TypeSpec, ::Puma::CSyntax::TypeSpec, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 419 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 419 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.type_spec (); }
    static inline bool parse (CSyntax &);
  
#line 9191 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef TypeSpec CTypeSpecBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . type_spec ( ) ;
}
#line 421 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 9198 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 421 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 421 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool type_spec ();

  struct SimpleTypeSpec {
#line 9235 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax14SimpleTypeSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax14SimpleTypeSpecE;
#line 424 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 424 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9244 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax14SimpleTypeSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14SimpleTypeSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::SimpleTypeSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 9282 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14SimpleTypeSpec5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::SimpleTypeSpec, ::Puma::CSyntax::SimpleTypeSpec, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.simple_type_spec (); }
    
#line 9299 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax &);

#line 426 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 426 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
  
#line 9307 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef SimpleTypeSpec CSimpleTypeSpecBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . simple_type_spec ( ) ;
}
#line 427 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 9313 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _simple_type_spec_1 ) ;
}
#line 427 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 9319 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 427 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 427 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool simple_type_spec ();

  struct TypeName {
#line 9356 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax8TypeNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax8TypeNameE;
#line 430 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 430 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9365 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8TypeName5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8TypeName5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::TypeName::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 431 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 431 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 9403 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8TypeName5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::TypeName, ::Puma::CSyntax::TypeName, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 431 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 431 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.type_name (); }
    static inline bool parse (CSyntax &);
  
#line 9421 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef TypeName CTypeNameBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . type_name ( ) ;
}
#line 433 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 9427 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _type_name_1 ) ;
}
#line 433 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 9433 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 433 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 433 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool type_name ();

  struct ElaboratedTypeSpec {
#line 9470 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax18ElaboratedTypeSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax18ElaboratedTypeSpecE;
#line 436 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 436 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9479 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax18ElaboratedTypeSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax18ElaboratedTypeSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::ElaboratedTypeSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 437 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 437 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 9517 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax18ElaboratedTypeSpec5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::ElaboratedTypeSpec, ::Puma::CSyntax::ElaboratedTypeSpec, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 437 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 437 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.elaborated_type_spec (); }
    static inline bool parse (CSyntax &);
  
#line 9535 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef ElaboratedTypeSpec CElaboratedTypeSpecBuilder; public :
#line 9537 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax18ElaboratedTypeSpec5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax18ElaboratedTypeSpec5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 9567 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 9569 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax18ElaboratedTypeSpec5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::ElaboratedTypeSpec, ::Puma::CSyntax::ElaboratedTypeSpec, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a11_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 9581 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . elaborated_type_spec ( ) ;
}
#line 439 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 9586 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _elaborated_type_spec_1 ) ;
}
#line 439 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 9592 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 439 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 439 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool elaborated_type_spec ();

  struct EnumKey {
#line 9629 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax7EnumKeyE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax7EnumKeyE;
#line 442 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 442 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9638 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax7EnumKey5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax7EnumKey5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::EnumKey::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 443 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 443 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 9676 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax7EnumKey5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::EnumKey, ::Puma::CSyntax::EnumKey, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 443 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 443 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.enum_key (); }
    static inline bool parse (CSyntax &);
  
#line 9694 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef EnumKey CEnumKeyBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . enum_key ( ) ;
}
#line 445 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 9700 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _enum_key_1 ) ;
}
#line 445 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 9706 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 445 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 445 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool enum_key ();

  struct EnumSpec {
#line 9743 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax8EnumSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax8EnumSpecE;
#line 448 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 448 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9752 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8EnumSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8EnumSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::EnumSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 449 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 449 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 9790 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8EnumSpec5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::EnumSpec, ::Puma::CSyntax::EnumSpec, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 449 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 449 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.enum_spec (); }
    static inline bool parse (CSyntax &);
  
#line 9808 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef EnumSpec CEnumSpecBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . enum_spec ( ) ;
}
#line 451 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 9814 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _enum_spec_1 ) ;
}
#line 451 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 9820 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 451 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 451 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool enum_spec ();

  struct EnumSpec1 {
#line 9857 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax9EnumSpec1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax9EnumSpec1E;
#line 454 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 454 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 9866 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9EnumSpec15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9EnumSpec15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::EnumSpec1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 455 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 455 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 9904 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9EnumSpec15checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::EnumSpec1, ::Puma::CSyntax::EnumSpec1, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 455 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 455 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.enum_spec1 (); }
    static inline bool parse (CSyntax &);
  
#line 9922 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef EnumSpec1 CEnumSpec1Builder; public :
#line 9924 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9EnumSpec15buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9EnumSpec15buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 9954 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 9956 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9EnumSpec15buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::EnumSpec1, ::Puma::CSyntax::EnumSpec1, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a12_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 9968 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . enum_spec1 ( ) ;
}
#line 457 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 9973 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _enum_spec1_1 ) ;
}
#line 457 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 9979 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 457 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 457 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool enum_spec1 ();

  struct EnumeratorList {
#line 10016 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax14EnumeratorListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax14EnumeratorListE;
#line 460 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 460 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10025 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax14EnumeratorList5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14EnumeratorList5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::EnumeratorList::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 461 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 461 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 10063 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14EnumeratorList5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::EnumeratorList, ::Puma::CSyntax::EnumeratorList, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 461 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 461 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.enumerator_list (); }
    static inline bool parse (CSyntax &);
  
#line 10081 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef EnumeratorList CEnumeratorListBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . enumerator_list ( ) ;
}
#line 463 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 10088 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 463 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 463 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool enumerator_list ();

  struct EnumeratorDef {
#line 10125 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax13EnumeratorDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax13EnumeratorDefE;
#line 466 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 466 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10134 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax13EnumeratorDef5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax13EnumeratorDef5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::EnumeratorDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 467 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 467 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 10172 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax13EnumeratorDef5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::EnumeratorDef, ::Puma::CSyntax::EnumeratorDef, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 467 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 467 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.enumerator_def (); }
    static bool parse (CSyntax &);
  
#line 10190 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef EnumeratorDef CEnumeratorDefBuilder; public :
#line 10192 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax13EnumeratorDef5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax13EnumeratorDef5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 10222 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 10224 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax13EnumeratorDef5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::EnumeratorDef, ::Puma::CSyntax::EnumeratorDef, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a13_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 10236 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . enumerator_def ( ) ;
}
#line 469 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 10242 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 469 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 469 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool enumerator_def ();

  struct Enumerator {
#line 10279 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax10EnumeratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax10EnumeratorE;
#line 472 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 472 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10288 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10Enumerator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10Enumerator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::Enumerator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 473 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 473 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 10326 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10Enumerator5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::Enumerator, ::Puma::CSyntax::Enumerator, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 473 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 473 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.enumerator (); }
    static inline bool parse (CSyntax &);
  
#line 10344 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef Enumerator CEnumeratorBuilder; public :
#line 10346 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10Enumerator5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10Enumerator5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 10376 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 10378 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10Enumerator5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::Enumerator, ::Puma::CSyntax::Enumerator, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a14_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 10390 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . enumerator ( ) ;
}
#line 475 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 10396 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 475 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 475 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool enumerator ();

  struct AsmDef {
#line 10433 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax6AsmDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax6AsmDefE;
#line 478 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 478 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10442 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax6AsmDef5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax6AsmDef5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::AsmDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 479 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 479 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 10480 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax6AsmDef5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::AsmDef, ::Puma::CSyntax::AsmDef, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 479 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 479 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.asm_def (); }
    static inline bool parse (CSyntax &);
  
#line 10498 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef AsmDef CAsmDefBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . asm_def ( ) ;
}
#line 481 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 10505 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 481 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 481 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  
#line 10540 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline bool __exec_old_asm_def();

#line 482 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 482 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
virtual bool asm_def ();

  // A.7 Declarators
  struct InitDeclaratorList {
#line 10550 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax18InitDeclaratorListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax18InitDeclaratorListE;
#line 485 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 485 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10559 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax18InitDeclaratorList5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax18InitDeclaratorList5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::InitDeclaratorList::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 486 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 486 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 10597 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax18InitDeclaratorList5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::InitDeclaratorList, ::Puma::CSyntax::InitDeclaratorList, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 486 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 486 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.init_declarator_list (); }
    static inline bool parse (CSyntax &);
  
#line 10615 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef InitDeclaratorList CInitDeclaratorListBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . init_declarator_list ( ) ;
}
#line 488 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 10622 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 488 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 488 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool init_declarator_list ();

  struct InitDeclarator {
#line 10659 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax14InitDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax14InitDeclaratorE;
#line 491 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 491 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10668 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax14InitDeclarator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14InitDeclarator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::InitDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 492 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 492 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 10706 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14InitDeclarator5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::InitDeclarator, ::Puma::CSyntax::InitDeclarator, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 492 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 492 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.init_declarator (); }
    static bool parse (CSyntax &);
  
#line 10724 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef InitDeclarator CInitDeclaratorBuilder; public :
#line 10726 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax14InitDeclarator5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14InitDeclarator5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 10756 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 10758 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14InitDeclarator5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::InitDeclarator, ::Puma::CSyntax::InitDeclarator, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a15_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 10770 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . init_declarator ( ) ;
}
#line 494 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 10776 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 494 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 494 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool init_declarator ();

  struct InitDeclarator1 {
#line 10813 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax15InitDeclarator1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax15InitDeclarator1E;
#line 497 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 497 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10822 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax15InitDeclarator15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax15InitDeclarator15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::InitDeclarator1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 498 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 498 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 10860 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax15InitDeclarator15checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::InitDeclarator1, ::Puma::CSyntax::InitDeclarator1, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 498 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 498 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.init_declarator1 (); }
    
#line 10877 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax &);

#line 499 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 499 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
  
#line 10885 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef InitDeclarator1 CInitDeclarator1Builder; public :
#line 10887 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax15InitDeclarator15buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax15InitDeclarator15buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 10917 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 10919 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax15InitDeclarator15buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::InitDeclarator1, ::Puma::CSyntax::InitDeclarator1, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a17_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 10931 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . init_declarator1 ( ) ;
}
#line 500 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 10937 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 500 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 500 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool init_declarator1 ();

  struct Declarator {
#line 10974 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax10DeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax10DeclaratorE;
#line 503 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 503 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 10983 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10Declarator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10Declarator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::Declarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 504 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 504 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 11021 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10Declarator5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::Declarator, ::Puma::CSyntax::Declarator, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 504 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 504 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.declarator (); }
    static inline bool parse (CSyntax &);
  
#line 11039 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef Declarator CDeclaratorBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . declarator ( ) ;
}
#line 506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 11046 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool declarator ();

  struct DirectDeclarator {
#line 11083 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax16DirectDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax16DirectDeclaratorE;
#line 509 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 509 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11092 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax16DirectDeclarator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax16DirectDeclarator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::DirectDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 510 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 510 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 11130 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax16DirectDeclarator5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::DirectDeclarator, ::Puma::CSyntax::DirectDeclarator, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 510 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 510 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.direct_declarator (); }
    static inline bool parse (CSyntax &);
  
#line 11148 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef DirectDeclarator CDirectDeclaratorBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . direct_declarator ( ) ;
}
#line 512 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 11155 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 512 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 512 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool direct_declarator ();

  struct DirectDeclarator1 {
#line 11192 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax17DirectDeclarator1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax17DirectDeclarator1E;
#line 515 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 515 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11201 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax17DirectDeclarator15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax17DirectDeclarator15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::DirectDeclarator1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 516 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 516 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 11239 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax17DirectDeclarator15checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::DirectDeclarator1, ::Puma::CSyntax::DirectDeclarator1, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 516 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 516 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.direct_declarator1 (); }
    static inline bool parse (CSyntax &);
  
#line 11257 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef DirectDeclarator1 CDirectDeclarator1Builder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . direct_declarator1 ( ) ;
}
#line 518 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 11263 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _direct_declarator1_1 ) ;
}
#line 518 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 11269 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 518 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 518 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool direct_declarator1 ();

  struct IdentifierList {
#line 11306 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax14IdentifierListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax14IdentifierListE;
#line 521 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 521 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11315 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax14IdentifierList5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14IdentifierList5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::IdentifierList::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 522 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 522 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 11353 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14IdentifierList5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::IdentifierList, ::Puma::CSyntax::IdentifierList, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 522 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 522 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.identifier_list (); }
    
#line 11370 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax &);

#line 523 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 523 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
  
#line 11378 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef IdentifierList CIdentifierListBuilder; public :
#line 11380 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax14IdentifierList5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14IdentifierList5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 11410 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 11412 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14IdentifierList5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::IdentifierList, ::Puma::CSyntax::IdentifierList, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a19_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 11424 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . identifier_list ( ) ;
}
#line 524 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 11430 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 524 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 524 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool identifier_list ();

  struct ArrayDelim {
#line 11467 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax10ArrayDelimE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax10ArrayDelimE;
#line 527 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 527 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11476 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10ArrayDelim5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10ArrayDelim5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::ArrayDelim::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 528 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 528 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 11514 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10ArrayDelim5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::ArrayDelim, ::Puma::CSyntax::ArrayDelim, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 528 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 528 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.array_delim (); }
    static inline bool parse (CSyntax &);
  
#line 11532 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef ArrayDelim CArrayDelimBuilder; public :
#line 11534 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10ArrayDelim5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10ArrayDelim5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 11564 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 11566 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10ArrayDelim5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::ArrayDelim, ::Puma::CSyntax::ArrayDelim, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a21_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 11578 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . array_delim ( ) ;
}
#line 530 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 11584 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 530 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 530 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool array_delim ();

  struct PtrOperator {
#line 11621 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax11PtrOperatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax11PtrOperatorE;
#line 533 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 533 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11630 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax11PtrOperator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11PtrOperator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::PtrOperator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 534 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 534 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 11668 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11PtrOperator5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::PtrOperator, ::Puma::CSyntax::PtrOperator, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 534 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 534 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.ptr_operator (); }
    static inline bool parse (CSyntax &);
  
#line 11686 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef PtrOperator CPtrOperatorBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . ptr_operator ( ) ;
}
#line 536 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 11693 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 536 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 536 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool ptr_operator ();

  struct CvQualSeq {
#line 11730 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax9CvQualSeqE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax9CvQualSeqE;
#line 539 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 539 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11739 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9CvQualSeq5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9CvQualSeq5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::CvQualSeq::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 540 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 540 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 11777 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9CvQualSeq5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::CvQualSeq, ::Puma::CSyntax::CvQualSeq, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 540 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 540 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cv_qual_seq (); }
    static inline bool parse (CSyntax &);
  
#line 11795 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef CvQualSeq CCvQualSeqBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cv_qual_seq ( ) ;
}
#line 542 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 11801 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _cv_qual_seq_1 ) ;
}
#line 542 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 11807 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 542 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 542 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool cv_qual_seq ();

  struct CvQual {
#line 11844 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax6CvQualE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax6CvQualE;
#line 545 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 545 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11853 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax6CvQual5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax6CvQual5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::CvQual::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 546 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 546 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 11891 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax6CvQual5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::CvQual, ::Puma::CSyntax::CvQual, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 546 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 546 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.cv_qual (); }
    static inline bool parse (CSyntax &);
  
#line 11909 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef CvQual CCvQualBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . cv_qual ( ) ;
}
#line 548 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 11915 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _cv_qual_1 ) ;
}
#line 548 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 11921 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 548 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 548 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool cv_qual ();

  struct DeclaratorId {
#line 11958 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax12DeclaratorIdE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax12DeclaratorIdE;
#line 551 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 551 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 11967 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax12DeclaratorId5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12DeclaratorId5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::DeclaratorId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 552 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 552 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 12005 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12DeclaratorId5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::DeclaratorId, ::Puma::CSyntax::DeclaratorId, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 552 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 552 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.declarator_id (); }
    static inline bool parse (CSyntax &);
  
#line 12023 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef DeclaratorId CDeclaratorIdBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . declarator_id ( ) ;
}
#line 554 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 12030 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 554 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 554 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool declarator_id ();

  struct TypeId {
#line 12067 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax6TypeIdE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax6TypeIdE;
#line 557 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 557 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 12076 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax6TypeId5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax6TypeId5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::TypeId::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 558 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 558 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 12114 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax6TypeId5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::TypeId, ::Puma::CSyntax::TypeId, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 558 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 558 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.type_id (); }
    
#line 12131 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax &);

#line 559 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 559 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
  
#line 12139 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef TypeId CTypeIdBuilder; public :
#line 12141 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax6TypeId5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax6TypeId5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 12171 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 12173 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax6TypeId5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::TypeId, ::Puma::CSyntax::TypeId, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a22_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 12185 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . type_id ( ) ;
}
#line 560 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 12191 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 560 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 560 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool type_id ();

  struct TypeSpecSeq {
#line 12228 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax11TypeSpecSeqE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax11TypeSpecSeqE;
#line 563 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 563 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 12237 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax11TypeSpecSeq5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11TypeSpecSeq5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::TypeSpecSeq::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 564 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 564 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 12275 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11TypeSpecSeq5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::TypeSpecSeq, ::Puma::CSyntax::TypeSpecSeq, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 564 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 564 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.type_spec_seq (); }
    
#line 12292 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax &);

#line 565 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 565 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
  
#line 12300 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef TypeSpecSeq CTypeSpecSeqBuilder; public :
#line 12302 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax11TypeSpecSeq5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax11TypeSpecSeq5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 12332 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 12334 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax11TypeSpecSeq5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::TypeSpecSeq, ::Puma::CSyntax::TypeSpecSeq, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a25_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 12346 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return 0 ;
}
#line 566 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 12352 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 566 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 566 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool type_spec_seq ();

  struct TypeSpecSeq1 {
#line 12389 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax12TypeSpecSeq1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax12TypeSpecSeq1E;
#line 569 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 569 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 12398 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax12TypeSpecSeq15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12TypeSpecSeq15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::TypeSpecSeq1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 570 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 570 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 12436 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12TypeSpecSeq15checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::TypeSpecSeq1, ::Puma::CSyntax::TypeSpecSeq1, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 570 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 570 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.type_spec_seq1 (); }
    static inline bool parse (CSyntax &);
  
#line 12454 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef TypeSpecSeq1 CTypeSpecSeq1Builder; public :
#line 12456 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax12TypeSpecSeq15buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12TypeSpecSeq15buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 12486 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 12488 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12TypeSpecSeq15buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::TypeSpecSeq1, ::Puma::CSyntax::TypeSpecSeq1, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a26_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 12500 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . decl_spec_seq1 ( ) ;
}
#line 572 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 12506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 572 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 572 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool type_spec_seq1 ();

  struct AbstDeclarator {
#line 12543 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax14AbstDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax14AbstDeclaratorE;
#line 575 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 575 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 12552 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax14AbstDeclarator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14AbstDeclarator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::AbstDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 576 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 576 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 12590 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14AbstDeclarator5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::AbstDeclarator, ::Puma::CSyntax::AbstDeclarator, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 576 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 576 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.abst_declarator (); }
    static inline bool parse (CSyntax &);
  
#line 12608 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef AbstDeclarator CAbstDeclaratorBuilder; public :
#line 12610 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax14AbstDeclarator5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14AbstDeclarator5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 12640 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 12642 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14AbstDeclarator5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::AbstDeclarator, ::Puma::CSyntax::AbstDeclarator, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a27_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 12654 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . abst_declarator ( ) ;
}
#line 578 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 12660 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 578 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 578 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool abst_declarator ();

  struct DirectAbstDeclarator {
#line 12697 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax20DirectAbstDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax20DirectAbstDeclaratorE;
#line 581 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 581 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 12706 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax20DirectAbstDeclarator5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax20DirectAbstDeclarator5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::DirectAbstDeclarator::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 582 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 582 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 12744 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax20DirectAbstDeclarator5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::DirectAbstDeclarator, ::Puma::CSyntax::DirectAbstDeclarator, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 582 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 582 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.direct_abst_declarator (); }
    static inline bool parse (CSyntax &);
  
#line 12762 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef DirectAbstDeclarator CDirectAbstDeclaratorBuilder; public :
#line 12764 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax20DirectAbstDeclarator5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax20DirectAbstDeclarator5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 12794 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 12796 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax20DirectAbstDeclarator5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::DirectAbstDeclarator, ::Puma::CSyntax::DirectAbstDeclarator, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a28_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 12808 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . direct_abst_declarator ( ) ;
}
#line 584 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 12814 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 584 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 584 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool direct_abst_declarator ();

  struct DirectAbstDeclarator1 {
#line 12851 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax21DirectAbstDeclarator1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax21DirectAbstDeclarator1E;
#line 587 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 587 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 12860 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax21DirectAbstDeclarator15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax21DirectAbstDeclarator15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::DirectAbstDeclarator1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 588 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 588 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 12898 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax21DirectAbstDeclarator15checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::DirectAbstDeclarator1, ::Puma::CSyntax::DirectAbstDeclarator1, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 588 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 588 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.direct_abst_declarator1 (); }
    static inline bool parse (CSyntax &);
  
#line 12916 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef DirectAbstDeclarator1 CDirectAbstDeclarator1Builder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . direct_abst_declarator1 ( ) ;
}
#line 590 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 12923 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 590 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 590 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool direct_abst_declarator1 ();

  struct ParamDeclClause {
#line 12960 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax15ParamDeclClauseE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax15ParamDeclClauseE;
#line 593 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 593 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 12969 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax15ParamDeclClause5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax15ParamDeclClause5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::ParamDeclClause::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 594 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 594 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 13007 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax15ParamDeclClause5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::ParamDeclClause, ::Puma::CSyntax::ParamDeclClause, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 594 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 594 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.param_decl_clause (); }
    
#line 13024 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static bool __exec_old_parse(::Puma::CSyntax &);

#line 595 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 595 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool parse (CSyntax &);
  
#line 13032 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef ParamDeclClause CParamDeclClauseBuilder; public :
#line 13034 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax15ParamDeclClause5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax15ParamDeclClause5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 13064 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 13066 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax15ParamDeclClause5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::ParamDeclClause, ::Puma::CSyntax::ParamDeclClause, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a20_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 13078 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . param_decl_clause ( ) ;
}
#line 596 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 13084 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 596 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 596 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool param_decl_clause ();

  struct ParamDeclList {
#line 13121 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax13ParamDeclListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax13ParamDeclListE;
#line 599 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 599 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 13130 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax13ParamDeclList5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax13ParamDeclList5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::ParamDeclList::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 600 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 600 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 13168 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax13ParamDeclList5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::ParamDeclList, ::Puma::CSyntax::ParamDeclList, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 600 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 600 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.param_decl_list (); }
    static inline bool parse (CSyntax &);
  
#line 13186 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef ParamDeclList CParamDeclListBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . param_decl_list ( ) ;
}
#line 602 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 13192 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return ! s -> look_ahead ( TOK_CLOSE_ROUND ) && ! s -> look_ahead ( TOK_ELLIPSIS ) ;
}
#line 602 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 13198 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 602 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 602 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool param_decl_list ();

  CTree * rule_param_decl ();
  virtual bool param_decl ();
  
  struct ParamDecl1 {
#line 13238 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax10ParamDecl1E {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax10ParamDecl1E;
#line 608 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 608 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 13247 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10ParamDecl15checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10ParamDecl15checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::ParamDecl1::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 609 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 609 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 13285 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10ParamDecl15checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::ParamDecl1, ::Puma::CSyntax::ParamDecl1, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 609 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 609 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.param_decl1 (); }
    static inline bool parse (CSyntax &);
  
#line 13303 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef ParamDecl1 CParamDecl1Builder; public :
#line 13305 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10ParamDecl15buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10ParamDecl15buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 13335 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 13337 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10ParamDecl15buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::ParamDecl1, ::Puma::CSyntax::ParamDecl1, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a29_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 13349 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . param_decl1 ( ) ;
}
#line 611 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 13355 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 611 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 611 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool param_decl1 ();

//  CTree * rule_param_decl2 ();
//  virtual bool param_decl2 ();
  CTree * rule_fct_def ();
  
#line 13395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline bool __exec_old_fct_def();

#line 617 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 617 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
virtual bool fct_def ();
  CTree * rule_arg_decl_seq ();
  virtual bool arg_decl_seq ();
  CTree * rule_fct_body ();
  virtual bool fct_body ();
  CTree * rule_init ();
  virtual bool init ();
  CTree * rule_init_clause ();
  virtual bool init_clause ();
  CTree * rule_init_list ();
  virtual bool init_list ();
  CTree * rule_init_list_item ();
  virtual bool init_list_item ();
  CTree * rule_designation ();
  virtual bool designation ();
  CTree * rule_designator ();
  virtual bool designator ();

  // A.8 Classes
  CTree * rule_class_spec ();
  virtual bool class_spec ();

  struct ClassHead {
#line 13424 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax9ClassHeadE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax9ClassHeadE;
#line 639 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 639 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 13433 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9ClassHead5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9ClassHead5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::ClassHead::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 640 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 640 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 13471 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9ClassHead5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::ClassHead, ::Puma::CSyntax::ClassHead, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 640 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 640 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.class_head (); }
    static inline bool parse (CSyntax &);
  
#line 13489 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef ClassHead CClassHeadBuilder; public :
#line 13491 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9ClassHead5buildERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9ClassHead5buildERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

};

#line 13521 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static CTree * build ( Puma :: CSyntax & s ) 
#line 13523 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9ClassHead5buildERN4PumaE7CSyntax_0< ::Puma::CTree *, ::Puma::CSyntax::ClassHead, ::Puma::CSyntax::ClassHead, Puma::CTree *(Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  ::Puma::CTree *__result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_CSemBinding_CSemBinding__a31_around<__TJP> (&tjp);
  return (::Puma::CTree *&)__result_buffer;

}
__attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s)
#line 13535 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
return s . builder ( ) . class_head ( ) ;
}
#line 642 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 13540 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _class_head_1 ) ;
}
#line 642 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 13546 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 642 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 642 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool class_head ();

  struct ClassKey {
#line 13583 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  template <typename, int = 0> struct __BYPASS_ZN4Puma7CSyntax8ClassKeyE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CSyntax8ClassKeyE;
#line 645 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 645 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

    
#line 13592 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax8ClassKey5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax8ClassKey5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::ClassKey::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};


#line 646 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 646 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
static inline bool check (CSyntax &s) 
#line 13630 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax8ClassKey5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::ClassKey, ::Puma::CSyntax::ClassKey, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 646 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 646 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
{ return s.class_key (); }
    static inline bool parse (CSyntax &);
  
#line 13648 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef ClassKey CClassKeyBuilder; public :
static CTree * build ( Puma :: CSyntax & s ) {
return s . builder ( ) . class_key ( ) ;
}
#line 648 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 13654 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: static inline bool lookahead ( CSyntax * s ) {
return s -> predict_1 ( s -> _class_key_1 ) ;
}
#line 648 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
  public: static bool lookahead ( void * ) { return true ; }
#line 13660 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 648 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 648 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};
  virtual bool class_key ();

  CTree * rule_member_spec ();
  virtual bool member_spec ();
  
#line 13699 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree *__exec_old_rule_member_decl();

#line 653 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 653 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
CTree * rule_member_decl ();
  virtual bool member_decl ();
  CTree * rule_member_declarator_list ();
  virtual bool member_declarator_list ();
  
#line 13710 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline ::Puma::CTree *__exec_old_rule_member_declarator();

#line 657 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 657 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
CTree * rule_member_declarator ();
  virtual bool member_declarator ();

protected:
  virtual bool is_fct_def ();
  virtual bool is_ass_expr ();

  virtual void handle_directive ();
#line 13724 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  public: tokenset _typedef_name_1 ;
tokenset _identifier_1 ;
tokenset _literal_1 ;
tokenset _cmpd_str_1 ;
tokenset _str_literal_1 ;
tokenset _prim_expr_1 ;
tokenset _id_expr_1 ;
tokenset _cmpd_literal_1 ;
tokenset _postfix_expr_1 ;
tokenset _postfix_expr1_1 ;
tokenset _cast_expr1_1 ;
tokenset _cast_expr2_1 ;
tokenset _label_stmt_1 ;
tokenset _cmpd_stmt_1 ;
tokenset _select_stmt_1 ;
tokenset _iter_stmt_1 ;
tokenset _jump_stmt_1 ;
tokenset _decl_spec_1 ;
tokenset _misc_spec_1 ;
tokenset _storage_class_spec_1 ;
tokenset _fct_spec_1 ;
tokenset _type_spec_1 ;
tokenset _simple_type_spec_1 ;
tokenset _type_name_1 ;
tokenset _elaborated_type_spec_1 ;
tokenset _enum_spec_1 ;
tokenset _enum_spec1_1 ;
tokenset _direct_declarator1_1 ;
tokenset _cv_qual_seq_1 ;
tokenset _cv_qual_1 ;
tokenset _class_head_1 ;
tokenset _class_key_1 ;
tokenset _enum_key_1 ;

virtual void init_typedef_name ( ) {
_typedef_name_1 . set ( TOK_ID ) ;
}
virtual void init_identifier ( ) {
_identifier_1 . set ( TOK_ID ) ;
}
virtual void init_literal ( ) {
init_cmpd_str ( ) ;
_literal_1 = _cmpd_str_1 ;
_literal_1 . set ( TOK_INT_VAL ) ;
_literal_1 . set ( TOK_ZERO_VAL ) ;
_literal_1 . set ( TOK_CHAR_VAL ) ;
_literal_1 . set ( TOK_FLT_VAL ) ;
}
virtual void init_cmpd_str ( ) {
init_str_literal ( ) ;
_cmpd_str_1 = _str_literal_1 ;
}
virtual void init_str_literal ( ) {
_str_literal_1 . set ( TOK_STRING_VAL ) ;
}
virtual void init_prim_expr ( ) {
init_literal ( ) ;
init_id_expr ( ) ;
_prim_expr_1 = _literal_1 ;
_prim_expr_1 |= _id_expr_1 ;
_prim_expr_1 . set ( TOK_OPEN_ROUND ) ;
}
virtual void init_id_expr ( ) {
_id_expr_1 . set ( TOK_ID ) ;
}
virtual void init_cmpd_literal ( ) {
_cmpd_literal_1 . set ( TOK_OPEN_ROUND ) ;
}
virtual void init_postfix_expr ( ) {
init_prim_expr ( ) ;
init_cmpd_literal ( ) ;
_postfix_expr_1 = _prim_expr_1 ;
_postfix_expr_1 |= _cmpd_literal_1 ;
}
virtual void init_postfix_expr1 ( ) {
_postfix_expr1_1 . set ( TOK_DECR ) ;
_postfix_expr1_1 . set ( TOK_INCR ) ;
_postfix_expr1_1 . set ( TOK_DOT ) ;
_postfix_expr1_1 . set ( TOK_PTS ) ;
_postfix_expr1_1 . set ( TOK_OPEN_ROUND ) ;
_postfix_expr1_1 . set ( TOK_OPEN_SQUARE ) ;
}

virtual void init_cast_expr1 ( ) {
init_cast_expr2 ( ) ;
_cast_expr1_1 = _cast_expr2_1 ;
}

virtual void init_cast_expr2 ( ) {
_cast_expr2_1 . set ( TOK_OPEN_ROUND ) ;
}

virtual void init_label_stmt ( ) {
init_identifier ( ) ;
_label_stmt_1 = _identifier_1 ;
_label_stmt_1 . set ( TOK_CASE ) ;
_label_stmt_1 . set ( TOK_DEFAULT ) ;
}

virtual void init_cmpd_stmt ( ) {
_cmpd_stmt_1 . set ( TOK_OPEN_CURLY ) ;
}

virtual void init_select_stmt ( ) {
_select_stmt_1 . set ( TOK_SWITCH ) ;
_select_stmt_1 . set ( TOK_IF ) ;
}

virtual void init_iter_stmt ( ) {
_iter_stmt_1 . set ( TOK_FOR ) ;
_iter_stmt_1 . set ( TOK_WHILE ) ;
_iter_stmt_1 . set ( TOK_DO ) ;
}

virtual void init_jump_stmt ( ) {
_jump_stmt_1 . set ( TOK_BREAK ) ;
_jump_stmt_1 . set ( TOK_CONTINUE ) ;
_jump_stmt_1 . set ( TOK_RETURN ) ;
_jump_stmt_1 . set ( TOK_GOTO ) ;
}

virtual void init_decl_spec ( ) {
init_storage_class_spec ( ) ;
init_type_spec ( ) ;
init_fct_spec ( ) ;
init_misc_spec ( ) ;
_decl_spec_1 = _storage_class_spec_1 ;
_decl_spec_1 |= _type_spec_1 ;
_decl_spec_1 |= _fct_spec_1 ;
_decl_spec_1 |= _misc_spec_1 ;
}

#line 13857 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax14init_misc_specEv_0 {
  typedef TJP__ZN4Puma7CSyntax14init_misc_specEv_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef TEntity TTarget::* MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};

#line 13882 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
virtual void init_misc_spec ( ) 
#line 13884 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14init_misc_specEv_0< void, ::Puma::CSyntax, ::Puma::CSyntax, void (),  AC::TLE > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
  this->__exec_old_init_misc_spec();
  AC::invoke_WinDeclSpecs_WinDeclSpecs__a0_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_init_misc_spec()
#line 13894 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
_misc_spec_1 . set ( TOK_TYPEDEF ) ;
}

#line 13899 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax23init_storage_class_specEv_0 {
  typedef TJP__ZN4Puma7CSyntax23init_storage_class_specEv_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef TEntity TTarget::* MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};

#line 13924 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
virtual void init_storage_class_spec ( ) 
#line 13926 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax23init_storage_class_specEv_0< void, ::Puma::CSyntax, ::Puma::CSyntax, void (),  AC::TLE > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
  this->__exec_old_init_storage_class_spec();
  AC::invoke_ExtGnu_ExtGnu__a36_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_init_storage_class_spec()
#line 13936 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
_storage_class_spec_1 . set ( TOK_AUTO ) ;
_storage_class_spec_1 . set ( TOK_REGISTER ) ;
_storage_class_spec_1 . set ( TOK_STATIC ) ;
_storage_class_spec_1 . set ( TOK_EXTERN ) ;
}

virtual void init_fct_spec ( ) {
_fct_spec_1 . set ( TOK_INLINE ) ;
}

virtual void init_type_spec ( ) {
init_simple_type_spec ( ) ;
init_class_spec ( ) ;
init_enum_spec ( ) ;
init_elaborated_type_spec ( ) ;
init_cv_qual ( ) ;
_type_spec_1 = _simple_type_spec_1 ;
_type_spec_1 |= _class_spec_1 ;
_type_spec_1 |= _enum_spec_1 ;
_type_spec_1 |= _elaborated_type_spec_1 ;
_type_spec_1 |= _cv_qual_1 ;
}

#line 13961 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax21init_simple_type_specEv_0 {
  typedef TJP__ZN4Puma7CSyntax21init_simple_type_specEv_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef TEntity TTarget::* MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};

#line 13986 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
virtual void init_simple_type_spec ( ) 
#line 13988 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax21init_simple_type_specEv_0< void, ::Puma::CSyntax, ::Puma::CSyntax, void (),  AC::TLE > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
  this->__exec_old_init_simple_type_spec();
  AC::invoke_ExtGnu_ExtGnu__a38_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_init_simple_type_spec()
#line 13998 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
init_type_name ( ) ;

_simple_type_spec_1 = _type_name_1 ;
_simple_type_spec_1 |= _prim_types ;
}

virtual void init_type_name ( ) {
init_typedef_name ( ) ;
_type_name_1 = _typedef_name_1 ;
}

virtual void init_elaborated_type_spec ( ) {
init_class_key ( ) ;
_elaborated_type_spec_1 = _class_key_1 ;
_elaborated_type_spec_1 . set ( TOK_ENUM ) ;
}

virtual void init_enum_key ( ) {
_enum_key_1 . set ( TOK_ENUM ) ;
}

virtual void init_enum_spec ( ) {
init_enum_spec1 ( ) ;
_enum_spec_1 = _enum_spec1_1 ;
}

virtual void init_enum_spec1 ( ) {
init_enum_key ( ) ;
_enum_spec1_1 = _enum_key_1 ;
}

virtual void init_direct_declarator1 ( ) {
_direct_declarator1_1 . set ( TOK_OPEN_SQUARE ) ;
_direct_declarator1_1 . set ( TOK_OPEN_ROUND ) ;
}

virtual void init_cv_qual_seq ( ) {
init_cv_qual ( ) ;
_cv_qual_seq_1 = _cv_qual_1 ;
}

virtual void init_cv_qual ( ) {
_cv_qual_1 = _cv_quals ;
}

virtual void init_class_head ( ) {
init_class_key ( ) ;
_class_head_1 = _class_key_1 ;
}

virtual void init_class_key ( ) {
_class_key_1 . set ( TOK_STRUCT ) ;
_class_key_1 . set ( TOK_UNION ) ;
}
#line 665 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 14055 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef CSyntax ExtGnuAttributeSyntax; public :
struct GnuAttribute {
#line 14058 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax12GnuAttribute5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax12GnuAttribute5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::GnuAttribute::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};

#line 14091 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax & s ) 
#line 14093 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax12GnuAttribute5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::GnuAttribute, ::Puma::CSyntax::GnuAttribute, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 14105 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_attribute ( ) ; }
static inline bool parse ( CSyntax & ) ;
static inline CTree * build ( CSyntax & s ) ;
  public: static bool lookahead ( void * ) { return true ; }
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;
} ;
virtual bool gnu_attribute ( ) ;
bool catch_gnu_attribute ( ) ;
#line 665 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 14141 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef CSyntax ExtGnuAsmSyntax; public :
struct GnuAsmSpec {
#line 14144 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax10GnuAsmSpec5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax10GnuAsmSpec5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::GnuAsmSpec::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};

#line 14177 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax & s ) 
#line 14179 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax10GnuAsmSpec5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::GnuAsmSpec, ::Puma::CSyntax::GnuAsmSpec, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 14191 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_asm_spec ( ) ; }
static inline bool parse ( CSyntax & ) ;
static inline CTree * build ( CSyntax & s ) ;
  public: static bool lookahead ( void * ) { return true ; }
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;
} ;
virtual bool gnu_asm_spec ( ) ;

struct GnuAsmDef {
#line 14227 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax9GnuAsmDef5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax9GnuAsmDef5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::GnuAsmDef::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};

#line 14260 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax & s ) 
#line 14262 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax9GnuAsmDef5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::GnuAsmDef, ::Puma::CSyntax::GnuAsmDef, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 14274 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_asm_def ( ) ; }
static inline bool parse ( CSyntax & ) ;
static inline CTree * build ( CSyntax & s ) ;
  public: static bool lookahead ( void * ) { return true ; }
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;
} ;
virtual bool gnu_asm_def ( ) ;

struct GnuAsmOperands {
#line 14310 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax14GnuAsmOperands5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14GnuAsmOperands5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::GnuAsmOperands::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};

#line 14343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax & s ) 
#line 14345 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14GnuAsmOperands5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::GnuAsmOperands, ::Puma::CSyntax::GnuAsmOperands, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 14357 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_asm_operands ( ) ; }
static inline bool parse ( CSyntax & ) ;
static inline CTree * build ( CSyntax & s ) ;
  public: static bool lookahead ( void * ) { return true ; }
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;
} ;
virtual bool gnu_asm_operands ( ) ;

struct GnuAsmEmptyOperands {
#line 14393 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax19GnuAsmEmptyOperands5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax19GnuAsmEmptyOperands5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::GnuAsmEmptyOperands::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};

#line 14426 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax & s ) 
#line 14428 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax19GnuAsmEmptyOperands5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::GnuAsmEmptyOperands, ::Puma::CSyntax::GnuAsmEmptyOperands, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 14440 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_asm_empty_operands ( ) ; }
static inline bool parse ( CSyntax & ) ;
static inline CTree * build ( CSyntax & s ) ;
  public: static bool lookahead ( void * ) { return true ; }
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;
} ;
virtual bool gnu_asm_empty_operands ( ) ;

struct GnuAsmOperand {
#line 14476 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax13GnuAsmOperand5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax13GnuAsmOperand5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::GnuAsmOperand::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};

#line 14509 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax & s ) 
#line 14511 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax13GnuAsmOperand5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::GnuAsmOperand, ::Puma::CSyntax::GnuAsmOperand, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 14523 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_asm_operand ( ) ; }
static inline bool parse ( CSyntax & ) ;
static inline CTree * build ( CSyntax & s ) ;
  public: static bool lookahead ( void * ) { return true ; }
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;
} ;
virtual bool gnu_asm_operand ( ) ;

struct GnuAsmClobbers {
#line 14559 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax14GnuAsmClobbers5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax14GnuAsmClobbers5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::GnuAsmClobbers::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};

#line 14592 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax & s ) 
#line 14594 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax14GnuAsmClobbers5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::GnuAsmClobbers, ::Puma::CSyntax::GnuAsmClobbers, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 14606 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_asm_clobbers ( ) ; }
static inline bool parse ( CSyntax & ) ;
static inline CTree * build ( CSyntax & s ) ;
  public: static bool lookahead ( void * ) { return true ; }
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;
} ;
virtual bool gnu_asm_clobbers ( ) ;
#line 665 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 14641 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef CSyntax ExtGnuLocalLabelStmtSyntax; public :
struct GnuLocalLabelStmt {
#line 14644 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma7CSyntax17GnuLocalLabelStmt5checkERN4PumaE7CSyntax_0 {
  typedef TJP__ZN4Puma7CSyntax17GnuLocalLabelStmt5checkERN4PumaE7CSyntax_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)16777216;
  struct Res {
    typedef TResult Type;
    typedef TResult ReferredType;
  };

  void *_args[ARGS];
  Result *_result;

  inline void * arg (int n) {return _args[n];}
  template <int I> typename Arg<I>::ReferredType *arg () {
    return (typename Arg<I>::ReferredType*)arg (I);
  }
  inline Result *result() {return (Result*)_result;}

  __attribute__((always_inline)) void proceed () {
  *__TJP::result() = (bool)::Puma::CSyntax::GnuLocalLabelStmt::__exec_old_check(*(typename __TJP::template Arg<0>::ReferredType*)__TJP::arg(0));
  }
};

#line 14677 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline bool check ( CSyntax & s ) 
#line 14679 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{
  typedef TJP__ZN4Puma7CSyntax17GnuLocalLabelStmt5checkERN4PumaE7CSyntax_0< bool, ::Puma::CSyntax::GnuLocalLabelStmt, ::Puma::CSyntax::GnuLocalLabelStmt, bool (Puma::CSyntax &),  AC::TL< ::Puma::CSyntax &, AC::TLE > > __TJP;
  bool __result_buffer;
  __TJP tjp;
  tjp._args[0] = (void*)&s;
  tjp._result = &(__TJP::Result&)__result_buffer;
  AC::invoke_LookAhead_LookAhead__a0_around<__TJP> (&tjp);
  return (bool &)__result_buffer;

}
__attribute__((always_inline)) inline static bool __exec_old_check(::Puma::CSyntax &s)
#line 14691 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
{ return s . gnu_local_label_stmt ( ) ; }
static inline bool parse ( CSyntax & ) ;
#line 14694 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
public: __attribute__((always_inline)) inline static ::Puma::CTree *__exec_old_build(::Puma::CSyntax &s);
#line 14696 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
static inline CTree * build ( CSyntax & s ) ;
  public: static bool lookahead ( void * ) { return true ; }
  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;
} ;
virtual bool gnu_local_label_stmt ( ) ;
#line 665 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 14729 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef CSyntax ExtGnuTypeofSyntax; public :
CTree * rule_gnu_typeof ( ) ;
virtual bool gnu_typeof ( ) ;
#line 665 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 14734 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef CSyntax WinAsmSyntax; public :
virtual bool asm_block ( ) ;
Puma :: CTree * rule_asm_block ( ) ;
#line 665 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 14739 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"
  private: typedef CSyntax WinDeclSpecsSyntax; public :

Puma :: CTree * rule_win_decl_spec ( ) ;
virtual bool win_decl_spec ( ) ;
#line 665 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
#line 14745 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CSyntax.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 665 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"

#line 665 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CSyntax.h"
};

inline CSyntax::CSyntax (CBuilder &b, CSemantic &s) : Syntax (b, s),
 last_look_ahead_token (0),
 last_look_ahead_result (false)
 {}

inline void CSyntax::handle_directive ()
 { Syntax::handle_directive (); }


} // namespace Puma

#endif /* __CSyntax_h__ */

#ifdef __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_CSyntax_h__
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#include "Puma/CCExprResolveCC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#include "Puma/CExprResolveCC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#include "Puma/SyntaxState.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#include "Puma/CCSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#include "Puma/WinIfExists.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#include "Puma/WinImportHandler.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#include "Puma/WinMacros.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#include "Puma/ExtGnuCInfos.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#include "Puma/ExtGnuCSemantic.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#include "Puma/ExtGnuCSemExpr.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#include "Puma/ExtGnuCSemDeclSpecs.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#include "Puma/PragmaOnce.ah"
#endif
#endif
#undef __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#undef __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_CSyntax_h__
#endif // __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_CSyntax_h__

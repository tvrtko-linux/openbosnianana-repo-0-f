#ifndef __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#define __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#define __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_CTree_h__
#ifndef __ac_have_predefined_includes__
#define __ac_have_predefined_includes__
#endif // __ac_have_predefined_includes__

#ifndef __ac_h_
#define __ac_h_
#ifdef __cplusplus
namespace AC {
  typedef const char* Type;
  enum JPType { CALL = 262144, EXECUTION = 16777216, CONSTRUCTION = 33554432, DESTRUCTION = 67108864 };
  enum Protection { PROT_NONE, PROT_PRIVATE, PROT_PROTECTED, PROT_PUBLIC };
  enum Specifiers { SPEC_NONE = 0x0 , SPEC_STATIC = 0x1, SPEC_MUTABLE = 0x2, SPEC_VIRTUAL = 0x4 };
  struct Action {
    void **_args; void *_result; void *_entity; void *_target; void *_that; void *_fptr;
    void (*_wrapper)(Action &);
    inline void trigger () { _wrapper (*this); }
  };
  template <typename T> struct ResultBuffer {
    char _data[sizeof (T)];
    void operator = (const T& t) { *this = (const ResultBuffer &)t; }
  };
  template <typename T, typename N> struct TL {
    typedef T type; typedef N next; enum { ARGS = next::ARGS + 1 };
  };
  struct TLE { enum { ARGS = 0 }; };
  template <typename T> struct Referred { typedef T type; };
  template <typename T> struct Referred<T &> { typedef T type; };
  template <typename TL, int I> struct Arg {
    typedef typename Arg<typename TL::next, I - 1>::Type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename TL> struct Arg<TL, 0> {
    typedef typename TL::type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename T> int ttest(...);
  template <typename T> char ttest(typename T::__TI const volatile *);
  template<typename T> struct HasTypeInfo {
    enum { RET=((sizeof(ttest<T>(0))==1)?1:0) };
  };
  template<typename T, int HAVE = HasTypeInfo<T>::RET> struct TypeInfo {
    enum { AVAILABLE = 0, BASECLASSES = 0, MEMBERS = 0, FUNCTIONS = 0,
           CONSTRUCTORS = 0, DESTRUCTORS = 0 };
    typedef T That;
  };
  template<typename T> struct TypeInfo<T, 1> : T::__TI {
    enum { AVAILABLE = 1 };
  };
  template<typename T> struct RT {};
  template<typename T> RT<T> rt_deduce (const T&) { return RT<T>(); }
  template<typename T> RT<T> rt_deduce (const volatile T&) { return RT<T>(); }
  struct Cnv { template<typename T> operator RT<T>() const { return RT<T>(); }};
  #define __AC_TYPEOF(expr) (1?AC::Cnv():AC::rt_deduce(expr))
  template <class Aspect, int Index>
  struct CFlow {
    static int &instance () {
      static int counter = 0;
      return counter;
    }
    CFlow () { instance ()++; }
    ~CFlow () { instance ()--; }
    static bool active () { return instance () > 0; }
  };
}
#endif // __cplusplus
#endif // __ac_h_
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACTree;
class ExtGnu;
class ExtGnuCTree;
class ExtGnuKeywords;
class PragmaOnceUnitState;
class PragmaOnce;
#endif // __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#line 99 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

#ifndef __ac_fwd_ExtGnuCTree__
#define __ac_fwd_ExtGnuCTree__
class ExtGnuCTree;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnuCTree_ExtGnuCTree__a0_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnuCTree_ExtGnuCTree__a1_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnuCTree_ExtGnuCTree__a2_around (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtGnuCTree_ExtGnuCTree__a3_around (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#endif

#ifndef __ac_fwd_ExtACTree__
#define __ac_fwd_ExtACTree__
class ExtACTree;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtACTree_ExtACTree__a0_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_ExtACTree_ExtACTree__a1_before (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#endif

#line 1 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
// This file is part of PUMA.
// Copyright (C) 1999-2003  The PUMA developer team.
//                                                                
// This program is free software;  you can redistribute it and/or 
// modify it under the terms of the GNU General Public License as 
// published by the Free Software Foundation; either version 2 of 
// the License, or (at your option) any later version.            
//                                                                
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
// GNU General Public License for more details.                   
//                                                                
// You should have received a copy of the GNU General Public      
// License along with this program; if not, write to the Free     
// Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
// MA  02111-1307  USA                                            

#ifndef __CTree_h__
#define __CTree_h__

/** \file 
 *  C/C++ syntax tree classes. */

namespace Puma {


// Syntax tree node hierarchy:
class CTree;
class   CT_Statement;          
class     CT_LabelStmt;
class     CT_IfStmt;
class     CT_IfElseStmt;
class     CT_SwitchStmt;
class     CT_BreakStmt;
class     CT_ExprStmt;
class     CT_WhileStmt;
class     CT_DoStmt;
class     CT_ForStmt;
class     CT_ContinueStmt;
class     CT_ReturnStmt;
class     CT_GotoStmt;
class     CT_DeclStmt;
class     CT_CaseStmt;
class     CT_DefaultStmt;
class     CT_TryStmt;
class   CT_Expression;
class     CT_Call;
class       CT_CallExpr;
class       CT_ImplicitCall;
class     CT_ThrowExpr;
class     CT_NewExpr;
class     CT_DeleteExpr;
class     CT_ConstructExpr;
class     CT_Integer;
class     CT_Character;
class       CT_WideCharacter;
class     CT_Float;
class     CT_Bool;
class     CT_BracedExpr;
class     CT_BinaryExpr;
class       CT_MembPtrExpr;
class         CT_MembRefExpr;
class     CT_UnaryExpr;
class       CT_PostfixExpr;
class       CT_AddrExpr;
class       CT_DerefExpr;
class     CT_IfThenExpr;
class     CT_CmpdLiteral;
class     CT_IndexExpr;
class     CT_CastExpr;
class     CT_StaticCast;
class       CT_ConstCast;
class       CT_ReintCast;
class       CT_DynamicCast;
class     CT_TypeidExpr;
class     CT_SizeofExpr;
class     CT_AlignofExpr;
class     CT_TypeTraitExpr;
class     CT_OffsetofExpr;
class     CT_MembDesignator;
class     CT_IndexDesignator;
class     CT_ImplicitCast;
class     CT_MembInit;
class   CT_DeclSpec;
class     CT_PrimDeclSpec;
class     CT_NamedType;
class     CT_ClassSpec;
class       CT_UnionSpec;
class       CT_EnumSpec;
class     CT_ExceptionSpec;
class   CT_Declarator;
class     CT_InitDeclarator;
class     CT_BracedDeclarator;
class     CT_ArrayDeclarator;
class     CT_FctDeclarator;
class     CT_RefDeclarator;
class     CT_PtrDeclarator;
class     CT_MembPtrDeclarator;
class     CT_BitFieldDeclarator;
class   CT_Decl;
class     CT_ObjDecl;
class     CT_ArgDecl;
class     CT_AccessDecl;
class       CT_UsingDecl;
class     CT_FctDef;
class     CT_AsmDef;
class     CT_EnumDef;
class     CT_ClassDef;
class       CT_UnionDef;
class     CT_Enumerator;
class     CT_LinkageSpec;
class     CT_Handler;
class     CT_TemplateDecl;
class     CT_TemplateParamDecl;
class       CT_TypeParamDecl;
class       CT_NonTypeParamDecl;
class     CT_NamespaceDef;
class     CT_NamespaceAliasDef;
class     CT_UsingDirective;
class     CT_Condition;
class   CT_List;
class     CT_CmpdStmt;
class     CT_DeclSpecSeq;
class     CT_HandlerSeq;
class     CT_DesignatorSeq;
class     CT_DeclList;
class       CT_Program;
class       CT_ArgDeclList;
class         CT_ArgNameList;
class       CT_ArgDeclSeq;
class       CT_MembList;
class     CT_ExprList;
class     CT_DeclaratorList;
class     CT_BaseSpecList;
class     CT_MembInitList;
class     CT_SimpleName;
class       CT_SpecialName;
class         CT_PrivateName;
class         CT_OperatorName;
class         CT_DestructorName;
class         CT_ConversionName;
class         CT_TemplateName;
class       CT_QualName;
class         CT_RootQualName;
class     CT_String;
class       CT_WideString;
class     CT_TemplateParamList;
class     CT_TemplateArgList;
class     CT_ExtensionList;
class   CT_Token;
class   CT_Error;
class   CT_DelayedParse;
class   CT_BaseSpec;
class   CT_AccessSpec;
class   CT_ArrayDelimiter;
class   CT_Any;
class   CT_AnyList;
class   CT_AnyExtension;
class   CT_AnyCondition;

} // namespace Puma

#include "Puma/ErrorSeverity.h"
#include "Puma/CSemObject.h"
#include "Puma/CSemScope.h"
#include "Puma/CSemValue.h"
#include "Puma/CExprValue.h"
#include "Puma/CStrLiteral.h"
#include "Puma/CTypeInfo.h"
#include "Puma/Printable.h"
#include "Puma/CTokens.h"
#include "Puma/Token.h"

#include <iostream>
#include <map>
#include <string.h>

namespace Puma {


class ErrorStream;
class CObjectInfo;
class CStructure;

/*****************************************************************************/
/*                                                                           */
/*                    S y n t a x  t r e e  n o d e s                        */
/*                                                                           */
/*****************************************************************************/

/** \class CTree CTree.h Puma/CTree.h
 *  Base class for all C/C++ syntax tree classes. 
 *
 *  The syntax tree is the result of the syntactic analysis of the input source 
 *  code representing its syntactic structure according to the accepted grammar
 *  (see class Syntax). 
 *
 *  Objects of this class and classes derived from this class are created by 
 *  the tree builder component of %Puma during the parse process. A syntax tree 
 *  shall be destroyed using the tree builder that has created it by calling its 
 *  method Builder::destroy(CTree*) with the root node of the syntax tree as its 
 *  argument.
 *  
 *  The navigation in the syntax tree is done using the methods CTree::Parent(), 
 *  CTree::Sons(), and CTree::Son(int) const. In a syntax tree "sons" are 
 *  understood as the syntactic child nodes of a syntax tree node, whereas 
 *  "daughters" are understood are their semantic child nodes. 
 *
 *  Another way to traverse a syntax tree is to implement an own tree visitor 
 *  based on class Puma::CVisitor. This is recommended especially for larger 
 *  syntax trees.
 *
 *  A syntax tree node can be identified by comparing its node name with the node 
 *  identifier of the expected syntax tree node:
 *  \code if (node->NodeName() == Puma::CT_BinaryExpr::NodeId()) ... \endcode
 *  
 *  Based on the syntax tree further semantic analyses can be performed. Semantic 
 *  information, like scope, value, type, and object information, is linked into 
 *  the syntax tree. It can be accessed using the methods CTree::SemScope(), 
 *  CTree::SemValue(), and CTree::SemObject(). Some nodes provide short-cuts to
 *  the semantic type and value information by implementing the methods 
 *  CTree::Type() and CTree::Value().
 *
 *  The information of the syntax tree can be used to perform high-level 
 *  transformations of the source code (see class ManipCommander). */
#line 364 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 227 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 374 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 227 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 384 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 227 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 227 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CTree {
#line 397 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma5CTreeE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma5CTreeE;
private:
#line 227 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 227 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree * _parent;

public:
  /*DEBUG*/static int alloc;
  /*DEBUG*/static int release;

protected:
  /** Get the n-th son from given sons array. Skips empty (NULL) array items.
   *  \param sons The sons array.
   *  \param len Length of the sons array.
   *  \param n Index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (CTree * const *sons, int len, int n) const;
  /** Get the number of sons in the given sons array. Skips empty (NULL) array items.
   *  \param sons The sons array.
   *  \param len Length of the sons array. */
  int Sons (CTree * const *sons, int len) const;
  /** Replace a son.
   *  \param sons The sons array.
   *  \param len Length of the sons array.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree **sons, int len, CTree *old_son, CTree *new_son);
  /** Replace a son if it equals the given son.
   *  \param son The actual son.
   *  \param old_son The son to replace, must match the actual son.
   *  \param new_son The new son, overwrites the actual son. */
  void ReplaceSon (CTree *&son, CTree *old_son, CTree *new_son);
  /** Add a new son.
   *  \param son The actual son.
   *  \param new_son The new son, overwrites the actual son. */
  void AddSon (CTree *&son, CTree *new_son);
  /** Set the parent tree node.
   *  \param parent The new parent tree node. */
  void SetParent (const CTree *parent) { _parent = (CTree*)parent; }
  /** Set the parent tree node of the given tree node.
   *  \param node The tree node.
   *  \param parent The new parent. */
  void SetParent (CTree *node, const CTree *parent) { node->_parent = (CTree*)parent; }
  
protected:
  /** Default constructor. */
  CTree () : _parent(0) { /*DEBUG*/alloc++; }

public:
  /** Destructor. */
  virtual ~CTree () { /*DEBUG*/release++; }
  /** Get the number of sons. */
  virtual int Sons () const = 0;
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  virtual CTree *Son (int n) const { return (CTree*)0; }
  /** Get the node name (node identifier). */
  virtual const char *NodeName () const = 0;
  /** Get the first token of the syntactic construct represented by this sub-tree.
   *  \return The token or NULL. */
  
#line 464 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public: __attribute__((always_inline)) inline ::Puma::Token *__exec_old_token() const;

#line 285 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 285 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
virtual Token *token () const;
  /** Get the last token of the syntactic construct represented by this sub-tree.
   *  \return The token or NULL. */
  
#line 474 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public: __attribute__((always_inline)) inline ::Puma::Token *__exec_old_end_token() const;

#line 288 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 288 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
virtual Token *end_token () const;
  /** Get the CT_Token node of the first token of the syntactic construct represented by this sub-tree.
   *  \return The token node or NULL. */
  
#line 484 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public: __attribute__((always_inline)) inline ::Puma::CT_Token *__exec_old_token_node() const;

#line 291 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 291 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
virtual CT_Token *token_node () const;
  /** Get the CT_Token node of the last token of the syntactic construct represented by this sub-tree.
   *  \return The token node or NULL. */
  
#line 494 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public: __attribute__((always_inline)) inline ::Puma::CT_Token *__exec_old_end_token_node() const;

#line 294 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 294 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
virtual CT_Token *end_token_node () const;
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The son with which to replace. */
  virtual void ReplaceSon (CTree *old_son, CTree *new_son) {}
  /** Get the parent node.
   *  \return The parent node or NULL. */
  virtual CTree *Parent () const { return (CTree*)_parent; }

public: // semantic information
  /** Get the semantic type of the node.
   *  \return The type object or NULL. */
  virtual CTypeInfo *Type () const { return (CTypeInfo*)0; }
  /** Get the calculated value of the expression.
   *  \return The value object or NULL. */
  virtual CExprValue *Value () const { return (CExprValue*)0; }
  
  /** Get the scope opened by the node.
   *  \return The scope object or NULL. */
  virtual CSemScope *SemScope () const { return (CSemScope*)0; }
  /** Get the semantic value of the node.
   *  \return The value object or NULL. */
  virtual CSemValue *SemValue () const { return (CSemValue*)0; }
  /** Get the semantic information of the node.
   *  \return The semantic object or NULL. */
  virtual CSemObject *SemObject () const { return (CSemObject*)0; }
  
public: // node classification function
  /** Get a pointer to CT_SimpleName if the current node represents a name.
   *  \return The CT_SimpleName node or NULL. */
  virtual CT_SimpleName *IsSimpleName () { return 0; }
  /** Get a pointer to CT_String if the current node represents a string.
   *  \return The CT_String node or NULL. */
  virtual CT_String *IsString () { return 0; }
  /** Get a pointer to CT_Declarator if the current node represents a declarator.
   *  \return The CT_Declarator pointer or NULL. */
  virtual CT_Declarator *IsDeclarator () { return 0; }
  /** Get a pointer to CT_Statement if the current node represents a statement.
   *  \return The CT_Statement pointer or NULL. */
  virtual CT_Statement *IsStatement () { return 0; }
  /** Get a pointer to CT_Expression if the current node represents a expression.
   *  \return The CT_Expression pointer or NULL. */
  virtual CT_Expression *IsExpression () { return 0; }
  /** Get a pointer to CT_Decl if the current node represents a declaration.
   *  \return The CT_Decl pointer or NULL. */
  virtual CT_Decl *IsDeclaration () { return 0; }
  /** Get a pointer to CT_Call if the current node represents a call expression.
   *  \return The CT_Call pointer or NULL. */
  virtual CT_Call *IsCall () { return 0; }
  /** Get a pointer to CT_List if the current node represents a list.
   *  \return The CT_List pointer or NULL. */
  virtual CT_List *IsList () { return 0; }
  /** Get a pointer to CT_DelayedParse if the current node represents a delayed code fragment.
   *  \return The CT_DelayedParse pointer or NULL. */
  virtual CT_DelayedParse *IsDelayedParse () { return 0; }

public: // additional semantic information
  /** Return true if the tree has the constant value 0.
   *  \return True if constant value is 0. */
  bool HasValueNull () const;
#line 560 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CTree CCExprResolveCTree; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 354 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 564 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CTree CExprResolveCTree; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 354 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 568 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: public :
typedef std :: list < CTree * > CTreeList ;
virtual CTreeList * gnu_prefix ( ) { return 0 ; }
virtual CTreeList * gnu_suffix ( ) { return 0 ; }
virtual CTreeList * gnu_infix ( ) { return 0 ; }
virtual const CTreeList * gnu_prefix ( ) const { return 0 ; }
virtual const CTreeList * gnu_suffix ( ) const { return 0 ; }
virtual const CTreeList * gnu_infix ( ) const { return 0 ; }
virtual int gnu_infix_pos ( ) const { return - 1 ; }
#line 354 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 579 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 354 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 354 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_Error CTree.h Puma/CTree.h
 *  Error tree node that is inserted into the tree for syntactic constructs
 *  that could not be parsed. */
class CT_Error : public CTree {
#line 618 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma8CT_ErrorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CT_ErrorE;
private:
#line 359 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 359 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 0; }
#line 634 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 367 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 367 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_Token CTree.h Puma/CTree.h
 *  Tree node representing a single token in the source code. */
class CT_Token : public CTree {
#line 672 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma8CT_TokenE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CT_TokenE;
private:
#line 371 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 371 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  Token *_token;
  unsigned long int _number;
  
public:
  /** Constructor. 
   *  \param token The represented token.
   *  \param number The token number (a consecutive number). */
  CT_Token (Token *token, unsigned long int number = 0) : 
    _token (token), _number (number) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 0; }
  /** Get the represented token. */
  Token *token () const { return _token; }
  /** Get the represented token. */
  Token *end_token () const { return _token; }
  /** Get this. */
  CT_Token *token_node () const { return (CT_Token*)this; }
  /** Get this. */
  CT_Token *end_token_node () const { return (CT_Token*)this; }
  /** Set the token number. 
   *  \param number The token number. */ 
  void Number (unsigned long int number) { _number = number; }
  /** Get the token number. Can be used to indentify this token. */
  unsigned long int Number () const { return _number; }
  
public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
#line 715 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 406 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 406 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/*****************************************************************************/
/*                                                                           */
/*                              List nodes                                   */
/*                                                                           */
/*****************************************************************************/

/** \class CT_List CTree.h Puma/CTree.h
 *  Base class for tree nodes representing lists. */
class CT_List : public CTree {
#line 759 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma7CT_ListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CT_ListE;
private:
#line 416 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 416 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  /** Son to index map type. */
  typedef std::map<CTree*,int> SonToIndexMap;

  Array<CTree*> _sons;
  int _properties;
  SonToIndexMap _son2idx;

protected:
  /** Constructor.
   *  \param size The initial list size.
   *  \param incr The initial increment count. 
   *  \param props The list properties (bit array). */
  CT_List(int size = 5, int incr = 5, int props = 0) : 
    _sons (size, incr), _properties (props) {}

public:
  /** %List properties. */
  enum {
    /** %List has a start token, like ':' in ":a(1),b(2)" */
    OPEN = 1,         
    /** %List has an end token */
    CLOSE = 2,        
    /** %List has opening and closing delimiters, like '(' and ')' */
    OPEN_CLOSE = 3,   
    /** %List has separators, like ',' */
    SEPARATORS = 4,   
    /** %List pretend to be empty, like for "(void)" */
    FORCE_EMPTY = 8,  
    /** %List has trailing separator, like "a,b,c," */
    END_SEP = 16,     
    /** %List has no separator before last element, like "(a,b...)" */
    NO_LAST_SEP = 32, 
    /** %List has an introduction chararacter, like "=" in "={a,b}" */
    INTRO = 64        
  };
 
  /** Get a pointer to this CT_List. */
  CT_List *IsList () { return this; }
  /** Get the number of list entries. */
  int Entries () const;
  /** Get the n-th list entry.
   *  \param n The index of the entry. 
   *  \return The list entry or NULL. */
  CTree *Entry (int n) const;
  /** Get the number of sons. */
  int Sons () const { return _sons.length (); }
  /** Get the n-th son.
   *  \param n The index of the son. 
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return _sons.lookup (n); }
  /** Get the index of the given son, or -1 if not found. */
  int Index (CTree *son);
  /** Get the list properties. */
  int GetProperties () const { return _properties; }
  /** Add a list property.
   *  \param p The property to add. */
  void AddProperties (int p) { _properties |= p; }
  /** Add a son.
   *  \param s The son to add. */
  void AddSon (CTree *s);
  /** Prepend a son.
   *  \param s The son to prepend. */
  void PrefixSon (CTree *s);
  /** Insert a son before another son.
   *  \param before The son to insert the new son before.
   *  \param son The son to insert. */
  void InsertSon (CTree *before, CTree *son); 
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son);
  /** Remove a son.
   *  \param son The son to remove. */
  void RemoveSon (CTree *son);
  /** Insert a son at the given index. 
   *  \param idx The index at which to insert.
   *  \param s The son to insert. */
  void InsertSon (int idx, CTree *s);
  /** Replace the son at the given index.
   *  \param idx The index of the son to replace.
   *  \param s The new son. */
  void ReplaceSon (int idx, CTree *s);
  /** Remove the son at the given index. 
   *  \param idx The index of the son to remove. */
  void RemoveSon (int idx);
#line 853 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 502 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 502 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ExprList CTree.h Puma/CTree.h
 *  Tree node representing an expression list. */
class CT_ExprList : public CT_List, public CSemValue, public CSemObject {
#line 891 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_ExprListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_ExprListE;
private:
#line 506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. */
  CT_ExprList () { AddProperties (SEPARATORS); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }

  /** Get the type of the last expression in the expression list.
   *  \return The type or NULL. */
  CTypeInfo *Type () const { return type; }
  /** Get the value of the last expression in the expression list.
   *  \return The value of NULL. */
  CExprValue *Value () const { return value; }
  /** Get the semantic value of the node. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
  /** Get the semantic information about the node. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
#line 918 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 525 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 525 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_DeclaratorList CTree.h Puma/CTree.h
 *  Tree node representing a list of declarators. */
class CT_DeclaratorList : public CT_List {
#line 956 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma17CT_DeclaratorListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma17CT_DeclaratorListE;
private:
#line 529 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 529 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. */
  CT_DeclaratorList () { AddProperties (SEPARATORS); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 972 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 537 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 537 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_EnumeratorList CTree.h Puma/CTree.h
 *  Tree node representing a list of enumerator constants. */
class CT_EnumeratorList : public CT_List {
#line 1010 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma17CT_EnumeratorListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma17CT_EnumeratorListE;
private:
#line 541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. */
  CT_EnumeratorList () { AddProperties (SEPARATORS | OPEN_CLOSE); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 1026 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 549 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 549 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};
   
/** \class CT_DeclList CTree.h Puma/CTree.h
 *  Tree node representing a list of declarations. */
class CT_DeclList : public CT_List {
#line 1064 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_DeclListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_DeclListE;
private:
#line 553 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 553 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. 
   *  \param size The initial size of the list.
   *  \param incr The initial increment count of the list. */
  CT_DeclList (int size = 20, int incr = 20) : CT_List (size, incr) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Set the linkage specifiers to each declaration in the list.
   *  \param l The linkage specifiers node. */
  void Linkage (CT_LinkageSpec *l);
#line 1085 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 566 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 566 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_DeclSpecSeq CTree.h Puma/CTree.h
 *  Tree node representing a sequence of declaration specifiers. */
#line 1122 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 570 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 570 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DeclSpecSeq : public CT_List {
#line 1135 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14CT_DeclSpecSeqE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14CT_DeclSpecSeqE;
private:
#line 570 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 570 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 1149 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_suffix ;
public :
CTreeList * gnu_suffix ( ) { return & _gnu_suffix ; }
const CTreeList * gnu_suffix ( ) const { return & _gnu_suffix ; }
#line 576 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1155 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 576 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 576 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_CmpdStmt CTree.h Puma/CTree.h
 *  Tree node representing a compound statement. */
class CT_CmpdStmt : public CT_List, public CSemScope {
#line 1193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_CmpdStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_CmpdStmtE;
private:
#line 580 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 580 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /* Constructor. */
  CT_CmpdStmt () { AddProperties (OPEN_CLOSE); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the scope opened by the compound statement. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
#line 1211 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 590 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 590 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_HandlerSeq CTree.h Puma/CTree.h
 *  Tree node representing an exception handler sequence. */
class CT_HandlerSeq : public CT_List {
#line 1249 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_HandlerSeqE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_HandlerSeqE;
private:
#line 594 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 594 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 1263 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 600 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 600 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_TemplateParamList CTree.h Puma/CTree.h
 *  Tree node representing a template parameter list. */
class CT_TemplateParamList : public CT_List, public CSemScope {
#line 1301 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma20CT_TemplateParamListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma20CT_TemplateParamListE;
private:
#line 604 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 604 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  CT_TemplateParamList () { AddProperties (INTRO | SEPARATORS | OPEN_CLOSE); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the scope opened by the template parameter list. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
#line 1318 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 613 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 613 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_TemplateArgList CTree.h Puma/CTree.h
 *  Tree node representing a template argument list. */
class CT_TemplateArgList : public CT_List {
#line 1356 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma18CT_TemplateArgListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma18CT_TemplateArgListE;
private:
#line 617 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 617 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. */
  CT_TemplateArgList () { AddProperties (SEPARATORS | OPEN_CLOSE); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 1372 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 625 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 625 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ExtensionList CTree.h Puma/CTree.h
 *  Tree node representing a sequence of compiler specific extensions such
 *  as __attribute__((...)) nodes. */
class CT_ExtensionList : public CT_List {
#line 1411 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16CT_ExtensionListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16CT_ExtensionListE;
private:
#line 630 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 630 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 1425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 636 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 636 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/*****************************************************************************/
/*                                                                           */
/*                              Expressions                                  */
/*                                                                           */
/*****************************************************************************/

/** \class CT_Expression CTree.h Puma/CTree.h
 *  Base class for all expression tree nodes. */
#line 1468 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 646 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1478 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 646 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1488 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 646 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 646 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Expression : public CTree, public CSemValue {
#line 1501 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_ExpressionE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_ExpressionE;
private:
#line 646 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 646 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. */
  CT_Expression () {}

  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 0; }
  /** Get the type of the expression.
   *  \return The type information object or NULL. */
  CTypeInfo *Type () const { return type; }
  /** Get the value of the expression.
   *  \return The value object or NULL. */
  CExprValue *Value () const { return value; }
  /** Get the semantic value information of the expression.
   *  \return The value object or NULL. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
  /** Get this. */
  virtual CT_Expression *IsExpression () { return this; }
#line 1531 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_Expression CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 668 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1535 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_Expression CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 668 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1539 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 668 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1545 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 668 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 668 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_Call CTree.h Puma/CTree.h
 *  Tree node representing explicit or implicit function calls 
 *  including built-in or user-defined functions and overloaded
 *  operators. */
#line 1584 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 674 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1594 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 674 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 674 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Call : public CT_Expression, public CSemObject {
#line 1607 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma7CT_CallE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CT_CallE;
private:
#line 674 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 674 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

protected:
  /** Constructor. */
  CT_Call () {}
  
public:
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the semantic information of the call. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Get this. */
  CT_Call *IsCall () { return this; }
#line 1629 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_Call CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 688 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1633 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_Call CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 688 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1637 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 688 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 688 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ImplicitCall CTree.h Puma/CTree.h
 *  Tree node representing implicit function calls detected by
 *  the semantic analysis. 
 *  Example:
 *  \code
 * class Number {
 *   int _n;
 * public:
 *   Number(int n) : _n(n) {}
 *   int operator+(const Number& n) { return n._n + _n; }
 * };
 *     
 * Number one(1), two(2);
 * one + two;  // implicitely calls one.operator+(two)
 *  \endcode */
#line 1687 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 705 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1697 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 705 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 705 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ImplicitCall : public CT_Call {
#line 1710 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15CT_ImplicitCallE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15CT_ImplicitCallE;
private:
#line 705 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 705 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *_arg;

public:
  /** Constructor.
   *  \param arg The call argument. */
  CT_ImplicitCall (CTree *arg) { AddSon (_arg, arg); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 1; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return (n == 0) ? _arg : (CTree*)0; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) 
   { CTree::ReplaceSon (_arg, old_son, new_son); }
#line 1740 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_ImplicitCall CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 727 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1744 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_ImplicitCall CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 727 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1748 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 727 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 727 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_String CTree.h Puma/CTree.h
 *  Tree node representing a string literal. 
 *  Example: \code "abc" \endcode */
#line 1786 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 732 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1796 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 732 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 732 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_String : public CT_List, public CSemValue {
#line 1809 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma9CT_StringE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma9CT_StringE;
private:
#line 732 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 732 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. 
   *  \param size The number of sub-strings. */
  CT_String (int size) : CT_List (size, 1) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }

  /** Get the type of the string. 
   *  \return The type or NULL. */
  CTypeInfo *Type () const { return type; }
  /** Get the string value.
   *  \return The value or NULL. */
  CExprValue *Value () const { return value; }
  /** Get the semantic value info object.
   *  \return The semantic value object or NULL. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
  /** Get this. */
  virtual CT_String *IsString () { return this; }
#line 1838 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_String CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 753 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1842 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_String CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 753 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1846 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 753 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 753 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_WideString CTree.h Puma/CTree.h
 *  Tree node representing a wide string literal. 
 *  Example: \code L"abc" \endcode */
#line 1884 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 758 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1894 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 758 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 758 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_WideString : public CT_String {
#line 1907 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_WideStringE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_WideStringE;
private:
#line 758 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 758 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size The number of sub-strings. */
  CT_WideString (int size) : CT_String (size) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 1924 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_WideString CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 767 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1928 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_WideString CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 767 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1932 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 767 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 767 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_Integer CTree.h Puma/CTree.h
 *  Tree node representing an integer constant. 
 *  Example: \code 1234 \endcode */
#line 1970 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 772 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 1980 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 772 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 772 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Integer : public CT_Expression {
#line 1993 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma10CT_IntegerE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma10CT_IntegerE;
private:
#line 772 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 772 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *_value;  // CT_Token

public:
  /** Constructor.
   *  \param token The token containing the integer value. */
  CT_Integer (CTree *token) { AddSon (_value, token); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return _value ? 1 : 0; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return (n == 0) ? _value : (CTree*)0; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) 
   { CTree::ReplaceSon (_value, old_son, new_son); }
#line 2023 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_Integer CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 794 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2027 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_Integer CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 794 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2031 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 794 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 794 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_Character CTree.h Puma/CTree.h
 *  Tree node representing a single character constant. 
 *  Example: \code 'a' \endcode */
#line 2069 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 799 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2079 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 799 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 799 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Character : public CT_Expression {
#line 2092 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_CharacterE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_CharacterE;
private:
#line 799 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 799 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *_value;  // CT_Token

public:
  /** Constructor.
   *  \param token The token containing the character value. */
  CT_Character (CTree *token) { AddSon (_value, token); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 1; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return (n == 0) ? _value : (CTree*)0; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) 
   { CTree::ReplaceSon (_value, old_son, new_son); }
#line 2122 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_Character CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 821 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2126 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_Character CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 821 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2130 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 821 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 821 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_WideCharacter CTree.h Puma/CTree.h
 *  Tree node representing a wide character constant. 
 *  Example: \code L'a' \endcode */
#line 2168 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 826 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2178 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 826 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 826 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_WideCharacter : public CT_Character {
#line 2191 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16CT_WideCharacterE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16CT_WideCharacterE;
private:
#line 826 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 826 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param token The token containing the wide character value. */
  CT_WideCharacter (CTree *token) : CT_Character (token) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 2208 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_WideCharacter CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 835 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2212 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_WideCharacter CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 835 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2216 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 835 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 835 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_Float CTree.h Puma/CTree.h
 *  Tree node representing a floating point constant. 
 *  Example: \code 12.34 \endcode */
#line 2254 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 840 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2264 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 840 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 840 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Float : public CT_Expression {
#line 2277 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma8CT_FloatE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8CT_FloatE;
private:
#line 840 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 840 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *_value;  // CT_Token

public:
  /** Constructor.
   *  \param token The token containing the floating point value. */
  CT_Float (CTree *token) { AddSon (_value, token); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 1; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return (n == 0) ? _value : (CTree*)0; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) 
   { CTree::ReplaceSon (_value, old_son, new_son); }
#line 2307 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_Float CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 862 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2311 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_Float CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 862 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2315 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 862 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 862 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_Bool CTree.h Puma/CTree.h
 *  Tree node representing a boolean literal. 
 *  Examples: 
 *  \code 
 * true
 * false
 *  \endcode */
#line 2357 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 871 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2367 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 871 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 871 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Bool : public CT_Expression {
#line 2380 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma7CT_BoolE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CT_BoolE;
private:
#line 871 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 871 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *_value;  // CT_Token

public:
  /** Constructor.
   *  \param token The token containing the boolean value. */
  CT_Bool (CTree *token) { AddSon (_value, token); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 1; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return (n == 0) ? _value : (CTree*)0; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) 
   { CTree::ReplaceSon (_value, old_son, new_son); }
#line 2410 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_Bool CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 893 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2414 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_Bool CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 893 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2418 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 893 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 893 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_BracedExpr CTree.h Puma/CTree.h
 *  Tree node representing a braced expression.
 *  Example: \code (a+b) \endcode */
#line 2456 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 898 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2466 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 898 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 898 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_BracedExpr : public CT_Expression {
#line 2479 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_BracedExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_BracedExprE;
private:
#line 898 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 898 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // open, expr, close

public:
  /** Constructor.
   *  \param o The opening brace.
   *  \param e The enclosed expression.
   *  \param c The closing brace. */
  CT_BracedExpr (CTree *o, CTree *e, CTree *c) { 
    AddSon (sons[0], o); AddSon (sons[1], e); AddSon (sons[2], c); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the enclosed expression. */
  CTree *Expr () const { return sons[1]; }
  /** Get the semantic value of the expression. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 2518 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_BracedExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 929 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2522 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_BracedExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 929 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2526 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 929 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 929 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_SimpleName CTree.h Puma/CTree.h
 *  Base class for all tree nodes representing a name. 
 *  Example: \code a \endcode */
#line 2564 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 934 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2574 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 934 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2584 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 934 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 934 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_SimpleName : public CT_List, public Printable, 
                      public CSemValue, public CSemObject {
#line 2598 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_SimpleNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_SimpleNameE;
private:
#line 935 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 935 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

protected:
  /** Constructor.
   *  \param size The number of sub-names (for qualified names). */
  CT_SimpleName (int size) : CT_List (size, 1) {}
  /** Constructor.
   *  \param size The number of sub-names (for qualified names). 
   *  \param properties Additional name list properties (for root qualified names). */
  CT_SimpleName (int size, int properties) : 
    CT_List (size, 2, properties) {}
  
public:
  /** Constructor.
   *  \param n The sub-tree containing the name. */
  CT_SimpleName (CTree *n) : CT_List (1, 1) { AddSon (n); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the string containing the name. */
  virtual const char *Text () const 
   { return Son (Sons ()-1)->token ()->text (); }
  /** Print the name on the given stream. 
   *  \param os The output stream. */
  virtual void print (std::ostream &os) const { os << Text (); }
  /** Get this. */
  virtual CT_SimpleName *Name () const { return (CT_SimpleName*)this; }
  /** Get the type of the entity represented by the name. */
  CTypeInfo *Type () const { return type; }
  /** Get the value of the entity represented by the name. */ 
  CExprValue *Value () const { return value; }
  /** Get the sematic value information of the name. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
  /** Get the sematic information about the name. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Get this. */
  virtual CT_SimpleName *IsSimpleName () { return this; }  

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
#line 2649 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_SimpleName CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 978 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2653 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_SimpleName CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 978 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2657 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_suffix ;
public :
CTreeList * gnu_suffix ( ) { return & _gnu_suffix ; }
const CTreeList * gnu_suffix ( ) const { return & _gnu_suffix ; }
#line 978 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2663 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 978 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2669 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 978 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 978 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_SpecialName CTree.h Puma/CTree.h
 *  Base class for tree nodes representing a special name, like destructor names. */
#line 2706 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 982 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2716 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 982 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 982 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_SpecialName : public CT_SimpleName {
#line 2729 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14CT_SpecialNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14CT_SpecialNameE;
private:
#line 982 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 982 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  char *_name;
  
protected:
  /** Constructor.
   *  \param size The number of sub-names (for qualified names). */
  CT_SpecialName (int size = 1) : CT_SimpleName (size), _name (0) {}
  
public:
  /** Destructor. Deletes the name string. */
  ~CT_SpecialName () { if (_name) delete[] _name; }
  /** Get the string containing the name. */
  const char *Text () const { return _name; }
  /** Set the name. The name is copied.
   *  \param n The name. */
  void Name (const char *n) { 
    if (n) { 
      _name = new char[strlen(n) + 1];
      strcpy (_name,n);
    }
  }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
#line 2764 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_SpecialName CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1009 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2768 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_SpecialName CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1009 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2772 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1009 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1009 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_PrivateName CTree.h Puma/CTree.h
 *  Tree node representing a private name. Private names 
 *  are generated names for instance for abstract declarators.
 *  Example: 
 *  \code 
 * void foo(int*);  // first parameter of foo has private name
 *  \endcode */
#line 2814 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1018 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2824 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1018 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1018 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_PrivateName : public CT_SpecialName {
#line 2837 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14CT_PrivateNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14CT_PrivateNameE;
private:
#line 1018 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1018 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param n The private (generated) name. */
  CT_PrivateName (const char *n) { Name (n); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 0; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return (CTree*)0; }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
#line 2866 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_PrivateName CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1039 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2870 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_PrivateName CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1039 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2874 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1039 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1039 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_DestructorName CTree.h Puma/CTree.h
 *  Tree node representing a destructor name.
 *  Example: \code ~X \endcode */
#line 2912 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1044 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2922 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1044 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1044 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DestructorName : public CT_SpecialName {
#line 2935 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma17CT_DestructorNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma17CT_DestructorNameE;
private:
#line 1044 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1044 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param t The tilde operator.
   *  \param n The class name. */
  CT_DestructorName (CTree *t, CTree *n);
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
#line 2959 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_DestructorName CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1060 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2963 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_DestructorName CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1060 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 2967 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1060 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1060 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_TemplateName CTree.h Puma/CTree.h
 *  Tree node representing a template name.
 *  Example: \code X<T> \endcode */
#line 3005 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1065 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3015 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1065 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1065 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_TemplateName : public CT_SpecialName {
#line 3028 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15CT_TemplateNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15CT_TemplateNameE;
private:
#line 1065 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1065 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param n The template class or function name.
   *  \param a The template argument list. */
  CT_TemplateName (CTree *n, CTree *a) 
   { AddSon (n); AddSon (a); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the template argument list. */
  CT_TemplateArgList *Arguments () const 
   { return (CT_TemplateArgList*)Son (Sons ()-1); }
  /** Get the template class or function name. */
  CT_SimpleName *TemplateName () const 
   { return (CT_SimpleName*)Son (Sons ()-2); }
  // may change in the future
  const char *Text () const { return TemplateName ()->Text (); }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
#line 3061 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_TemplateName CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1090 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3065 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_TemplateName CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1090 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3069 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1090 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1090 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_OperatorName CTree.h Puma/CTree.h
 *  Tree node representing the name of an overloaded operator. 
 *  Example: \code operator== \endcode */
#line 3107 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1095 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3117 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1095 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1095 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_OperatorName : public CT_SpecialName {
#line 3130 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15CT_OperatorNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15CT_OperatorNameE;
private:
#line 1095 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1095 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  int _oper;

public:
  /** Complex operator types. */
  enum { 
    FCT_CALL = -100,  /** Function call operator, i.e. (). */
    SUBSCRIPT,        /** Array subscript operator, i.e. []. */
    NEW_ARRAY,        /** New array operator, i.e. new[]. */
    DEL_ARRAY         /** Delete array operator, i.e. delete[]. */
  };
 
public:
  /** Constructor.
   *  \param op The token containing the operator. */
  CT_OperatorName (CTree *op);
  /** Constructor.
   *  \param f The operator function keyword 'operator'.
   *  \param op The token containing the operator. 
   *  \param o The token of '[' or '('.
   *  \param c The token of ']' or ')'. */
  CT_OperatorName (CTree *f, CTree *op, CTree *o, CTree *c);
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the operator type (either the token type or one of 
   *  the complex operator types). */
  int Operator () const { return _oper; }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
#line 3173 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_OperatorName CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1130 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3177 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_OperatorName CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1130 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3181 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1130 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1130 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ConversionName CTree.h Puma/CTree.h
 *  Tree node representing the name of a conversion function.
 *  Example: \code operator int* \endcode */
#line 3219 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1135 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3229 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1135 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1135 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ConversionName : public CT_SpecialName {
#line 3242 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma17CT_ConversionNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma17CT_ConversionNameE;
private:
#line 1135 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1135 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param f The operator function keyword 'operator'.
   *  \param t The sub-tree containing the conversion type. */
  CT_ConversionName (CTree *f, CTree *t);
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the conversion type. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)Son (Sons ()-1); }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
#line 3268 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_ConversionName CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1153 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3272 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_ConversionName CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1153 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3276 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1153 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1153 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_QualName CTree.h Puma/CTree.h
 *  Tree node representing a qualified name.
 *  Example: \code X::Y::Z \endcode */
#line 3314 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1158 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3324 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1158 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1158 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_QualName : public CT_SimpleName {
#line 3337 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_QualNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_QualNameE;
private:
#line 1158 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1158 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size The initial number sub-names plus separators. */
  CT_QualName (int size = 3) : 
    CT_SimpleName (size, CT_List::SEPARATORS) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Print the qualified name on the given stream. 
   *  \param os The output stream. */
  void print (std::ostream &os) const;
  /** Get the last name of the qualified name, e.g. Z of qualified name X::Y::Z. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)Son (Sons ()-1); }
  /** Get the string containing the last name of the qualified name. */
  const char *Text () const { return Name ()->Text (); }
  /** Get the type of the last name. */
  CTypeInfo *Type () const { return Name ()->Type (); }
  /** Get the value of the last name. */
  CExprValue *Value () const { return Name ()->Value (); }
  /** Get the semantic value object of the last name. */
  CSemValue *SemValue () const { return Name ()->SemValue (); }
  /** Get the semantic information of the last name. */
  CSemObject *SemObject () const { return Name ()->SemObject (); }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
#line 3376 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_QualName CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1189 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3380 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_QualName CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1189 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3384 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1189 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1189 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_RootQualName CTree.h Puma/CTree.h
 *  Tree node representing a qualified name with introducing name separator.
 *  Example: \code ::X::Y::Z \endcode */
#line 3422 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1194 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3432 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1194 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1194 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_RootQualName : public CT_QualName {
#line 3445 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15CT_RootQualNameE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15CT_RootQualNameE;
private:
#line 1194 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1194 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size Initial number of sub-name plus separator. */
  CT_RootQualName (int size = 2) : 
    CT_QualName (size) { AddProperties (INTRO); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }

public:
  /** Own new operator reusing memory. */
  void *operator new (size_t);
  /** Own delete operator. */
  void operator delete (void *);
#line 3469 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_RootQualName CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1210 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3473 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_RootQualName CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1210 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3477 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1210 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1210 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_BinaryExpr CTree.h Puma/CTree.h
 *  Tree node representing a binary expression.
 *  Example: \code a+b \endcode */
#line 3515 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1215 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3525 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1215 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1215 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_BinaryExpr : public CT_Call {
#line 3538 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_BinaryExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_BinaryExprE;
private:
#line 1215 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1215 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // expr, oper, expr

public:
  /** Constructor. 
   *  \param l Left hand side of the expression. 
   *  \param o The operator token. 
   *  \param r Right hand side of the expression. */
  CT_BinaryExpr (CTree *l, CTree *o, CTree *r) {
    AddSon (sons[0], l); AddSon (sons[1], o); AddSon (sons[2], r);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 3573 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_BinaryExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1242 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3577 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_BinaryExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1242 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3581 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1242 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1242 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_MembPtrExpr CTree.h Puma/CTree.h
 *  Tree node representing a member pointer expression.
 *  Example: \code a->b \endcode */
#line 3619 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1247 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3629 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1247 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1247 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_MembPtrExpr : public CT_Expression, public CSemObject {
#line 3642 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14CT_MembPtrExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14CT_MembPtrExprE;
private:
#line 1247 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1247 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // expr, oper, expr
  
public:
  /** Constructor.
   *  \param e Expression on which to call the member.
   *  \param o The arrow operator token.
   *  \param i The member name. */
  CT_MembPtrExpr (CTree *e, CTree *o, CTree *i) {
    AddSon (sons[0], e); AddSon (sons[1], o); AddSon (sons[2], i);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 3677 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_MembPtrExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1274 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3681 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_MembPtrExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1274 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3685 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1274 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1274 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_MembRefExpr CTree.h Puma/CTree.h
 *  Tree node representing a member reference expression.
 *  Example: \code a.b \endcode */
#line 3723 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1279 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3733 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1279 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1279 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_MembRefExpr : public CT_MembPtrExpr {
#line 3746 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14CT_MembRefExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14CT_MembRefExprE;
private:
#line 1279 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1279 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param e Expression on which to call the member.
   *  \param o The dot operator.
   *  \param i The member name. */
  CT_MembRefExpr (CTree *e, CTree *o, CTree *i) :
    CT_MembPtrExpr (e, o, i) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 3766 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_MembRefExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1291 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3770 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_MembRefExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1291 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3774 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1291 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1291 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_UnaryExpr CTree.h Puma/CTree.h
 *  Base class for tree nodes representing unary expressions. 
 *  Example: \code !a \endcode */
#line 3812 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1296 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3822 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1296 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1296 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_UnaryExpr : public CT_Call {
#line 3835 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_UnaryExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_UnaryExprE;
private:
#line 1296 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1296 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // oper, expr

public:
  /** Constructor.
   *  \param o The unary operator.
   *  \param e The expression on which the operator is invoked. */
  CT_UnaryExpr (CTree *o, CTree *e) { AddSon (sons[0], o); AddSon (sons[1], e); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  /** Get the expression node. */
  CTree *Expr () const { return sons[1]; }
#line 3869 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_UnaryExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1322 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3873 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_UnaryExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1322 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3877 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1322 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1322 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_PostfixExpr CTree.h Puma/CTree.h
 *  Tree node representing a postfix expression.
 *  Example: \code a++ \endcode */
#line 3915 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1327 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3925 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1327 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1327 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_PostfixExpr : public CT_UnaryExpr {
#line 3938 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14CT_PostfixExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14CT_PostfixExprE;
private:
#line 1327 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1327 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param e The expression on which to invoke the operator. 
   *  \param o The postfix operator. */
  CT_PostfixExpr (CTree *e, CTree *o) :
    CT_UnaryExpr (e, o) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 3957 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_PostfixExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1338 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3961 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_PostfixExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1338 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 3965 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1338 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1338 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_AddrExpr CTree.h Puma/CTree.h
 *  Tree node representing an address expression.
 *  Example: \code &a \endcode */
#line 4003 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4013 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_AddrExpr : public CT_UnaryExpr {
#line 4026 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_AddrExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_AddrExprE;
private:
#line 1343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1343 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param o The address operator, i.e. '&'.
   *  \param e The expression from which to take the address. */
  CT_AddrExpr (CTree *o, CTree *e) :
    CT_UnaryExpr (o, e) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 4045 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_AddrExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1354 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4049 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_AddrExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1354 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4053 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1354 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1354 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_DerefExpr CTree.h Puma/CTree.h
 *  Tree node representing a pointer dereferencing expression.
 *  Example: \code *a \endcode */
#line 4091 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1359 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4101 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1359 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1359 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DerefExpr : public CT_UnaryExpr {
#line 4114 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_DerefExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_DerefExprE;
private:
#line 1359 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1359 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param o The dereferencing operator, i.e. '*'.
   *  \param e The expression to dereference. */
  CT_DerefExpr (CTree *o, CTree *e) :
    CT_UnaryExpr (o, e) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 4133 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_DerefExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1370 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4137 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_DerefExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1370 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4141 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1370 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1370 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_DeleteExpr CTree.h Puma/CTree.h
 *  Tree node representing a delete expression.
 *  Example: \code delete a \endcode */
#line 4179 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1375 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4189 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1375 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1375 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DeleteExpr : public CT_Expression, public CSemObject {
#line 4202 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_DeleteExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_DeleteExprE;
private:
#line 1375 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1375 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // oper, expr

public:
  /** Constructor.
   *  \param op The delete operator.
   *  \param e The expression representing the object to delete. */
  CT_DeleteExpr (CTree *op, CTree *e) { AddSon (sons[0], op); AddSon (sons[1], e); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  /** Get the expression. */
  CTree *Expr () const { return sons[1]; }
  /** Get the operator name, i.e. 'delete' or 'delete[]'. */
  CT_SimpleName *OperName () const { return (CT_SimpleName*)sons[0]; }
  /** Get the semantic information. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
#line 4240 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_DeleteExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1405 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4244 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_DeleteExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1405 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4248 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1405 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1405 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_NewExpr CTree.h Puma/CTree.h
 *  Tree node representing a new expression.
 *  Example: \code new A() \endcode */
#line 4286 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1410 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4296 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1410 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1410 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_NewExpr : public CT_Expression, public CSemObject {
#line 4309 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma10CT_NewExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma10CT_NewExprE;
private:
#line 1410 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1410 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[6]; // oper, placement, open, type, close, init

public:
  /** Constructor.
   *  \param op The new operator.
   *  \param p The optional placement expression.
   *  \param o The optional left parenthesis around the type identifier.
   *  \param t The type identifier specifying the type of the object to create.
   *  \param c The optional right parenthesis around the type identifier.
   *  \param i The optional initializer. */
  CT_NewExpr (CTree *op, CTree *p, CTree *o, CTree *t, CTree *c, CTree *i) {
    AddSon (sons[0], op); AddSon (sons[1], p); AddSon (sons[2], o); 
    AddSon (sons[3], t); AddSon (sons[4], c); AddSon (sons[5], i); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 6); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 6, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 6, old_son, new_son);
  }
  /** Get the operator name. */
  CT_SimpleName *OperName () const { return (CT_SimpleName*)sons[0]; }
  /** Get the placement expression. */
  CT_ExprList *Placement () const { return (CT_ExprList*)sons[1];; }
  /** Get the initializer. */
  CT_ExprList *Initializer () const { return (CT_ExprList*)sons[5]; }
  /** Get the type of the object to create. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)sons[3]; }
  /** Get the semantic information. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
#line 4358 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_NewExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1451 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4362 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_NewExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1451 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4366 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1451 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1451 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_IfThenExpr CTree.h Puma/CTree.h
 *  Tree node representing an if-then expression.
 *  Example: \code a>0?a:b \endcode or \code a?:b \endcode */
#line 4404 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1456 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4414 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1456 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1456 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_IfThenExpr : public CT_Expression {
#line 4427 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_IfThenExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_IfThenExprE;
private:
#line 1456 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1456 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // cond, oper, left, colon, right

public:
  /** Constructor.
   *  \param c1 The condition expression.
   *  \param o The question mark operator. 
   *  \param l The expression to the left of the colon.
   *  \param c2 The colon operator.
   *  \param r The expression to the right of the colon. */ 
  CT_IfThenExpr (CTree *c1, CTree *o, CTree *l, CTree *c2, CTree *r) {
    AddSon (sons[0], c1); AddSon (sons[1], o); AddSon (sons[2], l); 
    AddSon (sons[3], c2); AddSon (sons[4], r);
  }
  /** Constructor.
   *  \param c1 The condition expression.
   *  \param o The question mark operator. 
   *  \param c2 The colon operator.
   *  \param r The expression to the right of the colon. */ 
  CT_IfThenExpr (CTree *c1, CTree *o, CTree *c2, CTree *r) {
    AddSon (sons[0], c1); AddSon (sons[1], o); AddSon (sons[2], 0); 
    AddSon (sons[3], c2); AddSon (sons[4], r);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 5); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Get the condition expression. */
  CTree *Condition () const { return sons[0]; }
  /** Get the left expression (condition=true). */
  CTree *LeftOperand () const { return sons[2]; }
  /** Get the right expression (condition=false). */
  CTree *RightOperand () const { return sons[4]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
#line 4480 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_IfThenExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1501 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4484 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_IfThenExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1501 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4488 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1501 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1501 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_CmpdLiteral CTree.h Puma/CTree.h
 *  Tree node representing a compound literal.
 *  Example: \code (int[]){1,2,3) \endcode */
#line 4526 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4536 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_CmpdLiteral : public CT_Expression, public CSemObject {
#line 4549 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14CT_CmpdLiteralE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14CT_CmpdLiteralE;
private:
#line 1506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // open, type, close, init

public:
  /** Constructor.
   *  \param r Left parenthesis of the type name.
   *  \param t The type name.
   *  \param cr Right parenthesis of the type name.
   *  \param i The initializer list. */
  CT_CmpdLiteral (CTree *r, CTree *t, CTree *cr, CTree *i) {
    AddSon (sons[0], r); AddSon (sons[1], t); 
    AddSon (sons[2], cr); AddSon (sons[3], i);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 4; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
  /** Get the type name. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)sons[1]; }
  /** Get the initializer list. */
  CT_ExprList *Initializer () const { return (CT_ExprList*)sons[3]; }
  /** Get the semantic information about the created object. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
#line 4592 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_CmpdLiteral CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4596 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_CmpdLiteral CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4600 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ConstructExpr CTree.h Puma/CTree.h
 *  Tree node representing a construct expression.
 *  Example: \code std::string("abc") \endcode */
#line 4638 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1546 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4648 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1546 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1546 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ConstructExpr : public CT_Expression, public CSemObject {
#line 4661 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16CT_ConstructExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16CT_ConstructExprE;
private:
#line 1546 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1546 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // type, init

public:
  /** Constructor.
   *  \param t The type name.
   *  \param i The initializer list. */
  CT_ConstructExpr (CTree *t, CTree *i) { AddSon (sons[0], t); AddSon (sons[1], i); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  /** Get the type name. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)sons[0]; }
  /** Get the initializer. */
  CT_ExprList *Initializer () const { return (CT_ExprList*)sons[1]; }
  /** Get the semantic information about the created object. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
#line 4699 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_ConstructExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1576 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4703 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_ConstructExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1576 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4707 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1576 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1576 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ThrowExpr CTree.h Puma/CTree.h
 *  Tree node representing a throw expression.
 *  Example: \code throw std::exception() \endcode */
#line 4745 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1581 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4755 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1581 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1581 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ThrowExpr : public CT_Expression {
#line 4768 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_ThrowExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_ThrowExprE;
private:
#line 1581 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1581 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // throw, expr

public:
  /** Constructor.
   *  \param t The 'throw' keyword.
   *  \param e The expression. */
  CT_ThrowExpr (CTree *t, CTree *e = (CTree*)0) { AddSon (sons[0], t); AddSon (sons[1], e); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  /** Get the expression. */
  CTree *Expr () const { return sons[1]; }
#line 4802 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_ThrowExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1607 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4806 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_ThrowExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1607 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4810 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1607 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1607 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_IndexExpr CTree.h Puma/CTree.h
 *  Tree node representing an index expression. 
 *  Example: \code a[1] \endcode */
#line 4848 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1612 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4858 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1612 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1612 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_IndexExpr : public CT_Call {
#line 4871 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_IndexExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_IndexExprE;
private:
#line 1612 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1612 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // expr, open, index, close

public:
  /** Constructor.
   *  \param e The expression on which to invoke the index operator.
   *  \param o Left parenthesis of the index expression.
   *  \param i The index expression. 
   *  \param c Right parenthesis of the index expression. */
  CT_IndexExpr (CTree *e, CTree *o, CTree *i, CTree *c) {
    AddSon (sons[0], e); AddSon (sons[1], o); 
    AddSon (sons[2], i); AddSon (sons[3], c);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 4; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
#line 4908 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_IndexExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1641 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4912 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_IndexExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1641 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4916 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1641 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1641 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_CallExpr CTree.h Puma/CTree.h
 *  Tree node representing a function call expression.
 *  Example: \code f(i) \endcode */
#line 4954 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1646 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 4964 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1646 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1646 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_CallExpr : public CT_Call {
#line 4977 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_CallExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_CallExprE;
private:
#line 1646 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1646 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // expr, args

public:
  /** Constructor.
   *  \param e The expression on which the call is invoked. */
  CT_CallExpr (CTree *e) { AddSon (sons[0], e); AddSon (sons[1], 0); }
  /** Constructor.
   *  \param e The expression on which the call is invoked.
   *  \param l The argument list of the call. */
  CT_CallExpr (CTree *e, CTree *l) { AddSon (sons[0], e); AddSon (sons[1], l); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); } 
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  CTree *Expr () const { return sons[0]; }
  CT_ExprList *Arguments () const { return (CT_ExprList*)sons[1]; }
#line 5014 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_CallExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1675 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5018 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_CallExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1675 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5022 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1675 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1675 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_CastExpr CTree.h Puma/CTree.h
 *  Tree node representing a cast expression.
 *  Example: \code (int)a \endcode */
#line 5060 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1680 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5070 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1680 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1680 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_CastExpr : public CT_Expression {
#line 5083 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_CastExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_CastExprE;
private:
#line 1680 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1680 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // open, type, close, expr

public:
  /** Constructor.
   *  \param o Left parenthesis of the type name.
   *  \param t The type to cast to.
   *  \param c Right parenthesis of the type name. 
   *  \param e The expression to cast. */
  CT_CastExpr (CTree *o, CTree *t, CTree *c, CTree *e) {
    AddSon (sons[0], o); AddSon (sons[1], t); 
    AddSon (sons[2], c); AddSon (sons[3], e);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 4; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
  /** Get the casted expression. */
  CTree *Expr () const { return sons[3]; }
  /** Get the type to cast to. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)sons[1]; }
#line 5124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_CastExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1713 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5128 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_CastExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1713 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5132 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1713 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1713 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_StaticCast CTree.h Puma/CTree.h
 *  Tree node representing a static cast.
 *  Example: \code static_cast<int>(a) \endcode */
#line 5170 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1718 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5180 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1718 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1718 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_StaticCast : public CT_Expression {
#line 5193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_StaticCastE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_StaticCastE;
private:
#line 1718 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1718 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // cast, open, type, close, expr

public:
  /** Constructor.
   *  \param cst The cast operator, i.e. 'static_cast'.
   *  \param o Left arrow bracket of the type name.
   *  \param t The type to cast to.
   *  \param c Right array bracket of the type name.
   *  \param e The expression to cast. */
  CT_StaticCast (CTree *cst, CTree *o, CTree *t, CTree *c, CTree *e) {
    AddSon (sons[0], cst); AddSon (sons[1], o); AddSon (sons[2], t); 
    AddSon (sons[3], c); AddSon (sons[4], e);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 5; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
  /** Get the casted expression. */
  CTree *Expr () const { return sons[4]; }
  /** Get the type to cast to. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)sons[2]; }
#line 5235 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_StaticCast CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1752 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5239 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_StaticCast CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1752 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5243 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1752 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1752 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ConstCast CTree.h Puma/CTree.h
 *  Tree node representing a const cast.
 *  Example: \code const_cast<int>(a) \endcode */
#line 5281 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1757 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5291 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1757 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1757 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ConstCast : public CT_StaticCast {
#line 5304 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_ConstCastE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_ConstCastE;
private:
#line 1757 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1757 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param cst The cast operator, i.e. 'const_cast'.
   *  \param o Left arrow bracket of the type name.
   *  \param t The type to cast to.
   *  \param c Right array bracket of the type name.
   *  \param e The expression to cast. */
  CT_ConstCast (CTree *cst, CTree *o, CTree *t, CTree *c, CTree *e) :
    CT_StaticCast (cst, o, t, c, e) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 5326 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_ConstCast CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1771 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5330 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_ConstCast CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1771 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5334 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1771 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1771 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ReintCast CTree.h Puma/CTree.h
 *  Tree node representing a reinterpret cast.
 *  Example: \code reinterpret_cast<int>(a) \endcode */
#line 5372 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1776 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5382 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1776 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1776 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ReintCast : public CT_StaticCast {
#line 5395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_ReintCastE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_ReintCastE;
private:
#line 1776 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1776 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param cst The cast operator, i.e. 'reinterpret_cast'.
   *  \param o Left arrow bracket of the type name.
   *  \param t The type to cast to.
   *  \param c Right array bracket of the type name.
   *  \param e The expression to cast. */
  CT_ReintCast (CTree *cst, CTree *o, CTree *t, CTree *c, CTree *e) :
    CT_StaticCast (cst, o, t, c, e) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 5417 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_ReintCast CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1790 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5421 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_ReintCast CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1790 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1790 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1790 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_DynamicCast CTree.h Puma/CTree.h
 *  Tree node representing a dynamic cast.
 *  Example: \code dynamic_cast<int>(a) \endcode */
#line 5463 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1795 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5473 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1795 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1795 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DynamicCast : public CT_StaticCast {
#line 5486 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14CT_DynamicCastE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14CT_DynamicCastE;
private:
#line 1795 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1795 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param cst The cast operator, i.e. 'dynamic_cast'.
   *  \param o Left arrow bracket of the type name.
   *  \param t The type to cast to.
   *  \param c Right array bracket of the type name.
   *  \param e The expression to cast. */
  CT_DynamicCast (CTree *cst, CTree *o, CTree *t, CTree *c, CTree *e) :
    CT_StaticCast (cst, o, t, c, e) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 5508 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_DynamicCast CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1809 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5512 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_DynamicCast CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1809 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5516 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1809 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1809 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ImplicitCast CTree.h Puma/CTree.h
 *  Tree node representing an implicit cast.
 *  Example: 
 *  \code 
 * int i = 1.2;  // implicit cast from float to int 
 *  \endcode */
#line 5557 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1817 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5567 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1817 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1817 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ImplicitCast : public CT_Expression {
#line 5580 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15CT_ImplicitCastE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15CT_ImplicitCastE;
private:
#line 1817 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1817 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *_expr; // casted expression

public:
  /** Constructor.
   *  \param e The expression that is implicitely casted. */
  CT_ImplicitCast (CTree *e) { AddSon (_expr, e); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 1; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return n == 0 ? _expr : (CTree*)0; }
  /** Get the casted expression. */
  CTree *Expr () const { return _expr; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) 
   { CTree::ReplaceSon (_expr, old_son, new_son); }
#line 5612 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_ImplicitCast CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1841 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5616 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_ImplicitCast CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1841 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5620 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1841 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1841 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_TypeidExpr CTree.h Puma/CTree.h
 *  Tree node representing a typeid expression.
 *  Example: \code typeid(X) \endcode */
#line 5658 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1846 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5668 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1846 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1846 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_TypeidExpr : public CT_Expression {
#line 5681 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_TypeidExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_TypeidExprE;
private:
#line 1846 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1846 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // typeid, open, type_id/expr, close

public:
  /** Constructor.
   *  \param tid The 'typeid' operator.
   *  \param o The left parenthesis of the type name or expression.
   *  \param e The expression or type name for which to get the type identifier.
   *  \param c The right parenthesis of the type name or expression. */
  CT_TypeidExpr (CTree *tid, CTree *o, CTree *e, CTree *c) {
    AddSon (sons[0], tid); AddSon (sons[1], o); 
    AddSon (sons[2], e); AddSon (sons[3], c);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 4; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
  /** Get the typeid argument, i.e. the expression or type name for
   *  which to get the type identifier. */
  CTree *Arg () const { return sons[2]; }
#line 5721 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_TypeidExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1878 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5725 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_TypeidExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1878 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5729 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1878 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1878 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_SizeofExpr CTree.h Puma/CTree.h
 *  Tree node representing a sizeof expression.
 *  Example: \code sizeof(int*) \endcode */
#line 5767 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1883 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5777 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1883 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1883 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_SizeofExpr : public CT_Expression {
#line 5790 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_SizeofExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_SizeofExprE;
private:
#line 1883 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1883 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // key, open, type, close, expr

public:
  /** Constructor.
   *  \param k The 'sizeof' keyword.
   *  \param o Left parenthesis around the type name.
   *  \param t The type from which to get the size.
   *  \param c Right parenthesis around the type name. */
  CT_SizeofExpr (CTree *k, CTree *o, CTree *t, CTree *c) {
    AddSon (sons[0], k); AddSon (sons[1], o); AddSon (sons[2], t); 
    AddSon (sons[3], c); AddSon (sons[4], 0);
  }
  /** Constructor.
   *  \param k The 'sizeof' keyword.
   *  \param e The expression from which to get the size. */
  CT_SizeofExpr (CTree *k, CTree *e) {
    AddSon (sons[0], k); AddSon (sons[1], 0); AddSon (sons[2], 0); 
    AddSon (sons[3], 0); AddSon (sons[4], e);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 5); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
  /** Get the expression. */
  CTree *Expr () const { return sons[4]; }
  /** Get the type name. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)sons[2]; }
#line 5838 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_SizeofExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1923 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5842 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_SizeofExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1923 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5846 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1923 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1923 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_AlignofExpr CTree.h Puma/CTree.h
 *  Tree node representing an alignof expression.
 *  Example: \code __alignof(int) \endcode */
#line 5884 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1928 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5894 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1928 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1928 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_AlignofExpr : public CT_Expression {
#line 5907 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14CT_AlignofExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14CT_AlignofExprE;
private:
#line 1928 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1928 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // key, open, type, close, expr

public:
  /** Constructor.
   *  \param k The 'alignof' keyword.
   *  \param o Left parenthesis around the type name.
   *  \param t The type from which to get the alignment.
   *  \param c Right parenthesis around the type name. */
  CT_AlignofExpr (CTree *k, CTree *o, CTree *t, CTree *c) {
    AddSon (sons[0], k); AddSon (sons[1], o); AddSon (sons[2], t); 
    AddSon (sons[3], c); AddSon (sons[4], 0);
  }
  /** Constructor.
   *  \param k The 'alignof' keyword.
   *  \param e The expression from which to get the alignment. */
  CT_AlignofExpr (CTree *k, CTree *e) {
    AddSon (sons[0], k); AddSon (sons[1], 0); AddSon (sons[2], 0); 
    AddSon (sons[3], 0); AddSon (sons[4], e);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 5); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
  /** Get the expression. */
  CTree *Expr () const { return sons[4]; }
  /** Get the type name. */
  CT_NamedType *TypeName () const { return (CT_NamedType*)sons[2]; }
#line 5955 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_AlignofExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1968 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5959 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_AlignofExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 1968 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 5963 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 1968 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1968 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_TypeTraitExpr CTree.h Puma/CTree.h
 *  Tree node representing an type trait expression.
 *  Example: \code __is_enum(E) \endcode */
#line 6001 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 1973 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6011 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 1973 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1973 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_TypeTraitExpr : public CT_Expression {
#line 6024 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16CT_TypeTraitExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16CT_TypeTraitExprE;
private:
#line 1973 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 1973 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[6]; // key, open, type, comma, type, close

public:
  /** Constructor.
   *  \param k The type trait keyword.
   *  \param o Left parenthesis around the type name.
   *  \param t The type from which to get the trait.
   *  \param c Right parenthesis around the type name. */
  CT_TypeTraitExpr (CTree *k, CTree *o, CTree *t, CTree *c) {
    AddSon (sons[0], k); AddSon (sons[1], o); AddSon (sons[2], t);
    AddSon (sons[3], 0); AddSon (sons[4], 0); AddSon (sons[5], c);
  }
  /** Constructor.
   *  \param k The type trait keyword.
   *  \param o Left parenthesis around the type name.
   *  \param t1 The first type from which to get the trait.
   *  \param cc The comma between the types.
   *  \param t2 The second type from which to get the trait.
   *  \param c Right parenthesis around the type name. */
  CT_TypeTraitExpr (CTree *k, CTree *o, CTree *t1, CTree *cc, CTree *t2, CTree *c) {
    AddSon (sons[0], k); AddSon (sons[1], o); AddSon (sons[2], t1);
    AddSon (sons[3], cc); AddSon (sons[4], t2); AddSon (sons[5], c);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 6); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 6, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) {
    CTree::ReplaceSon (sons, 6, old_son, new_son);
  }
  /** Get the type trait operator. */
  int Operator () const { return sons[0]->token ()->type (); }
  /** Get the first type. */
  CT_NamedType *FirstType () const { return (CT_NamedType*)sons[2]; }
  /** Get the second type. */
  CT_NamedType *SecondType () const { return (CT_NamedType*)sons[4]; }
#line 6078 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_TypeTraitExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 2019 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6082 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_TypeTraitExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 2019 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6086 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2019 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2019 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_OffsetofExpr CTree.h Puma/CTree.h
 *  Tree node representing an offsetof expression.
 *  Example: \code offsetof(Circle,radius) \endcode */
#line 6124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 2024 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6134 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 2024 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2024 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_OffsetofExpr : public CT_Expression {
#line 6147 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15CT_OffsetofExprE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15CT_OffsetofExprE;
private:
#line 2024 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2024 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[6]; // key, open, type, comma, member, close

public:
  /** Constructor.
   *  \param k The 'offsetof' keyword.
   *  \param o Left parenthesis around the parameters.
   *  \param t The type containing the member.
   *  \param co The comma between type and member.
   *  \param m The member for which to get the offset.
   *  \param c Right parenthesis around the parameters. */
  CT_OffsetofExpr (CTree *k, CTree *o, CTree *t, CTree *co, CTree *m, CTree *c) {
    AddSon (sons[0], k); AddSon (sons[1], o); AddSon (sons[2], t); 
    AddSon (sons[3], co); AddSon (sons[4], m); AddSon (sons[5], c);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 6; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 6, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 6, old_son, new_son);
  }
  /** Get the typename. */
  CTree *TypeName () const { return sons[2]; }
  /** Get the member designator. */
  CT_DesignatorSeq *MemberDesignator () const { return (CT_DesignatorSeq*)sons[4]; }
#line 6190 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_OffsetofExpr CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 2059 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6194 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_OffsetofExpr CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 2059 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6198 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2059 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2059 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_IndexDesignator CTree.h Puma/CTree.h
 *  Tree node representing an index designator.
 *  Example: \code [1] \endcode */
#line 6236 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 2064 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6246 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 2064 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2064 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_IndexDesignator : public CT_Expression {
#line 6259 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma18CT_IndexDesignatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma18CT_IndexDesignatorE;
private:
#line 2064 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2064 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // open, index, close

public:
  /** Constructor.
   *  \param o Left bracket of the index designator.
   *  \param i The index expression.
   *  \param c Right bracket of the index designator. */
  CT_IndexDesignator (CTree *o, CTree *i, CTree *c) {
    AddSon (sons[0], o); AddSon (sons[1], i); AddSon (sons[2], c);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 6294 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_IndexDesignator CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 2091 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6298 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_IndexDesignator CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 2091 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6302 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2091 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2091 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_MembDesignator CTree.h Puma/CTree.h
 *  Tree node representing a member designator.
 *  Example: \code .a \endcode */
#line 6340 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 2096 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6350 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 2096 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2096 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_MembDesignator : public CT_Expression {
#line 6363 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma17CT_MembDesignatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma17CT_MembDesignatorE;
private:
#line 2096 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2096 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // dot, member

public:
  /** Constructor.
   *  \param d The dot before the member name.
   *  \param m The member name. */
  CT_MembDesignator (CTree *d, CTree *m) { AddSon (sons[0], d); AddSon (sons[1], m); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
#line 6395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_MembDesignator CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 2120 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6399 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_MembDesignator CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 2120 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6403 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2120 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2120 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_DesignatorSeq CTree.h Puma/CTree.h
 *  Tree node representing a designator sequence.
 *  Example: \code .a.b.c \endcode */
class CT_DesignatorSeq : public CT_List, public CSemValue {
#line 6442 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16CT_DesignatorSeqE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16CT_DesignatorSeqE;
private:
#line 2125 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2125 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size Initial number of designators. */
  CT_DesignatorSeq (int size = 1) : CT_List (size, 2) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }

  /** Get the type of the entity to initialize. */
  CTypeInfo *Type () const { return type; }
  /** Get the value of the entity to initialize. */
  CExprValue *Value () const { return value; }
  /** Get the semantic value object. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
#line 6466 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2141 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2141 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/*****************************************************************************/
/*                                                                           */
/*                         Declaration specifiers                            */
/*                                                                           */
/*****************************************************************************/

/** \class CT_DeclSpec CTree.h Puma/CTree.h
 *  Base class for all tree nodes representing declaration specifiers. */
#line 6509 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2151 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2151 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_DeclSpec : public CTree {
#line 6522 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_DeclSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_DeclSpecE;
private:
#line 2151 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2151 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

protected:
  /** Constructor. */
  CT_DeclSpec () {}
#line 6534 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_suffix ;
public :
CTreeList * gnu_suffix ( ) { return & _gnu_suffix ; }
const CTreeList * gnu_suffix ( ) const { return & _gnu_suffix ; }
#line 2155 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6540 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 2155 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6546 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2155 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2155 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_PrimDeclSpec CTree.h Puma/CTree.h
 *  Tree node representing a primitive declaration specifier. */
class CT_PrimDeclSpec : public CT_DeclSpec {
#line 6584 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15CT_PrimDeclSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15CT_PrimDeclSpecE;
private:
#line 2159 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2159 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Declaration specifier types. */
  enum Type { 
    PDS_FRIEND,    /** friend */
    PDS_TYPEDEF,   /** typedef */
    PDS_AUTO,      /** auto */
    PDS_REGISTER,  /** register */
    PDS_STATIC,    /** static */
    PDS_EXTERN,    /** extern */
    PDS_MUTABLE,   /** mutable */
    PDS_INLINE,    /** inline */
    PDS_VIRTUAL,   /** virtual */
    PDS_EXPLICIT,  /** explicit */
    PDS_CONST,     /** const */
    PDS_VOLATILE,  /** volatile */
    PDS_RESTRICT,  /** restrict */
    PDS_CHAR,      /** char */
    PDS_WCHAR_T,   /** wchar_t */
    PDS_BOOL,      /** bool */
    PDS_C_BOOL,    /** _Bool */
    PDS_SHORT,     /** short */
    PDS_INT,       /** int */
    PDS_LONG,      /** long */
    PDS_SIGNED,    /** signed */
    PDS_UNSIGNED,  /** unsigned */
    PDS_FLOAT,     /** float */
    PDS_DOUBLE,    /** double */
    PDS_VOID,      /** void */
    // GNU C specific type specifier
    PDS_INT128,    /** __int128 */
    // GNU C++ specific storage specifier
    PDS_THREAD,    /** __thread */
    // AspectC++ specific type specifier
    PDS_UNKNOWN_T, /** unknown_t */
    // Win specific declaration specifiers
    PDS_CDECL,     /** __cdecl */
    PDS_STDCALL,   /** __stdcall */
    PDS_FASTCALL,  /** __fastcall */
    PDS_INT64,     /** __int64 */
    PDS_UNKNOWN,   /** Unknown declaration specifier. */
    PDS_NUM        /** Number of declaration specifier types. */
  };

private:
  Type _type;
  CTree *_token; // has to be a CT_Token

  void determine_type ();

public:
  /** Constructor.
   *  \param t The token containing the declaration specifier. */
  CT_PrimDeclSpec (CT_Token *t) { AddSon (_token, (CTree*)t); determine_type (); }
  /** Constructor.
   *  \param t The declaration specifier type. */
  CT_PrimDeclSpec (Type t) : _token (0) { _type = t; }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return _token ? 1 : 0; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const 
   { return (n == 0) ? _token : (CTree*)0; }
  /** Get the textual representation of the declaration specifier.
   *  \return The string representation or " ". */
  const char *SpecText () const 
   { return _token ? _token->token ()->text () : " "; }
  /** Get the declaration specifier type. */
  Type SpecType () const { return _type; }
  /** Number of declaration specifier types. */
  static const int NumTypes = PDS_NUM;
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (_token, (CTree*)old_son, (CTree*)new_son);
    determine_type ();
  }
#line 6675 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2242 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2242 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_NamedType CTree.h Puma/CTree.h
 *  Tree node representing a named type.
 *  Example: \code (int*)a \endcode where int* is a 
 *  type with a generated name. */
class CT_NamedType : public CT_DeclSpec, public CSemObject {
#line 6715 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_NamedTypeE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_NamedTypeE;
private:
#line 2248 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2248 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // declspecs, declarator

public:
  /** Constructor.
   *  \param dss The declaration specifier sequence of the type.
   *  \param d The type declarator. */
  CT_NamedType (CTree *dss, CTree *d) { AddSon (sons[0], dss); AddSon (sons[1], d); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  /** Get the semantic information about the created temporary object. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
#line 6751 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2276 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2276 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};
      
/** \class CT_ClassSpec CTree.h Puma/CTree.h
 *  Tree node representing a class specifier.
 *  Example: \code class X \endcode */
#line 6789 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2281 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2281 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ClassSpec : public CT_DeclSpec, public CSemObject {
#line 6802 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_ClassSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_ClassSpecE;
private:
#line 2281 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2281 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // key, name
  
public:
  /** Constructor.
   *  \param k The 'class' or 'struct' keyword.
   *  \param n The class name. */
  CT_ClassSpec (CTree *k, CTree *n) { AddSon (sons[0], k); AddSon (sons[1], n); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); } 
  /** Get the class name. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[1]; }
  /** Get the semantic information about the class. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
#line 6838 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 0 ; }
#line 2309 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6845 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2309 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2309 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_UnionSpec CTree.h Puma/CTree.h
 *  Tree node representing a union specifier.
 *  Example: \code union X \endcode */
class CT_UnionSpec : public CT_ClassSpec {
#line 6884 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_UnionSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_UnionSpecE;
private:
#line 2314 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2314 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param k The 'union' keyword.
   *  \param n The name of the union. */
  CT_UnionSpec (CTree *k, CTree *n) : CT_ClassSpec (k, n) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 6902 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2324 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2324 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_EnumSpec CTree.h Puma/CTree.h
 *  Tree node representing an enumeration specifier.
 *  Example: \code enum X \endcode */
#line 6940 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2329 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2329 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_EnumSpec : public CT_ClassSpec {
#line 6953 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_EnumSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_EnumSpecE;
private:
#line 2329 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2329 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param k The 'enum' keyword. 
   *  \param n The name of the enumeration. */
  CT_EnumSpec (CTree *k, CTree *n) : CT_ClassSpec (k, n) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 6971 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 0 ; }
#line 2339 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 6978 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2339 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2339 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ExceptionSpec CTree.h Puma/CTree.h
 *  Tree node representing an exception specifier.
 *  Example: \code throw(std::exception) \endcode */
class CT_ExceptionSpec : public CT_DeclSpec {
#line 7017 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16CT_ExceptionSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16CT_ExceptionSpecE;
private:
#line 2344 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2344 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // throw, type_id_list
  
public:
  /** Constructor.
   *  \param k The 'throw' keyword.
   *  \param l The type list for the exception type to throw. */
  CT_ExceptionSpec (CTree *k, CTree *l) { AddSon (sons[0], k); AddSon (sons[1], l); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the exception type list. */
  CT_ArgDeclList *Arguments () const { return (CT_ArgDeclList*)sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
#line 7051 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2370 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2370 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/*****************************************************************************/
/*                                                                           */
/*                              Declarations                                 */
/*                                                                           */
/*****************************************************************************/

/** \class CT_Decl CTree.h Puma/CTree.h
 *  Base class for all tree nodes representing declarations. */
class CT_Decl : public CTree {
#line 7095 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma7CT_DeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma7CT_DeclE;
private:
#line 2380 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2380 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
 
  CT_LinkageSpec *_linkage;
  
protected:
  /** Constructor. */
  CT_Decl () : _linkage (0) {}
  
public:
  /** Set the linkage of the declared entity.
   *  \param l The linkage specifiers. */
  void Linkage (CT_LinkageSpec *l) { _linkage = l; }
  /** Get the linkage specifiers. */
  CT_LinkageSpec *Linkage () const { return _linkage; }
  /** Get this. */
  virtual CT_Decl *IsDeclaration () { return this; }
#line 7118 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2395 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_Program CTree.h Puma/CTree.h
 *  Root node of C/C++ syntax trees. */
class CT_Program : public CT_DeclList, public CSemScope {
#line 7156 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma10CT_ProgramE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma10CT_ProgramE;
private:
#line 2399 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2399 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size The initial number of declarations in the program.
   *  \param incr The initial increment count. */
  CT_Program (int size = 20, int incr = 20) : CT_DeclList (size, incr) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the top scope. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
#line 7176 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2411 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2411 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};
   
/** \class CT_ObjDecl CTree.h Puma/CTree.h
 *  Tree node representing an object declaration.
 *  Example: \code int *i \endcode */
#line 7214 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2416 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2416 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ObjDecl : public CT_Decl {
#line 7227 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma10CT_ObjDeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma10CT_ObjDeclE;
private:
#line 2416 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2416 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // declspecs, declarators, colon

public:
  /** Constructor.
   *  \param dsl The declaration specifier sequence.
   *  \param dl The declarator list.
   *  \param c Optional colon. */
  CT_ObjDecl (CTree *dsl, CTree *dl, CTree *c) {
    AddSon (sons[0], dsl); AddSon (sons[1], dl); AddSon (sons[2], c);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the declaration specifier sequence. */
  CT_DeclSpecSeq *DeclSpecs () const { return (CT_DeclSpecSeq*)sons[0]; }
  /** Get the declarator list. */
  CT_DeclaratorList *Declarators () const { return (CT_DeclaratorList*)sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 7266 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 2447 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 7272 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2447 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2447 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_TemplateDecl CTree.h Puma/CTree.h
 *  Tree node representing a template declaration. */
#line 7309 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2451 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2451 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_TemplateDecl : public CT_Decl, public CSemScope {
#line 7322 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15CT_TemplateDeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15CT_TemplateDeclE;
private:
#line 2451 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2451 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // export, param_list, decl

public:
  /** Constructor.
   *  \param e Optional 'export' keyword. 
   *  \param p The template parameter list.
   *  \param d The class or function declaration. */
  CT_TemplateDecl (CTree *e, CTree *p, CTree *d) {
    AddSon (sons[0], e); AddSon (sons[1], p); AddSon (sons[2], d);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son); 
  }
  /** Get the 'export' keyword. */
  CTree *Export () const { return sons[0]; }
  /** Get the template parameter list. */
  CT_TemplateParamList *Parameters () const { 
    return (CT_TemplateParamList*)sons[1]; 
  }
  /** Get the class or function declaration. */
  CTree *Declaration () const { return sons[2]; }
  /** Get the scope opened by the template declaration. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
#line 7367 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 2488 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 7373 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2488 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2488 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_TemplateParamDecl CTree.h Puma/CTree.h
 *  Base class for all tree nodesrepresenting a template parameter declaration. */
class CT_TemplateParamDecl : public CT_Decl, public CSemObject {
#line 7411 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma20CT_TemplateParamDeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma20CT_TemplateParamDeclE;
private:
#line 2492 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2492 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

protected:
  /** Constructor. */
  CT_TemplateParamDecl () {}
  
public:
  /** Get the template default argument. */
  virtual CT_ExprList *DefaultArgument () const = 0;
  /** Get the semantic information about the template parameter. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
#line 7429 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2502 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2502 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_NonTypeParamDecl CTree.h Puma/CTree.h
 *  Tree node representing a template non-type parameter declaration. */
class CT_NonTypeParamDecl : public CT_TemplateParamDecl {
#line 7467 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma19CT_NonTypeParamDeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma19CT_NonTypeParamDeclE;
private:
#line 2506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2506 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // declspecs, declarator, init

public:
  /** Constructor.
   *  \param dsl The declaration specifier sequence.
   *  \param d The parameter declarator.
   *  \param i The default template argument. */
  CT_NonTypeParamDecl (CTree *dsl, CTree *d, CTree *i = (CTree*)0) {
    AddSon (sons[0], dsl); AddSon (sons[1], d); AddSon (sons[2], i);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the declaration specifier sequence. */
  CT_DeclSpecSeq *DeclSpecs () const { return (CT_DeclSpecSeq*)sons[0]; }
  /** Get the parameter declarator. */
  CTree *Declarator () const { return sons[1]; }
  /** Get the default template argument. */
  CT_ExprList *DefaultArgument () const { return (CT_ExprList*)sons[2]; }
  /** Get the semantic information about the template parameter. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Set the default template argument. 
   *  \param i The default argument. */
  void Initializer (CTree *i) { AddSon (sons[2], i); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 7513 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2544 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2544 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_TypeParamDecl CTree.h Puma/CTree.h
 *  Tree node representing a template type parameter declaration. */
class CT_TypeParamDecl : public CT_TemplateParamDecl {
#line 7551 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16CT_TypeParamDeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16CT_TypeParamDeclE;
private:
#line 2548 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2548 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // params, key, id, init

public:
  /** Constructor.
   *  \param pl The template parameter list of an template template parameter.
   *  \param k The type keyword, i.e. 'class' or 'typename'.
   *  \param id The parameter identifier.
   *  \param i The default template argument. */
  CT_TypeParamDecl (CTree *pl, CTree *k, CTree *id, CTree *i = (CTree*)0) { 
    AddSon (sons[0], pl); AddSon (sons[1], k); 
    AddSon (sons[2], id); AddSon (sons[3], i);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 4); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the template parameter list of a template template parameter. */
  CT_TemplateParamList *Parameters () const { 
    return (CT_TemplateParamList*)sons[0]; 
  }
  /** Get the templare parameter name. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[2]; }
  /** Get the template default argument. */
  CT_ExprList *DefaultArgument () const { return (CT_ExprList*)sons[3]; }
  /** Set the template default argument.
   *  \param i The default argument. */
  void Initializer (CTree *i) { AddSon (sons[3], i); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
#line 7599 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2588 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2588 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_EnumDef CTree.h Puma/CTree.h
 *  Tree node representing the definition of an enumeration. 
 *  Example: \code enum E { A, B, C } \endcode */
#line 7637 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2593 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2593 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_EnumDef : public CT_Decl, public CSemObject {
#line 7650 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma10CT_EnumDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma10CT_EnumDefE;
private:
#line 2593 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2593 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // key, name, enumerators

public:
  /** Constructor.
   *  \param k The keyword 'enum'.
   *  \param n The name of the enumeration. */
  CT_EnumDef (CTree *k, CTree *n) {
    AddSon (sons[0], k); AddSon (sons[1], n); AddSon (sons[2], 0); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the name of the enumeration. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[1]; }
  /** Set the list of enumeration constants.
   *  \param el The enumerator list. */
  void Enumerators (CTree *el) { AddSon (sons[2], el); }
  /** Get the list of enumeration constants. */
  CT_EnumeratorList *Enumerators () const { return (CT_EnumeratorList*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
  /** Get the semantic information about the enumeration. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
#line 7693 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_suffix ;
public :
CTreeList * gnu_suffix ( ) { return & _gnu_suffix ; }
const CTreeList * gnu_suffix ( ) const { return & _gnu_suffix ; }
#line 2628 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 7699 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 2628 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 7705 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 0 ; }
#line 2628 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 7712 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2628 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2628 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_Enumerator CTree.h Puma/CTree.h
 *  Tree node representing a single enumeration constant. */
class CT_Enumerator : public CT_Decl, public CSemObject {
#line 7750 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_EnumeratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_EnumeratorE;
private:
#line 2632 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2632 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // name, init

public:
  /** Constructor.
   *  \param n The name of the enumerator. */
  CT_Enumerator (CTree *n) { AddSon (sons[0], n); AddSon (sons[1], 0); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the name of the enumerator. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[0]; }
  /** Set the initializer expression of the enumerator. */
  void Initializer (CTree *i) { AddSon (sons[1], i); }
  /** Get the initializer expression of the enumerator. */
  CT_ExprList *Initializer () const { return (CT_ExprList*)sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son); 
  }
  /** Get the semantic information about the enumerator. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
#line 7789 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2663 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2663 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_FctDef CTree.h Puma/CTree.h
 *  Tree node representing a function definition. 
 *  Example:
 *  \code
 * int mul(int x, int y) {
 *   return x*y;
 * }
 *  \endcode */
#line 7832 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2673 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2673 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_FctDef : public CT_Decl, public CSemObject {
#line 7845 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma9CT_FctDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma9CT_FctDefE;
private:
#line 2673 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2673 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[7]; // declspecs, declarator, try, ctor_init, args, body, handlers

public:
  /** Constructor.
   *  \param dss The declaration specifier sequence. 
   *  \param d The function declarator.
   *  \param t Optional keyword 'try' for a function try-block.
   *  \param ci Optional constructor initializer list.
   *  \param as Optional K&R argument declaration list.
   *  \param b The function body.
   *  \param hs Exception handler sequence for a function try-block. */
  CT_FctDef (CTree *dss, CTree *d, CTree *t, CTree *ci, CTree *as, 
             CTree *b, CTree *hs) {
    AddSon (sons[0], dss); AddSon (sons[1], d); AddSon (sons[2], t); 
    AddSon (sons[3], ci); AddSon (sons[4], as); AddSon (sons[5], b); 
    AddSon (sons[6], hs); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 7); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 7, n); }
  /** Get the declaration specifier sequence. */
  CT_DeclSpecSeq *DeclSpecs () const { return (CT_DeclSpecSeq*)sons[0]; }
  /** Get the function declarator. */
  CTree *Declarator () const { return sons[1]; }
  /** Get the 'try' keyword of the function try-block. */
  CT_Token *TryKey () const { return (CT_Token*)sons[2]; }
  /** Get the constructor initializer list. */
  CTree *CtorInit () const { return sons[3]; }
  /** Get the K&R argument declaration sequence. */
  CT_ArgDeclSeq *ArgDeclSeq () const { return (CT_ArgDeclSeq*)sons[4]; }
  /** Get the function body. */
  CT_CmpdStmt *Body () const { return (CT_CmpdStmt*)sons[5]; }
  /** Get the exception handler sequence of a function try-block. */
  CT_HandlerSeq *Handlers () const { return (CT_HandlerSeq*)sons[6]; }
  /** Get the semantic information about the function. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Set the constructor initializer list. 
   *  \param i The initializer list. */
  void CtorInit (CTree *i) { AddSon (sons[3], i); }
  /** Set the function body.
   *  \param b The function body. */
  void Body (CTree *b) { AddSon (sons[5], b); }
  /** Set the exception handler sequence of a function try-block.
   *  \param h The handlers. */
  void Handlers (CTree *h) { AddSon (sons[6], h); }
  /** Set the function try-block.
   *  \param t The keyword 'try'.
   *  \param c Optional constructor initializer list.
   *  \param b The function body.
   *  \param h The exception handler sequence. */
  void FctTryBlock (CTree *t, CTree *c, CTree *b, CTree *h) { 
    AddSon (sons[2], t); AddSon (sons[3], c); 
    AddSon (sons[5], b); AddSon (sons[6], h);
  }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 7, old_son, new_son);
  }
#line 7921 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 2741 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 7927 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2741 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2741 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_AsmDef CTree.h Puma/CTree.h
 *  Tree node representing an inline assembly definition. 
 *  Example: \code asm("movl %ecx %eax"); \endcode */
#line 7965 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2746 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2746 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_AsmDef : public CT_Decl {
#line 7978 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma9CT_AsmDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma9CT_AsmDefE;
private:
#line 2746 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2746 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // asm, open, str, close, semi_colon

public:
  /** Constructor.
   *  \param a The keyword 'asm'.
   *  \param o Left parenthesis around the assembler code string. 
   *  \param s The assembler code.
   *  \param c Right parenthesis around the assembler code string.
   *  \param sc Trailing semi-colon. */
  CT_AsmDef (CTree *a, CTree *o, CTree *s, CTree *c, CTree *sc) {
    AddSon (sons[0], a); AddSon (sons[1], o); AddSon (sons[2], s); 
    AddSon (sons[3], c); AddSon (sons[4], sc); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 5; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Get the assembler code. */
  CT_String *Instructions () const { return (CT_String*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
#line 8018 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 2778 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 8024 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2778 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2778 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_Handler CTree.h Puma/CTree.h
 *  Tree node representing an exception handler. */
class CT_Handler : public CT_Decl, public CSemScope {
#line 8062 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma10CT_HandlerE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma10CT_HandlerE;
private:
#line 2782 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2782 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // catch, exception_decl, stmt

public:
  /** Constructor.
   *  \param c The keyword 'catch'.
   *  \param e The exception object declaration.
   *  \param s The exception handling statement. */
  CT_Handler (CTree *c, CTree *e, CTree *s) {
    AddSon (sons[0], c); AddSon (sons[1], e); AddSon (sons[2], s);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the exception object declaration. */
  CT_ArgDeclList *Arguments () const { return (CT_ArgDeclList*)sons[1]; }
  /** Get the exception handling statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
  /** Get the scope opened by the handler. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
#line 8103 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2815 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2815 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_LinkageSpec CTree.h Puma/CTree.h
 *  Tree node representing a list of declaration with a specific linkage. */
#line 8140 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2819 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2819 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_LinkageSpec : public CT_Decl {
#line 8153 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14CT_LinkageSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14CT_LinkageSpecE;
private:
#line 2819 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2819 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // linkage specifiers, open, decls, close

public:
  /** Constructor.
   *  \param dss The linkage specifiers, e.g. extern and "C".
   *  \param o Left parenthesis around the declaration list.
   *  \param d The list of declarations.
   *  \param c Right parenthesis around the declaration list. */
  CT_LinkageSpec (CTree *dss, CTree *o, CTree *d, CTree *c) {
    AddSon (sons[0], dss); AddSon (sons[1], o);
    AddSon (sons[2], d); AddSon (sons[3], c);
    if (isList ())
      ((CT_DeclList*)Decls ())->Linkage (this);
    else
      ((CT_Decl*)Decls ())->Linkage (this);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 4); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the linkage specifier list. */
  CT_DeclSpecSeq *LinkageSpecifiers () const { return (CT_DeclSpecSeq*)sons[0]; }
  /** Get the list declarations. */
  CTree *Decls () const { return sons[2]; }
  /** Check if there is more than one enclosed declaration. 
   *  In this case the node returned by Decls() is a CT_DeclList
   *  node. */
  bool isList () const {
    return Decls ()->NodeName () == CT_DeclList::NodeId ();
  }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
#line 8204 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 2862 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 8210 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2862 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2862 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ArgDecl CTree.h Puma/CTree.h
 *  Tree node representing the declaration of a function parameter. */
class CT_ArgDecl : public CT_Decl, public CSemObject, public CSemValue {
#line 8248 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma10CT_ArgDeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma10CT_ArgDeclE;
private:
#line 2866 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2866 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // declspecs, declarator, init, ellipsis

public:
  /** Constructor.
   *  \param dsl The declaration specifier sequence.
   *  \param d The parameter declarator. */
  CT_ArgDecl (CTree *dsl, CTree *d) {
    AddSon (sons[0], dsl); AddSon (sons[1], d); 
    AddSon (sons[2], 0); AddSon (sons[3], 0); 
  }
  /** Constructor.
   *  \param ellipsis The variable argument list operator "...". */
  CT_ArgDecl (CTree *ellipsis) {
    AddSon (sons[0], 0); AddSon (sons[1], 0); 
    AddSon (sons[2], 0); AddSon (sons[3], ellipsis); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 4); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the declaration specifier sequence. */
  CT_DeclSpecSeq *DeclSpecs () const { return (CT_DeclSpecSeq*)sons[0]; }
  /** Get the function parameter declarator. */
  CTree *Declarator () const { return sons[1]; }
  /** Get the default argument. */
  CT_ExprList *Initializer () const {
    return (sons[2] && sons[2]->IsDelayedParse ()) ? 0 : (CT_ExprList*)sons[2];
  }
  /** Get the variable argument list operator. */
  CT_Token *Ellipsis () const { return (CT_Token*)sons[3]; }
  /** Get the semantic information about the function parameter. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Get the type of the function parameter.
   *  \return The type information object or NULL. */
  CTypeInfo *Type () const { return type; }
  /** Get the value of the function parameter.
   *  \return The value object or NULL. */
  CExprValue *Value () const { return value; }
  /** Get the semantic value information of the function parameter.
   *  \return The value object or NULL. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
  /** Set the default argument. */
  void Initializer (CTree *i) { AddSon (sons[2], i); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
#line 8312 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2922 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2922 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ArgDeclList CTree.h Puma/CTree.h
 *  Tree node representing a function parameter list. */
class CT_ArgDeclList : public CT_DeclList, public CSemScope {
#line 8350 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14CT_ArgDeclListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14CT_ArgDeclListE;
private:
#line 2926 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2926 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size The initial size of the list.
   *  \param props The list properties. */
  CT_ArgDeclList (int size = 2, int props = SEPARATORS | OPEN_CLOSE) : 
   CT_DeclList (size, 2) { AddProperties (props); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the scope opened by the parameter list. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
#line 8371 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2939 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2939 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ArgDeclSeq CTree.h Puma/CTree.h
 *  Tree node representing a K&R function parameter declarations list. */
class CT_ArgDeclSeq : public CT_DeclList, public CSemScope {
#line 8409 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_ArgDeclSeqE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_ArgDeclSeqE;
private:
#line 2943 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2943 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size The initial size of the list. */
  CT_ArgDeclSeq (int size = 2) : CT_DeclList (size, 2) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the scope opened by the parameter declarations list. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
#line 8428 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2954 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2954 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ArgNameList CTree.h Puma/CTree.h
 *  Tree node representing a K&R function parameter name list. */
class CT_ArgNameList : public CT_ArgDeclList {
#line 8466 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14CT_ArgNameListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14CT_ArgNameListE;
private:
#line 2958 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2958 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor. */
  CT_ArgNameList () : CT_ArgDeclList () {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 8482 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 2966 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2966 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_NamespaceDef CTree.h Puma/CTree.h
 *  Tree node representing a namespace definition.
 *  Example: \code namespace a {} \endcode */
#line 8520 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 2971 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2971 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_NamespaceDef : public CT_Decl, public CSemObject {
#line 8533 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15CT_NamespaceDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15CT_NamespaceDefE;
private:
#line 2971 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 2971 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // inline, ns, name, members

public:
  /** Constructor.
   *  \param i The keyword 'inline'.
   *  \param n The keyword 'namespace'.
   *  \param nm The name of the namespace. */
  CT_NamespaceDef (CTree *i, CTree *n, CTree *nm) {
    AddSon (sons[0], i); AddSon (sons[1], n); AddSon (sons[2], nm); AddSon (sons[3], 0); 
  }
  /** Constructor.
   *  \param i The keyword 'inline'.
   *  \param n The keyword 'namespace'.
   *  \param nm The name of the namespace. 
   *  \param m The namespace member declarations list. */
  CT_NamespaceDef (CTree *i, CTree *n, CTree *nm, CTree *m) {
    AddSon (sons[0], i); AddSon (sons[1], n); AddSon (sons[2], nm); AddSon (sons[3], m); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 4); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Set the namespace member declarations list. */
  void Members (CTree *m) { AddSon (sons[3], m); }
  /** Get the namespace member declarations list. */
  CT_MembList *Members () const { return (CT_MembList*)sons[3]; }
  /** Get the name of the namespace. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[2]; }
  /** Get the semantic information about the namespace. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
  /** Return true if this is an inline namespace. */
  bool isInline () const { return sons[0] != (CTree*)0; }
#line 8586 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 3016 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 8592 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3016 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3016 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_NamespaceAliasDef CTree.h Puma/CTree.h
 *  Tree node representing a namespace alias definition.
 *  Example: \code namespace b = a; \endcode */
#line 8630 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 3021 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3021 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_NamespaceAliasDef : public CT_Decl, public CSemObject {
#line 8643 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma20CT_NamespaceAliasDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma20CT_NamespaceAliasDefE;
private:
#line 3021 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3021 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // ns, alias, assign, name, semi_colon

public:
  /** Constructor.
   *  \param n The keyword 'namespace'.
   *  \param a The name of the namespace alias.
   *  \param as The assignment operator '='.
   *  \param nm The name of the original namespace.
   *  \param s The trailing semi-colon. */
  CT_NamespaceAliasDef (CTree *n, CTree *a, CTree *as, CTree *nm, CTree *s) {
    AddSon (sons[0], n); AddSon (sons[1], a); AddSon (sons[2], as); 
    AddSon (sons[3], nm); AddSon (sons[4], s); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 5; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Get the name of the original namespace. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[3]; }
  /** Get the name of the namespace alias. */
  CT_SimpleName *Alias () const { return (CT_SimpleName*)sons[1]; }
  /** Get the semantic information about the namespace alias. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
#line 8687 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 3057 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 8693 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3057 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3057 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_UsingDirective CTree.h Puma/CTree.h
 *  Tree node representing a namespace using directive.
 *  Example: \code using namespace std; \endcode */
#line 8731 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 3062 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3062 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_UsingDirective : public CT_Decl {
#line 8744 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma17CT_UsingDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma17CT_UsingDirectiveE;
private:
#line 3062 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3062 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // using, ns, name, semi_colon

public:
  /** Constructor. 
   *  \param u The keyword 'using'.
   *  \param ns The keyword 'namespace'. 
   *  \param n The name of the namespace.
   *  \param s The trailing semi-colon. */
  CT_UsingDirective (CTree *u, CTree *ns, CTree *n, CTree *s) {
    AddSon (sons[0], u); AddSon (sons[1], ns); AddSon (sons[2], n); 
    AddSon (sons[3], s); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 4; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the name of the namespace. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
#line 8783 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 3093 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 8789 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 2 ; }
#line 3093 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 8796 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3093 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3093 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/*****************************************************************************/
/*                                                                           */
/*                              Declarators                                  */
/*                                                                           */
/*****************************************************************************/

/** \class CT_Declarator CTree.h Puma/CTree.h
 *  Base class for all tree nodes representing declarators. */
#line 8839 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 3103 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3103 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Declarator : public CTree {
#line 8852 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_DeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_DeclaratorE;
private:
#line 3103 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3103 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

protected:
  /** Constructor. */
  CT_Declarator () {}

public:
  /** Get the declarator. */
  virtual CTree *Declarator () const = 0;
  /** Get this. */
  virtual CT_Declarator *IsDeclarator () { return this; }
  /** Get the declared name. */
  CT_SimpleName *Name ();
  /** Get the declared name and set last_declarator to 
   *  the declarator containing the name. 
   *  \param last_declarator To be set to the declarator containing the name. */
  CT_SimpleName *Name (CT_Declarator *&last_declarator);
#line 8876 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_suffix ;
public :
CTreeList * gnu_suffix ( ) { return & _gnu_suffix ; }
const CTreeList * gnu_suffix ( ) const { return & _gnu_suffix ; }
#line 3119 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 8882 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 3119 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 8888 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3119 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3119 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_InitDeclarator CTree.h Puma/CTree.h
 *  Tree node representing a declarator with initializer.
 *  Example: \code int *i = 0; \endcode */
#line 8926 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 3124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_InitDeclarator : public CT_Declarator, public CSemObject {
#line 8939 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma17CT_InitDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma17CT_InitDeclaratorE;
private:
#line 3124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3124 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // declarator, init
  CTree *obj_decl;

public:
  /** Constructor.
   *  \param d The declarator.
   *  \param i The initializer. */
  CT_InitDeclarator (CTree *d, CTree *i = 0) {
    AddSon (sons[0], d); AddSon (sons[1], i);
    AddSon (obj_decl, 0); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[0]; }
  /** Get the initializer. */
  CT_ExprList *Initializer () const { return (CT_ExprList*)sons[1]; }
  /** Get the semantic information about the declared object. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Get the object declaration node containing the declarator. */
  CT_ObjDecl *ObjDecl () const { return (CT_ObjDecl*)obj_decl; }
  /** Set the initializer. */
  void Initializer (CTree* i) { AddSon (sons[1], i); }
  /** Set the object declaration node containing the declarator. 
   *  \param od The object declaration node. */
  void ObjDecl (CTree *od) { AddSon (obj_decl, od); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
#line 8988 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 0 ; }
#line 3165 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 8995 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3165 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3165 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_BracedDeclarator CTree.h Puma/CTree.h
 *  Tree node representing a braced declarator.
 *  Example: \code int (i); \endcode */
class CT_BracedDeclarator : public CT_Declarator {
#line 9034 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma19CT_BracedDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma19CT_BracedDeclaratorE;
private:
#line 3170 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3170 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // open, win_specs, declarator, close

public:
  /** Constructor.
   *  \param o Left parenthesis around the declarator.
   *  \param d The declarator.
   *  \param c Right parenthesis around the declarator. */
  CT_BracedDeclarator (CTree *o, CTree *d, CTree *c) {
    AddSon (sons[0], o); AddSon (sons[1], 0); 
    AddSon (sons[2], d); AddSon (sons[3], c); 
  }
  /** Constructor.
   *  \param o Left parenthesis around the declarator.
   *  \param ws Declaration specifiers.
   *  \param d The declarator.
   *  \param c Right parenthesis around the declarator. */
  CT_BracedDeclarator (CTree *o, CTree *ws, CTree *d, CTree *c) {
    AddSon (sons[0], o); AddSon (sons[1], ws); 
    AddSon (sons[2], d); AddSon (sons[3], c); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 4); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
#line 9081 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3209 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3209 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ArrayDelimiter CTree.h Puma/CTree.h
 *  Tree node representing an array delimiter.
 *  Example: \code [10] \endcode or \code [*] \endcode */
class CT_ArrayDelimiter : public CTree {
#line 9120 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma17CT_ArrayDelimiterE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma17CT_ArrayDelimiterE;
private:
#line 3214 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3214 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // star, static, quals, expr
  bool pos0;

public:
  /** Constructor.
   *  \param m The operator '*'.
   *  \param s The keyword 'static'.
   *  \param q The const/volatile qualifier sequence. 
   *  \param e The array size expression. 
   *  \param p Position of keyword 'static', true means before the
   *           qualifier sequence and false means behind it. */
  CT_ArrayDelimiter (CTree *m, CTree *s, CTree *q, CTree *e, bool p = false) {
    AddSon (sons[0], m); AddSon (sons[1], s); 
    AddSon (sons[2], q); AddSon (sons[3], e); pos0 = p;
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 4); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the operator '*'. */
  CT_Token *Star () const { return (CT_Token*)sons[0]; }
  /** Get the keyword 'static'. */
  CT_Token *Static () const { return (CT_Token*)sons[pos0?2:1]; }
  /** Get the const/volatile qualifier sequence. */
  CT_DeclSpecSeq *Qualifier () const { return (CT_DeclSpecSeq*)sons[pos0?1:2]; }
  /** Get the array size expression. */
  CTree *Expr () const { return sons[3]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
#line 9168 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3254 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3254 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ArrayDeclarator CTree.h Puma/CTree.h
 *  Tree node representing an array declarator.
 *  Example: \code a[10] \endcode */
class CT_ArrayDeclarator : public CT_Declarator, public CSemValue {
#line 9207 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma18CT_ArrayDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma18CT_ArrayDeclaratorE;
private:
#line 3259 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3259 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // declarator, open, delim, close

public:
  /** Constructor.
   *  \param d The array declarator.
   *  \param o Left bracket around the delimiter.
   *  \param ad The array delimiter.
   *  \param c Right bracket around the delimiter. */
  CT_ArrayDeclarator (CTree *d, CTree *o, CTree *ad, CTree *c) {
    AddSon (sons[0], d); AddSon (sons[1], o); 
    AddSon (sons[2], ad); AddSon (sons[3], c); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 4; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the array declarator. */
  CTree *Declarator () const { return sons[0]; }
  /** Get the array delimiter. */
  CT_ArrayDelimiter *Delimiter () const 
   { return (CT_ArrayDelimiter*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
  /** Get the semantic information for the type of the declared array. */
  CTypeInfo *Type () const { return type; }
  /** Get the semantic information for the value of the declared array. */
  CExprValue *Value () const { return value; }
  /** Get the semantic information object. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
#line 9255 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3299 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3299 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_FctDeclarator CTree.h Puma/CTree.h
 *  Tree node representing a function declarator.
 *  Example: \code f(int a) const \endcode */
class CT_FctDeclarator : public CT_Declarator {
#line 9294 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16CT_FctDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16CT_FctDeclaratorE;
private:
#line 3304 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3304 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // declarator, args, cv_quals, exception_specs

public:
  /** Constructor.
   *  \param d The function declarator.
   *  \param args The function parameter list.
   *  \param cv The function qualifiers.
   *  \param es The exception specifier. */
  CT_FctDeclarator (CTree *d, CTree *args, CTree *cv, CTree *es) {
    AddSon (sons[0], d); AddSon (sons[1], args); 
    AddSon (sons[2], cv); AddSon (sons[3], es); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 4); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the function declarator. */
  CTree *Declarator () const { return sons[0]; }
  /** Get the function parameter list. */
  CT_ArgDeclList *Arguments () const { return (CT_ArgDeclList*)sons[1]; }
  /** Get the function qualifier list. */
  CT_DeclSpecSeq *Qualifier () const { return (CT_DeclSpecSeq*)sons[2]; }
  /** Get the exception specifier. */
  CT_ExceptionSpec *ExceptionSpecs () const { return (CT_ExceptionSpec*)sons[3]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
#line 9339 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3341 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3341 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_RefDeclarator CTree.h Puma/CTree.h
 *  Tree node representing a reference declarator.
 *  Example: \code &a \endcode */
class CT_RefDeclarator : public CT_Declarator {
#line 9378 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16CT_RefDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16CT_RefDeclaratorE;
private:
#line 3346 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3346 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // ref, declarator

public:
  /** Constructor.
   *  \param r The reference operator '&'.
   *  \param d The declarator. */
  CT_RefDeclarator (CTree *r, CTree *d) { AddSon (sons[0], r); AddSon (sons[1], d); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) {
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
#line 9412 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3372 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3372 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_PtrDeclarator CTree.h Puma/CTree.h
 *  Tree node representing a pointer declarator.
 *  Example: \code *a \endcode */
class CT_PtrDeclarator : public CT_Declarator {
#line 9451 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16CT_PtrDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16CT_PtrDeclaratorE;
private:
#line 3377 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3377 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // ptr, cv_quals, declarator

public:
  /** Constructor.
   *  \param p The pointer operator '*'.
   *  \param c The const/volatile pointer qualifier sequence.
   *  \param d The declarator. */
  CT_PtrDeclarator (CTree *p, CTree *c, CTree *d) {
    AddSon (sons[0], p); AddSon (sons[1], c); AddSon (sons[2], d); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[2]; }
  /** Get the const/volatile qualifier sequence. */
  CT_DeclSpecSeq *Qualifier () const { return (CT_DeclSpecSeq*)sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 9490 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3408 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3408 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_MembPtrDeclarator CTree.h Puma/CTree.h
 *  Tree node representing a member pointer declarator.
 *  Example: \code *X::a \endcode */
class CT_MembPtrDeclarator : public CT_Declarator {
#line 9529 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma20CT_MembPtrDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma20CT_MembPtrDeclaratorE;
private:
#line 3413 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3413 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // class, colon, ptr, cv_quals, declarator

public:
  /** Constructor.
   *  \param c The class name.
   *  \param cc The scope operator '::'.
   *  \param p The name of the pointer.
   *  \param q The const/volatile pointer qualifier sequence.
   *  \param d The declarator. */
  CT_MembPtrDeclarator (CTree *c, CTree *cc, CTree *p, CTree *q, CTree *d) {
    AddSon (sons[0], c); AddSon (sons[1], cc); AddSon (sons[2], p); 
    AddSon (sons[3], q); AddSon (sons[4], d); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 5); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Get the name of the declared pointer. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[0]; }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[4]; }
  /** Get the const/volatile qualifier sequence. */
  CT_DeclSpecSeq *Qualifier () const { return (CT_DeclSpecSeq*)sons[3]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
#line 9573 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3449 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3449 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_BitFieldDeclarator CTree.h Puma/CTree.h
 *  Tree node representing a bit-field declarator.
 *  Example: \code a : 2 \endcode */
class CT_BitFieldDeclarator : public CT_Declarator, public CSemObject {
#line 9612 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma21CT_BitFieldDeclaratorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma21CT_BitFieldDeclaratorE;
private:
#line 3454 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3454 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // declarator, colon, expr

public:
  /** Constructor.
   *  \param d The declarator.
   *  \param c The colon between the declarator and the bit count.
   *  \param e The expression specifying the number of bits. */
  CT_BitFieldDeclarator (CTree *d, CTree *c, CTree *e = 0) {
    AddSon (sons[0], d); AddSon (sons[1], c); AddSon (sons[2], e); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[0]; }
  /** Get the expression specifying the number of bits. */
  CTree *Expr () const { return sons[2]; }
  /** Set the expression specifying the number of bits. */
  void FieldSize (CTree *s) { AddSon (sons[2], s); }
  /** Get the semantic information about the declared bit-field. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 9655 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3489 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3489 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/*****************************************************************************/
/*                                                                           */
/*                              Statements                                   */
/*                                                                           */
/*****************************************************************************/

/** \class CT_Statement CTree.h Puma/CTree.h
 *  Base class for all tree nodes representing statements. */
class CT_Statement : public CTree {
#line 9699 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_StatementE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_StatementE;
private:
#line 3499 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3499 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
 
protected:
  /** Constructor. */
  CT_Statement () {}
  /** Get this. */
  virtual CT_Statement *IsStatement () { return this; }
#line 9713 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3505 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3505 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_LabelStmt CTree.h Puma/CTree.h
 *  Tree node representing a label statement.
 *  Example: \code incr_a: a++; \endcode */
#line 9751 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 3510 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3510 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_LabelStmt : public CT_Statement {
#line 9764 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_LabelStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_LabelStmtE;
private:
#line 3510 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3510 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // id, colon, stmt

public:
  /** Constructor.
   *  \param id The name of the label.
   *  \param c The colon behind the label.
   *  \param stmt The statement following the label. */
  CT_LabelStmt (CTree *id, CTree *c, CTree *stmt) {
    AddSon (sons[0], id); AddSon (sons[1], c); AddSon (sons[2], stmt); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[2]; }
  /** Get the name of the label. */
  CT_SimpleName *Label () const { return (CT_SimpleName*)sons[0]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 9803 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 1 ; }
#line 3541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 9810 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_DefaultStmt CTree.h Puma/CTree.h
 *  Tree node representing a default statement of a switch statement.
 *  Example: \code default: break; \endcode */
class CT_DefaultStmt : public CT_Statement {
#line 9849 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14CT_DefaultStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14CT_DefaultStmtE;
private:
#line 3546 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3546 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // keyword, colon, stmt

public:
  /** Constructor.
   *  \param kw The keyword 'default'.
   *  \param c The colon behind the keyword.
   *  \param stmt The statement of the default case. */
  CT_DefaultStmt (CTree *kw, CTree *c, CTree *stmt) {
    AddSon (sons[0], kw); AddSon (sons[1], c); AddSon (sons[2], stmt); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 9886 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3575 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3575 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_TryStmt CTree.h Puma/CTree.h
 *  Tree node representing a try-catch statement.
 *  Example: \code try { f(); } catch (...) {} \endcode */
class CT_TryStmt : public CT_Statement {
#line 9925 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma10CT_TryStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma10CT_TryStmtE;
private:
#line 3580 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3580 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // try, stmt, handlers

public:
  /** Constructor.
   *  \param t The keyword 'try'.
   *  \param s The statement enclosed in the try-catch block.
   *  \param h The exception handler sequence. */
  CT_TryStmt (CTree *t, CTree *s, CTree *h) {
    AddSon (sons[0], t); AddSon (sons[1], s); AddSon (sons[2], h); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the enclosed statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[1]; }
  /** Get the exception handler sequence. */
  CT_HandlerSeq *Handlers () const { return (CT_HandlerSeq*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 9964 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3611 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3611 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_CaseStmt CTree.h Puma/CTree.h
 *  Tree node representing a case statement.
 *  Example: \code case 42: a=42; \endcode */
class CT_CaseStmt : public CT_Statement {
#line 10003 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_CaseStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_CaseStmtE;
private:
#line 3616 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3616 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[4]; // keyword, expr, colon, stmt

public:
  /** Constructor.
   *  \param kw The keyword 'case'.
   *  \param expr The constant expression specifying the case value.
   *  \param c The colon.
   *  \param stmt The statement of the case. */
  CT_CaseStmt (CTree *kw, CTree *expr, CTree *c, CTree *stmt) {
    AddSon (sons[0], kw); AddSon (sons[1], expr); 
    AddSon (sons[2], c); AddSon (sons[3], stmt); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 4; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[3]; }
  /** Get the expression specifying the case value. */
  CTree *Expr () const { return sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
#line 10044 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3649 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3649 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ExprStmt CTree.h Puma/CTree.h
 *  Tree node representing an expression statement.
 *  Example: \code a+b; \endcode */
#line 10082 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 3654 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3654 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ExprStmt : public CT_Statement {
#line 10095 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_ExprStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_ExprStmtE;
private:
#line 3654 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3654 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // expr, semi_colon

public:
  /** Constructor.
   *  \param expr The expression.
   *  \param sc The trailing semi-colon. */
  CT_ExprStmt (CTree *expr, CTree *sc) { AddSon (sons[0], expr); AddSon (sons[1], sc); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the expression. */
  CTree *Expr () const { return sons[0]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
#line 10129 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 3680 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 10135 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3680 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3680 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_DeclStmt CTree.h Puma/CTree.h
 *  Tree node representing a declaration statement.
 *  Example: \code int i = 0; \endcode */
class CT_DeclStmt : public CT_Statement {
#line 10174 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_DeclStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_DeclStmtE;
private:
#line 3685 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3685 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *_decl;

public:
  /** Constructor.
   *  \param decl The declaration. */
  CT_DeclStmt (CTree *decl) { AddSon (_decl, decl); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 1; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return n == 0 ? _decl : (CTree*)0; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) 
   { CTree::ReplaceSon (_decl, old_son, new_son); }
#line 10204 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3707 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3707 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_SwitchStmt CTree.h Puma/CTree.h
 *  Tree node representing a switch statement.
 *  Example: \code switch(a) { case 0: a++; } \endcode */
class CT_SwitchStmt : public CT_Statement, public CSemScope {
#line 10243 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_SwitchStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_SwitchStmtE;
private:
#line 3712 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3712 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // keyword, open, cond, close, stmt

public:
  /** Constructor.
   *  \param kw The keyword 'switch'.
   *  \param o Left parenthesis before the condition.
   *  \param cond The switch-expression. 
   *  \param c Right parenthesis behind the condition. 
   *  \param stmt The cases of the switch-statement. */
  CT_SwitchStmt (CTree *kw, CTree *o, CTree *cond, CTree *c, CTree *stmt) {
    AddSon (sons[0], kw); AddSon (sons[1], o); AddSon (sons[2], cond); 
    AddSon (sons[3], c); AddSon (sons[4], stmt); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 5; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Get the cases. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[4]; }
  /** Get the switch-expression. */
  CTree *Condition () const { return sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
  /** Get the scope opened by the switch-statement. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
#line 10287 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3748 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3748 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_IfStmt CTree.h Puma/CTree.h
 *  Tree node representing a if-statement.
 *  Example: \code if(a==0) a++; \endcode */
class CT_IfStmt : public CT_Statement, public CSemScope {
#line 10326 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma9CT_IfStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma9CT_IfStmtE;
private:
#line 3753 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3753 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // keyword, open, cond, close, stmt

public:
  /** Constructor.
   *  \param kw The keyword 'if'.
   *  \param o Left parenthesis before the condition.
   *  \param cond The condition.
   *  \param c Right parenthesis behind the condition.
   *  \param stmt The controlled statement. */
  CT_IfStmt (CTree *kw, CTree *o, CTree *cond, CTree *c, CTree *stmt) {
    AddSon (sons[0], kw); AddSon (sons[1], o); AddSon (sons[2], cond); 
    AddSon (sons[3], c); AddSon (sons[4], stmt); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 5; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Get the controlled statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[4]; }
  /** Get the condition. */
  CTree *Condition () const { return sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
  /** Get the scope opened by the if-statement. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
#line 10370 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3789 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3789 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_IfElseStmt CTree.h Puma/CTree.h
 *  Tree node representing a if-else-statement.
 *  Example: \code if(a==0) a++; else a=0; \endcode */
class CT_IfElseStmt : public CT_Statement, public CSemScope {
#line 10409 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_IfElseStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_IfElseStmtE;
private:
#line 3794 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3794 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[7]; // if, open, cond, close, if_stmt, else, else_stmt

public:
  /** Constructor.
   *  \param i The keyword 'if'.
   *  \param o Left parenthesis before the condition.
   *  \param cond The condition.
   *  \param c Right parenthesis behind the condition.
   *  \param is The statement controlled by the if-branch.
   *  \param e The keyword 'else'.
   *  \param es The statement controlled by the else-branch. */
  CT_IfElseStmt (CTree *i, CTree *o, CTree *cond, CTree *c, 
                 CTree *is, CTree *e, CTree *es) {
    AddSon (sons[0], i); AddSon (sons[1], o); AddSon (sons[2], cond); 
    AddSon (sons[3], c); AddSon (sons[4], is); AddSon (sons[5], e); 
    AddSon (sons[6], es); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 7; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 7, n); }
  /** Get the condition. */
  CTree *Condition () const { return sons[2]; }
  /** Get the statement controlled by the if-branch. */
  CT_Statement *IfPart () const { return (CT_Statement*)sons[4]; }
  /** Get the statement controlled by the else-branch. */
  CT_Statement *ElsePart () const { return (CT_Statement*)sons[6]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 7, old_son, new_son);
  }
  /** Get the scope opened by the if-statement. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
#line 10459 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3836 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3836 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_BreakStmt CTree.h Puma/CTree.h
 *  Tree node representing a break-statement.
 *  Example: \code break; \endcode */
class CT_BreakStmt : public CT_Statement {
#line 10498 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_BreakStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_BreakStmtE;
private:
#line 3841 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3841 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // key, semi_colon

public:
  /** Constructor.
   *  \param key The keyword 'break'.
   *  \param sc The trailing semi-colon. */
  CT_BreakStmt (CTree *key, CTree *sc) { AddSon (sons[0], key); AddSon (sons[1], sc); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
#line 10530 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3865 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3865 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ContinueStmt CTree.h Puma/CTree.h
 *  Tree node representing a continue-statement.
 *  Example: \code continue; \endcode */
class CT_ContinueStmt : public CT_Statement {
#line 10569 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15CT_ContinueStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15CT_ContinueStmtE;
private:
#line 3870 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3870 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // key, semi_colon

public:
  /** Constructor.
   *  \param key The keyword 'continue'.
   *  \param sc The trailing semi-colon. */
  CT_ContinueStmt (CTree *key, CTree *sc) { AddSon (sons[0], key); AddSon (sons[1], sc); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
#line 10601 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3894 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3894 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_GotoStmt CTree.h Puma/CTree.h
 *  Tree node representing a goto-stmt.
 *  Example: \code goto incr_a; \endcode */
class CT_GotoStmt : public CT_Statement {
#line 10640 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_GotoStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_GotoStmtE;
private:
#line 3899 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3899 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // key, label, semi_colon

public:
  /** Constructor.
   *  \param key The keyword 'goto'.
   *  \param l The name of the jump label.
   *  \param sc The trailing semi-colon. */
  CT_GotoStmt (CTree *key, CTree *l, CTree *sc) {
    AddSon (sons[0], key); AddSon (sons[1], l); AddSon (sons[2], sc); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 3; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the name of the jump label. */
  CT_SimpleName *Label () const { return (CT_SimpleName*)sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 10677 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3928 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3928 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ReturnStmt CTree.h Puma/CTree.h
 *  Tree node representing a return-statement.
 *  Example: \code return 1; \endcode */
class CT_ReturnStmt : public CT_Statement {
#line 10716 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_ReturnStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_ReturnStmtE;
private:
#line 3933 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3933 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // key, expr, semi_colon

public:
  /** Constructor.
   *  \param key The keyword 'return'.
   *  \param e The expression specifying the return value. 
   *  \param sc The trailing semi-colon. */
  CT_ReturnStmt (CTree *key, CTree *e, CTree *sc) {
    AddSon (sons[0], key); AddSon (sons[1], e); AddSon (sons[2], sc); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the expression specifying the return value. */
  CTree *Expr () const { return sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 10753 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 3962 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3962 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_WhileStmt CTree.h Puma/CTree.h
 *  Tree node representing a while-statement.
 *  Example: \code while(a>0) a--; \endcode */
class CT_WhileStmt : public CT_Statement, public CSemScope {
#line 10792 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_WhileStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_WhileStmtE;
private:
#line 3967 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 3967 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // key, open, cond, close, stmt

public:
  /** Constructor.
   *  \param kw The keyword 'while'.
   *  \param o Left parenthesis before the condition.
   *  \param cond The loop condition. 
   *  \param c Right parenthesis behind the condition. 
   *  \param stmt The controlled statement. */
  CT_WhileStmt (CTree *kw, CTree *o, CTree *cond, CTree *c, CTree *stmt) {
    AddSon (sons[0], kw); AddSon (sons[1], o); AddSon (sons[2], cond); 
    AddSon (sons[3], c); AddSon (sons[4], stmt); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 5; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Get the controlled statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[4]; }
  /** Get the loop condition. */
  CTree *Condition () const { return sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
  /** Get the scope opened by the while-statement. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
#line 10836 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4003 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4003 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_DoStmt CTree.h Puma/CTree.h
 *  Tree node representing a do-while-statement.
 *  Example: \code do a--; while(a>0); \endcode */
class CT_DoStmt : public CT_Statement {
#line 10875 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma9CT_DoStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma9CT_DoStmtE;
private:
#line 4008 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4008 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[7]; // do, stmt, while, open, expr, close, semi_colon

public:
  /** Constructor.
   *  \param d The keyword 'do'.
   *  \param stmt The controlled statement.
   *  \param w The keyword 'while'.
   *  \param o Left parenthesis before the loop condition.
   *  \param e The loop condition.
   *  \param c Right parenthesis behind the loop condition.
   *  \param sc The trailing semi-colon. */
  CT_DoStmt (CTree *d, CTree *stmt, CTree *w, CTree *o, CTree *e, 
             CTree *c, CTree *sc) {
    AddSon (sons[0], d); AddSon (sons[1], stmt); AddSon (sons[2], w); 
    AddSon (sons[3], o); AddSon (sons[4], e); AddSon (sons[5], c); 
    AddSon (sons[6], sc); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 7; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 7, n); }
  /** Get the controlled statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[1]; }
  /** Get the loop condition. */
  CTree *Expr () const { return sons[4]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 7, old_son, new_son);
  }
#line 10921 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4046 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4046 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_ForStmt CTree.h Puma/CTree.h
 *  Tree node representing a for-statement.
 *  Example: \code for(int i=0; i<10; i++) f(i); \endcode */
class CT_ForStmt : public CT_Statement, public CSemScope {
#line 10960 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma10CT_ForStmtE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma10CT_ForStmtE;
private:
#line 4051 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4051 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[8]; // key, open, init, cond, semi_colon, expr, close, stmt

public:
  /** Constructor.
   *  \param k The keyword 'for'.
   *  \param o Left parenthesis.
   *  \param i The loop initializer statement.
   *  \param co The loop condition.
   *  \param sc The semi-colon behind the loop condition.
   *  \param e The loop counter expression.
   *  \param c Right parenthesis.
   *  \param stmt The controlled statement. */
  CT_ForStmt (CTree *k, CTree *o, CTree *i, CTree *co, CTree *sc,
              CTree *e, CTree *c, CTree *stmt) {
    AddSon (sons[0], k); AddSon (sons[1], o); AddSon (sons[2], i); 
    AddSon (sons[3], co); AddSon (sons[4], sc); AddSon (sons[5], e); 
    AddSon (sons[6], c); AddSon (sons[7], stmt); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 8); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 8, n); }
  /** Get the loop initializer. */
  CTree *InitStmt () const { return sons[2]; }
  /** Get the loop condition. */
  CTree *Condition () const { return sons[3]; }
  /** Get the loop counter expression. */
  CTree *Expr () const { return sons[5]; }
  /** Get the controlled statement. */
  CT_Statement *Statement () const { return (CT_Statement*)sons[7]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 8, old_son, new_son);
  }
  /** Get the scope opened by the for-statement. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
#line 11013 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4096 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4096 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_Condition CTree.h Puma/CTree.h
 *  Tree node representing a control-statement condition.
 *  Example: \code int i = 0 \endcode */
#line 11051 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 4101 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4101 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_Condition : public CT_Decl, public CSemObject {
#line 11064 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_ConditionE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_ConditionE;
private:
#line 4101 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4101 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // declspecs, declarator, init

public:
  /** Constructor.
   *  \param dsl The declaration specifier sequence. 
   *  \param d The variable declarator. */
  CT_Condition (CTree *dsl, CTree *d) {
    AddSon (sons[0], dsl); AddSon (sons[1], d); AddSon (sons[2], 0);
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the declaration specifier sequence. */
  CT_DeclSpecSeq *DeclSpecs () const { return (CT_DeclSpecSeq*)sons[0]; }
  /** Get the declarator. */
  CTree *Declarator () const { return sons[1]; }
  /** Get the initializer of the declaration. */
  CT_ExprList *Initializer () const { return (CT_ExprList*)sons[2]; }
  /** Get the semantic information of the declared object. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Set the initializer. */
  void Initializer (CTree *i) { AddSon (sons[2], i); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 11108 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 1 ; }
#line 4137 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 11115 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4137 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4137 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/*****************************************************************************/
/*                                                                           */
/*                              Classes                                      */
/*                                                                           */
/*****************************************************************************/

/** \class CT_ClassDef CTree.h Puma/CTree.h
 *  Tree node representing a class definition.
 *  Example: \code class X : Y { int x; } \endcode */
#line 11159 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
namespace Puma {

#line 4148 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 11169 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 4148 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4148 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_ClassDef : public CT_Decl, public CSemObject {
#line 11182 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_ClassDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_ClassDefE;
private:
#line 4148 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4148 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  
#line 11192 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  struct __ac_wrapper_sons {
    struct __ac_P { typedef Puma::CTree *sons[4]; };
    template <typename T> struct __ac_T {};
    template <typename T, int D> struct __ac_T<T[D]> { typedef T Type; };
    typedef __ac_P::sons __ac_A;
    typedef __ac_T<__ac_P::sons>::Type __ac_E;
    __ac_A _data;
    operator __ac_A& () const { return (__ac_A&)_data; }
    operator const __ac_A& () const { return (const __ac_A&)_data; }
    __ac_A* operator &() { return &_data; }
    const __ac_A * operator &() const { return &_data; }
    operator void* () const { return (void*)&_data; }
    operator const void* () const { return (const void*)&_data; }
    template <typename I> __ac_E& operator [] (I i) { return _data[i]; } // for VC++ 2003
    template <typename I> const __ac_E& operator [] (I i) const { return _data[i]; } // for VC++ 2003
  } sons
#line 4149 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4149 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
; // key, name, bases, members
  CTree *obj_decl;

public:
  /** Constructor.
   *  \param k The keyword 'class' or 'struct'.
   *  \param n The name of the class.
   *  \param b The base class list. */
  
#line 11222 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"


template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma11CT_ClassDefC1EPN4PumaE5CTreePN4PumaE5CTreePN4PumaE5CTree_0 {
  typedef TJP__ZN4Puma11CT_ClassDefC1EPN4PumaE5CTreePN4PumaE5CTreePN4PumaE5CTree_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)33554432;
  struct Res {
    typedef void Type;
    typedef void ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};


#line 4157 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4157 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
CT_ClassDef (CTree *k, CTree *n, CTree *b = (CTree*)0) 
#line 11252 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
{
  typedef TJP__ZN4Puma11CT_ClassDefC1EPN4PumaE5CTreePN4PumaE5CTreePN4PumaE5CTree_0< void, ::Puma::CT_ClassDef, ::Puma::CT_ClassDef, void (Puma::CTree *,Puma::CTree *,Puma::CTree *),  AC::TL< ::Puma::CTree *, AC::TL< ::Puma::CTree *, AC::TL< ::Puma::CTree *, AC::TLE > > > > __TJP;
    __TJP tjp;
  tjp._that =  (__TJP::That*)this;
  this->__exec_old_C1(k, n, b);
  AC::invoke_ExtACTree_ExtACTree__a0_after<__TJP> (&tjp);
  
}
__attribute__((always_inline)) inline void __exec_old_C1(::Puma::CTree *k,::Puma::CTree *n,::Puma::CTree *b)
#line 4157 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4157 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
{
    AddSon (sons[0], k); AddSon (sons[1], n); AddSon (sons[2], b); 
    AddSon (sons[3], 0); AddSon (obj_decl, 0); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 4); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 4, n); }
  /** Get the name of the class. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[1]; }
  /** Get the member declarations list. */
  CT_MembList *Members () const { return (CT_MembList*)sons[3]; }
  /** Get the base class specifiers list. */
  CT_BaseSpecList *BaseClasses () const { return (CT_BaseSpecList*)sons[2]; }
  /** Get the object declaration node containing the class definition. */
  CT_ObjDecl *ObjDecl () const { return (CT_ObjDecl*)obj_decl; }
  /** Get the semantic information about the declared class. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
  /** Set the member declarations list. */
  void Members (CTree *m) { AddSon (sons[3], m); }
  /** Set the base class specifiers list. */
  void BaseClasses (CTree *bc) { AddSon (sons[2], bc); }
  /** Set the object declaration containing the class definition. */
  void ObjDecl (CTree *od) { AddSon (obj_decl, od); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) {
    CTree::ReplaceSon (sons, 4, old_son, new_son);
  }
#line 11301 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma11CT_ClassDefC1ERKN4PumaE11CT_ClassDef_0 {
  typedef TJP__ZN4Puma11CT_ClassDefC1ERKN4PumaE11CT_ClassDef_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)33554432;
  struct Res {
    typedef void Type;
    typedef void ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};


#line 4193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 11327 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

public:
inline CT_ClassDef (const ::Puma::CT_ClassDef& arg0) : Puma::CT_Decl (arg0), Puma::CSemObject (arg0), sons (arg0.sons), obj_decl (arg0.obj_decl), _intro_members (arg0._intro_members), _base_intros (arg0._base_intros), _gnu_suffix (arg0._gnu_suffix), _gnu_prefix (arg0._gnu_prefix), _gnu_infix (arg0._gnu_infix) {
  typedef TJP__ZN4Puma11CT_ClassDefC1ERKN4PumaE11CT_ClassDef_0< void, ::Puma::CT_ClassDef, ::Puma::CT_ClassDef, void,  AC::TL< const ::Puma::CT_ClassDef&, AC::TLE > > __TJP;
  __TJP tjp;
  tjp._that =  (__TJP::That*)this;
  AC::invoke_ExtACTree_ExtACTree__a0_after<__TJP> (&tjp);

}

#line 4193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 11339 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

template <typename TResult, typename TThat, typename TTarget, typename TEntity, typename TArgs> struct TJP__ZN4Puma11CT_ClassDefD1Ev_0 {
  typedef TJP__ZN4Puma11CT_ClassDefD1Ev_0 __TJP;
  typedef TResult Result;
  typedef TThat   That;
  typedef TTarget Target;
  typedef TEntity Entity;
  enum { DIMS = 0 };
  typedef void * MemberPtr;
  enum { ARGS = TArgs::ARGS };
  template <int I> struct Arg : AC::Arg<TArgs, I> {};
  static const AC::JPType JPTYPE = (AC::JPType)67108864;
  struct Res {
    typedef void Type;
    typedef void ReferredType;
  };

  That *_that;

  inline That *that() {return (That*)_that;}

};


#line 4193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 11365 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

public:
inline ~CT_ClassDef () {
  typedef TJP__ZN4Puma11CT_ClassDefD1Ev_0< void, ::Puma::CT_ClassDef, ::Puma::CT_ClassDef, void,  AC::TLE > __TJP;
  __TJP tjp;
  tjp._that =  (__TJP::That*)this;
  AC::invoke_ExtACTree_ExtACTree__a1_before<__TJP> (&tjp);

}

#line 4193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 11379 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: Puma :: CTree * _intro_members ;
Puma :: CTree * _base_intros ;
public :
Puma :: CTree * IntroMembers ( ) const { return _intro_members ; }
void IntroMembers ( Puma :: CTree * members ) { _intro_members = members ; }
Puma :: CTree * BaseIntros ( ) const { return _base_intros ; }
void BaseIntros ( Puma :: CTree * bases ) { _base_intros = bases ; }
#line 4193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 11388 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_suffix ;
public :
CTreeList * gnu_suffix ( ) { return & _gnu_suffix ; }
const CTreeList * gnu_suffix ( ) const { return & _gnu_suffix ; }
#line 4193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 11394 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 4193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 11400 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_infix ;
public :
CTreeList * gnu_infix ( ) { return & _gnu_infix ; }
const CTreeList * gnu_infix ( ) const { return & _gnu_infix ; }
int gnu_infix_pos ( ) const { return 0 ; }
#line 4193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 11407 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4193 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};
      
/** \class CT_UnionDef CTree.h Puma/CTree.h
 *  Tree node representing the definition of a union.
 *  Example: \code union U { int i; } \endcode */
class CT_UnionDef : public CT_ClassDef {
#line 11446 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_UnionDefE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_UnionDefE;
private:
#line 4198 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4198 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param k The keyword 'union'.
   *  \param n The name of the union.
   *  \param b The base union list. */
  CT_UnionDef (CTree *k, CTree *n, CTree *b = 0) : CT_ClassDef (k, n, b) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 11465 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4209 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4209 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};
      
/** \class CT_MembList CTree.h Puma/CTree.h
 *  Tree node representing a member declarations list. */ 
class CT_MembList : public CT_DeclList, public CSemScope {
#line 11503 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_MembListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_MembListE;
private:
#line 4213 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4213 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  CT_MembList (int size = 10, int incr = 10) : 
    CT_DeclList (size, incr) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the scope opened by the member declarations list. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
#line 11521 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4223 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4223 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_MembInitList CTree.h Puma/CTree.h
 *  Tree node representing a constructor initializer list.
 *  Example: \code : Base(), m_Member(0) \endcode */
class CT_MembInitList : public CT_List, public CSemScope {
#line 11560 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15CT_MembInitListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15CT_MembInitListE;
private:
#line 4228 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4228 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size The initial size of the list. */
  CT_MembInitList (int size = 2) : 
    CT_List (size, 2, CT_List::OPEN) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the scope opened by the member initializer list. */
  CSemScope *SemScope () const { return (CSemScope*)this; }
#line 11580 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4240 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4240 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_MembInit CTree.h Puma/CTree.h
 *  Tree node representing a member initializer.
 *  Example: \code m_Member(0) \endcode */
#line 11618 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
namespace Puma {

#line 4245 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 11628 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
namespace Puma {

#line 4245 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4245 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_MembInit : public CT_Expression, public CSemObject {
#line 11641 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_MembInitE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_MembInitE;
private:
#line 4245 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4245 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // name, init

public:
  /** Constructor.
   *  \param n The name of the member.
   *  \param i The member initializer. */
  CT_MembInit (CTree *n, CTree *i) { AddSon (sons[0], n); AddSon (sons[1], i); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  /** Get the name of the member. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[0]; }
  /** Get the initializer. */
  CT_ExprList *Initializer () const { return (CT_ExprList*)sons[1]; }
  /** Get the semantic information about the initialized member. */
  CSemObject *SemObject () const { return (CSemObject*)this; }
#line 11679 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_MembInit CCExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CCSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 4275 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 11683 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: typedef CT_MembInit CExprResolveExpr; public :
virtual Puma :: CTypeInfo * resolve ( Puma :: CSemExpr & sem_expr , Puma :: CTree * base ) ;
#line 4275 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 11687 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4275 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4275 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_BaseSpecList CTree.h Puma/CTree.h
 *  Tree node representing a base specifier list.
 *  Example: \code : X, Y, Z \endcode */
class CT_BaseSpecList : public CT_List {
#line 11726 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15CT_BaseSpecListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15CT_BaseSpecListE;
private:
#line 4280 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4280 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param size The initial size of the list. */
  CT_BaseSpecList (int size = 2) : 
    CT_List (size, 2, CT_List::OPEN|CT_List::SEPARATORS) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 11744 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4290 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4290 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_AccessSpec CTree.h Puma/CTree.h
 *  Tree node representing an access specifier.
 *  Example: \code public: \endcode */
class CT_AccessSpec : public CTree {
#line 11783 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_AccessSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_AccessSpecE;
private:
#line 4295 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4295 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // access, colon

public:
  /** Constructor.
   *  \param a The access specifier, i.e. 'public', 'private', or 'protected'.
   *  \param c The trailing colon. */
  CT_AccessSpec (CTree *a, CTree *c) { AddSon (sons[0], a); AddSon (sons[1], c); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the access specifier type (token type). */
  int Access () const { return sons[0]->token ()->type (); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
#line 11817 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4321 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4321 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_BaseSpec CTree.h Puma/CTree.h
 *  Tree node representing a base class specifier.
 *  Example: \code public X \endcode */
class CT_BaseSpec : public CTree {
#line 11856 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11CT_BaseSpecE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11CT_BaseSpecE;
private:
#line 4326 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4326 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // virtual, access, name

public:
  /** Constructor.
   *  \param v Optional keyword 'virtual'.
   *  \param a The optional access specifier.
   *  \param n The name of the base class. */
  CT_BaseSpec (CTree *v, CTree *a, CTree *n) {
    AddSon (sons[0], v); AddSon (sons[1], a); AddSon (sons[2], n); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Get the type of the access specifier (token type). */
  int Access () const { return sons[1]->token ()->type (); }
  /** The access specifier. */
  CTree *AccessSpec () const { return sons[1]; }
  /** Get the keyword 'virtual'. */
  CTree *Virtual () const { return sons[0]; }
  /** Get the name of the base class. */
  CT_SimpleName *Name () const { return (CT_SimpleName*)sons[2]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 11899 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4361 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4361 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_AccessDecl CTree.h Puma/CTree.h
 *  Tree node representing a member access declaration.
 *  Example: \code m_BaseClassMember; \endcode */
class CT_AccessDecl : public CT_Decl {
#line 11938 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma13CT_AccessDeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma13CT_AccessDeclE;
private:
#line 4366 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4366 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // name, semi_colon

public:
  /** Constructor.
   *  \param n The name of the base class member.
   *  \param s The trailing semi-colon. */
  CT_AccessDecl (CTree *n, CTree *s) { AddSon (sons[0], n); AddSon (sons[1], s); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return 2; }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Get the name of the base class member. */
  CT_QualName *Member () const { return (CT_QualName*)sons[0]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
#line 11972 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4392 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4392 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_UsingDecl CTree.h Puma/CTree.h
 *  Tree node representing a using declaration.
 *  Example: \code using Base::m_Member; \endcode */
#line 12010 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
} // closed Puma

#ifndef __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_guard__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
namespace Puma {

#line 4397 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4397 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
class CT_UsingDecl : public CT_AccessDecl {
#line 12023 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12CT_UsingDeclE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12CT_UsingDeclE;
private:
#line 4397 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4397 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // using, typename

public:
  /** Constructor.
   *  \param u The keyword 'using'.
   *  \param n The name of the entity.
   *  \param s The trailing semi-colon. */
  CT_UsingDecl (CTree *u, CTree *n, CTree *s) : CT_AccessDecl (n, s) {
    AddSon (sons[0], u); AddSon (sons[1], 0); 
  }
  /** Constructor.
   *  \param u The keyword 'using'.
   *  \param t The keyword 'typename'.
   *  \param n The name of the entity.
   *  \param s The trailing semi-colon. */
  CT_UsingDecl (CTree *u, CTree *t, CTree *n, CTree *s) : CT_AccessDecl (n, s) {
    AddSon (sons[0], u); AddSon (sons[1], t); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2) + CT_AccessDecl::Sons (); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const {
    int num = CTree::Sons (sons, 2);
    CTree *result = CTree::Son (sons, 2, n);
    return result ? result : CT_AccessDecl::Son (n-num);
  }
  /** Get the keyword 'typename'. */
  CTree *Typename () const { return sons[1]; }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
    CT_AccessDecl::ReplaceSon (old_son, new_son);
  }
#line 12073 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
  private: CTreeList _gnu_prefix ;
public :
CTreeList * gnu_prefix ( ) { return & _gnu_prefix ; }
const CTreeList * gnu_prefix ( ) const { return & _gnu_prefix ; }
#line 4439 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
#line 12079 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4439 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4439 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/*****************************************************************************/
/*                                                                           */
/*                              Wildcards                                    */
/*                                                                           */
/*****************************************************************************/

/** \class CT_Any CTree.h Puma/CTree.h
 *  Tree node representing a wildcard. */
class CT_Any : public CTree {
#line 12123 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma6CT_AnyE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma6CT_AnyE;
private:
#line 4449 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4449 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[2]; // keyword, extension

public:
  /** Constructor.
   *  \param k The wildcard keyword.
   *  \param e The extension. */
  CT_Any (CTree *k, CTree *e = (CTree*)0) { AddSon (sons[0], k); AddSon (sons[1], e); }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 2); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 2, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 2, old_son, new_son);
  }
  /** Get the type of the wildcard (token type). */
  int AnyType () const { return sons[0]->token ()->type (); }
  /** Get the extension. */
  CT_AnyExtension *Extension () const { return (CT_AnyExtension*)sons[1]; }
#line 12159 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4477 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4477 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_AnyList CTree.h Puma/CTree.h
 *  Tree node representing a list wildcard. */
class CT_AnyList : public CT_Any {
#line 12197 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma10CT_AnyListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma10CT_AnyListE;
private:
#line 4481 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4481 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

public:
  /** Constructor.
   *  \param k The wildcard keyword.
   *  \param e The extension. */
  CT_AnyList (CTree *k, CTree *e = (CTree*)0) : CT_Any (k, e) {}
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
#line 12215 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4491 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4491 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_AnyExtension CTree.h Puma/CTree.h
 *  Tree node representing a wildcard extension. */
class CT_AnyExtension : public CTree, public CSemValue {
#line 12253 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15CT_AnyExtensionE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15CT_AnyExtensionE;
private:
#line 4495 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4495 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[5]; // open, string, comma, cond, close

public:
  /** Constructor.
   *  \param o Left parenthesis before the extension. 
   *  \param n The name of the extension.
   *  \param co The comma between the name and the condition. 
   *  \param c The condition.
   *  \param cr Right parenthesis behind the extension. */
  CT_AnyExtension (CTree *o, CTree *n, CTree *co, CTree *c, CTree *cr) {
    AddSon (sons[0], o); AddSon (sons[1], n); AddSon (sons[2], co); 
    AddSon (sons[3], c); AddSon (sons[4], cr); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 5); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 5, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 5, old_son, new_son);
  }
  /** Get the condition. */
  CTree *Condition () const { return sons[3]; }
  /** Get the name string. */
  CT_Token *String () const { return (CT_Token*)sons[1]; }
  /** Get the extension name. */
  const char *Name () const { return value ? value->StrLiteral ()->String () : (const char*)0; }
  /** Get the value of the extension (the name). */
  CExprValue *Value () const { return value; }
  /** Get the semantic value information object. */
  CSemValue *SemValue () const { return (CSemValue*)this; }
#line 12301 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4535 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4535 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};

/** \class CT_AnyCondition CTree.h Puma/CTree.h
 *  Tree node representing the condition of a wildcard. */
class CT_AnyCondition : public CTree {
#line 12339 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15CT_AnyConditionE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15CT_AnyConditionE;
private:
#line 4539 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4539 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

  CTree *sons[3]; // arg1, arg2, arg3

public:
  /** Constructor.
   *  \param a1 The first argument.
   *  \param a2 The optional second argument.
   *  \param a3 The optional third argument. */
  CT_AnyCondition (CTree *a1, CTree *a2 = (CTree*)0, CTree *a3 = (CTree*)0) {
    AddSon (sons[0], a1); AddSon (sons[1], a2); AddSon (sons[2], a3); 
  }
  /** Get the identifier for this node type. Can be compared with NodeName(). */
  static const char *NodeId ();
  /** Get the name of the node. Can be compared with NodeId(). */
  const char *NodeName () const { return NodeId (); }
  /** Get the number of sons. */
  int Sons () const { return CTree::Sons (sons, 3); }
  /** Get the n-th son.
   *  \param n The index of the son.
   *  \return The n-th son or NULL. */
  CTree *Son (int n) const { return CTree::Son (sons, 3, n); }
  /** Replace a son.
   *  \param old_son The son to replace.
   *  \param new_son The new son. */
  void ReplaceSon (CTree *old_son, CTree *new_son) { 
    CTree::ReplaceSon (sons, 3, old_son, new_son);
  }
#line 12374 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/CTree.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 4566 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"

#line 4566 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/CTree.h"
};


} // namespace Puma

#endif /* __CTree_h__ */

#ifdef __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_CTree_h__
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#include "Puma/CCExprResolveCC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#include "Puma/CExprResolveCC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#include "Puma/SyntaxState.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#include "Puma/CCSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#include "Puma/WinIfExists.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#include "Puma/WinImportHandler.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#include "Puma/WinMacros.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#include "Puma/ExtGnuCInfos.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#include "Puma/ExtGnuCSemantic.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#include "Puma/ExtGnuCSemExpr.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#include "Puma/ExtGnuCSemDeclSpecs.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#include "Puma/PragmaOnce.ah"
#endif
#endif
#undef __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#undef __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_CTree_h__
#endif // __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_CTree_h__

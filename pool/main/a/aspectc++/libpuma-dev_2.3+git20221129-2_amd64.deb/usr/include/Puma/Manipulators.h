#ifndef __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#define __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#define __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_Manipulators_h__
#ifndef __ac_have_predefined_includes__
#define __ac_have_predefined_includes__
#endif // __ac_have_predefined_includes__

#ifndef __ac_h_
#define __ac_h_
#ifdef __cplusplus
namespace AC {
  typedef const char* Type;
  enum JPType { CALL = 262144, EXECUTION = 16777216, CONSTRUCTION = 33554432, DESTRUCTION = 67108864 };
  enum Protection { PROT_NONE, PROT_PRIVATE, PROT_PROTECTED, PROT_PUBLIC };
  enum Specifiers { SPEC_NONE = 0x0 , SPEC_STATIC = 0x1, SPEC_MUTABLE = 0x2, SPEC_VIRTUAL = 0x4 };
  struct Action {
    void **_args; void *_result; void *_entity; void *_target; void *_that; void *_fptr;
    void (*_wrapper)(Action &);
    inline void trigger () { _wrapper (*this); }
  };
  template <typename T> struct ResultBuffer {
    char _data[sizeof (T)];
    void operator = (const T& t) { *this = (const ResultBuffer &)t; }
  };
  template <typename T, typename N> struct TL {
    typedef T type; typedef N next; enum { ARGS = next::ARGS + 1 };
  };
  struct TLE { enum { ARGS = 0 }; };
  template <typename T> struct Referred { typedef T type; };
  template <typename T> struct Referred<T &> { typedef T type; };
  template <typename TL, int I> struct Arg {
    typedef typename Arg<typename TL::next, I - 1>::Type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename TL> struct Arg<TL, 0> {
    typedef typename TL::type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename T> int ttest(...);
  template <typename T> char ttest(typename T::__TI const volatile *);
  template<typename T> struct HasTypeInfo {
    enum { RET=((sizeof(ttest<T>(0))==1)?1:0) };
  };
  template<typename T, int HAVE = HasTypeInfo<T>::RET> struct TypeInfo {
    enum { AVAILABLE = 0, BASECLASSES = 0, MEMBERS = 0, FUNCTIONS = 0,
           CONSTRUCTORS = 0, DESTRUCTORS = 0 };
    typedef T That;
  };
  template<typename T> struct TypeInfo<T, 1> : T::__TI {
    enum { AVAILABLE = 1 };
  };
  template<typename T> struct RT {};
  template<typename T> RT<T> rt_deduce (const T&) { return RT<T>(); }
  template<typename T> RT<T> rt_deduce (const volatile T&) { return RT<T>(); }
  struct Cnv { template<typename T> operator RT<T>() const { return RT<T>(); }};
  #define __AC_TYPEOF(expr) (1?AC::Cnv():AC::rt_deduce(expr))
  template <class Aspect, int Index>
  struct CFlow {
    static int &instance () {
      static int counter = 0;
      return counter;
    }
    CFlow () { instance ()++; }
    ~CFlow () { instance ()--; }
    static bool active () { return instance () > 0; }
  };
}
#endif // __cplusplus
#endif // __ac_h_
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACTree;
class ExtGnu;
class ExtGnuCTree;
class ExtGnuKeywords;
class PragmaOnceUnitState;
class PragmaOnce;
#endif // __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
// This file is part of PUMA.
// Copyright (C) 1999-2003  The PUMA developer team.
//                                                                
// This program is free software;  you can redistribute it and/or 
// modify it under the terms of the GNU General Public License as 
// published by the Free Software Foundation; either version 2 of 
// the License, or (at your option) any later version.            
//                                                                
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
// GNU General Public License for more details.                   
//                                                                
// You should have received a copy of the GNU General Public      
// License along with this program; if not, write to the Free     
// Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
// MA  02111-1307  USA                                            

#ifndef __puma_manipulator_classes__
#define __puma_manipulator_classes__

// Puma manipulator classes.
//
// ManipError..................Error reporting class for manipulators.
// Manipulator.................Abstract base class for manipulators.
// ManipulatorSequence.........A sequence of manipulator objects.
//
// CopyManipulator.............Copy one or more tokens into buffer.
// CutManipulator..............Remove one or more tokens and copy in buffer.
// KillManipulator.............Remove one or more tokens permanently.
// PasteManipulator............Insert a list of tokens at given position.
// PasteBeforeManipulator......Insert a list of tokens before given position.
// MoveManipulator.............Shift a list of tokens at given position.
// MoveBeforeManipulator.......Shift a list of tokens before given position.
//
// CKillManipulator..........Remove all tokens of a tree permanently.
// CCopyManipulator..........Copy a tree after the last token of a 2nd tree.
// CCopyBeforeManipulator....Copy a tree before the first token of a 2nd tree.
// CMoveManipulator..........Move a tree after the last token of a 2nd tree.
// CMoveBeforeManipulator....Move a tree before the first token of a 2nd tree.
// CReplaceManipulator.......Replace a tree with an other tree.
// CSwapManipulator..........Swap two trees.

#include "Puma/Unit.h"
#include "Puma/List.h"
#include "Puma/CTree.h"
#include "Puma/Array.h"
#include "Puma/Token.h"
#include "Puma/Printable.h"
#include "Puma/RuleTable.h"

namespace Puma {


// Manipulator error structure. 

class Manipulator;

class ManipError : public Printable {
#line 158 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma10ManipErrorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma10ManipErrorE;
private:
#line 59 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 59 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  int                 _errorno;        // The error number. See below.
  Manipulator *_faulty;                // The faulty manipulator.

public:
  enum {
    UNBALANCED = -3,        // Unbalanced preprocessor directives found.
    MACRO_GEN,                // Wanted to manipulate macro generated tokens.
    BAD_ARG,                // Bad arguments has been given to manipulator.
    FATAL,                // Fatal errors, like NULL pointer buffer.
    OK                        // Everything seems to be correct.
  };
    
  ManipError () : _faulty(0) {}

  // Get ...
  int                 errorno () const  { return _errorno; }
  Manipulator *faulty ()  const  { return _faulty; }
  // An error is true if there really was an error.
  operator bool () const         { return _errorno != OK; }
        
  // Set ...
  void errorno  (int number)       { _errorno = number; }
  void faulty (Manipulator *manip) { _faulty  = manip; }

  // Print ...
  void print (std::ostream &os) const;

  // There has to be a first arg ...
  Location location ();
#line 196 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 89 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 89 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};
 

// Enum for checks which should NOT be performed on a Manipulator
enum ManipIgnoreMask { MIM_NONE = 0, MIM_UNBALANCED = 1, MIM_MACRO = 2 };


enum ManipMode {
  MM_NO_MACRO_MANIP, // Macro-generated tokens are not transformed unless they are at the end/begin of an
                     // expansion. In this case the token is replace by the macro call end/begin.
  MM_EXPAND_MACROS   // Macros are expanded on demand.
};


// Abstract base class for manipulator classes.

class Manipulator : public ListElement {
#line 246 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11ManipulatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11ManipulatorE;
private:
#line 105 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 105 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"


  ManipIgnoreMask _ignore;
  
protected:        
  Manipulator () : _ignore (MIM_NONE) {}

  int valid (Token *, Token *, ManipMode) const;

public:
  // Manipulator identifiers used to identify a manipulator typ.
  static const char *copy_op;
  static const char *cut_op;
  static const char *paste_op; 
  static const char *paste_before_op; 
  static const char *move_op; 
  static const char *move_before_op; 
  static const char *kill_op;
  static const char *cpp_copy_op; 
  static const char *cpp_copy_before_op; 
  static const char *cpp_kill_op; 
  static const char *cpp_move_op; 
  static const char *cpp_move_before_op;
  static const char *sequence_op;
  static const char *cpp_replace_op;
  static const char *cpp_swap_op;

  virtual ~Manipulator () {}

  virtual ManipError valid (ManipMode) const = 0;
  virtual void manipulate ()              = 0;
        
  virtual Array<Token*> &args ()     = 0;
  virtual void args (Array<Token*>&) = 0;
        
  virtual const char *op () const   = 0;
  virtual ListElement *duplicate () = 0;
  
  // set/get the ignore mask
  void ignore_mask (ManipIgnoreMask mim) { _ignore = mim; }
  ManipIgnoreMask ignore_mask () const { return _ignore; }
#line 295 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 146 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 146 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};
 

// Special manipulator class that manages a sequence of
// manipulator commands.

class ManipulatorSequence : public Manipulator, public List {
#line 335 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma19ManipulatorSequenceE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma19ManipulatorSequenceE;
private:
#line 152 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 152 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  RuleTable     _rules;
  Array<Token*> _empty;        // Not really used.
        
  void checkArgs (ManipError&, Manipulator*);

public:
  ManipulatorSequence () {}
        
  Array<Token*> &args () { return _empty; }
  void args (Array<Token*> &empty) {}

  const char *op () const { return sequence_op; }
  ListElement *duplicate ();

  ManipError valid (ManipMode mode) const;
  void manipulate ();
        
  void append (Manipulator *manip)
    { List::append (*manip); }
#line 363 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 172 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 172 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};

 
// The `copy' manipulator.

class CopyManipulator : public Manipulator {
#line 402 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15CopyManipulatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15CopyManipulatorE;
private:
#line 177 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 177 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  Token *_from;
  Token *_to;
  Unit * _buffer;
  Array<Token*> _arguments;
        
public:
  CopyManipulator (Unit *buffer, Token *from, Token *to = (Token*) 0);
  ~CopyManipulator () {}
                
  const char *op () const { return copy_op; }
  ListElement *duplicate () 
    { return new CopyManipulator (_buffer, _from, _to); }

  Array<Token*> &args () { return _arguments; }
  void args (Array<Token*>&);

  ManipError valid (ManipMode) const;
  void manipulate ();
        
  void manipulate (Unit *buffer, Token *from, Token *to = (Token*) 0)
    { _buffer = buffer; _from = from; _to = to; manipulate (); }
#line 432 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 199 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 199 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};


// The `cut' manipulator.

class CutManipulator : public Manipulator {
#line 471 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14CutManipulatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14CutManipulatorE;
private:
#line 204 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 204 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  Token *_from;
  Token *_to;
  Unit * _buffer;
  Array<Token*> _arguments;
        
public:
  CutManipulator (Unit *buffer, Token *from, Token *to = (Token*) 0);
  ~CutManipulator () {}

  const char *op () const { return cut_op; }
  ListElement *duplicate () 
    { return new CutManipulator (_buffer, _from, _to); }
                
  Array<Token*> &args () { return _arguments; }
  void args (Array<Token*>&);
                
  ManipError valid (ManipMode) const;
  void manipulate ();
        
  void manipulate (Unit *buffer, Token *from, Token *to = (Token*) 0)
    { _buffer = buffer; _from = from; _to = to; manipulate (); }
#line 501 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 226 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 226 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};


// The `kill' manipulator.

class KillManipulator : public Manipulator {
#line 540 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15KillManipulatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15KillManipulatorE;
private:
#line 231 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 231 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  Token *_from;
  Token *_to;
  Array<Token*> _arguments;
        
public:
  KillManipulator (Token *from, Token *to = (Token*) 0);
  ~KillManipulator () {}

  const char *op () const { return kill_op; }
  ListElement *duplicate () 
    { return new KillManipulator (_from, _to); }
                
  Array<Token*> &args () { return _arguments; }
  void args (Array<Token*>&);
                
  ManipError valid (ManipMode) const;
  void manipulate ();
        
  void manipulate (Token *from, Token *to = (Token*) 0)
    { _from = from; _to = to; manipulate (); }
#line 569 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 252 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 252 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};


// The `paste' manipulator.

class PasteManipulator : public Manipulator {
#line 608 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16PasteManipulatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16PasteManipulatorE;
private:
#line 257 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 257 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  Token *_at;
  Unit * _buffer;
  Array<Token*> _arguments;
        
public:
  PasteManipulator (Unit *buffer, Token *at);
  ~PasteManipulator () {}

  const char *op () const { return paste_op; }
  ListElement *duplicate () 
    { return new PasteManipulator (_buffer, _at); }
                
  Array<Token*> &args () { return _arguments; }
  void args (Array<Token*>&);
                
  ManipError valid (ManipMode) const;
  void manipulate ();
        
  void manipulate (Unit *buffer, Token *at)
    { _buffer = buffer; _at = at; manipulate (); }
#line 637 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 278 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 278 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};


// The `paste_before' manipulator.

class PasteBeforeManipulator : public Manipulator {
#line 676 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma22PasteBeforeManipulatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma22PasteBeforeManipulatorE;
private:
#line 283 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 283 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  Token *_at;
  Unit * _buffer;
  Array<Token*> _arguments;
        
public:
  PasteBeforeManipulator (Unit *buffer, Token *at);
  ~PasteBeforeManipulator () {}
                
  const char *op () const { return paste_before_op; }
  ListElement *duplicate () 
    { return new PasteBeforeManipulator (_buffer, _at); }

  Array<Token*> &args () { return _arguments; }
  void args (Array<Token*>&);
                
  ManipError valid (ManipMode) const;
  void manipulate ();
        
  void manipulate (Unit *buffer, Token *at)
    { _buffer = buffer; _at = at; manipulate (); }
#line 705 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 304 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 304 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};


// The `move' manipulator.

class MoveManipulator : public Manipulator {
#line 744 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma15MoveManipulatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma15MoveManipulatorE;
private:
#line 309 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 309 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  Token *_at;
  Unit * _buffer;
  Array<Token*> _arguments;
        
public:
  MoveManipulator (Unit *buffer, Token *at);
  ~MoveManipulator () {}

  const char *op () const { return move_op; }
  ListElement *duplicate () 
    { return new MoveManipulator (_buffer, _at); }
                
  Array<Token*> &args () { return _arguments; }
  void args (Array<Token*>&);
                
  ManipError valid (ManipMode) const;
  void manipulate ();
        
  void manipulate (Unit *buffer, Token *at)
    { _buffer = buffer; _at = at; manipulate (); }
#line 773 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 330 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 330 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};


// The `move_before' manipulator.

class MoveBeforeManipulator : public Manipulator {
#line 812 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma21MoveBeforeManipulatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma21MoveBeforeManipulatorE;
private:
#line 335 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 335 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  Token *_at;
  Unit * _buffer;
  Array<Token*> _arguments;
        
public:
  MoveBeforeManipulator (Unit *buffer, Token *at);
  ~MoveBeforeManipulator () {}
                
  const char *op () const { return move_before_op; }
  ListElement *duplicate () 
    { return new MoveBeforeManipulator (_buffer, _at); }

  Array<Token*> &args () { return _arguments; }
  void args (Array<Token*>&);
                
  ManipError valid (ManipMode) const;
  void manipulate ();
        
  void manipulate (Unit *buffer, Token *at)
    { _buffer = buffer; _at = at; manipulate (); }
#line 841 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 356 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 356 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};


// The C++ syntax tree `kill' manipulator.

class CKillManipulator : public Manipulator {
#line 880 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16CKillManipulatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16CKillManipulatorE;
private:
#line 361 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 361 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  Token *_from;
  Token *_to;
  Array<Token*> _arguments;
        
public:
  CKillManipulator (CTree *what);
  CKillManipulator (Token*, Token*);
  ~CKillManipulator () {}

  const char *op () const { return cpp_kill_op; }
  ListElement *duplicate () 
    { return new CKillManipulator (_from, _to); }
                
  Array<Token*> &args () { return _arguments; }
  void args (Array<Token*>&);
                
  ManipError valid (ManipMode) const;
  void manipulate ();
        
  void manipulate (CTree *what)
    { _from = what ? what->token () : (Token*) 0; 
      _to   = what ? what->end_token () : (Token*) 0; 
      manipulate (); }
#line 912 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 385 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 385 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};


// The C++ syntax tree `copy' manipulator.

class CCopyManipulator : public Manipulator {
#line 951 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16CCopyManipulatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16CCopyManipulatorE;
private:
#line 390 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 390 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  Token *_from_from;
  Token *_from_to;
  Token *_to;
  Array<Token*> _arguments;

public:
  CCopyManipulator (CTree *from, CTree *to);
  CCopyManipulator (Token*, Token*, Token*);
  ~CCopyManipulator () {}

  const char *op () const { return cpp_copy_op; }
  ListElement *duplicate ()
    { return new CCopyManipulator (_from_from, _from_to, _to); }
                
  Array<Token*> &args () { return _arguments; }
  void args (Array<Token*>&);
                
  ManipError valid (ManipMode) const;
  void manipulate ();
        
  void manipulate (CTree *from, CTree *to)
    { _from_from = from ? from->token () : (Token*) 0; 
      _from_to   = from ? from->end_token () : (Token*) 0;
      _to        = to ? to->end_token () : (Token*) 0;
      manipulate (); }
              
  void manipulate (Token *from, Token *to, Token *at)
    { _from_from = from; _from_to = to; _to = at; manipulate (); }
#line 988 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 419 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 419 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};


// The C++ syntax tree `copy_before' manipulator.

class CCopyBeforeManipulator : public Manipulator {
#line 1027 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma22CCopyBeforeManipulatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma22CCopyBeforeManipulatorE;
private:
#line 424 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 424 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  Token *_from_from;
  Token *_from_to;
  Token *_to;
  Array<Token*> _arguments;
        
public:
  CCopyBeforeManipulator (CTree *from, CTree *to);
  CCopyBeforeManipulator (Token*, Token*, Token*);
  ~CCopyBeforeManipulator () {}

  const char *op () const { return cpp_copy_before_op; }
  ListElement *duplicate ()
    { return new CCopyBeforeManipulator (_from_from, _from_to, _to); }
                
  Array<Token*> &args () { return _arguments; }
  void args (Array<Token*>&);
                
  ManipError valid (ManipMode) const;
  void manipulate ();
        
  void manipulate (CTree *from, CTree *to)
    { _from_from = from ? from->token () : (Token*) 0; 
      _from_to   = from ? from->end_token () : (Token*) 0;
      _to        = to ? to->token () : (Token*) 0;
      manipulate (); }

  void manipulate (Token *from, Token *to, Token *at)
    { _from_from = from; _from_to = to; _to = at; manipulate (); }
#line 1064 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 453 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 453 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};


// The C++ syntax tree `move' manipulator.

class CMoveManipulator : public Manipulator {
#line 1103 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16CMoveManipulatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16CMoveManipulatorE;
private:
#line 458 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 458 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  Token *_from_from;
  Token *_from_to;
  Token *_to;
  Array<Token*> _arguments;
        
public:
  CMoveManipulator (CTree *from, CTree *to);
  CMoveManipulator (Token*, Token*, Token*);
  ~CMoveManipulator () {}

  const char *op () const { return cpp_move_op; }
  ListElement *duplicate ()
    { return new CMoveManipulator (_from_from, _from_to, _to); }
                
  Array<Token*> &args () { return _arguments; }
  void args (Array<Token*>&);
                
  ManipError valid (ManipMode) const;
  void manipulate ();
        
  void manipulate (CTree *from, CTree *to)
    { _from_from = from ? from->token () : (Token*) 0; 
      _from_to   = from ? from->end_token () : (Token*) 0;
      _to        = to ? to->end_token () : (Token*) 0;
      manipulate (); }

  void manipulate (Token *from, Token *to, Token *at)
    { _from_from = from; _from_to = to; _to = at; manipulate (); }
#line 1140 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 487 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 487 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};


// The C++ syntax tree `move_before' manipulator.

class CMoveBeforeManipulator : public Manipulator {
#line 1179 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma22CMoveBeforeManipulatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma22CMoveBeforeManipulatorE;
private:
#line 492 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 492 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  Token *_from_from;
  Token *_from_to;
  Token *_to;
  Array<Token*> _arguments;

public:
  CMoveBeforeManipulator (CTree *from, CTree *to);
  CMoveBeforeManipulator (Token*, Token*, Token*);
  ~CMoveBeforeManipulator () {}

  const char *op () const { return cpp_move_before_op; }
  ListElement *duplicate ()
    { return new CMoveBeforeManipulator (_from_from, _from_to, _to); }
                
  Array<Token*> &args () { return _arguments; }
  void args (Array<Token*>&);
                
  ManipError valid (ManipMode) const;
  void manipulate ();
        
  void manipulate (CTree *from, CTree *to)
    { _from_from = from ? from->token () : (Token*) 0; 
      _from_to   = from ? from->end_token () : (Token*) 0;
      _to        = to ? to->token () : (Token*) 0;
      manipulate (); }

  void manipulate (Token *from, Token *to, Token *at)
    { _from_from = from; _from_to = to; _to = at; manipulate (); } 
#line 1216 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 521 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 521 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};


// The C++ syntax tree `replace' manipulator.

class CReplaceManipulator : public Manipulator {
#line 1255 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma19CReplaceManipulatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma19CReplaceManipulatorE;
private:
#line 526 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 526 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  Token *_what_from;
  Token *_what_to;
  Token *_with_from;
  Token *_with_to;
  Array<Token*> _arguments;
        
public:
  CReplaceManipulator (CTree *what, CTree *with);
  CReplaceManipulator (Token*, Token*, Token*, Token*);
  ~CReplaceManipulator () {}

  const char *op () const { return cpp_replace_op; }
  ListElement *duplicate ()
    { return new CReplaceManipulator (_what_from, _what_to, 
                                                _with_from, _with_to); }
                
  Array<Token*> &args () { return _arguments; }
  void args (Array<Token*>&);
                
  ManipError valid (ManipMode) const;
  void manipulate ();
        
  void manipulate (CTree *what, CTree *with)
    { _what_from = what ? what->token () : (Token*) 0; 
      _what_to   = what ? what->end_token () : (Token*) 0;
      _with_from = with ? with->token () : (Token*) 0; 
      _with_to   = with ? with->end_token () : (Token*) 0;
      manipulate (); }

  void manipulate (Token *wf, Token *wt, Token *tf, Token *tt)
    { _what_from = wf; _what_to = wt; _with_from = tf;
      _with_to = tt; manipulate (); }
#line 1296 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 559 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 559 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};


// The C++ syntax tree `swap' manipulator.

class CSwapManipulator : public Manipulator {
#line 1335 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16CSwapManipulatorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16CSwapManipulatorE;
private:
#line 564 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 564 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

  Token *_what_from;
  Token *_what_to;
  Token *_with_from;
  Token *_with_to;
  Array<Token*> _arguments;
        
public:
  CSwapManipulator (CTree *what, CTree *with);
  CSwapManipulator (Token*, Token*, Token*, Token*);
  ~CSwapManipulator () {}

  const char *op () const { return cpp_swap_op; }
  ListElement *duplicate ()
    { return new CSwapManipulator (_what_from, _what_to, 
                                   _with_from, _with_to); }
                
  Array<Token*> &args () { return _arguments; }
  void args (Array<Token*>&);
                
  ManipError valid (ManipMode) const;
  void manipulate ();
        
  void manipulate (CTree *what, CTree *with)
    { _what_from = what ? what->token () : (Token*) 0; 
      _what_to   = what ? what->end_token () : (Token*) 0;
      _with_from = with ? with->token () : (Token*) 0; 
      _with_to   = with ? with->end_token () : (Token*) 0;
      manipulate (); }

  void manipulate (Token *wf, Token *wt, Token *tf, Token *tt)
    { _what_from = wf; _what_to = wt; _with_from = tf;
      _with_to = tt; manipulate (); }
#line 1376 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Manipulators.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 597 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"

#line 597 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Manipulators.h"
};


} // namespace Puma

#endif /* __puma_manipulator_classes__ */

#ifdef __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_Manipulators_h__
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#include "Puma/CCExprResolveCC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#include "Puma/CExprResolveCC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#include "Puma/SyntaxState.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#include "Puma/CCSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#include "Puma/WinIfExists.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#include "Puma/WinImportHandler.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#include "Puma/WinMacros.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#include "Puma/ExtGnuCInfos.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#include "Puma/ExtGnuCSemantic.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#include "Puma/ExtGnuCSemExpr.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#include "Puma/ExtGnuCSemDeclSpecs.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#include "Puma/PragmaOnce.ah"
#endif
#endif
#undef __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#undef __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_Manipulators_h__
#endif // __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_Manipulators_h__

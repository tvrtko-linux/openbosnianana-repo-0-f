#ifndef __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#define __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#define __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_PreTreeNodes_h__
#ifndef __ac_have_predefined_includes__
#define __ac_have_predefined_includes__
#endif // __ac_have_predefined_includes__

#ifndef __ac_h_
#define __ac_h_
#ifdef __cplusplus
namespace AC {
  typedef const char* Type;
  enum JPType { CALL = 262144, EXECUTION = 16777216, CONSTRUCTION = 33554432, DESTRUCTION = 67108864 };
  enum Protection { PROT_NONE, PROT_PRIVATE, PROT_PROTECTED, PROT_PUBLIC };
  enum Specifiers { SPEC_NONE = 0x0 , SPEC_STATIC = 0x1, SPEC_MUTABLE = 0x2, SPEC_VIRTUAL = 0x4 };
  struct Action {
    void **_args; void *_result; void *_entity; void *_target; void *_that; void *_fptr;
    void (*_wrapper)(Action &);
    inline void trigger () { _wrapper (*this); }
  };
  template <typename T> struct ResultBuffer {
    char _data[sizeof (T)];
    void operator = (const T& t) { *this = (const ResultBuffer &)t; }
  };
  template <typename T, typename N> struct TL {
    typedef T type; typedef N next; enum { ARGS = next::ARGS + 1 };
  };
  struct TLE { enum { ARGS = 0 }; };
  template <typename T> struct Referred { typedef T type; };
  template <typename T> struct Referred<T &> { typedef T type; };
  template <typename TL, int I> struct Arg {
    typedef typename Arg<typename TL::next, I - 1>::Type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename TL> struct Arg<TL, 0> {
    typedef typename TL::type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename T> int ttest(...);
  template <typename T> char ttest(typename T::__TI const volatile *);
  template<typename T> struct HasTypeInfo {
    enum { RET=((sizeof(ttest<T>(0))==1)?1:0) };
  };
  template<typename T, int HAVE = HasTypeInfo<T>::RET> struct TypeInfo {
    enum { AVAILABLE = 0, BASECLASSES = 0, MEMBERS = 0, FUNCTIONS = 0,
           CONSTRUCTORS = 0, DESTRUCTORS = 0 };
    typedef T That;
  };
  template<typename T> struct TypeInfo<T, 1> : T::__TI {
    enum { AVAILABLE = 1 };
  };
  template<typename T> struct RT {};
  template<typename T> RT<T> rt_deduce (const T&) { return RT<T>(); }
  template<typename T> RT<T> rt_deduce (const volatile T&) { return RT<T>(); }
  struct Cnv { template<typename T> operator RT<T>() const { return RT<T>(); }};
  #define __AC_TYPEOF(expr) (1?AC::Cnv():AC::rt_deduce(expr))
  template <class Aspect, int Index>
  struct CFlow {
    static int &instance () {
      static int counter = 0;
      return counter;
    }
    CFlow () { instance ()++; }
    ~CFlow () { instance ()--; }
    static bool active () { return instance () > 0; }
  };
}
#endif // __cplusplus
#endif // __ac_h_
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACTree;
class ExtGnu;
class ExtGnuCTree;
class ExtGnuKeywords;
class PragmaOnceUnitState;
class PragmaOnce;
#endif // __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
// This file is part of PUMA.
// Copyright (C) 1999-2003  The PUMA developer team.
//                                                                
// This program is free software;  you can redistribute it and/or 
// modify it under the terms of the GNU General Public License as 
// published by the Free Software Foundation; either version 2 of 
// the License, or (at your option) any later version.            
//                                                                
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
// GNU General Public License for more details.                   
//                                                                
// You should have received a copy of the GNU General Public      
// License along with this program; if not, write to the Free     
// Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
// MA  02111-1307  USA                                            

#ifndef __pre_syntax_tree_nodes__
#define __pre_syntax_tree_nodes__

/** \file 
 *  Preprocessor syntax tree classes. */

#include "Puma/Unit.h"
#include "Puma/PreVisitor.h"
#include "Puma/PreTreeToken.h"
#include "Puma/PreTreeComposite.h"

namespace Puma {


/** \class PreProgram PreTreeNodes.h Puma/PreTreeNodes.h
 *  The root node of the preprocessor syntax tree. */
class PreProgram : public PreTreeComposite {
#line 134 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma10PreProgramE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma10PreProgramE;
private:
#line 35 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 35 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor.
   *  \param g The group of preprocessor directives. */
  PreProgram (PreTree* g) : PreTreeComposite (1, 0) { 
    add_son (g); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor &v) {
    v.visitPreProgram_Pre (this);
    v.iterateNodes (this);
    v.visitPreProgram_Post (this);
  }            
#line 159 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 52 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 52 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreDirectiveGroups PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing the directive groups in the program. */
class PreDirectiveGroups : public PreTreeComposite {
#line 198 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma18PreDirectiveGroupsE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma18PreDirectiveGroupsE;
private:
#line 57 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 57 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. */
  PreDirectiveGroups () : PreTreeComposite (-1, 0) {}

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreDirectiveGroups_Pre (this);
    v.iterateNodes (this);
    v.visitPreDirectiveGroups_Post (this);
  }            
#line 220 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 71 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 71 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreConditionalGroup PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing a group of conditional directives. 
 *  Example: \code #if ... #elif ... #else ... #endif \endcode */
class PreConditionalGroup : public PreTreeComposite {
#line 260 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma19PreConditionalGroupE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma19PreConditionalGroupE;
private:
#line 77 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 77 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param i The \#if part.
   *  \param dg The directive group.
   *  \param ei The \#endif part. */
  PreConditionalGroup (PreTree* i, PreTree* dg, PreTree* ei) : PreTreeComposite (3, 0) { 
    add_son (i); add_son (dg); add_son (ei); 
  }
  /** Constructor. 
   *  \param i The \#if part.
   *  \param e The \#elif or \#else part.
   *  \param dg The directive group.
   *  \param ei The \#endif part. */
  PreConditionalGroup (PreTree* i, PreTree* e, PreTree* dg, PreTree* ei) : PreTreeComposite (4, 0) { 
    add_son (i); add_son (e); add_son (dg); add_son (ei); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreConditionalGroup_Pre (this);
    v.iterateNodes (this);
    v.visitPreConditionalGroup_Post (this);
  }
#line 295 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 104 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 104 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreElsePart PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing a group of directives 
 *  in the \#else part of an \#if conditional. */
class PreElsePart : public PreTreeComposite {
#line 335 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11PreElsePartE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11PreElsePartE;
private:
#line 110 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 110 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param dg The directive group.
   *  \param el The \#else directive. */
  PreElsePart (PreTree* dg, PreTree* el) : PreTreeComposite (2, 0) { 
    add_son (dg); add_son (el); 
  }
  /** Constructor. 
   *  \param ei The preceding \#elif part.
   *  \param dg The directive group.
   *  \param el The \#else directive. */
  PreElsePart (PreTree* ei, PreTree* dg, PreTree* el) : PreTreeComposite (3, 0) { 
    add_son (ei); add_son (dg); add_son (el); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreElsePart_Pre (this);
    v.iterateNodes (this);
    v.visitPreElsePart_Post (this);
  }
#line 368 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 135 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 135 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreElifPart PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing a group of directives 
 *  in the \#elif part of an \#if conditional. */
class PreElifPart : public PreTreeComposite {
#line 408 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11PreElifPartE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11PreElifPartE;
private:
#line 141 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 141 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. */
  PreElifPart () : PreTreeComposite (-1, 0) {}
        
  /** Add two sons, a directive group and a \#elif directive.
   *  \param dg The directive group.
   *  \param el The \#elif directive. */
  void addSons (PreTree* dg, PreTree* el) { 
    add_son (dg); add_son (el); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreElifPart_Pre (this);
    v.iterateNodes (this);
    v.visitPreElifPart_Post (this);
  }
#line 437 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 162 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 162 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreIfDirective PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing an \#if directive. 
 *  Example: \code #if OSTYPE==Linux \endcode */
class PreIfDirective : public PreTreeComposite {
#line 477 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14PreIfDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14PreIfDirectiveE;
private:
#line 168 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 168 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor.
   *  \param i The \#if token.
   *  \param c The condition. */
  PreIfDirective (PreTree* i, PreTree* c) : PreTreeComposite (2, 1) { 
    add_son (i); add_son (c); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreIfDirective_Pre (this);
    v.iterateNodes (this);
    v.visitPreIfDirective_Post (this);
  }
#line 503 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 186 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 186 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreIfdefDirective PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing an \#ifdef directive. 
 *  Example: \code #ifdef Linux \endcode */
class PreIfdefDirective : public PreTreeComposite {
#line 543 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma17PreIfdefDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma17PreIfdefDirectiveE;
private:
#line 192 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 192 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param i The \#ifdef token.
   *  \param n The name of the macro. 
   *  \param tl The remaining tokens of the line. */
  PreIfdefDirective (PreTree* i, PreTree* n, PreTree* tl) : PreTreeComposite (3, 1) { 
    add_son (i); add_son (n); add_son (tl); 
  }
  /** Constructor. 
   *  \param i The \#ifdef token.
   *  \param tl The remaining tokens of the line. */
  PreIfdefDirective (PreTree* i, PreTree* tl) : PreTreeComposite (2, 0) { 
    add_son (i); add_son (tl); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreIfdefDirective_Pre (this);
    v.iterateNodes (this);
    v.visitPreIfdefDirective_Post (this);
  }
#line 576 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 217 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 217 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreIfndefDirective PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing an \#ifndef directive. 
 *  Example: \code #ifndef Linux \endcode */
class PreIfndefDirective : public PreTreeComposite {
#line 616 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma18PreIfndefDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma18PreIfndefDirectiveE;
private:
#line 223 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 223 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param i The \#ifndef token.
   *  \param n The name of the macro. 
   *  \param tl The remaining tokens of the line. */
  PreIfndefDirective (PreTree* i, PreTree* n, PreTree* tl) : PreTreeComposite (3, 1) { 
    add_son (i); add_son (n); add_son (tl); 
  }
  /** Constructor. 
   *  \param i The \#ifndef token.
   *  \param tl The remaining tokens of the line. */
  PreIfndefDirective (PreTree* i, PreTree* tl) : PreTreeComposite (2, 0) { 
    add_son (i); add_son (tl); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreIfndefDirective_Pre (this);
    v.iterateNodes (this);
    v.visitPreIfndefDirective_Post (this);
  }
#line 649 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 248 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 248 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreElifDirective PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing an \#elif directive. 
 *  Example: \code #elif OSTYPE==linux \endcode */
class PreElifDirective : public PreTreeComposite {
#line 689 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16PreElifDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16PreElifDirectiveE;
private:
#line 254 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 254 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param e The \#elif token.
   *  \param c The condition. */
  PreElifDirective (PreTree* e, PreTree* c) : PreTreeComposite (2, 1) { 
    add_son (e); add_son (c); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreElifDirective_Pre (this);
    v.iterateNodes (this);
    v.visitPreElifDirective_Post (this);
  }
#line 715 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 272 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 272 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreElseDirective PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing an \#else directive. 
 *  Example: \code #else \endcode */
class PreElseDirective : public PreTreeComposite {
#line 755 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16PreElseDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16PreElseDirectiveE;
private:
#line 278 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 278 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param e The \#else token.
   *  \param tl The remaining tokens of the line. */
  PreElseDirective (PreTree* e, PreTree* tl) : PreTreeComposite (2, 0) { 
    add_son (e); add_son (tl); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreElseDirective_Pre (this);
    v.iterateNodes (this);
    v.visitPreElseDirective_Post (this);
  }
#line 781 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 296 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 296 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreEndifDirective PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing an \#endif directive. 
 *  Example: \code #endif \endcode */
class PreEndifDirective : public PreTreeComposite {
#line 821 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma17PreEndifDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma17PreEndifDirectiveE;
private:
#line 302 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 302 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param e The \#endif token.
   *  \param tl The remaining tokens of the line. */
  PreEndifDirective (PreTree* e, PreTree* tl) : PreTreeComposite (2, 0) { 
    add_son (e); add_son (tl); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreEndifDirective_Pre (this);
    v.iterateNodes (this);
    v.visitPreEndifDirective_Post (this);
  }
#line 847 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 320 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 320 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreIncludeDirective PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing an \#include or \#include_next directive. 
 *  Example: \code #include <stdio.h> \endcode */
class PreIncludeDirective : public PreTreeComposite {
#line 887 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma19PreIncludeDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma19PreIncludeDirectiveE;
private:
#line 326 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 326 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

  int _depth; // depth of nested includes

public:
  /** Constructor. 
   *  \param i The \#include or \#include_next token. 
   *  \param tl The remaining tokens of the line containing the file to include. */
  PreIncludeDirective (PreTree* i, PreTree* tl) : PreTreeComposite (2, 1) { 
    add_son (i); add_son (tl); 
    _depth = -1; 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreIncludeDirective_Pre (this);
    v.iterateNodes (this);
    v.visitPreIncludeDirective_Post (this);
  }
        
  /** Get the depth of nested inclusion. 
   *  \return The depth or -1 for a top-level include. */
  int depth () const {
    return _depth;
  }
  /** Set the depth of nested inclusion. 
   *  \param d The depth of inclusion. */
  void depth (int d) {
    _depth = d;
  }
        
  /** Check if this is a forced include (given by command line). */
  bool is_forced () const {
    return !((Unit*)startToken ()->belonging_to ())->isFile ();
  }
#line 932 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 363 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 363 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreAssertDirective PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing an \#assert directive. 
 *  Example: \code #assert OSTYPE (linux) \endcode */
class PreAssertDirective : public PreTreeComposite {
#line 972 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma18PreAssertDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma18PreAssertDirectiveE;
private:
#line 369 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 369 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param a The \#assert token.
   *  \param p The predicate name.
   *  \param an The answer to the predicate. */
  PreAssertDirective (PreTree* a, PreTree* p, PreTree* an) : PreTreeComposite (3, 0) { 
    add_son (a); add_son (p); add_son (an); 
  }
  /** Constructor. 
   *  \param a The \#assert token.
   *  \param tl The remaining tokens of the line. */
  PreAssertDirective (PreTree* a, PreTree* tl) : PreTreeComposite (2, 0) { 
    add_son (a); add_son (tl); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreAssertDirective_Pre (this);
    v.iterateNodes (this);
    v.visitPreAssertDirective_Post (this);
  }
#line 1005 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 394 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 394 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreUnassertDirective PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing an \#unassert directive. 
 *  Example: \code #unassert OSTYPE \endcode */
class PreUnassertDirective : public PreTreeComposite {
#line 1045 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma20PreUnassertDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma20PreUnassertDirectiveE;
private:
#line 400 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 400 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param ua The \#unassert token. 
   *  \param n The name of the predicate.
   *  \param tl The remaining tokens of the line. */
  PreUnassertDirective (PreTree* ua, PreTree* n, PreTree* tl) : PreTreeComposite (3, 0) { 
    add_son (ua); add_son (n); add_son (tl); 
  }
  /** Constructor. 
   *  \param ua The \#unassert token. 
   *  \param tl The remaining tokens of the line. */
  PreUnassertDirective (PreTree* ua, PreTree* tl) : PreTreeComposite (2, 0) { 
    add_son (ua); add_son (tl); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreUnassertDirective_Pre (this);
    v.iterateNodes (this);
    v.visitPreUnassertDirective_Post (this);
  }
#line 1078 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 425 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreDefineFunctionDirective PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing a \#define directive for function-like macros. 
 *  Example: \code #define MUL(a,b) (a * b) \endcode */
class PreDefineFunctionDirective : public PreTreeComposite {
#line 1118 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma26PreDefineFunctionDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma26PreDefineFunctionDirectiveE;
private:
#line 431 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 431 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param a The \#define token.
   *  \param b The macro name.
   *  \param c Left parenthesis before the parameter list.
   *  \param d The macro parameter list. 
   *  \param e Comma before the last parameter.
   *  \param f The token '...'.
   *  \param g Right parenthesis behind the parameter list.
   *  \param h The macro body. */
  PreDefineFunctionDirective (PreTree* a, PreTree* b, PreTree* c, PreTree* d, 
   PreTree* e, PreTree* f, PreTree* g, PreTree* h) : PreTreeComposite (8, 0) { 
    add_son (a); add_son (b); add_son (c); add_son (d);
    add_son (e); add_son (f); add_son (g); add_son (h); 
  }

  /** Constructor. 
   *  \param a The \#define token.
   *  \param b The macro name.
   *  \param c Left parenthesis before the parameter list.
   *  \param d The macro parameter list. 
   *  \param e The token '...'.
   *  \param f Right parenthesis behind the parameter list.
   *  \param g The macro body. */
  PreDefineFunctionDirective (PreTree* a, PreTree* b, PreTree* c, PreTree* d, 
   PreTree* e, PreTree* f, PreTree* g) : PreTreeComposite (7, 0) { 
    add_son (a); add_son (b); add_son (c); add_son (d);
    add_son (e); add_son (f); add_son (g); 
  }

  /** Constructor. 
   *  \param a The \#define token.
   *  \param b The macro name.
   *  \param c Left parenthesis before the parameter list.
   *  \param d The macro parameter list. 
   *  \param e Right parenthesis behind the parameter list.
   *  \param f The macro body. */
  PreDefineFunctionDirective (PreTree* a, PreTree* b, PreTree* c, PreTree* d, 
   PreTree* e, PreTree* f) : PreTreeComposite (6, 0) { 
    add_son (a); add_son (b); add_son (c); 
    add_son (d); add_son (e); add_son (f); 
  }
        
  /** Constructor. 
   *  \param a The \#define token.
   *  \param b The macro name.
   *  \param c Left parenthesis before the parameter list.
   *  \param d Right parenthesis behind the parameter list.
   *  \param e The macro body. */
  PreDefineFunctionDirective (PreTree* a, PreTree* b, PreTree* c, 
   PreTree* d, PreTree* e) : PreTreeComposite (5, 0) { 
    add_son (a); add_son (b); add_son (c); add_son (d); add_son (e); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreDefineFunctionDirective_Pre (this);
    v.iterateNodes (this);
    v.visitPreDefineFunctionDirective_Post (this);
  }
#line 1190 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 495 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 495 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};   


/** \class PreDefineConstantDirective PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing a \#define directive for constants. 
 *  Example: \code #define CONSTANT 1 \endcode */
class PreDefineConstantDirective : public PreTreeComposite {
#line 1230 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma26PreDefineConstantDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma26PreDefineConstantDirectiveE;
private:
#line 501 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 501 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param d The \#define token.
   *  \param n The name of the constant.
   *  \param v The constant value. */
  PreDefineConstantDirective (PreTree* d, PreTree* n, PreTree* v) : PreTreeComposite (3, 0) { 
    add_son (d); add_son (n); add_son (v); 
  }
  /** Constructor. 
   *  \param d The \#define token.
   *  \param tl The remaining tokens of the line. */
  PreDefineConstantDirective (PreTree* d, PreTree* tl) : PreTreeComposite (2, 0) { 
    add_son (d); add_son (tl); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreDefineConstantDirective_Pre (this);
    v.iterateNodes (this);
    v.visitPreDefineConstantDirective_Post (this);
  }
#line 1263 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 526 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 526 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreUndefDirective PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing an \#undef directive. 
 *  Example: \code #undef MACRO \endcode */
class PreUndefDirective : public PreTreeComposite {
#line 1303 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma17PreUndefDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma17PreUndefDirectiveE;
private:
#line 532 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 532 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param u The \#undef token. 
   *  \param m The name of the macro to undefine. 
   *  \param tl The remaining tokens of the line. */
  PreUndefDirective (PreTree* u, PreTree* m, PreTree* tl) : PreTreeComposite (3, 0) { 
    add_son (u); add_son (m); add_son (tl); 
  }
  /** Constructor. 
   *  \param u The \#undef token.
   *  \param tl The remaining tokens of the line. */
  PreUndefDirective (PreTree* u, PreTree* tl) : PreTreeComposite (2, 0) { 
    add_son (u); add_son (tl); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreUndefDirective_Pre (this);
    v.iterateNodes (this);
    v.visitPreUndefDirective_Post (this);
  }
#line 1336 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 557 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 557 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreWarningDirective PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing a \#warning directive. 
 *  Example: \code #warning This is a warning. \endcode */
class PreWarningDirective : public PreTreeComposite {
#line 1376 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma19PreWarningDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma19PreWarningDirectiveE;
private:
#line 563 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 563 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param w The \#warning token. 
   *  \param m The warning message. */
  PreWarningDirective (PreTree* w, PreTree* m) : PreTreeComposite (2, 0) { 
    add_son (w); add_son (m); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreWarningDirective_Pre (this);
    v.iterateNodes (this);
    v.visitPreWarningDirective_Post (this);
  }
#line 1402 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 581 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 581 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreErrorDirective PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing an \#error directive. 
 *  Example: \code #error This is an error. \endcode */
class PreErrorDirective : public PreTreeComposite {
#line 1442 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma17PreErrorDirectiveE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma17PreErrorDirectiveE;
private:
#line 587 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 587 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param e The \#error token.
   *  \param m The error message. */
  PreErrorDirective (PreTree* e, PreTree* m) : PreTreeComposite (2, 0) { 
    add_son (e); add_son (m); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreErrorDirective_Pre (this);
    v.iterateNodes (this);
    v.visitPreErrorDirective_Post (this);
  }
#line 1468 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 605 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 605 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreIdentifierList PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing the identifier list of a 
 *  function-like macro definition. 
 *  Example: \code a,b,c \endcode */
class PreIdentifierList : public PreTreeComposite {
#line 1509 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma17PreIdentifierListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma17PreIdentifierListE;
private:
#line 612 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 612 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param id An identifier. */
  PreIdentifierList (PreTree* id) : PreTreeComposite (-1, 0) { 
    add_son (id); 
  }
        
  /** Add two sons, a comma and an identifier.
   *  \param c A comma.
   *  \param id An identifier. */
  void addSons (PreTree* c, PreTree* id) { 
    add_son (c); add_son (id); 
  }

  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreIdentifierList_Pre (this);
    v.iterateNodes (this);
    v.visitPreIdentifierList_Post (this);
  }
#line 1541 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 636 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 636 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};


/** \class PreTokenList PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing the token list of a macro body. */
class PreTokenList : public PreTreeComposite {
#line 1580 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma12PreTokenListE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma12PreTokenListE;
private:
#line 641 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 641 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. */
  PreTokenList () : PreTreeComposite (0, 0) {}
  /** Constructor. 
   *  \param tl The token list. 
   *  \param nl The newline token. */
  PreTokenList (PreTree* tl, PreTree* nl) : PreTreeComposite (2, 0) { 
    add_son (tl); add_son (nl); 
  }
  /** Constructor. 
   *  \param tl The token list. */
  PreTokenList (PreTree* tl) : PreTreeComposite (1, 0) { 
    add_son (tl); 
  }
        
  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreTokenList_Pre (this);
    v.iterateNodes (this);
    v.visitPreTokenList_Post (this);
  }
#line 1613 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 666 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 666 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreTokenListPart PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing a part of the token list of a macro body. */
class PreTokenListPart : public PreTreeComposite {
#line 1652 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma16PreTokenListPartE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma16PreTokenListPartE;
private:
#line 671 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 671 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. 
   *  \param tl The token list. */
  PreTokenListPart (PreTree* tl) : PreTreeComposite (-1, 0) { 
    add_son (tl); 
  }
        
  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreTokenListPart_Pre (this);
    v.iterateNodes (this);
    v.visitPreTokenListPart_Post (this);
  }
#line 1677 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 688 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 688 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreCondSemNode PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor semantic tree node for conditions. */
class PreCondSemNode : public PreTree {
#line 1716 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14PreCondSemNodeE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14PreCondSemNodeE;
private:
#line 693 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 693 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

  // The calculated value of the condition.
  bool _value;

public:
  /** Constructor. 
   *  \param value The calculated value of the condition. */
  PreCondSemNode (bool value) : _value (value) {}
        
  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreCondSemNode (this);
  }
        
  /** Get the calculated value of the condition. */
  bool value () const { return _value; }
#line 1743 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 712 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 712 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreInclSemNode PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor semantic tree node for the \#include directive
 *  containing the unit to include. */
class PreInclSemNode : public PreTree {
#line 1783 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma14PreInclSemNodeE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma14PreInclSemNodeE;
private:
#line 718 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 718 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

  // Pointer to the included file unit.
  Unit* _unit;
        
  // True if the inclusion was not done, because of an active include guard.
  bool _guarded;

public:
  /** Constructor. 
   *  \param unit The unit containing the tokens of the include file.
   *  \param guarded True if the inclusion was not done due to an include guard. */
  PreInclSemNode (Unit* unit, bool guarded) :
    _unit (unit), _guarded (guarded) {}
        
  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreInclSemNode (this);
  }
        
  /** Get the token unit of the included file. */
  Unit* unit () const { return _unit; }
        
  /** Check if the inclusion was not done due to an include guard. */
  bool guarded () const { return _guarded; }
#line 1818 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 745 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 745 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


/** \class PreError PreTreeNodes.h Puma/PreTreeNodes.h
 *  Preprocessor tree node representing a parse error. */
class PreError : public PreTree {
#line 1857 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma8PreErrorE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma8PreErrorE;
private:
#line 750 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 750 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

public:
  /** Constructor. */
  PreError () {}
        
  /** Part of the tree visitor pattern. Calls the node
   *  visiting functions suitable for this node type. 
   *  \param v The visitor object on which to call the 
   *           visiting functions. */
  void accept (PreVisitor& v) {
    v.visitPreError (this);
  }
#line 1877 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/PreTreeNodes.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 762 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"

#line 762 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/PreTreeNodes.h"
};      


} // namespace Puma

#endif /* __pre_syntax_tree_nodes__ */

#ifdef __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_PreTreeNodes_h__
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#include "Puma/CCExprResolveCC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#include "Puma/CExprResolveCC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#include "Puma/SyntaxState.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#include "Puma/CCSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#include "Puma/WinIfExists.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#include "Puma/WinImportHandler.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#include "Puma/WinMacros.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#include "Puma/ExtGnuCInfos.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#include "Puma/ExtGnuCSemantic.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#include "Puma/ExtGnuCSemExpr.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#include "Puma/ExtGnuCSemDeclSpecs.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#include "Puma/PragmaOnce.ah"
#endif
#endif
#undef __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#undef __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_PreTreeNodes_h__
#endif // __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_PreTreeNodes_h__

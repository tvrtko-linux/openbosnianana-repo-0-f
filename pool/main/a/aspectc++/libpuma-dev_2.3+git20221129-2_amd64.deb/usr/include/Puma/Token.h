#ifndef __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#define __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#define __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_Token_h__
#ifndef __ac_have_predefined_includes__
#define __ac_have_predefined_includes__
#endif // __ac_have_predefined_includes__

#ifndef __ac_h_
#define __ac_h_
#ifdef __cplusplus
namespace AC {
  typedef const char* Type;
  enum JPType { CALL = 262144, EXECUTION = 16777216, CONSTRUCTION = 33554432, DESTRUCTION = 67108864 };
  enum Protection { PROT_NONE, PROT_PRIVATE, PROT_PROTECTED, PROT_PUBLIC };
  enum Specifiers { SPEC_NONE = 0x0 , SPEC_STATIC = 0x1, SPEC_MUTABLE = 0x2, SPEC_VIRTUAL = 0x4 };
  struct Action {
    void **_args; void *_result; void *_entity; void *_target; void *_that; void *_fptr;
    void (*_wrapper)(Action &);
    inline void trigger () { _wrapper (*this); }
  };
  template <typename T> struct ResultBuffer {
    char _data[sizeof (T)];
    void operator = (const T& t) { *this = (const ResultBuffer &)t; }
  };
  template <typename T, typename N> struct TL {
    typedef T type; typedef N next; enum { ARGS = next::ARGS + 1 };
  };
  struct TLE { enum { ARGS = 0 }; };
  template <typename T> struct Referred { typedef T type; };
  template <typename T> struct Referred<T &> { typedef T type; };
  template <typename TL, int I> struct Arg {
    typedef typename Arg<typename TL::next, I - 1>::Type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename TL> struct Arg<TL, 0> {
    typedef typename TL::type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename T> int ttest(...);
  template <typename T> char ttest(typename T::__TI const volatile *);
  template<typename T> struct HasTypeInfo {
    enum { RET=((sizeof(ttest<T>(0))==1)?1:0) };
  };
  template<typename T, int HAVE = HasTypeInfo<T>::RET> struct TypeInfo {
    enum { AVAILABLE = 0, BASECLASSES = 0, MEMBERS = 0, FUNCTIONS = 0,
           CONSTRUCTORS = 0, DESTRUCTORS = 0 };
    typedef T That;
  };
  template<typename T> struct TypeInfo<T, 1> : T::__TI {
    enum { AVAILABLE = 1 };
  };
  template<typename T> struct RT {};
  template<typename T> RT<T> rt_deduce (const T&) { return RT<T>(); }
  template<typename T> RT<T> rt_deduce (const volatile T&) { return RT<T>(); }
  struct Cnv { template<typename T> operator RT<T>() const { return RT<T>(); }};
  #define __AC_TYPEOF(expr) (1?AC::Cnv():AC::rt_deduce(expr))
  template <class Aspect, int Index>
  struct CFlow {
    static int &instance () {
      static int counter = 0;
      return counter;
    }
    CFlow () { instance ()++; }
    ~CFlow () { instance ()--; }
    static bool active () { return instance () > 0; }
  };
}
#endif // __cplusplus
#endif // __ac_h_
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACTree;
class ExtGnu;
class ExtGnuCTree;
class ExtGnuKeywords;
class PragmaOnceUnitState;
class PragmaOnce;
#endif // __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
// This file is part of PUMA.
// Copyright (C) 1999-2015  The PUMA developer team.
//                                                                
// This program is free software;  you can redistribute it and/or 
// modify it under the terms of the GNU General Public License as 
// published by the Free Software Foundation; either version 2 of 
// the License, or (at your option) any later version.            
//                                                                
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
// GNU General Public License for more details.                   
//                                                                
// You should have received a copy of the GNU General Public      
// License along with this program; if not, write to the Free     
// Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
// MA  02111-1307  USA                                            

#ifndef PUMA_Token_H
#define PUMA_Token_H

/** \file
 * Token abstraction. */

#include "Puma/LanguageID.h"
#include "Puma/Location.h"
#include "Puma/Printable.h"
#include "Puma/ListElement.h"
#include "Puma/Array.h"
#include "Puma/DString.h"

namespace Puma {

class Unit;

/** \class Token Token.h Puma/Token.h
 * Abstraction of a lexical token. A token is created by a
 * scanner (see Puma::CScanner). It is part a token chain
 * (see Puma::Unit) and encapsulates a lexical unit of the
 * scanned text.
 *
 * The information provided about a lexical unit is:
 * - token type
 * - location in the scanned text
 * - portion of the scanned text represented by this token
 * - language of the token
 *  
 * \ingroup common */
class Token : public ListElement {
#line 148 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Token.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma5TokenE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma5TokenE;
private:
#line 49 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Token.h"

#line 49 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Token.h"

  int m_type;
  int m_realType;

  Location m_location;
  LanguageID m_language;

  const char *m_text;
  mutable DString m_dictText;

  Array<int> *m_continuousLines;

  enum TK_Flags {
    TK_COMMENT = (0x01 << 0),
    TK_CORE = (0x01 << 1),
    TK_MACRO_CALL = (0x01 << 2)
  };
  unsigned short m_flags;

public:
  /** Special token types. */
  enum {
    /** End-of-file token. */
    ID_END_OF_FILE = -1,
    /** Unknown token type. */
    ID_UNKNOWN = -2,
    /** Error token type. */
    ID_ERROR = -3,
    /** Warning token type. */
    ID_WARNING = -4
  };

  /** Comment tokens. */
  static LanguageID comment_id;
  /** Preprocessor tokens. */
  static LanguageID pre_id;
  /** Compiler directives. */
  static LanguageID dir_id;
  /** C/C++ core language tokens. */
  static LanguageID cpp_id;
  /** White-spaces. */
  static LanguageID white_id;
  /** Wildcards. */
  static LanguageID wildcard_id;
  /** Keywords. */
  static LanguageID keyword_id;
  /** Left parenthesis. */
  static LanguageID open_id;
  /** Function-like macro operands. */
  static LanguageID macro_op_id;
  /** Identifiers. */
  static LanguageID identifier_id;
  /** Comma. */
  static LanguageID comma_id;
  /** Right parenthesis. */
  static LanguageID close_id;

public:
  /** Constructor.
   *  \param type The token type.
   *  \param lang The language of the token.
   *  \param text The optional token text (defaults to the empty string). */
  Token(int type = 0, LanguageID lang = LanguageID(0), const char *text = "");
  /** Copy-constructor. 
   *  \param copy The token to copy. */
  Token(const Token &copy);
  /** Destructor. Frees the token text. */
  virtual ~Token();

  /** Print the token text on the given stream. 
   *  \param os The output stream. */
  void print(std::ostream &os) const;
  /** Duplicate this token.
   *  \return A copy of this token. Has to be destroyed by the caller. */
  virtual ListElement *duplicate() {
    return new Token(*this);
  }

  /** Get the unit this token belongs to.
   * \return A pointer to the unit. */
  Unit* unit() const;

  /** Reset the token object optionally providing new content.
   *  \param type The new token type.
   *  \param text The new token text.
   *  \param lang The new token language. */
  void reset(int type = 0, const char *text = 0, LanguageID lang = LanguageID(0));

  /** Set the location of the token (usually the line and column in a file). 
   *  \param loc The location. */
  void location(const Location &loc) {
    m_location = loc;
  }

  /** Set the continuous lines appeared in this token.
   *  \param lines The continuous line array. */
  void cont_lines(Array<int> *lines) {
    m_continuousLines = lines;
  }

  /** Count the number of line breaks in the text of this token.
   * \return The number of line breaks found. */
  int line_breaks() const;

  /** Set the token to be a macro call.
   * \param is_call Is a macro call or not. */
  void macro_call(bool is_call = true);

  /** Get the token text.
   * \return The constant token text. */
  const char *text() const;

  /** Get the token text from the global dictionary.
   * \return A reference to the global dictionary managed version of the token text. */
  DString &dtext() const;

  /** Get the static token text. Only for keywords, operators, and other tokens
   * with a constant token text.
   * \return The static text, or NULL for tokens with dynamic text (like identifiers). */
  char *get_static_text() const;

  /** Get the static token text for the given token type. Only for keywords,
   * operators, and other tokens with a constant token text.
   * \param token_type The token type.
   * \return The static text, or NULL for tokens with dynamic text (like identifiers). */
  static char *get_static_text(int token_type);

  /** Get the type of the token (see Puma::CTokens).
   * \return The numerical value of the token type. */
  int type() const {
    return m_type;
  }

  /** Get the location of the token (usually the line and column in a file).
   * \return A reference to the token location. */
  const Location &location() const {
    return m_location;
  }

  /** Check if the token is macro generated.
   * \return True if macro generated. */
  bool is_macro_generated() const;
  /** Check if the token is a macro call.
   * \return True if it is a macro call. */
  bool is_macro_call() const {
    return (m_flags & TK_MACRO_CALL) != 0;
  }
  /** Check if this is a core language token.
   * \return True if this is core language token. */
  bool is_core() const;
  /** Check if the token is an identifier. Subset of core tokens.
   * \return True if this is an identifier. */
  bool is_identifier() const;
  /** Check if the token is a keyword. Subset of identifiers.
   * \return True if this is a keyword. */
  bool is_keyword() const;
  /** Check if this is a comma. Subset of core tokens.
   * \return True if this is a comma. */
  bool is_comma() const;
  /** Check if this is a left parenthesis. Subset of core tokens.
   * \return True if this is a left parenthesis. */
  bool is_open() const;
  /** Check if this is a right parenthesis. Subset of core tokens.
   * \return True if this is a right parenthesis. */
  bool is_close() const;
  /** Check if this is a white-space token.
   * \return True if this is a white space. */
  bool is_whitespace() const;
  /** Check if this is a comment.
   * \return True if this is a comment token. */
  bool is_comment() const;
  /** Check if this is a preprocessor token.
   * \return True if this is a preprocessor token. */
  bool is_preprocessor() const;
  /** Check if this is function-like macro operand.
   * \return True if this is an operand of a function-like macro. */
  bool is_macro_op() const;
  /** Check if this is a compiler directive token.
   * \return True if this is compiler directive token. */
  bool is_directive() const;
  /** Check if this is a wildcard token. Subset of core tokens.
   * \return True if this is a wildcard token. */
  bool is_wildcard() const;

  /** Overwrite operator new for better performance. Tokens are allocated
   * very often. To reduce the overhead of allocating a lot of small portions
   * of memory, this implementation reuses already allocated memory
   * by using a constant size memory pool (see Puma::ConstSizeMemPool).
   * \param size The size of the memory to allocate in byte.
   * \return A pointer to the allocated memory. */
  void *operator new(size_t size);
  /** Free the memory allowed with the Token's own operator new. The memory is
   * not freed but kept back for reuse.
   * \param ptr A pointer to the memory to free. */
  void operator delete(void *ptr);

private:
  int get_general_type() const;
  LanguageID language() const {
    return m_language;
  }
  void determine_is_comment();
  void determine_is_core();
#line 359 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/Token.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 252 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Token.h"

#line 252 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/Token.h"
};

inline void Token::macro_call(bool is_call) {
  if (is_call)
    m_flags |= TK_MACRO_CALL;
  else
    m_flags &= ~TK_MACRO_CALL;
}

inline void Token::determine_is_core() {
  if (m_language == cpp_id || m_language == wildcard_id || m_language == open_id || m_language == comma_id || m_language == close_id || is_identifier())
    m_flags |= TK_CORE;
}
inline void Token::determine_is_comment() {
  if (m_language == comment_id)
    m_flags |= TK_COMMENT;
}

inline bool Token::is_core() const {
  return (m_flags & TK_CORE) != 0;
}
inline bool Token::is_identifier() const {
  return m_language == identifier_id || is_keyword();
}
inline bool Token::is_keyword() const {
  return m_language == keyword_id;
}
inline bool Token::is_wildcard() const {
  return m_language == wildcard_id;
}
inline bool Token::is_preprocessor() const {
  return m_language == pre_id;
}
inline bool Token::is_directive() const {
  return m_language == dir_id;
}
inline bool Token::is_whitespace() const {
  return m_language == white_id;
}
inline bool Token::is_comment() const {
  return (m_flags & TK_COMMENT) != 0;
}
inline bool Token::is_macro_op() const {
  return m_language == macro_op_id;
}
inline bool Token::is_open() const {
  return m_language == open_id;
}
inline bool Token::is_comma() const {
  return m_language == comma_id;
}
inline bool Token::is_close() const {
  return m_language == close_id;
}

inline std::ostream &operator <<(std::ostream &os, const Token &object) {
  object.print(os);
  return os;
}

} // namespace Puma

#endif /* PUMA_Token_H */

#ifdef __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_Token_h__
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#include "Puma/CCExprResolveCC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#include "Puma/CExprResolveCC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#include "Puma/SyntaxState.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#include "Puma/CCSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#include "Puma/WinIfExists.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#include "Puma/WinImportHandler.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#include "Puma/WinMacros.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#include "Puma/ExtGnuCInfos.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#include "Puma/ExtGnuCSemantic.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#include "Puma/ExtGnuCSemExpr.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#include "Puma/ExtGnuCSemDeclSpecs.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#include "Puma/PragmaOnce.ah"
#endif
#endif
#undef __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#undef __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_Token_h__
#endif // __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_Token_h__

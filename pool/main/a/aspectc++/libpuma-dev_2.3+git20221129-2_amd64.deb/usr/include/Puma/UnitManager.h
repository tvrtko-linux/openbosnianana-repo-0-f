#ifndef __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#define __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#define __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_UnitManager_h__
#ifndef __ac_have_predefined_includes__
#define __ac_have_predefined_includes__
#endif // __ac_have_predefined_includes__

#ifndef __ac_h_
#define __ac_h_
#ifdef __cplusplus
namespace AC {
  typedef const char* Type;
  enum JPType { CALL = 262144, EXECUTION = 16777216, CONSTRUCTION = 33554432, DESTRUCTION = 67108864 };
  enum Protection { PROT_NONE, PROT_PRIVATE, PROT_PROTECTED, PROT_PUBLIC };
  enum Specifiers { SPEC_NONE = 0x0 , SPEC_STATIC = 0x1, SPEC_MUTABLE = 0x2, SPEC_VIRTUAL = 0x4 };
  struct Action {
    void **_args; void *_result; void *_entity; void *_target; void *_that; void *_fptr;
    void (*_wrapper)(Action &);
    inline void trigger () { _wrapper (*this); }
  };
  template <typename T> struct ResultBuffer {
    char _data[sizeof (T)];
    void operator = (const T& t) { *this = (const ResultBuffer &)t; }
  };
  template <typename T, typename N> struct TL {
    typedef T type; typedef N next; enum { ARGS = next::ARGS + 1 };
  };
  struct TLE { enum { ARGS = 0 }; };
  template <typename T> struct Referred { typedef T type; };
  template <typename T> struct Referred<T &> { typedef T type; };
  template <typename TL, int I> struct Arg {
    typedef typename Arg<typename TL::next, I - 1>::Type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename TL> struct Arg<TL, 0> {
    typedef typename TL::type Type;
    typedef typename Referred<Type>::type ReferredType;
  };
  template <typename T> int ttest(...);
  template <typename T> char ttest(typename T::__TI const volatile *);
  template<typename T> struct HasTypeInfo {
    enum { RET=((sizeof(ttest<T>(0))==1)?1:0) };
  };
  template<typename T, int HAVE = HasTypeInfo<T>::RET> struct TypeInfo {
    enum { AVAILABLE = 0, BASECLASSES = 0, MEMBERS = 0, FUNCTIONS = 0,
           CONSTRUCTORS = 0, DESTRUCTORS = 0 };
    typedef T That;
  };
  template<typename T> struct TypeInfo<T, 1> : T::__TI {
    enum { AVAILABLE = 1 };
  };
  template<typename T> struct RT {};
  template<typename T> RT<T> rt_deduce (const T&) { return RT<T>(); }
  template<typename T> RT<T> rt_deduce (const volatile T&) { return RT<T>(); }
  struct Cnv { template<typename T> operator RT<T>() const { return RT<T>(); }};
  #define __AC_TYPEOF(expr) (1?AC::Cnv():AC::rt_deduce(expr))
  template <class Aspect, int Index>
  struct CFlow {
    static int &instance () {
      static int counter = 0;
      return counter;
    }
    CFlow () { instance ()++; }
    ~CFlow () { instance ()--; }
    static bool active () { return instance () > 0; }
  };
}
#endif // __cplusplus
#endif // __ac_h_
class CCExprResolve;
class CExprResolve;
class SyntaxState;
class SyntaxBuilder;
class LookAhead;
class CBuilderExtension;
class CLookAhead;
class CSemBinding;
class CCBuilderExtension;
class CCLookAhead;
class CCSemBinding;
class WinIfExists;
class WinImportHandler;
class WinMacros;
class WinAsm;
class WinDeclSpecs;
class WinMemberExplSpec;
class WinTypeKeywords;
class WinFriend;
class WinKeywords;
class ExtAC;
class ExtACTree;
class ExtGnu;
class ExtGnuCTree;
class ExtGnuKeywords;
class PragmaOnceUnitState;
class PragmaOnce;
#endif // __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#line 99 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/UnitManager.h"

#ifndef __ac_fwd_PragmaOnceUnitState__
#define __ac_fwd_PragmaOnceUnitState__
class PragmaOnceUnitState;
namespace AC {
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_PragmaOnceUnitState_PragmaOnceUnitState__a0_after (JoinPoint *tjp);
  template <class JoinPoint>
  __attribute((always_inline)) inline void invoke_PragmaOnceUnitState_PragmaOnceUnitState__a1_after (JoinPoint *tjp);
}
#endif

#ifndef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#endif

#line 1 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/UnitManager.h"

#line 1 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/UnitManager.h"
// This file is part of PUMA.
// Copyright (C) 1999-2016  The PUMA developer team.
//                                                                
// This program is free software;  you can redistribute it and/or 
// modify it under the terms of the GNU General Public License as 
// published by the Free Software Foundation; either version 2 of 
// the License, or (at your option) any later version.            
//                                                                
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
// GNU General Public License for more details.                   
//                                                                
// You should have received a copy of the GNU General Public      
// License along with this program; if not, write to the Free     
// Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
// MA  02111-1307  USA                                            

#ifndef PUMA_UnitManager_H
#define PUMA_UnitManager_H

/** \file
 * Token unit management. */

#include <iostream>
#include <list>
#include <map>
#include <string>
#include "Puma/ErrorStream.h"

namespace Puma {

class Unit;
class Source;
class Tokenizer;

/** \class UnitManager UnitManager.h Puma/UnitManager.h
 * Class to manage the units built to parse the files of
 * the source project.
 * \ingroup common */
class UnitManager {
#line 160 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/UnitManager.h"
public:
  template <typename, int = 0> struct __BYPASS_ZN4Puma11UnitManagerE {};
  template <typename, int> friend struct __BYPASS_ZN4Puma11UnitManagerE;
private:
#line 41 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/UnitManager.h"

#line 41 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/UnitManager.h"

public:
  /** Name to unit map type. */
  typedef std::map<std::string, Unit*> UMap;
  /** Name to unit map entry type. */
  typedef UMap::value_type UMapEntry;
  /** Name to unit map iterator type. */
  typedef UMap::iterator UMapIter;

private:
  ErrorStream *_err;
  std::list<Unit*> _nonames;
  mutable UMap _umap;
  Tokenizer *_tokenizer;

public:
  /** Constructor.
   * \param err Error stream to use for reporting errors. */
  UnitManager(ErrorStream &err)
      : _err(&err), _tokenizer(0) {
  }
  /** Destructor. Deletes all managed units. */
  virtual ~UnitManager();

  /** Get the unit management table.
   * \return A reference to the unit table. */
  UMap &getTable() const {
    return _umap;
  }

  /** Get the tokenizer (scanner) that is used by scanSource()
   * to tokenize sources.
   * \return A pointer to the tokenizer used. */
  Tokenizer *tokenizer() const {
    return _tokenizer;
  }
  /** Set the tokenizer (scanner) to be used by scanSource()
   * to tokenize sources.
   * \param tokenizer The tokenizer to use. */
  void tokenizer(Tokenizer *tokenizer) {
    _tokenizer = tokenizer;
  }

  /** Add a token unit to the manager.
   * \param unit The unit to add. */
  void add(Unit *unit);

  /** Get a managed unit by name.
   * \param name The name of the unit to get.
   * \param isfile True to indicate that the given name refers to a file (defaults to false).
   * \return A pointer to the unit. */
  Unit *get(const char *name, bool isfile = false) const;

  /** Discard a unit managed by this unit manager.
   * \param name The name of the unit to remove.
   * \param isfile True to indicate that the given name refers to a file (defaults to false).
   * \param destroy True to indicate that the unit shall be destroyed (defaults to true). */
  void discard(const char *name, bool isfile = false, bool destroy = true) const;

  /** Discard all named units managed by this unit manager.
   * \param destroy True to indicate that the units shall be destroyed (defaults to true). */
  void discardAll(bool destroy = true) const;

  /** Discard all no-name units managed by this unit manager. */
  void discardNonames();

  /** Scan the tokens from the given input source and create a unit from it.
   * The new unit is added to the unit manager.
   * \param name The name of the unit to create.
   * \param in The input source.
   * \param isfile True to indicate that the given name refers to a file (defaults to false).
   * \return A pointer to the new unit created. */
  Unit *scanSource(const char *name, Source *in = 0, bool isfile = false);

  /** Print a named unit on the given output stream.
   * \param name The name of the unit to print.
   * \param isfile True to indicate that the given name refers to a file (defaults to false).
   * \param out The output stream, defaults to std::cout. */
  void print(const char *name, bool isfile = false, std::ostream &out = std::cout) const;

  /** Initialize the unit manager and the managed units for the next parse process. */
  
#line 250 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/UnitManager.h"
public: __attribute__((always_inline)) inline void __exec_old_init();

#line 122 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/UnitManager.h"

#line 122 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/UnitManager.h"
void init();
#line 257 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step2/inc/Puma/UnitManager.h"

  friend class ::CCExprResolve;
  friend class ::CExprResolve;
  friend class ::SyntaxState;
  friend class ::SyntaxBuilder;
  friend class ::LookAhead;
  friend class ::CBuilderExtension;
  friend class ::CLookAhead;
  friend class ::CSemBinding;
  friend class ::CCBuilderExtension;
  friend class ::CCLookAhead;
  friend class ::CCSemBinding;
  friend class ::WinIfExists;
  friend class ::WinImportHandler;
  friend class ::WinMacros;
  friend class ::WinAsm;
  friend class ::WinDeclSpecs;
  friend class ::WinMemberExplSpec;
  friend class ::WinTypeKeywords;
  friend class ::WinFriend;
  friend class ::WinKeywords;
  friend class ::ExtAC;
  friend class ::ExtACTree;
  friend class ::ExtGnu;
  friend class ::ExtGnuCTree;
  friend class ::ExtGnuKeywords;
  friend class ::PragmaOnceUnitState;
  friend class ::PragmaOnce;

#line 123 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/UnitManager.h"

#line 123 "/build/aspectc++-hxplZt/aspectc++-2.3+git20221129/Puma/gen-release/step1/inc/Puma/UnitManager.h"
};

} // namespace Puma

#endif /* PUMA_UnitManager_H */

#ifdef __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_UnitManager_h__
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveCC_ah__
#include "Puma/CCExprResolveCC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCExprResolveH_ah__
#include "Puma/CCExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveCC_ah__
#include "Puma/CExprResolveCC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CExprResolveH_ah__
#include "Puma/CExprResolveH.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxState_ah__
#include "Puma/SyntaxState.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CBuilderExtension_ah__
#include "Puma/CBuilderExtension.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCBuilderExtension_ah__
#include "Puma/CCBuilderExtension.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_LookAhead_ah__
#include "Puma/LookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CLookAhead_ah__
#include "Puma/CLookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CSemBinding_ah__
#include "Puma/CSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCLookAhead_ah__
#include "Puma/CCLookAhead.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_CCSemBinding_ah__
#include "Puma/CCSemBinding.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinIfExists_ah__
#include "Puma/WinIfExists.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinImportHandler_ah__
#include "Puma/WinImportHandler.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMacros_ah__
#include "Puma/WinMacros.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinAsm_ah__
#include "Puma/WinAsm.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinDeclSpecs_ah__
#include "Puma/WinDeclSpecs.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinMemberExplSpec_ah__
#include "Puma/WinMemberExplSpec.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinTypeKeywords_ah__
#include "Puma/WinTypeKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinFriend_ah__
#include "Puma/WinFriend.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_SyntaxBuilder_ah__
#include "Puma/SyntaxBuilder.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtAC_ah__
#include "Puma/ExtAC.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnu_ah__
#include "Puma/ExtGnu.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCInfos_ah__
#include "Puma/ExtGnuCInfos.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemantic_ah__
#include "Puma/ExtGnuCSemantic.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemExpr_ah__
#include "Puma/ExtGnuCSemExpr.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtACTree_ah__
#include "Puma/ExtACTree.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCSemDeclSpecs_ah__
#include "Puma/ExtGnuCSemDeclSpecs.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuCTree_ah__
#include "Puma/ExtGnuCTree.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_WinKeywords_ah__
#include "Puma/WinKeywords.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_ExtGnuKeywords_ah__
#include "Puma/ExtGnuKeywords.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#endif
#ifdef __ac_need__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnceUnitState_ah__
#include "Puma/PragmaOnceUnitState.ah"
#endif
#ifndef __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#define __ac_have__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_aspects_Puma_PragmaOnce_ah__
#include "Puma/PragmaOnce.ah"
#endif
#endif
#undef __ac_FIRST__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1__
#undef __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_UnitManager_h__
#endif // __ac_FIRST_FILE__build_aspectcX43X43X45hxplZt_aspectcX43X43X452_3X43git20221129_Puma_genX45release_step1_inc_Puma_UnitManager_h__

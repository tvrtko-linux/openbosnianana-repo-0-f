var _base_importer_8h =
[
    [ "Assimp::BaseImporter", "class_assimp_1_1_base_importer.html", "class_assimp_1_1_base_importer" ],
    [ "AI_MAKE_MAGIC", "_base_importer_8h.html#a9bcea7601ce5a87775108e621ead5016", null ],
    [ "INCLUDED_AI_BASEIMPORTER_H", "_base_importer_8h.html#ae017b86bfc5b4a75feef8e45341d0c92", null ]
];
var _blob_i_o_system_8h =
[
    [ "Assimp::BlobIOStream", "class_assimp_1_1_blob_i_o_stream.html", "class_assimp_1_1_blob_i_o_stream" ],
    [ "Assimp::BlobIOSystem", "class_assimp_1_1_blob_i_o_system.html", "class_assimp_1_1_blob_i_o_system" ],
    [ "AI_BLOBIO_MAGIC", "_blob_i_o_system_8h.html#a7b2ca02473b77e5709418732ca5fc3c4", null ],
    [ "AI_BLOBIOSYSTEM_H_INCLUDED", "_blob_i_o_system_8h.html#a88968d6031b3503349338e5835c0d928", null ]
];
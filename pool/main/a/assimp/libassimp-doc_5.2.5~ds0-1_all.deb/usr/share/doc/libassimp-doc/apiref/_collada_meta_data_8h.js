var _collada_meta_data_8h =
[
    [ "AI_COLLADAMETADATA_H_INC", "_collada_meta_data_8h.html#a8d8fa27e088458a5dcc6467fc009c85c", null ],
    [ "AI_METADATA_COLLADA_ID", "_collada_meta_data_8h.html#a253707a7395ca6c9325f53d4348801da", null ],
    [ "AI_METADATA_COLLADA_SID", "_collada_meta_data_8h.html#a7be40126497de0854aa7ca165b65373b", null ]
];
var _default_i_o_stream_8h =
[
    [ "Assimp::DefaultIOStream", "class_assimp_1_1_default_i_o_stream.html", "class_assimp_1_1_default_i_o_stream" ],
    [ "AI_DEFAULTIOSTREAM_H_INC", "_default_i_o_stream_8h.html#a288251b53555db579af4c12b0bb589bd", null ]
];
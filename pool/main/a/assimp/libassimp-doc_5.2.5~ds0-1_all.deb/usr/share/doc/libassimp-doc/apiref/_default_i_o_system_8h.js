var _default_i_o_system_8h =
[
    [ "Assimp::DefaultIOSystem", "class_assimp_1_1_default_i_o_system.html", "class_assimp_1_1_default_i_o_system" ],
    [ "AI_DEFAULTIOSYSTEM_H_INC", "_default_i_o_system_8h.html#add72ed68a15ef02ed4fca6421fff9743", null ]
];
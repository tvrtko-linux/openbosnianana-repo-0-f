var _default_logger_8hpp =
[
    [ "Assimp::DefaultLogger", "class_assimp_1_1_default_logger.html", "class_assimp_1_1_default_logger" ],
    [ "ASSIMP_DEFAULT_LOG_NAME", "_default_logger_8hpp.html#a5e31e6d6c9f8a8954134f3da38fec0a0", null ],
    [ "INCLUDED_AI_DEFAULTLOGGER", "_default_logger_8hpp.html#aa29948e9281de78a8e8720847f65a58d", null ]
];
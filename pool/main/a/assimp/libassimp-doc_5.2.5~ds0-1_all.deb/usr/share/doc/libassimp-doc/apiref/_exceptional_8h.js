var _exceptional_8h =
[
    [ "DeadlyErrorBase", "class_deadly_error_base.html", "class_deadly_error_base" ],
    [ "DeadlyExportError", "class_deadly_export_error.html", "class_deadly_export_error" ],
    [ "DeadlyImportError", "class_deadly_import_error.html", "class_deadly_import_error" ],
    [ "ExceptionSwallower< T >", "struct_exception_swallower.html", "struct_exception_swallower" ],
    [ "ExceptionSwallower< aiReturn >", "struct_exception_swallower_3_01ai_return_01_4.html", "struct_exception_swallower_3_01ai_return_01_4" ],
    [ "ExceptionSwallower< T * >", "struct_exception_swallower_3_01_t_01_5_01_4.html", "struct_exception_swallower_3_01_t_01_5_01_4" ],
    [ "ExceptionSwallower< void >", "struct_exception_swallower_3_01void_01_4.html", "struct_exception_swallower_3_01void_01_4" ],
    [ "AI_INCLUDED_EXCEPTIONAL_H", "_exceptional_8h.html#acc7b14d55f629364b99ed26dd1ffd971", null ],
    [ "ASSIMP_BEGIN_EXCEPTION_REGION", "_exceptional_8h.html#acb6e447fb7d69e49bad111832d05b220", null ],
    [ "ASSIMP_END_EXCEPTION_REGION", "_exceptional_8h.html#a98cb8e1e422caa0f1052825ac667883f", null ],
    [ "ASSIMP_END_EXCEPTION_REGION_WITH_ERROR_STRING", "_exceptional_8h.html#a294c088a0b0c058f5e61e876de77e89d", null ]
];
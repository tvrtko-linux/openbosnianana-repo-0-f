var _generic_property_8h =
[
    [ "AI_GENERIC_PROPERTY_H_INCLUDED", "_generic_property_8h.html#af514d7cc04d1a005ff18cd5f792ddb85", null ],
    [ "GetGenericProperty", "_generic_property_8h.html#a82034801e2397217a1311bdfb578ef6e", null ],
    [ "HasGenericProperty", "_generic_property_8h.html#aeeac2b9cadb75b0e7f2d328d44cec21e", null ],
    [ "SetGenericProperty", "_generic_property_8h.html#a85fa8d7a3d4bb630960427916b37a6ab", null ],
    [ "SetGenericPropertyPtr", "_generic_property_8h.html#abc74bee46dea616f659b02e3abc50e9d", null ]
];
var _gltf_material_8h =
[
    [ "_AI_MATKEY_GLTF_MAPPINGFILTER_MAG_BASE", "_gltf_material_8h.html#a94642b4e663dd7bdf9d55f8e0cf5857d", null ],
    [ "_AI_MATKEY_GLTF_MAPPINGFILTER_MIN_BASE", "_gltf_material_8h.html#ae21c07f167facbff3dfd9b00278b2e75", null ],
    [ "_AI_MATKEY_GLTF_MAPPINGID_BASE", "_gltf_material_8h.html#adf2a0d14eb7a9ef14c0b737bddd41e9d", null ],
    [ "_AI_MATKEY_GLTF_MAPPINGNAME_BASE", "_gltf_material_8h.html#a2b44ca26faf1c3010e838f4a34e0e25a", null ],
    [ "_AI_MATKEY_GLTF_SCALE_BASE", "_gltf_material_8h.html#a568eab3f7f4421684c3419a51bc5c9fa", null ],
    [ "_AI_MATKEY_GLTF_STRENGTH_BASE", "_gltf_material_8h.html#adf3b7556372fc968e5bb10ce11f7822b", null ],
    [ "AI_MATKEY_GLTF_ALPHACUTOFF", "_gltf_material_8h.html#adda58f37ebbaaa81ef3a20b05be6d8e0", null ],
    [ "AI_MATKEY_GLTF_ALPHAMODE", "_gltf_material_8h.html#aa1e95297f0f2f2ea9995dee2e337473d", null ],
    [ "AI_MATKEY_GLTF_MAPPINGFILTER_MAG", "_gltf_material_8h.html#a2a36fa736e06cbec99b2609278563a2f", null ],
    [ "AI_MATKEY_GLTF_MAPPINGFILTER_MIN", "_gltf_material_8h.html#ae3484e40af3630963bb880fbe16e5a93", null ],
    [ "AI_MATKEY_GLTF_MAPPINGID", "_gltf_material_8h.html#a937611dece60c3928311aadaf6002d34", null ],
    [ "AI_MATKEY_GLTF_MAPPINGNAME", "_gltf_material_8h.html#a255fa52a83d841db61feb7d37e3b1b76", null ],
    [ "AI_MATKEY_GLTF_PBRMETALLICROUGHNESS_METALLICROUGHNESS_TEXTURE", "_gltf_material_8h.html#a8030b47ec2342a1ecd75a4044fe73b8c", null ],
    [ "AI_MATKEY_GLTF_TEXTURE_SCALE", "_gltf_material_8h.html#a85b168e8b008d310b58898105c601ee3", null ],
    [ "AI_MATKEY_GLTF_TEXTURE_STRENGTH", "_gltf_material_8h.html#a7215ce7e32adebb36c446b5da0fa4482", null ]
];
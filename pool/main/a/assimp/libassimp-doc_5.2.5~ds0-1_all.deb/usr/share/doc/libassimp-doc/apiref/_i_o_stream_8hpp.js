var _i_o_stream_8hpp =
[
    [ "Assimp::IOStream", "class_assimp_1_1_i_o_stream.html", "class_assimp_1_1_i_o_stream" ],
    [ "AI_IOSTREAM_H_INC", "_i_o_stream_8hpp.html#ace19faed05e7a941220d5337528ddb9c", null ]
];
var _i_o_stream_buffer_8h =
[
    [ "Assimp::IOStreamBuffer< T >", "class_assimp_1_1_i_o_stream_buffer.html", "class_assimp_1_1_i_o_stream_buffer" ],
    [ "AI_IOSTREAMBUFFER_H_INC", "_i_o_stream_buffer_8h.html#ab640518960ab8aad9c03c63481070e8a", null ],
    [ "isEndOfCache", "_i_o_stream_buffer_8h.html#a35ef4d4a311ee5dfe8e0d4f0ebefab9c", null ]
];
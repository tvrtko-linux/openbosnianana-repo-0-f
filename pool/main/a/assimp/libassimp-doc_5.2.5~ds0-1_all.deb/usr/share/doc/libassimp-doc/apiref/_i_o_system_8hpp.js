var _i_o_system_8hpp =
[
    [ "Assimp::IOSystem", "class_assimp_1_1_i_o_system.html", "class_assimp_1_1_i_o_system" ],
    [ "AI_IOSYSTEM_H_INC", "_i_o_system_8hpp.html#a97dd8264e55a5aac38122da34ea489e8", null ]
];
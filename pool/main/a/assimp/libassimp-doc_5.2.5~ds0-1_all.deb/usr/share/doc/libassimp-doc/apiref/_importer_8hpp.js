var _importer_8hpp =
[
    [ "Assimp::Importer", "class_assimp_1_1_importer.html", "class_assimp_1_1_importer" ],
    [ "AI_ASSIMP_HPP_INC", "_importer_8hpp.html#a5c981017bdc01cdf69aeb781344c2aff", null ],
    [ "AI_PROPERTY_WAS_NOT_EXISTING", "_importer_8hpp.html#adb9160ea5bf307fd2ee2b1fb945a4468", null ]
];
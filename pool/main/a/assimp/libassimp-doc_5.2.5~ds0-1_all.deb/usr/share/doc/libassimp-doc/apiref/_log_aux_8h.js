var _log_aux_8h =
[
    [ "Assimp::LogFunctions< TDeriving >", "class_assimp_1_1_log_functions.html", "class_assimp_1_1_log_functions" ],
    [ "INCLUDED_AI_LOGAUX_H", "_log_aux_8h.html#a806d8caf5482028503dd35f25f39bdc0", null ]
];
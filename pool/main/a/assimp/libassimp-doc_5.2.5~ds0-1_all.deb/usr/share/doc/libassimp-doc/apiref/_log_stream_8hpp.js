var _log_stream_8hpp =
[
    [ "Assimp::LogStream", "class_assimp_1_1_log_stream.html", "class_assimp_1_1_log_stream" ],
    [ "INCLUDED_AI_LOGSTREAM_H", "_log_stream_8hpp.html#a72cba6f5bfaf4522902668d60036c255", null ]
];
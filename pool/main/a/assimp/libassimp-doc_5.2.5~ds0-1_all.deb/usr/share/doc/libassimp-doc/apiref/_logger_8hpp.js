var _logger_8hpp =
[
    [ "Assimp::Logger", "class_assimp_1_1_logger.html", "class_assimp_1_1_logger" ],
    [ "ASSIMP_LOG_DEBUG", "_logger_8hpp.html#a1a20dc2c2ad4ba28557c1c53375589c9", null ],
    [ "ASSIMP_LOG_ERROR", "_logger_8hpp.html#af9c5f9debd2b062dec87a32121cf12dd", null ],
    [ "ASSIMP_LOG_INFO", "_logger_8hpp.html#a02b8b6684736711bfc07e74805d314bd", null ],
    [ "ASSIMP_LOG_VERBOSE_DEBUG", "_logger_8hpp.html#a2e93a38394c31960fa5a2f51a7c32da9", null ],
    [ "ASSIMP_LOG_WARN", "_logger_8hpp.html#ae2042ef82dfa543c7f03ae9766067552", null ],
    [ "INCLUDED_AI_LOGGER_H", "_logger_8hpp.html#a404415b2c267becf36fc1efab88a9bac", null ],
    [ "MAX_LOG_MESSAGE_LENGTH", "_logger_8hpp.html#a3adf7dc8e9dcfe1da6e33aa8043a80c3", null ]
];
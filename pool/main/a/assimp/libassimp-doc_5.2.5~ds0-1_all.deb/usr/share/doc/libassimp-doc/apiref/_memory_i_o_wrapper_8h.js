var _memory_i_o_wrapper_8h =
[
    [ "Assimp::MemoryIOStream", "class_assimp_1_1_memory_i_o_stream.html", "class_assimp_1_1_memory_i_o_stream" ],
    [ "Assimp::MemoryIOSystem", "class_assimp_1_1_memory_i_o_system.html", "class_assimp_1_1_memory_i_o_system" ],
    [ "AI_MEMORYIO_MAGIC_FILENAME", "_memory_i_o_wrapper_8h.html#a68dd7d3f79f33c2c9c68fa97df2e10e5", null ],
    [ "AI_MEMORYIO_MAGIC_FILENAME_LENGTH", "_memory_i_o_wrapper_8h.html#a96d6cede3dff866d038e00b1442f1415", null ],
    [ "AI_MEMORYIOSTREAM_H_INC", "_memory_i_o_wrapper_8h.html#a99cf023c24716a1f8ef290beeef12a13", null ]
];
var _null_logger_8hpp =
[
    [ "Assimp::NullLogger", "class_assimp_1_1_null_logger.html", "class_assimp_1_1_null_logger" ],
    [ "INCLUDED_AI_NULLLOGGER_H", "_null_logger_8hpp.html#a50416d8a712954276dead0c968596c1e", null ]
];
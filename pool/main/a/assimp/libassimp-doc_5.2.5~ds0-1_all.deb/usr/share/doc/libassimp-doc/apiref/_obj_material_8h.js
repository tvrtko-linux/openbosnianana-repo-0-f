var _obj_material_8h =
[
    [ "AI_MATKEY_OBJ_BUMPMULT", "_obj_material_8h.html#a52ee08e213bec1947d68cea6753139f9", null ],
    [ "AI_MATKEY_OBJ_ILLUM", "_obj_material_8h.html#a802855c4ab694b3952c9654d0bfcba4a", null ]
];
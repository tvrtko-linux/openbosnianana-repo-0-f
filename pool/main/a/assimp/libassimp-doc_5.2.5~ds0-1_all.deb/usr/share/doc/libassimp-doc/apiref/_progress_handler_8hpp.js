var _progress_handler_8hpp =
[
    [ "Assimp::ProgressHandler", "class_assimp_1_1_progress_handler.html", "class_assimp_1_1_progress_handler" ],
    [ "AI_PROGRESSHANDLER_H_INC", "_progress_handler_8hpp.html#a74460b8d99076460b57b7be247aa9814", null ]
];
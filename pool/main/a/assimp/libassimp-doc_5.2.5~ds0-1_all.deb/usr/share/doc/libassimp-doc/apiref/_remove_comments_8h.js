var _remove_comments_8h =
[
    [ "Assimp::CommentRemover", "class_assimp_1_1_comment_remover.html", "class_assimp_1_1_comment_remover" ],
    [ "AI_REMOVE_COMMENTS_H_INC", "_remove_comments_8h.html#a0c654d4678b72190d26ca45a3ad49318", null ]
];
var _s_g_spatial_sort_8h =
[
    [ "Assimp::SGSpatialSort", "class_assimp_1_1_s_g_spatial_sort.html", "class_assimp_1_1_s_g_spatial_sort" ],
    [ "Assimp::SGSpatialSort::Entry", "struct_assimp_1_1_s_g_spatial_sort_1_1_entry.html", "struct_assimp_1_1_s_g_spatial_sort_1_1_entry" ],
    [ "AI_D3DSSPATIALSORT_H_INC", "_s_g_spatial_sort_8h.html#aacba25e50a69341a40f7b804d5d21f68", null ]
];
var _scene_combiner_8h =
[
    [ "Assimp::AttachmentInfo", "struct_assimp_1_1_attachment_info.html", "struct_assimp_1_1_attachment_info" ],
    [ "Assimp::BoneWithHash", "struct_assimp_1_1_bone_with_hash.html", "struct_assimp_1_1_bone_with_hash" ],
    [ "Assimp::NodeAttachmentInfo", "struct_assimp_1_1_node_attachment_info.html", "struct_assimp_1_1_node_attachment_info" ],
    [ "Assimp::SceneCombiner", "class_assimp_1_1_scene_combiner.html", "class_assimp_1_1_scene_combiner" ],
    [ "Assimp::SceneHelper", "struct_assimp_1_1_scene_helper.html", "struct_assimp_1_1_scene_helper" ],
    [ "AI_INT_MERGE_SCENE_DUPLICATES_DEEP_CPY", "_scene_combiner_8h.html#a68ddd39bb994f5b4e7ee00d7eccfa45b", null ],
    [ "AI_INT_MERGE_SCENE_GEN_UNIQUE_MATNAMES", "_scene_combiner_8h.html#ad05433b2560cd156295ece638c536d90", null ],
    [ "AI_INT_MERGE_SCENE_GEN_UNIQUE_NAMES", "_scene_combiner_8h.html#a9cf10d806d7b2e00ce39d4b8b1dcc1f1", null ],
    [ "AI_INT_MERGE_SCENE_GEN_UNIQUE_NAMES_IF_NECESSARY", "_scene_combiner_8h.html#a1e990dc138aab33fb520e67101f6d7f7", null ],
    [ "AI_INT_MERGE_SCENE_RESOLVE_CROSS_ATTACHMENTS", "_scene_combiner_8h.html#a0f20b2791b4bcf39856845e4c856a3ee", null ],
    [ "AI_SCENE_COMBINER_H_INC", "_scene_combiner_8h.html#ad74e7dee55ad7d93b69eae5610eaf081", null ],
    [ "BoneSrcIndex", "_scene_combiner_8h.html#a5a6f2070082f2eff6e9ccf57539bfad2", null ]
];
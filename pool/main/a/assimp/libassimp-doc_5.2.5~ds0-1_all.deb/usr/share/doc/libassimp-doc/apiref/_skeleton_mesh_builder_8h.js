var _skeleton_mesh_builder_8h =
[
    [ "Assimp::SkeletonMeshBuilder", "class_assimp_1_1_skeleton_mesh_builder.html", "class_assimp_1_1_skeleton_mesh_builder" ],
    [ "AI_SKELETONMESHBUILDER_H_INC", "_skeleton_mesh_builder_8h.html#a5a78fd0b76f9509d8551319b0c2471fc", null ]
];
var _smoothing_groups_8h =
[
    [ "FaceWithSmoothingGroup", "struct_face_with_smoothing_group.html", "struct_face_with_smoothing_group" ],
    [ "MeshWithSmoothingGroups< T >", "struct_mesh_with_smoothing_groups.html", "struct_mesh_with_smoothing_groups" ],
    [ "AI_SMOOTHINGGROUPS_H_INC", "_smoothing_groups_8h.html#a560d64cdce788040de6574855904742a", null ],
    [ "ComputeNormalsWithSmoothingsGroups", "_smoothing_groups_8h.html#a8213a64aefeba1a25b9c82573d779140", null ]
];
var _smoothing_groups_8inl =
[
    [ "AI_SMOOTHINGGROUPS_INL_INCLUDED", "_smoothing_groups_8inl.html#afbe5332c630031a378a0a2bac5f52d44", null ],
    [ "ComputeNormalsWithSmoothingsGroups", "_smoothing_groups_8inl.html#a8213a64aefeba1a25b9c82573d779140", null ]
];
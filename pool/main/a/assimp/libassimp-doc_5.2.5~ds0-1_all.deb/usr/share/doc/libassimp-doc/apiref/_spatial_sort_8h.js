var _spatial_sort_8h =
[
    [ "Assimp::SpatialSort", "class_assimp_1_1_spatial_sort.html", "class_assimp_1_1_spatial_sort" ],
    [ "Assimp::SpatialSort::Entry", "struct_assimp_1_1_spatial_sort_1_1_entry.html", "struct_assimp_1_1_spatial_sort_1_1_entry" ],
    [ "AI_SPATIALSORT_H_INC", "_spatial_sort_8h.html#a32b462256a711d4f9fbdfeb9b26480a2", null ]
];
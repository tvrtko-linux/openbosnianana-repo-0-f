var _standard_shapes_8h =
[
    [ "Assimp::StandardShapes", "class_assimp_1_1_standard_shapes.html", "class_assimp_1_1_standard_shapes" ],
    [ "AI_STANDARD_SHAPES_H_INC", "_standard_shapes_8h.html#a785ea717e979096f15e490f2016d7e90", null ]
];
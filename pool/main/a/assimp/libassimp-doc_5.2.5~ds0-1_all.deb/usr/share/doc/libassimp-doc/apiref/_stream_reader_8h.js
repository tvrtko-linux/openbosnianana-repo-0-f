var _stream_reader_8h =
[
    [ "Assimp::StreamReader< SwapEndianess, RuntimeSwitch >", "class_assimp_1_1_stream_reader.html", "class_assimp_1_1_stream_reader" ],
    [ "AI_STREAMREADER_H_INCLUDED", "_stream_reader_8h.html#a0ec903fd351e29c03cbd3acb57303d29", null ],
    [ "StreamReaderAny", "_stream_reader_8h.html#a8e193a5db58ec2f8e39010b733a38bea", null ],
    [ "StreamReaderBE", "_stream_reader_8h.html#af2ff0c84f4cfd99b6c1faa01e84460a1", null ],
    [ "StreamReaderLE", "_stream_reader_8h.html#ab34515c230b8458492195a11571f266f", null ]
];
var _stream_writer_8h =
[
    [ "Assimp::StreamWriter< SwapEndianess, RuntimeSwitch >", "class_assimp_1_1_stream_writer.html", "class_assimp_1_1_stream_writer" ],
    [ "AI_STREAMWRITER_H_INCLUDED", "_stream_writer_8h.html#af387802bd4c3308985623fd8af6b09ff", null ],
    [ "StreamWriterAny", "_stream_writer_8h.html#a558b226631652eba1e293f9335a0e207", null ],
    [ "StreamWriterBE", "_stream_writer_8h.html#ad44bf37a916baf307c87ba3e4e939a6e", null ],
    [ "StreamWriterLE", "_stream_writer_8h.html#a88e476e3981b368edc1c4c0ed44bf773", null ]
];
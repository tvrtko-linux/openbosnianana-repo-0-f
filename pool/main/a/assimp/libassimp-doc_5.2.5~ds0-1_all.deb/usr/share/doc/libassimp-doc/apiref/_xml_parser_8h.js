var _xml_parser_8h =
[
    [ "Assimp::find_node_by_name_predicate", "struct_assimp_1_1find__node__by__name__predicate.html", "struct_assimp_1_1find__node__by__name__predicate" ],
    [ "Assimp::NodeConverter< TNodeType >", "struct_assimp_1_1_node_converter.html", "struct_assimp_1_1_node_converter" ],
    [ "Assimp::TXmlParser< TNodeType >", "class_assimp_1_1_t_xml_parser.html", "class_assimp_1_1_t_xml_parser" ],
    [ "Assimp::XmlNodeIterator", "class_assimp_1_1_xml_node_iterator.html", "class_assimp_1_1_xml_node_iterator" ],
    [ "XmlAttribute", "_xml_parser_8h.html#af8d3ea66e7aaa03fdf0553ab6af8a8de", null ],
    [ "XmlNode", "_xml_parser_8h.html#ad9aa76cdbe59a3c057f55760f3a02c0a", null ],
    [ "XmlParser", "_xml_parser_8h.html#a6295df0173c66269feae004611f499a2", null ]
];
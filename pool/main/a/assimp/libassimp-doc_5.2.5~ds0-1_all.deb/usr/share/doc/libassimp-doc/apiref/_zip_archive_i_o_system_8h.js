var _zip_archive_i_o_system_8h =
[
    [ "Assimp::ZipArchiveIOSystem", "class_assimp_1_1_zip_archive_i_o_system.html", "class_assimp_1_1_zip_archive_i_o_system" ],
    [ "AI_ZIPARCHIVEIOSYSTEM_H_INC", "_zip_archive_i_o_system_8h.html#a5750350ed96de4ffda998e6943ff620e", null ]
];
var class_assimp_1_1_comment_remover =
[
    [ "RemoveLineComments", "class_assimp_1_1_comment_remover.html#a6c43b3571d2af5353985801c3cbf21cf", null ],
    [ "RemoveMultiLineComments", "class_assimp_1_1_comment_remover.html#a774b3a2ca208590a9575848e13c6e83e", null ]
];
var class_assimp_1_1_default_logger =
[
    [ "attachStream", "class_assimp_1_1_default_logger.html#ab60317037f8864bf53b8eb8b5110e91d", null ],
    [ "create", "class_assimp_1_1_default_logger.html#aeba2d768f7549fb218bcce1245e88e1c", null ],
    [ "detachStream", "class_assimp_1_1_default_logger.html#a6313f4734baa0a5776891c839538e054", null ],
    [ "get", "class_assimp_1_1_default_logger.html#a4b6ac25541ce63973f7fb0bf1b8bcb44", null ],
    [ "isNullLogger", "class_assimp_1_1_default_logger.html#abebc7ee702a2a2dde765e771948400c6", null ],
    [ "kill", "class_assimp_1_1_default_logger.html#a0b1da096d7442af5a4a4cb5ebb2540f7", null ],
    [ "set", "class_assimp_1_1_default_logger.html#a9daba548026045b99813c760c2842ed2", null ]
];
var class_assimp_1_1_log_functions =
[
    [ "LogDebug", "class_assimp_1_1_log_functions.html#aab00c04699f94932eb8561a0cd2382e4", null ],
    [ "LogError", "class_assimp_1_1_log_functions.html#a4f0f372bc912ff87a7340b29e2d9dec0", null ],
    [ "LogInfo", "class_assimp_1_1_log_functions.html#ab66b363e82aade628aff56e7a05854c4", null ],
    [ "LogVerboseDebug", "class_assimp_1_1_log_functions.html#a952b0df256d133fb4bf6ebfa6bc3203b", null ],
    [ "LogWarn", "class_assimp_1_1_log_functions.html#a077d37ba3a8303542248cccff3b3d332", null ],
    [ "ThrowException", "class_assimp_1_1_log_functions.html#a152406e61f24c27bd2c20ecb4b3cf143", null ]
];
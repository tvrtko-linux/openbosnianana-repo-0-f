var class_assimp_1_1_null_logger =
[
    [ "attachStream", "class_assimp_1_1_null_logger.html#a31c05ecaee392b5fd34fd2dfd1cca559", null ],
    [ "detachStream", "class_assimp_1_1_null_logger.html#a071c06bd70831e2e5da932ca806423d8", null ],
    [ "OnDebug", "class_assimp_1_1_null_logger.html#af354ebbd382b7097a55d364794a45631", null ],
    [ "OnError", "class_assimp_1_1_null_logger.html#a4fbf66103757fafcff891fb04b4ee714", null ],
    [ "OnInfo", "class_assimp_1_1_null_logger.html#a12d2b0048d17a819c8c00277ad1394c5", null ],
    [ "OnVerboseDebug", "class_assimp_1_1_null_logger.html#aa1817f1e94f406931d138a510b32e16e", null ],
    [ "OnWarn", "class_assimp_1_1_null_logger.html#a9a04c2b9e3d4bc9eec8f693ed8115f24", null ]
];
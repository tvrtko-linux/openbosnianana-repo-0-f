var class_assimp_1_1_profiling_1_1_profiler =
[
    [ "Profiler", "class_assimp_1_1_profiling_1_1_profiler.html#a6995b89263e75fc268b34c8419d4e5cd", null ],
    [ "BeginRegion", "class_assimp_1_1_profiling_1_1_profiler.html#a45e182494822c3c276f0508c23405d94", null ],
    [ "EndRegion", "class_assimp_1_1_profiling_1_1_profiler.html#a67ae536cfdd0844c67486243707d93f5", null ]
];
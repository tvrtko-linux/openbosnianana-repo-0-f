var class_assimp_1_1_s_g_spatial_sort =
[
    [ "Entry", "struct_assimp_1_1_s_g_spatial_sort_1_1_entry.html", "struct_assimp_1_1_s_g_spatial_sort_1_1_entry" ],
    [ "SGSpatialSort", "class_assimp_1_1_s_g_spatial_sort.html#a8d4df2d8225cb74e6cd6342fa10da2ed", null ],
    [ "SGSpatialSort", "class_assimp_1_1_s_g_spatial_sort.html#a03c330e8cdf61d8b33e6de8893e235e6", null ],
    [ "~SGSpatialSort", "class_assimp_1_1_s_g_spatial_sort.html#afe7e34a71c28f2e66e7d41d3fbaec0ca", null ],
    [ "Add", "class_assimp_1_1_s_g_spatial_sort.html#adfe82e1689fc782166019d8f7f9b35a5", null ],
    [ "FindPositions", "class_assimp_1_1_s_g_spatial_sort.html#ab06ebf9fdf866149666dbb5206111e87", null ],
    [ "Prepare", "class_assimp_1_1_s_g_spatial_sort.html#aeccf2ea7b7b5b0e2b3d22ff366c5fc59", null ],
    [ "mPlaneNormal", "class_assimp_1_1_s_g_spatial_sort.html#a8b804cf9b91af01eedebca7d878cd3df", null ],
    [ "mPositions", "class_assimp_1_1_s_g_spatial_sort.html#ae259b68b3d5d1161dcf2d9d71e605cd4", null ]
];
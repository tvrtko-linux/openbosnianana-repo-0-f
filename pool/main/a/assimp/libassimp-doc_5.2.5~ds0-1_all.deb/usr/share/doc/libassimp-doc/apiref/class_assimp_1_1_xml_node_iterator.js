var class_assimp_1_1_xml_node_iterator =
[
    [ "IterationMode", "class_assimp_1_1_xml_node_iterator.html#a8b2559c1b090867a20f54892b3391c1b", [
      [ "PreOrderMode", "class_assimp_1_1_xml_node_iterator.html#a8b2559c1b090867a20f54892b3391c1ba6e93bdfa382164189f8f2323b4536e71", null ],
      [ "PostOrderMode", "class_assimp_1_1_xml_node_iterator.html#a8b2559c1b090867a20f54892b3391c1ba5e0113b2dfc00efb1768903c2fb4f54b", null ]
    ] ],
    [ "XmlNodeIterator", "class_assimp_1_1_xml_node_iterator.html#ac91f7e3201cb252deb653b4aaed41207", null ],
    [ "~XmlNodeIterator", "class_assimp_1_1_xml_node_iterator.html#ad0ef7ae6788b36d61cd061403c97e3e8", null ],
    [ "clear", "class_assimp_1_1_xml_node_iterator.html#a4638e2eaf70a0b64963c00735c7a15dd", null ],
    [ "collectChildrenPostOrder", "class_assimp_1_1_xml_node_iterator.html#aca9024c882f07991467e05676123d035", null ],
    [ "collectChildrenPreOrder", "class_assimp_1_1_xml_node_iterator.html#a71e766fc388e15793cc892f70d770c31", null ],
    [ "getNext", "class_assimp_1_1_xml_node_iterator.html#a5817a15765681eb544ac1e8c44ce33aa", null ],
    [ "isEmpty", "class_assimp_1_1_xml_node_iterator.html#ac8937d559903bfe99ee6ea280025cce8", null ],
    [ "size", "class_assimp_1_1_xml_node_iterator.html#ac2d21217d2921169efec5f318a0c594e", null ]
];
var class_deadly_error_base =
[
    [ "DeadlyErrorBase", "class_deadly_error_base.html#af100784aff998fbbdd4119fc8e7c45b9", null ],
    [ "DeadlyErrorBase", "class_deadly_error_base.html#ac2f9ad96d4d189c7dcac25d612114095", null ]
];
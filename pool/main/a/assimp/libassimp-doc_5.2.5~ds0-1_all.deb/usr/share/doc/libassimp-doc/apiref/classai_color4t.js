var classai_color4t =
[
    [ "aiColor4t", "classai_color4t.html#acb9a4a10d9ef48d54000e48d40bafd5b", null ],
    [ "aiColor4t", "classai_color4t.html#a05b7243f07dd3150992152167fed2ded", null ],
    [ "aiColor4t", "classai_color4t.html#aeca9a1ccc0fc27ffdec465436216f1cd", null ],
    [ "aiColor4t", "classai_color4t.html#aaf142f7dba3f25dbd1e851329bb126bc", null ],
    [ "IsBlack", "classai_color4t.html#a13d103612df5e001fa8ce776a07f5e79", null ],
    [ "operator!=", "classai_color4t.html#a20ad4b42bcae13bd261122ec1be0bfe8", null ],
    [ "operator*=", "classai_color4t.html#a7bdfa2166a28eca334ef26cfb6fbab37", null ],
    [ "operator+=", "classai_color4t.html#a092e3d6740453cd4a2b22479919807f4", null ],
    [ "operator-=", "classai_color4t.html#afbc773cfac1d84f4779c4e60794ccd46", null ],
    [ "operator/=", "classai_color4t.html#a29068290fc4da64ea6a2c960516b8b26", null ],
    [ "operator<", "classai_color4t.html#a4f1ba7293e201ce8a608b544462fa202", null ],
    [ "operator==", "classai_color4t.html#a623187ac74cb9bed5ce0e1ca4e234d24", null ],
    [ "operator[]", "classai_color4t.html#a5ebae0688eb188c11150ef53dbc87330", null ],
    [ "operator[]", "classai_color4t.html#a2db0c57f84f9562b780caa5eb47245d4", null ],
    [ "a", "classai_color4t.html#a8e81e26e8bd226985310eff4fea16adc", null ],
    [ "b", "classai_color4t.html#a4e0d4475cd107cc62b41d31b01cf8250", null ],
    [ "g", "classai_color4t.html#ab0308badb3f7322781db38a51e52c921", null ],
    [ "r", "classai_color4t.html#a8032f2a2c3613c0761161ae971fb2c41", null ]
];
var classai_quaterniont =
[
    [ "aiQuaterniont", "classai_quaterniont.html#a7b8bf3ffb58f4a5efac701730e09c0c4", null ],
    [ "aiQuaterniont", "classai_quaterniont.html#a570ba95c517f9b76f76a0bc4dddde510", null ],
    [ "aiQuaterniont", "classai_quaterniont.html#acc84e78a8dd2548ccf098c52ed9714b6", null ],
    [ "aiQuaterniont", "classai_quaterniont.html#a6e6e326968c01355b468ca3c297215a6", null ],
    [ "aiQuaterniont", "classai_quaterniont.html#a6efab53b1a15f56b1a7275352c61b958", null ],
    [ "aiQuaterniont", "classai_quaterniont.html#a4d4f012d62584e9a8b656081b70c5921", null ],
    [ "Conjugate", "classai_quaterniont.html#a5423571dc6d36fd134c61d6c6c2979fc", null ],
    [ "Equal", "classai_quaterniont.html#a9aedac23c34388580b903061a492ffa2", null ],
    [ "GetMatrix", "classai_quaterniont.html#a5f14f0491de62a24f9c66f7aa0504868", null ],
    [ "Interpolate", "classai_quaterniont.html#a0ef9d1ce7a258e92ffb0ff117f48b9f6", null ],
    [ "Normalize", "classai_quaterniont.html#a476e48051aee949deeb44a8fd768b019", null ],
    [ "operator!=", "classai_quaterniont.html#a34109b4b747fe41a2e69f0fd246e7bb5", null ],
    [ "operator*", "classai_quaterniont.html#a785eca8688069b59a2062299b841df13", null ],
    [ "operator*=", "classai_quaterniont.html#a2057bd9ff3faea157f0504ac74747128", null ],
    [ "operator==", "classai_quaterniont.html#aa35d6473022bf87b1b07cc5395c3bb7c", null ],
    [ "Rotate", "classai_quaterniont.html#a43d31abfd6338eddec2c38f66c0d1777", null ],
    [ "w", "classai_quaterniont.html#a1d41620a1101e8bf9f3c06626b518062", null ],
    [ "x", "classai_quaterniont.html#ad3364d5c704a60123927b5a1927e6c14", null ],
    [ "y", "classai_quaterniont.html#af2ce303fbc1e2986a1d14acd2c48a6a5", null ],
    [ "z", "classai_quaterniont.html#a2a5c289e193c3952f1234beee37e5760", null ]
];
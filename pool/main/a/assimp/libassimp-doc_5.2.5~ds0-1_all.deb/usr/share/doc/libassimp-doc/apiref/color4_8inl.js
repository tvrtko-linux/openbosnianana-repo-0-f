var color4_8inl =
[
    [ "AI_COLOR4D_INL_INC", "color4_8inl.html#a77423de67c2c45745a4a79741ad8a4b1", null ],
    [ "operator*", "color4_8inl.html#a3f4a9a440890e5f175237b3d3d4bc098", null ],
    [ "operator*", "color4_8inl.html#a6e48856824665c2f30aa4feb30cd9fc9", null ],
    [ "operator*", "color4_8inl.html#a9897232af8be641d8a9626f5beabdadc", null ],
    [ "operator+", "color4_8inl.html#a1b7114c6b4022532bfa2ac8f254342c0", null ],
    [ "operator+", "color4_8inl.html#adddeb83bd828fdd8b247de30825d96ee", null ],
    [ "operator+", "color4_8inl.html#a8e2fd65d377c5a13bfd5a641e4ff62cd", null ],
    [ "operator-", "color4_8inl.html#aa44ec85271bd471c91678d3bdfdc01f7", null ],
    [ "operator-", "color4_8inl.html#a451b4e1830b8382cece7f10898d8295c", null ],
    [ "operator-", "color4_8inl.html#ac2c9b17cf3d88978a72b5bb9215a72a7", null ],
    [ "operator/", "color4_8inl.html#a5b40f26c1519bdf7f49330fa1d180ea2", null ],
    [ "operator/", "color4_8inl.html#af5b7f1bf1dd820385f8a69159b5e7a26", null ],
    [ "operator/", "color4_8inl.html#a2b20a87b36aafeead9542330fc50b131", null ]
];
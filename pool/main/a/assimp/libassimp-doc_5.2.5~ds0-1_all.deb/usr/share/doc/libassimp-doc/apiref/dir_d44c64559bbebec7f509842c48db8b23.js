var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "assimp", "dir_2a3ab8ae23d2cffc0bffa70c4703d52b.html", "dir_2a3ab8ae23d2cffc0bffa70c4703d52b" ]
];
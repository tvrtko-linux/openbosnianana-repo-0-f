var importerdesc_8h =
[
    [ "aiImporterDesc", "structai_importer_desc.html", "structai_importer_desc" ],
    [ "AI_IMPORTER_DESC_H_INC", "importerdesc_8h.html#ace56c61d92c8f89d1bb82b393b73da81", null ],
    [ "aiImporterFlags", "importerdesc_8h.html#a3c78e1208ecbd75fecdbb4e38d820449", [
      [ "aiImporterFlags_SupportTextFlavour", "importerdesc_8h.html#a3c78e1208ecbd75fecdbb4e38d820449a022e8627161639e2362da3ca7fff2c01", null ],
      [ "aiImporterFlags_SupportBinaryFlavour", "importerdesc_8h.html#a3c78e1208ecbd75fecdbb4e38d820449aa098d1efe9961ac268b8f40c85404bfc", null ],
      [ "aiImporterFlags_SupportCompressedFlavour", "importerdesc_8h.html#a3c78e1208ecbd75fecdbb4e38d820449a96b161d2bff39018f1bc626ec0bb5f5d", null ],
      [ "aiImporterFlags_LimitedSupport", "importerdesc_8h.html#a3c78e1208ecbd75fecdbb4e38d820449a6344b2d4487c5894e20cf06e807e127f", null ],
      [ "aiImporterFlags_Experimental", "importerdesc_8h.html#a3c78e1208ecbd75fecdbb4e38d820449aff5af9356317719908b4dee9b50588f3", null ]
    ] ],
    [ "aiGetImporterDesc", "importerdesc_8h.html#a1bb5fd1e5603a1fbe66c71920d949f00", null ]
];
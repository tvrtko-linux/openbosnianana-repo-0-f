var light_8h =
[
    [ "aiLight", "structai_light.html", "structai_light" ],
    [ "AI_LIGHT_H_INC", "light_8h.html#a7f9d67609e200bdeea07a539a1433c0f", null ],
    [ "aiLightSourceType", "light_8h.html#a7a75cb224d903e71e8daede432449766", [
      [ "aiLightSource_UNDEFINED", "light_8h.html#a7a75cb224d903e71e8daede432449766a7c7578b784f98cab23cbefcf242758eb", null ],
      [ "aiLightSource_DIRECTIONAL", "light_8h.html#a7a75cb224d903e71e8daede432449766ab2dd8e6f09a9ca0efcf22457da2e8724", null ],
      [ "aiLightSource_POINT", "light_8h.html#a7a75cb224d903e71e8daede432449766a0f5bf9437cd16516e15c095309476d37", null ],
      [ "aiLightSource_SPOT", "light_8h.html#a7a75cb224d903e71e8daede432449766a05ef88df7bae63499a8ed950c995e392", null ],
      [ "aiLightSource_AMBIENT", "light_8h.html#a7a75cb224d903e71e8daede432449766a586dc7f849733364cb5b28c403759bf3", null ],
      [ "aiLightSource_AREA", "light_8h.html#a7a75cb224d903e71e8daede432449766a835d706047f460d4a70bf6a4b5b334b1", null ],
      [ "_aiLightSource_Force32Bit", "light_8h.html#a7a75cb224d903e71e8daede432449766a110c3b047ed41a1656849921d75e83a1", null ]
    ] ]
];
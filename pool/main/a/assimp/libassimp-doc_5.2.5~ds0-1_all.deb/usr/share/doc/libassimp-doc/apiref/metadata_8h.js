var metadata_8h =
[
    [ "aiMetadata", "structai_metadata.html", "structai_metadata" ],
    [ "aiMetadataEntry", "structai_metadata_entry.html", "structai_metadata_entry" ],
    [ "AI_METADATA_H_INC", "metadata_8h.html#a23ee816cdc02fb9a01ca166295e75ba2", null ],
    [ "aiMetadataType", "metadata_8h.html#aa910906c37416da57bb36335a4d04232", [
      [ "AI_BOOL", "metadata_8h.html#aa910906c37416da57bb36335a4d04232afefc9e3487a8cc29072efcd45f96e525", null ],
      [ "AI_INT32", "metadata_8h.html#aa910906c37416da57bb36335a4d04232ad3844385f0c5d41d06f32b1db8db54c2", null ],
      [ "AI_UINT64", "metadata_8h.html#aa910906c37416da57bb36335a4d04232aaf521cce3ea0823fc860ca4066dbe97f", null ],
      [ "AI_FLOAT", "metadata_8h.html#aa910906c37416da57bb36335a4d04232a282d5cc9926ba25c9b6fd3f1cabef2f9", null ],
      [ "AI_DOUBLE", "metadata_8h.html#aa910906c37416da57bb36335a4d04232a0d337dace41be4ad121805cd084cb6a0", null ],
      [ "AI_AISTRING", "metadata_8h.html#aa910906c37416da57bb36335a4d04232a0ef60d073637076f1a103a1b94fb347c", null ],
      [ "AI_AIVECTOR3D", "metadata_8h.html#aa910906c37416da57bb36335a4d04232ac7250619893396c6f18523640b7f8eff", null ],
      [ "AI_AIMETADATA", "metadata_8h.html#aa910906c37416da57bb36335a4d04232ae84205f8f8a78c7c13f9a1176f369387", null ],
      [ "AI_META_MAX", "metadata_8h.html#aa910906c37416da57bb36335a4d04232a25738f563a1d1b36c00ec87db1b7710f", null ],
      [ "FORCE_32BIT", "metadata_8h.html#aa910906c37416da57bb36335a4d04232abaea8901dff1913cf4e2545ae9893b0f", null ]
    ] ],
    [ "GetAiType", "metadata_8h.html#a6b13f4873d7ed1c74ff0665221e150c1", null ],
    [ "GetAiType", "metadata_8h.html#a460d586138c2984cdebdbaab4d5aa926", null ],
    [ "GetAiType", "metadata_8h.html#ae834a2e0277a969b5aa27c1de1c23f42", null ],
    [ "GetAiType", "metadata_8h.html#a7c984b91eead2b2bb9a0a69b490c90fe", null ],
    [ "GetAiType", "metadata_8h.html#a64cc5615ba51db20d857c167b9c6d81e", null ],
    [ "GetAiType", "metadata_8h.html#aada3c07909bdbfca937ffe047e5031c1", null ],
    [ "GetAiType", "metadata_8h.html#aca6fb4caf4726c9be9d6a91365c3ebca", null ],
    [ "GetAiType", "metadata_8h.html#a6d9f32bb67cecb8aa9d611205d0d99bd", null ]
];
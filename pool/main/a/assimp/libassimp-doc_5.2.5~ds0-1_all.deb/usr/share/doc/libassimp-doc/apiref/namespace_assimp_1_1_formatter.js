var namespace_assimp_1_1_formatter =
[
    [ "basic_formatter", "class_assimp_1_1_formatter_1_1basic__formatter.html", "class_assimp_1_1_formatter_1_1basic__formatter" ],
    [ "format", "namespace_assimp_1_1_formatter.html#a6cf94459cb125ad767209c268d4bbcd4", null ],
    [ "wformat", "namespace_assimp_1_1_formatter.html#a666d0e2f6623b5531902a03a81d4e5d2", null ]
];
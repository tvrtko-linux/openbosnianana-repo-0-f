var namespace_assimp_1_1_intern =
[
    [ "ByteSwapper", "struct_assimp_1_1_intern_1_1_byte_swapper.html", "struct_assimp_1_1_intern_1_1_byte_swapper" ],
    [ "ByteSwapper< T, false >", "struct_assimp_1_1_intern_1_1_byte_swapper_3_01_t_00_01false_01_4.html", "struct_assimp_1_1_intern_1_1_byte_swapper_3_01_t_00_01false_01_4" ],
    [ "divides", "struct_assimp_1_1_intern_1_1divides.html", "struct_assimp_1_1_intern_1_1divides" ],
    [ "Getter", "struct_assimp_1_1_intern_1_1_getter.html", "struct_assimp_1_1_intern_1_1_getter" ],
    [ "Getter< SwapEndianess, T, false >", "struct_assimp_1_1_intern_1_1_getter_3_01_swap_endianess_00_01_t_00_01false_01_4.html", "struct_assimp_1_1_intern_1_1_getter_3_01_swap_endianess_00_01_t_00_01false_01_4" ],
    [ "minus", "struct_assimp_1_1_intern_1_1minus.html", "struct_assimp_1_1_intern_1_1minus" ],
    [ "multiplies", "struct_assimp_1_1_intern_1_1multiplies.html", "struct_assimp_1_1_intern_1_1multiplies" ],
    [ "plus", "struct_assimp_1_1_intern_1_1plus.html", "struct_assimp_1_1_intern_1_1plus" ]
];
var namespace_assimp_1_1_profiling =
[
    [ "Profiler", "class_assimp_1_1_profiling_1_1_profiler.html", "class_assimp_1_1_profiling_1_1_profiler" ]
];
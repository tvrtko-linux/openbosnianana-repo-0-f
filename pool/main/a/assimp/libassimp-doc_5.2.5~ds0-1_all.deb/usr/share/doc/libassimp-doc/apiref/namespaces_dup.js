var namespaces_dup =
[
    [ "Assimp", "namespace_assimp.html", "namespace_assimp" ]
];
var pbrmaterial_8h =
[
    [ "AI_MATKEY_GLTF_MATERIAL_CLEARCOAT_FACTOR", "pbrmaterial_8h.html#a0fb83ba857f7edffccdcfd902c48df2d", null ],
    [ "AI_MATKEY_GLTF_MATERIAL_CLEARCOAT_NORMAL_TEXTURE", "pbrmaterial_8h.html#a38f9188040fd98c5d5a93aaa72675894", null ],
    [ "AI_MATKEY_GLTF_MATERIAL_CLEARCOAT_ROUGHNESS_FACTOR", "pbrmaterial_8h.html#ac1299272d3df9afbb8721b40ec32c898", null ],
    [ "AI_MATKEY_GLTF_MATERIAL_CLEARCOAT_ROUGHNESS_TEXTURE", "pbrmaterial_8h.html#a287792e0ba57686215ee12aba49b6029", null ],
    [ "AI_MATKEY_GLTF_MATERIAL_CLEARCOAT_TEXTURE", "pbrmaterial_8h.html#a17a7993808fc1965cca9d43f1abdd576", null ],
    [ "AI_MATKEY_GLTF_MATERIAL_SHEEN_COLOR_FACTOR", "pbrmaterial_8h.html#aa742ebe7b98e7ece018cad6c26a8e009", null ],
    [ "AI_MATKEY_GLTF_MATERIAL_SHEEN_COLOR_TEXTURE", "pbrmaterial_8h.html#ac48cbe733498d54f7ed1d29841aac41a", null ],
    [ "AI_MATKEY_GLTF_MATERIAL_SHEEN_ROUGHNESS_FACTOR", "pbrmaterial_8h.html#a0dcfe7ab9fad6727fb9bcfac06b51279", null ],
    [ "AI_MATKEY_GLTF_MATERIAL_SHEEN_ROUGHNESS_TEXTURE", "pbrmaterial_8h.html#a73aa1c61670b30407210c706163db74b", null ],
    [ "AI_MATKEY_GLTF_MATERIAL_TRANSMISSION_FACTOR", "pbrmaterial_8h.html#ac5c181cf716c946f461c9c7d4ba2ec03", null ],
    [ "AI_MATKEY_GLTF_MATERIAL_TRANSMISSION_TEXTURE", "pbrmaterial_8h.html#a7509e17acf607a407705c6d512c01161", null ],
    [ "AI_MATKEY_GLTF_PBRMETALLICROUGHNESS_BASE_COLOR_FACTOR", "pbrmaterial_8h.html#aaec742eb67a3722767d5b714a925e561", null ],
    [ "AI_MATKEY_GLTF_PBRMETALLICROUGHNESS_BASE_COLOR_TEXTURE", "pbrmaterial_8h.html#af706528d7fa67d9c0a13c4e2f4527be2", null ],
    [ "AI_MATKEY_GLTF_PBRMETALLICROUGHNESS_METALLIC_FACTOR", "pbrmaterial_8h.html#aabbda7c5ac4a16d6f5fe4b1964aa60da", null ],
    [ "AI_MATKEY_GLTF_PBRMETALLICROUGHNESS_ROUGHNESS_FACTOR", "pbrmaterial_8h.html#a5776c78d321a3e9cd1a8bcc0801c2356", null ],
    [ "AI_MATKEY_GLTF_PBRSPECULARGLOSSINESS", "pbrmaterial_8h.html#a7ccc8f73d6b0006c76a3136872995af8", null ],
    [ "AI_MATKEY_GLTF_PBRSPECULARGLOSSINESS_GLOSSINESS_FACTOR", "pbrmaterial_8h.html#ae8dc7df86060706872228bf0f26a6d93", null ],
    [ "AI_MATKEY_GLTF_TEXTURE_TEXCOORD", "pbrmaterial_8h.html#a40f1cd00864f590a62811eb1e23e3dd1", null ],
    [ "AI_MATKEY_GLTF_UNLIT", "pbrmaterial_8h.html#ab9118b0b3af90a8c14a9347217cb3b4c", null ],
    [ "AI_PBRMATERIAL_H_INC", "pbrmaterial_8h.html#ad89dffc6b9479250b26d9ac72234c911", null ]
];
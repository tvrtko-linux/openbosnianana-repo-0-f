var qnan_8h =
[
    [ "_IEEEDouble", "union___i_e_e_e_double.html", "union___i_e_e_e_double" ],
    [ "_IEEESingle", "union___i_e_e_e_single.html", "union___i_e_e_e_single" ],
    [ "AI_QNAN_H_INCLUDED", "qnan_8h.html#af6b38ad2b40bc1f7f630a965dd70003b", null ],
    [ "get_qnan", "qnan_8h.html#a1563bfa01954df98282cbaaf632dc95a", null ],
    [ "is_not_qnan", "qnan_8h.html#a4b93a2d042b065c5b0c068626dc54ed2", null ],
    [ "is_qnan", "qnan_8h.html#a682b18f4d3112793d4f7dd5c1a117c67", null ],
    [ "is_qnan", "qnan_8h.html#aba07171feddf4c9513c2424a630b03a5", null ],
    [ "is_special_float", "qnan_8h.html#abefbb78762da57066abee01f541de2be", null ],
    [ "is_special_float", "qnan_8h.html#ae81ad0f99eba1f73bad78e48a16df827", null ]
];
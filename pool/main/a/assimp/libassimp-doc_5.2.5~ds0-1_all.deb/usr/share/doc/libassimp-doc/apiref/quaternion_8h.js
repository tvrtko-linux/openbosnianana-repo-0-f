var quaternion_8h =
[
    [ "aiQuaterniont< TReal >", "classai_quaterniont.html", "classai_quaterniont" ],
    [ "AI_QUATERNION_H_INC", "quaternion_8h.html#a8e364f1b033380df7bbaba37b5d8aa37", null ],
    [ "aiQuaternion", "quaternion_8h.html#a90332e4974fbd571493e0f9b3b5ce707", null ]
];
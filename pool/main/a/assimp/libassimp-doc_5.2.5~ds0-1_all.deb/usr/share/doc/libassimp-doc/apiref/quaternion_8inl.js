var quaternion_8inl =
[
    [ "AI_QUATERNION_INL_INC", "quaternion_8inl.html#a212808dfb687dd8e2f4c5d16a097d08e", null ],
    [ "operator*", "quaternion_8inl.html#aee28c4effa3cdb46d64e762dd54a5194", null ]
];
var scene_8h =
[
    [ "aiNode", "structai_node.html", "structai_node" ],
    [ "aiScene", "structai_scene.html", "structai_scene" ],
    [ "AI_SCENE_FLAGS_ALLOW_SHARED", "scene_8h.html#a612c9ba4674d5d376dffd204755738d0", null ],
    [ "AI_SCENE_FLAGS_INCOMPLETE", "scene_8h.html#a64c3b662e066126207bb842fc406a745", null ],
    [ "AI_SCENE_FLAGS_NON_VERBOSE_FORMAT", "scene_8h.html#ae17f4a0adb51e554db9575cc4e1126f9", null ],
    [ "AI_SCENE_FLAGS_TERRAIN", "scene_8h.html#aedee2bca78ed19d64877da98448d2b82", null ],
    [ "AI_SCENE_FLAGS_VALIDATED", "scene_8h.html#a7a1bb84d14b26be1b1455b050559ec73", null ],
    [ "AI_SCENE_FLAGS_VALIDATION_WARNING", "scene_8h.html#a0a1ef5c25053dbc47106e84cd737ca86", null ],
    [ "AI_SCENE_H_INC", "scene_8h.html#a056ad49744f1123b1d21e008612e2fc8", null ]
];
var struct_assimp_1_1_attachment_info =
[
    [ "AttachmentInfo", "struct_assimp_1_1_attachment_info.html#a9bb6a814dd37f6524f82c04b4c939369", null ],
    [ "AttachmentInfo", "struct_assimp_1_1_attachment_info.html#adcaaddd711aff0c20397036665a7f4ac", null ],
    [ "attachToNode", "struct_assimp_1_1_attachment_info.html#a3bbce212f1e8427681a8a8ced25d866c", null ],
    [ "scene", "struct_assimp_1_1_attachment_info.html#a686b5dbdcf6eb6156b401f22349e2daa", null ]
];
var struct_assimp_1_1_bitmap_1_1_d_i_b =
[
    [ "bits_per_pixel", "struct_assimp_1_1_bitmap_1_1_d_i_b.html#afb807e26fa867909098491735d7cbc86", null ],
    [ "compression", "struct_assimp_1_1_bitmap_1_1_d_i_b.html#a8f44512e4507b2f2f574f5a75ed752a3", null ],
    [ "dib_size", "struct_assimp_1_1_bitmap_1_1_d_i_b.html#a0a5faa8d3093a2f626ebfd85abe8bc94", null ],
    [ "height", "struct_assimp_1_1_bitmap_1_1_d_i_b.html#a574c072f98b3b3728ab6d2cd46c9510a", null ],
    [ "image_size", "struct_assimp_1_1_bitmap_1_1_d_i_b.html#af7dd8666a096cd433e80b9a3ef6103f7", null ],
    [ "nb_colors", "struct_assimp_1_1_bitmap_1_1_d_i_b.html#af440f5fced97b6be82466ecbf0402b0e", null ],
    [ "nb_important_colors", "struct_assimp_1_1_bitmap_1_1_d_i_b.html#af1293883ac6b8e3d384e32a2a15fb5e5", null ],
    [ "planes", "struct_assimp_1_1_bitmap_1_1_d_i_b.html#a94b97deb6d6cfa4453fd701055fc2c5b", null ],
    [ "size", "struct_assimp_1_1_bitmap_1_1_d_i_b.html#a3f900bb044bf5acdb15df11b01d6d1fc", null ],
    [ "width", "struct_assimp_1_1_bitmap_1_1_d_i_b.html#aaf07cdb2ea0ec2281c658dcf16d11fa1", null ],
    [ "x_resolution", "struct_assimp_1_1_bitmap_1_1_d_i_b.html#af6ea407698b3210b9cb20c2f9346d4e9", null ],
    [ "y_resolution", "struct_assimp_1_1_bitmap_1_1_d_i_b.html#a762d6e3c0911dd1aef2a6d0ceea0421f", null ]
];
var struct_assimp_1_1_bitmap_1_1_header =
[
    [ "header_size", "struct_assimp_1_1_bitmap_1_1_header.html#a739559ab2c90a06a9757817ad6b63075", null ],
    [ "offset", "struct_assimp_1_1_bitmap_1_1_header.html#a914920645985790cb0d3891f161160c1", null ],
    [ "reserved1", "struct_assimp_1_1_bitmap_1_1_header.html#a3c1c022bfff7d79d567ef9a2c70f9b7d", null ],
    [ "reserved2", "struct_assimp_1_1_bitmap_1_1_header.html#a1df418b87a2ed1fd5c3661fbfbb4155c", null ],
    [ "size", "struct_assimp_1_1_bitmap_1_1_header.html#a1e75ec49a56dd7846bccaed9115a39d8", null ],
    [ "type", "struct_assimp_1_1_bitmap_1_1_header.html#a06473e47eb40838c66474e3b6155d5d1", null ]
];
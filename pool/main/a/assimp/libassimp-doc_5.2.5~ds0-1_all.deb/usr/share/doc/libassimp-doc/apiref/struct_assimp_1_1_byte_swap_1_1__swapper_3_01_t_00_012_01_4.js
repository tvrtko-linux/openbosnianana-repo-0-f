var struct_assimp_1_1_byte_swap_1_1__swapper_3_01_t_00_012_01_4 =
[
    [ "operator()", "struct_assimp_1_1_byte_swap_1_1__swapper_3_01_t_00_012_01_4.html#a5af2a409a0d5903f8dd3d03ff9dfdc83", null ]
];
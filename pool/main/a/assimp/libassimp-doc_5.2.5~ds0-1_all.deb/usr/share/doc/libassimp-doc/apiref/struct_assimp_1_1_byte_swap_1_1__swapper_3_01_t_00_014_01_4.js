var struct_assimp_1_1_byte_swap_1_1__swapper_3_01_t_00_014_01_4 =
[
    [ "operator()", "struct_assimp_1_1_byte_swap_1_1__swapper_3_01_t_00_014_01_4.html#a23f16e0b274b4a75e9bca7d0f4490e4c", null ]
];
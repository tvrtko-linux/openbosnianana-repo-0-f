var struct_assimp_1_1_byte_swap_1_1__swapper_3_01_t_00_018_01_4 =
[
    [ "operator()", "struct_assimp_1_1_byte_swap_1_1__swapper_3_01_t_00_018_01_4.html#a592a9813fb91dfd4508aa0650f12dd74", null ]
];
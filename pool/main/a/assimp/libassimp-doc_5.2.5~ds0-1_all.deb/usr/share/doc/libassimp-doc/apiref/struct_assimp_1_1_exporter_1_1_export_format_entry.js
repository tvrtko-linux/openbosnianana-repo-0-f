var struct_assimp_1_1_exporter_1_1_export_format_entry =
[
    [ "ExportFormatEntry", "struct_assimp_1_1_exporter_1_1_export_format_entry.html#ab89610d7a5b295aa8a22bceae013d76f", null ],
    [ "ExportFormatEntry", "struct_assimp_1_1_exporter_1_1_export_format_entry.html#a6a34ccd6431d47d6a9fd6d1a498d1ee5", null ],
    [ "mDescription", "struct_assimp_1_1_exporter_1_1_export_format_entry.html#a59f8bf48e35a70ac0540c9b65d4b891d", null ],
    [ "mEnforcePP", "struct_assimp_1_1_exporter_1_1_export_format_entry.html#aefb2d077aebc473ce9a6e38fd883f181", null ],
    [ "mExportFunction", "struct_assimp_1_1_exporter_1_1_export_format_entry.html#a5cf4464ae6f7f7d92aaade27f1e545f5", null ]
];
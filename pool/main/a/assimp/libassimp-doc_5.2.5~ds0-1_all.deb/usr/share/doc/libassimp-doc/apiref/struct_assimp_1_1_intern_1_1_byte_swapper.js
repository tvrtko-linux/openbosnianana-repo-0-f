var struct_assimp_1_1_intern_1_1_byte_swapper =
[
    [ "operator()", "struct_assimp_1_1_intern_1_1_byte_swapper.html#a3531b179de4ba56b6873676b1fba0205", null ]
];
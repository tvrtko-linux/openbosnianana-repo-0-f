#define HAVE_NETPBM 1

from astroplan.plots import plot_sky
from astroplan import Observer, FixedTarget

import matplotlib.pyplot as plt
from matplotlib import cm
from astropy.time import Time
from astropy.coordinates import SkyCoord
import astropy.units as u


# Get grid of times within the time_range limits
from astroplan import time_grid_from_range
time_range = Time(["2015-08-01 06:00", "2015-08-01 12:00"])
time_grid = time_grid_from_range(time_range)

subaru = Observer.at_site("Subaru")

target_table_string = """# name ra_degrees dec_degrees
Polaris 37.95456067 89.26410897
Vega 279.234734787 38.783688956
Albireo 292.68033548 27.959680072
Algol 47.042218553 40.955646675
Rigel 78.634467067 -8.201638365
Regulus 152.092962438 11.967208776"""
# Read in the table of targets
from astropy.io import ascii
target_table = ascii.read(target_table_string)
targets = [FixedTarget(coord=SkyCoord(ra=ra*u.deg, dec=dec*u.deg), name=name)
           for name, ra, dec in target_table]

plt.figure(figsize=(6,6))
cmap = cm.Set1             # Cycle through this colormap

for i, target in enumerate(targets):
    ax = plot_sky(target, subaru, time_grid,
                  style_kwargs=dict(color=cmap(float(i)/len(targets)),
                                    label=target.name))

legend = ax.legend(loc='lower center')
legend.get_frame().set_facecolor('w')
plt.show()
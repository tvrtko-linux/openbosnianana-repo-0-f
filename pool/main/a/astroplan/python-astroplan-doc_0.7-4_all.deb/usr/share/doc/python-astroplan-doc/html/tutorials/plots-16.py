from astroplan import FixedTarget
from astroplan.plots import plot_finder_image
import matplotlib.pyplot as plt

messier1 = FixedTarget.from_name("M1")
ax, hdu = plot_finder_image(messier1)
plt.tight_layout()
plt.show()
import matplotlib.pyplot as plt
import astropy.units as u
from astropy.coordinates import EarthLocation, SkyCoord
from pytz import timezone
from astropy.time import Time

from astroplan import Observer
from astroplan import FixedTarget
from astroplan.plots import plot_airmass

# Set up Observer, Target and observation time objects.
longitude = '-155d28m48.900s'
latitude = '+19d49m42.600s'
elevation = 4163 * u.m
location = EarthLocation.from_geodetic(longitude, latitude, elevation)

observer = Observer(name='Subaru Telescope',
               location=location,
               pressure=0.615 * u.bar,
               relative_humidity=0.11,
               temperature=0 * u.deg_C,
               timezone=timezone('US/Hawaii'),
               description="Subaru Telescope on Maunakea, Hawaii")

coordinates = SkyCoord('06h45m08.9173s', '-16d42m58.017s', frame='icrs')
target = FixedTarget(name='Sirius', coord=coordinates)

start_time = Time('2000-06-15 20:00:00')
end_time = Time('2000-06-16 04:00:00')
delta_t = end_time - start_time
observe_time = start_time + delta_t*np.linspace(0, 1, 75)

plot_airmass(target, observer, observe_time)
plt.tight_layout()
plt.show()
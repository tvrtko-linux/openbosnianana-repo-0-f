import matplotlib.pyplot as plt
import astropy.units as u
from astropy.coordinates import EarthLocation, SkyCoord
from pytz import timezone
from astropy.time import Time

from astroplan import Observer
from astroplan import FixedTarget
from astroplan.plots import plot_airmass

longitude = '-155d28m48.900s'
latitude = '+19d49m42.600s'
elevation = 4163 * u.m
location = EarthLocation.from_geodetic(longitude, latitude, elevation)

observer = Observer(name='Subaru Telescope',
               location=location,
               pressure=0.615 * u.bar,
               relative_humidity=0.11,
               temperature=0 * u.deg_C,
               timezone=timezone('US/Hawaii'),
               description="Subaru Telescope on Maunakea, Hawaii")

coordinates = SkyCoord('06h45m08.9173s', '-16d42m58.017s', frame='icrs')
target = FixedTarget(name='Sirius', coord=coordinates)

coordinates = SkyCoord('07h45m19.4s', '+28d01m35s', frame='icrs')
other_target = FixedTarget(name='Pollux', coord=coordinates)

observe_time = Time('2000-06-30 23:30:00') + np.linspace(-10, 10, 50)*u.hour

sirius_styles = {'linestyle': '--', 'color': 'r'}
pollux_styles = {'color': 'g'}

plot_airmass(target, observer, observe_time, style_kwargs=sirius_styles)
plot_airmass(other_target, observer, observe_time, style_kwargs=pollux_styles)

plt.legend(shadow=True, loc=2)
plt.tight_layout()
plt.show()
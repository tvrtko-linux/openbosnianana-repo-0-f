from astropy.time import Time
from astropy.coordinates import SkyCoord
import astropy.units as u

from astroplan.plots import plot_airmass, dark_style_sheet
from astroplan import Observer, FixedTarget

import numpy as np
import matplotlib.pyplot as plt

vega = FixedTarget(coord=SkyCoord(ra=279.23473479*u.deg, dec=38.78368896*u.deg))
apo = Observer.at_site('APO')

plot_airmass(vega, apo, Time('2005-01-02 19:00') + np.linspace(-5, 5, 20)*u.hour,
             style_sheet=dark_style_sheet)
plt.tight_layout()
plt.show()
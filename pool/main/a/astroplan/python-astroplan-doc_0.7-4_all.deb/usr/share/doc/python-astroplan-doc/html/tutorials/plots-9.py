from astroplan.plots import plot_airmass
import matplotlib.pyplot as plt
from astropy.time import Time
from astroplan import FixedTarget, Observer

time = Time('2018-01-02 19:00')
target = FixedTarget.from_name('HD 189733')
apo = Observer.at_site('APO')
plot_airmass(target, apo, time, brightness_shading=True, altitude_yaxis=True)
plt.tight_layout()
plt.show()
from astropy.coordinates import EarthLocation, SkyCoord
from astropy.time import Time
import astropy.units as u
import matplotlib.pyplot as plt
from pytz import timezone

from astroplan import Observer, FixedTarget
from astroplan.plots import plot_sky

longitude = '-155d28m48.900s'
latitude = '+19d49m42.600s'
elevation = 4163 * u.m
location = EarthLocation.from_geodetic(longitude, latitude, elevation)

subaru = Observer(name='Subaru Telescope',
                  location=location,
                  timezone=timezone('US/Hawaii'),
                  description="Subaru Telescope on Maunakea, Hawaii")

coordinates = SkyCoord('19h50m47.6s', '+08d52m12.0s', frame='icrs')
altair = FixedTarget(name='Altair', coord=coordinates)

coordinates = SkyCoord('18h36m56.5s', '+38d47m06.6s', frame='icrs')
vega = FixedTarget(name='Vega', coord=coordinates)

coordinates = SkyCoord('20h41m25.9s', '+45d16m49.3s', frame='icrs')
deneb = FixedTarget(name='Deneb', coord=coordinates)

start = Time('2015-06-16 06:28:40.126')
end = Time('2015-06-16 15:47:35.822')

altair_style = {'color': 'r'}
deneb_style = {'color': 'g'}

plot_sky(altair, subaru, start, style_kwargs=altair_style)
plot_sky(vega, subaru, start)
plot_sky(deneb, subaru, start, style_kwargs=deneb_style)

# Note that you don't need this code block to produce the plot.
# It reduces the plot size for the documentation.
ax = plt.gca()
box = ax.get_position()
ax.set_position([box.x0, box.y0, box.width * 0.75, box.height * 0.75])

plt.legend(loc='center left', bbox_to_anchor=(1.25, 0.5))
plt.tight_layout()
plt.show()

plot_sky(altair, subaru, end, style_kwargs=altair_style)
plot_sky(vega, subaru, end)
plot_sky(deneb, subaru, end, style_kwargs=deneb_style)

# Note that you don't need this code block to produce the plot.
# It reduces the plot size for the documentation.
ax = plt.gca()
box = ax.get_position()
ax.set_position([box.x0, box.y0, box.width * 0.75, box.height * 0.75])

plt.legend(loc='center left', bbox_to_anchor=(1.25, 0.5))
plt.tight_layout()
plt.show()
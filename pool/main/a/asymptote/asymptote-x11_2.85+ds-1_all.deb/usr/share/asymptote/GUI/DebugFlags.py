#!/usr/bin/env python3

keepFiles = False
printAsyTranscript = False
printDeconstTranscript = False

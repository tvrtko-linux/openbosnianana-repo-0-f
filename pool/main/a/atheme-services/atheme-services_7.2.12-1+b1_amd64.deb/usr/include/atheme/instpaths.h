#ifndef ATHEME_INC_INSTPATHS_H
#define ATHEME_INC_INSTPATHS_H 1

/* These don't need to be in any particular order; use alphabetical.
 *
 * If you modify this file, don't forget to modify the sed script in
 * include/Makefile.
 */

#define BINDIR          "/usr/bin"
#define DATADIR         "/var/lib/atheme"
#define DOCDIR          "/usr/share/doc/atheme-services"
#define LOCALEDIR       "/usr/share/locale"
#define LOGDIR          "/var/log/atheme"
#define MODDIR          "/usr/lib/x86_64-linux-gnu/atheme"
#define PREFIX          "/usr"
#define RUNDIR          "/var/run/atheme"
#define SHAREDIR        "/usr/share/atheme"
#define SYSCONFDIR      "/etc/atheme"

#endif /* !ATHEME_INC_INSTPATHS_H */

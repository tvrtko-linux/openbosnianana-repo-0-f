/*
 * Copyright (C) 2005 William Pitcock, et al.
 * Rights to this code are as documented in doc/LICENSE.
 *
 * This code contains the channel mode definitions for ircnet ircd.
 *
 */

#ifndef INC_PROTO_IRCNET_H
#define INC_PROTO_IRCNET_H

/* Extended channel modes will eventually go here. */

#endif /* !INC_PROTO_IRCNET_H */

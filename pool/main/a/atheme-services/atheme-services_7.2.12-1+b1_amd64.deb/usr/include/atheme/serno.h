#ifndef ATHEME_INC_SERNO_H
#define ATHEME_INC_SERNO_H 1

#define SERNO "v7.2.12-0-g937b61ee1a3b6117dd44"

#endif /* !ATHEME_INC_SERNO_H */

require 'net/irc'

# monkey hack
module Net::IRC
  module_function :low_quote, :low_dequote
end

module Atig
  VERSION = "0.6.1"
end

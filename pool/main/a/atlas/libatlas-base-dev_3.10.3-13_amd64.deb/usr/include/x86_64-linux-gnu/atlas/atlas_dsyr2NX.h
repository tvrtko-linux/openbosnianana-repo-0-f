#ifndef ATLAS_DSYR2_H
   #define ATLAS_DSYR2_H
   #define ATL_S2NX 48
#endif

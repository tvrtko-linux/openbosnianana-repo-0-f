#ifndef ATL_ZSYSINFO_H
   #define ATL_ZSYSINFO_H

#define ATL_NOMULADD
#define ATL_L1elts 4096
#define ATL_fplat  5
#define ATL_lbnreg 16
#define ATL_mmnreg 16
#define ATL_nkflop 3055381

#endif

#ifndef DXOVER_H
#define DXOVER_H

#define ATL_3NB 168
#define NN_MNK_M 50400
#define NN_MNK_N 2240000
#define NN_MNK_MN 94080
#define NN_MNK_K 80864
#define NN_MNK_GE 54872
#define NT_MNK_M 123704
#define NT_MNK_N 80864
#define NT_MNK_MN 119168
#define NT_MNK_K 123704
#define NT_MNK_GE 103823
#define TN_MNK_M 12600
#define TN_MNK_N 80864
#define TN_MNK_MN 119168
#define TN_MNK_K 5600
#define TN_MNK_GE 27000
#define TT_MNK_M 50400
#define TT_MNK_N 80864
#define TT_MNK_MN 94080
#define TT_MNK_K 5600
#define TT_MNK_GE 592704

#endif

;;
;;;;;;
;
; HX-2016-07:
; for Clojure code
; translated from ATS
;
;;;;;;
;;

;;
;;;;;;
; beg of [bool_cats.clj]
;;;;;;
;;

;; ****** ****** ;;

(defmacro
 ats2cljpre_neg_bool0[x] `(not ~x)
)
(defmacro
 ats2cljpre_neg_bool1[x] `(not ~x)
)

;; ****** ****** ;;

;; end of [bool_cats.clj] ;;

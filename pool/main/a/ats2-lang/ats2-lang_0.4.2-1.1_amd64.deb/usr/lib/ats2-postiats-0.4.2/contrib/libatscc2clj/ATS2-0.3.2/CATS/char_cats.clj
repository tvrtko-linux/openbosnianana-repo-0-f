;;
;;;;;;
;
; HX-2016-07:
; for Clojure code
; translated from ATS
;
;;;;;;
;;

;;
;;;;;;
; beg of [char_cats.clj]
;;;;;;
;;

;; ****** ****** ;;

;; end of [char_cats.clj] ;;

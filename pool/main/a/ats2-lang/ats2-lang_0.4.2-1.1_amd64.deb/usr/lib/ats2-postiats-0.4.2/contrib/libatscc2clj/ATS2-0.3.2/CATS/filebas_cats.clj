;;;;;;
;
; HX-2016-07:
; for Clojure code translated from ATS
;
;;;;;;

;;;;;;
;beg of [filebas_cats.clj]
;;;;;;
;;
(defmacro ats2cljpre_stdin_get[] *in*)
(defmacro ats2cljpre_stdout_get[] *out*)
(defmacro ats2cljpre_stderr_get[] *err*)
;;
;;;;;;
;;;;;; end of [filebas_cats.clj] ;;;;;;

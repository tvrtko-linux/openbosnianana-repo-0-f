<?php

/*
******
*
* HX-2014-09:
* for PHP code
* translated from ATS
*
******
*/

/*
******
* beg of [filebas_cats.php]
******
*/

/* ****** ****** */
//
/*
$ats2phppre_stdin = STDIN;
$ats2phppre_stdout = STDOUT;
$ats2phppre_stderr = STDERR;
*/
//
/* ****** ****** */

function
ats2phppre_fclose_1
  ($x) { return fclose($x); }

/* ****** ****** */

function
ats2phppre_unlink_1
  ($x) { return unlink($x); }

/* ****** ****** */

function
ats2phppre_fwrite_2
  ($x1, $x2) { return fwrite($x1, $x2); }
function
ats2phppre_fwrite_3
  ($x1, $x2, $x3) { return fwrite($x1, $x2, $x3); }

/* ****** ****** */

/* end of [filebas_cats.php] */

?>

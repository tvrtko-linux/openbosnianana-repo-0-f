######
#
# HX-2016-06:
# for Python code translated from ATS
#
######

######
# beg of [random_cats.py]
######

######
import random
######

############################################

def ats2pylibc_random_random(): return random.random()

############################################

def ats2pylibc_random_randint(a, b): return random.randint(a, b)

############################################

def ats2pylibc_random_uniform(a, b): return random.uniform(a, b)

############################################

###### end of [random_cats.py] ######

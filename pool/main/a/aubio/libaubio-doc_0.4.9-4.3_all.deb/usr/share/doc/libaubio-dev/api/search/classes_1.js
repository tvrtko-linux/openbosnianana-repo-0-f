var searchData=
[
  ['fmat_5ft_0',['fmat_t',['../structfmat__t.html',1,'']]],
  ['fvec_5ft_1',['fvec_t',['../structfvec__t.html',1,'']]]
];

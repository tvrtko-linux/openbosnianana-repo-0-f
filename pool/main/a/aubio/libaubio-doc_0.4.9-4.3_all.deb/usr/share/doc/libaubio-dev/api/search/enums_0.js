var searchData=
[
  ['aubio_5flog_5flevel_0',['aubio_log_level',['../log_8h.html#af6fb372ec7b09a754961f6ab73deaf74',1,'log.h']]]
];

var searchData=
[
  ['char_5ft_0',['char_t',['../types_8h.html#a40bb5262bf908c328fbcfbe5d29d0201',1,'types.h']]]
];

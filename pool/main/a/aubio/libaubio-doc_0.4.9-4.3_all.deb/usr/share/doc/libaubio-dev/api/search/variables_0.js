var searchData=
[
  ['data_0',['data',['../structfmat__t.html#a0e57678a4423da9cfc031b87bd6ec277',1,'fmat_t::data()'],['../structfvec__t.html#a14bf045394eb718428b8cd64573caa54',1,'fvec_t::data()'],['../structlvec__t.html#a58afd973406c70aef25580291f57582f',1,'lvec_t::data()']]]
];

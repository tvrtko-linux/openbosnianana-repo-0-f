var searchData=
[
  ['norm_0',['norm',['../structcvec__t.html#a25ee232234c0585a6a4f6de27e1f8dbb',1,'cvec_t']]]
];

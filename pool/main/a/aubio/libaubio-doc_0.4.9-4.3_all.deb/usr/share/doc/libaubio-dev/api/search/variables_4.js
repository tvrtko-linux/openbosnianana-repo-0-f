var searchData=
[
  ['phas_0',['phas',['../structcvec__t.html#a3a2b1542ce3ee5d29a1c364f720a20f3',1,'cvec_t']]]
];

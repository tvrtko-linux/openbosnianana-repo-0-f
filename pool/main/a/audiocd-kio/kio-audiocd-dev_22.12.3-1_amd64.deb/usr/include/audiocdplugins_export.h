
#ifndef AUDIOCDPLUGINS_EXPORT_H
#define AUDIOCDPLUGINS_EXPORT_H

#ifdef AUDIOCDPLUGINS_STATIC_DEFINE
#  define AUDIOCDPLUGINS_EXPORT
#  define AUDIOCDPLUGINS_NO_EXPORT
#else
#  ifndef AUDIOCDPLUGINS_EXPORT
#    ifdef audiocdplugins_EXPORTS
        /* We are building this library */
#      define AUDIOCDPLUGINS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define AUDIOCDPLUGINS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef AUDIOCDPLUGINS_NO_EXPORT
#    define AUDIOCDPLUGINS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef AUDIOCDPLUGINS_EXPORT_DEPRECATED
#  define AUDIOCDPLUGINS_EXPORT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef AUDIOCDPLUGINS_EXPORT_DEPRECATED_EXPORT
#  define AUDIOCDPLUGINS_EXPORT_DEPRECATED_EXPORT AUDIOCDPLUGINS_EXPORT AUDIOCDPLUGINS_EXPORT_DEPRECATED
#endif

#ifndef AUDIOCDPLUGINS_EXPORT_DEPRECATED_NO_EXPORT
#  define AUDIOCDPLUGINS_EXPORT_DEPRECATED_NO_EXPORT AUDIOCDPLUGINS_NO_EXPORT AUDIOCDPLUGINS_EXPORT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef AUDIOCDPLUGINS_NO_DEPRECATED
#    define AUDIOCDPLUGINS_NO_DEPRECATED
#  endif
#endif

#endif /* AUDIOCDPLUGINS_EXPORT_H */

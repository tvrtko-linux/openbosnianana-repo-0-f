/*
  simple - manufacture a simple test data set for multimix
*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

double gauss(void);

/*      return normally distributed random number (zero mean, unit variance) */
double gauss()
{       int i;
 double sum=0;
 for (i = 0; i < 12; i++) sum += rand();
 return sum/RAND_MAX - 6.;
}

int main()
{
  int threshold = RAND_MAX/3;
  int i;
  double x, y;

  for (i = 0; i < 1000; i++)
    {
      if (rand() < threshold)
	{
	  x = gauss();
	  y = gauss() + 4;
	}
      else
	{
	  x = gauss()*3 + 5;
	  y = gauss()*3 + 9;
	}
      printf("%6.5f %6.5f\n", x, y);
    }
}

package Vs;

# These need to be updated as The Sleuth Kit supports more volume systems
$Vs::type{'dos'} = 1;
$Vs::type{'bsd'} = 1;
$Vs::type{'gpt'} = 1;
$Vs::type{'mac'} = 1;
$Vs::type{'sun'} = 1;

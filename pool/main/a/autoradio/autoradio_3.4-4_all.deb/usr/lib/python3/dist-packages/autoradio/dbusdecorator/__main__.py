from . import DbusAttr
from . import DbusInterface
from . import DbusMethod
from . import DbusSignal

if __name__ == '__main__':
    print(DbusAttr())
    print(DbusInterface())
    print(DbusMethod())
    print(DbusSignal())

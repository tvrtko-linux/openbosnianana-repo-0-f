from django.conf.urls.defaults import *
#from models import Fascia, Spot
#
#urlpatterns = patterns('',
#    (r'^$', 'programs.views.index'),
#    (r'^/schedule/(?P<schedule_id>\d+)/$', 'views.detail'),
#
#)

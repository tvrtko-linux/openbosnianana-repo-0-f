from django.conf.urls.defaults import *
#from models import Program, Schedule

#urlpatterns = patterns('',
#    (r'^$', 'programs.views.index'),
#    (r'^/schedule/(?P<schedule_id>\d+)/$', 'views.detail'),
#    (r'^schedule/(?P<schedule_id>\d+)/results/$', 'mysite.polls.views.results'),
#    (r'^schedule/(?P<schedule_id>\d+)/vote/$', 'mysite.polls.views.vote'),

#)

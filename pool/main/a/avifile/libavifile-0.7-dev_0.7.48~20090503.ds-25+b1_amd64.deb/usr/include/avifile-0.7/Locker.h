#ifndef AVIFILE_LOCKER_H
#define AVIFILE_LOCKER_H

#warning Use #include "avm_locker.h" instead
#include "avm_locker.h"

#endif

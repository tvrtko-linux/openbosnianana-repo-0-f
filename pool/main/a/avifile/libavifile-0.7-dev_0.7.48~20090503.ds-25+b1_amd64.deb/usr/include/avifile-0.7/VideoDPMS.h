#ifndef AVIFILE_VIDEODPMS_H
#define AVIFILE_VIDEODPMS_H

#include "avm_default.h"

#ifndef X_DISPLAY_MISSING
#include <X11/Xlib.h>
#endif

AVM_BEGIN_NAMESPACE;

class AVMEXPORT VideoDPMS
{
    Display* m_pDisplay;
    int m_iTimeoutSave;
    bool m_bDisabled;
public:
    VideoDPMS(Display* dpy);
    ~VideoDPMS();
};

AVM_END_NAMESPACE;

#endif	// AVIFILE_VIDEODPMS_H

#ifndef AVIFILE_CPUINFO_H
#define AVIFILE_CPUINFO_H

#warning Use #include "avm_cpuinfo.h" instead
#include "avm_cpuinfo.h"

#endif // AVIFILE_CPUINFO_H

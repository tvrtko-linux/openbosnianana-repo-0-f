#ifndef AVIFILE_CREATORS_H
#define AVIFILE_CREATORS_H

#warning Use #include "avm_creators.h" instead
#include "avm_creators.h"

#endif //AVIFILE_CREATORS_H

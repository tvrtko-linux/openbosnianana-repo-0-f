#ifndef AVIFILE_DEFAULT_H
#define AVIFILE_DEFAULT_H

#warning Use #include "avm_default.h" instead
#include "avm_default.h"

#endif /* AVIFILE_DEFAULT_H */

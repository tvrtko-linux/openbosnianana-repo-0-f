#ifndef AVIFILE_EXCEPT_H
#define AVIFILE_EXCEPT_H

#warning Use #include "avm_except.h" instead
#include "avm_except.h"

#endif // AVIFILE_EXCEPT_H

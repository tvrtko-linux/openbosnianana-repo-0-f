#ifndef AVIFILE_FOURCC_H
#define AVIFILE_FOURCC_H

#warning Use #include "avm_fourcc.h" instead
#include "avm_fourcc.h"

#endif

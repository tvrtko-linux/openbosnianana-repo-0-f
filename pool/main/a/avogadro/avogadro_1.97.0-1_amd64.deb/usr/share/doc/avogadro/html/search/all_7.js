var searchData=
[
  ['newmolecule_0',['newMolecule',['../class_avogadro_1_1_main_window.html#a42f102ea58fcb86165f67ecfe5f4c348',1,'Avogadro::MainWindow']]]
];

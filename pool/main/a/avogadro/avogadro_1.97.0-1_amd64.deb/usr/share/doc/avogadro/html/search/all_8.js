var searchData=
[
  ['openfile_0',['openFile',['../class_avogadro_1_1_main_window.html#a1382a4a77d66068c73ffc20e5b87b790',1,'Avogadro::MainWindow::openFile(const QString &amp;fileName, Io::FileFormat *reader=nullptr)'],['../class_avogadro_1_1_main_window.html#acd0224d6aee829fc45210f977168abb4',1,'Avogadro::MainWindow::openFile()']]],
  ['openrecentfile_1',['openRecentFile',['../class_avogadro_1_1_main_window.html#a5ac51ceae46c5ea1a8ae35ec4364c50a',1,'Avogadro::MainWindow']]]
];

var searchData=
[
  ['updaterecentfiles_0',['updateRecentFiles',['../class_avogadro_1_1_main_window.html#a6e0d3a1847dc60060c387456f338ccf5',1,'Avogadro::MainWindow']]],
  ['updatewindowtitle_1',['updateWindowTitle',['../class_avogadro_1_1_main_window.html#a1710759372596a93e98ad126dee31007',1,'Avogadro::MainWindow']]]
];

var searchData=
[
  ['aboutdialog_0',['AboutDialog',['../class_avogadro_1_1_about_dialog.html',1,'Avogadro']]],
  ['application_1',['Application',['../class_avogadro_1_1_application.html',1,'Avogadro']]]
];

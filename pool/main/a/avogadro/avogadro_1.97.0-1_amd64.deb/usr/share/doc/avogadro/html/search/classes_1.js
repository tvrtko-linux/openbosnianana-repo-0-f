var searchData=
[
  ['backgroundfileformat_0',['BackgroundFileFormat',['../class_avogadro_1_1_background_file_format.html',1,'Avogadro']]]
];

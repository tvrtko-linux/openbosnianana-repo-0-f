var searchData=
[
  ['mainwindow_0',['MainWindow',['../class_avogadro_1_1_main_window.html',1,'Avogadro']]],
  ['menubuilder_1',['MenuBuilder',['../class_avogadro_1_1_menu_builder.html',1,'Avogadro']]]
];

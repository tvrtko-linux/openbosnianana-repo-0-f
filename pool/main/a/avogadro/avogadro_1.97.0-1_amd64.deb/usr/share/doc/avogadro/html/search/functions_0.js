var searchData=
[
  ['addaction_0',['addAction',['../class_avogadro_1_1_menu_builder.html#ae87f14a89ab0e0f6d8ec7cc14a67c878',1,'Avogadro::MenuBuilder']]],
  ['addscript_1',['addScript',['../class_avogadro_1_1_main_window.html#a8081efe1e472ea803a160fdd5ca1840e',1,'Avogadro::MainWindow']]]
];

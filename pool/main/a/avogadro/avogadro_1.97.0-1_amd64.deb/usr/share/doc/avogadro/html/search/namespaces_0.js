var searchData=
[
  ['avogadro_0',['Avogadro',['../namespace_avogadro.html',1,'']]]
];

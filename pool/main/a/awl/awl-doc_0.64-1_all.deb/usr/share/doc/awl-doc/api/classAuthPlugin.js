var classAuthPlugin =
[
    [ "__construct", "classAuthPlugin.html#a210a7e57d516135f8ce9f0589202651a", null ],
    [ "Authenticate", "classAuthPlugin.html#a993c890a4ff0123d4d899cf16ebc64aa", null ],
    [ "$usr", "classAuthPlugin.html#acc77594b14083b65210a82082c47d5ee", null ]
];
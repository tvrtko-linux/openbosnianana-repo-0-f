var classAwlDBDialect =
[
    [ "__construct", "classAwlDBDialect.html#a2e28fdbd575dafc6a0c98f79f9b69a2d", null ],
    [ "GetFields", "classAwlDBDialect.html#aacd512e0767682eae6a27d24ff752fd5", null ],
    [ "GetVersion", "classAwlDBDialect.html#ad2ad6af345559d7061dcf131b19e2e7d", null ],
    [ "Quote", "classAwlDBDialect.html#a8a5cf7a5a3dfbe966cab083d4ad525d0", null ],
    [ "ReplaceNamedParameters", "classAwlDBDialect.html#a169dd0a7fa1279396b88f8382b72eba4", null ],
    [ "ReplaceParameters", "classAwlDBDialect.html#a63b763508fae0d618413bca7ac068b0d", null ],
    [ "SetSearchPath", "classAwlDBDialect.html#a47a2cdb0570923f61ae2a3564764d43b", null ],
    [ "TranslateSQL", "classAwlDBDialect.html#acde8d110e57cdf58ee51ebdd82080fd0", null ],
    [ "$db", "classAwlDBDialect.html#aa3e3873e5e9cd46d3a94453270f42684", null ],
    [ "$dialect", "classAwlDBDialect.html#a9d84d6368617ee0c401c99f07eb672e5", null ],
    [ "$version", "classAwlDBDialect.html#a5c31e9cfff69f1bcfbe4ea1827f27ee0", null ],
    [ "HttpDateFormat", "classAwlDBDialect.html#ae63c89e5bdb38bababfefd717d94d432", null ],
    [ "SqlDateFormat", "classAwlDBDialect.html#a76f561da59984857d072b364824f6c0b", null ],
    [ "SqlDurationFormat", "classAwlDBDialect.html#aefd32c1be3014caf1b6eb9dd35502efc", null ],
    [ "SqlUTCFormat", "classAwlDBDialect.html#a4e1ce432b00afbe5635a37c1adf8462e", null ]
];
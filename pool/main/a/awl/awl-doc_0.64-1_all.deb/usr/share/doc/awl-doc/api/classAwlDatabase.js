var classAwlDatabase =
[
    [ "Begin", "classAwlDatabase.html#a173dcf2f7de8994dd472974018ec5d5e", null ],
    [ "Commit", "classAwlDatabase.html#a34174dcec0b660eeabd113ec583f48a7", null ],
    [ "prepare", "classAwlDatabase.html#aba70b2e5b5c1d7b013f8bd3ea7d4b430", null ],
    [ "PrepareTranslated", "classAwlDatabase.html#a69f95e070ff39043c50dcee78c8ba706", null ],
    [ "query", "classAwlDatabase.html#a845167b22ae1f581745e2656755d8b09", null ],
    [ "Rollback", "classAwlDatabase.html#a0e79260b997375d846c7c9f66b9e3995", null ],
    [ "TransactionState", "classAwlDatabase.html#ad4549071f07d301b47228b4b6a2d2180", null ],
    [ "TranslateAll", "classAwlDatabase.html#a549daf1a72a36f33c2aba6f05ddbe85e", null ],
    [ "$translate_all", "classAwlDatabase.html#ab0e8a47e8f9a61f29ed7bff8a6aef495", null ],
    [ "$txnstate", "classAwlDatabase.html#a9ae1262681c4bdfe6191ed0a5514bac7", null ]
];
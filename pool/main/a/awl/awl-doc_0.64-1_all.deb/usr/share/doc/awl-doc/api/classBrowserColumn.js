var classBrowserColumn =
[
    [ "__construct", "classBrowserColumn.html#af1ac23a10f7d89e6adcbcf659cfdf6b7", null ],
    [ "GetTarget", "classBrowserColumn.html#a1392faad042bc66b173410b3bc78b980", null ],
    [ "RenderHeader", "classBrowserColumn.html#ab9f744167c0db7ed4aabbfc98acab1bc", null ]
];
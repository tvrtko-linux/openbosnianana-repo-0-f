var classDBRecord =
[
    [ "__construct", "classDBRecord.html#ad499b1412ecbba3ff6197db7c684b5e1", null ],
    [ "_BuildFieldList", "classDBRecord.html#abc50f5c98d984cd30359e3da82d95ff6", null ],
    [ "_BuildJoinClause", "classDBRecord.html#a09352912220d37b6ee7d43388fa80551", null ],
    [ "_BuildWhereClause", "classDBRecord.html#a8f84c8fa9b08d2daa2040be187f07c7e", null ],
    [ "AddTable", "classDBRecord.html#a4882c5feab56eba5d3d5a3ae5943a484", null ],
    [ "Get", "classDBRecord.html#a10bb31ba9753e05b8786601ea386c7ea", null ],
    [ "Initialise", "classDBRecord.html#ad0d4a0a0ef99cd8dbb997cf2f86c98ce", null ],
    [ "PostToValues", "classDBRecord.html#af098a0160001de5a3f2a574887a79107", null ],
    [ "Read", "classDBRecord.html#a648ce9618bc6e3c18e8830298052eb3d", null ],
    [ "Set", "classDBRecord.html#ac343501911222c4234cca400e7b9c6e6", null ],
    [ "Undefine", "classDBRecord.html#a074ffb1219a97a85d0be08ff230318fc", null ],
    [ "Write", "classDBRecord.html#a69e78e74a5c0d68a0140abc2b523e658", null ]
];
var classEMail =
[
    [ "__construct", "classEMail.html#a73119f6d8b99607aaf3e29178084d287", null ],
    [ "_AppendDelimited", "classEMail.html#afcadbced58ba04687f4b100901cd06f0", null ],
    [ "AddBcc", "classEMail.html#a6adfe5bed3281951fa10acc9e094df27", null ],
    [ "AddCc", "classEMail.html#a66a2830de0d48cb9729180fba339d10f", null ],
    [ "AddErrorsTo", "classEMail.html#a6338c0c8b432560475b83aa2a03cc5dd", null ],
    [ "AddReplyTo", "classEMail.html#a67b0cf070bdbe6e655b051673c93a415", null ],
    [ "AddTo", "classEMail.html#aef206ddf794c133c27775135a3f42d82", null ],
    [ "Pretend", "classEMail.html#a34d85d53abbdd2364792f8ee2a38160b", null ],
    [ "PretendLog", "classEMail.html#aff54cf28e23a465ec4bbed0946804d87", null ],
    [ "Send", "classEMail.html#afa900fcf6696aca8b8d040b7940c25ed", null ],
    [ "SetBody", "classEMail.html#a368b5ac9fe31af3346b9cc3c701782e5", null ],
    [ "SetFrom", "classEMail.html#a582dd658286a79078656bd1a2f1de264", null ],
    [ "SetSender", "classEMail.html#a9c48355fc970676435fb0bbce7ae777e", null ],
    [ "SetSubject", "classEMail.html#a81abca2c1a76d5ea7624655b0747b3f2", null ],
    [ "To", "classEMail.html#a6791a3c4e1e8f3642c11f35b21eff7e3", null ]
];
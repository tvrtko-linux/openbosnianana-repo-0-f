var classMenuOption =
[
    [ "__construct", "classMenuOption.html#a2ff527b473e487d5e205444698608b35", null ],
    [ "Active", "classMenuOption.html#adade313916eb68f3522d0f59a010dabe", null ],
    [ "AddSubmenu", "classMenuOption.html#ab2350f9d724b9a466386a100fbc16b05", null ],
    [ "IsActive", "classMenuOption.html#a27ddcca771a6c932c59b9ee128d41cdc", null ],
    [ "MaybeActive", "classMenuOption.html#aa3fdcd6d0b0d3bd0abf4375ea180f877", null ],
    [ "Render", "classMenuOption.html#ac875e646890180176bcb05d97ee54868", null ],
    [ "Set", "classMenuOption.html#afe8417a37ca39947b5e80ffc39a3dfe0", null ]
];
var classMenuSet =
[
    [ "__construct", "classMenuSet.html#a754514c76e9ac2eabaec8c342a9e3627", null ],
    [ "_CompareSequence", "classMenuSet.html#a264c10df8250d73cf55a769e1d83b173", null ],
    [ "_HasActive", "classMenuSet.html#ab2511e6ff12ff20af31fbd46ee624e65", null ],
    [ "_OptionExists", "classMenuSet.html#a0c62273332777e8612d56841614e21cf", null ],
    [ "AddOption", "classMenuSet.html#a2088f8e6e860c7776bfd4661f1b9cb9e", null ],
    [ "AddSubMenu", "classMenuSet.html#a53c3ea6981f5b5e13d0171985f641666", null ],
    [ "LinkActiveSubMenus", "classMenuSet.html#a674567ed5c77991f7fd405db2f8cf826", null ],
    [ "MakeSomethingActive", "classMenuSet.html#af1b55da0df0f50d0d21343d4823d8072", null ],
    [ "Render", "classMenuSet.html#ae893c7edfb985ca4fb7dc1c5decb10fb", null ],
    [ "RenderAsCSS", "classMenuSet.html#a55e8626d16b8fa3a4a8a87a531489a4f", null ],
    [ "Size", "classMenuSet.html#a7aef408fd123711e52b3d09f338ba75e", null ]
];
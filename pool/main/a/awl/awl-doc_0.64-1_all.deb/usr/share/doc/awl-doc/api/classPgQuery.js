var classPgQuery =
[
    [ "__construct", "classPgQuery.html#a149d0c3a372ebc7b2d9b077c075550e6", null ],
    [ "_log_error", "classPgQuery.html#a6a5b0a00bba7c2a976e8c2f22478a5e5", null ],
    [ "BuildOptionList", "classPgQuery.html#a18a8834c31a6cb361171ecacdbb452c9", null ],
    [ "Exec", "classPgQuery.html#a1eeef01c808769e3b88e0107eeaffd8e", null ],
    [ "Fetch", "classPgQuery.html#a905fe2a887677d8ba37f46538541c704", null ],
    [ "FetchBackwards", "classPgQuery.html#a89f2bf921f4d86e25447d7725d12aa1f", null ],
    [ "Plain", "classPgQuery.html#a1251778b79322edbcd184782ba8253de", null ],
    [ "quote", "classPgQuery.html#acaa79aa4efd07c55863025cfb78cfa35", null ],
    [ "rows", "classPgQuery.html#a7de148f2435d952c09a9a71100603818", null ],
    [ "SetConnection", "classPgQuery.html#afe6bfa3cea35cf1a5f1dc01782fcc8f2", null ],
    [ "UnFetch", "classPgQuery.html#a3070b636a65e271fbbc90b2bf6ff1c3f", null ]
];
var classSession =
[
    [ "__construct", "classSession.html#a220419fcb017e9587961a68c0b921107", null ],
    [ "_CheckLogin", "classSession.html#adae1fa3bdfe55fa66861d66736a62f0b", null ],
    [ "AllowedTo", "classSession.html#a9912bc780639b5c26150553d3226b0b5", null ],
    [ "AssignSessionDetails", "classSession.html#ade461179b3c769caa91fd29eede3be3b", null ],
    [ "BuildConfirmationHash", "classSession.html#a3ae5d9a43f5394aa5ddaf7262d67f2bc", null ],
    [ "CheckConfirmationHash", "classSession.html#add99613da8321f2027c87fd8d10c5967", null ],
    [ "Dbg", "classSession.html#ad162b998d7d502c974e37101e0e4102f", null ],
    [ "EmailTemporaryPassword", "classSession.html#a6ec6b672e237947e95c47ef47810905b", null ],
    [ "FormattedDate", "classSession.html#a738932d627596113f5f3c621002026bf", null ],
    [ "GetRoles", "classSession.html#a236342a66e0b8978815e1fd04c14aa94", null ],
    [ "Log", "classSession.html#addc529adb9d166e6b075e5ba20c2f1c0", null ],
    [ "Login", "classSession.html#a160527ef02773d7130b7a56824db0d68", null ],
    [ "LoginRequired", "classSession.html#ad0c113f8aeabeeb013be5ddd79ca4232", null ],
    [ "RenderLoginPanel", "classSession.html#af468bf86c34fd3b81f593f3c4aeb547c", null ],
    [ "SendTemporaryPassword", "classSession.html#a6961a54d9bdc7991aa679d8f9975955a", null ],
    [ "$roles", "classSession.html#ab3b401ac6d6400ef3b3d968bd0b594f3", null ]
];
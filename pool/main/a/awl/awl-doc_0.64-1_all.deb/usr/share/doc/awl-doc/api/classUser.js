var classUser =
[
    [ "__construct", "classUser.html#a4e0b6e353c017a9c43eae986c1d29968", null ],
    [ "AllowedTo", "classUser.html#ad152fcfaa2e23580829659354472962e", null ],
    [ "GetRoles", "classUser.html#ac1a5f3ba68f2096867ff4fc43a8cf859", null ],
    [ "Render", "classUser.html#aad83cb1e9ce913df893d60193170990a", null ],
    [ "RenderFields", "classUser.html#acfe9b9b81bee2c6bce2508bc8562b227", null ],
    [ "RenderRoles", "classUser.html#ac031b1fdbbdc446abfea2f08c820ad89", null ],
    [ "Validate", "classUser.html#afed6e821e7b2960c0d5e7a4dbf78b375", null ],
    [ "Write", "classUser.html#a46e0be5a0c2b116c9fcd5b69f459c65a", null ],
    [ "WriteRoles", "classUser.html#ab8f463b6ced967d473857189aaa23a23", null ]
];
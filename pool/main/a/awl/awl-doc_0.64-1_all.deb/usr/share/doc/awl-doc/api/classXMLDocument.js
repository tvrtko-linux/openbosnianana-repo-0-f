var classXMLDocument =
[
    [ "__construct", "classXMLDocument.html#a369bc8cafa632ef07ffe718b7515ff2c", null ],
    [ "AddNamespace", "classXMLDocument.html#af2ffd60a2b9f64c7eb505a756752b03e", null ],
    [ "CalDAVElement", "classXMLDocument.html#ad43ef39eb9841256267bc328d78d814a", null ],
    [ "CalendarserverElement", "classXMLDocument.html#a33c040d54fb65f28836c0bb6c804bfcf", null ],
    [ "CardDAVElement", "classXMLDocument.html#acdc15724f70dc942a0b0adb45ebfb84f", null ],
    [ "DAVElement", "classXMLDocument.html#a53266e7aa4a4f3c09625620168fe2f2c", null ],
    [ "DefaultNamespace", "classXMLDocument.html#ae5acaf43c7bca033711558881b1837ec", null ],
    [ "GetXmlNsArray", "classXMLDocument.html#a9018c5660fc6580af1bd902d4227063e", null ],
    [ "href", "classXMLDocument.html#a75fb7c86a3dfd5106ab98950c5333aa7", null ],
    [ "NewXMLElement", "classXMLDocument.html#a1ae6b114e13b498a281af171b217ee53", null ],
    [ "NSElement", "classXMLDocument.html#a6272dd317e2d680d3ac24959dff4a9a7", null ],
    [ "Render", "classXMLDocument.html#a1f6d99f204b188def7a0cce573b1e875", null ],
    [ "Tag", "classXMLDocument.html#a5c2503c44e827f33bdcc511d225689df", null ]
];
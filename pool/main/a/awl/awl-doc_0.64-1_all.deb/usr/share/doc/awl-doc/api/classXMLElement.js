var classXMLElement =
[
    [ "__construct", "classXMLElement.html#a31f7fc22da0770eb8894dee9974dcc63", null ],
    [ "AddSubTag", "classXMLElement.html#a7136eab5ed19be75d7d0c2e6db881031", null ],
    [ "CountElements", "classXMLElement.html#ad1964149859d308eef8082eceef20efd", null ],
    [ "GetAttribute", "classXMLElement.html#a4a356505d3c3f062b7b319c2e458ffe7", null ],
    [ "GetAttributes", "classXMLElement.html#abad546ecfb3891c9108c7fe8092b718c", null ],
    [ "GetContent", "classXMLElement.html#acb2260a7f49211e42074e3a3ca03122e", null ],
    [ "GetElements", "classXMLElement.html#a79ceb2d297072a8e08d8e058ac49ea26", null ],
    [ "GetNSTag", "classXMLElement.html#a72a82d7d72a73e48fb54997929c5d1b6", null ],
    [ "GetPath", "classXMLElement.html#a9370a3ae0814d4ac524a695409af448f", null ],
    [ "GetTag", "classXMLElement.html#a9644590e0323a3f1cb5c7d77b2659f9b", null ],
    [ "NewElement", "classXMLElement.html#a242becc7a6e0a872a80f938a87eb5224", null ],
    [ "Render", "classXMLElement.html#a6f48d9e64232be310c51842e03a67b07", null ],
    [ "RenderContent", "classXMLElement.html#a890255c3984847729166768d30d8abff", null ],
    [ "SetAttribute", "classXMLElement.html#a00a01345ae100e5f0fb6139abc665604", null ],
    [ "SetContent", "classXMLElement.html#a60b3015bcd106b1b24a8ef571f4b8787", null ]
];
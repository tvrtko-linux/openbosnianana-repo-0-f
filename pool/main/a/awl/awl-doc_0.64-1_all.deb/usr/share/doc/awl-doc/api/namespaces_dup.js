var namespaces_dup =
[
    [ "awl", "namespaceawl.html", null ]
];
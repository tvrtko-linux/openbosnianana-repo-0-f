var searchData=
[
  ['_24contained_5ftype_0',['$contained_type',['../classvCalendar.html#aeca8a742bd06c9739c5bd3dd6b68b4e9',1,'vCalendar']]],
  ['_24db_1',['$db',['../classAwlDBDialect.html#aa3e3873e5e9cd46d3a94453270f42684',1,'AwlDBDialect']]],
  ['_24dialect_2',['$dialect',['../classAwlDBDialect.html#a9d84d6368617ee0c401c99f07eb672e5',1,'AwlDBDialect']]],
  ['_24roles_3',['$roles',['../classSession.html#ab3b401ac6d6400ef3b3d968bd0b594f3',1,'Session']]],
  ['_24translate_5fall_4',['$translate_all',['../classAwlDatabase.html#ab0e8a47e8f9a61f29ed7bff8a6aef495',1,'AwlDatabase']]],
  ['_24txnstate_5',['$txnstate',['../classAwlDatabase.html#a9ae1262681c4bdfe6191ed0a5514bac7',1,'AwlDatabase']]],
  ['_24usr_6',['$usr',['../classAuthPlugin.html#acc77594b14083b65210a82082c47d5ee',1,'AuthPlugin']]],
  ['_24version_7',['$version',['../classAwlDBDialect.html#a5c31e9cfff69f1bcfbe4ea1827f27ee0',1,'AwlDBDialect']]]
];

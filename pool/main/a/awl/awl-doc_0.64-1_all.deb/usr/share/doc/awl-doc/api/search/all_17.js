var searchData=
[
  ['xmldocument_0',['XMLDocument',['../classXMLDocument.html',1,'']]],
  ['xmlelement_1',['XMLElement',['../classXMLElement.html',1,'']]]
];

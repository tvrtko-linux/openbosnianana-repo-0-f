var searchData=
[
  ['pgquery_0',['PgQuery',['../classPgQuery.html',1,'']]]
];

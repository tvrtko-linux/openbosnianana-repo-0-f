# Ayatana System Indicator &mdash; Notifications

The -notifications Ayatana System Indicator is an optional indicator that
can collect system notifications (e.g. while having been away from
keyboard. It also features filtering out notifications from specific
applications and provides a do-not-disturb feature (currently only functional
on the MATE desktop environment).

## Installation and Unit Tests

For instructions on building and running built-in tests, see the INSTALL file.

## Author and License

The -notifications Ayatana System Indicator has been written by Jason
Conti (originally as an Ubuntu System Indicator). This project has been
published under the GPL-3+ license (see COPYING file).
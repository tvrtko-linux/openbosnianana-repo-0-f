from .in_memory import InMemoryAccountInfo

assert InMemoryAccountInfo

# Note: the spaces around the equal sign ('=') are optional.
when = saturdays at 05:30

dpkg --get-selections > /var/backups/dpkg-selections.txt

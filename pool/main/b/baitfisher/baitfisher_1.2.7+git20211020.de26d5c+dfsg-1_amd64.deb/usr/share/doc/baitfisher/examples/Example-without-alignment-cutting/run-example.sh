#!/bin/sh
BaitFisher parameter.txt 1> console_output 2> console_error_output 

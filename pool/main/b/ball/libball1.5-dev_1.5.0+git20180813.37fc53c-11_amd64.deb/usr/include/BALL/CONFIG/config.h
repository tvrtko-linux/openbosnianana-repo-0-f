// -*- Mode: C++; tab-width: 2; -*-
// vi: set ts=2:

#ifndef BALL_CONFIG_CONFIG_H
#define BALL_CONFIG_CONFIG_H

// Here are some global configuration flags for BALL

// BALL_DEBUG enables some debugging methods
// change the DEBUG entry in configure to define this flag.
// If in debug mode, inline functions won't be compiled
// as inline by defining BALL_NO_INLINE_FUNCTIONS
// This facilitates debugging, as the debugger can always
// find the corresponding source code line.
// See also COMMON/debug.h for these symbols.
/* #undef BALL_DEBUG */
/* #undef BALL_VIEW_DEBUG */
/* #undef BALL_NO_INLINE_FUNCTIONS */

// BALL release version string
#define BALL_RELEASE_STRING "1.5.0"

// The path to the directory where BALL is installed.
#define BALL_PATH "/usr"
#define BALL_DATA_PATH "/usr/share/BALL-1.5/data"

// The string describes the binary format.
#define BALL_BINFMT "Linux-x86_64"

// The processor architecture
#define BALL_ARCH "x86_64"

// The operating system
#define BALL_OS "Linux"

// Some convenient shortcuts for operating systems we often encounter
// NOTE: we'd like to deprecate these, so try using BALL_OS instead
// whenever possible
#define BALL_OS_LINUX
/* #undef BALL_OS_SOLARIS */
/* #undef BALL_OS_SUNOS */
/* #undef BALL_OS_IRIX */
/* #undef BALL_OS_FREEBSD */
/* #undef BALL_OS_NETBSD */
/* #undef BALL_OS_OPENBSD */
/* #undef BALL_OS_DARWIN */
/* #undef BALL_OS_WINDOWS */

// Deprecated, only for compatibility
/* #undef BALL_PLATFORM_WINDOWS */

// Define compiler specifics

// Microsoft Visual Studio .NET
/* #undef BALL_COMPILER_MSVC */
// GNU g++
#define BALL_COMPILER_GXX
// Intel C++
/* #undef BALL_COMPILER_INTEL */
// LLVM
/* #undef BALL_COMPILER_LLVM */

// The compiler name.
#define BALL_COMPILER "GXX"

// Defines for the compiler version (major.minor.minor_minor)
#define BALL_COMPILER_VERSION 12
#define BALL_COMPILER_VERSION_MAJOR 12 
#define BALL_COMPILER_VERSION_MINOR 12
#define BALL_COMPILER_VERSION_MINOR_MINOR 12

// define symbols for the endianness of the system
#define BALL_LITTLE_ENDIAN
/* #undef BALL_BIG_ENDIAN */

// Type sizes

// This flag is defined on 64bit architectures
#define BALL_64BIT_ARCHITECTURE

// define some symbols for the (bit)size of some builtin types
#define BALL_CHAR_SIZE 1
#define BALL_SHORT_SIZE 2
#define BALL_INT_SIZE 4
#define BALL_LONG_SIZE 8
#define BALL_USHORT_SIZE 2
#define BALL_UINT_SIZE 4
#define BALL_ULONG_SIZE 8
#define BALL_SIZE_T_SIZE 8
#define BALL_POINTER_SIZE 8
#define BALL_FLOAT_SIZE 4
#define BALL_DOUBLE_SIZE 8

// define platform independant types for unsigned 16|32|64 bit numbers
#define BALL_UINT16 uint16_t
#define BALL_UINT32 uint32_t
#define BALL_UINT64 uint64_t
#define BALL_INT16 int16_t
#define BALL_INT32 int32_t
#define BALL_INT64 int64_t

// Define a signed/unsigned numeric type of 64 bit length (used for
// platform independent persistence: stores pointers)
// this usually defaults to unsigned long on 64 bit architectures
// and unsigned long long on 32 bit machines
#define BALL_ULONG64_TYPE uint64_t
#define BALL_LONG64_TYPE int64_t

// Defines an unsigned integer type of the same size as void*
#define BALL_POINTERSIZEUINT_TYPE unsigned long

// Defines an unsigned type that has the same length as size_t
#define BALL_SIZE_TYPE uint32_t

// Defines a signed type that has the same length as size_t
#define BALL_INDEX_TYPE int32_t

// Define the precision for the BALL Complex type. 
/* #undef BALL_COMPLEX_PRECISION */

// System header information
#define BALL_HAS_UNISTD_H
/* #undef BALL_HAS_PROCESS_H */
#define BALL_HAS_TIME_H
#define BALL_HAS_DIRENT_H
/* #undef BALL_HAS_DIRECT_H */
#define BALL_HAS_PWD_H
#define BALL_HAS_STDINT_H

#define BALL_HAS_SYS_TIME_H
#define BALL_HAS_SYS_STAT_H
#define BALL_HAS_SYS_TIMES_H
#define BALL_HAS_SYS_TYPES_H
#define BALL_HAS_SYS_PARAM_H
#define BALL_HAS_SYS_SYSINFO_H

// Some systems don't provide mode_t for us...
/* #undef mode_t */

// on some systems (e.g. Solaris) we need to include /usr/include/ieeefp.h
// for some floating point functions
/* #undef BALL_HAS_IEEEFP_H */

#define BALL_HAS_KILL
#define BALL_HAS_SYSCONF

// Specific to the Windows port
#ifdef BALL_OS_WINDOWS
#define BALL_HAS_WINDOWS_PERFORMANCE_COUNTER

// Keep Windows from defining min/max, ERROR,... as preprocesor symbols!
// May he how thought of defining these by default rot in hell!
#ifndef NOMINMAX
#	define NOMINMAX 1
#endif

#define NOGDI
#define NOWINRES

#define WINDOWS_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN

#endif // BALL_OS_WINDOWS

// Defines whether the C++11 thread_local keyword is supported.
// If this keyword is present, some uses of static in methods can
// be replaced by thread_local for improving the thread safety of
// BALL.
#define BALL_HAS_THREAD_LOCAL

// Defines whether the compiler supports c++11-style noexcept statements
#define BALL_HAS_NOEXCEPT

// for convencience
#ifdef BALL_HAS_NOEXCEPT
# define BALL_NOEXCEPT noexcept
#else
# define BALL_NOEXCEPT
#endif

// Defines whether the c++ std lib implementation supports const_iterators in insert, replace, ...
#define BALL_HAS_STD_STRING_CONST_ITERATOR_FUNCTIONS
#define BALL_HAS_STD_STRING_CONST_ITERATOR_INITLIST_INSERT

// Defines whether we can overload functions with LongIndex and LongSize safely
/* #undef BALL_ALLOW_LONG64_TYPE_OVERLOADS */

// This define is used in string.C and enables a workaround
// on those poor systems that do not define vsnprintf.
#define BALL_HAVE_VSNPRINTF

// This flag is used by GenericPDBFile
// if it is not set, the length of each line has
// to meet the PDB spcifications exactly.
// As virtually no existing PDB file fulfills
// this requirement, we disencourage its usage.
// Nevertheless, it can be quite useful for debugging.
/* #undef BALL_STRICT_PDB_LINE_IMPORT */

// the signature of the function arguments used in xdrrec_create differs
// from platform to platform, so we define some symbols describing the
// correct arguments: (void*, char*, int), (char*, char*, int), or (void)
// take arguments of type (void*, char*, int)
/* #undef BALL_XDRREC_CREATE_CHAR_CHAR_INT */
/* #undef BALL_XDRREC_CREATE_VOID_VOID_INT */
/* #undef BALL_XDRREC_CREATE_VOID_CHAR_INT */
/* #undef BALL_XDRREC_CREATE_VOID_VOID_UINT */
/* #undef BALL_XDRREC_CREATE_VOID */

// XDR
/* #undef BALL_HAS_XDR */

// some platforms do not provide xdr_u_hyper, so we need a workaround for this
/* #undef BALL_HAS_XDR_U_HYPER */

// Define the argument type for xdr_u_hyper (64 bit)
/* #undef BALL_XDR_UINT64_TYPE */

// flex
/* #undef BALL_HAS_YYLEX_DESTROY */

// Define whether the FFTW library/header is available.
/* #undef BALL_HAS_FFTW */
/* #undef BALL_HAS_FFTW_H */

// Define which versions of fftw can be used: double, float, long double
/* #undef BALL_HAS_FFTW_DOUBLE */
/* #undef BALL_HAS_FFTW_FLOAT */
/* #undef BALL_HAS_FFTW_LONG_DOUBLE */

// The default traits for the FFTW classes
/* #undef BALL_FFTW_DEFAULT_TRAITS */

// Define whether BALL was built with lpsolve support
/* #undef BALL_HAS_LPSOLVE */

// Define whether BALL was built with libsvm support
/* #undef BALL_HAS_LIBSVM */

// VIEW related options
#define BALL_HAS_VIEW

// Define whether BALL was built with rtfact support
/* #undef BALL_HAS_RTFACT */

//OpenBabel
/* #undef BALL_HAS_OPENBABEL */

// QT options
#define QT_THREAD_SUPPORT

// Qt WebEngine
#define BALL_HAS_QTWEBENGINE

// Glew
#define BALL_HAS_GLEW

// MPI
/* #undef BALL_HAS_MPI */

// TBB
/* #undef BALL_HAS_TBB */

// RTfact
/* #undef BALL_HAS_RTFACT */

// Define for activated PYTHON support
/* #undef BALL_PYTHON_SUPPORT */

// Maximum line length for reading from files (see source/FORMAT)
#define BALL_MAX_LINE_LENGTH 65535

#endif // BALL_CONFIG_CONFIG_H

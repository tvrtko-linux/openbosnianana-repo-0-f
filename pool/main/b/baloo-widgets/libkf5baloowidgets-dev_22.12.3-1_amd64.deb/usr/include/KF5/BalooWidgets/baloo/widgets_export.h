
#ifndef BALOO_WIDGETS_EXPORT_H
#define BALOO_WIDGETS_EXPORT_H

#ifdef BALOO_WIDGETS_STATIC_DEFINE
#  define BALOO_WIDGETS_EXPORT
#  define BALOO_WIDGETS_NO_EXPORT
#else
#  ifndef BALOO_WIDGETS_EXPORT
#    ifdef KF5BalooWidgets_EXPORTS
        /* We are building this library */
#      define BALOO_WIDGETS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define BALOO_WIDGETS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef BALOO_WIDGETS_NO_EXPORT
#    define BALOO_WIDGETS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef BALOO_WIDGETS_DEPRECATED
#  define BALOO_WIDGETS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef BALOO_WIDGETS_DEPRECATED_EXPORT
#  define BALOO_WIDGETS_DEPRECATED_EXPORT BALOO_WIDGETS_EXPORT BALOO_WIDGETS_DEPRECATED
#endif

#ifndef BALOO_WIDGETS_DEPRECATED_NO_EXPORT
#  define BALOO_WIDGETS_DEPRECATED_NO_EXPORT BALOO_WIDGETS_NO_EXPORT BALOO_WIDGETS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef BALOO_WIDGETS_NO_DEPRECATED
#    define BALOO_WIDGETS_NO_DEPRECATED
#  endif
#endif

#endif /* BALOO_WIDGETS_EXPORT_H */

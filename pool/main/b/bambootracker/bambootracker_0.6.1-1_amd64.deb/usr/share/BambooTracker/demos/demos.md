# Sample Files

## Modules

- [Dippy] - Neo Megalopolis.btm
- [HeavyViper] - sword with no scabbard
- [ImATrackMan] - Battleship.btm
- [maak] - breeze 2608.btm, Rude Buster.btm
- [Rerrah] - Lotus.btm
- [RigidatoMS] - Is This What You Desired.btm
- [SuperJet Spade] - Strategic Achievement.btm, Underwater Ruins.btm, Temple Theme.btm
- TastySnax12 - Flying High.btm
- Zexxerd - Jump.btm, Wilderness.btm

## Instruments

- [papiezak] - 2 banks (32 instruments)
- [Rerrah] - 3 banks (54 instruments)
- [Takeshi Abo] - 12 banks (255 instruments from [VAL-SOUND](http://valsound.fc2web.com))

Thanks all for samples!

[Dippy]: https://www.youtube.com/channel/UCw2xCNQhuwpnfnf1-wfRefQ
[maak]: https://twitter.com/maakmusic
[papiezak]: https://github.com/papiezak
[SuperJet Spade]: https://twitter.com/SuperJet_Spade
[RigidatoMS]: https://twitter.com/RigidatoMS
[ImATrackMan]: https://twitter.com/ImATrackMan
[Takeshi Abo]: https://twitter.com/valsound
[HeavyViper]: https://twitter.com/HeavyViper
[Rerrah]: https://github.com/rerrahkr

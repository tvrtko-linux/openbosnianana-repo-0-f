# Sample Color Schemes

- [Rerrah] - Cream.ini, Default.ini, Default-Blue.ini, Dynagray.ini, FTish.ini, Night Blue.ini
- [Yuzu] - Yuzu4K.ini

[Yuzu]: https://twitter.com/Yuzu4K
[Rerrah]: https://github.com/rerrahkr

var searchData=
[
  ['qualities_0',['Qualities',['../class_bam_tools_1_1_bam_alignment.html#a9af49d39bda11b60eb12ed4162100fd6',1,'BamTools::BamAlignment']]],
  ['querybases_1',['QueryBases',['../class_bam_tools_1_1_bam_alignment.html#aed5682a27b7bc660d45d705e4411b3d5',1,'BamTools::BamAlignment']]]
];

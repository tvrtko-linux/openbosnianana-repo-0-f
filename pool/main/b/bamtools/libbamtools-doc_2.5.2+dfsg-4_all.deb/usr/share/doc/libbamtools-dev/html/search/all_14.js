var searchData=
[
  ['uncompressed_0',['Uncompressed',['../class_bam_tools_1_1_bam_writer.html#af602e9ed717a9fb8288c46a55a6cff8aab0b9d5faf2962cfa82f7b97a9884192a',1,'BamTools::BamWriter']]],
  ['unpackdouble_1',['UnpackDouble',['../namespace_bam_tools.html#ae8ff80b95685561a3f64390e99a13eb6',1,'BamTools']]],
  ['unpackfloat_2',['UnpackFloat',['../namespace_bam_tools.html#ab48c404191e8d4b994234ac28f61fd62',1,'BamTools']]],
  ['unpacksignedint_3',['UnpackSignedInt',['../namespace_bam_tools.html#a22411da6d7641153e91878d0d406cf2e',1,'BamTools']]],
  ['unpacksignedshort_4',['UnpackSignedShort',['../namespace_bam_tools.html#a45b0b642522cd5daa01b5975b1c0b0fb',1,'BamTools']]],
  ['unpackunsignedint_5',['UnpackUnsignedInt',['../namespace_bam_tools.html#a301bcd05554045ea18fe358225566ff2',1,'BamTools']]],
  ['unpackunsignedshort_6',['UnpackUnsignedShort',['../namespace_bam_tools.html#aa8dccd65248544654a8cee1dc521c2d2',1,'BamTools']]],
  ['unsorted_7',['Unsorted',['../struct_bam_tools_1_1_algorithms_1_1_sort_1_1_unsorted.html',1,'BamTools::Algorithms::Sort']]],
  ['uri_8',['URI',['../struct_bam_tools_1_1_sam_sequence.html#af499d5b85d972cc9597d451ca539c183',1,'BamTools::SamSequence']]]
];

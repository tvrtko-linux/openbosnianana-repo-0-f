var searchData=
[
  ['z_5fdefault_5fmem_5flevel_0',['Z_DEFAULT_MEM_LEVEL',['../namespace_bam_tools_1_1_constants.html#a7e609a2244b193c11b17f045322c6638',1,'BamTools::Constants']]]
];

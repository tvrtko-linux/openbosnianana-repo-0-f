var searchData=
[
  ['descendingorder_0',['DescendingOrder',['../struct_bam_tools_1_1_algorithms_1_1_sort.html#ab00bd07c176b33933717ca362b716f61a551ab4e6dbb5a38344515ca0823b8ddd',1,'BamTools::Algorithms::Sort']]],
  ['description_1',['Description',['../struct_bam_tools_1_1_sam_read_group.html#a2dacc156b52b83496b9cdd9e55adb06e',1,'BamTools::SamReadGroup']]]
];

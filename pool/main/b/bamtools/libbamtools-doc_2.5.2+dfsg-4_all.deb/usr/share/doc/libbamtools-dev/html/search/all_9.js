var searchData=
[
  ['jump_0',['Jump',['../class_bam_tools_1_1_bam_index.html#a29066c364a1a54624ad881a3e223d757',1,'BamTools::BamIndex::Jump()'],['../class_bam_tools_1_1_bam_multi_reader.html#adabb999cbc393ecf8d268a053d987fb1',1,'BamTools::BamMultiReader::Jump()'],['../class_bam_tools_1_1_bam_reader.html#aa62d784c8348662064fe363de2b40381',1,'BamTools::BamReader::Jump()']]]
];

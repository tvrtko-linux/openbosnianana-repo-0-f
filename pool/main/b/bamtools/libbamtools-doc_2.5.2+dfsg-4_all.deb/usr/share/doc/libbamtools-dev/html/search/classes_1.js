var searchData=
[
  ['cigarop_0',['CigarOp',['../struct_bam_tools_1_1_cigar_op.html',1,'BamTools']]],
  ['customheadertag_1',['CustomHeaderTag',['../struct_bam_tools_1_1_custom_header_tag.html',1,'BamTools']]]
];

var searchData=
[
  ['refdata_0',['RefData',['../struct_bam_tools_1_1_ref_data.html',1,'BamTools']]]
];

var searchData=
[
  ['mergebycoordinate_0',['MergeByCoordinate',['../class_bam_tools_1_1_bam_multi_reader.html#abf4e4909508f19cc4f733a48aa7d1ed2a2af00a6dfb052ee8a23319acfd33839b',1,'BamTools::BamMultiReader']]],
  ['mergebyname_1',['MergeByName',['../class_bam_tools_1_1_bam_multi_reader.html#abf4e4909508f19cc4f733a48aa7d1ed2a98ab3051854a1357045117cd1a24e835',1,'BamTools::BamMultiReader']]]
];

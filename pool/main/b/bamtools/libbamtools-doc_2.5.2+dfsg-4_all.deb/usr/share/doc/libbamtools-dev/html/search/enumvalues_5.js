var searchData=
[
  ['notopen_0',['NotOpen',['../class_bam_tools_1_1_i_bam_i_o_device.html#a97309e79d2a827f02b748ebbfbe0363fa33dd1b7df3b89980411a7cfd3b9385fb',1,'BamTools::IBamIODevice']]]
];

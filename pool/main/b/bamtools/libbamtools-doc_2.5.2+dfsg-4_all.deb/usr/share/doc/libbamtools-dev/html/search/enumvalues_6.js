var searchData=
[
  ['readonly_0',['ReadOnly',['../class_bam_tools_1_1_i_bam_i_o_device.html#a97309e79d2a827f02b748ebbfbe0363fa645c01fab293cd9f7ece68482c37fb6c',1,'BamTools::IBamIODevice']]],
  ['readwrite_1',['ReadWrite',['../class_bam_tools_1_1_i_bam_i_o_device.html#a97309e79d2a827f02b748ebbfbe0363fa0f63fd0c93bb14d075885e361750144f',1,'BamTools::IBamIODevice']]],
  ['roundrobinmerge_2',['RoundRobinMerge',['../class_bam_tools_1_1_bam_multi_reader.html#abf4e4909508f19cc4f733a48aa7d1ed2a84e28c1d03be927b219307f33248f89e',1,'BamTools::BamMultiReader']]]
];

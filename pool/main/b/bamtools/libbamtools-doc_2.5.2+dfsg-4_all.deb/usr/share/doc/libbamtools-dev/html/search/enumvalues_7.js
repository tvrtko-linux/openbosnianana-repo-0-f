var searchData=
[
  ['standard_0',['STANDARD',['../class_bam_tools_1_1_bam_index.html#a3bd9db935c5805ab8dea473c2819058aa15b7d8aa9dcd545307455ba5115af430',1,'BamTools::BamIndex']]]
];

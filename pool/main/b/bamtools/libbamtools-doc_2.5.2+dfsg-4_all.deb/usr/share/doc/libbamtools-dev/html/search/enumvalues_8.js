var searchData=
[
  ['uncompressed_0',['Uncompressed',['../class_bam_tools_1_1_bam_writer.html#af602e9ed717a9fb8288c46a55a6cff8aab0b9d5faf2962cfa82f7b97a9884192a',1,'BamTools::BamWriter']]]
];

var searchData=
[
  ['writeonly_0',['WriteOnly',['../class_bam_tools_1_1_i_bam_i_o_device.html#a97309e79d2a827f02b748ebbfbe0363fa2f19dae7f3a87fd2155346fb8906a717',1,'BamTools::IBamIODevice']]]
];

var searchData=
[
  ['packunsignedint_0',['PackUnsignedInt',['../namespace_bam_tools.html#a53750928dd60a51f81fd89c050f1fc27',1,'BamTools']]],
  ['packunsignedshort_1',['PackUnsignedShort',['../namespace_bam_tools.html#ae312a004460f1d311050aee20948fe30',1,'BamTools']]]
];

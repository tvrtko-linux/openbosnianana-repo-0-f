var searchData=
[
  ['bamreaderprivate_0',['BamReaderPrivate',['../class_bam_tools_1_1_bam_alignment.html#a1ff3357da3472115c30e9b3285502bbf',1,'BamTools::BamAlignment']]],
  ['bamwriterprivate_1',['BamWriterPrivate',['../class_bam_tools_1_1_bam_alignment.html#aa01fcc0bfc0452beb435289c61d8dec8',1,'BamTools::BamAlignment']]]
];

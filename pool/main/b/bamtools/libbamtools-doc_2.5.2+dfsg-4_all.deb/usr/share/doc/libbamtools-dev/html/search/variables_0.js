var searchData=
[
  ['alignedbases_0',['AlignedBases',['../class_bam_tools_1_1_bam_alignment.html#a55d27086aca3e321cee411d43633a788',1,'BamTools::BamAlignment']]],
  ['alignmentflag_1',['AlignmentFlag',['../class_bam_tools_1_1_bam_alignment.html#a528e10f19aec995e58ec7dbdf1e35b6b',1,'BamTools::BamAlignment']]],
  ['assemblyid_2',['AssemblyID',['../struct_bam_tools_1_1_sam_sequence.html#adb1f36a9ea5880a2b41645dc50ea913a',1,'BamTools::SamSequence']]]
];

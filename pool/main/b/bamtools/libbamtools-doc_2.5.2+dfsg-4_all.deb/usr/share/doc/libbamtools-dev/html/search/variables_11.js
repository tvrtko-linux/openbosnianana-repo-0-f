var searchData=
[
  ['uri_0',['URI',['../struct_bam_tools_1_1_sam_sequence.html#af499d5b85d972cc9597d451ca539c183',1,'BamTools::SamSequence']]]
];

var searchData=
[
  ['checksum_0',['Checksum',['../struct_bam_tools_1_1_sam_sequence.html#a3ce6a3616e28add448bdd2c81cebe14b',1,'BamTools::SamSequence']]],
  ['cigardata_1',['CigarData',['../class_bam_tools_1_1_bam_alignment.html#ac7ad2244a0e268abdcdf09e97fadee3e',1,'BamTools::BamAlignment']]],
  ['cm_5fdeflate_2',['CM_DEFLATE',['../namespace_bam_tools_1_1_constants.html#a1002dc50cdf3efd08d7948bbfcaf358c',1,'BamTools::Constants']]],
  ['commandline_3',['CommandLine',['../struct_bam_tools_1_1_sam_program.html#ad1754d9c2a563f5ad3db72b84e42d03d',1,'BamTools::SamProgram']]],
  ['comments_4',['Comments',['../struct_bam_tools_1_1_sam_header.html#a4892d51db975564d20b2df39dda4369e',1,'BamTools::SamHeader']]],
  ['customtags_5',['CustomTags',['../struct_bam_tools_1_1_sam_header.html#a92cb3b3de4a559859670236fb939be94',1,'BamTools::SamHeader::CustomTags()'],['../struct_bam_tools_1_1_sam_program.html#a5733e84e40aaf9c1b4c12c538bb23a8a',1,'BamTools::SamProgram::CustomTags()'],['../struct_bam_tools_1_1_sam_read_group.html#a149c2f017ac232b4e24c1da33eb4e70b',1,'BamTools::SamReadGroup::CustomTags()'],['../struct_bam_tools_1_1_sam_sequence.html#ab62ab4cbdccc06d0d0ca21e5aff43de4',1,'BamTools::SamSequence::CustomTags()']]]
];

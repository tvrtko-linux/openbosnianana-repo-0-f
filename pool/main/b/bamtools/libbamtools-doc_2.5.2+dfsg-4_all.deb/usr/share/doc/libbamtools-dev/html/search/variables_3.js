var searchData=
[
  ['description_0',['Description',['../struct_bam_tools_1_1_sam_read_group.html#a2dacc156b52b83496b9cdd9e55adb06e',1,'BamTools::SamReadGroup']]]
];

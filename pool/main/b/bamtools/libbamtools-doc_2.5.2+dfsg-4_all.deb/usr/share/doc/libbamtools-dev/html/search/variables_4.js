var searchData=
[
  ['filename_0',['Filename',['../class_bam_tools_1_1_bam_alignment.html#abbac2cbd8b0508c36a6be13ab1aa53c4',1,'BamTools::BamAlignment']]],
  ['flg_5ffextra_1',['FLG_FEXTRA',['../namespace_bam_tools_1_1_constants.html#a70b443f3505285dfb1fea8eb6f30152e',1,'BamTools::Constants']]],
  ['floworder_2',['FlowOrder',['../struct_bam_tools_1_1_sam_read_group.html#a51e27ae1aa984c83393024d12e54a2ea',1,'BamTools::SamReadGroup']]]
];

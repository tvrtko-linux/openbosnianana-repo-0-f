var searchData=
[
  ['grouporder_0',['GroupOrder',['../struct_bam_tools_1_1_sam_header.html#a81ac2ace0ee76a2dd5d75ce0bdb499b8',1,'BamTools::SamHeader']]],
  ['gzip_5fid1_1',['GZIP_ID1',['../namespace_bam_tools_1_1_constants.html#aee658df0c9d9f30f0526649dd47d070a',1,'BamTools::Constants']]],
  ['gzip_5fid2_2',['GZIP_ID2',['../namespace_bam_tools_1_1_constants.html#af2f43258da96e8f108ef9840af01b28c',1,'BamTools::Constants']]],
  ['gzip_5fwindow_5fbits_3',['GZIP_WINDOW_BITS',['../namespace_bam_tools_1_1_constants.html#ac389ed90be1ed547275053e91574c05c',1,'BamTools::Constants']]]
];

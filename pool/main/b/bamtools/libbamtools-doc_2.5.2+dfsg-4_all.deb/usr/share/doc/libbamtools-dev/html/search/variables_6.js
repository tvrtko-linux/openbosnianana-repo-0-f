var searchData=
[
  ['id_0',['ID',['../struct_bam_tools_1_1_sam_program.html#ae589e95036e7163e7363593de540d340',1,'BamTools::SamProgram::ID()'],['../struct_bam_tools_1_1_sam_read_group.html#a8e646f2dae01515c65b9f481bdf41576',1,'BamTools::SamReadGroup::ID()']]],
  ['insertsize_1',['InsertSize',['../class_bam_tools_1_1_bam_alignment.html#a19c45c67919fb8d22d3487b3f1fcd79d',1,'BamTools::BamAlignment']]]
];

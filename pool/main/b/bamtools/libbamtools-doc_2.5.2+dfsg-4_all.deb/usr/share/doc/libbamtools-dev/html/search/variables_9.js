var searchData=
[
  ['m_5ferrorstring_0',['m_errorString',['../class_bam_tools_1_1_i_bam_i_o_device.html#a27212a1126cc9f0134539cb5e1288c0b',1,'BamTools::IBamIODevice']]],
  ['m_5fmode_1',['m_mode',['../class_bam_tools_1_1_i_bam_i_o_device.html#a56e09712e67ebbaf6e203fa13182bef4',1,'BamTools::IBamIODevice']]],
  ['mapquality_2',['MapQuality',['../class_bam_tools_1_1_bam_alignment.html#a96c235eb7645c6e0fcf5da5bfb16a2aa',1,'BamTools::BamAlignment']]],
  ['mateposition_3',['MatePosition',['../class_bam_tools_1_1_bam_alignment.html#aaef8a38689198150d0627a51b53e6352',1,'BamTools::BamAlignment']]],
  ['materefid_4',['MateRefID',['../class_bam_tools_1_1_bam_alignment.html#acbfdd5b968249c9c074943b2d1fddca8',1,'BamTools::BamAlignment']]]
];

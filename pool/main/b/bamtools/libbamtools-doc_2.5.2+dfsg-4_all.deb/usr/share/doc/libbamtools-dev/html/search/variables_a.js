var searchData=
[
  ['name_0',['Name',['../class_bam_tools_1_1_bam_alignment.html#a723d7d4ff011c2e8cb612f96cbc53daf',1,'BamTools::BamAlignment::Name()'],['../struct_bam_tools_1_1_sam_program.html#a1db41b0088eaf6d97477fa3f6104c40a',1,'BamTools::SamProgram::Name()'],['../struct_bam_tools_1_1_sam_sequence.html#a5fb630155946f6bf5fb8d6cbd7ec0aa6',1,'BamTools::SamSequence::Name()']]]
];

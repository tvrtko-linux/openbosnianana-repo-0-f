var searchData=
[
  ['platformunit_0',['PlatformUnit',['../struct_bam_tools_1_1_sam_read_group.html#a03c247af5e2dccb3c6ef121fe7e31fd4',1,'BamTools::SamReadGroup']]],
  ['position_1',['Position',['../class_bam_tools_1_1_bam_alignment.html#add167f68b38bab397a10a28708ca55cc',1,'BamTools::BamAlignment']]],
  ['predictedinsertsize_2',['PredictedInsertSize',['../struct_bam_tools_1_1_sam_read_group.html#a25c5521c2398d29d07bebefce64cfc13',1,'BamTools::SamReadGroup']]],
  ['previousprogramid_3',['PreviousProgramID',['../struct_bam_tools_1_1_sam_program.html#a7890f0688e0da803c272d7dfa0c3fd0c',1,'BamTools::SamProgram']]],
  ['productiondate_4',['ProductionDate',['../struct_bam_tools_1_1_sam_read_group.html#a41ef6e3f744ba7a0bab0e8bab421a524',1,'BamTools::SamReadGroup']]],
  ['program_5',['Program',['../struct_bam_tools_1_1_sam_read_group.html#a3f4f9215ff456dc8a82040bbdd5385e8',1,'BamTools::SamReadGroup']]],
  ['programs_6',['Programs',['../struct_bam_tools_1_1_sam_header.html#aad689b9b4dbbd211664c08f89f745b1d',1,'BamTools::SamHeader']]]
];

var searchData=
[
  ['readgroups_0',['ReadGroups',['../struct_bam_tools_1_1_sam_header.html#a0de313fc16141a0b013f90c1c524ecee',1,'BamTools::SamHeader']]],
  ['refid_1',['RefID',['../class_bam_tools_1_1_bam_alignment.html#a5e4b74de5a5d6cd3f74a5466505b97b6',1,'BamTools::BamAlignment']]],
  ['reflength_2',['RefLength',['../struct_bam_tools_1_1_ref_data.html#aaca9e72fa1855228910b9e6e274f3b45',1,'BamTools::RefData']]],
  ['refname_3',['RefName',['../struct_bam_tools_1_1_ref_data.html#a06dc4dd6f05bed1531234d49180a8402',1,'BamTools::RefData']]],
  ['rightposition_4',['RightPosition',['../struct_bam_tools_1_1_bam_region.html#a71ce3b72e5e6f74022e21055a3dd3d93',1,'BamTools::BamRegion']]],
  ['rightrefid_5',['RightRefID',['../struct_bam_tools_1_1_bam_region.html#a1e11c35bce33870dc0c65019bfe886b1',1,'BamTools::BamRegion']]]
];

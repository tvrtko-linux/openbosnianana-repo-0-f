<?php
echo("<p>Page load completed in ". (time() - $starttime) ." seconds</p>"); 
?>

</BODY>
</HTML>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TS/html4/loose.dtd">
<html>
<HEAD>
<TITLE>BandwidthD<?php if (isset($subtitle)) { echo ' - ' . $subtitle; } ?></TITLE>
<link href="bandwidthd.css" rel="stylesheet" type="text/css">
</HEAD>

<BODY>
<center>
<img src="logo.gif" alt="BandwidthD Logo">
</center>


use strict;
use warnings;

package BarnOwl::Message::Generic;

use base qw( BarnOwl::Message );

sub body { "" }


1;

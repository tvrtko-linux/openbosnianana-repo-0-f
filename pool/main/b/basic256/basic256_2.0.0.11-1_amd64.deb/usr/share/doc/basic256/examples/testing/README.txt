This folder contains programs used to test various modifications
during development and refinement. 
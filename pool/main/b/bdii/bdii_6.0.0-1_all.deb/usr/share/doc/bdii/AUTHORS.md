# Authors

## Maintainers

- Andrea Manzi <andrea.manzi@egi.eu>
- Baptiste Grenier <baptiste.grenier@egi.eu>
- Enol Fernandez <enol.fernandez@egi.eu>
- Mattias Ellert <mattias.ellert@fysast.uu.se>

## Original Authors

David Groep <davidg@nikhef.nl>

## Contributors

- Maria Alandes Pradillo <maria.alandes.pradillo@cern.ch>
- Maarten Litmaath <Maarten.Litmaath@cern.ch>
- Felix Ehm <Felix.Ehm@cern.ch>
- Andrew Elwell <Andrew.Elwell@cern.ch>
- Daniel Johansson <daniel@ndgf.org>

[GitHub contributors](https://github.com/EGI-Federation/bdii/graphs/contributors).

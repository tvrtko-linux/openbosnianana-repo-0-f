# This adds the --generate option.
# pylint: disable=invalid-name
pytest_plugins = "beancount.ingest.regression_pytest"

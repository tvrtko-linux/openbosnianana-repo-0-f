echo FILE M1044 > times.dat 
time mb < run1044.nex >> times.dat 2>&1
echo FILE M1366 >> times.dat 
time mb < run1366.nex >> times.dat 2>&1
echo FILE M1510 >> times.dat 
time mb < run1510.nex >> times.dat 2>&1
echo FILE M1748 >> times.dat 
time mb < run1748.nex >> times.dat 2>&1
echo FILE M1749 >> times.dat 
time mb < run1749.nex >> times.dat 2>&1
echo FILE M1809 >> times.dat 
time mb < run1809.nex >> times.dat 2>&1
echo FILE M336 >> times.dat 
time mb < run336.nex >> times.dat 2>&1
echo FILE M3475 >> times.dat 
time mb < run3475.nex >> times.dat 2>&1
echo FILE M501 >> times.dat 
time mb < run501.nex >> times.dat 2>&1
echo FILE M520 >> times.dat 
time mb < run520.nex >> times.dat 2>&1
echo FILE M755 >> times.dat 
time mb < run755.nex >> times.dat 2>&1
echo FILE M767 >> times.dat 
time mb < run767.nex >> times.dat 2>&1

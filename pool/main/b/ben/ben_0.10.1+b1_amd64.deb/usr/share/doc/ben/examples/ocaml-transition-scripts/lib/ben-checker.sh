#!/bin/sh

PACKAGE=$1

cd ..

if [ -f pool/$PACKAGE.fake ] || [ -f pool/${PACKAGE}_*.changes ]; then
    # The package exists in the new universe, report success
    exit 0
elif [ -f pool/$PACKAGE.log ]; then
    # A log already exists, do not retry to build
    exit 2
else
    # Package status unknown, try to build it
    exit 1
fi

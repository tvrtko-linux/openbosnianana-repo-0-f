#!/bin/sh

PACKAGE=$1

cd ..

if [ -f build/$PACKAGE.log ]; then
    mv build/$PACKAGE.log pool
fi

if [ -f build/${PACKAGE}_*.changes ]; then
    dcmd mv build/${PACKAGE}_*.changes pool
    exit 1
fi

exit 0

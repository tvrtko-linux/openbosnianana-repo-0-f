#!/bin/sh

[ -f ../build/stop ]

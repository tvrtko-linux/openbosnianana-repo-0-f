#!/bin/sh

set -e
cd ..
touch pool/stamp && make -C pool -f ../usr/lib/Makefile.pool
usr/bin/update-chroot.sh

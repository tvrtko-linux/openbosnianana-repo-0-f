#!/bin/sh

set -e

VERSION=$1
BASE=$2

cd $BASE/build
pbuilder create --basetgz ocaml-$VERSION.tgz --debootstrapopts --variant=minbase
pbuilder execute --basetgz ocaml-$VERSION.tgz --bindmounts "$BASE" --save-after-exec -- ../usr/lib/pbuilder-setup-chroot.sh $VERSION $BASE/pool
pbuilder update --basetgz ocaml-$VERSION.tgz --bindmounts "$BASE"

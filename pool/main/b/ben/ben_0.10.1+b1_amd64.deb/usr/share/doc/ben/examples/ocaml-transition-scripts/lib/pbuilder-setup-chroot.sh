#!/bin/sh

set -e

VERSION=$1
REPO=$2

useradd -s /bin/bash builder
mkdir /home/builder
chown builder:builder /home/builder

apt-get install -y pbuilder mg less ncurses-term fakeroot devscripts

cat > /etc/apt/sources.list <<EOF
deb http://ftp.fr.debian.org/debian/ sid main contrib non-free
deb-src http://ftp.fr.debian.org/debian/ sid main contrib non-free
deb [trusted=yes] file://$REPO ./
EOF

cat > /etc/apt/preferences <<EOF
Package: *
Pin: release a=unstable-ocaml
Pin-Priority: 1000
EOF

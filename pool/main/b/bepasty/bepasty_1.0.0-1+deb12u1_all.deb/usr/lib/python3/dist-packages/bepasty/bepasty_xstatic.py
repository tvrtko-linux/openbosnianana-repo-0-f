serve_files = {
    'asciinema_player': '',
    'bootbox': '/usr/share/javascript/bootbox/',
    'bootstrap': '/usr/share/javascript/bootstrap4/',
    'font_awesome': '/usr/share/fonts-font-awesome/',
    'jquery': '/usr/share/javascript/jquery/',
    'jquery_ui': '/usr/share/javascript/jquery-ui/',
    'jquery_file_upload': '/usr/share/javascript/jquery-file-upload/',
    'pygments': '',
    'font_awesome': '/usr/share/javascript/font-awesome',
    }

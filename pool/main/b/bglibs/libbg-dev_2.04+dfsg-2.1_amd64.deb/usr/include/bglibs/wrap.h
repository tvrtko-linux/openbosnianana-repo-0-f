#ifndef MSG__WRAP__H__
#define MSG__WRAP__H__

extern int wrap_exit;
extern void wrap_chdir(const char*);
extern void wrap_str(int);
extern void wrap_alloc(const void*);

#endif

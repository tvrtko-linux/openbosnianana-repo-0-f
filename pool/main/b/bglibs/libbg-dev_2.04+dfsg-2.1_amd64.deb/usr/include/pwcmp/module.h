#ifndef PW_CMP__MODULE__H__
#define PW_CMP__MODULE__H__

/* The following, single symbol must be defined by the module.
   Everything else is taken care of. */
extern int pwcmp_check(const char* plain, const char* encod);

#endif

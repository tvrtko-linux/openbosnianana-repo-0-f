Biboumi's man page index
========================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   synopsis
   admin

Synopsis
========

biboumi [*config_filename*]

# GNOME Notes

GNOME Notes, formerly "Bijiben", is a note editor designed to remain simple to use.  
(筆記本 / 笔记本 / bijiben means "notebook".)

<a href='https://flathub.org/apps/details/org.gnome.Notes'><img width='240' alt='Download on Flathub' src='https://flathub.org/assets/badges/flathub-badge-i-en.png'/></a>

## Useful links

- Homepage: <https://wiki.gnome.org/Apps/Notes>

- Report issues: <https://gitlab.gnome.org/GNOME/gnome-notes/issues/>

- Donate: <https://www.gnome.org/friends/>

- Translate: <https://wiki.gnome.org/TranslationProject>
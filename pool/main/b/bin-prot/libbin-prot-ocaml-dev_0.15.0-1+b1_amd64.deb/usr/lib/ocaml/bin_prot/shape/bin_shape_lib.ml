(** @canonical Bin_shape_lib.Bin_shape *)
module Bin_shape = Bin_shape_lib__Bin_shape


(** @canonical Bin_shape_lib.Std *)
module Std = Bin_shape_lib__Std

module Shape = Bin_shape

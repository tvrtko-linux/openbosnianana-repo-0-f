NOTE: This directory contains only a small piece of a genetic map to run the provided example. Full genetic maps can be downloaded at:

http://data.broadinstitute.org/alkesgroup/Eagle/downloads/tables/

package Bio::Tradis::Samtools;
$Bio::Tradis::Samtools::VERSION = '1.4.5';
# ABSTRACT: Change samtools syntax depending on version found


use Moose;
use File::Spec;

has 'exec'         => ( is => 'ro', isa => 'Str', default => 'samtools' );
has 'threads'      => ( is => 'ro', isa => 'Int', default => 1 );

sub find_exe {
    my ( $self, $bin ) = @_;
    for my $dir ( File::Spec->path ) {
        my $exe = File::Spec->catfile( $dir, $bin );
        return $exe if -x $exe;
    }
    return;
}


sub run_sort {
    my ( $self, $input_file, $output_file ) = @_;

    my $cmd;
    $cmd = join( ' ', ( $self->exec, 'sort', '-@', $self->threads, '-O', 'bam', '-T', $input_file.'.tmp',  '-o', $output_file, $input_file ) );
    system($cmd);
}

sub run_index {
    my ( $self, $input_file ) = @_;
    system( $self->exec . " index $input_file" );
}

no Moose;
__PACKAGE__->meta->make_immutable;

1;

__END__

=pod

=encoding UTF-8

=head1 NAME

Bio::Tradis::Samtools - Change samtools syntax depending on version found

=head1 VERSION

version 1.4.5

=head1 SYNOPSIS

Change samtools syntax depending on version found
   use Bio::Tradis::Samtools;

   my $obj = Bio::Tradis::Samtools->new(
      exec => 'samtools'
     );

   $obj->run_sort();

=head1 AUTHOR

Carla Cummins <path-help@sanger.ac.uk>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2013 by Wellcome Trust Sanger Institute.

This is free software, licensed under:

  The GNU General Public License, Version 3, June 2007

=cut

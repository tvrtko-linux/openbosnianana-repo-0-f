//
//  TestBCSequenceDNAInit.h
//  BioCocoa-test
//

/*
	Tests for the initializers of BCSequenceDNA.
	See implementation file 
*/

#import <SenTestingKit/SenTestingKit.h>


@interface TestBCSequenceDNAInit : SenTestCase
{

}

@end

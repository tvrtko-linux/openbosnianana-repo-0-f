//
//  TestBCSequenceProteinInit.h
//  BioCocoa-test
//

/*
	Tests for the initializers of BCSequenceProtein.
	See implementation file 
*/

#import <SenTestingKit/SenTestingKit.h>


@interface TestBCSequenceProteinInit : SenTestCase
{

}

@end

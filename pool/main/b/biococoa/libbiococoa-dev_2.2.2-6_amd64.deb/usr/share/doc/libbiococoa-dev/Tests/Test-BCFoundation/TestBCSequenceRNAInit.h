//
//  TestBCSequenceRNAInit.h
//  BioCocoa-test
//

/*
	Tests for the initializers of BCSequenceRNA.
	See implementation file 
*/

#import <SenTestingKit/SenTestingKit.h>


@interface TestBCSequenceRNAInit : SenTestCase
{

}

@end

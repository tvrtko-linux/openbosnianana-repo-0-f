#include "parser/parser.h"

int main()
{
    Parser calculator;
    return calculator.parse();
}

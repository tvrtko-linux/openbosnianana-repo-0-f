#ifndef INCLUDED_TOKENS_
#define INCLUDED_TOKENS_

struct Tokens
{
    // Symbolic tokens:
    enum Tokens_
    {
        NUMBER = 257,
        EOLN,
        UNARY,
    };

};

#endif

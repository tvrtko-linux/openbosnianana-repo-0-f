# the bkchem configuration file, do not edit!
 #(unless you are pretty sure that you know what you are doing, which even I am not)
BKCHEM_MODULE_PATH="/usr/share/bkchem/bkchem"
BKCHEM_TEMPLATE_PATH="/usr/share/bkchem/templates"
BKCHEM_PIXMAP_PATH="/usr/share/bkchem/pixmaps"
BKCHEM_IMAGE_PATH="/usr/share/bkchem/images"
BKCHEM_PLUGIN_PATH="/usr/share/bkchem/plugins"

var searchData=
[
  ['data_0',['data',['../structbladerf__image.html#abe222f6d3581e7920dcad5306cc906a8',1,'bladerf_image']]],
  ['dc_20calibration_1',['DC Calibration',['../group___f_n___b_l_a_d_e_r_f1___d_c___c_a_l.html',1,'']]],
  ['dc_5fref_2',['dc_ref',['../structbladerf__lms__dc__cals.html#a31b02eef31b734662bee7219035a445e',1,'bladerf_lms_dc_cals']]],
  ['den_3',['den',['../structbladerf__rational__rate.html#a79f155fae61d1864a103bcaa3bc1ed19',1,'bladerf_rational_rate']]],
  ['deprecated_20list_4',['Deprecated List',['../deprecated.html',1,'']]],
  ['describe_5',['describe',['../structbladerf__version.html#a6cb72c004e9c3001d82d2b445700d34f',1,'bladerf_version']]],
  ['device_20configuration_6',['Device Configuration',['../boilerplate.html',1,'']]],
  ['device_20properties_7',['Device properties',['../group___f_n___i_n_f_o.html',1,'']]]
];

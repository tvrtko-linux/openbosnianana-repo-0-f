var searchData=
[
  ['length_0',['length',['../structbladerf__image.html#aebb70c2aab3407a9f05334c47131a43b',1,'bladerf_image']]],
  ['libbladerf_1',['libbladeRF',['../index.html',1,'']]],
  ['libbladerf_202_2e0_20release_20notes_2',['libbladeRF 2.0 Release Notes',['../relnotes_2_0.html',1,'']]],
  ['libbladerf_2eh_3',['libbladeRF.h',['../libblade_r_f_8h.html',1,'']]],
  ['libbladerf_5fapi_5fversion_4',['LIBBLADERF_API_VERSION',['../group___f_n___l_i_b_r_a_r_y___v_e_r_s_i_o_n.html#ga3bc8497ca05618711cb1d2621f7db30f',1,'libbladeRF.h']]],
  ['library_20version_5',['Library version',['../group___f_n___l_i_b_r_a_r_y___v_e_r_s_i_o_n.html',1,'']]],
  ['lock_6',['lock',['../structbladerf__backendinfo.html#a100fdaedb8eb0d56fd262e7ea2930930',1,'bladerf_backendinfo']]],
  ['lock_5fcount_7',['lock_count',['../structbladerf__backendinfo.html#add279074b812357f316bf4a2734712e2',1,'bladerf_backendinfo']]],
  ['logging_8',['Logging',['../group___f_n___l_o_g_g_i_n_g.html',1,'']]],
  ['low_2dlevel_20accessors_9',['Low-level accessors',['../group___f_n___b_l_a_d_e_r_f1___l_o_w___l_e_v_e_l.html',1,'(Global Namespace)'],['../group___f_n___b_l_a_d_e_r_f2___l_o_w___l_e_v_e_l.html',1,'(Global Namespace)']]],
  ['low_2dlevel_20functions_10',['Low-level Functions',['../group___f_n___l_o_w___l_e_v_e_l.html',1,'']]],
  ['lpf_20bypass_11',['LPF Bypass',['../group___f_n___b_l_a_d_e_r_f1___l_p_f___b_y_p_a_s_s.html',1,'']]],
  ['lpf_5ftuning_12',['lpf_tuning',['../structbladerf__lms__dc__cals.html#a70992956f04cfc951df75a546092df96',1,'bladerf_lms_dc_cals']]]
];

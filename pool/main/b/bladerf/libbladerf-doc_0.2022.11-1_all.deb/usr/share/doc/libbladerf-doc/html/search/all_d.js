var searchData=
[
  ['patch_0',['patch',['../structbladerf__version.html#ab74656704767a7e73da4cd20dfd51a5d',1,'bladerf_version']]],
  ['phase_20detector_2ffreq_2e_20synth_20control_1',['Phase Detector/Freq. Synth Control',['../group___f_n___b_l_a_d_e_r_f2___l_o_w___l_e_v_e_l___p_l_l.html',1,'']]],
  ['port_2',['port',['../structbladerf__quick__tune.html#a2fa54f9024782843172506fadbee2ac8',1,'bladerf_quick_tune']]],
  ['power_20monitoring_3',['Power Monitoring',['../group___f_n___b_l_a_d_e_r_f2___l_o_w___l_e_v_e_l___p_m_i_c.html',1,'']]],
  ['power_20multiplexer_4',['Power Multiplexer',['../group___f_n___b_l_a_d_e_r_f2___l_o_w___l_e_v_e_l___p_o_w_e_r___s_o_u_r_c_e.html',1,'']]],
  ['product_5',['product',['../structbladerf__devinfo.html#a4369c00791073f53ce0d4c606df27c6f',1,'bladerf_devinfo']]]
];

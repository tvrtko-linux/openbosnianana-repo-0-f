var searchData=
[
  ['sample_20rate_0',['Sample rate',['../group___f_n___s_a_m_p_l_i_n_g.html',1,'']]],
  ['sampling_20mux_1',['Sampling Mux',['../group___f_n___b_l_a_d_e_r_f1___s_a_m_p_l_i_n_g___m_u_x.html',1,'']]],
  ['scale_2',['scale',['../structbladerf__range.html#a1d28dec57cce925ad92342891bd71e7c',1,'bladerf_range']]],
  ['scheduled_20tuning_3',['Scheduled Tuning',['../group___f_n___s_c_h_e_d_u_l_e_d___t_u_n_i_n_g.html',1,'']]],
  ['serial_4',['serial',['../structbladerf__devinfo.html#abe126c2e73d5e14a30c3648521a9aee0',1,'bladerf_devinfo::serial()'],['../structbladerf__image.html#aaa74f66cc1ee926c3c8e871411c8fa5f',1,'bladerf_image::serial()'],['../structbladerf__serial.html#abe126c2e73d5e14a30c3648521a9aee0',1,'bladerf_serial::serial()']]],
  ['signal_5',['signal',['../structbladerf__trigger.html#a2bea7884d40e7f7af4a9e2fa9ca39661',1,'bladerf_trigger']]],
  ['smb_20clock_20port_20control_6',['SMB clock port control',['../group___f_n___s_m_b___c_l_o_c_k.html',1,'']]],
  ['spdt_7',['spdt',['../structbladerf__quick__tune.html#a77be955e492f82e89eea9cc2d5696f85',1,'bladerf_quick_tune']]],
  ['spi_20flash_8',['SPI Flash',['../group___f_n___s_p_i___f_l_a_s_h.html',1,'']]],
  ['status_9',['status',['../structbladerf__metadata.html#ade20423e91627f07e610924cb0081623',1,'bladerf_metadata']]],
  ['step_10',['step',['../structbladerf__range.html#aa8630add62fc7df3a4559bd728d7f9b8',1,'bladerf_range']]],
  ['streaming_11',['Streaming',['../group___s_t_r_e_a_m_i_n_g.html',1,'']]],
  ['synchronous_20api_12',['Synchronous API',['../group___f_n___s_t_r_e_a_m_i_n_g___s_y_n_c.html',1,'']]],
  ['synchronous_20interface_3a_20rx_20with_20metadata_13',['Synchronous Interface: RX with Metadata',['../sync_rx_meta.html',1,'']]],
  ['synchronous_20interface_3a_20scheduled_20tx_20bursts_14',['Synchronous Interface: Scheduled TX bursts',['../sync_tx_meta_bursts.html',1,'']]]
];

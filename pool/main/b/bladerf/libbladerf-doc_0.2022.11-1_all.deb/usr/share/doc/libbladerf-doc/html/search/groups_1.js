var searchData=
[
  ['bandwidth_0',['Bandwidth',['../group___f_n___b_a_n_d_w_i_d_t_h.html',1,'']]],
  ['bias_20tee_20control_1',['Bias Tee Control',['../group___f_n___b_l_a_d_e_r_f2___b_i_a_s___t_e_e.html',1,'']]],
  ['bladerf1_2dspecific_20api_2',['bladeRF1-specific API',['../group___b_l_a_d_e_r_f1.html',1,'']]],
  ['bladerf2_2dspecific_20api_3',['bladeRF2-specific API',['../group___b_l_a_d_e_r_f2.html',1,'']]]
];

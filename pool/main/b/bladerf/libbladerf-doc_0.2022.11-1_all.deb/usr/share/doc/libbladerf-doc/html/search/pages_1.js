var searchData=
[
  ['configuration_20file_0',['Configuration File',['../configfile.html',1,'']]]
];

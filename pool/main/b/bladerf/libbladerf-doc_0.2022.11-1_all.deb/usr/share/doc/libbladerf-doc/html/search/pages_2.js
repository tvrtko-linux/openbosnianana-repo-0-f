var searchData=
[
  ['deprecated_20list_0',['Deprecated List',['../deprecated.html',1,'']]],
  ['device_20configuration_1',['Device Configuration',['../boilerplate.html',1,'']]]
];

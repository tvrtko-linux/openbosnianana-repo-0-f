var searchData=
[
  ['environment_20variables_0',['Environment Variables',['../envvars.html',1,'']]]
];

var searchData=
[
  ['frequency_20tuning_20_28bladerf1_29_0',['Frequency tuning (bladeRF1)',['../tuning.html',1,'']]]
];

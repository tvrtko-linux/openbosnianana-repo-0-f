var searchData=
[
  ['libbladerf_0',['libbladeRF',['../index.html',1,'']]],
  ['libbladerf_202_2e0_20release_20notes_1',['libbladeRF 2.0 Release Notes',['../relnotes_2_0.html',1,'']]]
];

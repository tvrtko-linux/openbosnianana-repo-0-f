var searchData=
[
  ['actual_5fcount_0',['actual_count',['../structbladerf__metadata.html#a0a144ddaed8845788d38379d7b469960',1,'bladerf_metadata']]],
  ['address_1',['address',['../structbladerf__image.html#ac0d31ca829f934cccd89f8054e02773e',1,'bladerf_image']]]
];

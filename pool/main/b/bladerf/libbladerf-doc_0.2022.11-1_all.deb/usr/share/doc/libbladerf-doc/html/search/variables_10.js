var searchData=
[
  ['vcocap_0',['vcocap',['../structbladerf__quick__tune.html#a686ab4c0f185c10e4f763cd2e6ae8964',1,'bladerf_quick_tune']]],
  ['version_1',['version',['../structbladerf__image.html#a43d7274c288b72f4cc877d48042f2f2c',1,'bladerf_image']]]
];

var searchData=
[
  ['patch_0',['patch',['../structbladerf__version.html#ab74656704767a7e73da4cd20dfd51a5d',1,'bladerf_version']]],
  ['port_1',['port',['../structbladerf__quick__tune.html#a2fa54f9024782843172506fadbee2ac8',1,'bladerf_quick_tune']]],
  ['product_2',['product',['../structbladerf__devinfo.html#a4369c00791073f53ce0d4c606df27c6f',1,'bladerf_devinfo']]]
];

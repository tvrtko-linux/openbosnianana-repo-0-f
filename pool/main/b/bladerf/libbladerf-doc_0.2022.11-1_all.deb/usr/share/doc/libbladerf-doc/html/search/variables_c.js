var searchData=
[
  ['reserved_0',['reserved',['../structbladerf__metadata.html#a60f55957c042aa67ccfc8a0d996c19bb',1,'bladerf_metadata::reserved()'],['../structbladerf__image.html#a109b0c141251e496ab3b3b6588dec2f0',1,'bladerf_image::reserved()']]],
  ['rffe_5fprofile_1',['rffe_profile',['../structbladerf__quick__tune.html#a3538aea77f8d78f36bedf8ccabbf1521',1,'bladerf_quick_tune']]],
  ['role_2',['role',['../structbladerf__trigger.html#a2cc2d40b2fe12ada278fe028f90354ce',1,'bladerf_trigger']]],
  ['rx1_5frfic_5fport_3',['rx1_rfic_port',['../structbladerf__rf__switch__config.html#aeb1bc97a9804990c9b6b1727bf21e5a9',1,'bladerf_rf_switch_config']]],
  ['rx1_5fspdt_5fport_4',['rx1_spdt_port',['../structbladerf__rf__switch__config.html#aaefe50603e9a9c9e66603d28e3ead35b',1,'bladerf_rf_switch_config']]],
  ['rx2_5frfic_5fport_5',['rx2_rfic_port',['../structbladerf__rf__switch__config.html#acfa432c32933e2f45329831b5dda6395',1,'bladerf_rf_switch_config']]],
  ['rx2_5fspdt_5fport_6',['rx2_spdt_port',['../structbladerf__rf__switch__config.html#afdcba6961ac43988568f1a6f227eb042',1,'bladerf_rf_switch_config']]],
  ['rx_5flpf_5fi_7',['rx_lpf_i',['../structbladerf__lms__dc__cals.html#a4532ebe05b25f4b7624300db68f5a38d',1,'bladerf_lms_dc_cals']]],
  ['rx_5flpf_5fq_8',['rx_lpf_q',['../structbladerf__lms__dc__cals.html#a2759bb6dcf9599cf8dc3918466c3fda6',1,'bladerf_lms_dc_cals']]],
  ['rxvga2a_5fi_9',['rxvga2a_i',['../structbladerf__lms__dc__cals.html#ae1765bb3e2905fecae15b278a808c42a',1,'bladerf_lms_dc_cals']]],
  ['rxvga2a_5fq_10',['rxvga2a_q',['../structbladerf__lms__dc__cals.html#a84750dbef613bced4b7f5c8520824921',1,'bladerf_lms_dc_cals']]],
  ['rxvga2b_5fi_11',['rxvga2b_i',['../structbladerf__lms__dc__cals.html#ac2eb71ba28504141484420addbca3865',1,'bladerf_lms_dc_cals']]],
  ['rxvga2b_5fq_12',['rxvga2b_q',['../structbladerf__lms__dc__cals.html#ac13555ea8831f183b9c851ab8a290420',1,'bladerf_lms_dc_cals']]]
];

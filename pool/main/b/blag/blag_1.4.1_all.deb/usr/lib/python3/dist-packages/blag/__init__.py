from blag.version import __VERSION__ as __VERSION__  # noqa

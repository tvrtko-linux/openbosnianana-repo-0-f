#include <blitz/array.h>
inline double p(double x) { return 2 * x; }
BZ_DECLARE_FUNCTION(p)
int main() { }

#include <blitz/array.h>

using namespace blitz;

int module2()
{
    using namespace blitz::tensor;

    Array<int,1> A(4);
    A = pow2(i);
    return 0;
}


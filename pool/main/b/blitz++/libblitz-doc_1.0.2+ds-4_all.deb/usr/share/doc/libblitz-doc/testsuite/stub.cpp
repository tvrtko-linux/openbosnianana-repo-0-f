#include "testsuite.h"
#include <blitz/array.h>

using namespace blitz;

int main()
{
    
    return 0;
}


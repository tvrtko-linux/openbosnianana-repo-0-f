#ifndef BZ_INDEXMAP_FWD
#define BZ_INDEXMAP_FWD

namespace blitz {


}

#endif

// Align escaped newlines as far left as possible

#define MY_MACRO                                                        \
    blablablablablablablabla blablablablablablablablablablablablablabla \
        blablablablablablablablablablablablablablablabla

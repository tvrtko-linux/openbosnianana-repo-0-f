// Horizontally align operands of binary and ternary expressions.
//

// clang-format off
int aaa = bbbbbbbbbbbbbbb +
          ccccccccccccccc;
// clang-format on

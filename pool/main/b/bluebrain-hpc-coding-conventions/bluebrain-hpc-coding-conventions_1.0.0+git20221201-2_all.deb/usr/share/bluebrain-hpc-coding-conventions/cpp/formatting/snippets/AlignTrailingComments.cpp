// Align trailing comments, prefixed with 2 spaces

int a;      // My comment for a
int b = 2;  // comment b

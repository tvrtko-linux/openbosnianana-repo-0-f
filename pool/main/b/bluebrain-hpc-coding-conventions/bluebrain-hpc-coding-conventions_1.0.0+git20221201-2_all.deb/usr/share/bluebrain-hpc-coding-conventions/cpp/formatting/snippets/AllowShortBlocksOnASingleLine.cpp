// Never contract short blocks on a single line

if (a) {
    return;
}

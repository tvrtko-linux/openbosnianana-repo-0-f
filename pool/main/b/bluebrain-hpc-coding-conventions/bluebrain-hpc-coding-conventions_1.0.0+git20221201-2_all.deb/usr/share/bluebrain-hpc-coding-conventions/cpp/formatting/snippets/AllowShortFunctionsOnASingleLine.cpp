// Only empty methods can be put in a single line

class Foo {
    void f() {
        foo();
    }

    void f() {}
};

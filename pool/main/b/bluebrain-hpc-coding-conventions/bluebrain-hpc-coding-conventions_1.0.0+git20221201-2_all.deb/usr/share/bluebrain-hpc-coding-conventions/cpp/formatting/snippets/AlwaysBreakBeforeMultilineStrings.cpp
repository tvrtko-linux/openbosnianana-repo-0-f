// Break before multiline strings

AAAA =
    "bbbb"
    "cccc";

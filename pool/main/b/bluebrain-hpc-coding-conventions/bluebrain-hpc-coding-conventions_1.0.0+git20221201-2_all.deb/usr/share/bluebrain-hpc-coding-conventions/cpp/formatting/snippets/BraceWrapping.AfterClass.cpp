// Opening brace is on same line than struct/class definition

class Foo {};

struct Bar {
    int i;
};

// Brace on same line than `extern "C"` directive

extern "C" {
int foo();
}

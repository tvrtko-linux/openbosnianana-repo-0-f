// Brace on same line than *namespace* definition

namespace {
int foo();
int bar();
}  // namespace

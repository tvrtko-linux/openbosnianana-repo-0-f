// Do not break before *else* block

if (foo()) {
} else {
}

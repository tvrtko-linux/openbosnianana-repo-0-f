// Indent lambda body based on the signature of the lambda

callingSomeLongLongLongLongLongLongLongLongLongLongMethod(
    [](SomeReallyLongLambdaSignatureArgument foo, SomeReallyLongLambdaSignatureArgument bar) {
        return;
    });

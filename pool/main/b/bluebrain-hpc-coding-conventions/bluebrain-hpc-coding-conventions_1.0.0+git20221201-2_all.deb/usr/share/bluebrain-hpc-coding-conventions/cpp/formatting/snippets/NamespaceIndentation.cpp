// Do not indent when entering a *namespace*

namespace out {
int i;

namespace in {
int i;
}
}  // namespace out

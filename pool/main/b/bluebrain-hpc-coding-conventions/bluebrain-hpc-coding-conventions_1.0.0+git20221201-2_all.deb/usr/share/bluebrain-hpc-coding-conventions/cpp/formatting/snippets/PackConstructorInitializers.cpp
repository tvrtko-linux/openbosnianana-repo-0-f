// The pack constructor initializers style to use.

Constructor()
    : aaaaaaaaaaaaaaaaaaaa()
    , bbbbbbbbbbbbbbbbbbbb()
    , ddddddddddddd()

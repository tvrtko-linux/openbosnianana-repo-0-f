// Different ways to arrange specifiers and qualifiers (e.g. const/volatile).

const int a;
const int* a;

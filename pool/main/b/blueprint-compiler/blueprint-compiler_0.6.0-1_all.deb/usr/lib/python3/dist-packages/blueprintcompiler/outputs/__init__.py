from ..language import UI

class OutputFormat:
    def emit(self, ui: UI) -> str:
        raise NotImplementedError()

from .xml import XmlOutput

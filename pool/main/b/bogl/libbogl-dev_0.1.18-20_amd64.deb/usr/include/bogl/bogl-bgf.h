
struct bogl_font *bogl_mmap_font(char *file, int scale);
void bogl_munmap_font(struct bogl_font *font);

// This is a place for project specific defines that might be necessary for your
// builds.  Put them here so configure doesn't clobber them
#ifndef _PROJECT_SPECIFIC_DEFINES_H_
#define _PROJECT_SPECIFIC_DEFINES_H_ 1

//#ifndef SETIATHOME
//#define SETIATHOME 1
//#define MEGS (1048576.0)
//#define ATI_MIN_RAM 222*MEGS
//#define OPENCL_ATI_MIN_RAM ATI_MIN_RAM
//#define OPENCL_NVIDIA_MIN_RAM ATI_MIN_RAM
//#undef MEGS
//#endif

//#ifndef EINSTEIN_AT_HOME
//#define EINSTEIN_AT_HOME 1
//#endif

//#ifndef _WCG
//#define _WCG 1
//#endif

#endif

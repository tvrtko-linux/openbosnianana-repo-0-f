#ifndef SVN_VERSION_H
#define SVN_VERSION_H

#include "version.h"
#define SVN_VERSION BOINC_VERSION_STRING

#endif

package main

type stair int

const (
	NormalStair stair = iota
	WinStair
)

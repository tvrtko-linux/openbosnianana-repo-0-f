/*
* Botan is released under the Simplified BSD License (see license.txt)
*/

#ifndef BOTAN_CRL_ENTRY_H_
#define BOTAN_CRL_ENTRY_H_

#include <botan/x509_crl.h>
BOTAN_DEPRECATED_HEADER(crl_ent.h)

#endif

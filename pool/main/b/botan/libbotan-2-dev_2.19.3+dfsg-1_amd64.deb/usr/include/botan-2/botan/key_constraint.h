/*
* Botan is released under the Simplified BSD License (see license.txt)
*/

#ifndef BOTAN_KEY_CONSTRAINT_H_
#define BOTAN_KEY_CONSTRAINT_H_

#include <botan/pkix_enums.h>
BOTAN_DEPRECATED_HEADER(key_constraint.h)

#endif

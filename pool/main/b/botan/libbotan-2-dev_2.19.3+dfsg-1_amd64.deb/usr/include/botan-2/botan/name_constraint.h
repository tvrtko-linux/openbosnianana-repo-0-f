/*
* Botan is released under the Simplified BSD License (see license.txt)
*/

#ifndef BOTAN_NAME_CONSTRAINT_H_
#define BOTAN_NAME_CONSTRAINT_H_

#include <botan/pkix_types.h>
BOTAN_DEPRECATED_HEADER(name_constraint.h)

#endif

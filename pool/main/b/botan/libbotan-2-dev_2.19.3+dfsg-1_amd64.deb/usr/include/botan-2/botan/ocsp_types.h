/*
* Botan is released under the Simplified BSD License (see license.txt)
*/

#ifndef BOTAN_OCSP_TYPES_H_
#define BOTAN_OCSP_TYPES_H_

#include <botan/ocsp.h>
BOTAN_DEPRECATED_HEADER(ocsp_types.h)

#endif

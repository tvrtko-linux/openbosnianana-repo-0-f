/*
* (C) 2017 Jack Lloyd
*
* Botan is released under the Simplified BSD License (see license.txt)
*/

#ifndef BOTAN_PSK_DB_SQL_H_
#define BOTAN_PSK_DB_SQL_H_

#include <botan/psk_db.h>
BOTAN_DEPRECATED_HEADER(psk_db_sql.h)

#endif

/*
* Threefish
* (C) 2013,2014 Jack Lloyd
*
* Botan is released under the Simplified BSD License (see license.txt)
*/

#ifndef BOTAN_THREEFISH_H_
#define BOTAN_THREEFISH_H_

// This header is deprecated and will be removed in a future major release

#include <botan/threefish_512.h>

BOTAN_DEPRECATED_HEADER(threefish.h)

#endif

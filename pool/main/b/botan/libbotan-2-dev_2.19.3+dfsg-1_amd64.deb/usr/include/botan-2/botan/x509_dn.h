/*
* Botan is released under the Simplified BSD License (see license.txt)
*/

#ifndef BOTAN_X509_DN_H_
#define BOTAN_X509_DN_H_

#include <botan/pkix_types.h>
BOTAN_DEPRECATED_HEADER(x509_dn.h)

#endif

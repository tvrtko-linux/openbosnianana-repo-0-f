import pyglyph

# load up fonts
fonts = pyglyph.font.LocalFontFactory('/usr/share/fonts/truetype/dejavu')
sans20 = fonts.get_font(family='DejaVu sans',
    size=20, bold=False, italic=False)

sans40 = fonts.get_font(family='DejaVu sans',
    size=40, bold=False, italic=False)

mono20 = fonts.get_font(family='DejaVu sans mono',
    size=20, bold=False, italic=False)


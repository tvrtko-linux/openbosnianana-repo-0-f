var b2__common_8h =
[
    [ "b2Version", "structb2_version.html", "structb2_version" ],
    [ "b2_aabbExtension", "b2__common_8h.html#adb86e231496fdd6ac7795ce58d40c870", null ],
    [ "b2_aabbMultiplier", "b2__common_8h.html#a7d1bd1594f20601d4079bccbd0a6a03c", null ],
    [ "b2_angularSleepTolerance", "b2__common_8h.html#a571f3e7c864aca14141b163205600eef", null ],
    [ "b2_angularSlop", "b2__common_8h.html#a67810fb101bb7a7e0b3afc14845383ee", null ],
    [ "b2_baumgarte", "b2__common_8h.html#a88e32539e0f9e69e3832e1321eba3caa", null ],
    [ "b2_linearSleepTolerance", "b2__common_8h.html#a6d882c48142a8c73011b576e20dc6dd8", null ],
    [ "b2_linearSlop", "b2__common_8h.html#a57268ade379c5c3373d0ff558b0350cf", null ],
    [ "b2_maxAngularCorrection", "b2__common_8h.html#a823e4f9a6fa4b9de3c97da696571400a", null ],
    [ "b2_maxLinearCorrection", "b2__common_8h.html#a23ab70e4809f5ee23abcd52018d5eb88", null ],
    [ "b2_maxManifoldPoints", "b2__common_8h.html#aa5f44cc9edf711433dea2b2ec94f3c42", null ],
    [ "b2_maxRotation", "b2__common_8h.html#a5808c5f1e946205d8f7458101ccc698e", null ],
    [ "b2_maxSubSteps", "b2__common_8h.html#ac1fd56e39ab8499f344b6398b7332e55", null ],
    [ "b2_maxTOIContacts", "b2__common_8h.html#aad3a54bcae5f7ec0235963403c2fccc9", null ],
    [ "b2_maxTranslation", "b2__common_8h.html#af2bad257bfbafed3665df3e243ba2b52", null ],
    [ "b2_polygonRadius", "b2__common_8h.html#afc0f934dabffb1e83e081249133ad860", null ],
    [ "b2_timeToSleep", "b2__common_8h.html#ab021adb740e4a5e1f5f7d9913ed94781", null ],
    [ "b2OpenDump", "b2__common_8h.html#ab6fcb96fe471342272c624bced36ac97", null ],
    [ "b2_version", "b2__common_8h.html#aad172c83e254377c7b646ff0377a6d1a", null ]
];
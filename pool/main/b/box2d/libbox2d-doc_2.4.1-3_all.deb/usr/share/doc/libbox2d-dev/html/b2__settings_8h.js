var b2__settings_8h =
[
    [ "b2BodyUserData", "structb2_body_user_data.html", "structb2_body_user_data" ],
    [ "b2FixtureUserData", "structb2_fixture_user_data.html", "structb2_fixture_user_data" ],
    [ "b2JointUserData", "structb2_joint_user_data.html", "structb2_joint_user_data" ],
    [ "b2_lengthUnitsPerMeter", "b2__settings_8h.html#ac981dcccb9ee291352843a27af829c8c", null ],
    [ "b2_maxPolygonVertices", "b2__settings_8h.html#a09d71ee1993bee28b5b2e6d893b41884", null ],
    [ "b2Alloc", "b2__settings_8h.html#a7cc86413ad14f195636bb93db3e15bb8", null ],
    [ "b2Alloc_Default", "b2__settings_8h.html#a0b93c7bd1142b76f72ca6aec0eef395f", null ],
    [ "b2Free", "b2__settings_8h.html#a50f4abf5edeabd0300946edbd542e24d", null ],
    [ "b2Log", "b2__settings_8h.html#a9f10095d05c74eebfe535931c9061ab2", null ],
    [ "b2Log_Default", "b2__settings_8h.html#a5bbb7f5988607acce4f0422a4683d824", null ]
];
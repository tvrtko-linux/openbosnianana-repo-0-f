var classb2_block_allocator =
[
    [ "Allocate", "classb2_block_allocator.html#a437bf775c23f6e36af11a6d1653d7040", null ],
    [ "Free", "classb2_block_allocator.html#a945fdf86e260318b930a53dcc887ca8b", null ]
];
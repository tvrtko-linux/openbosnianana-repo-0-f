var classb2_destruction_listener =
[
    [ "SayGoodbye", "classb2_destruction_listener.html#ab327c0073d162112c38d2fe8f8b9fce3", null ],
    [ "SayGoodbye", "classb2_destruction_listener.html#a6cd15baa6e5c33118cf7173ab5bf6d58", null ]
];
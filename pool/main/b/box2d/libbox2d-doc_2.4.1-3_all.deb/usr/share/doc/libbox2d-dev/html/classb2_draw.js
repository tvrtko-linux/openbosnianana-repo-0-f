var classb2_draw =
[
    [ "AppendFlags", "classb2_draw.html#acc2fd4648ee0a65574770c64528f7166", null ],
    [ "ClearFlags", "classb2_draw.html#afc240b71f4ba8c17440d6ed526d4e22e", null ],
    [ "DrawCircle", "classb2_draw.html#ac9d2741c2c0eb82e420e5c7c6656bbed", null ],
    [ "DrawPoint", "classb2_draw.html#a3202e73f617bd33d896d55f1d6464bc1", null ],
    [ "DrawPolygon", "classb2_draw.html#acd5427d1d2e7d19f1b34ad3620134d28", null ],
    [ "DrawSegment", "classb2_draw.html#a1de5aaf50db875d1c644c596832af57d", null ],
    [ "DrawSolidCircle", "classb2_draw.html#a407abb3672d4cdc9fabcbe208b2ad517", null ],
    [ "DrawSolidPolygon", "classb2_draw.html#a76f2d67de0781a32cab116278c5c9eea", null ],
    [ "DrawTransform", "classb2_draw.html#ade698123482a491a7a61fa1fe4d3a4f4", null ],
    [ "GetFlags", "classb2_draw.html#a10926d67ad6d3a2517197c4f10923700", null ],
    [ "SetFlags", "classb2_draw.html#ac2bbe31595478690e44de4ff1e7f347e", null ]
];
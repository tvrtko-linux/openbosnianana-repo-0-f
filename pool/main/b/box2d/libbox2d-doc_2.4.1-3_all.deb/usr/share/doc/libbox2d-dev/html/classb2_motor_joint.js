var classb2_motor_joint =
[
    [ "Dump", "classb2_motor_joint.html#abb67754f39b4747ae07af5cb5b348836", null ],
    [ "GetAnchorA", "classb2_motor_joint.html#a58adfab0fe79d254347a367341b0963a", null ],
    [ "GetAnchorB", "classb2_motor_joint.html#a5d563fd070f7b6cfe8db6f83e1bebbcd", null ],
    [ "GetCorrectionFactor", "classb2_motor_joint.html#a827da80c693304040cb171369af7d9ba", null ],
    [ "GetMaxForce", "classb2_motor_joint.html#a2d20421e4336350007db42caa9887101", null ],
    [ "GetMaxTorque", "classb2_motor_joint.html#aa8276f00dc2e32a0d7de6de2022e9ffa", null ],
    [ "GetReactionForce", "classb2_motor_joint.html#a5dd26e48d7820619bdf149e08ea49bcb", null ],
    [ "GetReactionTorque", "classb2_motor_joint.html#a5735431a7c29ca105ec2fb6bd6548d0e", null ],
    [ "SetAngularOffset", "classb2_motor_joint.html#aa9042733cfcac2acbc529c2fd60b15f5", null ],
    [ "SetCorrectionFactor", "classb2_motor_joint.html#a4fb5a4ee4d16bae6be450979bf3d388b", null ],
    [ "SetLinearOffset", "classb2_motor_joint.html#a99254b5fc9ed9f2d0fdccada513000c3", null ],
    [ "SetMaxForce", "classb2_motor_joint.html#aa3c2b0b06eda7fd50b8a0188d04714e0", null ],
    [ "SetMaxTorque", "classb2_motor_joint.html#a73ef23148813ca3b30e1d52d8faa43a9", null ]
];
var classb2_polygon_shape =
[
    [ "Clone", "classb2_polygon_shape.html#ae2c2343be33db465f7e83db2061fdd51", null ],
    [ "ComputeAABB", "classb2_polygon_shape.html#ae9bcc185caf4a030003cefc4576e4717", null ],
    [ "ComputeMass", "classb2_polygon_shape.html#ab9b7bf3fb10c6995b6ac3648919dfd36", null ],
    [ "GetChildCount", "classb2_polygon_shape.html#aa8bb0d5a88624104425cdee0b2f4427a", null ],
    [ "RayCast", "classb2_polygon_shape.html#a41f20072763688f1745f12f67f40e904", null ],
    [ "Set", "classb2_polygon_shape.html#a4d7b35550509f570814b97325a68966b", null ],
    [ "SetAsBox", "classb2_polygon_shape.html#ae356d825f51f7b827edb0c71fec781f8", null ],
    [ "SetAsBox", "classb2_polygon_shape.html#af80eb52027ffe85dd4d0a3110eae9d1b", null ],
    [ "TestPoint", "classb2_polygon_shape.html#a129c4ac76727fe02724f675e3fef7fe5", null ],
    [ "Validate", "classb2_polygon_shape.html#a135f4c20e17f10479e08f7befbd4d1f0", null ]
];
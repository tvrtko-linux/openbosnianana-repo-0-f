var classb2_query_callback =
[
    [ "ReportFixture", "classb2_query_callback.html#a187dd04dd0f5164fb05c2ce2cbfd9ee5", null ]
];
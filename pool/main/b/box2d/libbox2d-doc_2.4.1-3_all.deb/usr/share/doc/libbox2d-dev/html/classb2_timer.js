var classb2_timer =
[
    [ "b2Timer", "classb2_timer.html#afcc159032a8edeaa9febdf2b6cbd49a5", null ],
    [ "GetMilliseconds", "classb2_timer.html#a2b31785590ab43123553a20cefc31319", null ],
    [ "Reset", "classb2_timer.html#a367388794588e9283600437be82f2889", null ]
];
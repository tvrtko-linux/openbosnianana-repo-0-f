var searchData=
[
  ['ratio_0',['ratio',['../structb2_pulley_joint_def.html#a173782e8ef86e9e4b4c53b60f5b1b4d9',1,'b2PulleyJointDef::ratio()'],['../structb2_gear_joint_def.html#adb8dc3bcfa6e5149ba71630251edca22',1,'b2GearJointDef::ratio()']]],
  ['raycast_1',['RayCast',['../classb2_broad_phase.html#ae65392ea91c7d0839ed5312f78b2837a',1,'b2BroadPhase::RayCast()'],['../classb2_chain_shape.html#add9e88f7f90b32ae75738cfb042ef532',1,'b2ChainShape::RayCast()'],['../classb2_circle_shape.html#a442e847b9fc3d1344b02b48d490eb0c6',1,'b2CircleShape::RayCast()'],['../classb2_dynamic_tree.html#aebd2dc6ee462e0cd0763a5f472243a13',1,'b2DynamicTree::RayCast()'],['../classb2_edge_shape.html#a192cf10bd556a5a90b29a2bcee2ddd75',1,'b2EdgeShape::RayCast()'],['../classb2_fixture.html#aaaafd69aa3e1a922acc4b9d7fb49170a',1,'b2Fixture::RayCast()'],['../classb2_polygon_shape.html#a41f20072763688f1745f12f67f40e904',1,'b2PolygonShape::RayCast()'],['../classb2_shape.html#aee53a926f4fe64cd03693f6211ef6335',1,'b2Shape::RayCast()'],['../classb2_world.html#aa9955d94a254253997daaf16ce77bab6',1,'b2World::RayCast()']]],
  ['rebuildbottomup_2',['RebuildBottomUp',['../classb2_dynamic_tree.html#abd146017cfec1cf5ea7b87331f30a3ff',1,'b2DynamicTree']]],
  ['referenceangle_3',['referenceAngle',['../structb2_revolute_joint_def.html#a7d70409545eecd92b84b3d55724019e1',1,'b2RevoluteJointDef::referenceAngle()'],['../structb2_weld_joint_def.html#a88841acce3b4e88fb33997a2f9eedb52',1,'b2WeldJointDef::referenceAngle()'],['../structb2_prismatic_joint_def.html#abdfbcaa344eeebd0c0bf07e1030bc285',1,'b2PrismaticJointDef::referenceAngle()']]],
  ['references_4',['References',['../md_docs_references.html',1,'']]],
  ['refilter_5',['Refilter',['../classb2_fixture.html#a45d3320f94811d67383c48466165fa26',1,'b2Fixture']]],
  ['reportfixture_6',['ReportFixture',['../classb2_query_callback.html#a187dd04dd0f5164fb05c2ce2cbfd9ee5',1,'b2QueryCallback::ReportFixture()'],['../classb2_ray_cast_callback.html#ae0a13ab4fe2f4a7b501445af1a01ebb1',1,'b2RayCastCallback::ReportFixture()']]],
  ['reset_7',['Reset',['../classb2_timer.html#a367388794588e9283600437be82f2889',1,'b2Timer']]],
  ['resetfriction_8',['ResetFriction',['../classb2_contact.html#ad66d9290da187cef4c9f48c5766d4460',1,'b2Contact']]],
  ['resetmassdata_9',['ResetMassData',['../classb2_body.html#a109d8567c6ae84c61fce2919fb209c63',1,'b2Body']]],
  ['resetrestitution_10',['ResetRestitution',['../classb2_contact.html#a243501bc5c146e9eb1296162d328aef1',1,'b2Contact']]],
  ['resetrestitutionthreshold_11',['ResetRestitutionThreshold',['../classb2_contact.html#ad62865984306890f8cb5369b08918c1c',1,'b2Contact']]],
  ['restitution_12',['restitution',['../structb2_fixture_def.html#a87e1f5db5b7164fc7198e18a02ee6e36',1,'b2FixtureDef']]],
  ['restitutionthreshold_13',['restitutionThreshold',['../structb2_fixture_def.html#ad56b10047e9c1b3bb317e7e5249f030c',1,'b2FixtureDef']]],
  ['revision_14',['revision',['../structb2_version.html#a395cfe1434e348115d2ead3d72b88847',1,'b2Version']]]
];

var searchData=
[
  ['updatepairs_0',['UpdatePairs',['../classb2_broad_phase.html#a0a1acd693466b997700242ae00784c20',1,'b2BroadPhase']]],
  ['upperangle_1',['upperAngle',['../structb2_revolute_joint_def.html#a59d3a65db0f9ddde1416afa1f9b635a2',1,'b2RevoluteJointDef']]],
  ['upperbound_2',['upperBound',['../structb2_a_a_b_b.html#ad4a8ec483ba13a2c02918b01d058a18f',1,'b2AABB']]],
  ['uppertranslation_3',['upperTranslation',['../structb2_prismatic_joint_def.html#a7606811782ccef96beeccbc0b56eaf34',1,'b2PrismaticJointDef::upperTranslation()'],['../structb2_wheel_joint_def.html#a63cf58bd91517985d824cd983d3c7b94',1,'b2WheelJointDef::upperTranslation()']]],
  ['userdata_4',['userData',['../structb2_body_def.html#ae913ce354e5602ddafecd5999c2db170',1,'b2BodyDef::userData()'],['../structb2_fixture_def.html#a480da3de55f826e8df9e7d2c0f7e911f',1,'b2FixtureDef::userData()'],['../structb2_joint_def.html#a78ae1ebbdd3d9b9a6b409c0b05096ded',1,'b2JointDef::userData()']]]
];

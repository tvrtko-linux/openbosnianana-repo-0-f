var searchData=
[
  ['next_0',['next',['../structb2_contact_edge.html#a9af32b3cfadf35a927f4dffcf6338a6d',1,'b2ContactEdge::next()'],['../structb2_joint_edge.html#a3d17286bc697bb620ee151e4cd07438c',1,'b2JointEdge::next()']]],
  ['normal_1',['normal',['../structb2_world_manifold.html#acf8de61b73d9784d16f7d0e824ce44bf',1,'b2WorldManifold']]],
  ['normalimpulse_2',['normalImpulse',['../structb2_manifold_point.html#a09176fb626391441d9335af818ce51f2',1,'b2ManifoldPoint']]],
  ['normalize_3',['Normalize',['../structb2_vec2.html#ae0128c95454ebf5dfe152c5644f06d21',1,'b2Vec2::Normalize()'],['../structb2_sweep.html#ad66a3086bc7656df9cf7454013a2f61b',1,'b2Sweep::Normalize()']]]
];

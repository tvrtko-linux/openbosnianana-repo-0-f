var searchData=
[
  ['loose_20ends_0',['Loose Ends',['../md_docs_loose_ends.html',1,'']]]
];

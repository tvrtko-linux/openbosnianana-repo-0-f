var searchData=
[
  ['b2_5fversion_0',['b2_version',['../b2__common_8h.html#aad172c83e254377c7b646ff0377a6d1a',1,'b2_common.h']]],
  ['bodya_1',['bodyA',['../structb2_joint_def.html#a8cd54c93da396be75a9788f2c6897f05',1,'b2JointDef']]],
  ['bodyb_2',['bodyB',['../structb2_joint_def.html#aa4f4dee2fbcd12187b19506b60e68e3d',1,'b2JointDef']]],
  ['bullet_3',['bullet',['../structb2_body_def.html#a7c0047c9a98a1d20614eeddcdbce7586',1,'b2BodyDef']]]
];

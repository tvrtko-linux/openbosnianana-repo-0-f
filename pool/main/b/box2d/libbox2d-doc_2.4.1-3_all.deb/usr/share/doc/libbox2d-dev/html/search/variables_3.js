var searchData=
[
  ['damping_0',['damping',['../structb2_distance_joint_def.html#aa488d9b1f5300e795587b844b6db0d98',1,'b2DistanceJointDef::damping()'],['../structb2_mouse_joint_def.html#a0887471452796ff614965a7518e1f5aa',1,'b2MouseJointDef::damping()'],['../structb2_weld_joint_def.html#a59dcfbbd7c8d4421b3c621946ab4ec7d',1,'b2WeldJointDef::damping()'],['../structb2_wheel_joint_def.html#abfef1664c79bc98b782cc8035931aad0',1,'b2WheelJointDef::damping()']]],
  ['density_1',['density',['../structb2_fixture_def.html#a386a1e68b7bebb7d1de64332d3bf34ce',1,'b2FixtureDef']]]
];

var searchData=
[
  ['filter_0',['filter',['../structb2_fixture_def.html#a4c3e493a13d11ab27fcc2eee9f52fd61',1,'b2FixtureDef']]],
  ['fixedrotation_1',['fixedRotation',['../structb2_body_def.html#a273a51c57440a8884de5939d76b6e3ea',1,'b2BodyDef']]],
  ['friction_2',['friction',['../structb2_fixture_def.html#a13799607109ebee16538facf1f0e1701',1,'b2FixtureDef']]]
];

var searchData=
[
  ['ratio_0',['ratio',['../structb2_gear_joint_def.html#adb8dc3bcfa6e5149ba71630251edca22',1,'b2GearJointDef::ratio()'],['../structb2_pulley_joint_def.html#a173782e8ef86e9e4b4c53b60f5b1b4d9',1,'b2PulleyJointDef::ratio()']]],
  ['referenceangle_1',['referenceAngle',['../structb2_prismatic_joint_def.html#abdfbcaa344eeebd0c0bf07e1030bc285',1,'b2PrismaticJointDef::referenceAngle()'],['../structb2_revolute_joint_def.html#a7d70409545eecd92b84b3d55724019e1',1,'b2RevoluteJointDef::referenceAngle()'],['../structb2_weld_joint_def.html#a88841acce3b4e88fb33997a2f9eedb52',1,'b2WeldJointDef::referenceAngle()']]],
  ['restitution_2',['restitution',['../structb2_fixture_def.html#a87e1f5db5b7164fc7198e18a02ee6e36',1,'b2FixtureDef']]],
  ['restitutionthreshold_3',['restitutionThreshold',['../structb2_fixture_def.html#ad56b10047e9c1b3bb317e7e5249f030c',1,'b2FixtureDef']]],
  ['revision_4',['revision',['../structb2_version.html#a395cfe1434e348115d2ead3d72b88847',1,'b2Version']]]
];

var structb2_body_def =
[
    [ "b2BodyDef", "structb2_body_def.html#a87bee47596b3b3eced0d9dd1f4c18fee", null ],
    [ "allowSleep", "structb2_body_def.html#a0765068172e521ed63cb34084c59c003", null ],
    [ "angle", "structb2_body_def.html#ab92ebd313164742c001724c6d00d5497", null ],
    [ "angularDamping", "structb2_body_def.html#afc1f985f274c93ac99b4dea71e1d77cc", null ],
    [ "angularVelocity", "structb2_body_def.html#aa1dff31771e6b9c4f041869693571d7f", null ],
    [ "awake", "structb2_body_def.html#a17a8102638aac41e7ab94278651a45bd", null ],
    [ "bullet", "structb2_body_def.html#a7c0047c9a98a1d20614eeddcdbce7586", null ],
    [ "enabled", "structb2_body_def.html#a30e30e3af5977a325a918b848f774fb0", null ],
    [ "fixedRotation", "structb2_body_def.html#a273a51c57440a8884de5939d76b6e3ea", null ],
    [ "gravityScale", "structb2_body_def.html#ac9e6956338f4bd35c162bf1ac8deddd6", null ],
    [ "linearDamping", "structb2_body_def.html#a973e312d5d95d2cd53c335ac3994d3ec", null ],
    [ "linearVelocity", "structb2_body_def.html#a25fa5aa78d93159c344241af95bec2bf", null ],
    [ "position", "structb2_body_def.html#a680cadc09ad6cf4b3366cbf0914c648b", null ],
    [ "type", "structb2_body_def.html#a89cc3ad1873908042b002147b3861381", null ],
    [ "userData", "structb2_body_def.html#ae913ce354e5602ddafecd5999c2db170", null ]
];
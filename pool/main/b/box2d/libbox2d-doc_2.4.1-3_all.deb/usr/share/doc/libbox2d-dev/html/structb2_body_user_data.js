var structb2_body_user_data =
[
    [ "pointer", "structb2_body_user_data.html#ae23e3ff9873138240adc85619ba38fb6", null ]
];
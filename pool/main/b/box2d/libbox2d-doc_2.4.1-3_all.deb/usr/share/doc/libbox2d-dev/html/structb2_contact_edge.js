var structb2_contact_edge =
[
    [ "contact", "structb2_contact_edge.html#a2fbfaffa0dfdf715fd1a709cff939dee", null ],
    [ "next", "structb2_contact_edge.html#a9af32b3cfadf35a927f4dffcf6338a6d", null ],
    [ "other", "structb2_contact_edge.html#a69015fc22e064eac04ed74f27a13ae78", null ],
    [ "prev", "structb2_contact_edge.html#a606dfacb78dc5c51672e4d7449006b8c", null ]
];
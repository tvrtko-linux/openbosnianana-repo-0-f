var structb2_contact_feature =
[
    [ "indexA", "structb2_contact_feature.html#a833bc746e7cb5e3cd458f1c0809101d0", null ],
    [ "indexB", "structb2_contact_feature.html#ad96712b6a0cc1f4b22b85b5948eab81d", null ],
    [ "typeA", "structb2_contact_feature.html#a3361b651f0a88fb60ec6aba9f4921cc2", null ],
    [ "typeB", "structb2_contact_feature.html#abb74afd6ee5b60834a3f8e2616182bdf", null ]
];
var structb2_distance_joint_def =
[
    [ "Initialize", "structb2_distance_joint_def.html#a99788a534638cc28cd1e44e0036503f0", null ],
    [ "damping", "structb2_distance_joint_def.html#aa488d9b1f5300e795587b844b6db0d98", null ],
    [ "length", "structb2_distance_joint_def.html#a001acbbd67326ab5e5d5ec6dc64faf78", null ],
    [ "localAnchorA", "structb2_distance_joint_def.html#a15c7a75fa277e2056bf1b44198658518", null ],
    [ "localAnchorB", "structb2_distance_joint_def.html#a3c8995be726238eee084af750442255c", null ],
    [ "maxLength", "structb2_distance_joint_def.html#ace0033f63ca1cbede5e415e72f6c0698", null ],
    [ "minLength", "structb2_distance_joint_def.html#a91529f9af7d7881ac71cd96737b65cd9", null ],
    [ "stiffness", "structb2_distance_joint_def.html#a858640393f567a2aca1b40cbe534b4e2", null ]
];
var structb2_distance_output =
[
    [ "iterations", "structb2_distance_output.html#ae2d4c84dd3d05ea4f4d20c91099ec8d5", null ],
    [ "pointA", "structb2_distance_output.html#a7e0f1f44a64e596dc7d37570c69eefce", null ],
    [ "pointB", "structb2_distance_output.html#aa85beca17337a506cd4a924d0c6f92cc", null ]
];
var structb2_distance_proxy =
[
    [ "GetSupport", "structb2_distance_proxy.html#a39de286cc0c1e829adfacfa0061b04f2", null ],
    [ "GetSupportVertex", "structb2_distance_proxy.html#a245993f09e9f3d3f374bb95041acf822", null ],
    [ "GetVertex", "structb2_distance_proxy.html#a9073b2c680d3fee6399f15be79ad144a", null ],
    [ "GetVertexCount", "structb2_distance_proxy.html#a99c461f28d484429dac8f14b58f63d89", null ],
    [ "Set", "structb2_distance_proxy.html#a80a59a9c9e952482a8fc6db4b883365d", null ],
    [ "Set", "structb2_distance_proxy.html#a5cd9ba137f6ed9ab73648e5151692fbb", null ]
];
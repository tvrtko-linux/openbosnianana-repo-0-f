var structb2_filter =
[
    [ "categoryBits", "structb2_filter.html#a368907397168d39af8b4fc5201d50bba", null ],
    [ "groupIndex", "structb2_filter.html#a572a8f4a1672f6d5d71123a35e872950", null ],
    [ "maskBits", "structb2_filter.html#a533cccf85e3ba3d9e3700d73b819f6e2", null ]
];
var structb2_fixture_def =
[
    [ "b2FixtureDef", "structb2_fixture_def.html#aa34ba06bcf0d6d981931a83cf124a602", null ],
    [ "density", "structb2_fixture_def.html#a386a1e68b7bebb7d1de64332d3bf34ce", null ],
    [ "filter", "structb2_fixture_def.html#a4c3e493a13d11ab27fcc2eee9f52fd61", null ],
    [ "friction", "structb2_fixture_def.html#a13799607109ebee16538facf1f0e1701", null ],
    [ "isSensor", "structb2_fixture_def.html#ac8cfcc6208663c92861eaab3b3fdc57e", null ],
    [ "restitution", "structb2_fixture_def.html#a87e1f5db5b7164fc7198e18a02ee6e36", null ],
    [ "restitutionThreshold", "structb2_fixture_def.html#ad56b10047e9c1b3bb317e7e5249f030c", null ],
    [ "shape", "structb2_fixture_def.html#a1e41753d89abf3443e7897e2498a3240", null ],
    [ "userData", "structb2_fixture_def.html#a480da3de55f826e8df9e7d2c0f7e911f", null ]
];
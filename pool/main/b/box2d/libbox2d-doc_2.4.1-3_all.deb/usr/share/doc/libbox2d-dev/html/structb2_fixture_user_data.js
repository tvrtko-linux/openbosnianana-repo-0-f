var structb2_fixture_user_data =
[
    [ "pointer", "structb2_fixture_user_data.html#a7de93df0f0e8a734795b04b7255f55a8", null ]
];
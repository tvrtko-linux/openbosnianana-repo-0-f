var structb2_friction_joint_def =
[
    [ "Initialize", "structb2_friction_joint_def.html#aee104f2aeb34dec4e17e3c52a98f7915", null ],
    [ "localAnchorA", "structb2_friction_joint_def.html#a00b246e60ae282a956a42b662993e92a", null ],
    [ "localAnchorB", "structb2_friction_joint_def.html#ad6d5a5614a7ac77b13e53fda3e32ed05", null ],
    [ "maxForce", "structb2_friction_joint_def.html#ab481751b52e3c4a9b11592b4bb248928", null ],
    [ "maxTorque", "structb2_friction_joint_def.html#ad3a5caf9f40f632e996c2b0717ba0948", null ]
];
var structb2_gear_joint_def =
[
    [ "joint1", "structb2_gear_joint_def.html#ae42d33b54291a9e256f3810926883473", null ],
    [ "joint2", "structb2_gear_joint_def.html#a73cf056fe40e63355073a01b097f4c82", null ],
    [ "ratio", "structb2_gear_joint_def.html#adb8dc3bcfa6e5149ba71630251edca22", null ]
];
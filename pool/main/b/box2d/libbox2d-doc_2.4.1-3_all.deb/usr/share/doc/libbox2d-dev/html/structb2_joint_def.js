var structb2_joint_def =
[
    [ "bodyA", "structb2_joint_def.html#a8cd54c93da396be75a9788f2c6897f05", null ],
    [ "bodyB", "structb2_joint_def.html#aa4f4dee2fbcd12187b19506b60e68e3d", null ],
    [ "collideConnected", "structb2_joint_def.html#aef099a1f89b64e230173b6016848ea9b", null ],
    [ "type", "structb2_joint_def.html#a470f2879b24adb05facbd49f338856fb", null ],
    [ "userData", "structb2_joint_def.html#a78ae1ebbdd3d9b9a6b409c0b05096ded", null ]
];
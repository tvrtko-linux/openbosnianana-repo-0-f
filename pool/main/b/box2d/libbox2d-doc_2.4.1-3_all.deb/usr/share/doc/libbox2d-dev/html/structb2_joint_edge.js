var structb2_joint_edge =
[
    [ "joint", "structb2_joint_edge.html#ab5bac5d495af1280c50271f56a221503", null ],
    [ "next", "structb2_joint_edge.html#a3d17286bc697bb620ee151e4cd07438c", null ],
    [ "other", "structb2_joint_edge.html#a64aef21fb91211871de8796baecccb95", null ],
    [ "prev", "structb2_joint_edge.html#acc3621e38d9664db2805e0fc29d71335", null ]
];
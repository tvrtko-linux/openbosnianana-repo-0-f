var structb2_manifold =
[
    [ "localNormal", "structb2_manifold.html#a3604e9fef2a03347c5649c71a9fd4c79", null ],
    [ "localPoint", "structb2_manifold.html#a8825cea31b27dbbaf22c13c3070870d5", null ],
    [ "pointCount", "structb2_manifold.html#abf59ff6fa36bed34b0242ad54951a696", null ],
    [ "points", "structb2_manifold.html#ab8021128e9792cc7391a8804ea02173d", null ]
];
var structb2_mass_data =
[
    [ "center", "structb2_mass_data.html#a1d59bebc7030c4dded0c2febc57ebdd7", null ],
    [ "I", "structb2_mass_data.html#aea3213483fc61bb84e84c869875732a0", null ],
    [ "mass", "structb2_mass_data.html#a28306cd337e0a58f07ad21648367e35b", null ]
];
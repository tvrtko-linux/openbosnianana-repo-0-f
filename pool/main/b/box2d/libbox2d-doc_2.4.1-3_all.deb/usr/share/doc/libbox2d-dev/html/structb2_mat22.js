var structb2_mat22 =
[
    [ "b2Mat22", "structb2_mat22.html#ac3e10f6d457c8dab9062ba378f66bc4d", null ],
    [ "b2Mat22", "structb2_mat22.html#abd674c6d92e26962977f34bcd92ff24d", null ],
    [ "b2Mat22", "structb2_mat22.html#a1a5d89430e2ac3cb71ff57347f54f2f3", null ],
    [ "Set", "structb2_mat22.html#aed3bee1de38a0b3f36e21c90faa24112", null ],
    [ "SetIdentity", "structb2_mat22.html#a7192f063b771ac9ded060e41df890509", null ],
    [ "SetZero", "structb2_mat22.html#aaeae95f61cf3171ffb94703980e3594b", null ],
    [ "Solve", "structb2_mat22.html#a3313c8d135c01fbf74e7fea31f1ea4c1", null ]
];
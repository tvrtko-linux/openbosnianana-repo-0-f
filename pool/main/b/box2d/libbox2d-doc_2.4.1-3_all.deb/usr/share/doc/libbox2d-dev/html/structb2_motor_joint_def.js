var structb2_motor_joint_def =
[
    [ "Initialize", "structb2_motor_joint_def.html#a90eb924b6e04da8d75d9cefad0655960", null ],
    [ "angularOffset", "structb2_motor_joint_def.html#a2ecc5d74b75bd20b27d2a0d28ad1bd76", null ],
    [ "correctionFactor", "structb2_motor_joint_def.html#a2844c52e534602bae52c4531bdf49c26", null ],
    [ "linearOffset", "structb2_motor_joint_def.html#a2c957cffc2af66c6c8077c069b906bc4", null ],
    [ "maxForce", "structb2_motor_joint_def.html#a0048cc0264f23707214ad96273c5fc0d", null ],
    [ "maxTorque", "structb2_motor_joint_def.html#acfeb8b3e2275da2f8f4365c1848e5385", null ]
];
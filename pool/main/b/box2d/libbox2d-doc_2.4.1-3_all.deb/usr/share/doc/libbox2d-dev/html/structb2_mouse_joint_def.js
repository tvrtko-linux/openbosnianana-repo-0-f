var structb2_mouse_joint_def =
[
    [ "damping", "structb2_mouse_joint_def.html#a0887471452796ff614965a7518e1f5aa", null ],
    [ "maxForce", "structb2_mouse_joint_def.html#a6ae811967747e4d1752b571c894c1ba7", null ],
    [ "stiffness", "structb2_mouse_joint_def.html#ae44cee9f187989e20dfa4346970391ce", null ],
    [ "target", "structb2_mouse_joint_def.html#aa1b76f72df9aca8d42bdc3e9922e310a", null ]
];
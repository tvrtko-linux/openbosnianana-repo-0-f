var structb2_revolute_joint_def =
[
    [ "Initialize", "structb2_revolute_joint_def.html#a6401b2a663533415d032a525e4fa2806", null ],
    [ "enableLimit", "structb2_revolute_joint_def.html#a2eaefc5fc5caf879cfd59ebcd852b756", null ],
    [ "enableMotor", "structb2_revolute_joint_def.html#aa94d9e66be9f03818d0cfbd9c70b2996", null ],
    [ "localAnchorA", "structb2_revolute_joint_def.html#a76337d07aa63232a7b20d50decc862ae", null ],
    [ "localAnchorB", "structb2_revolute_joint_def.html#a3f33bc1d9f6c22043a5ff2f1d89f04e0", null ],
    [ "lowerAngle", "structb2_revolute_joint_def.html#a27e17792157fff2aedcabb4b98d96f24", null ],
    [ "maxMotorTorque", "structb2_revolute_joint_def.html#af059ed0a6290622637814d5003739082", null ],
    [ "motorSpeed", "structb2_revolute_joint_def.html#a2ef3e7869ceacdf7212cf813fcc18074", null ],
    [ "referenceAngle", "structb2_revolute_joint_def.html#a7d70409545eecd92b84b3d55724019e1", null ],
    [ "upperAngle", "structb2_revolute_joint_def.html#a59d3a65db0f9ddde1416afa1f9b635a2", null ]
];
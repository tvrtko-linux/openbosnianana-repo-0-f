var structb2_rot =
[
    [ "b2Rot", "structb2_rot.html#aaebeb46656eb895a9c376c54579cecfb", null ],
    [ "GetAngle", "structb2_rot.html#a7db29fc002fc40827446bd2608d38f3a", null ],
    [ "GetXAxis", "structb2_rot.html#a952a5555c1f68ce3e39ac992fcf4eba9", null ],
    [ "GetYAxis", "structb2_rot.html#ab057c4e9dc821099949391a6ded36dd6", null ],
    [ "Set", "structb2_rot.html#a16a35e0f8e38c2855d528ca0ae044bf3", null ],
    [ "SetIdentity", "structb2_rot.html#a7f534cb7ece8d325662d7d0e27d4f617", null ],
    [ "s", "structb2_rot.html#a481158564d4e66b742b591cd68575dda", null ]
];
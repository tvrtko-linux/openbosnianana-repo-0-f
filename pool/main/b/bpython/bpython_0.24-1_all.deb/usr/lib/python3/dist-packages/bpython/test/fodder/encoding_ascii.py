# -*- coding: ascii -*-


def foo():
    """Test"""
    pass

# -*- coding: latin1 -*-


def foo():
    """Test ���"""
    pass

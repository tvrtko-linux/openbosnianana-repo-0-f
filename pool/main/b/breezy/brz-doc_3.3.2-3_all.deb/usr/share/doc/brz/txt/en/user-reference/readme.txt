Note: The contents of the User Reference are fully generated from
Bazaar's online help topics. If you wish to edit this material,
most of it can be found under breezy/help_topics/. In some cases
though, the material is built by probing various internal
registries, e.g. the set of available file formats. If you're
not sure where to find the source content you're looking for,
please contact the developers on the mailing list or IRC.
See https://www.breezy-vcs.org/pages/support.html for contact details.

/* libbrial/include/polybori/config.h.  Generated from config.h.in by configure.  */
/* has gd png support */
/* #undef PBORI_HAVE_GD */

/* has m4ri support */
#define PBORI_HAVE_M4RI /**/

/* has m4ri png support */
#define PBORI_HAVE_M4RI_PNG /**/

/* The size of `int', as computed by sizeof. */
#define SIZEOF_INT 4

/* The size of `long', as computed by sizeof. */
#define SIZEOF_LONG 8

/* The size of `void *', as computed by sizeof. */
#define SIZEOF_VOID_P 8

/* Name of package */
#define PACKAGE "brial"

/* Define to the full name of this package. */
#define PACKAGE_NAME "BRiAl"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "BRiAl 1.2.11"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "brial"

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.2.11"

/*  Copyright (c) 2005-2007 by The PolyBoRi Team */

#ifndef DP_ASC4_DATA_H
#define DP_ASC4_DATA_H
#include "groebner_defs.h"
BEGIN_NAMESPACE_PBORIGB
extern const unsigned short dp_asc4var_data[][7];
END_NAMESPACE_PBORIGB
#endif

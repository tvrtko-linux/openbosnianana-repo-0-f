/*
 *  groebner.h
 *  PolyBoRi
 *
 *  Created by Michael Brickenstein on 19.04.06.
 *  Copyright 2006 The PolyBoRi Team. See LICENSE file.
 *
 */


#include "groebner_defs.h"
#include "pairs.h"

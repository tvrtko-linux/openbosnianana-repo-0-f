var annotated_dup =
[
    [ "Battery", "classBattery.html", "classBattery" ],
    [ "CriticalSectionBlock", "classCriticalSectionBlock.html", "classCriticalSectionBlock" ],
    [ "Lamp", "classLamp.html", "classLamp" ],
    [ "LightSensor", "classLightSensor.html", "classLightSensor" ],
    [ "Motor", "classMotor.html", "classMotor" ],
    [ "MotorPair", "classMotorPair.html", "classMotorPair" ],
    [ "note_t", "structnote__t.html", "structnote__t" ],
    [ "RotationSensor", "classRotationSensor.html", "classRotationSensor" ],
    [ "Sensor", "classSensor.html", "classSensor" ],
    [ "Sound", "classSound.html", "classSound" ],
    [ "TemperatureSensor", "classTemperatureSensor.html", "classTemperatureSensor" ],
    [ "TouchSensor", "classTouchSensor.html", "classTouchSensor" ]
];
var classBattery =
[
    [ "get", "classBattery.html#aa2ccbfc0c600b525715cad745ecf8598", null ]
];
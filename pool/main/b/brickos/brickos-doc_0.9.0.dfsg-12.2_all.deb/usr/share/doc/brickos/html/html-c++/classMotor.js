var classMotor =
[
    [ "Limits", "classMotor.html#a920c6d2040b8daf7a10ca1e96b9515a1", [
      [ "min", "classMotor.html#a920c6d2040b8daf7a10ca1e96b9515a1a2486840e80710fc6f700cb28921b1a79", null ],
      [ "max", "classMotor.html#a920c6d2040b8daf7a10ca1e96b9515a1ad4e0a5b3d2b302271bf80c16a17ba147", null ]
    ] ],
    [ "Port", "classMotor.html#a1949a08bd5feed6d0f4b63b75660ebfa", [
      [ "A", "classMotor.html#a1949a08bd5feed6d0f4b63b75660ebfaa4edcfdb0713870cd037d3345031f31b1", null ],
      [ "B", "classMotor.html#a1949a08bd5feed6d0f4b63b75660ebfaa8add9c7f7b5806f7c045ad3b8a4be97f", null ],
      [ "C", "classMotor.html#a1949a08bd5feed6d0f4b63b75660ebfaa95b31f84470d8895135fdec8785b9212", null ]
    ] ],
    [ "Motor", "classMotor.html#aea4885246cd5e0c6f6eda831b346832a", null ],
    [ "~Motor", "classMotor.html#a2e57c7b2681efea1d3b7f253ee88ecd4", null ],
    [ "brake", "classMotor.html#ad8b46b388400a9ef98a764116e1c9e77", null ],
    [ "brake", "classMotor.html#a60f769108a51285285647bf2c8b7f94a", null ],
    [ "direction", "classMotor.html#a9afeda63ad550293a913171e610a4da4", null ],
    [ "forward", "classMotor.html#a0848fdd4aa68c422eccecc6bdc4d5a9e", null ],
    [ "forward", "classMotor.html#a04c00af8a1c4648d7de6a5499946d645", null ],
    [ "off", "classMotor.html#a8f12d85a7d8163bf66e6761096ffc5f6", null ],
    [ "reverse", "classMotor.html#aff61d04990c263862b3eb4723d2eaa1d", null ],
    [ "reverse", "classMotor.html#af995bbe1c9fbc2225323dd741c03cafe", null ],
    [ "speed", "classMotor.html#a981927f738d8c3a5cb434af10ab2fb7d", null ]
];
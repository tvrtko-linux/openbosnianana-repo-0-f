var classMotorPair =
[
    [ "Limits", "classMotorPair.html#ac31769534f5b1ddb397196578573c20f", [
      [ "min", "classMotorPair.html#ac31769534f5b1ddb397196578573c20fa8ee105d7fed6aa35fd7810e99f3706d6", null ],
      [ "max", "classMotorPair.html#ac31769534f5b1ddb397196578573c20fa06b9013554ecf8fa3355f3a9779c2c2b", null ]
    ] ],
    [ "MotorPair", "classMotorPair.html#a49c2b53d7442d29702614d5c7e68f8f6", null ],
    [ "~MotorPair", "classMotorPair.html#ac0d11e8210e4e1e5d74fea5adbf6a1cc", null ],
    [ "brake", "classMotorPair.html#a43d2f65dc95265566e45efb8309496db", null ],
    [ "brake", "classMotorPair.html#a82d0d3917ed37c7692066ee44359cbb6", null ],
    [ "direction", "classMotorPair.html#a9d26e71747ae52093628c46edf58f2b5", null ],
    [ "forward", "classMotorPair.html#a27ffbefcbecc042f6dd5d106043b5fe8", null ],
    [ "forward", "classMotorPair.html#ab1f00808cfaff52962a0ac7ee1495aae", null ],
    [ "left", "classMotorPair.html#a5457497372553b1b49361d4b80412c69", null ],
    [ "left", "classMotorPair.html#a960ca9468336d17616824e86ed36264e", null ],
    [ "off", "classMotorPair.html#a78593cf18b2e54ed37ffe9c33c248a00", null ],
    [ "pivotLeft", "classMotorPair.html#a9228ffc8d9b2fa7acd13ac4f01c8bde1", null ],
    [ "pivotLeft", "classMotorPair.html#a905e400b354a1118c14bb8b4f62c824e", null ],
    [ "pivotRight", "classMotorPair.html#a2e4bd24e7c76a106a33d13babe73ee53", null ],
    [ "pivotRight", "classMotorPair.html#a0c1ef7cfc17fb3ea4341a48491469ee1", null ],
    [ "reverse", "classMotorPair.html#aa921c9f9129254b1c81343666308aa25", null ],
    [ "reverse", "classMotorPair.html#aaf6f471e04928e4217bd02f6b7767d64", null ],
    [ "right", "classMotorPair.html#aff596768c17c9887f518aa625826d3e1", null ],
    [ "right", "classMotorPair.html#ac7bf5b7035df0773593d9c3e1a7f5edf", null ],
    [ "speed", "classMotorPair.html#a87a7b4905bcb940de6bc8f015d2d4e76", null ]
];
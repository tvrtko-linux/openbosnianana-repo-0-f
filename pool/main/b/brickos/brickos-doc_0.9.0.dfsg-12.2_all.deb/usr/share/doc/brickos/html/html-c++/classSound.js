var classSound =
[
    [ "beep", "classSound.html#a40319855b3444903d9cbacf651f54392", null ],
    [ "duration", "classSound.html#acc799556d3b4393d23a7aa6bcfd21a5f", null ],
    [ "internote", "classSound.html#aa4e23a087c6be7cf433c9faed638f35e", null ],
    [ "play", "classSound.html#ad3ab5b86c985c1a8e09c6140bb1dcef8", null ],
    [ "playing", "classSound.html#af3dd38829c6f2c85c63abe6eb03ea3e1", null ],
    [ "stop", "classSound.html#a73f4e733ce81e6d6298da6c4992ff829", null ]
];
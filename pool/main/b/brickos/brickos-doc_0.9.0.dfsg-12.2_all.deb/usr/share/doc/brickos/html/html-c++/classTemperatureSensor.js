var classTemperatureSensor =
[
    [ "Port", "classTemperatureSensor.html#a49c4630e58a69a78ba1d709c803634df", [
      [ "S1", "classTemperatureSensor.html#a49c4630e58a69a78ba1d709c803634dfa70ce3fd2b880544e548dc37bde4321d4", null ],
      [ "S2", "classTemperatureSensor.html#a49c4630e58a69a78ba1d709c803634dfaecea80a7c7ca5cfcabaf145f2abafb93", null ],
      [ "S3", "classTemperatureSensor.html#a49c4630e58a69a78ba1d709c803634dfa4d399a030a36d3424be2b04e57d0531a", null ],
      [ "Battery", "classTemperatureSensor.html#a49c4630e58a69a78ba1d709c803634dfaf03b603a885bd88fedaedac3589663b6", null ]
    ] ],
    [ "TemperatureSensor", "classTemperatureSensor.html#a98ccf6d51f96b8d454efd8f7b5bb2670", null ],
    [ "~TemperatureSensor", "classTemperatureSensor.html#a4ee390badd77fa6c7ce46dc788f3d5c6", null ],
    [ "active", "classTemperatureSensor.html#a061c8e6d639bb9a374e418eda9d13f2f", null ],
    [ "C", "classTemperatureSensor.html#a0ad38fddb226b30e840751e4943b88c4", null ],
    [ "degrees", "classTemperatureSensor.html#a580722741cac3f975cc1c9e51d0c2b83", null ],
    [ "F", "classTemperatureSensor.html#ac2de1fa9fe3a459bc645438cf27a6971", null ],
    [ "get", "classTemperatureSensor.html#a39866e2a308e8d985daa1d0e0fc74078", null ],
    [ "mode", "classTemperatureSensor.html#a4c0e13a343041fcfb4e695bea14f8cc2", null ],
    [ "off", "classTemperatureSensor.html#ac8b1a54997563e120e90b559cbbfbf9d", null ],
    [ "on", "classTemperatureSensor.html#ada9c9e668e0b7363bf6f6f8f5c5a9e7f", null ],
    [ "passive", "classTemperatureSensor.html#aca194ef9741e39b7fcefc4977df5a6a6", null ],
    [ "sample", "classTemperatureSensor.html#af2058c5a03b2e59e936c437a5613ae36", null ],
    [ "strobe", "classTemperatureSensor.html#a522bc3e6b17c7e14d577f7c45da6e32b", null ],
    [ "strobe", "classTemperatureSensor.html#a56740329609ed271a872ecd990dff58a", null ],
    [ "tenths", "classTemperatureSensor.html#a8402bdd185a26b0e3642c0bfa0cbe0f8", null ],
    [ "sensor", "classTemperatureSensor.html#a3926628402116504af39c38c1f9c9b47", null ]
];
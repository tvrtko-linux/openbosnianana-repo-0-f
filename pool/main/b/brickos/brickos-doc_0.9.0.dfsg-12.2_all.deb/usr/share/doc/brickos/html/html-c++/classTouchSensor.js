var classTouchSensor =
[
    [ "Port", "classTouchSensor.html#a49c4630e58a69a78ba1d709c803634df", [
      [ "S1", "classTouchSensor.html#a49c4630e58a69a78ba1d709c803634dfa70ce3fd2b880544e548dc37bde4321d4", null ],
      [ "S2", "classTouchSensor.html#a49c4630e58a69a78ba1d709c803634dfaecea80a7c7ca5cfcabaf145f2abafb93", null ],
      [ "S3", "classTouchSensor.html#a49c4630e58a69a78ba1d709c803634dfa4d399a030a36d3424be2b04e57d0531a", null ],
      [ "Battery", "classTouchSensor.html#a49c4630e58a69a78ba1d709c803634dfaf03b603a885bd88fedaedac3589663b6", null ]
    ] ],
    [ "TouchSensor", "classTouchSensor.html#abb6fb35b90b94a95f39e52321a1ab74b", null ],
    [ "active", "classTouchSensor.html#a061c8e6d639bb9a374e418eda9d13f2f", null ],
    [ "get", "classTouchSensor.html#a39866e2a308e8d985daa1d0e0fc74078", null ],
    [ "mode", "classTouchSensor.html#a4c0e13a343041fcfb4e695bea14f8cc2", null ],
    [ "off", "classTouchSensor.html#ac8b1a54997563e120e90b559cbbfbf9d", null ],
    [ "on", "classTouchSensor.html#ada9c9e668e0b7363bf6f6f8f5c5a9e7f", null ],
    [ "passive", "classTouchSensor.html#aca194ef9741e39b7fcefc4977df5a6a6", null ],
    [ "pressed", "classTouchSensor.html#a31a180319a2df79fcf5a7a698b390af0", null ],
    [ "sample", "classTouchSensor.html#af2058c5a03b2e59e936c437a5613ae36", null ],
    [ "strobe", "classTouchSensor.html#a522bc3e6b17c7e14d577f7c45da6e32b", null ],
    [ "strobe", "classTouchSensor.html#a56740329609ed271a872ecd990dff58a", null ],
    [ "sensor", "classTouchSensor.html#a3926628402116504af39c38c1f9c9b47", null ]
];
var hierarchy =
[
    [ "Battery", "classBattery.html", null ],
    [ "CriticalSectionBlock", "classCriticalSectionBlock.html", null ],
    [ "Lamp", "classLamp.html", null ],
    [ "Motor", "classMotor.html", null ],
    [ "MotorPair", "classMotorPair.html", null ],
    [ "note_t", "structnote__t.html", null ],
    [ "Sensor", "classSensor.html", [
      [ "LightSensor", "classLightSensor.html", null ],
      [ "RotationSensor", "classRotationSensor.html", null ],
      [ "TemperatureSensor", "classTemperatureSensor.html", null ],
      [ "TouchSensor", "classTouchSensor.html", null ]
    ] ],
    [ "Sound", "classSound.html", null ]
];
var dkey_8h =
[
    [ "KEY_ANY", "dkey_8h.html#a35fa3fdfb312c5dd1d95498d913daeb2", null ],
    [ "KEY_ONOFF", "dkey_8h.html#abfd77cb3cac76fec3449a837ae749984", null ],
    [ "KEY_PRGM", "dkey_8h.html#a0fd6281e26bfb188fbdeb24281111045", null ],
    [ "KEY_RUN", "dkey_8h.html#a269063970782e4017faed9aa9d9e6646", null ],
    [ "KEY_VIEW", "dkey_8h.html#ae4ea8f56215397d43b3ee089b24d1595", null ],
    [ "dkey_pressed", "dkey_8h.html#aa929aef53620759f871e3ff92db45190", null ],
    [ "dkey_released", "dkey_8h.html#a0b4bbcbdf88657dae9d9245e7e8b9411", null ],
    [ "getchar", "dkey_8h.html#ac45fdeab51c3197c1e7c4ec7beabaca9", null ],
    [ "dkey", "dkey_8h.html#a5bf423125bb6b18e0b50010a86f7553d", null ],
    [ "dkey_multi", "dkey_8h.html#a89816217b0e0cdcafacb305d12b088d2", null ]
];
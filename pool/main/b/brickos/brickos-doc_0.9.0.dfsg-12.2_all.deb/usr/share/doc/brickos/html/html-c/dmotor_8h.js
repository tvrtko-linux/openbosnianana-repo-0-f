var dmotor_8h =
[
    [ "MAX_SPEED", "dmotor_8h.html#ac2cd96d53dd3ba6407db6766c3d92b26", null ],
    [ "MIN_SPEED", "dmotor_8h.html#ad5f5efaa5cb771bd06da4bfe6046809e", null ],
    [ "MotorDirection", "dmotor_8h.html#ab0dd3595d7049b92115a766f0ea6f7e0", [
      [ "off", "dmotor_8h.html#ab0dd3595d7049b92115a766f0ea6f7e0a53ace14c115e45153a1c9105accceb4c", null ],
      [ "fwd", "dmotor_8h.html#ab0dd3595d7049b92115a766f0ea6f7e0a005629bac9a3a7b36246e3b23b485b7a", null ],
      [ "rev", "dmotor_8h.html#ab0dd3595d7049b92115a766f0ea6f7e0a2933b3864a05bfa0554e2f058786a3a0", null ],
      [ "brake", "dmotor_8h.html#ab0dd3595d7049b92115a766f0ea6f7e0a464d39f4a3b3858219c68547eebe4f52", null ]
    ] ],
    [ "motor_a_dir", "dmotor_8h.html#ab32b15bc1dc4af4e6b55a266137b48ab", null ],
    [ "motor_a_speed", "dmotor_8h.html#afdd28dc7412e97de090113bdc44eb32a", null ],
    [ "motor_b_dir", "dmotor_8h.html#a9ff650171a734b7400eee0ea736921ab", null ],
    [ "motor_b_speed", "dmotor_8h.html#a3ba3ec9909c53799701212d4f0ab78c0", null ],
    [ "motor_c_dir", "dmotor_8h.html#abf59a330f989117469c3e67751b2a998", null ],
    [ "motor_c_speed", "dmotor_8h.html#a33311179b2fbdd706446fe5d47679991", null ],
    [ "dm_a", "dmotor_8h.html#a81b10cc1398e949b8ac2a3b02b070f79", null ],
    [ "dm_a_pattern", "dmotor_8h.html#a1913f8649ef6897453fa0e125f92b5c9", null ],
    [ "dm_b", "dmotor_8h.html#a4987ce6852a1a5c8c241fd096f9dbee5", null ],
    [ "dm_b_pattern", "dmotor_8h.html#a7774548ea3b18080f8527ec05b5fdb9b", null ],
    [ "dm_c", "dmotor_8h.html#aadd4bff0fd48bf65f6be74b2f5c55cf4", null ],
    [ "dm_c_pattern", "dmotor_8h.html#aa72c2efa04f85d358e37a1afb1a4e9c5", null ]
];
var lnp_logical_8h =
[
    [ "lnp_logical_fflush", "lnp-logical_8h.html#a6aac00ece3310818e2196ce06c3bccc2", null ],
    [ "lnp_logical_range", "lnp-logical_8h.html#a36bd8edc07c5e7e22cd7211d64dc0584", null ],
    [ "lnp_logical_range_is_far", "lnp-logical_8h.html#aaec3b788699296d96090b0ca3d866749", null ],
    [ "lnp_logical_write", "lnp-logical_8h.html#a631149dc046150566e2d4b7748f3e0bb", null ]
];
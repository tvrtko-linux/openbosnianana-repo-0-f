var modules =
[
    [ "standard note/rest durations", "group__noteDurations.html", null ]
];
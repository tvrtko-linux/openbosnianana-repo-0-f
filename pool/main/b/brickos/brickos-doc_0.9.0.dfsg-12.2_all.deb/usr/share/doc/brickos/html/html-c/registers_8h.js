var registers_8h =
[
    [ "rom_port1_ddr", "registers_8h.html#a94c388a7ede12edac43fee7b7378718c", null ],
    [ "rom_port2_ddr", "registers_8h.html#ab7d16adc1f60c8cd7feb9405e7208921", null ],
    [ "rom_port3_ddr", "registers_8h.html#a9ecdf6dc7399a68bf4bb655781b857bd", null ],
    [ "rom_port4_ddr", "registers_8h.html#a548cefebbf39adc1862fe307fb2f1e5a", null ],
    [ "rom_port5_ddr", "registers_8h.html#a2ffacfbb7733acfe9949c838261fd3d4", null ],
    [ "rom_port6_ddr", "registers_8h.html#a3c370967dcde20fa3419eab78bea8448", null ],
    [ "rom_port7_pin", "registers_8h.html#a329cbb19a117b03429348e6f53e6edb8", null ]
];
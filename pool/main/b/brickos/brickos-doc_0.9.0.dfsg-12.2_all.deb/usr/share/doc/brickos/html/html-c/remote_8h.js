var remote_8h =
[
    [ "LR_DUMMY_HANDLER", "remote_8h.html#a7c53b1cc1d04ef14c97ad2228ce70836", null ],
    [ "LR_TIMEOUT", "remote_8h.html#ae2ecd38a21e395938377e2dfeb1fac8d", null ],
    [ "LRKEY_A1", "remote_8h.html#a3089f48c2c0ab48ee3da749f9bc44a57", null ],
    [ "LRKEY_A2", "remote_8h.html#a80a1c0c0e008284f5fe23bc2887f974d", null ],
    [ "LRKEY_B1", "remote_8h.html#a01705f5462833ac8add747d6fc96d54c", null ],
    [ "LRKEY_B2", "remote_8h.html#a4b61bb1ed1b20ab68596d736384ffca3", null ],
    [ "LRKEY_BEEP", "remote_8h.html#ad94d91a14b0823122945c404b135d358", null ],
    [ "LRKEY_C1", "remote_8h.html#a9b669fd6a99b89a7a9ff858e2d89122e", null ],
    [ "LRKEY_C2", "remote_8h.html#a8eca57bfea13aaadedd20ebb15393e56", null ],
    [ "LRKEY_M1", "remote_8h.html#a5d1fb55f42e1c543fef6d0f630b34c4a", null ],
    [ "LRKEY_M2", "remote_8h.html#a56caa5c1f550b68146cf0cfdf4a3a9d5", null ],
    [ "LRKEY_M3", "remote_8h.html#a562985022720409b57ec2a0754e2f252", null ],
    [ "LRKEY_P1", "remote_8h.html#a975488f4f8a0f077989a2016aeeba63f", null ],
    [ "LRKEY_P2", "remote_8h.html#afb4962c557fd835bb9d531687417fb30", null ],
    [ "LRKEY_P3", "remote_8h.html#a5227d41b2af805f6694e8ac3b3acea01", null ],
    [ "LRKEY_P4", "remote_8h.html#ac9e02714b6969d1748df64c035b87137", null ],
    [ "LRKEY_P5", "remote_8h.html#a905441eca0c4d0e47bfb636f21eccbe3", null ],
    [ "LRKEY_STOP", "remote_8h.html#aab53594296ca9e0427b5a724d2217e05", null ],
    [ "lr_handler_t", "remote_8h.html#a4e756d575da70d904d6f23cacd6b275e", null ],
    [ "_evt", "remote_8h.html#aaf4d107d89536ed61b318c50ae9ec0bc", [
      [ "LREVT_KEYON", "remote_8h.html#aaf4d107d89536ed61b318c50ae9ec0bcab659182ddba07157d5dbe46607f24bef", null ],
      [ "LREVT_KEYOFF", "remote_8h.html#aaf4d107d89536ed61b318c50ae9ec0bcad54448427ab93f605fb08939bebacb8f", null ]
    ] ],
    [ "lr_init", "remote_8h.html#abbc73ecdee17c8e0cdd4d779be166ad8", null ],
    [ "lr_set_handler", "remote_8h.html#a8b96386aaa2cc284d48548e9f156ac2a", null ],
    [ "lr_shutdown", "remote_8h.html#adbd0dd981126e212f0e6c21ad61b3d97", null ],
    [ "lr_startup", "remote_8h.html#a55c73e6820d3f948da9f3c2b20568a81", null ],
    [ "EventType", "remote_8h.html#a41c73b122c40d47ee031672bf27bfa8b", null ],
    [ "lr_handler", "remote_8h.html#a5f861135a28cf95e0f644104b818b58e", null ]
];
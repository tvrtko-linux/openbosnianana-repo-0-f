var structnote__t =
[
    [ "length", "structnote__t.html#ac203758cb6b02ddbc40563196b0b1816", null ],
    [ "pitch", "structnote__t.html#a7c7d69f41f1b216b012eee1db67be598", null ]
];
var system_8h =
[
    [ "power_init", "system_8h.html#a1ca9d74e081ad1377b5c9b7773be973b", null ],
    [ "power_off", "system_8h.html#a3d22109c1bb9a743e687abed237c4927", null ],
    [ "reset", "system_8h.html#a569fb8103417659eae8a92ebdd173bb3", null ],
    [ "rom_reset", "system_8h.html#a30c7f1a7485f4f1d10ebf623d89d1e8e", null ]
];
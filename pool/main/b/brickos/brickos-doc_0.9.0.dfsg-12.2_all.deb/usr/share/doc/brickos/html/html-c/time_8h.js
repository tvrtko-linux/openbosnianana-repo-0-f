var time_8h =
[
    [ "MSECS_TO_TICKS", "time_8h.html#a1b21c5a17873d31fdb6d1441aad2efef", null ],
    [ "SECS_TO_TICKS", "time_8h.html#aa2ace8efe824a3afb36d84d95ba71ff6", null ],
    [ "TICK_IN_MS", "time_8h.html#abcc4a6859f70075a1be100c054603ee8", null ],
    [ "TICKS_PER_SEC", "time_8h.html#a4a0c770328891d8916c1142a26481e4a", null ],
    [ "time_t", "time_8h.html#aec517130c026730881898750d76e596f", null ],
    [ "get_system_up_time", "time_8h.html#a71274de1bb8fd0c69ac5be136c957eba", null ]
];
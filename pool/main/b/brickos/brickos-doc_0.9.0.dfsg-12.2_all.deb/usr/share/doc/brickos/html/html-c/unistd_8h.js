var unistd_8h =
[
    [ "execi", "unistd_8h.html#a6f38875e6991f5ffedad44b179abe637", null ],
    [ "exit", "unistd_8h.html#a5f5e7c968084a84a4a1a7f76164ac258", null ],
    [ "kill", "unistd_8h.html#ad4b713c7964af5f3a8d8114ba883ebe3", null ],
    [ "killall", "unistd_8h.html#aae285b5eb4461c7457115b3915a784bc", null ],
    [ "msleep", "unistd_8h.html#a8470faaa27e1e5736535977cc9db8032", null ],
    [ "shutdown_task", "unistd_8h.html#a679707c27051a7fb66bc32b0c6e04890", null ],
    [ "shutdown_tasks", "unistd_8h.html#ae152bd81aa457c4966815743dd702fb2", null ],
    [ "sleep", "unistd_8h.html#a43328680eff1bbb606d31807bd313ff2", null ],
    [ "wait_event", "unistd_8h.html#a9c476b7f83ffc5cde19a7984e9c4bd78", null ],
    [ "yield", "unistd_8h.html#a7cb51f5c2b5cad3766f19eb69c92793b", null ]
];
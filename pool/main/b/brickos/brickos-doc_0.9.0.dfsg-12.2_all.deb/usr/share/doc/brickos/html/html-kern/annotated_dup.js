var annotated_dup =
[
    [ "_pchain_t", "struct__pchain__t.html", "struct__pchain__t" ],
    [ "_tdata_t", "struct__tdata__t.html", "struct__tdata__t" ],
    [ "Battery", "classBattery.html", "classBattery" ],
    [ "CriticalSectionBlock", "classCriticalSectionBlock.html", "classCriticalSectionBlock" ],
    [ "critsec", "structcritsec.html", "structcritsec" ],
    [ "Lamp", "classLamp.html", "classLamp" ],
    [ "LightSensor", "classLightSensor.html", "classLightSensor" ],
    [ "Motor", "classMotor.html", "classMotor" ],
    [ "MotorPair", "classMotorPair.html", "classMotorPair" ],
    [ "MotorState", "structMotorState.html", "structMotorState" ],
    [ "note_t", "structnote__t.html", "structnote__t" ],
    [ "program_t", "structprogram__t.html", "structprogram__t" ],
    [ "RotationSensor", "classRotationSensor.html", "classRotationSensor" ],
    [ "Sensor", "classSensor.html", "classSensor" ],
    [ "Sound", "classSound.html", "classSound" ],
    [ "TemperatureSensor", "classTemperatureSensor.html", "classTemperatureSensor" ],
    [ "TouchSensor", "classTouchSensor.html", "classTouchSensor" ]
];
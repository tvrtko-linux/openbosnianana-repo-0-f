var battery_8h =
[
    [ "BATTERY_LOW_THRESHOLD_MV", "battery_8h.html#ad66e65ab36b42eaf85a95a1ba06e32b0", null ],
    [ "BATTERY_NORMAL_THRESHOLD_MV", "battery_8h.html#a93097073dc1e25efeb317d19d6803919", null ],
    [ "battery_refresh", "battery_8h.html#a42bfe56b8611b2c85388b25c9cf593a7", null ],
    [ "get_battery_mv", "battery_8h.html#afdc899c4170b9d78b1f81dd2367936ed", null ]
];
var classRotationSensor =
[
    [ "Port", "classRotationSensor.html#a49c4630e58a69a78ba1d709c803634df", [
      [ "S1", "classRotationSensor.html#a49c4630e58a69a78ba1d709c803634dfa70ce3fd2b880544e548dc37bde4321d4", null ],
      [ "S2", "classRotationSensor.html#a49c4630e58a69a78ba1d709c803634dfaecea80a7c7ca5cfcabaf145f2abafb93", null ],
      [ "S3", "classRotationSensor.html#a49c4630e58a69a78ba1d709c803634dfa4d399a030a36d3424be2b04e57d0531a", null ],
      [ "Battery", "classRotationSensor.html#a49c4630e58a69a78ba1d709c803634dfaf03b603a885bd88fedaedac3589663b6", null ]
    ] ],
    [ "RotationSensor", "classRotationSensor.html#aeab197bdedbbde1436ee09497772382e", null ],
    [ "~RotationSensor", "classRotationSensor.html#a1de7165fe56c2c317c6e0f039cffecd1", null ],
    [ "active", "classRotationSensor.html#a061c8e6d639bb9a374e418eda9d13f2f", null ],
    [ "get", "classRotationSensor.html#a39866e2a308e8d985daa1d0e0fc74078", null ],
    [ "mode", "classRotationSensor.html#a4c0e13a343041fcfb4e695bea14f8cc2", null ],
    [ "off", "classRotationSensor.html#ae067994e797d30a9dc34f9a3b0b6a72e", null ],
    [ "on", "classRotationSensor.html#a384f91cccf9ab7caa8d03253a84d4fa9", null ],
    [ "passive", "classRotationSensor.html#aca194ef9741e39b7fcefc4977df5a6a6", null ],
    [ "pos", "classRotationSensor.html#a70f43db8b08fd0cc2631647cefca30ac", null ],
    [ "pos", "classRotationSensor.html#a437c0b0f1d4d49cfb50658623b5718b9", null ],
    [ "sample", "classRotationSensor.html#af2058c5a03b2e59e936c437a5613ae36", null ],
    [ "strobe", "classRotationSensor.html#a522bc3e6b17c7e14d577f7c45da6e32b", null ],
    [ "strobe", "classRotationSensor.html#a56740329609ed271a872ecd990dff58a", null ],
    [ "rsensor", "classRotationSensor.html#afef856e827e531158aa2081d16a01ff9", null ],
    [ "sensor", "classRotationSensor.html#a3926628402116504af39c38c1f9c9b47", null ]
];
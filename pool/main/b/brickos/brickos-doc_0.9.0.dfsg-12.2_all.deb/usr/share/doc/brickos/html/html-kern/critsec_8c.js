var critsec_8c =
[
    [ "__asm__", "critsec_8c.html#a169d3ef90f8fea3a4385c75a9012b564", null ],
    [ "enter_critical_section", "critsec_8c.html#a7f08e172fa6f8145ac851cab21b5cc87", null ],
    [ "locked_check_and_increment", "critsec_8c.html#af4300b6025135e6aa4ae4cbeb7d2d3c7", null ],
    [ "wait_critical_section", "critsec_8c.html#afb0ca0822dc6e2b799978e22fcb8c44d", null ],
    [ "kernel_critsec_count", "critsec_8c.html#acb9e28993f336e89b7804e50b6aeb1d7", null ]
];
var critsec_8h =
[
    [ "critsec", "structcritsec.html", "structcritsec" ],
    [ "destroy_critical_section", "critsec_8h.html#a3399b9b2b824d5899569d2f4cd6e1b2a", null ],
    [ "initialize_critical_section", "critsec_8h.html#a3be6de9aa47cf9d4db88efa8d3fef37e", null ],
    [ "leave_critical_section", "critsec_8h.html#ae13877ce1424c200271872de22e59fa8", null ],
    [ "locked_decrement", "critsec_8h.html#ae8426728c658f80ebdd7014be764f7fd", null ],
    [ "critsec_t", "critsec_8h.html#a92c87edb85164f0c329eed99052a5aa7", null ],
    [ "enter_critical_section", "critsec_8h.html#a7f08e172fa6f8145ac851cab21b5cc87", null ],
    [ "wait_critical_section", "critsec_8h.html#afb0ca0822dc6e2b799978e22fcb8c44d", null ]
];
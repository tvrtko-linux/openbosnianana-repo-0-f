Programs for Bristol's "Mini" (from 50 to 86 PRG)
by Vasiliy Basic (e-mail: vbasic2008@gmail.com)

By default, unpack to:
/usr/local/share/bristol/memory/mini

List of prorgams:

-Melodic-
50 - Trumpet
51 - Cello
52 - Guitar 1
53 - Guitar 2
54 - Fingered Bass
55 - Picked Bass
56 - Harmonica
57 - Accordion
58 - Tango Accordion
59 - Super Accordion
60 - Piano
61 - Dark Organ
62 - Flute
63 - Music Box
64 - Glass Xylo
65 - Glass Pad
66 - Acid Bass

-Drums-
67 - Bass Drum 1 
68 - Bass Drum 2
69 - Bass Drum 3
70 - Bass Drum 4
71 - Tom
72 - Snare 1
73 - Snare 2
74 - Snare 3
75 - Snare 4
76 - Cl HH 1
77 - Op HH 1
78 - Crash Cym 1
79 - Crach Cym 2
80 - Cl HH 2
81 - Op HH 2

-FX-
82 - Sea Shore
83 - Helicopter 1
84 - Helicopter 2
85 - Bird Tweet
86 - Birds Tweet

Hope, this will be useful for your music :)
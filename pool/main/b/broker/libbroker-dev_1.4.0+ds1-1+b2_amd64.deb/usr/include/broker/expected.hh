#pragma once

#include <caf/expected.hpp>

namespace broker {

using caf::expected;

} // namespace broker

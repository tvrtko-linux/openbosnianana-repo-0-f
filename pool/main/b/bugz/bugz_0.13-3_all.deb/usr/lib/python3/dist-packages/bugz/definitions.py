__version__ = '0.13'
__author__ = 'Alastair Tse <http://www.liquidx.net/>'
__contributors__ = ['Santiago M. Mola <cooldwind@gmail.com>',
                    'William Hubbs <w.d.hubbs@gmail.com>',
                    'Mike Gilbert <floppym@gentoo.org>',
                    'Benjamin Behringer <mail@benjamin-behringer.de>']
__revision__ = '$Id: $'
__license__ = """Copyright (c) 2006, Alastair Tse, All rights reserved.
This following source code is licensed under the GPL v2 License."""

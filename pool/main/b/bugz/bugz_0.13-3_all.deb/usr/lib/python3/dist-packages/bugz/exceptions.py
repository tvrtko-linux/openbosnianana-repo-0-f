#
# Bugz specific exceptions
#


class BugzError(Exception):
    pass

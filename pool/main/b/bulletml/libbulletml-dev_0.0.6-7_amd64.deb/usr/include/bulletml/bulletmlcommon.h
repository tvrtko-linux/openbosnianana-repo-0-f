#ifndef bulletmlcommon_h_
#define bulletmlcommon_h_

#ifdef WIN32_DLL_EXPORT
# define DECLSPEC __declspec(dllexport)
#else
# define DECLSPEC
#endif

#endif // ! bulletmlcommon_h_


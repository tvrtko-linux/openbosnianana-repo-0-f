//#include <utility>
//
//template <typename Front, typename Next, typename ...Types>
//concept Addable =
//    Addable<Front, Types ...>
//    and
//    requires (Front lhs, Next rhs)
//    {
//        lhs + rhs;
//    };
//
//template <typename Front>
//concept Addable = true;
//
//
//template <Addable ...Types>
//void fun(Types &&...types)
//{
//}
//

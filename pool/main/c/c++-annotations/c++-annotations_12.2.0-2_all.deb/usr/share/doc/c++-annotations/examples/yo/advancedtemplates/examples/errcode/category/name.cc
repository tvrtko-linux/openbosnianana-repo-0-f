//#define XERR
#include "category.ih"

char const *Category::name() const noexcept
{
    return "Category";
}

    #include "buffer.h"

    int main(int argc)
    {
        Buffer<int, argc> b;    // won't compile
    }

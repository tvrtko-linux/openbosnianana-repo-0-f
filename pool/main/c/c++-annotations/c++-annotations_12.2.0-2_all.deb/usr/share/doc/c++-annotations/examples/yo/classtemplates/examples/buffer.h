    template <typename Type, size_t size>
    class Buffer
    {
        public:
            Type
                buffer[size];
    };

#include "forward.h"

#include <algorithm>
using namespace std;

int main()
{
    adjacent_find(ForwardIterator{ 0 }, ForwardIterator{ 100 });
}

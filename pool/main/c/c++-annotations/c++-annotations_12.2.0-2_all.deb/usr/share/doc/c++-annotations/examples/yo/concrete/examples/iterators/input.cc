#include "input.h"

#include <numeric>
using namespace std;

int main()
{
    accumulate(InputIterator{ 0 }, InputIterator{ 100 }, 0);
}

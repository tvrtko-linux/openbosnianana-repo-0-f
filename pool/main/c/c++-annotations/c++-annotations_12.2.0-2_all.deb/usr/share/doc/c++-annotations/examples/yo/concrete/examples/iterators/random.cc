#include "random.h"

#include <algorithm>
using namespace std;

int main()
{
    sort(RandomIterator{ 0 }, RandomIterator{ 100 });
}

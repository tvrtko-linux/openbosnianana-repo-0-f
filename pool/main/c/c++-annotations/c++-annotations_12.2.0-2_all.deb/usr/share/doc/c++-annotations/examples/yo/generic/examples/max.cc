    #include <algorithm>
    #include <iostream>
    #include <string>
    #include <cstring>
    using namespace std;

    class CaseString
    {
        public:
            bool operator()(string const &first, string const &second) const
            {
                return strcasecmp(second.c_str(), first.c_str()) > 0;
            }
    };
    int main()
    {
        cout << "Word '" << max("first"s, "second"s) <<
                                    "' is lexicographically last\n";

        cout << "Word '" << max("first"s, "SECOND"s) <<
                                    "' is lexicographically last\n";

        cout << "Word '" << max("first"s, "SECOND"s,
                            CaseString{}) << "' is lexicographically last\n";
    }
    /*
        Displays:
            Word 'second' is lexicographically last
            Word 'first' is lexicographically last
            Word 'SECOND' is lexicographically last
    */

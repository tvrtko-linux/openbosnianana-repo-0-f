#include "data.ih"

Data::Data(int value)
:
    d_field(Union::VALUE),
    d_union(value)
{}

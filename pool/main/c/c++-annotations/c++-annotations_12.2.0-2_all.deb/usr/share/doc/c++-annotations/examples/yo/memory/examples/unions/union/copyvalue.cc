#include "union.ih"

void Union::copyValue(Union const &other)
{
    u_value = other.u_value;
}

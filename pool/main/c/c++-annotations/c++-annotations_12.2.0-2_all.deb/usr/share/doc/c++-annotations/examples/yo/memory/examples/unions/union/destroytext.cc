#include "union.ih"

void Union::destroyText()
{
    u_text.std::string::~string();
}

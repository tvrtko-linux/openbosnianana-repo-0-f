#include "union.ih"

Union::~Union()               // no action for unrestr. union destructors
{}

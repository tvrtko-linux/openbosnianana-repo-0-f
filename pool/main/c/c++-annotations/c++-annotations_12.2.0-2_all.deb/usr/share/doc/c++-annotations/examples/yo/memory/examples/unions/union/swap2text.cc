#include "union.ih"

void Union::swap2Text(Union &other)
{
    u_text.swap(other.u_text);
}

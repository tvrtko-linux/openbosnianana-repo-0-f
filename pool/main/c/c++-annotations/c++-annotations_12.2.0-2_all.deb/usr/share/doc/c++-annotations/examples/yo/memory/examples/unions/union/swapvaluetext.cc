#include "union.ih"

void Union::swapValueText(Union &other)
{
    other.swapTextValue(*this);
}

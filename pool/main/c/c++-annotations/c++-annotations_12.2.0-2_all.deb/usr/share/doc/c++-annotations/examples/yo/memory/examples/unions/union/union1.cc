#include "union.ih"

Union::Union(std::string const &text)
:
    u_text(text)
{}

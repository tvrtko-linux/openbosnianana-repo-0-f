#include "union.ih"

Union::Union(int value)
:
    u_value(value)
{}

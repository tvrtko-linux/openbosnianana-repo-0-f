#include <chrono>
#include <iostream>
using namespace std;

int main()
{
//milli
    cout << milli::num << ',' << milli::den << '\n' <<
            kilo::num << ',' << kilo::den << '\n';
//=
}

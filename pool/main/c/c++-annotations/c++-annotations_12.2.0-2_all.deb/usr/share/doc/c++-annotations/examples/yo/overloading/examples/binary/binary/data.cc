#include "binary.ih"

 std::unordered_map<size_t, size_t> Binary::s_copy;

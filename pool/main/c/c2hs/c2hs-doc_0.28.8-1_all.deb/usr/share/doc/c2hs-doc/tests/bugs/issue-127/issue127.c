#include "issue127.h"

bool tst(int n)
{
  return n > 0;
}

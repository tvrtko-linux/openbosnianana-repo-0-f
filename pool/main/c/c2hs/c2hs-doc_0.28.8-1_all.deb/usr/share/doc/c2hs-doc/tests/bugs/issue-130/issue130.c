#include "issue130.h"

void my_add(int *a, int *b, int *result)
{
  *result = *a + *b;
}

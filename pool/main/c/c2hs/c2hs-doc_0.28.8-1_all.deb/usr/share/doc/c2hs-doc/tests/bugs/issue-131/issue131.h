#include <stdbool.h>

int f1(int, bool);
bool f2(int);

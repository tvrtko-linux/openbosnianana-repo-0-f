typedef void *tdptst;
typedef void tdtst;

typedef struct _p_Vec *Vec;

#include <stdio.h>

void test(int arg)
{
  printf("test: %d\n", arg);
}

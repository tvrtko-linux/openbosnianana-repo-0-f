void test(int arg);

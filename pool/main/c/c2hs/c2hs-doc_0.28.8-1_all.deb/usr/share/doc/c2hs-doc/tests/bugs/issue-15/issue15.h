const int tst_val(void);

enum Tst {
  kClippingCreator = 'drag',
  kClippingPictureType = 'clpp',
  kClippingTextType = 'clpt',
  kClippingSoundType = 'clps',
  kClippingUnknownType = 'clpu'
};

typedef void (*CPLErrorHandler)(int, const char*);

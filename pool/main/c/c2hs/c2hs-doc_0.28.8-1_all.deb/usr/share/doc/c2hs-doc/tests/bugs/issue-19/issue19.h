enum enums1 {
  ENUMS_ONE   = 1,
  ENUMS_TWO   = 2,
  ENUMS_THREE = 3
};

enum enums2 {
  ENUMS_FOUR = 4,
  ENUMS_FIVE = 5,
  ENUMS_SIX  = 6
};

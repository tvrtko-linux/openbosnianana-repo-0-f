#include <stdlib.h>

size_t foo(int n);

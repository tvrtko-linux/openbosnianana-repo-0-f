extern enum hello hello_fn(int);

int foo(int n) { return n + 1; }

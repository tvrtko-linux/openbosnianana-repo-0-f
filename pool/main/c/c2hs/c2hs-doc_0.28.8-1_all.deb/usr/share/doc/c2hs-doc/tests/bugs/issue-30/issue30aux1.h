int foo1(int);

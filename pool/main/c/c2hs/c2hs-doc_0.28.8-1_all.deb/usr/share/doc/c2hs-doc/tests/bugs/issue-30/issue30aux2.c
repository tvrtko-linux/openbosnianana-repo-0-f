int foo2(int n) { return n * 4; }

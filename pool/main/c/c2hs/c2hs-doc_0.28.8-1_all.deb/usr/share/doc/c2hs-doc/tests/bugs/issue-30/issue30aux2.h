int foo2(int);

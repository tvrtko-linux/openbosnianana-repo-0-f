typedef struct { int a; } foo;

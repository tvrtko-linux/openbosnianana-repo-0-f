#include "issue48.h"

int64_t foo(int64_t n)
{
  return n + 1;
}

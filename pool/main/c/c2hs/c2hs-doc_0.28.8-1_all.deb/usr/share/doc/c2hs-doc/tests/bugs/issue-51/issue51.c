int fooGnu(int n) { return 1; }
int fooNonGnu(int n) { return 0; }

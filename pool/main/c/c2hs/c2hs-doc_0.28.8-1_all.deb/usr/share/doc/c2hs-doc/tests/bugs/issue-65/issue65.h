#define CONST1 123
#define CONST2 3.14
#define CONST3 "hello"

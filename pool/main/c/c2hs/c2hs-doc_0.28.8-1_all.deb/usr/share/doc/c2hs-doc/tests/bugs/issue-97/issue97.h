/* foo.h */
#ifndef FOO_H
#define FOO_H

typedef struct {
    int x;
    int y;
} foo_t;

int foo_x(foo_t *f);

#endif

#include "issue98.h"
char identichar(char c) { return c; }
unsigned char identiuchar(unsigned char c) { return c; }
signed char identischar(signed char c) { return c; }

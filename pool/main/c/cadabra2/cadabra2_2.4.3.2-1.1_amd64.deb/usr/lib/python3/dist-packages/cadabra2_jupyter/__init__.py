__version__ = "2.4.3"
SITE_PATH = "/usr/lib/python3.11/site-packages"

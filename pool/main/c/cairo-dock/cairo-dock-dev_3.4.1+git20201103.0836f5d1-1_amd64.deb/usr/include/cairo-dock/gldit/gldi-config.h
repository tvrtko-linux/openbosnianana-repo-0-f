
#ifndef __GLDI_INTERNAL_CONFIG_H__
#define __GLDI_INTERNAL_CONFIG_H__

/* Defined if we can use X. */
#define HAVE_X11 1

/* Defined if we can use GLX. */
#define HAVE_GLX 1

/* Defined if we can use X Extensions. */
#define HAVE_XEXTEND 1

/* Defined if we can use Xinerama. */
#define HAVE_XINERAMA 1

/* Defined if we can use Wayland. */
#define HAVE_WAYLAND 1

/* Defined if we can use EGL. */
/* #undef HAVE_EGL */

/* Defined if we can crypt passwords. */
/* #undef HAVE_LIBCRYPT */

/* Define to 1 if you have the `dl' library (-ldl). */
#define HAVE_LIBDL 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

#define GLDI_GETTEXT_PACKAGE "cairo-dock"
#define GLDI_VERSION "3.4.1"
#define GLDI_SHARE_DATA_DIR "/usr/share/cairo-dock"
/* #undef AVOID_PATENT_CRAP */

#endif

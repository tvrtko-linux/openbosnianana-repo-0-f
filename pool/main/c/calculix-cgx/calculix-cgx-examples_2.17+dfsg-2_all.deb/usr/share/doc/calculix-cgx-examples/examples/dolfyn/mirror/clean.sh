#!/bin/sh

rm ingang.sur 
rm spiegel.sur
rm tunnel.sur
rm uitgang.sur
rm vloer.sur
rm spiegel.bnd
rm spiegel.dge
rm spiegel.frd
rm spiegel.odx
rm spiegel.vtk
rm spiegel.cel
rm spiegel.res
rm spiegel.txt
rm spiegel.dbg
rm spiegel.mon
rm spiegel.rst
rm spiegel.vrt

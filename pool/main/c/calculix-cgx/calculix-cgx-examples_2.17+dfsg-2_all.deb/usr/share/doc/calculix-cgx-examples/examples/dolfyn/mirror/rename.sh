#!/bin/sh

mv all.bnd spiegel.bnd
mv all.cel spiegel.cel
mv all.vrt spiegel.vrt

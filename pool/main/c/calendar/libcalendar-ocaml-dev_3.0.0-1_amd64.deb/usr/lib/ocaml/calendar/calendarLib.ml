(** @canonical CalendarLib.Calendar *)
module Calendar = CalendarLib__Calendar


(** @canonical CalendarLib.Calendar_builder *)
module Calendar_builder = CalendarLib__Calendar_builder


(** @canonical CalendarLib.Calendar_sig *)
module Calendar_sig = CalendarLib__Calendar_sig


(** @canonical CalendarLib.Date *)
module Date = CalendarLib__Date


(** @canonical CalendarLib.Date_sig *)
module Date_sig = CalendarLib__Date_sig


(** @canonical CalendarLib.Fcalendar *)
module Fcalendar = CalendarLib__Fcalendar


(** @canonical CalendarLib.Ftime *)
module Ftime = CalendarLib__Ftime


(** @canonical CalendarLib.Period *)
module Period = CalendarLib__Period


(** @canonical CalendarLib.Printer *)
module Printer = CalendarLib__Printer


(** @canonical CalendarLib.Time *)
module Time = CalendarLib__Time


(** @canonical CalendarLib.Time_Zone *)
module Time_Zone = CalendarLib__Time_Zone


(** @canonical CalendarLib.Time_sig *)
module Time_sig = CalendarLib__Time_sig


(** @canonical CalendarLib.Utils *)
module Utils = CalendarLib__Utils


(** @canonical CalendarLib.Version *)
module Version = CalendarLib__Version

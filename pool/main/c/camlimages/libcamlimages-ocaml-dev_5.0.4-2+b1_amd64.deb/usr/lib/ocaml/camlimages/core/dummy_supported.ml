(* A dummy module to make the compilation works even when
   there is no supported subpackages require external libs *)
 

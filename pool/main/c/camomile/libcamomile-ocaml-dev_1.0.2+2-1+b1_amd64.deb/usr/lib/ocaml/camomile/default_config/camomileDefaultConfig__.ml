(** @canonical CamomileDefaultConfig.InstallConfig *)
module InstallConfig = CamomileDefaultConfig__InstallConfig

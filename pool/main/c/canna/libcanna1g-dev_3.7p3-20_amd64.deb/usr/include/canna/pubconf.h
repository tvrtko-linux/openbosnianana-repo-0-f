/* Generated file. Modify "configure.ac" instead of this file. */
#ifndef CANNA_PUBCONF_H
#define CANNA_PUBCONF_H

#define CANNA_HAVE_INTTYPES_H 1
#define CANNA_HAVE_STDINT_H 1
#define CANNA_HAVE_INT32_T 1

#endif /* CANNA_PUBCONF_H */

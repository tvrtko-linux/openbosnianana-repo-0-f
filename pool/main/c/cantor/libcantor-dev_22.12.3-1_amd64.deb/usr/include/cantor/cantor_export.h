
#ifndef CANTOR_EXPORT_H
#define CANTOR_EXPORT_H

#ifdef CANTOR_STATIC_DEFINE
#  define CANTOR_EXPORT
#  define CANTOR_NO_EXPORT
#else
#  ifndef CANTOR_EXPORT
#    ifdef cantorlibs_EXPORTS
        /* We are building this library */
#      define CANTOR_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define CANTOR_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef CANTOR_NO_EXPORT
#    define CANTOR_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef CANTOR_DEPRECATED
#  define CANTOR_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef CANTOR_DEPRECATED_EXPORT
#  define CANTOR_DEPRECATED_EXPORT CANTOR_EXPORT CANTOR_DEPRECATED
#endif

#ifndef CANTOR_DEPRECATED_NO_EXPORT
#  define CANTOR_DEPRECATED_NO_EXPORT CANTOR_NO_EXPORT CANTOR_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef CANTOR_NO_DEPRECATED
#    define CANTOR_NO_DEPRECATED
#  endif
#endif

#endif /* CANTOR_EXPORT_H */

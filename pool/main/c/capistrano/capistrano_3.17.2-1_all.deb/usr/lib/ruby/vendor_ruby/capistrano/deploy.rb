require "capistrano/framework"

load File.expand_path("../tasks/deploy.rake", __FILE__)

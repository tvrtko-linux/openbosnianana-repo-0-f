load File.expand_path("../tasks/framework.rake", __FILE__)
require "capistrano/install"

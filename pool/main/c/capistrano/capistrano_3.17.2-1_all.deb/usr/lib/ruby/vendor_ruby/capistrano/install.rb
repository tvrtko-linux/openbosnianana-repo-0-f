load File.expand_path(File.join(File.dirname(__FILE__), "tasks/install.rake"))

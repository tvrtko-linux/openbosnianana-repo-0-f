module Capistrano
  VERSION = "3.17.2".freeze
end

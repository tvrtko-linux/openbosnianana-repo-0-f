TRANSGIRONDE_STOPS_LIST = {
[1005] = "Mérignac - Quatre Chemins",
[6001] = "Andernos - Centre"
}

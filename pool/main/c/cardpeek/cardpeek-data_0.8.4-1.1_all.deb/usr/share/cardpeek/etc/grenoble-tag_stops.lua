STOPS_LIST = {
[1018] = "Grenoble - Île Verte",
[1019] = "Grenoble - Victor Hugo"
}

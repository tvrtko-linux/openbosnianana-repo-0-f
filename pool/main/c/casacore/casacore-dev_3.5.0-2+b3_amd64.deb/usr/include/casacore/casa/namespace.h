#ifndef CASACORE_NAMESPACE_H
#define CASACORE_NAMESPACE_H 
#include <casacore/casa/aips.h>
using namespace casacore;
#endif

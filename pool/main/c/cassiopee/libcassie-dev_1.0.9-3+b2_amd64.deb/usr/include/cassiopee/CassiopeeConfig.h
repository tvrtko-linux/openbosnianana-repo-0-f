// the configured options and settings for Cassiopee
#define Cassiopee_VERSION_MAJOR 1
#define Cassiopee_VERSION_MINOR 0

#define use_openmp 1

#define SUFFIX_CHUNK_SIZE 10

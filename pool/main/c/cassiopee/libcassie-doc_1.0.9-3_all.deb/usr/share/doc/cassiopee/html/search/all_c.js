var searchData=
[
  ['save_33',['save',['../classCassieIndexer.html#a481f1dd85b429fbf6dc069f28acd2d83',1,'CassieIndexer']]],
  ['search_34',['search',['../classCassieSearch.html#ac5cf07a153f4021af5a0f511ec93ee8b',1,'CassieSearch::search(string suffix, bool clear)'],['../classCassieSearch.html#a5b3d92321ddb079559dc7cf53eb74563',1,'CassieSearch::search(string suffix)'],['../classCassieSearch.html#aeda2101931351dd1f96dd4c250686fde',1,'CassieSearch::search(string suffixes[])']]],
  ['sort_35',['sort',['../classCassieSearch.html#a66106eb57decacbf1ee551d9de72636b',1,'CassieSearch']]],
  ['subst_36',['subst',['../classMatch.html#a49c59d7e78506851688892c7834d275c',1,'Match']]]
];

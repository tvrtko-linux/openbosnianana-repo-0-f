var searchData=
[
  ['save_59',['save',['../classCassieIndexer.html#a481f1dd85b429fbf6dc069f28acd2d83',1,'CassieIndexer']]],
  ['search_60',['search',['../classCassieSearch.html#ac5cf07a153f4021af5a0f511ec93ee8b',1,'CassieSearch::search(string suffix, bool clear)'],['../classCassieSearch.html#a5b3d92321ddb079559dc7cf53eb74563',1,'CassieSearch::search(string suffix)'],['../classCassieSearch.html#aeda2101931351dd1f96dd4c250686fde',1,'CassieSearch::search(string suffixes[])']]],
  ['sort_61',['sort',['../classCassieSearch.html#a66106eb57decacbf1ee551d9de72636b',1,'CassieSearch']]]
];

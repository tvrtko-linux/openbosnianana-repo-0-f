var searchData=
[
  ['in_68',['in',['../classMatch.html#aa88040760fb141bd06119335a6224599',1,'Match']]]
];

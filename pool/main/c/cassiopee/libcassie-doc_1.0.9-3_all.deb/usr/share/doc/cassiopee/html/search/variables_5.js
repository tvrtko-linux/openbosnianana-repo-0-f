var searchData=
[
  ['next_5flength_76',['next_length',['../classTreeNode.html#abcdf798306e96401e94544f87ad914be',1,'TreeNode']]],
  ['next_5fpos_77',['next_pos',['../classTreeNode.html#ad4653b8cfd5f2fe1d1d2d333545897a6',1,'TreeNode']]],
  ['nmax_78',['nmax',['../classCassieSearch.html#a730a851a7e6833e6248562e0900a8711',1,'CassieSearch']]]
];

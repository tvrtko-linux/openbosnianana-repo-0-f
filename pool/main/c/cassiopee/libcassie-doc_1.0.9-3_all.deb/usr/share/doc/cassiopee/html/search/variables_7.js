var searchData=
[
  ['subst_80',['subst',['../classMatch.html#a49c59d7e78506851688892c7834d275c',1,'Match']]]
];

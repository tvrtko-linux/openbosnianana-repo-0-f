#!/usr/bin/env python3

__author__ = 'F. A. Bastiaan von Meijenfeldt'
__version__ = '5.2.3'
__date__ = '10 February, 2021'

C-BIOS machine configurations for openMSX
=========================================

Note: these configurations will only work in openMSX 0.9.2 or later.

Installation instructions:
1. Copy "C-BIOS_*" files to "share/machines" in the openMSX
   installation directory or the openMSX user directory.
2. Copy "cbios_*.rom" to the openMSX ROM pool ("share/systemroms").

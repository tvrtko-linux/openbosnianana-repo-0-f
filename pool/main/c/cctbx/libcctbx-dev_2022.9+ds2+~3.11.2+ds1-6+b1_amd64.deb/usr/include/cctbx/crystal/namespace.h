// Documentation only. Do not include.
namespace cctbx {

//! Crystal symmetry: unit cell + space group.
namespace crystal {}

} // namespace cctbx

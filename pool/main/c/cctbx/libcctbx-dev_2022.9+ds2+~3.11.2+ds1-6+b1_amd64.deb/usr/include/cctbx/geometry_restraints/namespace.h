// Documentation only. Do not include.
namespace cctbx {

//! Geometry restraints (bond, angle, etc.).
namespace geometry_restraints {}

} // namespace cctbx

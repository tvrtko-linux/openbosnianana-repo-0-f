#ifndef CCTBX_IMPORT_SCITBX_AF_H
#define CCTBX_IMPORT_SCITBX_AF_H

namespace scitbx { namespace af {
}}

namespace cctbx {
  namespace af = scitbx::af;
}

#endif // CCTBX_IMPORT_SCITBX_AF_H

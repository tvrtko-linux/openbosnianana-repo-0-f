// Documentation only. Do not include.
namespace cctbx {

//! Map algorithms.
namespace maptbx {

//! Copy structure factors to and from complex maps.
namespace structure_factors {

}}} // namespace cctbx

// Documentation only. Do not include.
namespace cctbx {

//! Translation searches.
namespace translation_search {}

} // namespace cctbx

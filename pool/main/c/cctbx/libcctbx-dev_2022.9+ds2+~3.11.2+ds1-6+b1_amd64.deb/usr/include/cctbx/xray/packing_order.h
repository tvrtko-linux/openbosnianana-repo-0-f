#ifndef CCTBX_XRAY_PACKING_ORDER_H
#define CCTBX_XRAY_PACKING_ORDER_H

namespace cctbx { namespace xray {

  static const int packing_order_convention = 2;

}} // namespace cctbx::xray

#endif // CCTBX_XRAY_PACKING_ORDER_H

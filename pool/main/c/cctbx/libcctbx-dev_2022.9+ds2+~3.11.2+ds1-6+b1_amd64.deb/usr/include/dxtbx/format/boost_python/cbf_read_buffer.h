#ifndef CBF_READ_BUFFER_H
#define CBF_READ_BUFFER_H

namespace dxtbx { namespace format { namespace boost_python {
  void export_cbf_read_buffer();
}}}  // namespace dxtbx::format::boost_python

#endif

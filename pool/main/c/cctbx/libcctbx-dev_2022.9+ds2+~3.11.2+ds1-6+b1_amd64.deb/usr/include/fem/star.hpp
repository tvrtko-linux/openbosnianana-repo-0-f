#ifndef FEM_STAR_HPP
#define FEM_STAR_HPP

namespace fem {

  struct star_type {};

  static const star_type star = star_type();

} // namespace fem

#endif // GUARD

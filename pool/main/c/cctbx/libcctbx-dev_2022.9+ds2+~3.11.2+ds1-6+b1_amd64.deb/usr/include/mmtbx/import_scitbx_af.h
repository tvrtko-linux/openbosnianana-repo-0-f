#ifndef MMTBX_IMPORT_SCITBX_AF_H
#define MMTBX_IMPORT_SCITBX_AF_H

namespace scitbx { namespace af {
}}

namespace mmtbx {
  namespace af = scitbx::af;
}

#endif // MMTBX_IMPORT_SCITBX_AF_H

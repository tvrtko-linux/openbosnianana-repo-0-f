#ifndef RSTBX_IMPORT_SCITBX_AF_HPP
#define RSTBX_IMPORT_SCITBX_AF_HPP

namespace scitbx { namespace af {
}}

namespace rstbx {
  namespace af = scitbx::af;
}

#endif // GUARD

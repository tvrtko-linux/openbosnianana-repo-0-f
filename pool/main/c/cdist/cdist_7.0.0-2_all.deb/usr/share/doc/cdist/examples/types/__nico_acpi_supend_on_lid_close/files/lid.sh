#!/bin/sh
# Nico Schottelius, 20111016
# Just suspend, my wife does not like to enter a password

/usr/sbin/pm-suspend

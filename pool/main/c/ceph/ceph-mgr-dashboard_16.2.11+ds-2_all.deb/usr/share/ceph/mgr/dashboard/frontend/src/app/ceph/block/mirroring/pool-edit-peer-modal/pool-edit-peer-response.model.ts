export class PoolEditPeerResponseModel {
  cluster_name: string;
  client_id: string;
  mon_host: string;
  key: string;
  uuid: string;
}

import { RbdFormModel } from './rbd-form.model';

export class RbdFormCreateRequestModel extends RbdFormModel {
  features: Array<string> = [];
}

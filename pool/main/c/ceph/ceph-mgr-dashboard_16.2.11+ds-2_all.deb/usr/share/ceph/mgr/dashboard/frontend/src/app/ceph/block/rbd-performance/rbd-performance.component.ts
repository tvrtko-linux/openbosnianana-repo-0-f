import { Component } from '@angular/core';

@Component({
  selector: 'cd-rbd-performance',
  templateUrl: './rbd-performance.component.html',
  styleUrls: ['./rbd-performance.component.scss']
})
export class RbdPerformanceComponent {}

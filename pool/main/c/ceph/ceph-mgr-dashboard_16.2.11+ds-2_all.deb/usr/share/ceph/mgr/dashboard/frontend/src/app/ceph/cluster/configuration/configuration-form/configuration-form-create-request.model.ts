export class ConfigFormCreateRequestModel {
  name: string;
  value: Array<any> = [];
}

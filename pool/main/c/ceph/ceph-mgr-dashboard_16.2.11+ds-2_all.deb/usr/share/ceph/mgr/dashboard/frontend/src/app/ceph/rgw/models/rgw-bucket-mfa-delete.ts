export enum RgwBucketMfaDelete {
  ENABLED = 'Enabled',
  DISABLED = 'Disabled'
}

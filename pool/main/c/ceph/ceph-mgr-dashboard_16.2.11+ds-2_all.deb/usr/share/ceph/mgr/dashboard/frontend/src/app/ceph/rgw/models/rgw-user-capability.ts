export class RgwUserCapability {
  type: string;
  perm: string;
}

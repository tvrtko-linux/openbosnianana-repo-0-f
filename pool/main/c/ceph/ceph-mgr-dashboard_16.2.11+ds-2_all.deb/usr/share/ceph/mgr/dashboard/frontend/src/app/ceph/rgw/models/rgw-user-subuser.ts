export class RgwUserSubuser {
  id: string;
  permissions: string;
  generate_secret?: boolean;
  secret_key?: string;
}

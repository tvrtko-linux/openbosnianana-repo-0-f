[![Build Status](https://travis-ci.org/TinoDidriksen/cg3.svg?branch=master)](https://travis-ci.org/TinoDidriksen/cg3)

See instead:
- https://visl.sdu.dk/constraint_grammar.html
- https://visl.sdu.dk/cg3.html
- https://visl.sdu.dk/cg3/chunked/
- manual/
- http://groups.google.com/group/constraint-grammar

Other links:
- https://visl.sdu.dk/svn/visl/tools/vislcg3/trunk/
- https://en.wikipedia.org/wiki/Constraint_Grammar
- http://wiki.apertium.org/wiki/Constraint_Grammar
- http://kevindonnelly.org.uk/2010/05/constraint-grammar-tutorial/
- http://openhub.net/p/cg3

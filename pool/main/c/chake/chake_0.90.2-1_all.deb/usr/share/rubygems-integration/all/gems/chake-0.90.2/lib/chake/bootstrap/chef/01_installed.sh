# chef-solo already installed
if which chef-solo >/dev/null 2>&1; then
  exit
fi

# itamae already installed
if which itamae >/dev/null 2>&1; then
  exit
fi

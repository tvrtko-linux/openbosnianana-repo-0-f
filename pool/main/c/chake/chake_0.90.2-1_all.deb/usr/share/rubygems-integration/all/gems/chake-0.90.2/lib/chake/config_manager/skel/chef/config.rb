root = __dir__
file_cache_path   "#{root}/cache"
cookbook_path     "#{root}/cookbooks"
role_path         "#{root}/config/roles"

module Chake
  VERSION = '0.90.2'.freeze
end

#! /usr/bin/python3

from changeme import core

if __name__ == '__main__':
    core.main()

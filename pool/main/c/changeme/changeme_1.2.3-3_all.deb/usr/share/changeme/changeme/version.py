__version__ = '1.2.3'
contributors = [
    "ztgrace",
    "the-c0d3r",
    "Graph-X",
    "AlessandroZ",
    "ThomasTJ",
    "Alistair Chapman",
    "John Van de Meulebrouck Brendgard",
    "network23",
    "decidedlygray",
    "Joe Testa",
    "Chandrapal",
    "Naglis Jonaitis",
    "Samuel Henrique",
    "sil3ntcor3",
]

#!/bin/sh

set -e

echo 'hello world'

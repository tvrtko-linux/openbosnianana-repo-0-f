int increment(int a);

int increment(int a)
{
   return a + 1;
}

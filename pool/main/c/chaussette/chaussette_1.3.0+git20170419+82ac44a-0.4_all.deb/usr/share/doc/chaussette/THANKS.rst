Chaussette was created by Tarek Ziade. 
It is maintained by Tarek Ziade and David Douard.

Here's a list of other contributors:

- Myoung-su Shin
- Trey Long
- Jannis Leidel
- Danilo Maurizio
- Emmanuel Raviart
- Pedro Romano
- Victor Fernandez de Alba
- Gilles Devaux
- INADA Naoki

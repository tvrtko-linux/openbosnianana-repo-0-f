Please see the Checker Framework manual
([HTML](https://checkerframework.org/manual/),
[PDF](https://checkerframework.org/manual/checker-framework-manual.pdf)).

The history of releases and changes is in file
[changelog.txt](changelog.txt).

Documentation for Checker Framework developers
is in directory `docs/developer/`.

* minimal.jxr - JPEG XR, based on minimal_valid.tif created via GIMP plugin http://registry.gimp.org/node/25508
* minimal.mdi - Microsoft Image Document, based on minimal_valid.tif, only header is changed
* minimal.tiff64 - BigTIFF, based on minimal_valid.tif created via libtiff tools

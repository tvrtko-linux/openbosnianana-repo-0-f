# shell script fragment setting options
# defaults for currently implemented parameters are
#lvm_vg=
#lvm_lv=chiark_backup
#lvm_lvsize_opts=
# -l <min(no. of free extents in vg, 1.1x total lv size)> (lvm)
# -l <min(no. of free extents in vg, 1.5x total space used)> (remountrocp)
#lvm_lvtools_opts='-A n'
#lvm_lvcreate_opts=
#lvm_lvcreate_args=

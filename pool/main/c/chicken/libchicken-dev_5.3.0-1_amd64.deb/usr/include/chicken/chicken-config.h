/* GENERATED */
#define HAVE_DIRENT_H 1
#define HAVE_DLFCN_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_LIMITS_H 1
#define HAVE_LONG_LONG 1
#define HAVE_MEMMOVE 1
#define HAVE_MEMORY_H 1
#define HAVE_SIGACTION 1
#define HAVE_SIGSETJMP 1
#define HAVE_SIGPROCMASK 1
#define HAVE_STDINT_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRERROR 1
#define HAVE_STRINGS_H 1
#define HAVE_STRING_H 1
#define HAVE_STRTOLL 1
#define HAVE_STRTOQ 1
#define HAVE_SYS_STAT_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_SETENV 1
#define HAVE_UNISTD_H 1
#define HAVE_UNSIGNED_LONG_LONG 1
#define STDC_HEADERS 1
#define HAVE_ALLOCA 1
#define HAVE_ALLOCA_H 1
#define HAVE_ERRNO_H 1
#define HAVE_SYSEXITS_H 1
#define C_STACK_GROWS_DOWNWARD 1
#define C_USE_STD_FEATURE_MACROS
#define C_CHICKEN_PROGRAM "chicken"
#ifndef C_INSTALL_CC
# define C_INSTALL_CC "x86_64-linux-gnu-gcc"
#endif
#ifndef C_INSTALL_CXX
# define C_INSTALL_CXX "x86_64-linux-gnu-g++"
#endif
#ifndef C_INSTALL_POSTINSTALL_PROGRAM
# define C_INSTALL_POSTINSTALL_PROGRAM "true"
#endif
#ifndef C_INSTALL_RC_COMPILER
# define C_INSTALL_RC_COMPILER ""
#endif
#ifndef C_INSTALL_CFLAGS
# define C_INSTALL_CFLAGS "-fno-strict-aliasing -fwrapv -DHAVE_CHICKEN_CONFIG_H -DC_ENABLE_PTABLES -g -O2 -ffile-prefix-map=/build/chicken-lFRG2K/chicken-5.3.0=. -fstack-protector-strong -Wformat -Werror=format-security -Wdate-time -D_FORTIFY_SOURCE=2"
#endif
#ifndef C_INSTALL_LDFLAGS
# define C_INSTALL_LDFLAGS " "
#endif
#ifndef C_INSTALL_PREFIX
# define C_INSTALL_PREFIX "/usr"
#endif
#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME "/usr/share/chicken"
#endif
#ifndef C_INSTALL_BIN_HOME
# define C_INSTALL_BIN_HOME "/usr/bin"
#endif
#ifndef C_INSTALL_EGG_HOME
# define C_INSTALL_EGG_HOME "/var/lib//chicken/11"
#endif
#ifndef C_INSTALL_LIB_HOME
# define C_INSTALL_LIB_HOME "/usr/lib"
#endif
#ifndef C_INSTALL_LIB_NAME
# define C_INSTALL_LIB_NAME "chicken"
#endif
#ifndef C_INSTALL_STATIC_LIB_HOME
# define C_INSTALL_STATIC_LIB_HOME "/usr/lib"
#endif
#ifndef C_INSTALL_INCLUDE_HOME
# define C_INSTALL_INCLUDE_HOME "/usr/include/chicken"
#endif
#ifndef C_INSTALL_MORE_LIBS
# define C_INSTALL_MORE_LIBS "-lm -ldl"
#endif
#ifndef C_INSTALL_MORE_STATIC_LIBS
# define C_INSTALL_MORE_STATIC_LIBS "-lm -ldl"
#endif
#ifndef C_STACK_GROWS_DOWNWARD
# define C_STACK_GROWS_DOWNWARD 1
#endif
#ifndef C_TARGET_MORE_LIBS
# define C_TARGET_MORE_LIBS "-lm -ldl"
#endif
#ifndef C_TARGET_MORE_STATIC_LIBS
# define C_TARGET_MORE_STATIC_LIBS "-lm -ldl"
#endif
#ifndef C_TARGET_CC
# define C_TARGET_CC "x86_64-linux-gnu-gcc"
#endif
#ifndef C_TARGET_CXX
# define C_TARGET_CXX "x86_64-linux-gnu-g++"
#endif
#ifndef C_TARGET_RC_COMPILER
# define C_TARGET_RC_COMPILER ""
#endif
#ifndef C_TARGET_LIBRARIAN
# define C_TARGET_LIBRARIAN "x86_64-linux-gnu-ar"
#endif
#ifndef C_TARGET_INSTALL_PROGRAM
# define C_TARGET_INSTALL_PROGRAM "install"
#endif
#ifndef C_TARGET_CFLAGS
# define C_TARGET_CFLAGS "-fno-strict-aliasing -fwrapv -DHAVE_CHICKEN_CONFIG_H -DC_ENABLE_PTABLES -g -O2 -ffile-prefix-map=/build/chicken-lFRG2K/chicken-5.3.0=. -fstack-protector-strong -Wformat -Werror=format-security -Wdate-time -D_FORTIFY_SOURCE=2"
#endif
#ifndef C_TARGET_LIBRARIAN_FLAGS
# define C_TARGET_LIBRARIAN_FLAGS "cru"
#endif
#ifndef C_TARGET_LDFLAGS
# define C_TARGET_LDFLAGS " "
#endif
#ifndef C_TARGET_INSTALL_PROGRAM_EXECUTABLE_OPTIONS
# define C_TARGET_INSTALL_PROGRAM_EXECUTABLE_OPTIONS "-m 755"
#endif
#ifndef C_TARGET_INSTALL_PROGRAM_FILE_OPTIONS
# define C_TARGET_INSTALL_PROGRAM_FILE_OPTIONS "-m 644"
#endif
#ifndef C_TARGET_FEATURES
# define C_TARGET_FEATURES ""
#endif
#ifndef C_CROSS_CHICKEN
# define C_CROSS_CHICKEN 0
#endif
#ifndef C_TARGET_PREFIX
# define C_TARGET_PREFIX "/usr"
#endif
#ifndef C_TARGET_BIN_HOME
# define C_TARGET_BIN_HOME "/usr/bin"
#endif
#ifndef C_TARGET_LIB_HOME
# define C_TARGET_LIB_HOME "/usr/lib"
#endif
#ifndef C_TARGET_LIB_NAME
# define C_TARGET_LIB_NAME "chicken"
#endif
#ifndef C_TARGET_RUN_LIB_HOME
# define C_TARGET_RUN_LIB_HOME "/usr/lib"
#endif
#ifndef C_TARGET_SHARE_HOME
# define C_TARGET_SHARE_HOME "/usr/share/chicken"
#endif
#ifndef C_TARGET_INCLUDE_HOME
# define C_TARGET_INCLUDE_HOME "/usr/include/chicken"
#endif
#ifndef C_TARGET_STATIC_LIB_HOME
# define C_TARGET_STATIC_LIB_HOME "/usr/lib"
#endif
#ifndef C_CHICKEN_PROGRAM
# define C_CHICKEN_PROGRAM "chicken"
#endif
#ifndef C_CSC_PROGRAM
# define C_CSC_PROGRAM "csc"
#endif
#ifndef C_CSI_PROGRAM
# define C_CSI_PROGRAM "csi"
#endif
#ifndef C_CHICKEN_DO_PROGRAM
# define C_CHICKEN_DO_PROGRAM "chicken-do"
#endif
#ifndef C_CHICKEN_INSTALL_PROGRAM
# define C_CHICKEN_INSTALL_PROGRAM "chicken-install"
#endif
#ifndef C_CHICKEN_UNINSTALL_PROGRAM
# define C_CHICKEN_UNINSTALL_PROGRAM "chicken-uninstall"
#endif
#ifndef C_CHICKEN_STATUS_PROGRAM
# define C_CHICKEN_STATUS_PROGRAM "chicken-status"
#endif
#ifndef C_WINDOWS_SHELL
# define C_WINDOWS_SHELL 0
#endif
#ifndef C_BINARY_VERSION
# define C_BINARY_VERSION 11
#endif
#ifndef C_USES_SONAME
# define C_USES_SONAME 1
#endif
/* END OF FILE */

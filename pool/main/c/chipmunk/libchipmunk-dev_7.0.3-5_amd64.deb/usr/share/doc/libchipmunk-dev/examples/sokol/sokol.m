// Blegh. Will deal with Metal later.
#define GL_SILENCE_DEPRECATION

#define SOKOL_IMPL
#include "sokol.h"

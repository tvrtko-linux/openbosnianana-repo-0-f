#!/usr/bin/env python

from circuits import Component


class MyComponent(Component):

    """My Component"""

MyComponent().run()

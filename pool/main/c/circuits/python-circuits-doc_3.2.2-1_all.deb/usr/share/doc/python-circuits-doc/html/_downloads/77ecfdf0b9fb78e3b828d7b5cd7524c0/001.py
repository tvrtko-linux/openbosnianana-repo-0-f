#!/usr/bin/env python

from circuits import Component

Component().run()

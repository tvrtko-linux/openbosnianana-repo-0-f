================
PyPi README Page
================


.. include:: ../../README.rst

/* global describe, it, expect, ToolbarConfigurator */

describe( 'Full toolbar configurator', function() {
	var FTE = ToolbarConfigurator.FullToolbarEditor;

	it( 'exists', function() {
		expect( FTE ).to.be.a( 'function' );
	} );
} );

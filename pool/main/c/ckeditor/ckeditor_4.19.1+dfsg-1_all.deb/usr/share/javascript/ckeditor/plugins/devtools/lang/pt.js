﻿/*
 Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("devtools","pt",{title:"Informação do elemento",dialogName:"Nome da janela de diálogo",tabName:"Nome do separador",elementId:"ID do elemento",elementType:"Tipo de elemento"});
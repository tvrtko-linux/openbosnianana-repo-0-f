# cl-github-v3 - Common Lisp interface to the github V3 API

This library implements a thin wrapper around
[github's V3 API](http://developer.github.com/).  At this point, it is
incomplete and only defines CL functions for listing and creating
repositories.

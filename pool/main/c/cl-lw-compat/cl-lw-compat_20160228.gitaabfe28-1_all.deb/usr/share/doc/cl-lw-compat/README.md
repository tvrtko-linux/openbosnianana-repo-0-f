# lw-compat
A few utility functions from the LispWorks library that I regularly use, ported to other Common Lisp implementations.

lw-compat is also provided by [Quicklisp](https://www.quicklisp.org/).

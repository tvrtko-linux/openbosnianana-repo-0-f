/* test' comment tef-4-1
with multiple lines
  --*/

  insert into company_employees (id,name,age,address,include_file,join_date) values (10, 'Catharina', 32, 'Vienna', 'sub1/tef-4.sql','2011-04-13');

/* test' comment tef-5-1
with multiple lines
  --*/

  insert into company_employees (id,name,age,address,include_file,join_date) values (11, 'Lisa', 32, 'Frankfurt', 'sub1/tef-5.sql','2011-04-13');

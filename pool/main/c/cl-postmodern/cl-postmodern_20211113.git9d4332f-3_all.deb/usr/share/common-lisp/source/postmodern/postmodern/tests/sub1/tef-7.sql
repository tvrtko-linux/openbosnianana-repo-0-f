/* test' comment tef-7-1
with multiple lines
  --*/

  insert into company_employees (id,name,age,address,include_file,join_date) values (155, 'Victor', 32, 'Warsaw', 'tef-7.sql','2011-04-13');

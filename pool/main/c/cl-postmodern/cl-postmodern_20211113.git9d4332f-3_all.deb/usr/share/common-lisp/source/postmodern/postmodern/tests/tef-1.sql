/* test' comment tef-1-1
with multiple lines
  --*/

  insert into company_employees (id,name,age,address,include_file,join_date) values (7, 'Robert', 32, 'Paris', 'tef-1.sql','2011-04-13');

/*
\i tef-2.sql
*/

-- \i tef-1.sql

/* test' comment tef-2-1
with multiple lines
  --*/

  insert into company_employees (id,name,age,address,include_file,join_date) values (8, 'Juan', 32, 'Madrid', 'tef-2.sql','2011-04-13');

/* test' comment tef-3-1
with multiple lines
  --*/

  insert into company_employees (id,name,age,address,include_file,join_date) values (9, 'Julian', 32, 'Athens', 'tef-3.sql','2011-04-13');

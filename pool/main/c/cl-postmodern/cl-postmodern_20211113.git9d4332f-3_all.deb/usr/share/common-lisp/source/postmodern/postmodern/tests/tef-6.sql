/* test' comment tef-6-1
with multiple lines
  --*/

  insert into company_employees (id,name,age,address,include_file,join_date) values (13, 'Stan', 32, 'Warsaw', 'tef-6.sql','2011-04-13');

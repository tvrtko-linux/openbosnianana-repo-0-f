/* claws-features.h.  Generated from claws-features.h.in by configure.  */
#define HAVE_DBUS_GLIB 1
#define HAVE_DIRENT_D_TYPE 1
#define HAVE_LIBCOMPFACE 1
#define HAVE_LIBETPAN 1
#define HAVE_LIBSM 1
#define HAVE_NETWORKMANAGER_SUPPORT 1
/* #undef HAVE_STARTUP_NOTIFICATION */
/* #undef HAVE_VALGRIND */
#define HAVE_SVG 1
/* #undef USE_BOGOFILTER_PLUGIN */
#define USE_ENCHANT 1
#define USE_GNUTLS 1
#define USE_GPGME 1
/* #undef USE_JPILOT */
#define USE_LDAP 1
#define USE_LDAP_TLS 1
/* #undef USE_ALT_ADDRBOOK */
#define USE_PTHREAD 1
/* #undef USE_SPAMASSASSIN_PLUGIN */
/* #undef __CYGWIN__ */

export CLANG="/usr/lib/llvm-14/bin/clang++"
export CLANG_APPLY_REPLACEMENTS="/usr/lib/llvm-14/bin/clang-apply-replacements"

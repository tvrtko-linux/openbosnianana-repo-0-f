# connect-non-signal

Warns when connecting a non-signal to something.

For example:
`connect(obj, &MyObj::mySlot, ...);`

Only works with the new Qt5 connect syntax (PMF).

# lowercase-qml-type-name

Warns when QML types registered with `qmlRegisterType()` or `qmlRegisterUncreatableType()`
don't start with uppercase. It's required by the QML engine that they do.

# qenums

Warns when you're using `Q_ENUMS`. Use Q_ENUM instead.

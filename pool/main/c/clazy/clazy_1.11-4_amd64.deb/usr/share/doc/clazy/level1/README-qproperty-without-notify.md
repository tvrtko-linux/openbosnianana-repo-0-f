# qproperty-without-notify

Warns when a non-CONSTANT Q_PROPERTY is missing a NOTIFY signal.

Objects used in QML (e.g. Qt Quick or Declarative Widgets) need to notify when a property changes.
This is also useful when viewing QObject properties in Gammaray.


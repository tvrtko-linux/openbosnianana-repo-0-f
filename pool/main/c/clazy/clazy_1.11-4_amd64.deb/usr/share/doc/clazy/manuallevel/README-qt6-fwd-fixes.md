# qt6-fwd-fixes

Warns against forward declaration that are present in  `<QtCore/qcontainerfwd.h>`

Include the file instead if not already included.

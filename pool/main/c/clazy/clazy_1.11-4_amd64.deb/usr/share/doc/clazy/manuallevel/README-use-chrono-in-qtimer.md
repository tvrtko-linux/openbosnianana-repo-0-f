# use-chrono-in-qtimer

Find places where a number is used with QTimer's `start`, `setElapsed` or `singleShot` methods,
and suggests to use chrono literals instead.

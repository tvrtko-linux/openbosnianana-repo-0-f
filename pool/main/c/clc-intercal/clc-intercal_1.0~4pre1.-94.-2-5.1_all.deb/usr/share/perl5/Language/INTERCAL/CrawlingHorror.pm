package Language::INTERCAL::CrawlingHorror;

# Placeholders to talk about grammars. Not used to store any value but.

# This file is part of CLC-INTERCAL

# Copyright (c) 2007-2008 Claudio Calvelli, all rights reserved.

# CLC-INTERCAL is copyrighted software. However, permission to use, modify,
# and distribute it is granted provided that the conditions set out in the
# licence agreement are met. See files README and COPYING in the distribution.

use strict;
use vars qw($VERSION $PERVERSION);
($VERSION) = ($PERVERSION = "CLC-INTERCAL/Base INTERCAL/CrawlingHorror.pm 1.-94.-2") =~ /\s(\S+)$/;

use Carp;
use Language::INTERCAL::Exporter '1.-94.-2';
use Language::INTERCAL::Splats '1.-94.-2', qw(:SP);
use Language::INTERCAL::DataItem '1.-94.-2';
use vars qw(@ISA);
@ISA = qw(Language::INTERCAL::DataItem);

sub new {
    @_ == 1 or croak "Usage: new Language::INTERCAL::CrawlingHorror";
    my ($class) = @_;
    bless qr/^/, $class;
}

sub copy {
    @_ == 1 or croak "Usage: CLASS->copy";
    my ($cho) = @_;
    bless qr/^/, ref $cho;
}

# can't really do much with one of these...

sub filehandle { faint(SP_NOVALUE) }
sub _store { faint(SP_NOVALUE) }
sub _get { faint(SP_NOVALUE) }
sub _assign { faint(SP_NOVALUE) }
sub tail { faint(SP_NOVALUE) }
sub hybrid { faint(SP_NOVALUE) }
sub as_list { faint(SP_NOVALUE) }
sub as_string { faint(SP_NOVALUE) }
sub digits { faint(SP_NOVALUE) }
sub elements { faint(SP_NOVALUE) }
sub number { faint(SP_NOVALUE) }
sub range { faint(SP_NOVALUE) }
sub spot { faint(SP_NOVALUE) }
sub twospot { faint(SP_NOVALUE) }

1;

#!/bin/bash
/usr/libexec/clevis-luks-askpass

var annotated_dup =
[
    [ "clfftSetupData", "structclfftSetupData__.html", "structclfftSetupData__" ]
];
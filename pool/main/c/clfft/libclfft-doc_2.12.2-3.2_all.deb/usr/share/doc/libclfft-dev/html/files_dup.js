var files_dup =
[
    [ "clFFT.h", "clFFT_8h.html", "clFFT_8h" ],
    [ "mainpage.h", "mainpage_8h_source.html", null ]
];
var searchData=
[
  ['debugflags_76',['debugFlags',['../structclfftSetupData__.html#aa69766b2183dafd7b57f4997ce2303a2',1,'clfftSetupData_']]]
];

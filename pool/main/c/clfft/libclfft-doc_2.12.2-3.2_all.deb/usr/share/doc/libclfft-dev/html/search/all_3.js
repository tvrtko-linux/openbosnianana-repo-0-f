var searchData=
[
  ['major_83',['major',['../structclfftSetupData__.html#a04260899b0439f27de6f9ff79b91dfcb',1,'clfftSetupData_']]],
  ['minor_84',['minor',['../structclfftSetupData__.html#ab561c9a70d46d4129853dcf9631c883d',1,'clfftSetupData_']]]
];

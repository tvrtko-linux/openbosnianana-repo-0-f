var searchData=
[
  ['opencl_20fast_20fourier_20transforms_20_28ffts_29_85',['OpenCL Fast Fourier Transforms (FFTs)',['../index.html',1,'']]]
];

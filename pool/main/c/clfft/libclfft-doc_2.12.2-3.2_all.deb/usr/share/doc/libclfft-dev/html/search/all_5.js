var searchData=
[
  ['patch_86',['patch',['../structclfftSetupData__.html#a817564e25ed276c000278a3c5f4bcd91',1,'clfftSetupData_']]],
  ['postcallback_87',['POSTCALLBACK',['../clFFT_8h.html#a5054fb252880d1e32b9d758e3c6b45e3a8b6cc34b822e92a0a2e8db260b42fdc8',1,'clFFT.h']]],
  ['precallback_88',['PRECALLBACK',['../clFFT_8h.html#a5054fb252880d1e32b9d758e3c6b45e3ac07041dc0f34755070319d1afc32ab6e',1,'clFFT.h']]]
];

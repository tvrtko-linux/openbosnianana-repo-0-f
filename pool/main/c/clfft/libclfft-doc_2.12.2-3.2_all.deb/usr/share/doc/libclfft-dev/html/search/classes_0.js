var searchData=
[
  ['clfftsetupdata_5f_89',['clfftSetupData_',['../structclfftSetupData__.html',1,'']]]
];

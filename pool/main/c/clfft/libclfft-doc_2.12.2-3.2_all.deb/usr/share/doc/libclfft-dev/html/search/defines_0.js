var searchData=
[
  ['clfft_5fdump_5fprograms_175',['CLFFT_DUMP_PROGRAMS',['../clFFT_8h.html#a15228e780233c33e1bd9b1e101fb5bb6',1,'clFFT.h']]],
  ['clfftapi_176',['CLFFTAPI',['../clFFT_8h.html#ab54789236f35ab11911c3232856e67d8',1,'clFFT.h']]]
];

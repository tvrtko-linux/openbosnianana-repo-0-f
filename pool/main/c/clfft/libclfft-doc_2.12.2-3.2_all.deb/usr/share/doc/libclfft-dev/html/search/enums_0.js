var searchData=
[
  ['clfftcallbacktype_130',['clfftCallbackType',['../clFFT_8h.html#a5054fb252880d1e32b9d758e3c6b45e3',1,'clFFT.h']]],
  ['clfftdim_131',['clfftDim',['../clFFT_8h.html#aa9d4934cdb8612616b6991b72e7f97b6',1,'clFFT.h']]],
  ['clfftdirection_132',['clfftDirection',['../clFFT_8h.html#a0a586ab5b1540f18a8596df47f5881bf',1,'clFFT.h']]],
  ['clfftlayout_133',['clfftLayout',['../clFFT_8h.html#a7a152426dc2895653d969b3354016f86',1,'clFFT.h']]],
  ['clfftprecision_134',['clfftPrecision',['../clFFT_8h.html#a0ed2c949c80e301ed7a2bffb9a7b8fb1',1,'clFFT.h']]],
  ['clfftresultlocation_135',['clfftResultLocation',['../clFFT_8h.html#ad4f03bc9528e7d8d0dc96650127896c7',1,'clFFT.h']]],
  ['clfftresulttransposed_136',['clfftResultTransposed',['../clFFT_8h.html#a9525ab6dda9e78f4fa545f8c3af0725c',1,'clFFT.h']]],
  ['clfftstatus_5f_137',['clfftStatus_',['../clFFT_8h.html#a74e303bed132064cfa22c1cce96d2bce',1,'clFFT.h']]]
];

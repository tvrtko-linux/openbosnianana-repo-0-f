var searchData=
[
  ['postcallback_173',['POSTCALLBACK',['../clFFT_8h.html#a5054fb252880d1e32b9d758e3c6b45e3a8b6cc34b822e92a0a2e8db260b42fdc8',1,'clFFT.h']]],
  ['precallback_174',['PRECALLBACK',['../clFFT_8h.html#a5054fb252880d1e32b9d758e3c6b45e3ac07041dc0f34755070319d1afc32ab6e',1,'clFFT.h']]]
];

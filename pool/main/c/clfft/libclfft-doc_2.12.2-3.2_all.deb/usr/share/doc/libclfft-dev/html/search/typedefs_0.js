var searchData=
[
  ['clfftplanhandle_129',['clfftPlanHandle',['../clFFT_8h.html#af8210cf8cf7d7a6183c0602506ef8425',1,'clFFT.h']]]
];

var searchData=
[
  ['patch_128',['patch',['../structclfftSetupData__.html#a817564e25ed276c000278a3c5f4bcd91',1,'clfftSetupData_']]]
];

var structclfftSetupData__ =
[
    [ "debugFlags", "structclfftSetupData__.html#aa69766b2183dafd7b57f4997ce2303a2", null ],
    [ "major", "structclfftSetupData__.html#a04260899b0439f27de6f9ff79b91dfcb", null ],
    [ "minor", "structclfftSetupData__.html#ab561c9a70d46d4129853dcf9631c883d", null ],
    [ "patch", "structclfftSetupData__.html#a817564e25ed276c000278a3c5f4bcd91", null ]
];
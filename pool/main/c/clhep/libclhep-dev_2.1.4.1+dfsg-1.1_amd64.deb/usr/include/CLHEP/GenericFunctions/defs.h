/* GenericFunctions/defs.h.  Generated from defs.h.in by configure.  */
/* GenericFunctions/defs.h.in.  Generated from configure.ac by autoheader.  */

#ifndef GENERICFUNCTIONS_DEFS_H
#define GENERICFUNCTIONS_DEFS_H

/* Name of package */
#ifndef PACKAGE
#define PACKAGE "GenericFunctions"
#endif

/* Define to the address where bug reports for this package should be sent. */
#ifndef PACKAGE_BUGREPORT
#define PACKAGE_BUGREPORT "http://savannah.cern.ch/projects/clhep/"
#endif

/* Define to the full name of this package. */
#ifndef PACKAGE_NAME
#define PACKAGE_NAME "CLHEP GenericFunctions"
#endif

/* Define to the full name and version of this package. */
#ifndef PACKAGE_STRING
#define PACKAGE_STRING "CLHEP GenericFunctions 2.1.4.1"
#endif

/* Define to the one symbol short name of this package. */
#ifndef PACKAGE_TARNAME
#define PACKAGE_TARNAME "GenericFunctions"
#endif

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#ifndef PACKAGE_VERSION
#define PACKAGE_VERSION "2.1.4.1"
#endif

/* Version number of package */
#ifndef VERSION
#define VERSION "2.1.4.1"
#endif

#endif  // GENERICFUNCTIONS_DEFS_H

var searchData=
[
  ['default_144',['DEFAULT',['../classCLI_1_1AsNumberWithUnit.html#a4f1b96d1a43a6acb3f85b68dd6f5a321a870d760dcdc3ddfe3dea704c3985eb89',1,'CLI::AsNumberWithUnit']]],
  ['default_5fflag_5fvalues_5f_145',['default_flag_values_',['../classCLI_1_1Option.html#ad2c7c8c939c6eacfb25ae7a83c0640af',1,'CLI::Option']]],
  ['default_5ffunction_146',['default_function',['../classCLI_1_1Option.html#a3693531e3da3574fc03185f759f13a83',1,'CLI::Option']]],
  ['default_5ffunction_5f_147',['default_function_',['../classCLI_1_1Option.html#acc7769c9cd48d7c7302dd51aa8fd3bd2',1,'CLI::Option']]],
  ['default_5fstartup_148',['default_startup',['../classCLI_1_1App.html#ae55bdb283aa20595c30a0cbb83d833d3',1,'CLI::App']]],
  ['default_5fstr_149',['default_str',['../classCLI_1_1Option.html#a446f47a5d6ddf6831defd707394d7c07',1,'CLI::Option']]],
  ['default_5fstr_5f_150',['default_str_',['../classCLI_1_1Option.html#a169893983f2dd0dc840ebca98bb76698',1,'CLI::Option']]],
  ['default_5fval_151',['default_val',['../classCLI_1_1Option.html#a4685cebdb75c6bf8ce0095fd08d8b892',1,'CLI::Option']]],
  ['delimiter_152',['delimiter',['../classCLI_1_1OptionBase.html#ad99f5bd0df1e736cd6c3478a77507289',1,'CLI::OptionBase::delimiter()'],['../classCLI_1_1OptionDefaults.html#a45dbccb3672d4d397e6d3b18897e1c0d',1,'CLI::OptionDefaults::delimiter()']]],
  ['delimiter_5f_153',['delimiter_',['../classCLI_1_1OptionBase.html#ac4164d93e2b8e59b2de24dad04a9f34b',1,'CLI::OptionBase']]],
  ['deprecate_5foption_154',['deprecate_option',['../namespaceCLI.html#a5e83d92a6ec271c2439141feaede1136',1,'CLI::deprecate_option(App &amp;app, const std::string &amp;option_name, const std::string &amp;replacement=&quot;&quot;)'],['../namespaceCLI.html#ad6d89b5d1aba2ebdca5f94534d658cab',1,'CLI::deprecate_option(App *app, const std::string &amp;option_name, const std::string &amp;replacement=&quot;&quot;)'],['../namespaceCLI.html#a6cb6f8bfff8c49385fb24f6f23a23c21',1,'CLI::deprecate_option(Option *opt, const std::string &amp;replacement=&quot;&quot;)']]],
  ['desc_5ffunction_5f_155',['desc_function_',['../classCLI_1_1Validator.html#a9f00a86d01b79facfc300be76b7463d7',1,'CLI::Validator']]],
  ['description_156',['description',['../classCLI_1_1Validator.html#acb7942915861f00426ba4106c3fa1445',1,'CLI::Validator::description(std::string validator_desc) const'],['../classCLI_1_1Validator.html#a1d62f88b256ae1587a5c9841f5a42c68',1,'CLI::Validator::description(std::string validator_desc)'],['../classCLI_1_1Option.html#abe8a53dc9fdeab4d74057891520ac3a7',1,'CLI::Option::description()'],['../classCLI_1_1App.html#a5c26c64a49536e623739685f42475fc2',1,'CLI::App::description(std::string app_description)']]],
  ['description_5f_157',['description_',['../classCLI_1_1App.html#aa6a2e79e0a5990b44bc5d76504437fcd',1,'CLI::App::description_()'],['../classCLI_1_1Option.html#aa6427b2f3303cc4469cacdc098b9d4bf',1,'CLI::Option::description_()']]],
  ['directory_158',['directory',['../namespaceCLI_1_1detail.html#a20a9a67e5f06ba0dc3f2ded2fed16f55a5f8f22b8cdbaeee8cf857673a9b6ba20',1,'CLI::detail']]],
  ['disable_5fflag_5foverride_159',['disable_flag_override',['../classCLI_1_1OptionDefaults.html#a8fc246a54dd092621bfb7216807e1490',1,'CLI::OptionDefaults::disable_flag_override()'],['../classCLI_1_1Option.html#abffc5b37b17b35b72b0489fc022e6e78',1,'CLI::Option::disable_flag_override()']]],
  ['disable_5fflag_5foverride_5f_160',['disable_flag_override_',['../classCLI_1_1OptionBase.html#ab62f608c0957e32ccf56f2834aa574c1',1,'CLI::OptionBase']]],
  ['disabled_161',['disabled',['../classCLI_1_1App.html#abafac323b1dac58044509a62938daa9a',1,'CLI::App::disabled(bool disable=true)'],['../classCLI_1_1App.html#a44223dc510ba0f7b680990476828e2e8a075ae3d2fc31640504f814f60e5ef713',1,'CLI::App::disabled()']]],
  ['disabled_5f_162',['disabled_',['../classCLI_1_1App.html#a405d0642ba4245a6ea61b230c4854667',1,'CLI::App']]],
  ['disabled_5fby_5fdefault_163',['disabled_by_default',['../classCLI_1_1App.html#a8aa17ef86c76df64bb67dc87b7e0f4bf',1,'CLI::App']]],
  ['dummy_164',['dummy',['../namespaceCLI_1_1detail.html#a01c35a876e2917ffdc1ee618e0c06619',1,'CLI::detail']]]
];

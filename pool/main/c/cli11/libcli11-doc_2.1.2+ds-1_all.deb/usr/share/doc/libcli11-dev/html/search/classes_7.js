var searchData=
[
  ['make_5fvoid_703',['make_void',['../structCLI_1_1make__void.html',1,'CLI']]]
];

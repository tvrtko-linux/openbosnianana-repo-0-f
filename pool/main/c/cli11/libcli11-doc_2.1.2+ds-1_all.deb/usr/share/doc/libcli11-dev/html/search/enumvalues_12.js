var searchData=
[
  ['windows_5fstyle_1319',['WINDOWS_STYLE',['../namespaceCLI_1_1detail.html#aba10771e3ff645fe1305be4cae517573a0693f2b4d4f0740bc76a2d65566b4fda',1,'CLI::detail']]]
];

var searchData=
[
  ['long_1294',['LONG',['../namespaceCLI_1_1detail.html#aba10771e3ff645fe1305be4cae517573ac1fabfea54ec6011e694f211f3ffebf3',1,'CLI::detail']]]
];

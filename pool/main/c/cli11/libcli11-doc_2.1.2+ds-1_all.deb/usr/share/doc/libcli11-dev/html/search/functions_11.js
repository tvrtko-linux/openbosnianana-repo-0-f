var searchData=
[
  ['range_1046',['Range',['../classCLI_1_1Range.html#a9206b918e2e8f1bac5bd461cfae58dbe',1,'CLI::Range::Range(T max_val, const std::string &amp;validator_name=std::string{})'],['../classCLI_1_1Range.html#a4b4696ecf99d2d6d237fbfd3e2421245',1,'CLI::Range::Range(T min_val, T max_val, const std::string &amp;validator_name=std::string{})']]],
  ['reduced_5fresults_1047',['reduced_results',['../classCLI_1_1Option.html#a35ae96199e3704c2b4be44bae9be28fa',1,'CLI::Option']]],
  ['remaining_1048',['remaining',['../classCLI_1_1App.html#a0474d71afa5672f645d2b645723c9818',1,'CLI::App']]],
  ['remaining_5ffor_5fpassthrough_1049',['remaining_for_passthrough',['../classCLI_1_1App.html#ab3b93e0ab2e848b5160e932bd62de8eb',1,'CLI::App']]],
  ['remaining_5fsize_1050',['remaining_size',['../classCLI_1_1App.html#a7a94b729128d22a6cc3e4998149d7101',1,'CLI::App']]],
  ['remove_5fdefault_5fflag_5fvalues_1051',['remove_default_flag_values',['../namespaceCLI_1_1detail.html#a73b9afbe8a438ab30291d35f1f24c87c',1,'CLI::detail']]],
  ['remove_5fexcludes_1052',['remove_excludes',['../classCLI_1_1App.html#a1c0670f27afe97a4e7ba12fcfb65a81c',1,'CLI::App::remove_excludes()'],['../classCLI_1_1Option.html#a414e6a8f76443036a9fb096f49165660',1,'CLI::Option::remove_excludes()'],['../classCLI_1_1App.html#a9ea4153f3081d8424e772254135237fd',1,'CLI::App::remove_excludes(Option *opt)']]],
  ['remove_5fneeds_1053',['remove_needs',['../classCLI_1_1App.html#aaa7bc9f48fc24b24742fd2fbe01c13f6',1,'CLI::App::remove_needs(Option *opt)'],['../classCLI_1_1App.html#a73a87ddd7511abb67e5f293817e5df73',1,'CLI::App::remove_needs(App *app)'],['../classCLI_1_1Option.html#aab72f7fef9aca5eefb25b09c1abffb3c',1,'CLI::Option::remove_needs()']]],
  ['remove_5foption_1054',['remove_option',['../classCLI_1_1App.html#a3058b128735eec0813589b56c5453115',1,'CLI::App']]],
  ['remove_5fquotes_1055',['remove_quotes',['../namespaceCLI_1_1detail.html#a242fa1bec3353c591a730efc6307f3ea',1,'CLI::detail']]],
  ['remove_5fsubcommand_1056',['remove_subcommand',['../classCLI_1_1App.html#acfd0b05943b8acba2a38c58f47140534',1,'CLI::App']]],
  ['remove_5funderscore_1057',['remove_underscore',['../namespaceCLI_1_1detail.html#a5359a7a0e33366a12e15523b100f591a',1,'CLI::detail']]],
  ['require_5foption_1058',['require_option',['../classCLI_1_1App.html#ad77cd2ce39f74e6bd871d05f377d8cc8',1,'CLI::App::require_option()'],['../classCLI_1_1App.html#a6003073a5ae4904cb27a978282363e99',1,'CLI::App::require_option(int value)'],['../classCLI_1_1App.html#a0e50594ad2ebfe6ce58e1d17398aeaac',1,'CLI::App::require_option(std::size_t min, std::size_t max)']]],
  ['require_5fsubcommand_1059',['require_subcommand',['../classCLI_1_1App.html#ae1bb42a7f768d636671552cb345f2d6c',1,'CLI::App::require_subcommand(int value)'],['../classCLI_1_1App.html#a41628b1a9cd4437bb81851fcfe9cdeef',1,'CLI::App::require_subcommand(std::size_t min, std::size_t max)'],['../classCLI_1_1App.html#a9cb090791a2594ffca877fd6afbf858a',1,'CLI::App::require_subcommand()']]],
  ['required_1060',['required',['../classCLI_1_1OptionBase.html#a38c0ea47532de712dd8d9803633383b2',1,'CLI::OptionBase::required()'],['../classCLI_1_1App.html#a33c3eb125a4e70d387dd9fc49c25432b',1,'CLI::App::required()']]],
  ['results_1061',['results',['../classCLI_1_1Option.html#a5d906c9a9cba1e759367e4e9a63a7703',1,'CLI::Option::results() const'],['../classCLI_1_1Option.html#ac445a3a3ac14d7ec0f229887028bbbf7',1,'CLI::Option::results(T &amp;output) const']]],
  ['retire_5foption_1062',['retire_option',['../namespaceCLI.html#a36cfe4a6a80bf143735c0b80960bc252',1,'CLI::retire_option(App *app, Option *opt)'],['../namespaceCLI.html#a52390f850f663cf38a27e134c1a39b61',1,'CLI::retire_option(App &amp;app, Option *opt)'],['../namespaceCLI.html#ad9ac23b01e2ef840ec123f5a115302ab',1,'CLI::retire_option(App *app, const std::string &amp;option_name)'],['../namespaceCLI.html#a77cd1a3639a91dea33a7d144ea476df6',1,'CLI::retire_option(App &amp;app, const std::string &amp;option_name)']]],
  ['rjoin_1063',['rjoin',['../namespaceCLI_1_1detail.html#af74b520ee1011d38fde77f907ddfea40',1,'CLI::detail']]],
  ['rtrim_1064',['rtrim',['../namespaceCLI_1_1detail.html#aed9338ae7c45f34f8240a31325d8d71c',1,'CLI::detail::rtrim(std::string &amp;str)'],['../namespaceCLI_1_1detail.html#a27306fb661edc7a7017a09a0e9ee7b18',1,'CLI::detail::rtrim(std::string &amp;str, const std::string &amp;filter)']]],
  ['run_5fcallback_1065',['run_callback',['../classCLI_1_1App.html#a5834471108897c92ba7fa2e3e01f7c2d',1,'CLI::App::run_callback()'],['../classCLI_1_1Option.html#ab06eb6c31666a4a003aeb2cf3e5cdcd9',1,'CLI::Option::run_callback()']]],
  ['run_5fcallback_5ffor_5fdefault_1066',['run_callback_for_default',['../classCLI_1_1Option.html#a3f3097fd90b0cf348f95204fd67bc72e',1,'CLI::Option']]]
];

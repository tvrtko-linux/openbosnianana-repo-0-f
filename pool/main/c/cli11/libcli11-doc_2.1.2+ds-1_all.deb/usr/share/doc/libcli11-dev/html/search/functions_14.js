var searchData=
[
  ['valid_5falias_5fname_5fstring_1109',['valid_alias_name_string',['../namespaceCLI_1_1detail.html#ac75f9ea4aa9649b9b3890bdcbc64b75a',1,'CLI::detail']]],
  ['valid_5ffirst_5fchar_1110',['valid_first_char',['../namespaceCLI_1_1detail.html#a3a05d1129df69e88135e178137b1fd89',1,'CLI::detail']]],
  ['valid_5flater_5fchar_1111',['valid_later_char',['../namespaceCLI_1_1detail.html#a841371d5dbb0a52f453de4cc1d00cc51',1,'CLI::detail']]],
  ['valid_5fname_5fstring_1112',['valid_name_string',['../namespaceCLI_1_1detail.html#a4274628d24f9e3fbc719284f1db263b8',1,'CLI::detail']]],
  ['validate_5fpositionals_1113',['validate_positionals',['../classCLI_1_1App.html#ad107f40cfb9d4301a47713465e6c66e7',1,'CLI::App']]],
  ['validator_1114',['Validator',['../classCLI_1_1Validator.html#a918d82662319f6dc9dad53d580741569',1,'CLI::Validator::Validator()=default'],['../classCLI_1_1Validator.html#a71df7c1c94c4abceee930eef957f5b76',1,'CLI::Validator::Validator(std::string validator_desc)'],['../classCLI_1_1Validator.html#aede1b1a51a7f924342a92cbbd3ee41be',1,'CLI::Validator::Validator(std::function&lt; std::string(std::string &amp;)&gt; op, std::string validator_desc, std::string validator_name=&quot;&quot;)']]],
  ['value_5fstring_1115',['value_string',['../namespaceCLI_1_1detail.html#a9a74f119a795b25c40db74ffa21d3c2d',1,'CLI::detail::value_string(const T &amp;value)'],['../namespaceCLI_1_1detail.html#a130e048f492ea4619246e2f4cabaf4ac',1,'CLI::detail::value_string(const T &amp;value) -&gt; decltype(to_string(value))']]],
  ['valueseparator_1116',['valueSeparator',['../classCLI_1_1ConfigBase.html#a7245cefabbffb0bce2f2b48d35e24039',1,'CLI::ConfigBase']]],
  ['version_1117',['version',['../classCLI_1_1App.html#acada3cd8a963944cfce74d1d90946433',1,'CLI::App']]]
];

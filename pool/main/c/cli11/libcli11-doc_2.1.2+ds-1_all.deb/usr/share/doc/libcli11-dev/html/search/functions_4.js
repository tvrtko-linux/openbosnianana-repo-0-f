var searchData=
[
  ['default_5ffunction_838',['default_function',['../classCLI_1_1Option.html#a3693531e3da3574fc03185f759f13a83',1,'CLI::Option']]],
  ['default_5fstr_839',['default_str',['../classCLI_1_1Option.html#a446f47a5d6ddf6831defd707394d7c07',1,'CLI::Option']]],
  ['default_5fval_840',['default_val',['../classCLI_1_1Option.html#a4685cebdb75c6bf8ce0095fd08d8b892',1,'CLI::Option']]],
  ['delimiter_841',['delimiter',['../classCLI_1_1OptionBase.html#ad99f5bd0df1e736cd6c3478a77507289',1,'CLI::OptionBase::delimiter()'],['../classCLI_1_1OptionDefaults.html#a45dbccb3672d4d397e6d3b18897e1c0d',1,'CLI::OptionDefaults::delimiter()']]],
  ['deprecate_5foption_842',['deprecate_option',['../namespaceCLI.html#a6cb6f8bfff8c49385fb24f6f23a23c21',1,'CLI::deprecate_option(Option *opt, const std::string &amp;replacement=&quot;&quot;)'],['../namespaceCLI.html#ad6d89b5d1aba2ebdca5f94534d658cab',1,'CLI::deprecate_option(App *app, const std::string &amp;option_name, const std::string &amp;replacement=&quot;&quot;)'],['../namespaceCLI.html#a5e83d92a6ec271c2439141feaede1136',1,'CLI::deprecate_option(App &amp;app, const std::string &amp;option_name, const std::string &amp;replacement=&quot;&quot;)']]],
  ['description_843',['description',['../classCLI_1_1App.html#a5c26c64a49536e623739685f42475fc2',1,'CLI::App::description()'],['../classCLI_1_1Option.html#abe8a53dc9fdeab4d74057891520ac3a7',1,'CLI::Option::description()'],['../classCLI_1_1Validator.html#a1d62f88b256ae1587a5c9841f5a42c68',1,'CLI::Validator::description(std::string validator_desc)'],['../classCLI_1_1Validator.html#acb7942915861f00426ba4106c3fa1445',1,'CLI::Validator::description(std::string validator_desc) const']]],
  ['disable_5fflag_5foverride_844',['disable_flag_override',['../classCLI_1_1OptionDefaults.html#a8fc246a54dd092621bfb7216807e1490',1,'CLI::OptionDefaults::disable_flag_override()'],['../classCLI_1_1Option.html#abffc5b37b17b35b72b0489fc022e6e78',1,'CLI::Option::disable_flag_override()']]],
  ['disabled_845',['disabled',['../classCLI_1_1App.html#abafac323b1dac58044509a62938daa9a',1,'CLI::App']]],
  ['disabled_5fby_5fdefault_846',['disabled_by_default',['../classCLI_1_1App.html#a8aa17ef86c76df64bb67dc87b7e0f4bf',1,'CLI::App']]]
];

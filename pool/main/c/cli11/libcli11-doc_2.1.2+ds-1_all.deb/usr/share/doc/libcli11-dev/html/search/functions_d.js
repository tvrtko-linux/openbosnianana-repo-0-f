var searchData=
[
  ['name_1011',['name',['../classCLI_1_1App.html#aff6ec09062edd6024c3f29a7792da554',1,'CLI::App::name()'],['../classCLI_1_1Validator.html#a6e4116061cd19611de38043a08086852',1,'CLI::Validator::name(std::string validator_name)'],['../classCLI_1_1Validator.html#a56272c0571e4b28e5f1387787bee671c',1,'CLI::Validator::name(std::string validator_name) const']]],
  ['needs_1012',['needs',['../classCLI_1_1App.html#a7c43c76fb672075be04a24ecbb6c5d7c',1,'CLI::App::needs(Option *opt)'],['../classCLI_1_1App.html#ac05c29fe17d83419f415ddef5057e9ea',1,'CLI::App::needs(App *app)'],['../classCLI_1_1Option.html#a30287b2ec43f5caa03c3c41216f40c6e',1,'CLI::Option::needs(Option *opt)'],['../classCLI_1_1Option.html#ab83ac1e75429676631aa8a9223682068',1,'CLI::Option::needs(std::string opt_name)'],['../classCLI_1_1Option.html#ac2e1015a0d5d0b9719c164fdd9ef3664',1,'CLI::Option::needs(A opt, B opt1, ARG... args)']]],
  ['non_5fmodifying_1013',['non_modifying',['../classCLI_1_1Validator.html#af3cde5a9bffc4943d4388480d439c1d5',1,'CLI::Validator']]],
  ['nonexistentpathvalidator_1014',['NonexistentPathValidator',['../classCLI_1_1detail_1_1NonexistentPathValidator.html#a1708ec7b5892f369b64be668870df677',1,'CLI::detail::NonexistentPathValidator']]],
  ['nonpositional_1015',['nonpositional',['../classCLI_1_1Option.html#a94cc5149d388be946c449e8ee61cd034',1,'CLI::Option']]]
];

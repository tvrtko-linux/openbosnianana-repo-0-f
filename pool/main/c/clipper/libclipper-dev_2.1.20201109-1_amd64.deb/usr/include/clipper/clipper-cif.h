/* Clipper header file */
/* (C) 2000-2002 Kevin Cowtan */

#ifndef CLIPPER_CIF_H
#define CLIPPER_CIF_H

#include "clipper/cif/cif_data_io.h"

#endif

/* Clipper header file */
/* (C) 2000-2002 Kevin Cowtan */

#ifndef CLIPPER_CNS_H
#define CLIPPER_CNS_H

#include "clipper/cns/cns_hkl_io.h"
#include "clipper/cns/cns_map_io.h"

#endif

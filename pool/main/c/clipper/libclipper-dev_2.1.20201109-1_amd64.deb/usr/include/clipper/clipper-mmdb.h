/* Clipper header file */
/* (C) 2000-2003 Kevin Cowtan */

#ifndef CLIPPER_MMDB_H
#define CLIPPER_MMDB_H

#include "clipper/mmdb/clipper_mmdb.h"

#endif

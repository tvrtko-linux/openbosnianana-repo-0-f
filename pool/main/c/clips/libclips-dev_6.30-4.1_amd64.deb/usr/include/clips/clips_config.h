/* clips_config.h.  Generated from clips_config.h.in by configure.  */
/* clips_config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* Define if you have the ANSI C header files.  */
/* #undef STDC_HEADERS */

/* Define if your <sys/time.h> declares struct tm.  */
#define TM_IN_SYS_TIME 1

/* Define if the X Window System is missing or not being used.  */
/* #undef X_DISPLAY_MISSING */
   
/* Define if you want for aditional degugging info */
/* #undef DEBUG */

/* Define if you have the <X11/Xaw3d/%.h> header files.  */
/* #undef HAVE_LIBXAW3D_H */

/* SOLARIS flag added at NRC 96.2.9 to allow customization for Solaris systems
/* #undef SOLARIS */

/* Define if you have the ftime function.  */
#define HAVE_FTIME 1

/* Define if you have the getwd function.  */
#define HAVE_GETWD 1

/* Define if you have the <dirent.h> header file.  */
/* #undef HAVE_DIRENT_H */

/* Define if you have the <fcntl.h> header file.  */
/* #undef HAVE_FCNTL_H */

/* Define if you have the <limits.h> header file.  */
/* #undef HAVE_LIMITS_H */

/* Define if you have the <malloc.h> header file.  */
/* #undef HAVE_MALLOC_H */

/* Define if you have the <ndir.h> header file.  */
/* #undef HAVE_NDIR_H */

/* Define if you have the <sgtty.h> header file.  */
/* #undef HAVE_SGTTY_H */

/* Define if you have the <stdio.h> header file.  */
/* #undef HAVE_STDIO_H */

/* Define if you have the <strings.h> header file.  */
/* #undef HAVE_STRINGS_H */

/* Define if you have the <sys/dir.h> header file.  */
/* #undef HAVE_SYS_DIR_H */

/* Define if you have the <sys/ndir.h> header file.  */
/* #undef HAVE_SYS_NDIR_H */

/* Define if you have the ICE library (-lICE).  */
/* #undef HAVE_LIBICE */

/* Define if you have the SM library (-lSM).  */
/* #undef HAVE_LIBSM */

/* Define if you have the X11 library (-lX11).  */
/* #undef HAVE_LIBX11 */

/* Define if you have the Xaw3d library (-lXaw3d).  */
/* #undef HAVE_LIBXAW3D */

/* Define if you have the Xext library (-lXext).  */
/* #undef HAVE_LIBXEXT */

/* Define if you have the Xmu library (-lXmu).  */
/* #undef HAVE_LIBXMU */

/* Define if you have the Xt library (-lXt).  */
/* #undef HAVE_LIBXT */

/* Define if you have the m library (-lm).  */
#define HAVE_LIBM 1

/* Define if you have the termcap library (-ltermcap).  */
/* #undef HAVE_LIBTERMCAP */

/* New in clips 6.2 still to be defined */
#define ENVIRONMENT_API_ONLY 0
#define ALLOW_ENVIRONMENT_GLOBALS 1


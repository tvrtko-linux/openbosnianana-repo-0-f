${MAKE-make} clisp-module \
  CC="${CC}" CPPFLAGS="${CPPFLAGS}" CFLAGS="${CFLAGS}" \
  CLISP_LINKKIT="$absolute_linkkitdir" CLISP="${CLISP}"
NEW_MODULES='bdb'
NEW_FILES="${NEW_MODULES}.o"
NEW_LIBS="${NEW_FILES} -ldb"
TO_LOAD='dbi'
TO_PRELOAD="preload.lisp"

${MAKE-make} clisp-module \
  CC="${CC}" CPPFLAGS="${CPPFLAGS}" CFLAGS="${CFLAGS}" \
  CLISP_LINKKIT="$absolute_linkkitdir" CLISP="${CLISP}"
NEW_FILES="clx.o"
NEW_LIBS="${NEW_FILES}  -lXpm -lXext -lXau  -lX11"
NEW_MODULES="clx"
TO_PRELOAD='clx-preload.lisp'
TO_LOAD='clx image resource'

${MAKE-make} clisp-module \
  CC="${CC}" CPPFLAGS="${CPPFLAGS}" CFLAGS="${CFLAGS}" \
  CLISP_LINKKIT="$absolute_linkkitdir" CLISP="${CLISP}"
NEW_FILES="dbus.o"
NEW_LIBS="${NEW_FILES} -ldbus-1"
NEW_MODULES="dbus"
TO_LOAD='dbus'

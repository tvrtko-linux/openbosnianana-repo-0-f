# link.sh for FastCGI library
${MAKE-make} clisp-module \
  CC="${CC}" CPPFLAGS="${CPPFLAGS}" CFLAGS="${CFLAGS}" \
  CLISP_LINKKIT="$absolute_linkkitdir" CLISP="${CLISP}"
NEW_FILES="fastcgi.o fastcgi_wrappers.o"
NEW_LIBS="${NEW_FILES} -lfcgi"
NEW_MODULES="fastcgi"
TO_LOAD="fastcgi"

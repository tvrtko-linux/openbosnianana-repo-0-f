${MAKE-make} clisp-module \
  CC="${CC}" CPPFLAGS="${CPPFLAGS}" CFLAGS="${CFLAGS}" \
  CLISP_LINKKIT="$absolute_linkkitdir" CLISP="${CLISP}"
NEW_FILES="gdbm.o"
NEW_LIBS="${NEW_FILES} -lgdbm"
NEW_MODULES='gdbm'
TO_LOAD='gdbm'
TO_PRELOAD="preload.lisp"

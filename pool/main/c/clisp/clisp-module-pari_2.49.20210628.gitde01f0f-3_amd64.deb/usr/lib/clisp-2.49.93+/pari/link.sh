${MAKE-make} clisp-module \
  CC="${CC}" CPPFLAGS="${CPPFLAGS}" CFLAGS="${CFLAGS}" \
  CLISP_LINKKIT="$absolute_linkkitdir" CLISP="${CLISP}"
NEW_FILES="cpari.o pari.o"
NEW_LIBS="${NEW_FILES} -lm -lpari"
NEW_MODULES="pari"
TO_LOAD='pari'
TO_PRELOAD='preload.lisp'

#!/bin/bash

LABEL="$1"

brotherssh rm -f /srv/lxc/"$LABEL"/clsync-backup.status




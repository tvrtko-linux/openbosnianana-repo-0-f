# Emacs 24 Theme - Clues

Clues was initially based on a Visual Studio theme called 'Blues 'n
Roots' however it's a long way from looking much like it, aside
from the occasional color accent, Blues (despite it's name) has a
more toasted caramel flavor. Clues on the other hand is made up of
cooling colors with a couple of flecks of light cream/brown/orange
to break up any monotony, with yellow/gold rainbow-delimiters.

Clues has become my working theme of choice since about 7/20, and
with xterm-frobs.el, looks really excellent in the terminal as well
as the GUI.

# Screenshot

![](https://raw.github.com/jasonm23/emacs-clues-theme/master/clues-theme.png)

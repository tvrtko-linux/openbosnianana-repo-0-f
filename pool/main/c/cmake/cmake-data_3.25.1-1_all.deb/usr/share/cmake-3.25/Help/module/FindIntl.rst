.. cmake-module:: ../../Modules/FindIntl.cmake

.. cmake-module:: ../../Modules/FindPatch.cmake

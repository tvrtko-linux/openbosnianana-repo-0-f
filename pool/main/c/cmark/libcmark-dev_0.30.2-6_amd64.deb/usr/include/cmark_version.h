#ifndef CMARK_VERSION_H
#define CMARK_VERSION_H

#define CMARK_VERSION ((0 << 16) | (30 << 8)  | 2)
#define CMARK_VERSION_STRING "0.30.2"

#endif

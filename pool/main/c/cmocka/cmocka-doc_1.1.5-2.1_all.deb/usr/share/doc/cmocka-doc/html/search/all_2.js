var searchData=
[
  ['deprecated_20list_0',['Deprecated List',['../deprecated.html',1,'']]],
  ['dynamic_20memory_20allocation_1',['Dynamic Memory Allocation',['../group__cmocka__alloc.html',1,'']]]
];

var searchData=
[
  ['ignore_5ffunction_5fcalls_0',['ignore_function_calls',['../group__cmocka__call__order.html#ga0b0c90d901ba153742fa6b04fec49902',1,'cmocka.h']]]
];

var searchData=
[
  ['mallocblockinfo_0',['MallocBlockInfo',['../unionMallocBlockInfo.html',1,'']]],
  ['mallocblockinfodata_1',['MallocBlockInfoData',['../structMallocBlockInfoData.html',1,'']]],
  ['mock_2',['mock',['../group__cmocka__mock.html#ga3cae77b8be3666adc80b294aeb21cc06',1,'cmocka.h']]],
  ['mock_20objects_3',['Mock Objects',['../group__cmocka__mock.html',1,'']]],
  ['mock_5fassert_4',['mock_assert',['../group__cmocka__mock__assert.html#ga7f1663184edbd6120732191c4bffada2',1,'mock_assert(const int result, const char *const expression, const char *const file, const int line):&#160;cmocka.c'],['../group__cmocka__mock__assert.html#ga7f1663184edbd6120732191c4bffada2',1,'mock_assert(const int result, const char *const expression, const char *const file, const int line):&#160;cmocka.c']]],
  ['mock_5fptr_5ftype_5',['mock_ptr_type',['../group__cmocka__mock.html#gac267dacf70a0f82aa1521b01a1c98238',1,'cmocka.h']]]
];

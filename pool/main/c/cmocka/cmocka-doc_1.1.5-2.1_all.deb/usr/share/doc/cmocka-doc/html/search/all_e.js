var searchData=
[
  ['will_5freturn_0',['will_return',['../group__cmocka__mock.html#ga64d184d2b658f0a29a9b937e8f1ffb90',1,'cmocka.h']]],
  ['will_5freturn_5falways_1',['will_return_always',['../group__cmocka__mock.html#ga5633b84abaa1dc899f4bf3faf8c6bd83',1,'cmocka.h']]],
  ['will_5freturn_5fcount_2',['will_return_count',['../group__cmocka__mock.html#gaac9a382a8509489d619538fe264e66a7',1,'cmocka.h']]],
  ['will_5freturn_5fmaybe_3',['will_return_maybe',['../group__cmocka__mock.html#ga73ef52ccf68061b759746f9a51d1e419',1,'cmocka.h']]]
];

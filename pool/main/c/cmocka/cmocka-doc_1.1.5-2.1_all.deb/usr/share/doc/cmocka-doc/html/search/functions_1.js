var searchData=
[
  ['check_5fexpected_0',['check_expected',['../group__cmocka__param.html#ga2788d04a9ae39c595d4c6189db7db1af',1,'cmocka.h']]],
  ['check_5fexpected_5fptr_1',['check_expected_ptr',['../group__cmocka__param.html#ga151f50163b3cbec97759ae9b199031a9',1,'cmocka.h']]],
  ['cmocka_5frun_5fgroup_5ftests_2',['cmocka_run_group_tests',['../group__cmocka__exec.html#ga7c62fd0acf2235ce98268c28ee262a57',1,'cmocka.h']]],
  ['cmocka_5frun_5fgroup_5ftests_5fname_3',['cmocka_run_group_tests_name',['../group__cmocka__exec.html#gae9d5f9af521ba6828081ea3014427569',1,'cmocka.h']]],
  ['cmocka_5fset_5fmessage_5foutput_4',['cmocka_set_message_output',['../group__cmocka.html#gae3764f4f38d067fe9c5faf034c07debd',1,'cmocka_set_message_output(enum cm_message_output output):&#160;cmocka.c'],['../group__cmocka.html#gae3764f4f38d067fe9c5faf034c07debd',1,'cmocka_set_message_output(enum cm_message_output output):&#160;cmocka.c']]],
  ['cmocka_5fset_5fskip_5ffilter_5',['cmocka_set_skip_filter',['../group__cmocka.html#gac3994cdf617401dee7b0923503621072',1,'cmocka_set_skip_filter(const char *pattern):&#160;cmocka.c'],['../group__cmocka.html#gac3994cdf617401dee7b0923503621072',1,'cmocka_set_skip_filter(const char *pattern):&#160;cmocka.c']]],
  ['cmocka_5fset_5ftest_5ffilter_6',['cmocka_set_test_filter',['../group__cmocka.html#gad5006b3adbbe8962a57579f1d182a3b8',1,'cmocka_set_test_filter(const char *pattern):&#160;cmocka.c'],['../group__cmocka.html#gad5006b3adbbe8962a57579f1d182a3b8',1,'cmocka_set_test_filter(const char *pattern):&#160;cmocka.c']]]
];

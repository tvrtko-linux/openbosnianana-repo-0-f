var searchData=
[
  ['mock_0',['mock',['../group__cmocka__mock.html#ga3cae77b8be3666adc80b294aeb21cc06',1,'cmocka.h']]],
  ['mock_5fassert_1',['mock_assert',['../group__cmocka__mock__assert.html#ga7f1663184edbd6120732191c4bffada2',1,'mock_assert(const int result, const char *const expression, const char *const file, const int line):&#160;cmocka.c'],['../group__cmocka__mock__assert.html#ga7f1663184edbd6120732191c4bffada2',1,'mock_assert(const int result, const char *const expression, const char *const file, const int line):&#160;cmocka.c']]],
  ['mock_5fptr_5ftype_2',['mock_ptr_type',['../group__cmocka__mock.html#gac267dacf70a0f82aa1521b01a1c98238',1,'cmocka.h']]]
];

var searchData=
[
  ['test_5fcalloc_0',['test_calloc',['../group__cmocka__alloc.html#gacd5909dd7c98761e03a41b40ef0b6691',1,'cmocka.h']]],
  ['test_5ffree_1',['test_free',['../group__cmocka__alloc.html#gaabb7aa4acb6dbea8bdfa9572cb96cb10',1,'cmocka.h']]],
  ['test_5fmalloc_2',['test_malloc',['../group__cmocka__alloc.html#gad0f990a8f11c97496d0cae820153ddd1',1,'cmocka.h']]],
  ['test_5frealloc_3',['test_realloc',['../group__cmocka__alloc.html#ga0478b063a0f346a43c1cc42c0a2f3d75',1,'cmocka.h']]]
];

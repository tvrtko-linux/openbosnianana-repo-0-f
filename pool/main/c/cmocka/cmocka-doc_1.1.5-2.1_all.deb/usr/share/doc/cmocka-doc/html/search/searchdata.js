var indexSectionsWithContent =
{
  0: "acdefgilmrstuvw",
  1: "cfglmstuv",
  2: "acefimrstw",
  3: "l",
  4: "acdmrst",
  5: "cd"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "typedefs",
  4: "groups",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions",
  3: "Typedefs",
  4: "Modules",
  5: "Pages"
};


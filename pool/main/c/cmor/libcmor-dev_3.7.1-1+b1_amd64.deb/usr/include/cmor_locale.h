#ifndef _CMOR_LOCALE
#define _CMOR_LOCALE
#define CMOR_PREFIX  "/usr"
#endif

# CMOR
Climate Model Output Rewriter

CMOR 3.7 documentation can be found here: http://cmor.llnl.gov



[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.7015697.svg)](https://doi.org/10.5281/zenodo.7015697)
[![stable version](https://img.shields.io/github/v/release/pcmdi/cmor.svg)](https://github.com/PCMDI/cmor/releases/latest)
![platforms](https://anaconda.org/pcmdi/cmor/badges/platforms.svg)
[![Anaconda-Server Badge](https://anaconda.org/pcmdi/cmor/badges/version.svg)](https://conda.anaconda.org/pcmdi)
[![Anaconda-Server Badge](https://anaconda.org/pcmdi/cmor/badges/downloads.svg)](https://anaconda.org/pcmdi)

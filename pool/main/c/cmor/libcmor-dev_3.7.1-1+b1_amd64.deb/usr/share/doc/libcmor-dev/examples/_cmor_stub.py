'''stub implementation of the C functions'''


def grid(*args):
    return args


def getCMOR_defaults_include(attr):
    return attr

#!/bin/sh
echo ':lisp:E::x86f::/usr/bin/lisp-start:'  > /proc/sys/fs/binfmt_misc/register
# this should only work for root under linux 2.1.XX or later
# now you can do "chmod a+x hello.x86f" and
# ./hello.x86f
# from your favorite shell.


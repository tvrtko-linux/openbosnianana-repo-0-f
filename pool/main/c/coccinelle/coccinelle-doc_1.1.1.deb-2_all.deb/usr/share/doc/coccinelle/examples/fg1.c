int main() {
  return 27;
}

int keep1() {
  return 27;
}

int keep2() {
  return 27;
}

// cf first slide of OLS

void main (int x) { 
  foo(1);
  h("toto");
  foo(2);
  foo(foo(2));

  if(foo(3)) { 
    int foo;
    do_something(foo);
  }
}

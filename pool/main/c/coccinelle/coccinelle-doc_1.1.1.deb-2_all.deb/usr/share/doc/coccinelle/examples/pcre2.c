
void foo() {

	bar(0);
	WINE_ERR(0);
	WINE_WARN(0);
}

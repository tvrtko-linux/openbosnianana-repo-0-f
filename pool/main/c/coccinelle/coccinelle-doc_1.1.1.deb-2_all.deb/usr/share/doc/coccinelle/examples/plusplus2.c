struct x {
	int z;
	int a;
	char b;
	int c;
	int *d;
};

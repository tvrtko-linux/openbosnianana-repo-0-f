void main(int i)
{

	
	foo(f(1),2);
	f(2);
	g(3);

}


void notmain(int i)
{

	f(3);
	f(4);

}

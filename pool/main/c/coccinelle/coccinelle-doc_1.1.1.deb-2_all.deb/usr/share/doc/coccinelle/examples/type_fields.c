void foo(int i) 
{
  struct file_operations myfops;
  foo(myfops.ioctl);

}




void foo(int i) 
{
  struct dir_operations myfops;
  foo(myfops.ioctl);

}


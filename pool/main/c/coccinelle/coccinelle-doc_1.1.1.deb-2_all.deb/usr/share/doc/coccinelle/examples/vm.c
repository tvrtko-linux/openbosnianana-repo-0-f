int main () {
  x = kmalloc();
  r = 15;
  kfree(x);
}

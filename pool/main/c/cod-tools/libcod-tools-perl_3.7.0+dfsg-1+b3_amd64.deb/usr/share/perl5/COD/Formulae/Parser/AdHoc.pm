####################################################################
#
#    This file was generated using Parse::Yapp version 1.21.
#
#        Don't edit this file, use source file instead.
#
#             ANY CHANGE MADE HERE WILL BE LOST !
#
####################################################################
package COD::Formulae::Parser::AdHoc;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );
use Parse::Yapp::Driver;

#line 10 "grammar.yp"

use warnings;
use COD::UserMessage qw( sprint_message );

$COD::Formulae::Parser::AdHoc::version = '1.0';

my $SVNID = '$Id: AdHoc.yp 9351 2022-07-31 01:53:56Z antanas $';

# 0 - no debug
# 1 - only YAPP output (type -> value)
# 2 - lex & yapp output
# 3 - generated array dump
$COD::Formulae::Parser::AdHoc::debug = 0;



sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '1.21',
                                  yystates =>
[
	{#State 0
		ACTIONS => {
			"(" => 1,
			"[" => 2,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		GOTOS => {
			'bracket_start' => 5,
			'formula' => 6,
			'formula_start' => 7,
			'item' => 8
		}
	},
	{#State 1
		DEFAULT => -19
	},
	{#State 2
		DEFAULT => -20
	},
	{#State 3
		ACTIONS => {
			'NUMBER' => 9
		},
		DEFAULT => -9
	},
	{#State 4
		ACTIONS => {
			"(" => 1,
			"[" => 2
		},
		GOTOS => {
			'bracket_start' => 10,
			'formula_start' => 11
		}
	},
	{#State 5
		ACTIONS => {
			'SPACE' => 12
		},
		DEFAULT => -22,
		GOTOS => {
			'opt_space' => 13
		}
	},
	{#State 6
		ACTIONS => {
			'' => 14,
			'SPACE' => 15
		},
		DEFAULT => -6,
		GOTOS => {
			'opt_spaces' => 16,
			'spaces' => 17
		}
	},
	{#State 7
		ACTIONS => {
			'SPACE' => 12
		},
		DEFAULT => -22,
		GOTOS => {
			'opt_space' => 18
		}
	},
	{#State 8
		ACTIONS => {
			'ELEMENT' => 19
		},
		DEFAULT => -1
	},
	{#State 9
		DEFAULT => -10
	},
	{#State 10
		ACTIONS => {
			'SPACE' => 12
		},
		DEFAULT => -22,
		GOTOS => {
			'opt_space' => 20
		}
	},
	{#State 11
		ACTIONS => {
			'SPACE' => 12
		},
		DEFAULT => -22,
		GOTOS => {
			'opt_space' => 21
		}
	},
	{#State 12
		DEFAULT => -21
	},
	{#State 13
		ACTIONS => {
			"(" => 1,
			"[" => 2,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		GOTOS => {
			'bracket_start' => 5,
			'formula' => 22,
			'formula_start' => 7,
			'item' => 8
		}
	},
	{#State 14
		DEFAULT => 0
	},
	{#State 15
		ACTIONS => {
			"(" => 1,
			"[" => 2,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		DEFAULT => -7,
		GOTOS => {
			'bracket_start' => 5,
			'formula_start' => 7,
			'item' => 23
		}
	},
	{#State 16
		ACTIONS => {
			"*" => 24,
			"," => 25
		}
	},
	{#State 17
		ACTIONS => {
			'SPACE' => 26
		},
		DEFAULT => -5
	},
	{#State 18
		ACTIONS => {
			"(" => 1,
			"[" => 2,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		GOTOS => {
			'bracket_start' => 5,
			'formula' => 27,
			'formula_start' => 7,
			'item' => 8
		}
	},
	{#State 19
		ACTIONS => {
			'NUMBER' => 28
		},
		DEFAULT => -11
	},
	{#State 20
		ACTIONS => {
			"(" => 1,
			"[" => 2,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		GOTOS => {
			'bracket_start' => 5,
			'formula' => 29,
			'formula_start' => 7,
			'item' => 8
		}
	},
	{#State 21
		ACTIONS => {
			"(" => 1,
			"[" => 2,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		GOTOS => {
			'bracket_start' => 5,
			'formula' => 30,
			'formula_start' => 7,
			'item' => 8
		}
	},
	{#State 22
		ACTIONS => {
			"]" => -22,
			'SPACE' => 31
		},
		DEFAULT => -6,
		GOTOS => {
			'opt_space' => 32,
			'opt_spaces' => 16,
			'spaces' => 17
		}
	},
	{#State 23
		ACTIONS => {
			'ELEMENT' => 19
		},
		DEFAULT => -2
	},
	{#State 24
		ACTIONS => {
			'SPACE' => 33
		},
		DEFAULT => -6,
		GOTOS => {
			'opt_spaces' => 34,
			'spaces' => 17
		}
	},
	{#State 25
		ACTIONS => {
			'SPACE' => 33
		},
		DEFAULT => -6,
		GOTOS => {
			'opt_spaces' => 35,
			'spaces' => 17
		}
	},
	{#State 26
		DEFAULT => -8
	},
	{#State 27
		ACTIONS => {
			")" => -22,
			'SPACE' => 31
		},
		DEFAULT => -6,
		GOTOS => {
			'opt_space' => 36,
			'opt_spaces' => 16,
			'spaces' => 17
		}
	},
	{#State 28
		DEFAULT => -12
	},
	{#State 29
		ACTIONS => {
			"]" => -22,
			'SPACE' => 31
		},
		DEFAULT => -6,
		GOTOS => {
			'opt_space' => 37,
			'opt_spaces' => 16,
			'spaces' => 17
		}
	},
	{#State 30
		ACTIONS => {
			")" => -22,
			'SPACE' => 31
		},
		DEFAULT => -6,
		GOTOS => {
			'opt_space' => 38,
			'opt_spaces' => 16,
			'spaces' => 17
		}
	},
	{#State 31
		ACTIONS => {
			"(" => 1,
			")" => -21,
			"[" => 2,
			"]" => -21,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		DEFAULT => -7,
		GOTOS => {
			'bracket_start' => 5,
			'formula_start' => 7,
			'item' => 23
		}
	},
	{#State 32
		ACTIONS => {
			"]" => 39
		}
	},
	{#State 33
		DEFAULT => -7
	},
	{#State 34
		ACTIONS => {
			"(" => 1,
			"[" => 2,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		GOTOS => {
			'bracket_start' => 5,
			'formula_start' => 7,
			'item' => 40
		}
	},
	{#State 35
		ACTIONS => {
			"(" => 1,
			"[" => 2,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		GOTOS => {
			'bracket_start' => 5,
			'formula_start' => 7,
			'item' => 41
		}
	},
	{#State 36
		ACTIONS => {
			")" => 42
		}
	},
	{#State 37
		ACTIONS => {
			"]" => 43
		}
	},
	{#State 38
		ACTIONS => {
			")" => 44
		}
	},
	{#State 39
		ACTIONS => {
			'NUMBER' => 45
		},
		DEFAULT => -16
	},
	{#State 40
		ACTIONS => {
			'ELEMENT' => 19
		},
		DEFAULT => -4
	},
	{#State 41
		ACTIONS => {
			'ELEMENT' => 19
		},
		DEFAULT => -3
	},
	{#State 42
		ACTIONS => {
			'NUMBER' => 46
		},
		DEFAULT => -13
	},
	{#State 43
		DEFAULT => -18
	},
	{#State 44
		DEFAULT => -15
	},
	{#State 45
		DEFAULT => -17
	},
	{#State 46
		DEFAULT => -14
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'formula', 1, undef
	],
	[#Rule 2
		 'formula', 3, undef
	],
	[#Rule 3
		 'formula', 5, undef
	],
	[#Rule 4
		 'formula', 5, undef
	],
	[#Rule 5
		 'opt_spaces', 1, undef
	],
	[#Rule 6
		 'opt_spaces', 0, undef
	],
	[#Rule 7
		 'spaces', 1, undef
	],
	[#Rule 8
		 'spaces', 2, undef
	],
	[#Rule 9
		 'item', 1,
sub
#line 56 "grammar.yp"
{
                    ## print ">>> ELEMENT: ",$_[1],"\n";
                    $_[0]->{USER}->{FormulaSum}{$_[1]} += 1;
                }
	],
	[#Rule 10
		 'item', 2,
sub
#line 61 "grammar.yp"
{
                    ## print ">>> ELEMENT: ",$_[1],"\n";
                    $_[0]->{USER}->{FormulaSum}{$_[1]} += $_[2];
                }
	],
	[#Rule 11
		 'item', 2,
sub
#line 67 "grammar.yp"
{
                    ## print ">>> ELEMENT: ",$_[1],"\n";
                    $_[0]->{USER}->{FormulaSum}{$_[2]} += 1;
                }
	],
	[#Rule 12
		 'item', 3,
sub
#line 73 "grammar.yp"
{
                    ## print ">>> ELEMENT: ",$_[2], " number: ", $_[3], "\n";
                    $_[0]->{USER}->{FormulaSum}{$_[2]} += $_[3];
                }
	],
	[#Rule 13
		 'item', 5,
sub
#line 79 "grammar.yp"
{
                    my $subformula = $_[0]->{USER}->{FormulaSum};
                    $_[0]->{USER}->{FormulaSum} =
                        pop @{$_[0]->{USER}->{FormulaStack}};

                    for my $key ( keys %{$subformula} ) {
                        $_[0]->{USER}->{FormulaSum}->{$key} +=
                            $subformula->{$key};
                    }
                }
	],
	[#Rule 14
		 'item', 6,
sub
#line 92 "grammar.yp"
{
                    my $subformula = $_[0]->{USER}->{FormulaSum};
                    $_[0]->{USER}->{FormulaSum} =
                        pop @{$_[0]->{USER}->{FormulaStack}};

                    for my $key ( keys %{$subformula} ) {
                        $_[0]->{USER}->{FormulaSum}->{$key} +=
                            $subformula->{$key} * $_[6];
                    }
                }
	],
	[#Rule 15
		 'item', 6,
sub
#line 105 "grammar.yp"
{
                    my $subformula = $_[0]->{USER}->{FormulaSum};
                    $_[0]->{USER}->{FormulaSum} =
                        pop @{$_[0]->{USER}->{FormulaStack}};

                    for my $key ( keys %{$subformula} ) {
                        $_[0]->{USER}->{FormulaSum}->{$key} +=
                            $subformula->{$key} * $_[1];
                    }
                }
	],
	[#Rule 16
		 'item', 5,
sub
#line 117 "grammar.yp"
{
                    my $subformula = $_[0]->{USER}->{FormulaSum};
                    $_[0]->{USER}->{FormulaSum} =
                        pop @{$_[0]->{USER}->{FormulaStack}};

                    for my $key ( keys %{$subformula} ) {
                        $_[0]->{USER}->{FormulaSum}->{$key} +=
                            $subformula->{$key};
                    }
                }
	],
	[#Rule 17
		 'item', 6,
sub
#line 130 "grammar.yp"
{
                    my $subformula = $_[0]->{USER}->{FormulaSum};
                    $_[0]->{USER}->{FormulaSum} =
                        pop @{$_[0]->{USER}->{FormulaStack}};

                    for my $key ( keys %{$subformula} ) {
                        $_[0]->{USER}->{FormulaSum}->{$key} +=
                            $subformula->{$key} * $_[6];
                    }
                }
	],
	[#Rule 18
		 'item', 6,
sub
#line 143 "grammar.yp"
{
                    my $subformula = $_[0]->{USER}->{FormulaSum};
                    $_[0]->{USER}->{FormulaSum} =
                        pop @{$_[0]->{USER}->{FormulaStack}};

                    for my $key ( keys %{$subformula} ) {
                        $_[0]->{USER}->{FormulaSum}->{$key} +=
                            $subformula->{$key} * $_[1];
                    }
                }
	],
	[#Rule 19
		 'formula_start', 1,
sub
#line 157 "grammar.yp"
{
            push @{$_[0]->{USER}->{FormulaStack}},
                  $_[0]->{USER}->{FormulaSum};
            $_[0]->{USER}->{FormulaSum} = {}
        }
	],
	[#Rule 20
		 'bracket_start', 1,
sub
#line 166 "grammar.yp"
{
            push @{$_[0]->{USER}->{FormulaStack}},
                  $_[0]->{USER}->{FormulaSum};
            $_[0]->{USER}->{FormulaSum} = {}
        }
	],
	[#Rule 21
		 'opt_space', 1, undef
	],
	[#Rule 22
		 'opt_space', 0, undef
	]
],
                                  @_);
    bless($self,$class);
}

#line 178 "grammar.yp"

# --------------------------------------------------------------
# begin of footer
# --------------------------------------------------------------

sub _Error
{
        $_[0]->YYData->{ERRCOUNT}++;
        exists $_[0]->YYData->{ERRMSG}
        and do {
                warn $_[0]->YYData->{ERRMSG};
                delete $_[0]->YYData->{ERRMSG};
                return;
        };
        warn sprint_message( {
            'program'      => $0,
            'err_level'    => 'ERROR',
            'message'      => 'incorrect formula syntax',
            'line_no'      => 0,
            'column_no'    => $_[0]->YYData->{VARS}{token_prev_pos}+1,
            'line_content' => $_[0]->YYData->{LINE}
        } );
}

sub PrintFormula
{
    my ( $self ) = @_;

    my $formula = $self->SprintFormula();

    print $formula, "\n" if defined $formula;
}

sub SprintFormula
{
    my ($parser) = @_;

    # Chemical formulas, according the IUCr recommendations, should
    # use the 'Hill' system used by Chemical Abstracts:
    #
    # the order of the elements within any group or moiety depends on
    # whether carbon is present or not. If carbon is present, the
    # order should be: C, then H, then the other elements in
    # alphabetical order of their symbol. If carbon is not present,
    # the elements are listed purely in alphabetical order of their
    # symbol.

    # References:
    # 1. http://www.iucr.org/__data/iucr/cifdic_html/1/cif_core.dic/Cchemical_formula.html
    # (2009-06-25)
    #
    # 2. Dictionary of organic compounds By J. I. G. (John Ivan
    # George) Cadogan, American Chemical Society. Chemical Abstracts
    # Service, P. H. Rhodes, Steven V Ley; page 106 (found by Google
    # book search on 2009-06-25)

    my $formula;

    if( $parser->YYNberr() == 0 ) {
        my %formula = %{$parser->{USER}->{FormulaSum}};
        $formula = '';
        my $separator = '';

        if( exists $formula{C} ) {
            if( $formula{C} == 1 ) {
                $formula .= 'C';
            } else {
                $formula .= 'C' . $formula{C};
            }
            delete $formula{C};
            $separator = ' ';
            if( exists $formula{H} ) {
                if( $formula{H} == 1 ) {
                    $formula .= $separator . 'H';
                } else {
                    $formula .= $separator . 'H' . $formula{H};
                }
                delete $formula{H};
            }
        }
        for my $key (sort {$a cmp $b} keys %formula) {
            $formula .= $separator . $key . ($formula{$key} != 1 ?
                $formula{$key} : '');
            $separator = ' ';
        }
    }
    return $formula;
}

my $INTEGER  = qr/[-+]?[0-9]+/s;
my $EXPONENT = qr/e[-+]?[0-9]+/is;
my $FLOAT11  = qr/(?: $INTEGER $EXPONENT)/ix;
my $FLOAT21  = qr/(?: [+-]? [0-9]* \. [0-9]+ $EXPONENT ?)/ix;
my $FLOAT31  = qr/(?: $INTEGER \. $EXPONENT ?)/ix;
my $FLOAT    = qr/(?: (?: $FLOAT11 | $FLOAT21 | $FLOAT31))/six;
my $NUMBER   = qr/(?: $FLOAT | $INTEGER  )/ix;

sub _Lexer
{
    my($parser) = shift;

    if( !defined $parser->YYData->{INPUT} ||
        $parser->YYData->{INPUT} =~ m/^\s*$/ ) {
        ## print ">>> lexing: empty line...\n";
        return('',undef);
    } else {
        ## $parser->YYData->{INPUT} =~ s/^\s*//;
        ## print ">>> lexing: ", $parser->YYData->{INPUT}, "\n";

        $parser->YYData->{VARS}{token_prev_pos} = $parser->YYData->{VARS}{token_pos};
        for($parser->YYData->{INPUT}) {
            if( s/^([A-Za-z][a-z]?)// ) {
                $parser->YYData->{VARS}{token_pos} += length($1);
                return( 'ELEMENT', $1 );
            }
            if( s/^($NUMBER)//x ) {
                $parser->YYData->{VARS}{token_pos} += length($1);
                return( 'NUMBER', $1 );
            }
            if( s/^(\()// ) {
                $parser->YYData->{VARS}{token_pos} += length($1);
                return ( '(', $1 );
            }
            if( s/^(\))// ) {
                $parser->YYData->{VARS}{token_pos} += length($1);
                return ( ')', $1 );
            }
            if( s/^(\[)// ) {
                $parser->YYData->{VARS}{token_pos} += length($1);
                return ( '[', $1 );
            }
            if( s/^(\])// ) {
                $parser->YYData->{VARS}{token_pos} += length($1);
                return ( ']', $1 );
            }
            if( s/^([\s.]+)// ) {
                $parser->YYData->{VARS}{token_pos} += length($1);
                return ( 'SPACE', $1 );
            }
            if( s/^(.)// ) {
                $parser->YYData->{VARS}{token_pos} += length($1);
                return ( $1, $1 );
            }
            else {
                return( '', undef );
            }
        }
    }
}

sub Run
{
    my ( $self, $filename ) = @_;

    $self->ParseFile( $filename );
}

sub ParseString
{
    my ($self, $text) = @_;

    $self->YYData->{INPUT} = $text;
    $self->YYData->{LINE} = $text;

    $self->YYData->{VARS}{token_prev_pos} = 0;
    $self->YYData->{VARS}{token_pos} = 0;

    $| = 1;

    if( $COD::Formulae::Parser::AdHoc::debug >= 2 &&
        $COD::Formulae::Parser::AdHoc::debug < 3) {
        $self->YYParse( yylex => \&_Lexer,
                        yyerror => \&_Error,
                        yydebug => 0x05 );
    } else {
        $self->YYParse( yylex => \&_Lexer, yyerror => \&_Error );
    }
    if( $self->YYNberr() == 0 ) {
        if( $COD::Formulae::Parser::AdHoc::debug >= 1 &&
            $COD::Formulae::Parser::AdHoc::debug < 3 ) {
            print "File syntax is CORRECT!\n";
        }
    } else {
        if( $COD::Formulae::Parser::AdHoc::debug >= 1 &&
            $COD::Formulae::Parser::AdHoc::debug < 3 ) {
            print "Syntax check failed.\n";
        }
    }
    return $self->{USER}->{FormulaSum};
}

sub ParseFile
{
    my($self) = shift;
    my($filename) = shift;

    $filename = '-' unless $filename;

    $self->{USER}{FILENAME} = $filename;

    open( my $formula_file, $filename ) or
        die( "could not open file '$filename' for input: $!" );

    my $formula_text = <$formula_file>;

    close $formula_file;

    return $self->ParseString( $formula_text );
}

return 1;

1;

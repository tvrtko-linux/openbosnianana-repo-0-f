####################################################################
#
#    This file was generated using Parse::Yapp version 1.21.
#
#        Don't edit this file, use source file instead.
#
#             ANY CHANGE MADE HERE WILL BE LOST !
#
####################################################################
package COD::Formulae::Parser::IUCr;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );
use Parse::Yapp::Driver;

#line 10 "grammar.yp"

use warnings;

$formula_sum::version = '1.0';

my $SVNID = '$Id: IUCr.yp 9351 2022-07-31 01:53:56Z antanas $';

# 0 - no debug
# 1 - only YAPP output (type -> value)
# 2 - lex & yapp output
# 3 - generated array dump
$formula_sum::debug = 0;



sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '1.21',
                                  yystates =>
[
	{#State 0
		ACTIONS => {
			"(" => 1,
			"[" => 2,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		GOTOS => {
			'bracket_start' => 5,
			'formula' => 6,
			'formula_start' => 7,
			'item' => 8
		}
	},
	{#State 1
		DEFAULT => -13
	},
	{#State 2
		DEFAULT => -14
	},
	{#State 3
		ACTIONS => {
			'NUMBER' => 9
		},
		DEFAULT => -3
	},
	{#State 4
		ACTIONS => {
			"(" => 1,
			"[" => 2
		},
		GOTOS => {
			'bracket_start' => 10,
			'formula_start' => 11
		}
	},
	{#State 5
		ACTIONS => {
			'SPACE' => 12
		},
		DEFAULT => -16,
		GOTOS => {
			'opt_space' => 13
		}
	},
	{#State 6
		ACTIONS => {
			'' => 14,
			'SPACE' => 15
		}
	},
	{#State 7
		ACTIONS => {
			'SPACE' => 12
		},
		DEFAULT => -16,
		GOTOS => {
			'opt_space' => 16
		}
	},
	{#State 8
		ACTIONS => {
			'ELEMENT' => 17
		},
		DEFAULT => -1
	},
	{#State 9
		DEFAULT => -4
	},
	{#State 10
		ACTIONS => {
			'SPACE' => 12
		},
		DEFAULT => -16,
		GOTOS => {
			'opt_space' => 18
		}
	},
	{#State 11
		ACTIONS => {
			'SPACE' => 12
		},
		DEFAULT => -16,
		GOTOS => {
			'opt_space' => 19
		}
	},
	{#State 12
		DEFAULT => -15
	},
	{#State 13
		ACTIONS => {
			"(" => 1,
			"[" => 2,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		GOTOS => {
			'bracket_start' => 5,
			'formula' => 20,
			'formula_start' => 7,
			'item' => 8
		}
	},
	{#State 14
		DEFAULT => 0
	},
	{#State 15
		ACTIONS => {
			"(" => 1,
			"[" => 2,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		GOTOS => {
			'bracket_start' => 5,
			'formula_start' => 7,
			'item' => 21
		}
	},
	{#State 16
		ACTIONS => {
			"(" => 1,
			"[" => 2,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		GOTOS => {
			'bracket_start' => 5,
			'formula' => 22,
			'formula_start' => 7,
			'item' => 8
		}
	},
	{#State 17
		ACTIONS => {
			'NUMBER' => 23
		},
		DEFAULT => -5
	},
	{#State 18
		ACTIONS => {
			"(" => 1,
			"[" => 2,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		GOTOS => {
			'bracket_start' => 5,
			'formula' => 24,
			'formula_start' => 7,
			'item' => 8
		}
	},
	{#State 19
		ACTIONS => {
			"(" => 1,
			"[" => 2,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		GOTOS => {
			'bracket_start' => 5,
			'formula' => 25,
			'formula_start' => 7,
			'item' => 8
		}
	},
	{#State 20
		ACTIONS => {
			'SPACE' => 26
		},
		DEFAULT => -16,
		GOTOS => {
			'opt_space' => 27
		}
	},
	{#State 21
		ACTIONS => {
			'ELEMENT' => 17
		},
		DEFAULT => -2
	},
	{#State 22
		ACTIONS => {
			'SPACE' => 26
		},
		DEFAULT => -16,
		GOTOS => {
			'opt_space' => 28
		}
	},
	{#State 23
		DEFAULT => -6
	},
	{#State 24
		ACTIONS => {
			'SPACE' => 26
		},
		DEFAULT => -16,
		GOTOS => {
			'opt_space' => 29
		}
	},
	{#State 25
		ACTIONS => {
			'SPACE' => 26
		},
		DEFAULT => -16,
		GOTOS => {
			'opt_space' => 30
		}
	},
	{#State 26
		ACTIONS => {
			"(" => 1,
			"[" => 2,
			'ELEMENT' => 3,
			'NUMBER' => 4
		},
		DEFAULT => -15,
		GOTOS => {
			'bracket_start' => 5,
			'formula_start' => 7,
			'item' => 21
		}
	},
	{#State 27
		ACTIONS => {
			"]" => 31
		}
	},
	{#State 28
		ACTIONS => {
			")" => 32
		}
	},
	{#State 29
		ACTIONS => {
			"]" => 33
		}
	},
	{#State 30
		ACTIONS => {
			")" => 34
		}
	},
	{#State 31
		ACTIONS => {
			'NUMBER' => 35
		},
		DEFAULT => -10
	},
	{#State 32
		ACTIONS => {
			'NUMBER' => 36
		},
		DEFAULT => -7
	},
	{#State 33
		DEFAULT => -12
	},
	{#State 34
		DEFAULT => -9
	},
	{#State 35
		DEFAULT => -11
	},
	{#State 36
		DEFAULT => -8
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'formula', 1, undef
	],
	[#Rule 2
		 'formula', 3, undef
	],
	[#Rule 3
		 'item', 1,
sub
#line 43 "grammar.yp"
{
		    ## print ">>> ELEMENT: ",$_[1],"\n";
		    $_[0]->{USER}->{FormulaSum}{$_[1]} += 1;
		}
	],
	[#Rule 4
		 'item', 2,
sub
#line 48 "grammar.yp"
{
		    ## print ">>> ELEMENT: ",$_[1],"\n";
		    $_[0]->{USER}->{FormulaSum}{$_[1]} += $_[2];
		}
	],
	[#Rule 5
		 'item', 2,
sub
#line 54 "grammar.yp"
{
		    ## print ">>> ELEMENT: ",$_[1],"\n";
		    $_[0]->{USER}->{FormulaSum}{$_[2]} += 1;
		}
	],
	[#Rule 6
		 'item', 3,
sub
#line 60 "grammar.yp"
{
		    ## print ">>> ELEMENT: ",$_[2], " number: ", $_[3], "\n";
		    $_[0]->{USER}->{FormulaSum}{$_[2]} += $_[3];
		}
	],
	[#Rule 7
		 'item', 5,
sub
#line 66 "grammar.yp"
{
		    my $subformula = $_[0]->{USER}->{FormulaSum};
		    $_[0]->{USER}->{FormulaSum} =
			pop( @{$_[0]->{USER}->{FormulaStack}} );

		    for my $key ( keys %{$subformula} ) {
			$_[0]->{USER}->{FormulaSum}->{$key} +=
			    $subformula->{$key};
		    }
		}
	],
	[#Rule 8
		 'item', 6,
sub
#line 79 "grammar.yp"
{
		    my $subformula = $_[0]->{USER}->{FormulaSum};
		    $_[0]->{USER}->{FormulaSum} =
			pop( @{$_[0]->{USER}->{FormulaStack}} );

		    for my $key ( keys %{$subformula} ) {
			$_[0]->{USER}->{FormulaSum}->{$key} +=
			    $subformula->{$key} * $_[6];
		    }
		}
	],
	[#Rule 9
		 'item', 6,
sub
#line 92 "grammar.yp"
{
		    my $subformula = $_[0]->{USER}->{FormulaSum};
		    $_[0]->{USER}->{FormulaSum} =
			pop( @{$_[0]->{USER}->{FormulaStack}} );

		    for my $key ( keys %{$subformula} ) {
			$_[0]->{USER}->{FormulaSum}->{$key} +=
			    $subformula->{$key} * $_[1];
		    }
		}
	],
	[#Rule 10
		 'item', 5,
sub
#line 104 "grammar.yp"
{
		    my $subformula = $_[0]->{USER}->{FormulaSum};
		    $_[0]->{USER}->{FormulaSum} =
			pop( @{$_[0]->{USER}->{FormulaStack}} );

		    for my $key ( keys %{$subformula} ) {
			$_[0]->{USER}->{FormulaSum}->{$key} +=
			    $subformula->{$key};
		    }
		}
	],
	[#Rule 11
		 'item', 6,
sub
#line 117 "grammar.yp"
{
		    my $subformula = $_[0]->{USER}->{FormulaSum};
		    $_[0]->{USER}->{FormulaSum} =
			pop( @{$_[0]->{USER}->{FormulaStack}} );

		    for my $key ( keys %{$subformula} ) {
			$_[0]->{USER}->{FormulaSum}->{$key} +=
			    $subformula->{$key} * $_[6];
		    }
		}
	],
	[#Rule 12
		 'item', 6,
sub
#line 130 "grammar.yp"
{
		    my $subformula = $_[0]->{USER}->{FormulaSum};
		    $_[0]->{USER}->{FormulaSum} =
			pop( @{$_[0]->{USER}->{FormulaStack}} );

		    for my $key ( keys %{$subformula} ) {
			$_[0]->{USER}->{FormulaSum}->{$key} +=
			    $subformula->{$key} * $_[1];
		    }
		}
	],
	[#Rule 13
		 'formula_start', 1,
sub
#line 145 "grammar.yp"
{
	    push( @{$_[0]->{USER}->{FormulaStack}},
		  $_[0]->{USER}->{FormulaSum} );
	    $_[0]->{USER}->{FormulaSum} = {}
	}
	],
	[#Rule 14
		 'bracket_start', 1,
sub
#line 154 "grammar.yp"
{
	    push( @{$_[0]->{USER}->{FormulaStack}},
		  $_[0]->{USER}->{FormulaSum} );
	    $_[0]->{USER}->{FormulaSum} = {}
	}
	],
	[#Rule 15
		 'opt_space', 1, undef
	],
	[#Rule 16
		 'opt_space', 0, undef
	]
],
                                  @_);
    bless($self,$class);
}

#line 166 "grammar.yp"

# --------------------------------------------------------------
# begin of footer
# --------------------------------------------------------------

sub _Error
{
        $_[0]->YYData->{ERRCOUNT}++;
	exists $_[0]->YYData->{ERRMSG}
	and do {
		print STDERR $_[0]->YYData->{ERRMSG};
		delete $_[0]->YYData->{ERRMSG};
		return;
	};
	print STDERR "incorrect formula syntax:\n";
	print STDERR $_[0]->YYData->{LINE}, "\n";
	print STDERR " " x $_[0]->YYData->{VARS}{token_prev_pos};
	print STDERR "^\n";
}

sub PrintFormula
{
    my ($parser) = @_;

    if( $parser->YYNberr() == 0 ) {
	my %formula = %{$parser->{USER}->{FormulaSum}};

	my $separator = "";
	if( exists $formula{C} && exists $formula{H} ) {
	    print "C", $formula{C}, " ", "H", $formula{H};
	    delete $formula{C};
	    delete $formula{H};
	    $separator = " ";
	}
	for my $key (sort {$a cmp $b} keys %formula) {
	    print $separator, $key, $formula{$key} != 1 ? $formula{$key} : "";
	    $separator = " ";
	}
	print "\n";
    }
}

sub _Lexer
{
    my($parser) = shift;

    if( !defined $parser->YYData->{INPUT} ||
	$parser->YYData->{INPUT} =~ m/^\s*$/ ) {
	## print ">>> lexing: empty line...\n";
	return('',undef);
    } else {
	## $parser->YYData->{INPUT} =~ s/^\s*//;
	## print ">>> lexing: ", $parser->YYData->{INPUT}, "\n";

	$parser->YYData->{VARS}{token_prev_pos} = $parser->YYData->{VARS}{token_pos};
	for($parser->YYData->{INPUT}) {
	    if( s/^([A-Za-z][a-z]?)// ) {
		$parser->YYData->{VARS}{token_pos} += length($1);
		return( 'ELEMENT', $1 );
	    }
	    if( s/^([-+0-9.Ee]+)// ) {
		$parser->YYData->{VARS}{token_pos} += length($1);
		return( 'NUMBER', $1 );
	    }
	    if( s/^(\()// ) {
		$parser->YYData->{VARS}{token_pos} += length($1);
		return ( '(', $1 );
	    }
	    if( s/^(\))// ) {
		$parser->YYData->{VARS}{token_pos} += length($1);
		return ( ')', $1 );
	    }
	    if( s/^(\[)// ) {
		$parser->YYData->{VARS}{token_pos} += length($1);
		return ( '[', $1 );
	    }
	    if( s/^(\])// ) {
		$parser->YYData->{VARS}{token_pos} += length($1);
		return ( ']', $1 );
	    }
	    if( s/^([\s.]+)// ) {
		$parser->YYData->{VARS}{token_pos} += length($1);
		return ( 'SPACE', $1 );
	    }
	    else {
		return( '', undef );
	    }
	}
    }
}

sub Run
{
    my ( $self, $filename ) = @_;

    $self->ParseFile( $filename );
}

sub ParseString
{
    my ($self, $text) = @_;

    $self->YYData->{INPUT} = $text;
    $self->YYData->{LINE} = $text;

    $self->YYData->{VARS}{token_prev_pos} = 0;
    $self->YYData->{VARS}{token_pos} = 0;

    $| = 1;

    if( $formula_sum::debug >= 2 && $formula_sum::debug < 3) {
	$self->YYParse( yylex => \&_Lexer,
			yyerror => \&_Error,
			yydebug => 0x05 );
    } else {
	$self->YYParse( yylex => \&_Lexer, yyerror => \&_Error );
    }
    if( $self->YYNberr() == 0 ) {
	if( $formula_sum::debug >= 1 && $formula_sum::debug < 3 ) {
	    print "File syntax is CORRECT!\n";
	}
    } else {
	if( $formula_sum::debug >= 1 && $formula_sum::debug < 3 ) {
	    print "Syntax check failed.\n";
	}
    }
    return $self->{USER}->{FormulaSum};
}

sub ParseFile
{
    my($self) = shift;
    my($filename) = shift;

    $filename = "-" unless $filename;

    $self->{USER}{FILENAME} = $filename;

    open( FORMULA_FILE, $filename ) or
        die( "could not open file '$filename' for input: $!" );

    my $formula_text = <FORMULA_FILE>;

    close( FORMULA_FILE );

    return $self->ParseString( $formula_text );
}

return 1;

1;

/*---------------------------------------------------------------------------*\
**$Author: antanas $
**$Date: 2019-11-15 18:13:46 +0200 (Fri, 15 Nov 2019) $ 
**$Revision: 7412 $
**$URL: svn+ssh://www.crystallography.net/home/coder/svn-repositories/cod-tools/tags/v3.7.0/src/components/codcif/version.hin $
\*---------------------------------------------------------------------------*/

#ifndef __VERSION_H
#define __VERSION_H

#define VERSION "3.7.0"

#endif

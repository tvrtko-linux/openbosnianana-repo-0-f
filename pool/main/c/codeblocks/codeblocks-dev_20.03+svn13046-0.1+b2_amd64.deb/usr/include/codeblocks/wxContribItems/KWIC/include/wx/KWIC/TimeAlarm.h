/////////////////////////////////////////////////////////////////////////////
// Name:        TimeAlarm.h
// Purpose:
// Author:      Marco Cavallini <m.cavallini AT koansoftware.com>
// Modified by:
// Copyright:   (C)2004-2006 Copyright by Koan s.a.s. - www.koansoftware.com
// Licence:     KWIC License http://www.koansoftware.com/kwic/kwic-license.htm
/////////////////////////////////////////////////////////////////////////////
//
//	Cleaned up and modified by Gary Harris for wxSmithKWIC, 2010.
//
/////////////////////////////////////////////////////////////////////////////

#ifndef TIMEALARM_H
#define TIMEALARM_H

#ifdef __WXMSW__
    #ifndef DLLEXPORT
	      #define DLLEXPORT __declspec (dllexport)
    #endif
#else
    #define DLLEXPORT
#endif

class DLLEXPORT CTimeAlarm
{
public:
	CTimeAlarm() ;

	void Enable () { m_bEnable = true ; } ;
	void Disable () { m_bEnable = false ; } ;

	void SetAlarmTime(wxDateTime alarmtime) ;
	void SetAlarmTime(double alarmtime) ;

	wxString GetAlarmString () ;

private:
	double m_dJAlarmTime ;
	bool m_bEnable ;

};

#endif

import './foldcode';

declare module './foldcode' {
    interface FoldHelpers {
        comment: FoldRangeFinder;
    }
}

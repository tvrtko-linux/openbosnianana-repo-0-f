import './foldcode';

declare module './foldcode' {
    interface FoldHelpers {
        indent: FoldRangeFinder;
    }
}

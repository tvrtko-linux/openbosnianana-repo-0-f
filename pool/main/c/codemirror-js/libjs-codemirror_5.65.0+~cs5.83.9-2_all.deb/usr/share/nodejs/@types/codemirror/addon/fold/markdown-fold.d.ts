import './foldcode';

declare module './foldcode' {
    interface FoldHelpers {
        markdown: FoldRangeFinder;
    }
}

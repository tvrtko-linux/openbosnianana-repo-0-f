import './show-hint';

declare module '../../' {
    interface HintHelpers {
        css: HintFunction;
    }
}

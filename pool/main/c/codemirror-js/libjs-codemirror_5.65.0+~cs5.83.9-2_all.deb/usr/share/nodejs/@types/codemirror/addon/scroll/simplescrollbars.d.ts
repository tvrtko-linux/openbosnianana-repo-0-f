import '../../';

declare module '../../' {
    interface ScrollbarModels {
        simple: ScrollbarModelConstructor;
        overlay: ScrollbarModelConstructor;
    }
}

// Type definitions for tern 0.23
// Project: https://github.com/ternjs/tern
// Definitions by: Nikolaj Kappler <https://github.com/nkappler>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped
// TypeScript Version: 2.8

export * from "./lib/infer";
export * from "./lib/tern";

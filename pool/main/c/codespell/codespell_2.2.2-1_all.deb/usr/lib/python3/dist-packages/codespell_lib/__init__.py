from ._codespell import main, _script_main  # noqa
from ._version import __version__  # noqa

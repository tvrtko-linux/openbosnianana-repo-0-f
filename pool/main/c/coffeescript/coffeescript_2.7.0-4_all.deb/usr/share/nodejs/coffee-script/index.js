module.exports = require('coffeescript');

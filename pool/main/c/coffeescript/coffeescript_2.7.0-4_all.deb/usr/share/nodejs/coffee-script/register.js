module.exports = require('coffeescript/register');

/* src/config_cgl.h.  Generated from config_cgl.h.in by configure.  */
/* src/config_cgl.h.in. */

#ifndef __CONFIG_CGL_H__
#define __CONFIG_CGL_H__

/* Version number of project */
#define CGL_VERSION "0.60.3"

/* Major Version number of project */
#define CGL_VERSION_MAJOR 0

/* Minor Version number of project */
#define CGL_VERSION_MINOR 60

/* Release Version number of project */
#define CGL_VERSION_RELEASE 3

#endif

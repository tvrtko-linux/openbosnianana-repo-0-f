var searchData=
[
  ['x_1669',['x',['../structDGG__data__t.html#a477a9528537c70c91aad40d55b752430',1,'DGG_data_t']]],
  ['xlp_1670',['xlp',['../classCglGMI.html#a8dfd941a8a722b8604bc9ba824d8eb90',1,'CglGMI::xlp()'],['../classCglRedSplit.html#a6a051b0768e94c07da2f3d67cb7e46b3',1,'CglRedSplit::xlp()'],['../classCglRedSplit2.html#a19aa32f560de2195a7625ed2485b9e7a',1,'CglRedSplit2::xlp()']]],
  ['xstar_1671',['xstar',['../structilp.html#a72917e0dab7067ce475f3fa465acf8a7',1,'ilp::xstar()'],['../structparity__ilp.html#aa64ea08a3a7f8533a669dd3990a94601',1,'parity_ilp::xstar()']]]
];

var searchData=
[
  ['justoriginalrows_5f_875',['justOriginalRows_',['../classCglClique.html#a3da7d1f01b67cb2038230532fc9348dc',1,'CglClique']]]
];

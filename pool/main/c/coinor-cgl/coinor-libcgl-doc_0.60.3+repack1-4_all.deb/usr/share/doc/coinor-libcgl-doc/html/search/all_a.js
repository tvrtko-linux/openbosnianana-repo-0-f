var searchData=
[
  ['keepcolumnnames_5f_876',['keepColumnNames_',['../classCglPreProcess.html#a8c3c595c25eda2b72fa10f20c1991f27',1,'CglPreProcess']]],
  ['krem_877',['KREM',['../CglTwomir_8hpp.html#a8fc70cb278bfe33ee9cf919372df5827',1,'CglTwomir.hpp']]]
];

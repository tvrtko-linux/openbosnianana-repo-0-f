var searchData=
[
  ['abov_3365',['ABOV',['../CglTwomir_8hpp.html#a621b51e72dd36d63d1cb3a76e99a950c',1,'CglTwomir.hpp']]]
];

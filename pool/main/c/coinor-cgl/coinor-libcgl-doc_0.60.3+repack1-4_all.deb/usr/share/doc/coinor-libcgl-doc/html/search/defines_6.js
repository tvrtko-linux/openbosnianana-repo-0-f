var searchData=
[
  ['lmin_3478',['LMIN',['../CglTwomir_8hpp.html#a7bbc700f25a44121d2b3020462eb4407',1,'CglTwomir.hpp']]]
];

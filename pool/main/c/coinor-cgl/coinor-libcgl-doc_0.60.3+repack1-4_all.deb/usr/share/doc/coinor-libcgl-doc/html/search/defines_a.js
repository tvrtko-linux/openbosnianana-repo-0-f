var searchData=
[
  ['reduction_3488',['REDUCTION',['../Cgl012cut_8hpp.html#a531a811a13a6b5422c391e0a51fc4ceb',1,'Cgl012cut.hpp']]]
];

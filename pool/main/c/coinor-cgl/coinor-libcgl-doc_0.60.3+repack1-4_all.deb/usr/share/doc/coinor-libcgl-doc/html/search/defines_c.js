var searchData=
[
  ['v2i_3494',['V2I',['../CglTwomir_8hpp.html#a0160a55dff3f8a6a896c3ced83035477',1,'CglTwomir.hpp']]],
  ['version_3495',['VERSION',['../config_8h.html#a1c6d5de492ac61ad29aec7aa9a436bbf',1,'config.h']]]
];

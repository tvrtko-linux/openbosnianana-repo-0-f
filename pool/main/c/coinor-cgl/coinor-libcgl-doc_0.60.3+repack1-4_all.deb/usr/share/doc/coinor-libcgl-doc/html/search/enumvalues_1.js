var searchData=
[
  ['begin_5fround_3179',['BEGIN_ROUND',['../namespaceLAP.html#ab0f61f9279b61d68c5dafebfa2b6a1b2af016a1ce2b530ee61e8d60896d2d6f4d',1,'LAP']]],
  ['bestpivot_3180',['bestPivot',['../classCglLandP.html#a4a2421732255fb36a7653287780530feade2b9209d9d188bddd24687258ebf5b0',1,'CglLandP']]],
  ['bigdynamic_3181',['BigDynamic',['../classLAP_1_1Validator.html#ab1604420363c97b352ae27008c313fd6a2c614d49f62b356d51d7ba459487bb63',1,'LAP::Validator']]]
];

var searchData=
[
  ['uniform_3330',['Uniform',['../classCglLandP.html#a77063357878ab868a965f0c887acf899a84d9e87861661f314b3637bc34984b2f',1,'CglLandP']]],
  ['unweighted_3331',['Unweighted',['../classCglLandP.html#ab4e0723cc1bbeabd0a0d7f3bac517781a2614701cd9cfe42b254dc46d1840d4ea',1,'CglLandP']]]
];

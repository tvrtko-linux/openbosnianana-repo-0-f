var searchData=
[
  ['y_0',['y',['../structlpprob__struct.html#af97b5ec49430cc3e3c82f96029553bd7',1,'lpprob_struct']]]
];

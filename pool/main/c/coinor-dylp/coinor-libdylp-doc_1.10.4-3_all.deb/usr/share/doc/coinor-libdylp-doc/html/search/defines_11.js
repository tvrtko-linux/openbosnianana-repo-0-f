var searchData=
[
  ['ucalloc_0',['ucalloc',['../glplib_8h.html#abe7a6a055a2add0aa3416e8b1e68629b',1,'glplib.h']]],
  ['ufree_1',['ufree',['../glplib_8h.html#ac638fb3bbeff76d4b9856b01eb1a7c9a',1,'glplib.h']]],
  ['umalloc_2',['umalloc',['../glplib_8h.html#a7c6ac0e722f04479274a29ede348e339',1,'glplib.h']]],
  ['unused_3',['UNUSED',['../dylib__std_8h.html#addf5ec070e9499d36b7f2009ce736076',1,'dylib_std.h']]]
];

var searchData=
[
  ['odsi_5finfomsgs_0',['ODSI_INFOMSGS',['../config_8h.html#a8c60a50a891ca8756b714d81379fd2eb',1,'config.h']]],
  ['odsi_5fparanoia_1',['ODSI_PARANOIA',['../config_8h.html#aefe92988d36b498657137c82175f1c16',1,'config.h']]]
];

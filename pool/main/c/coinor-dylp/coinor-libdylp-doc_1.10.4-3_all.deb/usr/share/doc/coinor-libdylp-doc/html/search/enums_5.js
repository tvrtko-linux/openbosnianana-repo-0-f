var searchData=
[
  ['odsi_5fstart_5fenum_0',['ODSI_start_enum',['../OsiDylpSolverInterface_8hpp.html#a1fdcb438b6a75b5876806d94b6f99528',1,'OsiDylpSolverInterface.hpp']]],
  ['osidylpmessageid_5fenum_1',['OsiDylpMessageID_enum',['../OsiDylpMessages_8hpp.html#a03585c66d35068405f03afae3afee044',1,'OsiDylpMessages.hpp']]]
];

var searchData=
[
  ['newlanguage_0',['newLanguage',['../classOsiDylpSolverInterface.html#af0323361a53f7e5ee565e44ad82d0a15',1,'OsiDylpSolverInterface']]],
  ['numberactiveconstraints_1',['numberActiveConstraints',['../classOsiDylpWarmStartBasis.html#a3faa116907f10b35d96008caf7194b4f',1,'OsiDylpWarmStartBasis']]]
];

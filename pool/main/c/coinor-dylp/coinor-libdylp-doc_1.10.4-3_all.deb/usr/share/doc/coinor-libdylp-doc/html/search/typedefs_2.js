var searchData=
[
  ['coeff_5fstruct_0',['coeff_struct',['../dy__consys_8h.html#ab49a33972ea5c5a5cccd61183b4bd509',1,'dy_consys.h']]],
  ['colhdr_5fstruct_1',['colhdr_struct',['../dy__consys_8h.html#acb124157d44655ebdcbc0581d41c58fa',1,'dy_consys.h']]]
];

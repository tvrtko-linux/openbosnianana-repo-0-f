var searchData=
[
  ['double_5fprecision_0',['double_precision',['../dylib__fortran_8h.html#a079c56d232f9e899364f22b4e50e55d1',1,'dylib_fortran.h']]]
];

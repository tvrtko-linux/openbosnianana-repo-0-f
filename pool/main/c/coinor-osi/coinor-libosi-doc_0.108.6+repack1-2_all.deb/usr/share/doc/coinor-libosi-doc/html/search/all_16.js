var searchData=
[
  ['x_1078',['x',['../classVOL__primal.html#a563b44dc1a2ebdb454678ad3e9d227c8',1,'VOL_primal']]],
  ['xprprobname_5f_1079',['xprProbname_',['../classOsiXprSolverInterface.html#ac3d8e889d003d1a7239b7b168c8ed49d',1,'OsiXprSolverInterface']]],
  ['xprsprob_1080',['XPRSprob',['../OsiXprSolverInterface_8hpp.html#a52d017fc4654de89d9a4ebd32c571719',1,'OsiXprSolverInterface.hpp']]],
  ['xrc_1081',['xrc',['../classVOL__dual.html#a20389534de13517ff7cae7155aa7719b',1,'VOL_dual']]]
];

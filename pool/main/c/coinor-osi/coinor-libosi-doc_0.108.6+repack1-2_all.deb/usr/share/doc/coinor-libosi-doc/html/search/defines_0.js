var searchData=
[
  ['coin_5fdefault_5fvalue_5ffor_5fduplicate_2270',['COIN_DEFAULT_VALUE_FOR_DUPLICATE',['../OsiCut_8hpp.html#ab20eaf1813ff887cfe62a45b3b56a538',1,'OsiCut.hpp']]],
  ['coin_5fhas_5fcoinutils_2271',['COIN_HAS_COINUTILS',['../config_8h.html#a3d2273b012898f0612a5de41b8d20ebb',1,'COIN_HAS_COINUTILS():&#160;config.h'],['../config__default_8h.html#a3d2273b012898f0612a5de41b8d20ebb',1,'COIN_HAS_COINUTILS():&#160;config_default.h']]],
  ['coin_5fhas_5fsample_2272',['COIN_HAS_SAMPLE',['../config_8h.html#a8ea44e87e1d5c8c821de2055bb250662',1,'config.h']]],
  ['coin_5fosi_5fchecklevel_2273',['COIN_OSI_CHECKLEVEL',['../config_8h.html#ae56d95e210219b3dc3bbb72d4501fda9',1,'COIN_OSI_CHECKLEVEL():&#160;config.h'],['../config__default_8h.html#ae56d95e210219b3dc3bbb72d4501fda9',1,'COIN_OSI_CHECKLEVEL():&#160;config_default.h']]],
  ['coin_5fosi_5fverbosity_2274',['COIN_OSI_VERBOSITY',['../config_8h.html#ab8e0758c05668b9b7689795beb5be88e',1,'COIN_OSI_VERBOSITY():&#160;config.h'],['../config__default_8h.html#ab8e0758c05668b9b7689795beb5be88e',1,'COIN_OSI_VERBOSITY():&#160;config_default.h']]]
];

var searchData=
[
  ['soplex_1186',['soplex',['../namespacesoplex.html',1,'']]]
];

var searchData=
[
  ['pointer_2196',['pointer',['../classOsiCuts_1_1const__iterator.html#aa428e9b661a7a4c9dd58208c13627fed',1,'OsiCuts::const_iterator']]]
];

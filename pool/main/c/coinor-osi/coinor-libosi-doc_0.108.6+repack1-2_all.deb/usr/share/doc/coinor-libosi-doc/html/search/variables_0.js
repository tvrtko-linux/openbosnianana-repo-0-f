var searchData=
[
  ['_5f_5fpad0_1849',['__pad0',['../classVOL__problem.html#abf2bf408a104f4d84341787fc7553f90',1,'VOL_problem']]],
  ['_5fopaque_5fprob_1850',['_opaque_prob',['../structglp__prob.html#aac3906c10056d1a010e4fa961c004494',1,'glp_prob']]]
];

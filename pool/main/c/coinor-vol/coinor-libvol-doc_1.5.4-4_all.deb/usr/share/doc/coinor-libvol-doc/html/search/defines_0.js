var searchData=
[
  ['coin_5fvol_5fchecklevel_683',['COIN_VOL_CHECKLEVEL',['../config__vol_8h.html#a404d44120da9a3816b4fdb9c8ea33af7',1,'config_vol.h']]],
  ['coin_5fvol_5fverbosity_684',['COIN_VOL_VERBOSITY',['../config__vol_8h.html#a828193d0e8474795fecd8b6a5fae6895',1,'config_vol.h']]]
];

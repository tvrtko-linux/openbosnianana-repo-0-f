var searchData=
[
  ['stdc_5fheaders_703',['STDC_HEADERS',['../config__vol_8h.html#a550e5c272cc3cf3814651721167dcd23',1,'config_vol.h']]]
];

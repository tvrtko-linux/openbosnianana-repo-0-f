var searchData=
[
  ['deletecols_401',['deleteCols',['../classOsiVolSolverInterface.html#a4e0e754ff11804efc4a2af47d886b53c',1,'OsiVolSolverInterface']]],
  ['deleterows_402',['deleteRows',['../classOsiVolSolverInterface.html#a26022e9595a58df902ac8f5d67663e25',1,'OsiVolSolverInterface']]]
];

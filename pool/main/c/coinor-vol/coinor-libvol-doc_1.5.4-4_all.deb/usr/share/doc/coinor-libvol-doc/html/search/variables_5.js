var searchData=
[
  ['fcost_580',['fcost',['../classUFL.html#a5763816ca8bc636da245e8bdfe72ff5c',1,'UFL']]],
  ['fdata_581',['fdata',['../classUFL__parms.html#acbee5e252937f19b8eb18eb3ea72e3e4',1,'UFL_parms::fdata()'],['../classLP__parms.html#ae4e16707b9045e8b0ffe2fbfc2611c4a',1,'LP_parms::fdata()']]],
  ['fix_582',['fix',['../classUFL.html#acd02f2ff49b16275aed41c02ed57e5cb',1,'UFL']]]
];

var searchData=
[
  ['gap_5fabs_5fprecision_583',['gap_abs_precision',['../structVOL__parms.html#a179592f4e8d7cd5d0c0b1c9aa50e39be',1,'VOL_parms']]],
  ['gap_5frel_5fprecision_584',['gap_rel_precision',['../structVOL__parms.html#a85276e75b2028f81fafc5387f463cc57',1,'VOL_parms']]],
  ['granularity_585',['granularity',['../structVOL__parms.html#a5042a409ddf58dd88c290de6362510c3',1,'VOL_parms']]],
  ['greentestinvl_586',['greentestinvl',['../structVOL__parms.html#a20b3ac7014e3ab8a08d01bd061ac7b68',1,'VOL_parms']]]
];

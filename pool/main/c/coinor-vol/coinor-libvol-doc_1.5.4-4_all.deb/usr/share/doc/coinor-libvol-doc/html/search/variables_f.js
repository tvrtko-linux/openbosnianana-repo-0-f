var searchData=
[
  ['sign_661',['sign',['../classRname.html#a93257e126df7a3b5402fd2b106647b7d',1,'Rname']]],
  ['sz_662',['sz',['../classVOL__dvector.html#af44989ee61d33c7b057d34d0695fffee',1,'VOL_dvector::sz()'],['../classVOL__ivector.html#ac0ce742eb6663a70202d3859d45a6a1f',1,'VOL_ivector::sz()']]]
];

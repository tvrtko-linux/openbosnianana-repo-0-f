/*******************************************************************************
    This file is part of ColPack, which is under its License protection.
    You should have received a copy of the License. If not, see 
    <https://github.com/CSCsw/ColPack>
*******************************************************************************/

#include <iostream>
#include <stdio.h>

//Special pause that work on both Windows and UNIX for both C and C++
void Pause();



/*******************************************************************************
    This file is part of ColPack, which is under its License protection.
    You should have received a copy of the License. If not, see 
    <https://github.com/CSCsw/ColPack>
*******************************************************************************/

#ifndef CURRENT_TIME_H
#define CURRENT_TIME_H

// Display current time
void current_time();

#endif

this folder contains templated code for example of using ColPack as an Library.

Firstly, make suer ColPack have been installed as an Library in your computer.

Then, check and modify Makefile as needed.

in your code (i.e. templated.cpp)  include ColPack header and use ColPack.

In then end, save your edit, make and run.






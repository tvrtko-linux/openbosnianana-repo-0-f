/*
 * Copyright © 2013 Canonical Ltd.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Authored by: Thomas Voß <thomas.voss@canonical.com>
 */
#ifndef COM_LOMIRI_CONTENT_TRANSFER_H_
#define COM_LOMIRI_CONTENT_TRANSFER_H_

#include <com/lomiri/content/item.h>
#include <com/lomiri/content/store.h>

#include <QObject>
#include <QSharedPointer>
#include <QVector>
#include <QString>

namespace com
{
namespace lomiri
{
namespace content
{
namespace detail
{
class Handler;
}
}
}
}

namespace com
{
namespace lomiri
{
namespace content
{
class Item;

class Transfer : public QObject
{
    Q_OBJECT
    Q_ENUMS(State)
    Q_ENUMS(SelectionType)
    Q_ENUMS(Direction)
    Q_PROPERTY(int id READ id)
    Q_PROPERTY(State state READ state NOTIFY stateChanged)
    Q_PROPERTY(QVector<Item> items READ collect WRITE charge)
    Q_PROPERTY(Store store READ store NOTIFY storeChanged)
    Q_PROPERTY(SelectionType selectionType READ selectionType WRITE setSelectionType NOTIFY selectionTypeChanged)
    Q_PROPERTY(Direction direction READ direction)
    Q_PROPERTY(QString downloadId READ downloadId WRITE setDownloadId NOTIFY downloadIdChanged)
    Q_PROPERTY(QString contentType READ contentType)
    Q_PROPERTY(QString source READ source)
    Q_PROPERTY(QString destination READ destination)

  public:
    enum State
    {
        created,
        initiated,
        in_progress,
        charged,
        collected,
        aborted,
        finalized,
        downloading,
        downloaded
    };

    enum SelectionType
    {
        single,
        multiple
    };

    enum Direction
    {
        Import,
        Export,
        Share
    };

    Transfer(const Transfer&) = delete;
    virtual ~Transfer();

    Transfer& operator=(const Transfer&) = delete;

    Q_INVOKABLE virtual int id() const;
    Q_INVOKABLE virtual State state() const;
    Q_INVOKABLE virtual SelectionType selectionType() const;
    Q_INVOKABLE virtual Direction direction() const;
    Q_INVOKABLE virtual bool start();
    Q_INVOKABLE virtual bool abort();
    Q_INVOKABLE virtual bool finalize();
    Q_INVOKABLE virtual bool charge(const QVector<Item>& items);
    Q_INVOKABLE virtual QVector<Item> collect();
    Q_INVOKABLE virtual Store store() const;
    Q_INVOKABLE virtual bool setStore(const Store*);
    Q_INVOKABLE virtual bool setSelectionType(const SelectionType&);
    Q_INVOKABLE virtual QString downloadId() const;
    Q_INVOKABLE virtual bool setDownloadId(const QString);
    Q_INVOKABLE virtual bool download();
    Q_INVOKABLE virtual QString contentType() const;
    Q_INVOKABLE virtual QString source() const;
    Q_INVOKABLE virtual QString destination() const;

    Q_SIGNAL void stateChanged();
    Q_SIGNAL void storeChanged();
    Q_SIGNAL void selectionTypeChanged();
    Q_SIGNAL void downloadIdChanged();

  private:
    struct Private;
    friend struct Private;
    friend class Hub;
    friend class com::lomiri::content::detail::Handler;
    QSharedPointer<Private> d;

    Transfer(const QSharedPointer<Private>&, QObject* parent = nullptr);    
};
}
}
}

#endif // COM_LOMIRI_CONTENT_TRANSFER_H_

var classcom_1_1lomiri_1_1content_1_1Paste =
[
    [ "State", "classcom_1_1lomiri_1_1content_1_1Paste.html#a663d1b5359128ea32ea2b8d0a783d96c", [
      [ "created", "classcom_1_1lomiri_1_1content_1_1Paste.html#a663d1b5359128ea32ea2b8d0a783d96ca1bcd1f94d82f8a44af3e5b05db9422e6", null ],
      [ "charged", "classcom_1_1lomiri_1_1content_1_1Paste.html#a663d1b5359128ea32ea2b8d0a783d96ca448f856955b44d16e3a7d078d07321ae", null ],
      [ "saved", "classcom_1_1lomiri_1_1content_1_1Paste.html#a663d1b5359128ea32ea2b8d0a783d96ca12537e3ccd4e249ed1003ada0d810c7a", null ],
      [ "collected", "classcom_1_1lomiri_1_1content_1_1Paste.html#a663d1b5359128ea32ea2b8d0a783d96ca72c1239c076ab88571cc523eece58218", null ]
    ] ],
    [ "Paste", "classcom_1_1lomiri_1_1content_1_1Paste.html#a7aa963a6633aea7e21fb592eeb6f09ff", null ],
    [ "~Paste", "classcom_1_1lomiri_1_1content_1_1Paste.html#a00dd9bbe72349e9354a1937343386ae0", null ],
    [ "id", "classcom_1_1lomiri_1_1content_1_1Paste.html#a2da093cce54aced76fd919d74d1b191c", null ],
    [ "mimeData", "classcom_1_1lomiri_1_1content_1_1Paste.html#aaa7df94783a3bd20cc02404dc0e897f1", null ],
    [ "operator=", "classcom_1_1lomiri_1_1content_1_1Paste.html#a1037a74639dbc4372e7d39b44c254f63", null ],
    [ "source", "classcom_1_1lomiri_1_1content_1_1Paste.html#a5c62791117f7abe426f7682df2ca88ff", null ],
    [ "Hub", "classcom_1_1lomiri_1_1content_1_1Paste.html#aea14f5495b4697c28ed665a9054acf5e", null ],
    [ "Private", "classcom_1_1lomiri_1_1content_1_1Paste.html#a15a94ff2bd578e608a94d0a1ba4bd3e0", null ],
    [ "id", "classcom_1_1lomiri_1_1content_1_1Paste.html#a725147b2e1dafb4a0224eebe7c0a381d", null ],
    [ "source", "classcom_1_1lomiri_1_1content_1_1Paste.html#ae2bfb534eb0bc77c5b9043ef9dc2fd38", null ]
];
var files_dup =
[
    [ "doc", "dir_e68e8157741866f444e17edd764ebbae.html", null ],
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ]
];
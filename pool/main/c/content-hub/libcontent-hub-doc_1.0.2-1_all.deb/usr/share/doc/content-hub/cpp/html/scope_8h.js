var scope_8h =
[
    [ "Scope", "scope_8h.html#aea10a1a6e64b50f573983e89d400296c", [
      [ "system", "scope_8h.html#aea10a1a6e64b50f573983e89d400296ca1612e2835e434fee43fa10b8257c7476", null ],
      [ "user", "scope_8h.html#aea10a1a6e64b50f573983e89d400296ca1d37a473f300b6daae9fe6425973e576", null ],
      [ "app", "scope_8h.html#aea10a1a6e64b50f573983e89d400296cad7aa64e7bf5e5502316ac9c6bdc559a7", null ]
    ] ]
];
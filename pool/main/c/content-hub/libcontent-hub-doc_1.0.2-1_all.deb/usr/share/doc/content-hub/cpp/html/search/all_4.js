var searchData=
[
  ['finalize_0',['finalize',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a3a5e7c568847e8418038dbc352bc94f6',1,'com::lomiri::content::Transfer']]],
  ['finalized_1',['finalized',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a9717fb775eed25139adae4c184305e7cae98588d0bbf456e85c1988e32e6e852f',1,'com::lomiri::content::Transfer']]]
];

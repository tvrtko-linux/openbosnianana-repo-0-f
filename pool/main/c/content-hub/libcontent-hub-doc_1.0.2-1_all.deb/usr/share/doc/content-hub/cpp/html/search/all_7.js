var searchData=
[
  ['known_0',['Known',['../structcom_1_1lomiri_1_1content_1_1Type_1_1Known.html',1,'com::lomiri::content::Type::Known'],['../classcom_1_1lomiri_1_1content_1_1Type.html#a201e4c47049bec7513b38a5ed76b1e86',1,'com::lomiri::content::Type::Known()']]],
  ['known_5fdestinations_5ffor_5ftype_1',['known_destinations_for_type',['../classcom_1_1lomiri_1_1content_1_1Hub.html#af69b54a4a3d055a685695606c3b3df3b',1,'com::lomiri::content::Hub']]],
  ['known_5fshares_5ffor_5ftype_2',['known_shares_for_type',['../classcom_1_1lomiri_1_1content_1_1Hub.html#a133bfcb2fbef96084670a09e7949de9c',1,'com::lomiri::content::Hub']]],
  ['known_5fsources_5ffor_5ftype_3',['known_sources_for_type',['../classcom_1_1lomiri_1_1content_1_1Hub.html#ab1eabcaa2dc630c7346fbd2b1da97062',1,'com::lomiri::content::Hub']]]
];

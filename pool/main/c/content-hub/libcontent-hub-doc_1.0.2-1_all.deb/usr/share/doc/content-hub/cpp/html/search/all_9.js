var searchData=
[
  ['mainpage_2emd_0',['Mainpage.md',['../Mainpage_8md.html',1,'']]],
  ['mimedata_1',['mimeData',['../classcom_1_1lomiri_1_1content_1_1Paste.html#aaa7df94783a3bd20cc02404dc0e897f1',1,'com::lomiri::content::Paste']]],
  ['multiple_2',['multiple',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#af1347ed4913736d10647cf9c1a27ec06a08187d8fe5e11f04205d791cbe9dd314',1,'com::lomiri::content::Transfer']]],
  ['music_3',['music',['../structcom_1_1lomiri_1_1content_1_1Type_1_1Known.html#a74927ae25ad0906cc1512b06e69e15fb',1,'com::lomiri::content::Type::Known']]]
];

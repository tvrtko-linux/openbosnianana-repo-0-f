var searchData=
[
  ['scope_0',['Scope',['../namespacecom_1_1lomiri_1_1content.html#aea10a1a6e64b50f573983e89d400296c',1,'com::lomiri::content']]],
  ['selectiontype_1',['SelectionType',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#af1347ed4913736d10647cf9c1a27ec06',1,'com::lomiri::content::Transfer']]],
  ['state_2',['State',['../classcom_1_1lomiri_1_1content_1_1Paste.html#a663d1b5359128ea32ea2b8d0a783d96c',1,'com::lomiri::content::Paste::State()'],['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a9717fb775eed25139adae4c184305e7c',1,'com::lomiri::content::Transfer::State()']]]
];

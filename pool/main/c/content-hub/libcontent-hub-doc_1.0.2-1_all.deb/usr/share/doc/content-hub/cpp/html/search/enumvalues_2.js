var searchData=
[
  ['downloaded_0',['downloaded',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a9717fb775eed25139adae4c184305e7cac57658a4a3ca2f584e004ab6769ebd5c',1,'com::lomiri::content::Transfer']]],
  ['downloading_1',['downloading',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a9717fb775eed25139adae4c184305e7caf4f472abea3766522375735e44573a7e',1,'com::lomiri::content::Transfer']]]
];

var searchData=
[
  ['finalized_0',['finalized',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a9717fb775eed25139adae4c184305e7cae98588d0bbf456e85c1988e32e6e852f',1,'com::lomiri::content::Transfer']]]
];

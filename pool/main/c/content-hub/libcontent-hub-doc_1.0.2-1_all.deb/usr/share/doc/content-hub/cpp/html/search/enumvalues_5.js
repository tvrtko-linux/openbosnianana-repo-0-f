var searchData=
[
  ['import_0',['Import',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a58cdf6c0c8c40198226a3925bee57f58ab857525f4c6afdc2753bcc2559177612',1,'com::lomiri::content::Transfer']]],
  ['in_5fprogress_1',['in_progress',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a9717fb775eed25139adae4c184305e7caf39d37ca33f76f2a13620544d4ad467e',1,'com::lomiri::content::Transfer']]],
  ['initiated_2',['initiated',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a9717fb775eed25139adae4c184305e7ca66d55633e136bc2f2fb2c990ca9ff2d6',1,'com::lomiri::content::Transfer']]]
];

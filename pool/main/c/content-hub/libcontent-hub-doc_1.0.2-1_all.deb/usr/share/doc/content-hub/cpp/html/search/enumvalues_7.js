var searchData=
[
  ['saved_0',['saved',['../classcom_1_1lomiri_1_1content_1_1Paste.html#a663d1b5359128ea32ea2b8d0a783d96ca12537e3ccd4e249ed1003ada0d810c7a',1,'com::lomiri::content::Paste']]],
  ['share_1',['Share',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a58cdf6c0c8c40198226a3925bee57f58aff78daa6f8fdce4df5451fd6a7adc36c',1,'com::lomiri::content::Transfer']]],
  ['single_2',['single',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#af1347ed4913736d10647cf9c1a27ec06a789a783be8c9f6dbcf390f0a399f8c2e',1,'com::lomiri::content::Transfer']]],
  ['system_3',['system',['../namespacecom_1_1lomiri_1_1content.html#aea10a1a6e64b50f573983e89d400296ca1612e2835e434fee43fa10b8257c7476',1,'com::lomiri::content']]]
];

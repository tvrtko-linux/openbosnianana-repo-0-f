var searchData=
[
  ['text_0',['text',['../classcom_1_1lomiri_1_1content_1_1Item.html#a123a761598f7904ef49b43ed556a39ca',1,'com::lomiri::content::Item::text()'],['../structcom_1_1lomiri_1_1content_1_1Type_1_1Known.html#af4ae8d18cc96514af1275bb9e93f277e',1,'com::lomiri::content::Type::Known::text()']]],
  ['transfer_1',['Transfer',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a91cafc27f811edf2cfcdb948b16edec5',1,'com::lomiri::content::Transfer']]],
  ['type_2',['Type',['../classcom_1_1lomiri_1_1content_1_1Type.html#ad259b3d4900f05a0d57eadcdef1c999d',1,'com::lomiri::content::Type::Type(const Type &amp;)'],['../classcom_1_1lomiri_1_1content_1_1Type.html#a3a17589468a3e0eeaa898d02fe400c54',1,'com::lomiri::content::Type::Type(const QString &amp;, QObject *=nullptr)']]]
];

var searchData=
[
  ['icondata_0',['iconData',['../classcom_1_1lomiri_1_1content_1_1Peer.html#a3abb1929a64c92f663a4cb2ac67fd8d3',1,'com::lomiri::content::Peer']]],
  ['iconname_1',['iconName',['../classcom_1_1lomiri_1_1content_1_1Peer.html#a06f10d66c4bc27afa9e0c6009e632995',1,'com::lomiri::content::Peer']]],
  ['id_2',['id',['../classcom_1_1lomiri_1_1content_1_1Paste.html#a2da093cce54aced76fd919d74d1b191c',1,'com::lomiri::content::Paste::id()'],['../classcom_1_1lomiri_1_1content_1_1Peer.html#ae192394f8b201f3f813347621fc3abf8',1,'com::lomiri::content::Peer::id()'],['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a301420f90cea77a315fce7a1eb31c170',1,'com::lomiri::content::Transfer::id()'],['../classcom_1_1lomiri_1_1content_1_1Type.html#ab45f6f41562265263eca0bc160bd9327',1,'com::lomiri::content::Type::id()']]],
  ['importexporthandler_3',['ImportExportHandler',['../classcom_1_1lomiri_1_1content_1_1ImportExportHandler.html#a30aac29d66bb6fdf513e3629e2b91b02',1,'com::lomiri::content::ImportExportHandler::ImportExportHandler(const ImportExportHandler &amp;)=delete'],['../classcom_1_1lomiri_1_1content_1_1ImportExportHandler.html#a11f2ea30bf683be69a5ea6b2ba2ea2d7',1,'com::lomiri::content::ImportExportHandler::ImportExportHandler(QObject *parent=nullptr)']]],
  ['instance_4',['instance',['../structcom_1_1lomiri_1_1content_1_1Hub_1_1Client.html#a42a139363c1fd84f3f608accabf3a67c',1,'com::lomiri::content::Hub::Client']]],
  ['isdefaultpeer_5',['isDefaultPeer',['../classcom_1_1lomiri_1_1content_1_1Peer.html#aa3a337a0d7557665b41f98400b8d0b8a',1,'com::lomiri::content::Peer']]],
  ['item_6',['Item',['../classcom_1_1lomiri_1_1content_1_1Item.html#a38d7c84b8d24e33d4d223375e11ee2b5',1,'com::lomiri::content::Item::Item(const QUrl &amp;=QUrl(), QObject *=nullptr)'],['../classcom_1_1lomiri_1_1content_1_1Item.html#a2cd0bbcf93ef7c6bc6f3676a876373a6',1,'com::lomiri::content::Item::Item(const Item &amp;)']]]
];

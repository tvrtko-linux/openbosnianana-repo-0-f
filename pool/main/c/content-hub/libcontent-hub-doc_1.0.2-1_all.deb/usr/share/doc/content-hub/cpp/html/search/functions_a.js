var searchData=
[
  ['name_0',['name',['../classcom_1_1lomiri_1_1content_1_1Item.html#a37bf1f6db29e4766c0f2ad4ad2d2695e',1,'com::lomiri::content::Item::name()'],['../classcom_1_1lomiri_1_1content_1_1Peer.html#abc832165265a2d2cba3ff2ffb6255221',1,'com::lomiri::content::Peer::name()']]]
];

var searchData=
[
  ['paste_0',['Paste',['../classcom_1_1lomiri_1_1content_1_1Paste.html#a7aa963a6633aea7e21fb592eeb6f09ff',1,'com::lomiri::content::Paste']]],
  ['paste_1',['paste',['../classcom_1_1lomiri_1_1content_1_1Hub.html#a80f18d38fee3e837d3a209ad35dc7fdb',1,'com::lomiri::content::Hub']]],
  ['pasteboardchanged_2',['pasteboardChanged',['../classcom_1_1lomiri_1_1content_1_1Hub.html#a5c60958f840f4b92b56e0e4a3086bb75',1,'com::lomiri::content::Hub']]],
  ['pastebyid_3',['pasteById',['../classcom_1_1lomiri_1_1content_1_1Hub.html#a94a2d4fb39c0284fe17d100336cfcd5d',1,'com::lomiri::content::Hub']]],
  ['pasteformats_4',['pasteFormats',['../classcom_1_1lomiri_1_1content_1_1Hub.html#a2ce35d010d72726c03141630b8b2ac06',1,'com::lomiri::content::Hub']]],
  ['pasteformatschanged_5',['pasteFormatsChanged',['../classcom_1_1lomiri_1_1content_1_1Hub.html#a247d0271f846152bad609d3a00981183',1,'com::lomiri::content::Hub']]],
  ['peer_6',['Peer',['../classcom_1_1lomiri_1_1content_1_1Peer.html#ae3ed1533ad3f8135b5ae42906c55e9a4',1,'com::lomiri::content::Peer::Peer(const QString &amp;id=QString(), bool isDefaultPeer=false, QObject *parent=nullptr)'],['../classcom_1_1lomiri_1_1content_1_1Peer.html#ab051781a81a02d1644692133a86710ee',1,'com::lomiri::content::Peer::Peer(const QString &amp;, const QString &amp;, QByteArray &amp;, const QString &amp;, bool, QObject *parent=nullptr)'],['../classcom_1_1lomiri_1_1content_1_1Peer.html#a5a6944d76b91e6b263d8bfbc2749ef8d',1,'com::lomiri::content::Peer::Peer(const Peer &amp;rhs)']]],
  ['peer_5ffor_5fapp_5fid_7',['peer_for_app_id',['../classcom_1_1lomiri_1_1content_1_1Hub.html#a5d41c115351f4df4bd11b46529ebdff8',1,'com::lomiri::content::Hub']]],
  ['pictures_8',['pictures',['../structcom_1_1lomiri_1_1content_1_1Type_1_1Known.html#aced735ba71f0ba6d9ecc137f02a10386',1,'com::lomiri::content::Type::Known']]]
];

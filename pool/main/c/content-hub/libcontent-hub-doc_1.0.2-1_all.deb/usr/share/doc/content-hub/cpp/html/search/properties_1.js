var searchData=
[
  ['destination_0',['destination',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a92706765770b5cfb20885902ba83f9ce',1,'com::lomiri::content::Transfer']]],
  ['direction_1',['direction',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#ad6f499014806b32e0211812418a9ec0b',1,'com::lomiri::content::Transfer']]],
  ['downloadid_2',['downloadId',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a9cbedb6f2f51979dd230f0fd81e6a22c',1,'com::lomiri::content::Transfer']]]
];

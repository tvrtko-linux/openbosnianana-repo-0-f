var searchData=
[
  ['iconname_0',['iconName',['../classcom_1_1lomiri_1_1content_1_1Peer.html#a23e58cbc131f25765ed7a0daabdb5c8e',1,'com::lomiri::content::Peer']]],
  ['id_1',['id',['../classcom_1_1lomiri_1_1content_1_1Paste.html#a725147b2e1dafb4a0224eebe7c0a381d',1,'com::lomiri::content::Paste::id()'],['../classcom_1_1lomiri_1_1content_1_1Peer.html#aedf9b089724ab3517e3014b75c6cea74',1,'com::lomiri::content::Peer::id()'],['../classcom_1_1lomiri_1_1content_1_1Transfer.html#ae871f4a024c67d1a2ae1ee28712c47b2',1,'com::lomiri::content::Transfer::id()'],['../classcom_1_1lomiri_1_1content_1_1Type.html#a2b8e0a81a972b5e43c8f4bfdd0d3ffed',1,'com::lomiri::content::Type::id()']]],
  ['isdefaultpeer_2',['isDefaultPeer',['../classcom_1_1lomiri_1_1content_1_1Peer.html#abb60a2f8504460f161c11816e4922923',1,'com::lomiri::content::Peer']]],
  ['items_3',['items',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a4152258dbcc7317083374983c4e16bbf',1,'com::lomiri::content::Transfer']]]
];

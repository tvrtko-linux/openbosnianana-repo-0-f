var searchData=
[
  ['name_0',['name',['../classcom_1_1lomiri_1_1content_1_1Item.html#a1eab7bd76a55701c175cb42174b557e0',1,'com::lomiri::content::Item::name()'],['../classcom_1_1lomiri_1_1content_1_1Peer.html#a9c23426b03d3d2a1b6481df3c4794d30',1,'com::lomiri::content::Peer::name()']]]
];

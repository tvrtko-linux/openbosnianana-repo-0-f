var searchData=
[
  ['selectiontype_0',['selectionType',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a09114ef7f16babf0a1ec8c81460cafc1',1,'com::lomiri::content::Transfer']]],
  ['source_1',['source',['../classcom_1_1lomiri_1_1content_1_1Paste.html#ae2bfb534eb0bc77c5b9043ef9dc2fd38',1,'com::lomiri::content::Paste::source()'],['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a8c5bd73b53fe2a48a5c5b810b8e4e24f',1,'com::lomiri::content::Transfer::source()']]],
  ['state_2',['state',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a8a6badefa9d8a166b5f5f32282c87653',1,'com::lomiri::content::Transfer']]],
  ['store_3',['store',['../classcom_1_1lomiri_1_1content_1_1Transfer.html#aa1d23dc78610d029a5fc0c2ba13e7e77',1,'com::lomiri::content::Transfer']]],
  ['stream_4',['stream',['../classcom_1_1lomiri_1_1content_1_1Item.html#af6d2a8d7e4444f7a70a08cd831cd36b0',1,'com::lomiri::content::Item']]],
  ['streamtype_5',['streamType',['../classcom_1_1lomiri_1_1content_1_1Item.html#abdb0063cc508142e4bc155cbd5ef7e10',1,'com::lomiri::content::Item']]]
];

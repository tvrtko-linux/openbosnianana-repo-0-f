var searchData=
[
  ['text_0',['text',['../classcom_1_1lomiri_1_1content_1_1Item.html#a69ae00d5525e94be80647532f58f9cf9',1,'com::lomiri::content::Item']]]
];

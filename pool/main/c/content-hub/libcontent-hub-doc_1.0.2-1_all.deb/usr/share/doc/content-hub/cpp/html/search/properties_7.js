var searchData=
[
  ['uri_0',['uri',['../classcom_1_1lomiri_1_1content_1_1Store.html#abb69144f11f693ed0a9c1aaaeeb51273',1,'com::lomiri::content::Store']]],
  ['url_1',['url',['../classcom_1_1lomiri_1_1content_1_1Item.html#a8bb6a80a00aa0fa3cbea4f45a16aa202',1,'com::lomiri::content::Item']]]
];

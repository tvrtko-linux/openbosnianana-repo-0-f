var searchData=
[
  ['private_0',['Private',['../classcom_1_1lomiri_1_1content_1_1Paste.html#a15a94ff2bd578e608a94d0a1ba4bd3e0',1,'com::lomiri::content::Paste::Private()'],['../classcom_1_1lomiri_1_1content_1_1Transfer.html#a15a94ff2bd578e608a94d0a1ba4bd3e0',1,'com::lomiri::content::Transfer::Private()']]]
];

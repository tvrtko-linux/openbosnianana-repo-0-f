var indexSectionsWithContent =
{
  0: "acdefhiklmnopqrstuv~",
  1: "chikpqst",
  2: "c",
  3: "himpst",
  4: "acdefhiklmnopqrstuv~",
  5: "d",
  6: "ds",
  7: "acdefimsu",
  8: "cdinpstu",
  9: "cdhkp",
  10: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "properties",
  9: "related",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Properties",
  9: "Friends",
  10: "Pages"
};


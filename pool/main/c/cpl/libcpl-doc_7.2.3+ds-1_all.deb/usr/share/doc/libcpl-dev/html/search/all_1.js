var searchData=
[
  ['api_0',['api',['../struct__cpl__plugin__.html#a0a2c1e2e44d8f3a0505fe96b1bf4ca6a',1,'_cpl_plugin_']]],
  ['arrays_1',['Arrays',['../group__cpl__array.html',1,'']]],
  ['author_2',['author',['../struct__cpl__plugin__.html#a1b0c0cc4cc4a296a8fc5b8f4104f4b06',1,'_cpl_plugin_']]],
  ['auxiliary_20frame_20data_3',['Auxiliary Frame Data',['../group__cpl__framedata.html',1,'']]]
];

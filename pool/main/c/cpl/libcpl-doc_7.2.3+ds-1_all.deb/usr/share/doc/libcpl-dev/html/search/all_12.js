var searchData=
[
  ['wavelength_20calibration_0',['Wavelength calibration',['../group__cpl__wlcalib.html',1,'']]],
  ['world_20coordinate_20system_1',['World Coordinate System',['../group__cpl__wcs.html',1,'']]]
];

var searchData=
[
  ['bi_2dvector_20object_0',['Bi-vector object',['../group__cpl__bivector.html',1,'']]]
];

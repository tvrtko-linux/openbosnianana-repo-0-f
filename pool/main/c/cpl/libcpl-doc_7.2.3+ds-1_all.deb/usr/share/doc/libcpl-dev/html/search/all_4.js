var searchData=
[
  ['deinitialize_0',['deinitialize',['../struct__cpl__plugin__.html#ac10df7398cc0b9c0d2b629c3317551b8',1,'_cpl_plugin_']]],
  ['deprecated_20list_1',['Deprecated List',['../deprecated.html',1,'']]],
  ['description_2',['description',['../struct__cpl__plugin__.html#af0f392cd13aede3e3071f2dd98fd87d5',1,'_cpl_plugin_']]],
  ['dfs_20related_20functions_3',['DFS related functions',['../group__cpl__dfs.html',1,'']]],
  ['dicb_20specific_20property_20functionality_4',['DICB specific property functionality',['../group__cpl__property__dicb.html',1,'']]]
];

var searchData=
[
  ['email_0',['email',['../struct__cpl__plugin__.html#a908a52f88e83ff76202ff68625649cff',1,'_cpl_plugin_']]],
  ['error_20handling_1',['Error handling',['../group__cpl__error.html',1,'']]],
  ['execute_2',['execute',['../struct__cpl__plugin__.html#a609f914f455c448fcee26938696df624',1,'_cpl_plugin_']]]
];

var searchData=
[
  ['handling_20of_20multiple_20cpl_20errors_0',['Handling of multiple CPL errors',['../group__cpl__errorstate.html',1,'']]],
  ['high_20level_20functions_20for_20geometric_20transformations_1',['High level functions for geometric transformations',['../group__cpl__geom__img.html',1,'']]],
  ['high_20level_20functions_20to_20handle_20apertures_2',['High level functions to handle apertures',['../group__cpl__apertures.html',1,'']]],
  ['high_2dlevel_20functions_20for_20non_2dlinear_20fitting_3',['High-level functions for non-linear fitting',['../group__cpl__fit.html',1,'']]],
  ['high_2dlevel_20functions_20that_20are_20photometry_20related_4',['High-level functions that are photometry related',['../group__cpl__photom.html',1,'']]],
  ['high_2dlevel_20functions_20to_20compute_20detector_20features_5',['High-level functions to compute detector features',['../group__cpl__detector.html',1,'']]]
];

var searchData=
[
  ['i_2fo_0',['I/O',['../group__cpl__io.html',1,'']]],
  ['imagelists_1',['Imagelists',['../group__cpl__imagelist.html',1,'']]],
  ['images_2',['Images',['../group__cpl__image.html',1,'']]],
  ['initialize_3',['initialize',['../struct__cpl__plugin__.html#ab002ac0650e78b33f4dc59aff90fe361',1,'_cpl_plugin_']]],
  ['interface_4',['interface',['../struct__cpl__recipe__.html#a0501a784ca75a0a8af4dedcfc511fb5c',1,'_cpl_recipe_']]]
];

var searchData=
[
  ['library_20initialization_0',['Library Initialization',['../group__cpl__init.html',1,'']]],
  ['library_20version_20information_1',['Library Version Information',['../group__cpl__version.html',1,'']]]
];

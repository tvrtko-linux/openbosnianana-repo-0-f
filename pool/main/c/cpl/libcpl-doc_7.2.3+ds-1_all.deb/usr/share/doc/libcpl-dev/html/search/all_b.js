var searchData=
[
  ['name_0',['name',['../struct__cpl__plugin__.html#a9cae15b2acdb2cbedddb18cead194d83',1,'_cpl_plugin_']]]
];

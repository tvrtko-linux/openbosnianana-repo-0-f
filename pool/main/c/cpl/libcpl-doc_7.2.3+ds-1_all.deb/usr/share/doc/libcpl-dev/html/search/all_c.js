var searchData=
[
  ['parameter_20lists_0',['Parameter Lists',['../group__cpl__parameterlist.html',1,'']]],
  ['parameters_1',['Parameters',['../group__cpl__parameter.html',1,'']]],
  ['parameters_2',['parameters',['../struct__cpl__recipe__.html#a92cc72b42d99943bba4ca2ec5a2a20b2',1,'_cpl_recipe_']]],
  ['plotting_20of_20cpl_20objects_3',['Plotting of CPL objects',['../group__cpl__plot.html',1,'']]],
  ['plugin_20interface_4',['Plugin Interface',['../group__cpl__plugin.html',1,'']]],
  ['plugin_20list_5',['Plugin List',['../group__cpl__pluginlist.html',1,'']]],
  ['point_20pattern_20matching_20module_6',['Point pattern matching module',['../group__cpl__ppm.html',1,'']]],
  ['polynomials_7',['Polynomials',['../group__cpl__polynomial.html',1,'']]],
  ['properties_8',['Properties',['../group__cpl__property.html',1,'']]],
  ['property_20lists_9',['Property Lists',['../group__cpl__propertylist.html',1,'']]]
];

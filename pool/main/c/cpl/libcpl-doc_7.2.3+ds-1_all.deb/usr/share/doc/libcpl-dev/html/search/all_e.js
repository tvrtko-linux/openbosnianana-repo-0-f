var searchData=
[
  ['statistics_0',['Statistics',['../group__cpl__stats.html',1,'']]],
  ['synopsis_1',['synopsis',['../struct__cpl__plugin__.html#ac6cc2a56f06017eb64bd24006f423979',1,'_cpl_plugin_']]]
];

var searchData=
[
  ['_5fcpl_5fframedata_5f_0',['_cpl_framedata_',['../struct__cpl__framedata__.html',1,'']]],
  ['_5fcpl_5fplugin_5f_1',['_cpl_plugin_',['../struct__cpl__plugin__.html',1,'']]],
  ['_5fcpl_5frecipe_5f_2',['_cpl_recipe_',['../struct__cpl__recipe__.html',1,'']]]
];

var searchData=
[
  ['arrays_0',['Arrays',['../group__cpl__array.html',1,'']]],
  ['auxiliary_20frame_20data_1',['Auxiliary Frame Data',['../group__cpl__framedata.html',1,'']]]
];

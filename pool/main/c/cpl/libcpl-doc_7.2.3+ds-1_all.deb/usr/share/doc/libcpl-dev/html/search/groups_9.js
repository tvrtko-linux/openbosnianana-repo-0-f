var searchData=
[
  ['parameter_20lists_0',['Parameter Lists',['../group__cpl__parameterlist.html',1,'']]],
  ['parameters_1',['Parameters',['../group__cpl__parameter.html',1,'']]],
  ['plotting_20of_20cpl_20objects_2',['Plotting of CPL objects',['../group__cpl__plot.html',1,'']]],
  ['plugin_20interface_3',['Plugin Interface',['../group__cpl__plugin.html',1,'']]],
  ['plugin_20list_4',['Plugin List',['../group__cpl__pluginlist.html',1,'']]],
  ['point_20pattern_20matching_20module_5',['Point pattern matching module',['../group__cpl__ppm.html',1,'']]],
  ['polynomials_6',['Polynomials',['../group__cpl__polynomial.html',1,'']]],
  ['properties_7',['Properties',['../group__cpl__property.html',1,'']]],
  ['property_20lists_8',['Property Lists',['../group__cpl__propertylist.html',1,'']]]
];

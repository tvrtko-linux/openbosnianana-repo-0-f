var searchData=
[
  ['statistics_0',['Statistics',['../group__cpl__stats.html',1,'']]]
];

var searchData=
[
  ['copyright_0',['copyright',['../struct__cpl__plugin__.html#a84ac0c13203840bf3bb6aece1a32da44',1,'_cpl_plugin_']]]
];

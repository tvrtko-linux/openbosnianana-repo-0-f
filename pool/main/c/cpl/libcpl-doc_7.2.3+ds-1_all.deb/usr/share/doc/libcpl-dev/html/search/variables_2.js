var searchData=
[
  ['deinitialize_0',['deinitialize',['../struct__cpl__plugin__.html#ac10df7398cc0b9c0d2b629c3317551b8',1,'_cpl_plugin_']]],
  ['description_1',['description',['../struct__cpl__plugin__.html#af0f392cd13aede3e3071f2dd98fd87d5',1,'_cpl_plugin_']]]
];

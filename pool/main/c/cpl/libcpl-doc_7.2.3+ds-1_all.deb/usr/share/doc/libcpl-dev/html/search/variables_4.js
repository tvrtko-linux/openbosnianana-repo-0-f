var searchData=
[
  ['frames_0',['frames',['../struct__cpl__recipe__.html#a0aa1af9cd0d279dee08ab991d6accf3e',1,'_cpl_recipe_']]]
];

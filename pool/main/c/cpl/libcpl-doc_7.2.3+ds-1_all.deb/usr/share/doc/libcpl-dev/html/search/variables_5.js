var searchData=
[
  ['initialize_0',['initialize',['../struct__cpl__plugin__.html#ab002ac0650e78b33f4dc59aff90fe361',1,'_cpl_plugin_']]],
  ['interface_1',['interface',['../struct__cpl__recipe__.html#a0501a784ca75a0a8af4dedcfc511fb5c',1,'_cpl_recipe_']]]
];

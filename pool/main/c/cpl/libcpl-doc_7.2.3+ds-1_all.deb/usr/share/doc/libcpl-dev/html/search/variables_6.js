var searchData=
[
  ['max_5fcount_0',['max_count',['../struct__cpl__framedata__.html#a5be3540e2e15ddb07f662947ee2f3e4a',1,'_cpl_framedata_']]],
  ['min_5fcount_1',['min_count',['../struct__cpl__framedata__.html#a2c7d54c341203106260bbe386ff58d60',1,'_cpl_framedata_']]]
];

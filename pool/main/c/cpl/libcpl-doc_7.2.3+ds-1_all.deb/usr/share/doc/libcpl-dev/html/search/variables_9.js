var searchData=
[
  ['synopsis_0',['synopsis',['../struct__cpl__plugin__.html#ac6cc2a56f06017eb64bd24006f423979',1,'_cpl_plugin_']]]
];

var searchData=
[
  ['version_0',['version',['../struct__cpl__plugin__.html#acb7b61553894cbdc842fa7a17cd45163',1,'_cpl_plugin_']]]
];

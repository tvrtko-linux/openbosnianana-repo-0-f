var searchData=
[
  ['base_0',['base',['../classcpptoml_1_1base.html',1,'cpptoml']]]
];

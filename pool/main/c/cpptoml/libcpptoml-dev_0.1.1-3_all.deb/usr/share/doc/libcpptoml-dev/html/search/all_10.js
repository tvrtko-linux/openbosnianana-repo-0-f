var searchData=
[
  ['zone_5foffset_0',['zone_offset',['../structcpptoml_1_1zone__offset.html',1,'cpptoml']]]
];

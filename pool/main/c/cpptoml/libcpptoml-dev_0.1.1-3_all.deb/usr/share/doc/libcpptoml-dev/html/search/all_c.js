var searchData=
[
  ['reserve_0',['reserve',['../classcpptoml_1_1array.html#a32a2f15d2483e14d0edb0d2d338454f0',1,'cpptoml::array::reserve()'],['../classcpptoml_1_1table__array.html#a8d427ee205fc1dcd640bb0c7a41e2baf',1,'cpptoml::table_array::reserve()']]]
];

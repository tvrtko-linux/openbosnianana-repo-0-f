/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef __ALPHA_SETUP_H
#define __ALPHA_SETUP_H

#define COMMAND_LINE_SIZE	256

#endif /* __ALPHA_SETUP_H */

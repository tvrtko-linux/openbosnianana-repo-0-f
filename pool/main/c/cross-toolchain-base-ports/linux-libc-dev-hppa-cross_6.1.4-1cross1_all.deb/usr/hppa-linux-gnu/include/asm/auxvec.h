/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _PARISC_AUXVEC_H
#define _PARISC_AUXVEC_H

/* The vDSO location. */
#define AT_SYSINFO_EHDR		33

#endif /* _PARISC_AUXVEC_H */

/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _ASM_M68K_UNISTD_H_
#define _ASM_M68K_UNISTD_H_

#include <asm/unistd_32.h>

#endif /* _ASM_M68K_UNISTD_H_ */

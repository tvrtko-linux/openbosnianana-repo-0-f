/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _ASMSPARC_PARAM_H
#define _ASMSPARC_PARAM_H

#define EXEC_PAGESIZE	8192    /* Thanks for sun4's we carry baggage... */
#include <asm-generic/param.h>

#endif /* _ASMSPARC_PARAM_H */

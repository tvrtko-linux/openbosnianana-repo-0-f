/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _ASM_POWERPC_SETUP_H
#define _ASM_POWERPC_SETUP_H

#define COMMAND_LINE_SIZE	2048

#endif /* _ASM_POWERPC_SETUP_H */

// +build linux freebsd netbsd openbsd solaris !windows

package fileacquisition

func trimLine(text string) string {
	return text
}

package csconfig

type PluginCfg struct {
	User  string
	Group string
}

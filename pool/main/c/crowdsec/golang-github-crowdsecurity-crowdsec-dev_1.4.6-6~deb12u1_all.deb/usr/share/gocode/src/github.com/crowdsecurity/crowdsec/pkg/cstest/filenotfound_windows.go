//go:build windows

package cstest

const FileNotFoundMessage = "The system cannot find the file specified."

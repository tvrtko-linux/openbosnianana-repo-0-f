/*
    float-version.h:

    Copyright (C) 1991-2010 Victor Lazzarini

    This file is part of Csound.

    The Csound Library is free software; you can redistribute it
    and/or modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    Csound is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with Csound; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
    02110-1301 USA
*/

/* this file can be copied as float-version.h in installers for double precision
   currently implemented only for OSX
*/

#ifndef FLOAT_VERSION_H
#define FLOAT_VERSION_H

#if !defined(USE_DOUBLE)
#define USE_DOUBLE
#endif

#endif

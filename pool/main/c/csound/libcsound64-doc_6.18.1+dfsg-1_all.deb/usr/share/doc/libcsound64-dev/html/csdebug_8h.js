var csdebug_8h =
[
    [ "breakpoint_cb_t", "group__DEBUGGER.html#gaa5eeed82518aa628ef8abb269e9224ec", null ],
    [ "csdebug_data_t", "group__DEBUGGER.html#gaaf2b2e4007963a423402affeab1ad58d", null ],
    [ "debug_instr_t", "group__DEBUGGER.html#gadb422a1f8df808ff22c9b8d726fc23bf", null ],
    [ "debug_opcode_t", "group__DEBUGGER.html#ga97dd9c4013981519875ad4318e7abce7", null ],
    [ "debug_variable_t", "group__DEBUGGER.html#ga4f83c426b9e5a2a9f70bd11f2145bb0f", null ],
    [ "csoundClearBreakpoints", "group__DEBUGGER.html#ga8aa5fc7d7b05c649d4b185bb75147333", null ],
    [ "csoundDebugContinue", "group__DEBUGGER.html#ga223234004d6ffb823fb42d36aae72c89", null ],
    [ "csoundDebugFreeInstrInstances", "group__DEBUGGER.html#gab361e88bf622d3d2723f935f82818612", null ],
    [ "csoundDebugFreeVariables", "group__DEBUGGER.html#ga9dc55d8b53911c540415771b4a556aa7", null ],
    [ "csoundDebuggerClean", "group__DEBUGGER.html#ga24d1d8d1b8d2e8f9f0389a6e1c2c9eb7", null ],
    [ "csoundDebuggerInit", "group__DEBUGGER.html#gaa54ba2b52c55d6dde7a0b2b3b3382a48", null ],
    [ "csoundDebugGetInstrInstances", "group__DEBUGGER.html#ga0abadf1adea00ca4f15cca463dc984d9", null ],
    [ "csoundDebugGetVariables", "group__DEBUGGER.html#ga59faa0c0b6dac918f90235f714df9293", null ],
    [ "csoundDebugNext", "group__DEBUGGER.html#ga63424e9a56db17bde9aba4cb178bdac2", null ],
    [ "csoundDebugStop", "group__DEBUGGER.html#gadd2e705af10b7606554aa06deed8140f", null ],
    [ "csoundRemoveBreakpoint", "group__DEBUGGER.html#gae9642481db8f23104f42dd50321dfef9", null ],
    [ "csoundRemoveInstrumentBreakpoint", "group__DEBUGGER.html#ga3911db6e7cca51acd05021dcf08fbaeb", null ],
    [ "csoundSetBreakpoint", "group__DEBUGGER.html#gabb0946230553658b21e7a53b8af678cd", null ],
    [ "csoundSetBreakpointCallback", "group__DEBUGGER.html#gae9174a39a24d28d9c8af608a98e8f98f", null ],
    [ "csoundSetInstrumentBreakpoint", "group__DEBUGGER.html#ga70783345b96524d37e5c9dbc168895d6", null ]
];
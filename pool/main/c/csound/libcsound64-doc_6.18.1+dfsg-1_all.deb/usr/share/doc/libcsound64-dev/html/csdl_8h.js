var csdl_8h =
[
    [ "FLINKAGE", "csdl_8h.html#a21d69c1767c237bc1fe7c136273d2cea", null ],
    [ "FLINKAGE_BUILTIN", "csdl_8h.html#a8ac71ae3711f60b4164f339677c74ce0", null ],
    [ "LINKAGE", "csdl_8h.html#ac81000045b9ef2369406deadc84add97", null ],
    [ "LINKAGE_BUILTIN", "csdl_8h.html#abb7ea530af23cb6940acfac233341d4a", null ],
    [ "Str", "csdl_8h.html#a8bbe979a5cb850a7644f2c7938835afb", null ],
    [ "csound_fgen_init", "csdl_8h.html#a970f8618226f5e6f8899969c73019d12", null ],
    [ "csound_opcode_init", "csdl_8h.html#a9c1a38f2c480c1e7c5ef879937d3f7a1", null ],
    [ "csoundModuleCreate", "csdl_8h.html#ab6edc288a069043d50dc6cc3d16eecfc", null ],
    [ "csoundModuleDestroy", "csdl_8h.html#aa57f2edc08e77822a9f940495b5923b0", null ],
    [ "csoundModuleErrorCodeToString", "csdl_8h.html#abdc21ea481f099f2f3e0d46f43a9dbc9", null ],
    [ "csoundModuleInfo", "csdl_8h.html#a386677bd0167c66d35d81eb628bf5585", null ],
    [ "csoundModuleInit", "csdl_8h.html#a08d822fde79ebd7a72016e9025168af5", null ]
];
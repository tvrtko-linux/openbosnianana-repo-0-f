var globals_func =
[
    [ "c", "globals_func.html", null ],
    [ "i", "globals_func_i.html", null ],
    [ "k", "globals_func_k.html", null ]
];
var group__ATTRIBUTES =
[
    [ "csoundGet0dBFS", "group__ATTRIBUTES.html#ga8e6f050848a8308ca5284f9e5eb6c1ad", null ],
    [ "csoundGetA4", "group__ATTRIBUTES.html#gaad8df8f551c982d213a6cbe473abeee0", null ],
    [ "csoundGetCurrentTimeSamples", "group__ATTRIBUTES.html#ga6a8172ddd2ca6cf89023ef0a463b8ab4", null ],
    [ "csoundGetDebug", "group__ATTRIBUTES.html#ga201031fd7beb0ffb11d4fc3b5b37ae2d", null ],
    [ "csoundGetHostData", "group__ATTRIBUTES.html#ga66a46997853cef91511b3957de8e300c", null ],
    [ "csoundGetKr", "group__ATTRIBUTES.html#ga6f0ab2e07abcd8a73e0e3273d85564e5", null ],
    [ "csoundGetKsmps", "group__ATTRIBUTES.html#ga38d9482623e10d30207d5b9bc928b0a2", null ],
    [ "csoundGetNchnls", "group__ATTRIBUTES.html#ga4446579180a66380982ba615de62ecfb", null ],
    [ "csoundGetNchnlsInput", "group__ATTRIBUTES.html#ga6ed9a53a532a642ce380afa3fb26a7f6", null ],
    [ "csoundGetParams", "group__ATTRIBUTES.html#gaf52b8a19c9c84c82ce66f5b6ae676c06", null ],
    [ "csoundGetSizeOfMYFLT", "group__ATTRIBUTES.html#gab27f2ab02ffc66087319e293dc546bc6", null ],
    [ "csoundGetSr", "group__ATTRIBUTES.html#ga634b75f05aae2e85454151c220127e30", null ],
    [ "csoundSetDebug", "group__ATTRIBUTES.html#ga03214879ba89bb894a605bc36636f0c8", null ],
    [ "csoundSetHostData", "group__ATTRIBUTES.html#gae8c2ec4270ec12bc0a52772739baf5b1", null ],
    [ "csoundSetOption", "group__ATTRIBUTES.html#ga332ed5da3d399f0ae039906c380764e1", null ],
    [ "csoundSetParams", "group__ATTRIBUTES.html#ga15cb37340ffddae130ba299e9a44c246", null ],
    [ "csoundSystemSr", "group__ATTRIBUTES.html#gaaf7c40d25c6977ac7a28f66e97cefbd9", null ]
];
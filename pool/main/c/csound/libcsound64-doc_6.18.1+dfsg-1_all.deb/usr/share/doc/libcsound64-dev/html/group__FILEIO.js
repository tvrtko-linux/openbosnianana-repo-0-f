var group__FILEIO =
[
    [ "csoundGetInputName", "group__FILEIO.html#ga23d1b041094a3c044d541a3d21dc59e5", null ],
    [ "csoundGetOutputFormat", "group__FILEIO.html#ga9ede5f7818b2e6f081d700eceb37783c", null ],
    [ "csoundGetOutputName", "group__FILEIO.html#gae6a9274eca55c17bb0587ab5302f2e9e", null ],
    [ "csoundSetFileOpenCallback", "group__FILEIO.html#ga43e4b06800528f897c011f7d5277c7f4", null ],
    [ "csoundSetInput", "group__FILEIO.html#gaca5d4f9b901de39ce91013ff0feb1d6e", null ],
    [ "csoundSetMIDIFileInput", "group__FILEIO.html#gae6211a070c248c1ec71e0404535ac04b", null ],
    [ "csoundSetMIDIFileOutput", "group__FILEIO.html#ga3435bf5fe5ba17d061ac81e23d02fbbc", null ],
    [ "csoundSetMIDIInput", "group__FILEIO.html#ga2bea19de526c797535360ed63ed06612", null ],
    [ "csoundSetMIDIOutput", "group__FILEIO.html#ga446932b051a5da6a1582b4db8c39a837", null ],
    [ "csoundSetOutput", "group__FILEIO.html#gac97f9bc8b7ec83550098c884991bacc3", null ]
];
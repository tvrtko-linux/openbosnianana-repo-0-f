var group__INSTANTIATION =
[
    [ "csoundCreate", "group__INSTANTIATION.html#ga36583daa2cfcdd1fdeca234e76e10908", null ],
    [ "csoundDestroy", "group__INSTANTIATION.html#ga3db5fab38f4509f70f4c4c93001440ee", null ],
    [ "csoundGetAPIVersion", "group__INSTANTIATION.html#ga4f6d949ef2c9adbe2e83baa5adb12117", null ],
    [ "csoundGetVersion", "group__INSTANTIATION.html#ga2a5763300d8baadc84a4e26728b189a3", null ],
    [ "csoundInitialize", "group__INSTANTIATION.html#ga4d8ff494f218225bb5c6226e9c3e7391", null ],
    [ "csoundLoadPlugins", "group__INSTANTIATION.html#gac6e1cbe3727153feb2a416efbb9e7cd5", null ],
    [ "csoundSetOpcodedir", "group__INSTANTIATION.html#ga70a8ef8208525c55a7192aa0e652c203", null ]
];
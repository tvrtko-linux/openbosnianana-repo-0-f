var group__MESSAGES =
[
    [ "csoundCreateMessageBuffer", "group__MESSAGES.html#ga01f4b4e4baabcd74c36500a4d27f776b", null ],
    [ "csoundDestroyMessageBuffer", "group__MESSAGES.html#ga6c2ab1d024e546e94b238c74926eb695", null ],
    [ "csoundGetFirstMessage", "group__MESSAGES.html#gae30069c1ec6a67dff54f54d600d24887", null ],
    [ "csoundGetFirstMessageAttr", "group__MESSAGES.html#gafad971d8390bf55e9ed82c365a19ba41", null ],
    [ "csoundGetMessageCnt", "group__MESSAGES.html#gae41f8a328e628b51b7cf0162fae2418f", null ],
    [ "csoundGetMessageLevel", "group__MESSAGES.html#gacdffd6397bf8925fb4220287a26bbe6c", null ],
    [ "csoundMessage", "group__MESSAGES.html#ga93a4d3cedb7ca27589fdee5abd91c90b", null ],
    [ "csoundMessageS", "group__MESSAGES.html#ga5f83191e7c516e5155e7ba496a172257", null ],
    [ "csoundMessageV", "group__MESSAGES.html#ga91c7aeda335666d257f412a674246c5d", null ],
    [ "csoundPopFirstMessage", "group__MESSAGES.html#ga9875508c467601f58b2dc002f78ffc33", null ],
    [ "csoundSetDefaultMessageCallback", "group__MESSAGES.html#gae6de43c17e614ca311f0965ea87f119e", null ],
    [ "csoundSetMessageCallback", "group__MESSAGES.html#ga45c8cd03e278274966232a12a0297313", null ],
    [ "csoundSetMessageLevel", "group__MESSAGES.html#gac683ad293e19394ef8d184d41ae81f91", null ],
    [ "csoundSetMessageStringCallback", "group__MESSAGES.html#ga1e20463d3345c014739f4fddb7837731", null ]
];
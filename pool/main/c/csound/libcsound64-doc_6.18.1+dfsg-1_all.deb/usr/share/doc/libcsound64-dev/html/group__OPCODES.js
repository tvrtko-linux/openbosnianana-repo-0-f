var group__OPCODES =
[
    [ "csoundAppendOpcode", "group__OPCODES.html#gaafb95461ce0e9b1df4af04da84c5f21e", null ],
    [ "csoundDisposeOpcodeList", "group__OPCODES.html#ga27f98bc9cec01c4833bb8f1df7b79a2d", null ],
    [ "csoundGetNamedGens", "group__OPCODES.html#gae547b79b98c6fa07d84c8f41906b3c43", null ],
    [ "csoundNewOpcodeList", "group__OPCODES.html#ga678c47c3398928769b1284803ce2d0c4", null ]
];
var group__PERFORMANCE =
[
    [ "csoundCleanup", "group__PERFORMANCE.html#ga81289d7daf033349d8b36aa03c528ea4", null ],
    [ "csoundCompile", "group__PERFORMANCE.html#ga92c741a482b072bc503f790bf0824dad", null ],
    [ "csoundCompileArgs", "group__PERFORMANCE.html#gaf22258f98067897341ce56dede89bbbf", null ],
    [ "csoundCompileCsd", "group__PERFORMANCE.html#ga9e438e221a7aa8a942372f01b3c47ffa", null ],
    [ "csoundCompileCsdText", "group__PERFORMANCE.html#ga900a86a46bd4696958da6b9671d317fe", null ],
    [ "csoundCompileOrc", "group__PERFORMANCE.html#ga00fc1c4745b51f3c42819cc77024e39d", null ],
    [ "csoundCompileOrcAsync", "group__PERFORMANCE.html#ga48a82cb1db8dabba5028913e191696f1", null ],
    [ "csoundCompileTree", "group__PERFORMANCE.html#ga22a3fa663f2124479a0733dae0c6542e", null ],
    [ "csoundCompileTreeAsync", "group__PERFORMANCE.html#ga1fb5a7a54760fcbe29639da067d3fa25", null ],
    [ "csoundDeleteTree", "group__PERFORMANCE.html#gadac36c1f003babab78eeee8ae25bb999", null ],
    [ "csoundEvalCode", "group__PERFORMANCE.html#ga50cd39501bafba67115bf91c516cd1b8", null ],
    [ "csoundInitializeCscore", "group__PERFORMANCE.html#ga1f7036a22a2bd1562ad9300782b22f33", null ],
    [ "csoundParseOrc", "group__PERFORMANCE.html#ga0f8e5b9c25e5635d65907a927890f979", null ],
    [ "csoundPerform", "group__PERFORMANCE.html#ga8da8e1173bafb42b6d906ba9af5045cc", null ],
    [ "csoundPerformBuffer", "group__PERFORMANCE.html#ga4abf49ed2317345edd0dae9e1424b51a", null ],
    [ "csoundPerformKsmps", "group__PERFORMANCE.html#ga3db60569a5e320507d6a5fa1f16202eb", null ],
    [ "csoundReset", "group__PERFORMANCE.html#ga2868c337ffcb100b1a4a56cfcc7d47c3", null ],
    [ "csoundStart", "group__PERFORMANCE.html#gad482282dd5197f1683bf5721766b2dec", null ],
    [ "csoundStop", "group__PERFORMANCE.html#gad0cba94589eed67907ccec52ecba6c7e", null ]
];
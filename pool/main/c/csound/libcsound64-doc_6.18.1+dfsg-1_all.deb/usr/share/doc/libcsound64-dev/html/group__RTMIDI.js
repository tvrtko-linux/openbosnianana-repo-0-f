var group__RTMIDI =
[
    [ "csoundGetMIDIDevList", "group__RTMIDI.html#ga32a52ca9e89256d9ccf54e0fef2c0ee7", null ],
    [ "csoundSetExternalMidiErrorStringCallback", "group__RTMIDI.html#gaa3b0121fcde6827bed67819377160c5c", null ],
    [ "csoundSetExternalMidiInCloseCallback", "group__RTMIDI.html#ga92f73aeeea26ace4a791b7e8da760046", null ],
    [ "csoundSetExternalMidiInOpenCallback", "group__RTMIDI.html#ga71afda1ac30f8e88679a1fdd05f7cf9e", null ],
    [ "csoundSetExternalMidiOutCloseCallback", "group__RTMIDI.html#ga3c23abaa9a52ca36ba425f8ffac5d915", null ],
    [ "csoundSetExternalMidiOutOpenCallback", "group__RTMIDI.html#gabff1ace3ec1a4ecd242d4d8bb7e59632", null ],
    [ "csoundSetExternalMidiReadCallback", "group__RTMIDI.html#ga62809d91727997fb5563d259633d9328", null ],
    [ "csoundSetExternalMidiWriteCallback", "group__RTMIDI.html#gabc34caedf0b15ca2066a1d1729f423c8", null ],
    [ "csoundSetHostImplementedMIDIIO", "group__RTMIDI.html#ga9b00b0b62db38e50e484cbc8557d96de", null ],
    [ "csoundSetMIDIDeviceListCallback", "group__RTMIDI.html#gae81c8e5a861e44c3fbf277c891f1008a", null ],
    [ "csoundSetMIDIModule", "group__RTMIDI.html#gab8b56761790ac3709c732845c1af5482", null ]
];
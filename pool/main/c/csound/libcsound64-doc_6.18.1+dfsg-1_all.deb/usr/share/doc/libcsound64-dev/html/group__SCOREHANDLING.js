var group__SCOREHANDLING =
[
    [ "csoundGetScoreOffsetSeconds", "group__SCOREHANDLING.html#ga56b0d6c5f7c00a1a0699c83455316d49", null ],
    [ "csoundGetScoreTime", "group__SCOREHANDLING.html#ga2075a2a3f148ec7cb0005324dde4dc1d", null ],
    [ "csoundIsScorePending", "group__SCOREHANDLING.html#gaef3946c59976df1c898e223c27ebfe23", null ],
    [ "csoundReadScore", "group__SCOREHANDLING.html#gaf338f7ddfdcac8ccb50cbe09e12e5fb7", null ],
    [ "csoundReadScoreAsync", "group__SCOREHANDLING.html#gae056a4cf8746f8c2ccdc30c6e2c33a3e", null ],
    [ "csoundRewindScore", "group__SCOREHANDLING.html#gae7f2e103da713c4546cd73c5bc35e6d0", null ],
    [ "csoundScoreExtract", "group__SCOREHANDLING.html#gabc691c9d579523a338f5d7796dbcd94d", null ],
    [ "csoundScoreSort", "group__SCOREHANDLING.html#gab9f668b7070e509b0cd3fd4670aa4322", null ],
    [ "csoundSetCscoreCallback", "group__SCOREHANDLING.html#ga0cfcb4facb909565e1c5214644da63ec", null ],
    [ "csoundSetScoreOffsetSeconds", "group__SCOREHANDLING.html#ga1c8554ce1bd38762fb05d2a879dd722a", null ],
    [ "csoundSetScorePending", "group__SCOREHANDLING.html#gab095323295515a9f284106e1473da577", null ]
];
var group__SERVER =
[
    [ "csoundStopUDPConsole", "group__SERVER.html#ga7a57d72af6f104d58cb250e0abc3da3b", null ],
    [ "csoundUDPConsole", "group__SERVER.html#gafbff1ba985f0eae4835cb33aa1875a01", null ],
    [ "csoundUDPServerClose", "group__SERVER.html#ga359a508d32bfbbc2411ca5e8306cc2ec", null ],
    [ "csoundUDPServerStart", "group__SERVER.html#ga6f4b146ca12e860fa848905a0c33e977", null ],
    [ "csoundUDPServerStatus", "group__SERVER.html#gaf806fc30304527c65598e86148757a66", null ]
];
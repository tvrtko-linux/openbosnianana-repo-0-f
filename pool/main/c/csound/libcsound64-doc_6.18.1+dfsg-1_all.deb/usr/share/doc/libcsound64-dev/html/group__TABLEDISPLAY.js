var group__TABLEDISPLAY =
[
    [ "csoundSetDrawGraphCallback", "group__TABLEDISPLAY.html#ga0480469bee231d552fadd0ab4a3d4f62", null ],
    [ "csoundSetExitGraphCallback", "group__TABLEDISPLAY.html#ga4e0d0c44338ad6ffdd8df3c946af217c", null ],
    [ "csoundSetIsGraphable", "group__TABLEDISPLAY.html#ga7cf6342b496cc1744515cae35f699584", null ],
    [ "csoundSetKillGraphCallback", "group__TABLEDISPLAY.html#ga918e04be88bb7bb6504452e29f55c2f9", null ],
    [ "csoundSetMakeGraphCallback", "group__TABLEDISPLAY.html#ga65c45679f436c261ba2d6ebc757b6963", null ]
];
var searchData=
[
  ['_5falloc_5fdata_5f_0',['_alloc_data_',['../struct__alloc__data__.html',1,'']]],
  ['_5ffft_5fsetup_1',['_FFT_SETUP',['../struct__FFT__SETUP.html',1,'']]],
  ['_5fmessage_5fqueue_5ft_5f_2',['_message_queue_t_',['../struct__message__queue__t__.html',1,'']]],
  ['_5fmm_5fdenormals_5fzero_5fmask_3',['_MM_DENORMALS_ZERO_MASK',['../csoundCore_8h.html#ae14d8bd09ddd9b380262a070b108e8da',1,'csoundCore.h']]],
  ['_5fmm_5fdenormals_5fzero_5foff_4',['_MM_DENORMALS_ZERO_OFF',['../csoundCore_8h.html#a3fe511b122f7320f24e1817e8924af9c',1,'csoundCore.h']]],
  ['_5fmm_5fdenormals_5fzero_5fon_5',['_MM_DENORMALS_ZERO_ON',['../csoundCore_8h.html#a5d16bacd654fa152bc169454f065d4ba',1,'csoundCore.h']]],
  ['_5fmm_5fset_5fdenormals_5fzero_5fmode_6',['_MM_SET_DENORMALS_ZERO_MODE',['../csoundCore_8h.html#a8a0c716610df0edd3bd62369c073e557',1,'csoundCore.h']]],
  ['_5fsystem_5fsr_7',['_system_sr',['../structCSOUND__.html#aec14b1fd11034ed3dbaaf1edef35a29b',1,'CSOUND_']]]
];

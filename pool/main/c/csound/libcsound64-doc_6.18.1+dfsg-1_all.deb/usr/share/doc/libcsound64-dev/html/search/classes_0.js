var searchData=
[
  ['_5falloc_5fdata_5f_0',['_alloc_data_',['../struct__alloc__data__.html',1,'']]],
  ['_5ffft_5fsetup_1',['_FFT_SETUP',['../struct__FFT__SETUP.html',1,'']]],
  ['_5fmessage_5fqueue_5ft_5f_2',['_message_queue_t_',['../struct__message__queue__t__.html',1,'']]]
];

var searchData=
[
  ['gen01args_0',['GEN01ARGS',['../structGEN01ARGS.html',1,'']]]
];

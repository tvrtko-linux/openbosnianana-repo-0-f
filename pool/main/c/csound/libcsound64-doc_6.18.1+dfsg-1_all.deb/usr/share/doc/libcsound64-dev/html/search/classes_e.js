var searchData=
[
  ['sndmemfile_5f_0',['SNDMEMFILE_',['../structSNDMEMFILE__.html',1,'']]],
  ['specdat_1',['SPECDAT',['../structSPECDAT.html',1,'']]],
  ['sread_5f_5f_2',['sread__',['../structCSOUND___1_1sread____.html',1,'CSOUND_']]],
  ['stringdat_3',['STRINGDAT',['../structSTRINGDAT.html',1,'']]]
];

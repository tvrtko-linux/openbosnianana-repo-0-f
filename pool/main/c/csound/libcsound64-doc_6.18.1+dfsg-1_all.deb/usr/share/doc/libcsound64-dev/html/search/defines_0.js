var searchData=
[
  ['_5fmm_5fdenormals_5fzero_5fmask_0',['_MM_DENORMALS_ZERO_MASK',['../csoundCore_8h.html#ae14d8bd09ddd9b380262a070b108e8da',1,'csoundCore.h']]],
  ['_5fmm_5fdenormals_5fzero_5foff_1',['_MM_DENORMALS_ZERO_OFF',['../csoundCore_8h.html#a3fe511b122f7320f24e1817e8924af9c',1,'csoundCore.h']]],
  ['_5fmm_5fdenormals_5fzero_5fon_2',['_MM_DENORMALS_ZERO_ON',['../csoundCore_8h.html#a5d16bacd654fa152bc169454f065d4ba',1,'csoundCore.h']]],
  ['_5fmm_5fset_5fdenormals_5fzero_5fmode_3',['_MM_SET_DENORMALS_ZERO_MODE',['../csoundCore_8h.html#a8a0c716610df0edd3bd62369c073e557',1,'csoundCore.h']]]
];

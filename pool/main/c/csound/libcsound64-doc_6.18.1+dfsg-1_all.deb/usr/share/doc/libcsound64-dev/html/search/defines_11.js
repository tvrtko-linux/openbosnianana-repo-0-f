var searchData=
[
  ['useropcode_0',['USEROPCODE',['../csoundCore_8h.html#a2d8650dab24aba3bc7da8184217e27da',1,'csoundCore.h']]]
];

var searchData=
[
  ['bytrevl_0',['BYTREVL',['../csoundCore_8h.html#a3667298ac314ef39a327a9a8c36e831b',1,'csoundCore.h']]],
  ['bytrevs_1',['BYTREVS',['../csoundCore_8h.html#a3c3d19c3f0343d018f73431483c707b7',1,'csoundCore.h']]]
];

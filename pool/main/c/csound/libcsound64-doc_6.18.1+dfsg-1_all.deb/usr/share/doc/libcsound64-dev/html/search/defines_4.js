var searchData=
[
  ['dflt_5fdbfs_0',['DFLT_DBFS',['../csoundCore_8h.html#ad905f100080b024cdc449c50ebf0ac2e',1,'csoundCore.h']]],
  ['dflt_5fkr_1',['DFLT_KR',['../csoundCore_8h.html#a728eb9142b0a4329687447cfb36939bc',1,'csoundCore.h']]],
  ['dflt_5fksmps_2',['DFLT_KSMPS',['../csoundCore_8h.html#a1764b501a5520c7a60421da61ef4036b',1,'csoundCore.h']]],
  ['dflt_5fnchnls_3',['DFLT_NCHNLS',['../csoundCore_8h.html#ae85555f2bbeddc3cf646002db8853e27',1,'csoundCore.h']]],
  ['dflt_5fsr_4',['DFLT_SR',['../csoundCore_8h.html#ac7d8514db0eef7b5936691ca9873612c',1,'csoundCore.h']]],
  ['dv32768_5',['DV32768',['../csoundCore_8h.html#adeeecf7a30a0efb9cee7eabc2ca7e6d1',1,'csoundCore.h']]]
];

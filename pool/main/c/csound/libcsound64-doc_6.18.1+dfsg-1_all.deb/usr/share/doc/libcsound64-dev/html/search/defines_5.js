var searchData=
[
  ['endin_0',['ENDIN',['../csoundCore_8h.html#aa97d83d75577cad84f8e2a4892207f72',1,'csoundCore.h']]],
  ['endop_1',['ENDOP',['../csoundCore_8h.html#a5d5fb12db6e5977c3ee6f70b93faaed2',1,'csoundCore.h']]]
];

var searchData=
[
  ['namelen_0',['NAMELEN',['../csoundCore_8h.html#a4411eb14f1a528142d32a8132e6d326c',1,'csoundCore.h']]],
  ['not_5fan_5finstrument_1',['NOT_AN_INSTRUMENT',['../csoundCore_8h.html#ad1226095360e6b81700c228c3c386bd5',1,'csoundCore.h']]],
  ['notok_2',['NOTOK',['../csoundCore_8h.html#a02812505694442b6f833040489d550d6',1,'csoundCore.h']]]
];

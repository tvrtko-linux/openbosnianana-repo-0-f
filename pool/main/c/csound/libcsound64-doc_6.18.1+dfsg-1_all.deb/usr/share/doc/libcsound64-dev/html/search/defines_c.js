var searchData=
[
  ['octres_0',['OCTRES',['../csoundCore_8h.html#ac23e4ef46d6c92a56a7c91035630428a',1,'csoundCore.h']]],
  ['ok_1',['OK',['../csoundCore_8h.html#aba51915c87d64af47fb1cc59348961c9',1,'csoundCore.h']]],
  ['onept_2',['ONEPT',['../csoundCore_8h.html#aed224fedfee1a6d3dea89b0e96f943bc',1,'csoundCore.h']]],
  ['opcode_3',['OPCODE',['../csoundCore_8h.html#abb0ffe51f3d9eb582eca011b61ba76fb',1,'csoundCore.h']]],
  ['opcodenumouts_5fhigh_4',['OPCODENUMOUTS_HIGH',['../csoundCore_8h.html#a038e98dae6a2b7d3912a50608fd9c51f',1,'csoundCore.h']]],
  ['opcodenumouts_5flow_5',['OPCODENUMOUTS_LOW',['../csoundCore_8h.html#a19be339232b6b7ce9131f0be84580546',1,'csoundCore.h']]],
  ['opcodenumouts_5fmax_6',['OPCODENUMOUTS_MAX',['../csoundCore_8h.html#a71711ed5a476ff9b73da0fea7e7b6650',1,'csoundCore.h']]],
  ['ortxt_7',['ORTXT',['../csoundCore_8h.html#ac391ca73ecd59d18452b8fce46f51ba6',1,'csoundCore.h']]],
  ['outcount_8',['OUTCOUNT',['../csoundCore_8h.html#af4dc424624a777f5efeac3c103e851ab',1,'csoundCore.h']]],
  ['outocount_9',['OUTOCOUNT',['../csoundCore_8h.html#a7098b3ebea1591ac296ff2d07b93d260',1,'csoundCore.h']]]
];

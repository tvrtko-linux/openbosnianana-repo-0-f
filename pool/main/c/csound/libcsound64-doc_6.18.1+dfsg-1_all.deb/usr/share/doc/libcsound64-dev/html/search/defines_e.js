var searchData=
[
  ['root2_0',['ROOT2',['../csoundCore_8h.html#a5ad3e7aa8c959da6685a19d86c5f01a0',1,'csoundCore.h']]],
  ['rptdepth_1',['RPTDEPTH',['../csoundCore_8h.html#ab4fc45666932f3cb60ce3fa018677abb',1,'csoundCore.h']]]
];

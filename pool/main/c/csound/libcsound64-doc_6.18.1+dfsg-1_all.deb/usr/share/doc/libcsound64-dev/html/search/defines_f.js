var searchData=
[
  ['setbeg_0',['SETBEG',['../csoundCore_8h.html#ac6e2d4ca3234e0f237dccedd37f0f45f',1,'csoundCore.h']]],
  ['setend_1',['SETEND',['../csoundCore_8h.html#a9fe358cf6ab6a988722c03dfc5a88700',1,'csoundCore.h']]],
  ['sstrcod_2',['SSTRCOD',['../csoundCore_8h.html#a902cba78c62226f2f9edf857ce144dfc',1,'csoundCore.h']]],
  ['sstrsiz_3',['SSTRSIZ',['../csoundCore_8h.html#ae42dc792f6d3678a2c0b33dee1293947',1,'csoundCore.h']]],
  ['str_4',['Str',['../csdl_8h.html#a8bbe979a5cb850a7644f2c7938835afb',1,'csdl.h']]]
];

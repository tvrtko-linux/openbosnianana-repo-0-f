var searchData=
[
  ['vdsp_5flib_0',['VDSP_LIB',['../csoundCore_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba069469b3e14aedc80b408da8efbf9b4d',1,'csoundCore.h']]]
];

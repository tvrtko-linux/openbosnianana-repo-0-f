var searchData=
[
  ['kperf_5fdebug_0',['kperf_debug',['../csoundCore_8h.html#adcf55c6f5072a2e64ae02a5b39946555',1,'csoundCore.h']]],
  ['kperf_5fnodebug_1',['kperf_nodebug',['../csoundCore_8h.html#a9afe925291a89ccd1aaaa4fb7230d711',1,'csoundCore.h']]]
];

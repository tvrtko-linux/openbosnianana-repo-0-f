var searchData=
[
  ['messages_20and_20text_0',['Messages and Text',['../group__MESSAGES.html',1,'']]],
  ['miscellaneous_20functions_1',['Miscellaneous functions',['../group__MISCELLANEOUS.html',1,'']]]
];

var searchData=
[
  ['realtime_20audio_20i_2fo_0',['Realtime Audio I/O',['../group__RTAUDIOIO.html',1,'']]],
  ['realtime_20midi_20i_2fo_1',['Realtime Midi I/O',['../group__RTMIDI.html',1,'']]]
];

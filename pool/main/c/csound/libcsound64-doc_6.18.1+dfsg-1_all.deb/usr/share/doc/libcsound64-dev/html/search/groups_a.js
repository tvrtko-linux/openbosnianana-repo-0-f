var searchData=
[
  ['score_20handling_0',['Score Handling',['../group__SCOREHANDLING.html',1,'']]]
];

var searchData=
[
  ['windat_0',['WINDAT',['../csound_8h.html#ad4da36207b17fd237cafbe4d9cdd1797',1,'csound.h']]]
];

var searchData=
[
  ['xyindat_0',['XYINDAT',['../csound_8h.html#ada85e8fcb2bcfa4cf3d8c299ef133499',1,'csound.h']]]
];

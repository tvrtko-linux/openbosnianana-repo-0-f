var searchData=
[
  ['debug_5finstr_5ft_0',['debug_instr_t',['../group__DEBUGGER.html#gadb422a1f8df808ff22c9b8d726fc23bf',1,'csdebug.h']]],
  ['debug_5fopcode_5ft_1',['debug_opcode_t',['../group__DEBUGGER.html#ga97dd9c4013981519875ad4318e7abce7',1,'csdebug.h']]],
  ['debug_5fvariable_5ft_2',['debug_variable_t',['../group__DEBUGGER.html#ga4f83c426b9e5a2a9f70bd11f2145bb0f',1,'csdebug.h']]],
  ['dklst_3',['DKLST',['../csoundCore_8h.html#a839bb7a630aab049e94f9cd47defbae5',1,'csoundCore.h']]]
];

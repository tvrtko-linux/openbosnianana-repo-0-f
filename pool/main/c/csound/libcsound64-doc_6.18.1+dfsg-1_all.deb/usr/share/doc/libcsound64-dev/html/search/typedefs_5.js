var searchData=
[
  ['fdch_0',['FDCH',['../csoundCore_8h.html#ae8398716d61c07c3af787ea01e29550a',1,'csoundCore.h']]]
];

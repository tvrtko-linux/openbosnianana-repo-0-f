var searchData=
[
  ['gen_0',['GEN',['../csoundCore_8h.html#ad3f1feb1b363bb2700e9bd201542e3d3',1,'csoundCore.h']]]
];

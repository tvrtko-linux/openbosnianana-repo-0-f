var searchData=
[
  ['in_5fstack_0',['IN_STACK',['../csoundCore_8h.html#aca32fb2721c49182d13061ae495a3f6e',1,'csoundCore.h']]],
  ['insds_1',['INSDS',['../csoundCore_8h.html#a2147523872d4a2e63ec77e18a24a0062',1,'csoundCore.h']]],
  ['instrname_2',['INSTRNAME',['../csoundCore_8h.html#afce5b9b59d70c3b512bba07e669bcd33',1,'csoundCore.h']]],
  ['instrtxt_3',['INSTRTXT',['../csoundCore_8h.html#a88209ced00539aa8bdfd7c07eebd4e24',1,'csoundCore.h']]]
];

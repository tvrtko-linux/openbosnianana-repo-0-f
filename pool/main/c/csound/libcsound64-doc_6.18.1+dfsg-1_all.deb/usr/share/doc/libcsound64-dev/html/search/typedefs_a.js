var searchData=
[
  ['name_0',['NAME',['../csoundCore_8h.html#a5d9f334d25f696c60ba91b4d9e2bae04',1,'csoundCore.h']]],
  ['namelst_1',['NAMELST',['../csoundCore_8h.html#af47c587c997816fd2e10f9856b4f915a',1,'csoundCore.h']]],
  ['names_2',['NAMES',['../csoundCore_8h.html#a5ca7e59ff22f491e5d4c6cdc4d161035',1,'csoundCore.h']]]
];

var searchData=
[
  ['oentry_0',['OENTRY',['../csoundCore_8h.html#ad6dea89dd1d6c608429e84d620c2d73e',1,'csoundCore.h']]],
  ['opcodinfo_1',['OPCODINFO',['../csoundCore_8h.html#a061afc7522cbf37dffa20cb97a507c19',1,'csoundCore.h']]],
  ['opds_2',['OPDS',['../csoundCore_8h.html#ab1901ddc474fd4114fa726f8f910e12c',1,'csoundCore.h']]],
  ['optxt_3',['OPTXT',['../csoundCore_8h.html#addb7bf858df11d2335c2257f454eac77',1,'csoundCore.h']]],
  ['orctoken_4',['ORCTOKEN',['../csound_8h.html#a0daba6ece0411d8b03cb4e26420b3837',1,'csound.h']]]
];

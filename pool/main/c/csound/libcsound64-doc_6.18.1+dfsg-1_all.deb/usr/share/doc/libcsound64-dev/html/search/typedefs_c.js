var searchData=
[
  ['pvocex_5fmemfile_0',['PVOCEX_MEMFILE',['../csoundCore_8h.html#a1b2b7d5e2afef10ce4d92bcc2cbe14f8',1,'csoundCore.h']]],
  ['pvsdatext_1',['PVSDATEXT',['../csound_8h.html#a1f6e86bd5deea4efe46794a09adb9120',1,'csound.h']]]
];

var searchData=
[
  ['sndmemfile_0',['SNDMEMFILE',['../csoundCore_8h.html#a4c4a965896f76424a470876308e738a9',1,'csoundCore.h']]],
  ['subr_1',['SUBR',['../csoundCore_8h.html#af58d1f61421f92a5ca1de8edd26a7815',1,'csoundCore.h']]]
];

var searchData=
[
  ['text_0',['TEXT',['../csoundCore_8h.html#a61c7347ef13c5aba72bb5dc519d0aa60',1,'csoundCore.h']]],
  ['threadinfo_1',['THREADINFO',['../csoundCore_8h.html#a338758f744d96c6953aedbf1a6b17436',1,'csoundCore.h']]],
  ['tree_2',['TREE',['../csound_8h.html#ad9fca774bd0672055a10e6ea808ac3b0',1,'csound.h']]]
];

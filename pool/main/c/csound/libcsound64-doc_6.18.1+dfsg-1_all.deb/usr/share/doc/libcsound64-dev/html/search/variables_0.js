var searchData=
[
  ['_5fsystem_5fsr_0',['_system_sr',['../structCSOUND__.html#aec14b1fd11034ed3dbaaf1edef35a29b',1,'CSOUND_']]]
];

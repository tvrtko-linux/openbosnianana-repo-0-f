var searchData=
[
  ['x_0',['x',['../structcontrolChannelHints__s.html#a112fec53a9875dc010c686e3bc4703aa',1,'controlChannelHints_s']]],
  ['xfilename_1',['xfilename',['../structCSOUND__.html#a55d988e33933213d8b01474c17f80390',1,'CSOUND_']]],
  ['xtratim_2',['xtratim',['../structinsds.html#a7b03f85415cb7d091ea090f53041d0b5',1,'insds']]]
];

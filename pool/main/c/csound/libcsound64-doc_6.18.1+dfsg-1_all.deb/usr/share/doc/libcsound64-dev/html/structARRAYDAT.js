var structARRAYDAT =
[
    [ "allocated", "structARRAYDAT.html#abfd4b9bbc5208d3f5bbe0f34cfa007aa", null ],
    [ "arrayMemberSize", "structARRAYDAT.html#a7ba93e2484ee3d3a3040e50f2c662ad8", null ],
    [ "arrayType", "structARRAYDAT.html#ab2d13dc3869dfbf0d6a10eb290a9fd49", null ],
    [ "data", "structARRAYDAT.html#a4e47537059c6e076d42a55742bbfc484", null ],
    [ "dimensions", "structARRAYDAT.html#abbcd165d47bdda0c6592b29bd564bdf8", null ],
    [ "sizes", "structARRAYDAT.html#a9bad93c35447bfd960e92a83fd7e75f0", null ]
];
var structAUXASYNC =
[
    [ "auxchp", "structAUXASYNC.html#a163a5911740a8c623effa49ab3bd2884", null ],
    [ "csound", "structAUXASYNC.html#ac2e06ccff8b9c437cb88f39d7d51b881", null ],
    [ "nbytes", "structAUXASYNC.html#ac48c994837f82ad5e18e848b628e00a2", null ],
    [ "notify", "structAUXASYNC.html#ac07593f14ce4b2482d27c132fc121365", null ],
    [ "userData", "structAUXASYNC.html#a4c5b9bd37690eda6554c8e2f4940d204", null ]
];
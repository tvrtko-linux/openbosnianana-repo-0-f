var structCORFIL =
[
    [ "body", "structCORFIL.html#a3cc958dcfa8b2d37ebb4fb749d50951f", null ],
    [ "len", "structCORFIL.html#a5eb8f64a2126eee18517a5b5a222e5a9", null ],
    [ "p", "structCORFIL.html#a67958d0b608edb555b2882aba54c5317", null ]
];
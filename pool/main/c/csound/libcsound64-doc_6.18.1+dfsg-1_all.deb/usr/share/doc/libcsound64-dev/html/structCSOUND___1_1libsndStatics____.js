var structCSOUND___1_1libsndStatics____ =
[
    [ "dither", "structCSOUND___1_1libsndStatics____.html#a13d4e73b2d835de2ed462ba2343ee4db", null ],
    [ "inbuf", "structCSOUND___1_1libsndStatics____.html#acc41ee162c2b98b92c3889099f08d8ad", null ],
    [ "inbufrem", "structCSOUND___1_1libsndStatics____.html#a6a211f5a0e02e5f0dfeccc59f2835ed6", null ],
    [ "inbufsiz", "structCSOUND___1_1libsndStatics____.html#a3e4231ab687b982a6e02b5dce139e5d1", null ],
    [ "infile", "structCSOUND___1_1libsndStatics____.html#a5d23efa755750a14a344695ce7132c47", null ],
    [ "isfopen", "structCSOUND___1_1libsndStatics____.html#a6135f4b5c7d56f9db0761eeea4ee7832", null ],
    [ "nframes", "structCSOUND___1_1libsndStatics____.html#acf2a70f95b314d595bfdd89f11673fd6", null ],
    [ "osfopen", "structCSOUND___1_1libsndStatics____.html#a3c0d8b985f17c85e67bca468c1faa09a", null ],
    [ "outbuf", "structCSOUND___1_1libsndStatics____.html#a357d74f47114f31aac5f2d8a4bfad743", null ],
    [ "outbufp", "structCSOUND___1_1libsndStatics____.html#a8ddaf66e6eae3002f0ba4dba256be12b", null ],
    [ "outbufrem", "structCSOUND___1_1libsndStatics____.html#af631d53740eaf05852a3b469e5c2e329", null ],
    [ "outbufsiz", "structCSOUND___1_1libsndStatics____.html#a632e04fe1be2a304d7bfb9f925dab873", null ],
    [ "outfile", "structCSOUND___1_1libsndStatics____.html#aa430cb0e24598f3f9ec4ccd1bc6479aa", null ],
    [ "pin", "structCSOUND___1_1libsndStatics____.html#a1ced7b672439b2052594ba0fc27ddbea", null ],
    [ "pipdevin", "structCSOUND___1_1libsndStatics____.html#a71c0ecda022d709a29232dac02656694", null ],
    [ "pipdevout", "structCSOUND___1_1libsndStatics____.html#a526655e627776194f4756fd43de68046", null ],
    [ "pout", "structCSOUND___1_1libsndStatics____.html#a6e73ef753384202899c77d290b611e25", null ],
    [ "sfoutname", "structCSOUND___1_1libsndStatics____.html#ac6ee399d6a36f331d8e32c69ba2cc0a0", null ]
];
var structCSOUND___1_1lineventStatics____ =
[
    [ "Linebuf", "structCSOUND___1_1lineventStatics____.html#a1dc971db666885cd1af61ae37c3e14a0", null ],
    [ "Linebufend", "structCSOUND___1_1lineventStatics____.html#ab04258f56631192ea2f9e5b75cce8899", null ],
    [ "linebufsiz", "structCSOUND___1_1lineventStatics____.html#a482681cc4045553d087e6f4918179bfd", null ],
    [ "Linep", "structCSOUND___1_1lineventStatics____.html#a77ba2d74533d6b651c364319ac6d4414", null ],
    [ "oflag", "structCSOUND___1_1lineventStatics____.html#a32e79b1057d97585e421eec742a0e1a4", null ],
    [ "orchestra", "structCSOUND___1_1lineventStatics____.html#a28899cecbbf4594005d1876a8eb2d321", null ],
    [ "orchestrab", "structCSOUND___1_1lineventStatics____.html#af6896888beadb6f313531b5c545926c1", null ],
    [ "prve", "structCSOUND___1_1lineventStatics____.html#a336f4ba7f56604f0ab2f87935fe8eab4", null ],
    [ "stdmode", "structCSOUND___1_1lineventStatics____.html#ad05deeae3612ee8de5ef9a235210d11a", null ]
];
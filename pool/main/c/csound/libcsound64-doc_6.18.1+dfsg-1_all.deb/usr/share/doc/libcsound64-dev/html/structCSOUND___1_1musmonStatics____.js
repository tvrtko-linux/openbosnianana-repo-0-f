var structCSOUND___1_1musmonStatics____ =
[
    [ "ep", "structCSOUND___1_1musmonStatics____.html#ad59edbe97593f2d5ae00d1f7a54a6624", null ],
    [ "epend", "structCSOUND___1_1musmonStatics____.html#abb455832315f758d9dabea2a11f100fd", null ],
    [ "lplayed", "structCSOUND___1_1musmonStatics____.html#afd3f06ca8479f3562e5458c976e45c1f", null ],
    [ "lsect", "structCSOUND___1_1musmonStatics____.html#aed25543d9aac788ad09c2d8e7f8a15ba", null ],
    [ "orngcnt", "structCSOUND___1_1musmonStatics____.html#abc6f01860fd3db33b153e00f88ac75f8", null ],
    [ "sectno", "structCSOUND___1_1musmonStatics____.html#a0b408c8d3b813b8bf3183651482da436", null ],
    [ "segamps", "structCSOUND___1_1musmonStatics____.html#a9c0eaa5f1adabc2e4c1af84135afbbed", null ],
    [ "sormsg", "structCSOUND___1_1musmonStatics____.html#abeb0b565aa2852296ccfe55707917312", null ],
    [ "srngcnt", "structCSOUND___1_1musmonStatics____.html#ab2d1a90c9e120af1c8b50c1bf994ec7f", null ],
    [ "srngflg", "structCSOUND___1_1musmonStatics____.html#a30d4bf2f7a02d98a7356ebcb09316457", null ]
];
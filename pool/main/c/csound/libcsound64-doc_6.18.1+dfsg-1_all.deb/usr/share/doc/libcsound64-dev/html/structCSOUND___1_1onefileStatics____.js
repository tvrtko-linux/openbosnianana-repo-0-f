var structCSOUND___1_1onefileStatics____ =
[
    [ "csdlinecount", "structCSOUND___1_1onefileStatics____.html#a88da8609c17cf972fdeb7f410613233b", null ],
    [ "midiSet", "structCSOUND___1_1onefileStatics____.html#a26483b08359fea52812d4ca9e06a8dd5", null ],
    [ "midname", "structCSOUND___1_1onefileStatics____.html#a85e60a1408803a47230ec9ace8589aed", null ],
    [ "orcname", "structCSOUND___1_1onefileStatics____.html#a58da2b19df295b0a8feb15c38607ab1c", null ],
    [ "sconame", "structCSOUND___1_1onefileStatics____.html#afdd2ca54070602150a636606451767e2", null ],
    [ "toremove", "structCSOUND___1_1onefileStatics____.html#a4e6dfa6ecfb80ec34f732307b9ebd081", null ]
];
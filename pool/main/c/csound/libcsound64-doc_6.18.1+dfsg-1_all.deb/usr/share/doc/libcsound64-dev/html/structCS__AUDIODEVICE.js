var structCS__AUDIODEVICE =
[
    [ "device_id", "structCS__AUDIODEVICE.html#a1b7dc01fae7ec2b75614d6345c3e7b7d", null ],
    [ "device_name", "structCS__AUDIODEVICE.html#ae1e7ae77117f6a9ddb06076a9beeda63", null ],
    [ "isOutput", "structCS__AUDIODEVICE.html#abe34361d001528d150f4c5976d195d41", null ],
    [ "max_nchnls", "structCS__AUDIODEVICE.html#ad290a89b60a4119d913ca98b765e3a2c", null ],
    [ "rt_module", "structCS__AUDIODEVICE.html#a4b8c9de97c92a047db42c6ba35a6da70", null ]
];
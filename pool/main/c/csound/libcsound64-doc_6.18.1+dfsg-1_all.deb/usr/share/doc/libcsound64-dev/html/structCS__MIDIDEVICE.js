var structCS__MIDIDEVICE =
[
    [ "device_id", "structCS__MIDIDEVICE.html#a34a9f229417ef0c9fcc38a667796a87a", null ],
    [ "device_name", "structCS__MIDIDEVICE.html#ad40136cac24b722815db92707db2a677", null ],
    [ "interface_name", "structCS__MIDIDEVICE.html#ae9b6e0662dbc502497fd079b0c6d3f10", null ],
    [ "isOutput", "structCS__MIDIDEVICE.html#a9b172a002d5bdb5a63b9252604446e74", null ],
    [ "midi_module", "structCS__MIDIDEVICE.html#a5a03bd5fc831fb92e8c6f11bb155f83b", null ]
];
var structCsoundEvent =
[
    [ "~CsoundEvent", "structCsoundEvent.html#a733a6a64a9c4c460e8eb0a68beabe12b", null ],
    [ "operator()", "structCsoundEvent.html#a37d1967ff86af31eee09b29743465600", null ]
];
var structCsoundRandMTState__ =
[
    [ "mt", "structCsoundRandMTState__.html#a14e25268d85745cd659ffbc115c44d46", null ],
    [ "mti", "structCsoundRandMTState__.html#a6b8baa05d4b47b0918bf364727c2fa8c", null ]
];
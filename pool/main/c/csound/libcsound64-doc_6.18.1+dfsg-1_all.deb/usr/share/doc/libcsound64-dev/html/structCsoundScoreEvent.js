var structCsoundScoreEvent =
[
    [ "CsoundScoreEvent", "structCsoundScoreEvent.html#a0058793fc4607855c19748a1cb73ba0a", null ],
    [ "operator()", "structCsoundScoreEvent.html#a346ec3376b267167026851c11011625d", null ],
    [ "opcode", "structCsoundScoreEvent.html#abece542b5cad7c6188e1b350a5dcb5bb", null ],
    [ "pfields", "structCsoundScoreEvent.html#ae42feefbddf1d456821c93f7f2e624bf", null ]
];
var structCsoundTextEvent =
[
    [ "CsoundTextEvent", "structCsoundTextEvent.html#a13681fb4477cafe163b41fe21900fded", null ],
    [ "operator()", "structCsoundTextEvent.html#a889fd38084fc4a86bedf11d654697bb9", null ],
    [ "events", "structCsoundTextEvent.html#a48a0521324208d0a74d825aa3415ac05", null ]
];
var structDOWNDAT =
[
    [ "auxch", "structDOWNDAT.html#a455116e8ad9ca1f8ad6517c227c7f521", null ],
    [ "hifrq", "structDOWNDAT.html#a996a302ec5208c5ec718d73b69322e09", null ],
    [ "lofrq", "structDOWNDAT.html#aabbd5044500b005c2945b8e91990f4da", null ],
    [ "looct", "structDOWNDAT.html#ab1250f03d4bb3b018a01d92f2a0ed28b", null ],
    [ "nocts", "structDOWNDAT.html#a8565cd94c208e4908ff0c922ae8137c7", null ],
    [ "npts", "structDOWNDAT.html#a8791e305fb007c8dc018920146c973fa", null ],
    [ "nsamps", "structDOWNDAT.html#aad3dbc2272c291f7711934d7dcd3ab53", null ],
    [ "octdata", "structDOWNDAT.html#a25a3bdf1752aff749eb3c200ebd74ca2", null ],
    [ "srate", "structDOWNDAT.html#a768c64865d3313898ce82c47a9f3e30f", null ]
];
var structDPARM =
[
    [ "dpexcl", "structDPARM.html#adb65558074a2261146d9da325f825f5c", null ],
    [ "exclset", "structDPARM.html#a9bb5a7738773c757eb647d459faa0d93", null ]
];
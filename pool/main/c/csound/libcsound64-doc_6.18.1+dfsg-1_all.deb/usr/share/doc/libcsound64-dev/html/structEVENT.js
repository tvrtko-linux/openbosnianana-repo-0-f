var structEVENT =
[
    [ "h", "structEVENT.html#a5c1e95f515e9d4f59df044a4059c88c8", null ],
    [ "op", "structEVENT.html#ae37ad8772524de235722e7a31fbfa1b3", null ],
    [ "p", "structEVENT.html#a63b0d30729169af6d90571d6a4b8e3e9", null ],
    [ "p2orig", "structEVENT.html#a13d0c4b26230dd6514ca806dd368b800", null ],
    [ "p3orig", "structEVENT.html#ab9e9a28046a84f5f9281eb077e5543e7", null ],
    [ "pcnt", "structEVENT.html#a1036ec7749030923ae0c6fb2c4dd7e08", null ],
    [ "strarg", "structEVENT.html#a38089596e0dcc5acd4bc199348a207b9", null ]
];
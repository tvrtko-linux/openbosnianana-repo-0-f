var structEVLIST =
[
    [ "e", "structEVLIST.html#a2cf8c304a990ca11593ece5b18dff7d1", null ],
    [ "h", "structEVLIST.html#a9cc9fbf3b95fe1712cfb7a64bcfaa4bd", null ],
    [ "nevents", "structEVLIST.html#a29c59985e0c150adac13f30f79f04880", null ],
    [ "nslots", "structEVLIST.html#ae9db4a6c9fdd8041e29de8ba3d9cb6bc", null ]
];
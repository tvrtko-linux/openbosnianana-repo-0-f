var structFGDATA =
[
    [ "csound", "structFGDATA.html#a69b6edc465ec18c47c07b87e119ab130", null ],
    [ "e", "structFGDATA.html#a5b025d3ccc7b79137734faebf5956448", null ],
    [ "flen", "structFGDATA.html#a81681579d43fba7233bd2c15ec050a23", null ],
    [ "fno", "structFGDATA.html#a23f627b902dea1b09dfca3194008a66b", null ],
    [ "guardreq", "structFGDATA.html#a6761ffef527da92c6efc344861bcc043", null ]
];
var structFUNC =
[
    [ "argcnt", "structFUNC.html#a8233d117326556533a5c23b8870448bb", null ],
    [ "args", "structFUNC.html#accee282c069d6d1a1a4596549aaff5cb", null ],
    [ "begin1", "structFUNC.html#a4a05cbc234157c40939c6dcff1422d0c", null ],
    [ "begin2", "structFUNC.html#a3d755ccaa7a8ce30be968dc94ca281ea", null ],
    [ "cpscvt", "structFUNC.html#a557bd23529daf5cdb8335998c43b0bea", null ],
    [ "cvtbas", "structFUNC.html#aeb20e114f29decf3eed9405854746273", null ],
    [ "end1", "structFUNC.html#a233eddb15592a225cf243b6d4a76900f", null ],
    [ "end2", "structFUNC.html#a50156f04b235192b4f71904e77cd7251", null ],
    [ "flen", "structFUNC.html#a4a3d5a86577a3e3baac06c31ec6cacab", null ],
    [ "flenfrms", "structFUNC.html#afe504f4d7b5b3f393bd6a2b23b6e26e8", null ],
    [ "fno", "structFUNC.html#a5a12b0fd577b65f5863f7312acfe8b4e", null ],
    [ "ftable", "structFUNC.html#a6ee8dbcd82d5e8d93e0f3b6f13c040a0", null ],
    [ "gen01args", "structFUNC.html#a350cc6f8fa0dc5c3ffc3eced724a9f98", null ],
    [ "lenmask", "structFUNC.html#aa01b25d8bae65e754fc27f826d6c0201", null ],
    [ "lobits", "structFUNC.html#ad4a3b8efbdc9b8d4693cf3ca6e6ba82d", null ],
    [ "lodiv", "structFUNC.html#a3110ddd9ed881d6a3f99fb3d38d74a33", null ],
    [ "lomask", "structFUNC.html#a2480601a06fc0dc99a695d2d66b8d39c", null ],
    [ "loopmode1", "structFUNC.html#a4e7cf60c30022eedf519c8d17783f2ab", null ],
    [ "loopmode2", "structFUNC.html#a6be8d17ce75c99cdd504aca489938b69", null ],
    [ "nchanls", "structFUNC.html#a7654121a18f33352cf290fd086e18f32", null ],
    [ "soundend", "structFUNC.html#a925bf3449a7bd2b685b71da3a2e1cfd1", null ]
];
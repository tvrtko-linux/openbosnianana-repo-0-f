var structGEN01ARGS =
[
    [ "channel", "structGEN01ARGS.html#ad9bb1e3e3f43b2e2372e1892062e29a2", null ],
    [ "gen01", "structGEN01ARGS.html#a2ab1753dd84337aa8a04574823c28830", null ],
    [ "ifilno", "structGEN01ARGS.html#ae541c0867d8efefa89857dc7fd183cb6", null ],
    [ "iformat", "structGEN01ARGS.html#a8948e02c0df913a3dc75f41a90b0e44e", null ],
    [ "iskptim", "structGEN01ARGS.html#a958fcefceeb087dae77f9c606e71638f", null ],
    [ "sample_rate", "structGEN01ARGS.html#a8e19fbe2dea5d7d11874df839b9c4eb1", null ],
    [ "strarg", "structGEN01ARGS.html#aa32d76a36e43676c5737bbc96ef2f9ed", null ]
];
var structMACRO =
[
    [ "acnt", "structMACRO.html#a597062cc424efec015bfea5b51364d73", null ],
    [ "arg", "structMACRO.html#aaa8d02cf363e642438bbb9d0ad2e3eb8", null ],
    [ "body", "structMACRO.html#a5bedfeda743e1c2a22171f66461b17af", null ],
    [ "margs", "structMACRO.html#a5fb12a4a57957ac521fb2d62b6bb1642", null ],
    [ "name", "structMACRO.html#a79a20fb97d72e7c46312a524192c256c", null ],
    [ "next", "structMACRO.html#ac37dafed7d2b4b16c6a311333c0b99d1", null ]
];
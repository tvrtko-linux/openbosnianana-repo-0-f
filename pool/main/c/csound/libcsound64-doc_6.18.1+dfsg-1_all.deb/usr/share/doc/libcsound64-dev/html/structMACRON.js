var structMACRON =
[
    [ "line", "structMACRON.html#a9e4ddb88f18c9f2bfd4286e36376e544", null ],
    [ "n", "structMACRON.html#ab2d8db2adc36ff3a674f0c733cb6ef78", null ],
    [ "path", "structMACRON.html#a34716c30cc632d276ec177e83c69af9b", null ],
    [ "s", "structMACRON.html#aa0266533a8f85cb2d1f7fc0da1bdf927", null ]
];
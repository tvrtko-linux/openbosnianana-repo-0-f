var searchData=
[
  ['default_5fformat_0',['default_format',['../structcubeb__device__info.html#a541ab16fcb5faf30184d5f6b245174db',1,'cubeb_device_info']]],
  ['default_5frate_1',['default_rate',['../structcubeb__device__info.html#a9aae58c6438876e6bfa9ae32fa72793f',1,'cubeb_device_info']]],
  ['device_2',['device',['../structcubeb__device__collection.html#a83d251410cf18f18ff2366aba44e0ece',1,'cubeb_device_collection']]],
  ['device_5fid_3',['device_id',['../structcubeb__device__info.html#ad30610890019cdb2a01fbc575f6bc2bc',1,'cubeb_device_info']]],
  ['devid_4',['devid',['../structcubeb__device__info.html#ad97d9c5e43e3bcc8552dbd461c1b9f69',1,'cubeb_device_info']]]
];

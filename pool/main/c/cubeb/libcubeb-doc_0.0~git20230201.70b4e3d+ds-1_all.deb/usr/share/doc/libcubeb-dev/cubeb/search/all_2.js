var searchData=
[
  ['format_0',['format',['../structcubeb__stream__params.html#a23410bac5fbc6d86f37d9fc09f3d5d3d',1,'cubeb_stream_params::format()'],['../structcubeb__device__info.html#affc047b13aefb18f2430fcb454815b8f',1,'cubeb_device_info::format()']]],
  ['friendly_5fname_1',['friendly_name',['../structcubeb__device__info.html#ae6b5c60e81ce3b53876c7f2625074c42',1,'cubeb_device_info']]]
];

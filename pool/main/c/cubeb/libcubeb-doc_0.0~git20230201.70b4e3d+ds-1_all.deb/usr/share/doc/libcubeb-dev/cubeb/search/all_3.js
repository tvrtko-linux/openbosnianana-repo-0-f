var searchData=
[
  ['group_5fid_0',['group_id',['../structcubeb__device__info.html#a6c60b7a3cc50f29bfb489131ad6370fb',1,'cubeb_device_info']]]
];

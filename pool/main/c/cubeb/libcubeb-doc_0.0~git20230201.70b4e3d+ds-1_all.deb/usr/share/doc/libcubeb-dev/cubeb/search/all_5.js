var searchData=
[
  ['latency_5fhi_0',['latency_hi',['../structcubeb__device__info.html#ab364cf824e003872a0453ffc98949457',1,'cubeb_device_info']]],
  ['latency_5flo_1',['latency_lo',['../structcubeb__device__info.html#aa995dd8a9316d63294c0d011c1f1fd3d',1,'cubeb_device_info']]],
  ['layout_2',['layout',['../structcubeb__stream__params.html#a3f1ff5c9ce242ab67a0bd75bed7b7ccc',1,'cubeb_stream_params']]]
];

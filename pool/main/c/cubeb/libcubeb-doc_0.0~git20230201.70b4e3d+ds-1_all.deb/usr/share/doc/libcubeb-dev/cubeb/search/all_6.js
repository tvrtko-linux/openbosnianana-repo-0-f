var searchData=
[
  ['max_5fchannels_0',['max_channels',['../structcubeb__device__info.html#a979703b2df939ebee6e1da6962d0f304',1,'cubeb_device_info']]],
  ['max_5frate_1',['max_rate',['../structcubeb__device__info.html#a294fec9387a973f477ed1fc0edde77b1',1,'cubeb_device_info']]],
  ['min_5frate_2',['min_rate',['../structcubeb__device__info.html#a31d0f999f023379e773ed78137bba19e',1,'cubeb_device_info']]]
];

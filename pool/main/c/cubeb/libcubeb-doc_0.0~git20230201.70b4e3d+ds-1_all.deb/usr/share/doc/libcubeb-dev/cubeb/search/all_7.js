var searchData=
[
  ['output_5fname_0',['output_name',['../structcubeb__device.html#a4b1d99a4ba29771740d2bb75d1dd3ddb',1,'cubeb_device']]]
];

var searchData=
[
  ['preferred_0',['preferred',['../structcubeb__device__info.html#a3a313b27906fb78517c2c1afd93bf595',1,'cubeb_device_info']]],
  ['prefs_1',['prefs',['../structcubeb__stream__params.html#aa282e861f9563aa4ba49e2c2757cb77a',1,'cubeb_stream_params']]]
];

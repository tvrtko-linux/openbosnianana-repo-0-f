var searchData=
[
  ['rate_0',['rate',['../structcubeb__stream__params.html#ad67260ce5fd956aba95968e14d827868',1,'cubeb_stream_params']]]
];

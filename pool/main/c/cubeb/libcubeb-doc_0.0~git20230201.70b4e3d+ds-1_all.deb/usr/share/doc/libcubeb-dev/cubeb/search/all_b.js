var searchData=
[
  ['type_0',['type',['../structcubeb__device__info.html#a3436fa15c0f11ef00df1ef19dd2d24ea',1,'cubeb_device_info']]]
];

var searchData=
[
  ['vendor_5fname_0',['vendor_name',['../structcubeb__device__info.html#aa9a3f1f8d63b2b70d0334dfc639f73a4',1,'cubeb_device_info']]]
];

var searchData=
[
  ['channels_0',['channels',['../structcubeb__stream__params.html#afc0221acf53136ed0d17bcf6a52aaae3',1,'cubeb_stream_params']]],
  ['count_1',['count',['../structcubeb__device__collection.html#a603d4936682759e234c1388dbc5adaac',1,'cubeb_device_collection']]]
];

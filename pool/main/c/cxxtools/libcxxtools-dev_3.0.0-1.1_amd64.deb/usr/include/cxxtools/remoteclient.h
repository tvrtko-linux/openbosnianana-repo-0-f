/*
 * Copyright (C) 2011 Tommi Maekitalo
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * As a special exception, you may use this file as part of a free
 * software library without restriction. Specifically, if other files
 * instantiate templates or use macros or inline functions from this
 * file, or you compile this file and link it with other files to
 * produce an executable, this file does not by itself cause the
 * resulting executable to be covered by the GNU General Public
 * License. This exception does not however invalidate any other
 * reasons why the executable file might be covered by the GNU Library
 * General Public License.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef CXXTOOLS_REMOTECLIENT_H
#define CXXTOOLS_REMOTECLIENT_H

#include <cstddef>
#include <cxxtools/timespan.h>

namespace cxxtools
{
    class IComposer;
    class IDecomposer;
    class IRemoteProcedure;
    class SelectorBase;

    /// Base class for rpc client.
    class RemoteClient
    {
        public:
            static const std::size_t WaitInfinite = static_cast<std::size_t>(-1);

            virtual ~RemoteClient()
            { }

            virtual void beginCall(IComposer& r, IRemoteProcedure& method, IDecomposer** argv, unsigned argc) = 0;

            virtual void endCall() = 0;

            virtual void call(IComposer& r, IRemoteProcedure& method, IDecomposer** argv, unsigned argc) = 0;

            virtual const IRemoteProcedure* activeProcedure() const = 0;

            virtual void cancel() = 0;

            virtual void wait(Milliseconds msecs = WaitInfinite) = 0;

            virtual Milliseconds timeout() const = 0;
            virtual void timeout(Milliseconds t) = 0;

            virtual Milliseconds connectTimeout() const = 0;
            virtual void connectTimeout(Milliseconds t) = 0;

            virtual void setSelector(SelectorBase* selector) = 0;

            void setSelector(SelectorBase& selector) { setSelector(&selector); }
    };
}

#endif // CXXTOOLS_REMOTECLIENT_H

// Automatically generated file by cmake

#include "dart/optimizer/nlopt/NloptSolver.hpp"

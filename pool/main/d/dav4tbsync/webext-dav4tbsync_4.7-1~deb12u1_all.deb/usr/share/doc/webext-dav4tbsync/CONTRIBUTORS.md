## Creator
* John Bieling

## Contributors
* John Bieling
* Brad2014
* Nathan Gauër
* Alexandr Heymdall (vCard parser)

## Translators
* Ettore Atalan (de)
* John Bieling (de, en-US)
* Wanderlei Hüttel (pt-BR)
* Alessandro Menti (it)
* Óvári (hu)
* Alexey Sinitsyn (ru)
* Jérémie Parisel (fr)
* Daniel Wróblewski (pl)

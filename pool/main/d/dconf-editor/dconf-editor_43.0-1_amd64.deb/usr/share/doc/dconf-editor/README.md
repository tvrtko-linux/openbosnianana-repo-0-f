# Dconf-Editor

A GSettings editor for GNOME.

## Useful links

- Homepage: <https://wiki.gnome.org/Apps/DconfEditor>
- Report issues: <https://gitlab.gnome.org/GNOME/dconf-editor/issues/>
- Translate: <https://wiki.gnome.org/TranslationProject>
- Code of Conduct: <https://gitlab.gnome.org/GNOME/dconf-editor/blob/master/code-of-conduct.md>

#!/bin/sh
# This is an install/update script for DebianParl
# DebianParl Homepage: https://wiki.debian.org/DebianParl
# Source of this code: git://git.debian.org/parl/blends

set -e

# Administration
#  * include package usage reporting Popularity-Contest
#  * include APT hook apt-listchanges
#  * include APT hook needrestart
#  * include APT package support tracking
#  * include bash-completion and uuid-runtime recommended by essential packages
#  * mark misc. packages, relevant only as dependencies, as auto-installed
#  * enable unattended package upgrades
# Console media
#  * include core ALSA audio tools
#  * include PulseAudio console tools
# Console mobile
#  * include SyncEvolution console tool and http service
# Desktop
#  * include GTK system tools
#  * include GNOME-oriented NetworkManager client
#  * include screensaver unicode-screensaver
#  * include desktop editor Mousepad
#  * include desktop hardening helper tools
# Desktop email
#  * include Thunderbird email client
# desktop-environment-xfce
#  * include the lightweight Xfce desktop
#  * include Xfce power management tools
#  * include Xfce file manager
#  * include Xfce notification manager
#  * include Xfce audio handling
# Filesystem desktop handling
#  * include GTK+ locate frontend Catfish
# Desktop media
#  * include simple ALSA volume systray icon
#  * include PulseAudio desktop volume control
#  * include video player Mpv
#  * exclude PulseAudio wrapper for legacy audio system EsounD
#  * exclude video player MPlayer2
# Desktop mobile
#  * include desktop tools to syncronize with mobile devices
# Desktop office
#  * include document viewer Evince
#  * include LibreOffice Writer
#  * include LibreOffice Calc
#  * include LibreOffice Impress
#  * exclude LibreOffice Database
#  * include LibreOffice integration with GTK+ 3.x
# Desktop photo
#  * include photo manager Shotwell
# Desktop scheduling
#  * include Thunderbird extension DAV-4-TbSync
# Desktop web
#  * include Firefox web browser
#  * include Firefox security plugins
# Crypto framework
#  * include GTK+ PIN entry interface for GnuPG
# Package framework
#  * include command-line and Curses APT frontend aptitude
# Hardware
#  * include support for Bluetooth hardware
#  * include OpenGL hardware rasterizers
#  * include low-level crypto hardening tools
# Service
#  * include sleep-supporting command scheduler service anacron
#  * include Network Time Protocol service Chrony
# Audio service
#  * include PulseAudio audio daemon
# Filesystem service
#  * include locate-compatible data indexer plocate
# Print service
#  * avoid support for Gutenprint based printers
#  * avoid support for HP GDI printers
#  * avoid support for HP IJS printers
#  * avoid support for HP JetReady 4.x printers
#  * avoid support for HP LIP printers
#  * avoid minimal support for (some) HP printers
#  * avoid support for (mostly Minolta) ZjStream based printers
#  * avoid support for Konica Minolta PagePro printers
#  * avoid support for Ricoh Aficio GDI printers
#  * avoid support for Samsung SPL2/SPLc printers
#  * Avoid CUPS printing system
#  * avoid CUPS support for printing via Bluetooth
apt install task-laptop acpi-support acpi-support-base alsa-utils anacron apt-listchanges aptitude bash-completion bluez catfish chrony debian-security-support evince firefox-esr gnome-disk-utility jitterentropy-rngd l3afpad libgl1-mesa-dri libreoffice-calc libreoffice-gtk3 libreoffice-impress libreoffice-writer lightdm mpv needrestart network-manager-gnome nuntius parcimonie pasystray pavucontrol pinentry-gtk2 plocate popularity-contest pulseaudio pulseaudio-utils pulsemixer shotwell slick-greeter syncevolution syncevolution-http thunar thunderbird unattended-upgrades unicode-screensaver usermode uuid-runtime volumeicon-alsa webext-dav4tbsync webext-privacy-badger webext-ublock-origin-firefox xfce4-notifyd xfce4-panel xfce4-power-manager xfce4-power-manager-plugins xfce4-pulseaudio-plugin xfce4-session xserver-xorg \
 bluez-cups- cpufrequtils- cups- evince-gtk- hplip- libreoffice-base- libreoffice-java-common- mplayer2- printer-driver-foo2zjs- printer-driver-gutenprint- printer-driver-hpcups- printer-driver-hpijs- printer-driver-min12xxw- printer-driver-pnm2ppa- printer-driver-postscript-hp- printer-driver-pxljr- printer-driver-sag-gdi- printer-driver-splix- pulseaudio-esound-compat-

# Administration
#  * define routines to make backup of and help edit config files
#  * define routines to resolve package dependencies
#  * fix mark auto-installed essential packages + dependencies
# desktop-environment-xfce
#  * silence confusing panel question at initial login
#  * replace appfinder with mail-reader in default panel
#  * disable storing session at logout by default
# Hardware
#  * sleep when lid is closed
# Service
#  * pre-resolve NTP hosts as fallback to avoid DNSSEC deadlock
suite=bookworm

apt-mark auto \
  acpi-support-base apparmor aptitude-common bash-completion dbus dmsetup e2fsprogs firmware-linux-free grub-common isc-dhcp-common libapparmor1 libargon2-1 libatm1 libcap2 libcap2-bin libcryptsetup12 libdbus-1-3 libdevmapper1.02.1 libelf1 libell0 libexpat1 libext2fs2 libidn11 libip4tc0 libjson-c3 libmnl0 libncurses6 libnewt0.52 libpam-cap libpam-systemd libpcre2-8-0 libpopt0 libpsl5 libreadline7 libslang2 libss2 libusb-1.0-0 libxtables12 publicsuffix pulseaudio-utils readline-common sensible-utils systemd systemd-sysv tasksel-data tzdata uuid-runtime vim-common xserver-xorg || true
 _backup(){ set -e;\
  if [ -e "$1" ]; then \
    find "$1.orig" -mtime +1 2>/dev/null && ext=bak || ext=orig;\
    cp -a "$1" "$1.$ext";\
  else \
    touch "$1.orig";\
  fi; };\
 _backup_todir(){ set -e;\
  dir="${2:-$(dirname "$1").bak}";\
  [ -e "$dir" ] || mkdir -p "$dir";\
  path="$dir/$(basename "$1")";\
  if [ -e "$1" ]; then \
    cp -fa "$1" "$path";\
  else \
    touch "$path";\
  fi; };\
 _clone(){ set -e;\
  test -e "$1";\
  _backup "$2";\
  cp -fa "$1" "$2"; };\
 _setline(){ set -e;\
  _backup "$1";\
  if [ $# = 3 ]; then \
    if grep -Eq "^$2\$" "$1"; then \
      sed -i -E \
        -e 's!^('"$2"')$!'"$3"'!g' "$1";\
    else \
      sed -i -E \
        -e 's!^#('"$2"')$!'"$3"'!g' "$1";\
    fi;\
  else \
    sed -i -E \
      -e 's!^#?('"$2"')$!\1!g' "$1";\
  fi; };\
 _setappendline(){ set -e;\
  if grep -Eq '^#?'"$2"'$' "$1" 2>/dev/null; then \
    _setline "$@";\
  else \
    _backup "$1";\
    echo "${3:-$2}" >> "$1";\
  fi; };\
 _setvar(){ set -e;\
  _backup "$1";\
  if grep -Eq '^'"$2"'[ \t]*=' "$1"; then \
    sed -i -E \
      -e 's!^('"$2"'[ \t]*=[ \t]*).*!\1'"$3"'!' "$1";\
  else \
    sed -i -E \
      -e 's!^#('"$2"'[ \t]*=[ \t]*).*!\1'"$3"'!' "$1";\
  fi; };\
 _setappendvar(){ set -e;\
  if grep -Eq '^#?'"$2"'[ \t]*=' "$1" 2>/dev/null; then \
    _setvar "$@";\
  else \
    _backup "$1";\
    echo "$2=$3" >> "$1";\
  fi; };\
 _setinivar(){ set -e;\
  _backup "$1";\
  if sed -ne '/^\['"$2"'\]/,/^\[.*\]/ p' "$1" | grep -Eq '^'"$3"'[ \t]*='; then \
    sed -i -E \
      -e '/^\['"$2"'\]/,/^\[.*\]/ s!^('"$3"'[ \t]*=[ \t]*).*$!\1'"$4"'!' "$1";\
  else \
    sed -i -E \
      -e '/^\['"$2"'\]/,/^\[.*\]/ s!^#('"$3"'[ \t]*=[ \t]*).*$!\1'"$4"'!' "$1";\
  fi; };\
 _clearinikey(){ set -e;\
  _backup "$1";\
  if sed -ne '/^\['"$2"'\]/,/^\[.*\]/ p' "$1" | grep -Eq '^'"$3"'[ \t]*='; then \
    sed -i -E \
      -e '/^\['"$2"'\]/,/^\[.*\]/ s!^('"$3"'[ \t]*=[ \t]*).*$!\1'"$4"'!' "$1";\
  else \
    sed -i -E \
      -e '/^\['"$2"'\]/,/^\[.*\]/ s!^#('"$3"'[ \t]*=[ \t]*).*$!\1'"$4"'!' "$1";\
  fi; };\
 _setaddinivar(){ set -e;\
  _backup "$1";\
  if [ ! -e "$1" ]; then \
    { echo "[$2]"; echo "$3=$4"; } >> "$1";\
  elif ! grep -Eq "^\\[$2\\]" "$1"; then \
    { echo; echo "[$2]"; echo "$3=$4"; } >> "$1";\
  elif sed -ne '/^\['"$2"'\]/,/^\[.*\]/ p' "$1" | grep -Eq '^#?'"$3"'[ \t]*='; then \
    _setinivar "$@";\
  else \
    sed -i -E \
      -e '/^\['"$2"'\]/ a'"$3=$4" "$1";\
  fi; };\
 _uuid(){ set -e;\
  tmpfile=$(mktemp);\
  (umask 077; fallocate --length 40kib "$tmpfile");\
  PATH="/usr/sbin:/sbin:$PATH" mkswap "$tmpfile" | grep -Po '\bUUID=\K\S+';\
  rm -f "$tmpfile"; };\
 _setvar /etc/default/acpi-support LID_SLEEP true;\
 _pkgdeps(){ set -e;\
  dpkg-query \
    -Wf=',${Pre-Depends},${Depends},${Recommends}\n' $* 2>/dev/null \
    | sed -E \
    -e 's/[,|] *([a-z0-9.+-]+)?(:\s+)?( *[^|,]*)?/\1\n/g' \
    | sed '/^$/d'|sort -u; };\
 _pkg2re(){ set -e;\
  echo $* \
    | sed -E \
    -e 's/\s+/\|/g;' \
    -e 's/^\|//;' \
    -e 's/([.+-])/\\\1/g;' \
    -e 's/\|$//'; };\
 _pkgreal(){ set -e;\
  dpkg-query \
    -Wf='${Package},${Provides},\n' \
    | sed -E \
    -e '/,,/d;' \
    -e 's/^([a-z0-9.+-]+).*[,|] *('"$(_pkg2re $*)"')[ :,]/\1/;' \
    -e '/,/d'; };\
 _pkganddeepdeps(){ set -e;\
  rest=$*;\
  all=$rest;\
  for i in 1 2 3 4 5; do \
    deps=$(_pkgdeps $rest);\
    rest="$deps $(_pkgreal $deps)";\
    all="$all $rest";\
  done;\
  echo $all \
    | sed -E \
    -e 's/\s+/\n/g' \
    | sort -u; };\
 _pkgessentials(){ set -e;\
  dpkg-query \
    -Wf='${Package}%${Essential}\n' \
    | sed -E \
    -e 's/(.*)%yes/\1/;' \
    -e '/%/d'; };\
 apt-mark auto \
  $(_pkganddeepdeps $(_pkgessentials) apt) || true;\
 file=/etc/chrony/sources.d/local-preresolved.sources;\
 _backup "$file";\
 echo 'pool 2.debian.pool.ntp.org iburst' > "$file";\
 echo '# pre-resolve NTP hosts as fallback to avoid DNSSEC deadlock' >> "$file";\
 echo 'server 195.137.195.251 iburst' >> "$file";\
 echo 'server 158.248.189.11 iburst' >> "$file";\
 echo 'server 193.104.228.123 iburst' >> "$file";\
 echo 'server 195.137.195.252 iburst' >> "$file";\
 echo 'server 2001:ac8:37::40 iburst' >> "$file";\
 echo 'server 2001:67c:28c8:12::123 iburst' >> "$file";\
 echo 'server 2a00:1b70:1200:1::123 iburst' >> "$file";\
 echo 'server 2001:67c:564::12 iburst' >> "$file";\
 cd /etc/xdg/xfce4/xfconf/xfce-perchannel-xml;\
 _clone ../../panel/default.xml xfce4-panel.xml;\
 sed -i -E \
  -e 's,xfce4-appfinder,exo-mail-reader,' \
  xfce4-panel.xml;\
 _backup xfce4-session.xml;\
 sed -i -E \
  -e 's,(<property name="general"[^>]*>),\1\n    <property name="SaveOnExit" type="bool" value="false"/>,' \
  xfce4-session.xml

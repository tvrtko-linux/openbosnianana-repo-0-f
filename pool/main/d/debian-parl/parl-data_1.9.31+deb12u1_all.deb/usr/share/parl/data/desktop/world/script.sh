#!/bin/sh
# This is an install/update script for DebianParl
# DebianParl Homepage: https://wiki.debian.org/DebianParl
# Source of this code: git://git.debian.org/parl/blends

set -e

# Administration
#  * include package usage reporting Popularity-Contest
#  * include APT hook apt-listchanges
#  * include APT hook needrestart
#  * include APT package support tracking
#  * include bash-completion and uuid-runtime recommended by essential packages
#  * mark misc. packages, relevant only as dependencies, as auto-installed
#  * enable unattended package upgrades
# Console media
#  * include core ALSA audio tools
#  * include PulseAudio console tools
# Console mobile
#  * include SyncEvolution console tool and http service
# Desktop
#  * include GTK system tools
#  * include GNOME-oriented NetworkManager client
#  * include screensaver unicode-screensaver
#  * include desktop editor Mousepad
#  * include desktop hardening helper tools
# Desktop email
#  * include Thunderbird email client
#  * include Thunderbird locale for British English
#  * include Thunderbird locale for South African English
#  * include Thunderbird locales for Africa
#  * include Thunderbird locale for American English
#  * include Thunderbird locales for Americas
#  * include Thunderbird locale for Bengali
#  * include Thunderbird locale for Gujarati
#  * include Thunderbird locale for Hindi
#  * include Thunderbird locale for Malayalam
#  * include Thunderbird locale for Nepali
#  * include Thunderbird locale for Telugu
#  * include Thunderbird support for bidirectional text
#  * include Thunderbird locales for official languages of India
#  * include Thunderbird locales for Asia (UN M.49 definition)
#  * include Thunderbird locale for Danish
#  * include Thunderbird locale for German
#  * include Thunderbird locale for Finnish
#  * include Thunderbird locales for European Union (except Maltese)
#  * include Thunderbird locales for Europe (UN M.49 definition)
#  * include all Thunderbird locales
# desktop-environment-xfce
#  * include the lightweight Xfce desktop
#  * include Xfce power management tools
#  * include Xfce file manager
#  * include Xfce notification manager
#  * include Xfce audio handling
# Filesystem desktop handling
#  * include GTK+ locate frontend Catfish
# Desktop media
#  * include simple ALSA volume systray icon
#  * include PulseAudio desktop volume control
#  * include video player Mpv
#  * exclude PulseAudio wrapper for legacy audio system EsounD
#  * exclude video player MPlayer2
# Desktop mobile
#  * include desktop tools to syncronize with mobile devices
# Desktop office
#  * include document viewer Evince
#  * include LibreOffice Writer
#  * include LibreOffice Calc
#  * include LibreOffice Impress
#  * exclude LibreOffice Database
#  * include LibreOffice integration with GTK+ 3.x
#  * include LibreOffice Afrikaans locale
#  * include LibreOffice South African English locale
#  * include LibreOffice Transvaal Ndebele locale
#  * include LibreOffice Northern Sotho locale
#  * include LibreOffice Swazi locale
#  * include LibreOffice Southern Soto locale
#  * include LibreOffice Tswana locale
#  * include LibreOffice Tsonga locale
#  * include LibreOffice Venda locale
#  * include LibreOffice Xhosa locale
#  * include LibreOffice Zulu locale
#  * include LibreOffice locales for official languages of South Africa
#  * include LibreOffice locales for Africa
#  * include LibreOffice locales for Americas
#  * include LibreOffice Assamese locale
#  * include LibreOffice Bengali locale
#  * include LibreOffice British English locale
#  * include LibreOffice Gujarati locale
#  * include LibreOffice Hindi locale
#  * include LibreOffice Kannada locale
#  * include LibreOffice Malayalam locale
#  * include LibreOffice Marathi locale
#  * include LibreOffice Nepali locale
#  * include LibreOffice Odia (a.k.a. Oriya or Orya) locale
#  * include LibreOffice Punjabi locale
#  * include LibreOffice Tamil locale
#  * include LibreOffice Telugu locale
#  * include LibreOffice locales for official languages of India
#  * include LibreOffice locales for Asia
#  * include LibreOffice Danish locale
#  * include LibreOffice German locale
#  * include LibreOffice locales for European Union (except Maltese)
#  * include LibreOffice locales for Europe (UN M.49 definition)
#  * include all LibreOffice locales
# Desktop photo
#  * include photo manager Shotwell
# Desktop scheduling
#  * include Thunderbird extension DAV-4-TbSync
# Desktop web
#  * include Firefox web browser
#  * include Firefox security plugins
#  * include Firefox Afrikaans locale
#  * include Firefox locale for South African English
#  * include Firefox Xhosa locale
#  * include Firefox locales for official languages of South Africa
#  * include Firefox locales for Africa
#  * include Firefox locale for Canadian English
#  * include Firefox locale for American English
#  * include Firefox locales for Americas
#  * include Firefox locale for Bengali
#  * include Firefox locale for British English
#  * include Firefox Gujarati locale
#  * include Firefox Hindi locale
#  * include Firefox Kannada locale
#  * include Firefox Malayalam locale
#  * include Firefox Marathi locale
#  * include Firefox locale for Nepali
#  * include Firefox locale for Punjabi (India)
#  * include Firefox Tamil locale
#  * include Firefox Telugu locale
#  * include Firefox locales for official languages of India
#  * include Firefox locale for Punjabi
#  * include Firefox locales for Asia
#  * include Firefox Danish locale
#  * include Firefox German locale
#  * include Firefox Finnish locale
#  * include Firefox locales for European Union (except Maltese)
#  * include Firefox locales for Europe (UN M.49 definition)
#  * include all Firefox locales
# Crypto framework
#  * include GTK+ PIN entry interface for GnuPG
# Package framework
#  * include command-line and Curses APT frontend aptitude
# Hardware
#  * include support for Bluetooth hardware
#  * include OpenGL hardware rasterizers
#  * include low-level crypto hardening tools
# Service
#  * include sleep-supporting command scheduler service anacron
#  * include Network Time Protocol service Chrony
# Audio service
#  * include PulseAudio audio daemon
# Filesystem service
#  * include locate-compatible data indexer plocate
# Print service
#  * avoid support for Gutenprint based printers
#  * avoid support for HP GDI printers
#  * avoid support for HP IJS printers
#  * avoid support for HP JetReady 4.x printers
#  * avoid support for HP LIP printers
#  * avoid minimal support for (some) HP printers
#  * avoid support for (mostly Minolta) ZjStream based printers
#  * avoid support for Konica Minolta PagePro printers
#  * avoid support for Ricoh Aficio GDI printers
#  * avoid support for Samsung SPL2/SPLc printers
#  * Avoid CUPS printing system
#  * avoid CUPS support for printing via Bluetooth
apt install task-laptop acpi-support acpi-support-base alsa-utils anacron apt-listchanges aptitude bash-completion bluez catfish chrony debian-security-support evince firefox-esr firefox-esr-l10n-ach firefox-esr-l10n-af firefox-esr-l10n-an firefox-esr-l10n-ar firefox-esr-l10n-ast firefox-esr-l10n-az firefox-esr-l10n-be firefox-esr-l10n-bg firefox-esr-l10n-bn firefox-esr-l10n-br firefox-esr-l10n-bs firefox-esr-l10n-ca firefox-esr-l10n-cak firefox-esr-l10n-cs firefox-esr-l10n-cy firefox-esr-l10n-da firefox-esr-l10n-de firefox-esr-l10n-dsb firefox-esr-l10n-el firefox-esr-l10n-en-ca firefox-esr-l10n-en-gb firefox-esr-l10n-eo firefox-esr-l10n-es-ar firefox-esr-l10n-es-cl firefox-esr-l10n-es-es firefox-esr-l10n-es-mx firefox-esr-l10n-et firefox-esr-l10n-eu firefox-esr-l10n-fa firefox-esr-l10n-ff firefox-esr-l10n-fi firefox-esr-l10n-fr firefox-esr-l10n-fy-nl firefox-esr-l10n-ga-ie firefox-esr-l10n-gd firefox-esr-l10n-gl firefox-esr-l10n-gn firefox-esr-l10n-gu-in firefox-esr-l10n-he firefox-esr-l10n-hi-in firefox-esr-l10n-hr firefox-esr-l10n-hsb firefox-esr-l10n-hu firefox-esr-l10n-hy-am firefox-esr-l10n-ia firefox-esr-l10n-id firefox-esr-l10n-is firefox-esr-l10n-it firefox-esr-l10n-ja firefox-esr-l10n-ka firefox-esr-l10n-kab firefox-esr-l10n-kk firefox-esr-l10n-km firefox-esr-l10n-kn firefox-esr-l10n-ko firefox-esr-l10n-lij firefox-esr-l10n-lt firefox-esr-l10n-lv firefox-esr-l10n-mk firefox-esr-l10n-mr firefox-esr-l10n-ms firefox-esr-l10n-my firefox-esr-l10n-nb-no firefox-esr-l10n-ne-np firefox-esr-l10n-nl firefox-esr-l10n-nn-no firefox-esr-l10n-oc firefox-esr-l10n-pa-in firefox-esr-l10n-pl firefox-esr-l10n-pt-br firefox-esr-l10n-pt-pt firefox-esr-l10n-rm firefox-esr-l10n-ro firefox-esr-l10n-ru firefox-esr-l10n-si firefox-esr-l10n-sk firefox-esr-l10n-sl firefox-esr-l10n-son firefox-esr-l10n-sq firefox-esr-l10n-sr firefox-esr-l10n-sv-se firefox-esr-l10n-ta firefox-esr-l10n-te firefox-esr-l10n-th firefox-esr-l10n-tr firefox-esr-l10n-uk firefox-esr-l10n-ur firefox-esr-l10n-uz firefox-esr-l10n-vi firefox-esr-l10n-xh firefox-esr-l10n-zh-cn firefox-esr-l10n-zh-tw gnome-disk-utility hunspell-af hunspell-an hunspell-ar hunspell-be hunspell-bg hunspell-bn hunspell-bo hunspell-br hunspell-bs hunspell-ca hunspell-cs hunspell-de-at hunspell-de-ch hunspell-de-de hunspell-dz hunspell-el hunspell-en-au hunspell-en-ca hunspell-en-gb hunspell-en-us hunspell-en-za hunspell-es hunspell-eu hunspell-fr-classical hunspell-gd hunspell-gl hunspell-gu hunspell-gug hunspell-he hunspell-hi hunspell-hr hunspell-hu hunspell-id hunspell-is hunspell-it hunspell-kk hunspell-kmr hunspell-ko hunspell-lo hunspell-lt hunspell-lv hunspell-ml hunspell-mn hunspell-ne hunspell-nl hunspell-no hunspell-oc hunspell-pl hunspell-pt-br hunspell-pt-pt hunspell-ro hunspell-ru hunspell-si hunspell-sk hunspell-sl hunspell-sr hunspell-sv hunspell-sw hunspell-te hunspell-th hunspell-tr hunspell-uk hunspell-uz hunspell-vi hyphen-af hyphen-as hyphen-bn hyphen-da hyphen-de hyphen-en-gb hyphen-kn hyphen-mr hyphen-pa hyphen-ta hyphen-zu jitterentropy-rngd l3afpad libgl1-mesa-dri libreoffice-calc libreoffice-gtk3 libreoffice-impress libreoffice-l10n-af libreoffice-l10n-am libreoffice-l10n-ar libreoffice-l10n-as libreoffice-l10n-ast libreoffice-l10n-be libreoffice-l10n-bg libreoffice-l10n-bn libreoffice-l10n-br libreoffice-l10n-bs libreoffice-l10n-ca libreoffice-l10n-cs libreoffice-l10n-cy libreoffice-l10n-da libreoffice-l10n-de libreoffice-l10n-dz libreoffice-l10n-el libreoffice-l10n-en-gb libreoffice-l10n-en-za libreoffice-l10n-eo libreoffice-l10n-es libreoffice-l10n-et libreoffice-l10n-eu libreoffice-l10n-fa libreoffice-l10n-fi libreoffice-l10n-fr libreoffice-l10n-ga libreoffice-l10n-gd libreoffice-l10n-gl libreoffice-l10n-gu libreoffice-l10n-gug libreoffice-l10n-he libreoffice-l10n-hi libreoffice-l10n-hr libreoffice-l10n-hu libreoffice-l10n-id libreoffice-l10n-in libreoffice-l10n-is libreoffice-l10n-it libreoffice-l10n-ja libreoffice-l10n-ka libreoffice-l10n-kk libreoffice-l10n-km libreoffice-l10n-kmr libreoffice-l10n-kn libreoffice-l10n-ko libreoffice-l10n-lt libreoffice-l10n-lv libreoffice-l10n-mk libreoffice-l10n-ml libreoffice-l10n-mn libreoffice-l10n-mr libreoffice-l10n-nb libreoffice-l10n-ne libreoffice-l10n-nl libreoffice-l10n-nn libreoffice-l10n-nr libreoffice-l10n-nso libreoffice-l10n-oc libreoffice-l10n-om libreoffice-l10n-or libreoffice-l10n-pa-in libreoffice-l10n-pl libreoffice-l10n-pt libreoffice-l10n-pt-br libreoffice-l10n-ro libreoffice-l10n-ru libreoffice-l10n-rw libreoffice-l10n-si libreoffice-l10n-sk libreoffice-l10n-sl libreoffice-l10n-sr libreoffice-l10n-ss libreoffice-l10n-st libreoffice-l10n-sv libreoffice-l10n-szl libreoffice-l10n-ta libreoffice-l10n-te libreoffice-l10n-tg libreoffice-l10n-th libreoffice-l10n-tn libreoffice-l10n-tr libreoffice-l10n-ts libreoffice-l10n-ug libreoffice-l10n-uk libreoffice-l10n-uz libreoffice-l10n-ve libreoffice-l10n-vi libreoffice-l10n-xh libreoffice-l10n-zh-cn libreoffice-l10n-zh-tw libreoffice-l10n-zu libreoffice-writer lightdm mpv myspell-da myspell-eo myspell-et myspell-fa myspell-ga myspell-gv myspell-hy myspell-sq myspell-tl mythes-en-au mythes-en-us mythes-es mythes-fr mythes-gug mythes-pt-br needrestart network-manager-gnome nuntius parcimonie pasystray pavucontrol pinentry-gtk2 plocate popularity-contest pulseaudio pulseaudio-utils pulsemixer shotwell slick-greeter syncevolution syncevolution-http thunar thunderbird thunderbird-bidiui thunderbird-l10n-ar thunderbird-l10n-ast thunderbird-l10n-be thunderbird-l10n-bg thunderbird-l10n-br thunderbird-l10n-ca thunderbird-l10n-cs thunderbird-l10n-cy thunderbird-l10n-da thunderbird-l10n-de thunderbird-l10n-dsb thunderbird-l10n-el thunderbird-l10n-en-gb thunderbird-l10n-es-ar thunderbird-l10n-es-es thunderbird-l10n-et thunderbird-l10n-eu thunderbird-l10n-fi thunderbird-l10n-fr thunderbird-l10n-fy-nl thunderbird-l10n-ga-ie thunderbird-l10n-gd thunderbird-l10n-gl thunderbird-l10n-he thunderbird-l10n-hr thunderbird-l10n-hsb thunderbird-l10n-hu thunderbird-l10n-hy-am thunderbird-l10n-id thunderbird-l10n-is thunderbird-l10n-it thunderbird-l10n-ja thunderbird-l10n-kab thunderbird-l10n-kk thunderbird-l10n-ko thunderbird-l10n-lt thunderbird-l10n-ms thunderbird-l10n-nb-no thunderbird-l10n-nl thunderbird-l10n-nn-no thunderbird-l10n-pl thunderbird-l10n-pt-br thunderbird-l10n-pt-pt thunderbird-l10n-rm thunderbird-l10n-ro thunderbird-l10n-ru thunderbird-l10n-sk thunderbird-l10n-sl thunderbird-l10n-sq thunderbird-l10n-sr thunderbird-l10n-sv-se thunderbird-l10n-tr thunderbird-l10n-uk thunderbird-l10n-vi thunderbird-l10n-zh-cn thunderbird-l10n-zh-tw unattended-upgrades unicode-screensaver usermode uuid-runtime volumeicon-alsa webext-dav4tbsync webext-privacy-badger webext-ublock-origin-firefox xfce4-notifyd xfce4-panel xfce4-power-manager xfce4-power-manager-plugins xfce4-pulseaudio-plugin xfce4-session xserver-xorg \
 bluez-cups- cpufrequtils- cups- evince-gtk- hplip- hunspell-da- hunspell-de-at-frami- hunspell-de-ch-frami- hunspell-de-de-frami- libreoffice-base- libreoffice-java-common- mplayer2- myspell-de-de-1901- printer-driver-foo2zjs- printer-driver-gutenprint- printer-driver-hpcups- printer-driver-hpijs- printer-driver-min12xxw- printer-driver-pnm2ppa- printer-driver-postscript-hp- printer-driver-pxljr- printer-driver-sag-gdi- printer-driver-splix- pulseaudio-esound-compat-

# Administration
#  * define routines to make backup of and help edit config files
#  * define routines to resolve package dependencies
#  * fix mark auto-installed essential packages + dependencies
# desktop-environment-xfce
#  * silence confusing panel question at initial login
#  * replace appfinder with mail-reader in default panel
#  * disable storing session at logout by default
# Hardware
#  * sleep when lid is closed
# Service
#  * pre-resolve NTP hosts as fallback to avoid DNSSEC deadlock
suite=bookworm

apt-mark auto \
  acpi-support-base apparmor aptitude-common bash-completion dbus dmsetup e2fsprogs firmware-linux-free grub-common isc-dhcp-common libapparmor1 libargon2-1 libatm1 libcap2 libcap2-bin libcryptsetup12 libdbus-1-3 libdevmapper1.02.1 libelf1 libell0 libexpat1 libext2fs2 libidn11 libip4tc0 libjson-c3 libmnl0 libncurses6 libnewt0.52 libpam-cap libpam-systemd libpcre2-8-0 libpopt0 libpsl5 libreadline7 libreoffice-l10n-af libreoffice-l10n-en-za libreoffice-l10n-nr libreoffice-l10n-nso libreoffice-l10n-ss libreoffice-l10n-st libreoffice-l10n-tn libreoffice-l10n-ts libreoffice-l10n-ve libreoffice-l10n-xh libreoffice-l10n-zu libslang2 libss2 libusb-1.0-0 libxtables12 publicsuffix pulseaudio-utils readline-common sensible-utils systemd systemd-sysv tasksel-data tzdata uuid-runtime vim-common xserver-xorg || true
 _backup(){ set -e;\
  if [ -e "$1" ]; then \
    find "$1.orig" -mtime +1 2>/dev/null && ext=bak || ext=orig;\
    cp -a "$1" "$1.$ext";\
  else \
    touch "$1.orig";\
  fi; };\
 _backup_todir(){ set -e;\
  dir="${2:-$(dirname "$1").bak}";\
  [ -e "$dir" ] || mkdir -p "$dir";\
  path="$dir/$(basename "$1")";\
  if [ -e "$1" ]; then \
    cp -fa "$1" "$path";\
  else \
    touch "$path";\
  fi; };\
 _clone(){ set -e;\
  test -e "$1";\
  _backup "$2";\
  cp -fa "$1" "$2"; };\
 _setline(){ set -e;\
  _backup "$1";\
  if [ $# = 3 ]; then \
    if grep -Eq "^$2\$" "$1"; then \
      sed -i -E \
        -e 's!^('"$2"')$!'"$3"'!g' "$1";\
    else \
      sed -i -E \
        -e 's!^#('"$2"')$!'"$3"'!g' "$1";\
    fi;\
  else \
    sed -i -E \
      -e 's!^#?('"$2"')$!\1!g' "$1";\
  fi; };\
 _setappendline(){ set -e;\
  if grep -Eq '^#?'"$2"'$' "$1" 2>/dev/null; then \
    _setline "$@";\
  else \
    _backup "$1";\
    echo "${3:-$2}" >> "$1";\
  fi; };\
 _setvar(){ set -e;\
  _backup "$1";\
  if grep -Eq '^'"$2"'[ \t]*=' "$1"; then \
    sed -i -E \
      -e 's!^('"$2"'[ \t]*=[ \t]*).*!\1'"$3"'!' "$1";\
  else \
    sed -i -E \
      -e 's!^#('"$2"'[ \t]*=[ \t]*).*!\1'"$3"'!' "$1";\
  fi; };\
 _setappendvar(){ set -e;\
  if grep -Eq '^#?'"$2"'[ \t]*=' "$1" 2>/dev/null; then \
    _setvar "$@";\
  else \
    _backup "$1";\
    echo "$2=$3" >> "$1";\
  fi; };\
 _setinivar(){ set -e;\
  _backup "$1";\
  if sed -ne '/^\['"$2"'\]/,/^\[.*\]/ p' "$1" | grep -Eq '^'"$3"'[ \t]*='; then \
    sed -i -E \
      -e '/^\['"$2"'\]/,/^\[.*\]/ s!^('"$3"'[ \t]*=[ \t]*).*$!\1'"$4"'!' "$1";\
  else \
    sed -i -E \
      -e '/^\['"$2"'\]/,/^\[.*\]/ s!^#('"$3"'[ \t]*=[ \t]*).*$!\1'"$4"'!' "$1";\
  fi; };\
 _clearinikey(){ set -e;\
  _backup "$1";\
  if sed -ne '/^\['"$2"'\]/,/^\[.*\]/ p' "$1" | grep -Eq '^'"$3"'[ \t]*='; then \
    sed -i -E \
      -e '/^\['"$2"'\]/,/^\[.*\]/ s!^('"$3"'[ \t]*=[ \t]*).*$!\1'"$4"'!' "$1";\
  else \
    sed -i -E \
      -e '/^\['"$2"'\]/,/^\[.*\]/ s!^#('"$3"'[ \t]*=[ \t]*).*$!\1'"$4"'!' "$1";\
  fi; };\
 _setaddinivar(){ set -e;\
  _backup "$1";\
  if [ ! -e "$1" ]; then \
    { echo "[$2]"; echo "$3=$4"; } >> "$1";\
  elif ! grep -Eq "^\\[$2\\]" "$1"; then \
    { echo; echo "[$2]"; echo "$3=$4"; } >> "$1";\
  elif sed -ne '/^\['"$2"'\]/,/^\[.*\]/ p' "$1" | grep -Eq '^#?'"$3"'[ \t]*='; then \
    _setinivar "$@";\
  else \
    sed -i -E \
      -e '/^\['"$2"'\]/ a'"$3=$4" "$1";\
  fi; };\
 _uuid(){ set -e;\
  tmpfile=$(mktemp);\
  (umask 077; fallocate --length 40kib "$tmpfile");\
  PATH="/usr/sbin:/sbin:$PATH" mkswap "$tmpfile" | grep -Po '\bUUID=\K\S+';\
  rm -f "$tmpfile"; };\
 _setvar /etc/default/acpi-support LID_SLEEP true;\
 _pkgdeps(){ set -e;\
  dpkg-query \
    -Wf=',${Pre-Depends},${Depends},${Recommends}\n' $* 2>/dev/null \
    | sed -E \
    -e 's/[,|] *([a-z0-9.+-]+)?(:\s+)?( *[^|,]*)?/\1\n/g' \
    | sed '/^$/d'|sort -u; };\
 _pkg2re(){ set -e;\
  echo $* \
    | sed -E \
    -e 's/\s+/\|/g;' \
    -e 's/^\|//;' \
    -e 's/([.+-])/\\\1/g;' \
    -e 's/\|$//'; };\
 _pkgreal(){ set -e;\
  dpkg-query \
    -Wf='${Package},${Provides},\n' \
    | sed -E \
    -e '/,,/d;' \
    -e 's/^([a-z0-9.+-]+).*[,|] *('"$(_pkg2re $*)"')[ :,]/\1/;' \
    -e '/,/d'; };\
 _pkganddeepdeps(){ set -e;\
  rest=$*;\
  all=$rest;\
  for i in 1 2 3 4 5; do \
    deps=$(_pkgdeps $rest);\
    rest="$deps $(_pkgreal $deps)";\
    all="$all $rest";\
  done;\
  echo $all \
    | sed -E \
    -e 's/\s+/\n/g' \
    | sort -u; };\
 _pkgessentials(){ set -e;\
  dpkg-query \
    -Wf='${Package}%${Essential}\n' \
    | sed -E \
    -e 's/(.*)%yes/\1/;' \
    -e '/%/d'; };\
 apt-mark auto \
  $(_pkganddeepdeps $(_pkgessentials) apt) || true;\
 file=/etc/chrony/sources.d/local-preresolved.sources;\
 _backup "$file";\
 echo 'pool 2.debian.pool.ntp.org iburst' > "$file";\
 echo '# pre-resolve NTP hosts as fallback to avoid DNSSEC deadlock' >> "$file";\
 echo 'server 195.137.195.251 iburst' >> "$file";\
 echo 'server 158.248.189.11 iburst' >> "$file";\
 echo 'server 193.104.228.123 iburst' >> "$file";\
 echo 'server 195.137.195.252 iburst' >> "$file";\
 echo 'server 2001:ac8:37::40 iburst' >> "$file";\
 echo 'server 2001:67c:28c8:12::123 iburst' >> "$file";\
 echo 'server 2a00:1b70:1200:1::123 iburst' >> "$file";\
 echo 'server 2001:67c:564::12 iburst' >> "$file";\
 cd /etc/xdg/xfce4/xfconf/xfce-perchannel-xml;\
 _clone ../../panel/default.xml xfce4-panel.xml;\
 sed -i -E \
  -e 's,xfce4-appfinder,exo-mail-reader,' \
  xfce4-panel.xml;\
 _backup xfce4-session.xml;\
 sed -i -E \
  -e 's,(<property name="general"[^>]*>),\1\n    <property name="SaveOnExit" type="bool" value="false"/>,' \
  xfce4-session.xml

## AUTHOR:

  * Robin Hahling <Rolinh> <robin.hahling@gw-computing.net>

## CONTRIBUTORS:

  * Adam Borowski
  * Alexandre Perrin
  * Baptiste Daroussin
  * Cyril Roelandt
  * Frank Villaro-Dixon
  * Kevin Gillieron
  * Landry Breuil
  * Matthieu Le Jeune
  * Sylvain Laperche
  * Tobias Patzl
  * Michiel Pater
  * George Angelopoulos

## TRANSLATORS:

French:

  * Robin Hahling <Rolinh> <robin.hahling@gw-computing.net>

Swedish:

  * Andreas Rönnquist <gusnan@gusnan.se>

Dutch:

  * Michiel Pater <mpater@tradosoft.com>

<!-- vim: set filetype=markdown textwidth=80 -->

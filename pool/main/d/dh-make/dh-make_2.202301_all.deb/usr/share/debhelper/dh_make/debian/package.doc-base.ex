Document: #PACKAGE#
Title: Debian #PACKAGE# Manual
Author: <insert document author here>
Abstract: This manual describes what #PACKAGE# is
 and how it can be used to
 manage online manuals on Debian systems.
Section: unknown

Format: debiandoc-sgml
Files: /usr/share/doc/#PACKAGE#/#PACKAGE#.sgml.gz

Format: postscript
Files: /usr/share/doc/#PACKAGE#/#PACKAGE#.ps.gz

Format: text
Files: /usr/share/doc/#PACKAGE#/#PACKAGE#.text.gz

Format: HTML
Index: /usr/share/doc/#PACKAGE#/html/index.html
Files: /usr/share/doc/#PACKAGE#/html/*.html

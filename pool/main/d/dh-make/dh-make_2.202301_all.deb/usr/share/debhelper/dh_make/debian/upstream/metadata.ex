# Example file for upstream/metadata.
# See https://wiki.debian.org/UpstreamMetadata for more info/fields.
# Below an example based on a github project.

# Bug-Database: https://github.com/<user>/#PACKAGE#/issues
# Bug-Submit: https://github.com/<user>/#PACKAGE#/issues/new
# Changelog: https://github.com/<user>/#PACKAGE#/blob/master/CHANGES
# Documentation: https://github.com/<user>/#PACKAGE#/wiki
# Repository-Browse: https://github.com/<user>/#PACKAGE#
# Repository: https://github.com/<user>/#PACKAGE#.git

/*
 * Diagnostics - a unified framework for code annotation, logging,
 * program monitoring, and unit-testing.
 *
 * Copyright (C) 2009 Christian Schallhart <christian@schallhart.net>,
 *                    Michael Tautschnig <tautschnig@forsyte.de>
 *               2008 model.in.tum.de group, FORSYTE group
 *               2006-2007 model.in.tum.de group
 *               2002-2005 Christian Schallhart
 *  
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**
 * @file diagnostics/basic_exceptions/parse_error.hpp
 *
 * @author Christian Schallhart
 *
 * @version $Id: parse_error.hpp 296 2007-11-27 00:21:41Z tautschn $
 *
 * @brief Interface @ref ::diagnostics::Parse_Error.
 *
 * @note DOCUMENTED
 */

#ifndef DIAGNOSTICS__BASIC_EXCEPTIONS__PARSE_ERROR_HPP__INCLUDE_GUARD
#define DIAGNOSTICS__BASIC_EXCEPTIONS__PARSE_ERROR_HPP__INCLUDE_GUARD

#include <diagnostics/basic_exceptions/low_level_exception.hpp>

DIAGNOSTICS_NAMESPACE_BEGIN;

/**
 * @class Parse_Error 
 *
 * @brief Interface @ref ::diagnostics::Parse_Error.
 *
 * @nosubgrouping
 */
class Parse_Error
    : public Low_Level_Exception
{
	////////////////////////////////////////////////////////////////////////////////
    /**
     * @name Types
     * @{
     */
private:
	typedef Parse_Error Self;
	// @}
	

	////////////////////////////////////////////////////////////////////////////////
    /**
     * @name Construction/Destruction/Assignment
     * @{
     */
public:
    explicit Parse_Error( ::std::string const & what );
    virtual ~Parse_Error() DIAGNOSTICS_EXCEPTIONS_THROW_DECL;
	Parse_Error(Self const & other);
private:
	Parse_Error();
    Self& operator=(Self const & rhs);
	// @}

	////////////////////////////////////////////////////////////////////////////////
    /**
     * @name Implementation of @ref Exception
     * @{
     */
public:
	virtual char const * name() const;
	// @}
};

DIAGNOSTICS_NAMESPACE_END;

#endif /* DIAGNOSTICS__BASIC_EXCEPTIONS__PARSE_ERROR_HPP__INCLUDE_GUARD */

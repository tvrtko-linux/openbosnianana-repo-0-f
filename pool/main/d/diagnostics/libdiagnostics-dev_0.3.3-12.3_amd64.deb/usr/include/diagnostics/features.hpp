#ifndef _DIAGNOSTICS_FEATURES_HPP
#define _DIAGNOSTICS_FEATURES_HPP 1
 
/*
diagnostics/features.hpp.
Generated
automatically
at
end
of
configure.
*/
/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1, if ACE is available on your system */
#ifndef DIAGNOSTICS_HAVE_ACE 
#define DIAGNOSTICS_HAVE_ACE  1 
#endif

/* Define to 1 if you have the <algorithm> header file. */
#ifndef DIAGNOSTICS_HAVE_ALGORITHM 
#define DIAGNOSTICS_HAVE_ALGORITHM  1 
#endif

/* Define to 1 if you have the `argz_add' function. */
#ifndef DIAGNOSTICS_HAVE_ARGZ_ADD 
#define DIAGNOSTICS_HAVE_ARGZ_ADD  1 
#endif

/* Define to 1 if you have the `argz_append' function. */
#ifndef DIAGNOSTICS_HAVE_ARGZ_APPEND 
#define DIAGNOSTICS_HAVE_ARGZ_APPEND  1 
#endif

/* Define to 1 if you have the `argz_count' function. */
#ifndef DIAGNOSTICS_HAVE_ARGZ_COUNT 
#define DIAGNOSTICS_HAVE_ARGZ_COUNT  1 
#endif

/* Define to 1 if you have the `argz_create_sep' function. */
#ifndef DIAGNOSTICS_HAVE_ARGZ_CREATE_SEP 
#define DIAGNOSTICS_HAVE_ARGZ_CREATE_SEP  1 
#endif

/* Define to 1 if you have the <argz.h> header file. */
#ifndef DIAGNOSTICS_HAVE_ARGZ_H 
#define DIAGNOSTICS_HAVE_ARGZ_H  1 
#endif

/* Define to 1 if you have the `argz_insert' function. */
#ifndef DIAGNOSTICS_HAVE_ARGZ_INSERT 
#define DIAGNOSTICS_HAVE_ARGZ_INSERT  1 
#endif

/* Define to 1 if you have the `argz_next' function. */
#ifndef DIAGNOSTICS_HAVE_ARGZ_NEXT 
#define DIAGNOSTICS_HAVE_ARGZ_NEXT  1 
#endif

/* Define to 1 if you have the `argz_stringify' function. */
#ifndef DIAGNOSTICS_HAVE_ARGZ_STRINGIFY 
#define DIAGNOSTICS_HAVE_ARGZ_STRINGIFY  1 
#endif

/* Define to 1 if you have the `atexit' function. */
#ifndef DIAGNOSTICS_HAVE_ATEXIT 
#define DIAGNOSTICS_HAVE_ATEXIT  1 
#endif

/* Define to 1 if you have the <cassert> header file. */
#ifndef DIAGNOSTICS_HAVE_CASSERT 
#define DIAGNOSTICS_HAVE_CASSERT  1 
#endif

/* Define to 1 if you have the `closedir' function. */
#ifndef DIAGNOSTICS_HAVE_CLOSEDIR 
#define DIAGNOSTICS_HAVE_CLOSEDIR  1 
#endif

/* Define to 1 if you have the <cmath> header file. */
#ifndef DIAGNOSTICS_HAVE_CMATH 
#define DIAGNOSTICS_HAVE_CMATH  1 
#endif

/* Define to 1 if you have the <cstdio> header file. */
#ifndef DIAGNOSTICS_HAVE_CSTDIO 
#define DIAGNOSTICS_HAVE_CSTDIO  1 
#endif

/* Define to 1 if you have the <cstdlib> header file. */
#ifndef DIAGNOSTICS_HAVE_CSTDLIB 
#define DIAGNOSTICS_HAVE_CSTDLIB  1 
#endif

/* Define to 1 if you have the declaration of `cygwin_conv_path', and to 0 if
   you don't. */
/* #undef DIAGNOSTICS_HAVE_DECL_CYGWIN_CONV_PATH */

/* Define to 1 if you have the <dirent.h> header file. */
#ifndef DIAGNOSTICS_HAVE_DIRENT_H 
#define DIAGNOSTICS_HAVE_DIRENT_H  1 
#endif

/* Define if you have the GNU dld library. */
/* #undef DIAGNOSTICS_HAVE_DLD */

/* Define to 1 if you have the <dld.h> header file. */
/* #undef DIAGNOSTICS_HAVE_DLD_H */

/* Define to 1 if you have the `dlerror' function. */
#ifndef DIAGNOSTICS_HAVE_DLERROR 
#define DIAGNOSTICS_HAVE_DLERROR  1 
#endif

/* Define to 1 if you have the <dlfcn.h> header file. */
#ifndef DIAGNOSTICS_HAVE_DLFCN_H 
#define DIAGNOSTICS_HAVE_DLFCN_H  1 
#endif

/* Define to 1 if you have the <dl.h> header file. */
/* #undef DIAGNOSTICS_HAVE_DL_H */

/* Define if you have the _dyld_func_lookup function. */
/* #undef DIAGNOSTICS_HAVE_DYLD */

/* Define to 1 if the system has the type `error_t'. */
#ifndef DIAGNOSTICS_HAVE_ERROR_T 
#define DIAGNOSTICS_HAVE_ERROR_T  1 
#endif

/* Define to 1 if you have the <exception> header file. */
#ifndef DIAGNOSTICS_HAVE_EXCEPTION 
#define DIAGNOSTICS_HAVE_EXCEPTION  1 
#endif

/* Define to 1 if you have the <fstream> header file. */
#ifndef DIAGNOSTICS_HAVE_FSTREAM 
#define DIAGNOSTICS_HAVE_FSTREAM  1 
#endif

/* Define to 1 if you have the `gettimeofday' function. */
#ifndef DIAGNOSTICS_HAVE_GETTIMEOFDAY 
#define DIAGNOSTICS_HAVE_GETTIMEOFDAY  1 
#endif

/* Define to 1 if you have the <inttypes.h> header file. */
#ifndef DIAGNOSTICS_HAVE_INTTYPES_H 
#define DIAGNOSTICS_HAVE_INTTYPES_H  1 
#endif

/* Define to 1 if you have the <iostream> header file. */
#ifndef DIAGNOSTICS_HAVE_IOSTREAM 
#define DIAGNOSTICS_HAVE_IOSTREAM  1 
#endif

/* Define if you have the libdl library or equivalent. */
#ifndef DIAGNOSTICS_HAVE_LIBDL 
#define DIAGNOSTICS_HAVE_LIBDL  1 
#endif

/* Define if libdlloader will be built on this platform */
#ifndef DIAGNOSTICS_HAVE_LIBDLLOADER 
#define DIAGNOSTICS_HAVE_LIBDLLOADER  1 
#endif

/* Define to 1 if you have the <limits> header file. */
#ifndef DIAGNOSTICS_HAVE_LIMITS 
#define DIAGNOSTICS_HAVE_LIMITS  1 
#endif

/* Define to 1 if you have the <link.h> header file. */
#ifndef DIAGNOSTICS_HAVE_LINK_H 
#define DIAGNOSTICS_HAVE_LINK_H  1 
#endif

/* Define this if a modern libltdl is already installed */
#ifndef DIAGNOSTICS_HAVE_LTDL 
#define DIAGNOSTICS_HAVE_LTDL  1 
#endif

/* Define to 1 if you have the <mach-o/dyld.h> header file. */
/* #undef DIAGNOSTICS_HAVE_MACH_O_DYLD_H */

/* Define to 1 if your system has a GNU libc compatible `malloc' function, and
   to 0 otherwise. */
#ifndef DIAGNOSTICS_HAVE_MALLOC 
#define DIAGNOSTICS_HAVE_MALLOC  1 
#endif

/* Define to 1 if you have the <map> header file. */
#ifndef DIAGNOSTICS_HAVE_MAP 
#define DIAGNOSTICS_HAVE_MAP  1 
#endif

/* Define to 1 if you have the `opendir' function. */
#ifndef DIAGNOSTICS_HAVE_OPENDIR 
#define DIAGNOSTICS_HAVE_OPENDIR  1 
#endif

/* Define if libtool can extract symbol lists from object files. */
#ifndef DIAGNOSTICS_HAVE_PRELOADED_SYMBOLS 
#define DIAGNOSTICS_HAVE_PRELOADED_SYMBOLS  1 
#endif

/* Define to 1 if the system has the type `ptrdiff_t'. */
#ifndef DIAGNOSTICS_HAVE_PTRDIFF_T 
#define DIAGNOSTICS_HAVE_PTRDIFF_T  1 
#endif

/* Define to 1 if you have the `readdir' function. */
#ifndef DIAGNOSTICS_HAVE_READDIR 
#define DIAGNOSTICS_HAVE_READDIR  1 
#endif

/* Define if you have the shl_load function. */
/* #undef DIAGNOSTICS_HAVE_SHL_LOAD */

/* Define to 1 if you have the <sstream> header file. */
#ifndef DIAGNOSTICS_HAVE_SSTREAM 
#define DIAGNOSTICS_HAVE_SSTREAM  1 
#endif

/* Define to 1 if you have the <stack> header file. */
#ifndef DIAGNOSTICS_HAVE_STACK 
#define DIAGNOSTICS_HAVE_STACK  1 
#endif

/* Define to 1 if you have the <stdint.h> header file. */
#ifndef DIAGNOSTICS_HAVE_STDINT_H 
#define DIAGNOSTICS_HAVE_STDINT_H  1 
#endif

/* Define to 1 if you have the <stdio.h> header file. */
#ifndef DIAGNOSTICS_HAVE_STDIO_H 
#define DIAGNOSTICS_HAVE_STDIO_H  1 
#endif

/* Define to 1 if you have the <stdlib.h> header file. */
#ifndef DIAGNOSTICS_HAVE_STDLIB_H 
#define DIAGNOSTICS_HAVE_STDLIB_H  1 
#endif

/* Define to 1 if you have the <string> header file. */
#ifndef DIAGNOSTICS_HAVE_STRING 
#define DIAGNOSTICS_HAVE_STRING  1 
#endif

/* Define to 1 if you have the <strings.h> header file. */
#ifndef DIAGNOSTICS_HAVE_STRINGS_H 
#define DIAGNOSTICS_HAVE_STRINGS_H  1 
#endif

/* Define to 1 if you have the <string.h> header file. */
#ifndef DIAGNOSTICS_HAVE_STRING_H 
#define DIAGNOSTICS_HAVE_STRING_H  1 
#endif

/* Define to 1 if you have the `strlcat' function. */
/* #undef DIAGNOSTICS_HAVE_STRLCAT */

/* Define to 1 if you have the `strlcpy' function. */
/* #undef DIAGNOSTICS_HAVE_STRLCPY */

/* Define to 1 if you have the <sys/dl.h> header file. */
/* #undef DIAGNOSTICS_HAVE_SYS_DL_H */

/* Define to 1 if you have the <sys/stat.h> header file. */
#ifndef DIAGNOSTICS_HAVE_SYS_STAT_H 
#define DIAGNOSTICS_HAVE_SYS_STAT_H  1 
#endif

/* Define to 1 if you have the <sys/types.h> header file. */
#ifndef DIAGNOSTICS_HAVE_SYS_TYPES_H 
#define DIAGNOSTICS_HAVE_SYS_TYPES_H  1 
#endif

/* Define to 1 if you have the <unistd.h> header file. */
#ifndef DIAGNOSTICS_HAVE_UNISTD_H 
#define DIAGNOSTICS_HAVE_UNISTD_H  1 
#endif

/* Define to 1 if you have the <utility> header file. */
#ifndef DIAGNOSTICS_HAVE_UTILITY 
#define DIAGNOSTICS_HAVE_UTILITY  1 
#endif

/* Define to 1 if you have the <vector> header file. */
#ifndef DIAGNOSTICS_HAVE_VECTOR 
#define DIAGNOSTICS_HAVE_VECTOR  1 
#endif

/* This value is set to 1 to indicate that the system argz facility works */
#ifndef DIAGNOSTICS_HAVE_WORKING_ARGZ 
#define DIAGNOSTICS_HAVE_WORKING_ARGZ  1 
#endif

/* Define if the OS needs help to load dependent libraries for dlopen(). */
/* #undef DIAGNOSTICS_LTDL_DLOPEN_DEPLIBS */

/* Define to the system default library search path. */
#ifndef DIAGNOSTICS_LT_DLSEARCH_PATH 
#define DIAGNOSTICS_LT_DLSEARCH_PATH  "/lib:/usr/lib:/usr/lib/x86_64-linux-gnu/libfakeroot:/usr/local/lib:/usr/local/lib/x86_64-linux-gnu:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu" 
#endif

/* The archive extension */
#ifndef DIAGNOSTICS_LT_LIBEXT 
#define DIAGNOSTICS_LT_LIBEXT  "a" 
#endif

/* The archive prefix */
#ifndef DIAGNOSTICS_LT_LIBPREFIX 
#define DIAGNOSTICS_LT_LIBPREFIX  "lib" 
#endif

/* Define to the extension used for runtime loadable modules, say, ".so". */
#ifndef DIAGNOSTICS_LT_MODULE_EXT 
#define DIAGNOSTICS_LT_MODULE_EXT  ".so" 
#endif

/* Define to the name of the environment variable that determines the run-time
   module search path. */
#ifndef DIAGNOSTICS_LT_MODULE_PATH_VAR 
#define DIAGNOSTICS_LT_MODULE_PATH_VAR  "LD_LIBRARY_PATH" 
#endif

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#ifndef DIAGNOSTICS_LT_OBJDIR 
#define DIAGNOSTICS_LT_OBJDIR  ".libs/" 
#endif

/* Define to the shared library suffix, say, ".dylib". */
/* #undef DIAGNOSTICS_LT_SHARED_EXT */

/* Define to the shared archive member specification, say "(shr.o)". */
/* #undef DIAGNOSTICS_LT_SHARED_LIB_MEMBER */

/* Define if dlsym() requires a leading underscore in symbol names. */
/* #undef DIAGNOSTICS_NEED_USCORE */

/* Name of package */
#ifndef DIAGNOSTICS_PACKAGE 
#define DIAGNOSTICS_PACKAGE  "diagnostics" 
#endif

/* Define to the address where bug reports for this package should be sent. */
#ifndef DIAGNOSTICS_PACKAGE_BUGREPORT 
#define DIAGNOSTICS_PACKAGE_BUGREPORT  "christian@schallhart.net" 
#endif

/* Define to the full name of this package. */
#ifndef DIAGNOSTICS_PACKAGE_NAME 
#define DIAGNOSTICS_PACKAGE_NAME  "diagnostics" 
#endif

/* Define to the full name and version of this package. */
#ifndef DIAGNOSTICS_PACKAGE_STRING 
#define DIAGNOSTICS_PACKAGE_STRING  "diagnostics 0.3.3" 
#endif

/* Define to the one symbol short name of this package. */
#ifndef DIAGNOSTICS_PACKAGE_TARNAME 
#define DIAGNOSTICS_PACKAGE_TARNAME  "diagnostics" 
#endif

/* Define to the home page for this package. */
#ifndef DIAGNOSTICS_PACKAGE_URL 
#define DIAGNOSTICS_PACKAGE_URL  "" 
#endif

/* Define to the version of this package. */
#ifndef DIAGNOSTICS_PACKAGE_VERSION 
#define DIAGNOSTICS_PACKAGE_VERSION  "0.3.3" 
#endif

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#ifndef DIAGNOSTICS_STDC_HEADERS 
#define DIAGNOSTICS_STDC_HEADERS  1 
#endif

/* Version number of package */
#ifndef DIAGNOSTICS_VERSION 
#define DIAGNOSTICS_VERSION  "0.3.3" 
#endif

/* Define so that glibc/gnulib argp.h does not typedef error_t. */
/* #undef DIAGNOSTICS___error_t_defined */

/* Define to a type to use for 'error_t' if it is not otherwise available. */
/* #undef _diagnostics_error_t */

/* Define to rpl_malloc if the replacement function should be used. */
/* #undef _diagnostics_malloc */

/* Define as a signed integer type capable of holding a process identifier. */
/* #undef _diagnostics_pid_t */

/* Define to `unsigned int' if <sys/types.h> does not define. */
/* #undef _diagnostics_size_t */
 
/* once:
_DIAGNOSTICS_FEATURES_HPP
*/
#endif

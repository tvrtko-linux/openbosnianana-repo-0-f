# Copyright 2020 gi-lom
# Copyright 2020-2022 Mufeed Ali
# Copyright 2020-2022 Rafael Mardojai CM
# SPDX-License-Identifier: GPL-3.0-or-later


APP_ID = 'app.drey.Dialect'
PROFILE = ''
RES_PATH = '/app/drey/Dialect'
VERSION = '2.1.1'

TRANS_NUMBER = 10  # number of translations to save in history



.. include:: ../README.rst

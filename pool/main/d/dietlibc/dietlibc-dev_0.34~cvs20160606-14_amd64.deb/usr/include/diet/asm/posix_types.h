#ifndef _ASM_POSIX_TYPES_H
#define _ASM_POSIX_TYPES_H

typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;

#endif

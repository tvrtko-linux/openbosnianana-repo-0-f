#ifndef _NETINET_IF_ETHER_H
#define _NETINET_IF_ETHER_H

#include <net/ethernet.h>

#endif

/* ah, the sublime brokenness... susv3 defines poll.h, the Linux man
 * page defines sys/poll.h; duh! */
#ifndef _SYS_POLL_H
#define _SYS_POLL_H

#include <poll.h>

#endif

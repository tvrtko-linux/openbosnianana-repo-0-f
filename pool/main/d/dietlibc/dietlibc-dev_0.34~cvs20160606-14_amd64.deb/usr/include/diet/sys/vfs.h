#ifndef _SYS_VFS_H
#define _SYS_VFS_H

#include <sys/statfs.h>

#endif

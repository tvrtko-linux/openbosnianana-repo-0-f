GRANT SELECT,INSERT ON digitemp.* TO dt_logger@localhost
IDENTIFIED BY 'TopSekRet';

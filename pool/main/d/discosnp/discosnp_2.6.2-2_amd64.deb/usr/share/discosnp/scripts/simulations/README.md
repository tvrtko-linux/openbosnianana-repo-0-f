# Simulation scripts


##Requirements
Mutareads tool

##Usage
	multiple_samples_simulator.sh –g genome.fasta

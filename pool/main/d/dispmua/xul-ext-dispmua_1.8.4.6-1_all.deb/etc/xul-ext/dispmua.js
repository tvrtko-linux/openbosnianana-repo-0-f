// Place your preferences for xul-ext-dispmua in this file.
// You can override here the preferences specified in
// /usr/share/xul-ext/dispmua/defaults/preferences/prefs.js

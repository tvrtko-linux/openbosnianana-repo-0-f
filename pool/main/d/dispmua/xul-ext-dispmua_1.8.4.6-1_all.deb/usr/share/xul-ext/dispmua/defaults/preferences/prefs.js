pref ( "extensions.{F8147CF4-B9E3-445B-AA87-081ED66548F8}.description" , "chrome://dispmua/locale/dispmua.properties" ) ;

from django.apps import AppConfig


class RecipesConfig(AppConfig):
    name = "cookbook.recipes"
    label = "recipes"
    verbose_name = "Recipes"

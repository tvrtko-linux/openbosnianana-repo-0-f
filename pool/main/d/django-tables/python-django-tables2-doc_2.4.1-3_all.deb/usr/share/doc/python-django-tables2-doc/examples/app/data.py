COUNTRIES = """Aruba;104822
Afghanistan;34656032
Angola;28813463
Albania;2876101
Andorra;77281
Arab World;406452690
United Arab Emirates;9269612
Argentina;43847430
Armenia;2924816
American Samoa;55599
Antigua and Barbuda;100963
Australia;24127159
Austria;8747358
Azerbaijan;9762274
Burundi;10524117
Belgium;11348159
Benin;10872298
Burkina Faso;18646433
Bangladesh;162951560
Bulgaria;7127822
Bahrain;1425171
Bahamas, The;391232
Bosnia and Herzegovina;3516816
Belarus;9507120
Belize;366954
Bermuda;65331
Bolivia;10887882
Brazil;207652865
Barbados;284996
Brunei Darussalam;423196
Bhutan;797765
Botswana;2250260
Central African Republic;4594621
Canada;36286425
Switzerland;8372098
Channel Islands;164541
Chile;17909754
China;1378665000
Cote d'Ivoire;23695919
Cameroon;23439189
Congo, Dem. Rep.;78736153
Congo, Rep.;5125821
Colombia;48653419
Comoros;795601
Cabo Verde;539560
"""

#!/usr/bin/python3

from dkimpy_milter import main

if __name__ == "__main__":
    main()

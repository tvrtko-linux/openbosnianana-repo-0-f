// Copyright (C) 2012  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_BSPh_
#define DLIB_BSPh_ 


#include "bsp/bsp.h"

#endif // DLIB_BSPh_ 




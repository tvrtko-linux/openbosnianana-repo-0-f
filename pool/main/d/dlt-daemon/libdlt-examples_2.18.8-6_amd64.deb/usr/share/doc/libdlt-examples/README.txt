Copyright (C) 2015 BMW AG.

Copying and distribution of this file, with or without modification,
are permitted in any medium without royalty provided the copyright
notice and this notice are preserved.

This folder contains several examples of applications using the DLT library. These examples will be extended in the future to show different Use Cases.

Example1: Minimal DLT Example
Example2: Non Verbose Mode Examples with different AppIdds and normal Strings
Example3: Non Verbose Mode Examples with different AppIdds and constant strings
Example4: Different RAW data

---
title: "context rm"
description: "The context rm command description and usage"
keywords: "context, rm"
---

# context rm

```markdown
Usage:  docker context rm CONTEXT [CONTEXT...]

Remove one or more contexts

Aliases:
  rm, remove

Options:
  -f, --force   Force the removal of a context in use
```

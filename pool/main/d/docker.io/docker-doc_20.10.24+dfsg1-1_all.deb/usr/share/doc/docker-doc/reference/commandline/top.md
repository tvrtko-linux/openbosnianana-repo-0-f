---
title: "top"
description: "The top command description and usage"
keywords: "container, running, processes"
---

# top

```markdown
Usage:  docker top CONTAINER [ps OPTIONS]

Display the running processes of a container

Options:
      --help   Print usage
```

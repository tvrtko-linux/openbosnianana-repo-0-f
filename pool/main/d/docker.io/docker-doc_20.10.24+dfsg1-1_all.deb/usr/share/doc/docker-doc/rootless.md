Moved to https://docs.docker.com/go/rootless/

<!-- do not remove this file, as there is a lot of links to https://github.com/moby/moby/blob/master/docs/rootless.md -->

package types

import (
	"github.com/docker/docker/api/types"
)

type AuthConfig = types.AuthConfig

#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include <doctest/doctest.h>

TEST_CASE("main") { std::cout << "hello from <main.cpp>" << std::endl; }

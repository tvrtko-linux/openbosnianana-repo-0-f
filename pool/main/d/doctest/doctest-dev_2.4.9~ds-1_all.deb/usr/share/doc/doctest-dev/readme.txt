Reference

Project:

  - Features and design goals - the complete list of features
  - Community driven roadmap - upcoming features
  - Benchmarks - compile-time and runtime supremacy
  - Contributing - how to make a proper pull request
  - Changelog - generated changelog based on closed issues/PRs

Usage:

  - Tutorial - make sure you have read it before the other parts of the documentation
  - Assertion macros
  - Test cases, subcases and test fixtures
  - Parameterized test cases
  - Logging macros
  - Command line
  - main() entry point
  - Configuration
  - String conversions
  - Reporters
  - Extensions
  - FAQ
  - Build systems
  - Examples

This library is free, and will stay free but needs your support to sustain its development. There are lots of new features and maintenance to do. If you work for a company using doctest or have the means to do so, please consider financial support.

Patreon
PayPal

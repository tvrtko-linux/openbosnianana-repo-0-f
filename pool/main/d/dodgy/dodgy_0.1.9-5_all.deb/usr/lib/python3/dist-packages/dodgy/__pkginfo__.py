
VERSION = (0, 1, 9)


def get_version():
    return '.'.join([str(v) for v in VERSION])

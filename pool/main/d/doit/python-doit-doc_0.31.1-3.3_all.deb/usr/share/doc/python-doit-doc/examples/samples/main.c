#include <stdio.h>

int main()
{
    printf("\nHello World\n");
    return 0;
}

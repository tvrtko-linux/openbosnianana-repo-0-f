def task_print():
    return {'actions': ['echo hello'],
            'verbosity': 2}

define(
"dojo/cldr/nls/en-au/currency", //begin v1.x content
{
	"CHF_symbol": "CHF",
	"JPY_symbol": "JPY",
	"HKD_symbol": "HKD",
	"USD_symbol": "USD",
	"CAD_symbol": "CAD",
	"EUR_symbol": "EUR",
	"CNY_symbol": "CNY",
	"GBP_symbol": "GBP",
	"AUD_symbol": "$"
}
//end v1.x content
);
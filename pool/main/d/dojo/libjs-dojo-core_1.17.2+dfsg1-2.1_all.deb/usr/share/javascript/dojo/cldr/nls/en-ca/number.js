define(
"dojo/cldr/nls/en-ca/number", //begin v1.x content
{
	"exponential": "e"
}
//end v1.x content
);
define(
"dojo/cldr/nls/en-gb/generic", //begin v1.x content
{
	"field-year-narrow": "yr",
	"field-second-narrow": "sec",
	"dateFormatItem-MEd": "E dd/MM",
	"dateFormatItem-MMMEd": "E d MMM",
	"field-hour-narrow": "hr"
}
//end v1.x content
);
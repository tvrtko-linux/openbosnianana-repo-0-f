define(
"dojo/cldr/nls/fr-ch/generic", //begin v1.x content
{
	"dateFormatItem-yMEd": "E, dd.MM.y GGGGG",
	"dateFormatItem-yMd": "dd.MM.y GGGGG",
	"dateFormat-short": "dd.MM.y GGGGG",
	"dateFormatItem-MMdd": "dd.MM",
	"dateFormatItem-MEd": "E, dd.MM.",
	"dateFormatItem-yM": "MM.y GGGGG",
	"dateFormat-full": "EEEE, d MMMM y G",
	"dateFormatItem-Md": "dd.MM."
}
//end v1.x content
);
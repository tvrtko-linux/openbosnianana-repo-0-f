define(
"dojo/cldr/nls/fr-ch/number", //begin v1.x content
{
	"currencyDecimal": ".",
	"percentFormat": "#,##0%"
}
//end v1.x content
);
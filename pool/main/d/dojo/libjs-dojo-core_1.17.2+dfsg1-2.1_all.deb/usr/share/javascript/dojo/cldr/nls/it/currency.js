define(
"dojo/cldr/nls/it/currency", //begin v1.x content
{
	"HKD_displayName": "dollaro di Hong Kong",
	"CHF_displayName": "franco svizzero",
	"JPY_symbol": "JPY",
	"CAD_displayName": "dollaro canadese",
	"HKD_symbol": "HKD",
	"CNY_displayName": "renminbi cinese",
	"USD_symbol": "USD",
	"AUD_displayName": "dollaro australiano",
	"JPY_displayName": "yen giapponese",
	"USD_displayName": "dollaro statunitense",
	"EUR_symbol": "€",
	"GBP_displayName": "sterlina britannica",
	"AUD_symbol": "A$",
	"EUR_displayName": "euro"
}
//end v1.x content
);
define(
"dojo/cldr/nls/pt-pt/number", //begin v1.x content
{
	"group": " ",
	"decimalFormat-long": "000 biliões",
	"currencyFormat": "#,##0.00 ¤;(#,##0.00 ¤)",
	"decimalFormat-short": "000 Bi",
	"currencyFormat-short": "000 B ¤",
	"approximatelySign": "~"
}
//end v1.x content
);
define("dijit/form/nls/eu/ComboBox", {      
//begin v1.x content
		previousMessage: "Aurreko aukerak",
		nextMessage: "Aukera gehiago"
//end v1.x content
});


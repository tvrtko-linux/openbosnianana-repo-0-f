define("dijit/form/nls/sr/ComboBox", {      
//begin v1.x content
		previousMessage: "Prethodne opcije",
		nextMessage: "Više opcija"
//end v1.x content
});


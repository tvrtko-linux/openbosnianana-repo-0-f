define(
"dijit/nls/ja/loading", ({
	loadingState: "ロード中...",
	errorState: "エラーが発生しました。"
})
);

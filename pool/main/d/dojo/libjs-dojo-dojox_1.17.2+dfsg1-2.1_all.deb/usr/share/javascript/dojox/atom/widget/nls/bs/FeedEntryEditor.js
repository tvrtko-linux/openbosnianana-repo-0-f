define("dojox/atom/widget/nls/bs/FeedEntryEditor", {      
//begin v1.x content
	doNew: "[novo]",
	edit: "[uredi]",
	save: "[sačuvaj]",
	cancel: "[otkaži]"
//end v1.x content
});


define("dojox/atom/widget/nls/bs/FeedEntryViewer", {      
//begin v1.x content
	displayOptions: "[prikaži opcije]",
	title: "Naslov",
	authors: "Autori",
	contributors: "Saradnici",
	id: "ID",
	close: "[zatvori]",
	updated: "Ažurirano",
	summary: "Rezime",
	content: "Sadržaj"
//end v1.x content
});


define(
"dojox/atom/widget/nls/ca/FeedEntryViewer", ({
	displayOptions: "[mostra opcions]",
	title: "Títol",
	authors: "Autors",
	contributors: "Col·laboradors",
	id: "ID",
	close: "[tanca]",
	updated: "Actualitzat",
	summary: "Resum",
	content: "Contingut"
})
);

define(
"dojox/atom/widget/nls/de/FeedEntryEditor", ({
	doNew: "[Neu]",
	edit: "[Bearbeiten]",
	save: "[Speichern]",
	cancel: "[Abbrechen]"
})
);

define(
"dojox/atom/widget/nls/de/PeopleEditor", ({
	add: "Hinzufügen",
	addAuthor: "Autor hinzufügen",
	addContributor: "Mitwirkenden hinzufügen"
})
);

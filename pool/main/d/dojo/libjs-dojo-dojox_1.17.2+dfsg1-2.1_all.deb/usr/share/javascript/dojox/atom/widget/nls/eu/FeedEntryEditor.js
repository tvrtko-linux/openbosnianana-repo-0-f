define("dojox/atom/widget/nls/eu/FeedEntryEditor", {      
//begin v1.x content
	doNew: "[berria]",
	edit: "[editatu]",
	save: "[gorde]",
	cancel: "[utzi]"
//end v1.x content
});


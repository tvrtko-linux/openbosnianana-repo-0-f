define("dojox/atom/widget/nls/eu/FeedViewerEntry", {      
//begin v1.x content
	deleteButton: "[Ezabatu]"
//end v1.x content
});


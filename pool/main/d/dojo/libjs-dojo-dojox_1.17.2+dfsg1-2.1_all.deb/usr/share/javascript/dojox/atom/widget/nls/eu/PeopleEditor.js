define("dojox/atom/widget/nls/eu/PeopleEditor", {      
//begin v1.x content
	add: "Gehitu",
	addAuthor: "Gehitu egilea",
	addContributor: "Gehitu kolaboratzailea"
//end v1.x content
});


define(
"dojox/atom/widget/nls/id/FeedEntryEditor", ({
	doNew: "[baru]",
	edit: "[edit]",
	save: "[simpan]",
	cancel: "[batal]"
})
);


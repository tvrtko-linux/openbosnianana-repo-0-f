define(
"dojox/atom/widget/nls/kk/FeedEntryViewer", ({
	displayOptions: "[көрсету параметрлері]",
	title: "Тақырып",
	authors: "Авторлар",
	contributors: "Салымшылар",
	id: "Жалпылауыш",
	close: "[жабу]",
	updated: "Жаңартылған",
	summary: "Жиынтық",
	content: "Мазмұн"
})
);

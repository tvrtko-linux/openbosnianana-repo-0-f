define(
"dojox/atom/widget/nls/ko/FeedEntryEditor", ({
	doNew: "[새로 작성]",
	edit: "[편집]",
	save: "[저장]",
	cancel: "[취소]"
})
);

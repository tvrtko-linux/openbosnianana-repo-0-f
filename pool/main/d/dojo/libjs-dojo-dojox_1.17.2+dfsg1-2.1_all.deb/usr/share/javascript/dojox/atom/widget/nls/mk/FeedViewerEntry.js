define("dojox/atom/widget/nls/mk/FeedViewerEntry", {      
//begin v1.x content
	deleteButton: "[Избриши]"
//end v1.x content
});


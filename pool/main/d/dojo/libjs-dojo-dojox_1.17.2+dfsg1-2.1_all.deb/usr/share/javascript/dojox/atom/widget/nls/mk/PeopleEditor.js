define("dojox/atom/widget/nls/mk/PeopleEditor", {      
//begin v1.x content
	add: "Додај",
	addAuthor: "Додај автор",
	addContributor: "Додај соработник"
//end v1.x content
});


define(
"dojox/atom/widget/nls/nb/FeedViewerEntry", ({
	deleteButton: "[Slett]"
})
);

define(
"dojox/atom/widget/nls/nl/FeedEntryViewer", ({
	displayOptions: "[weergaveopties]",
	title: "Titel",
	authors: "Auteurs",
	contributors: "Deelnemers",
	id: "ID",
	close: "[sluiten]",
	updated: "Bijgewerkt",
	summary: "Overzicht",
	content: "Content"
})
);

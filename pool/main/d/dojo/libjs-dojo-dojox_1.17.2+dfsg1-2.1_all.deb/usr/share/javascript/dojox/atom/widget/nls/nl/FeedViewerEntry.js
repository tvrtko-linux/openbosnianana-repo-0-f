define(
"dojox/atom/widget/nls/nl/FeedViewerEntry", ({
	deleteButton: "[Wissen]"
})
);

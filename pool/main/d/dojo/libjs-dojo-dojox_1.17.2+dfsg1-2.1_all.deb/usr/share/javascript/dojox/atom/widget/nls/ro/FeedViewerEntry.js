define(
"dojox/atom/widget/nls/ro/FeedViewerEntry", ({
	deleteButton: "[Ştergere]"
})
);

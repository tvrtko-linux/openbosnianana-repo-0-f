define(
"dojox/atom/widget/nls/sk/FeedEntryViewer", ({
	displayOptions: "[voľby zobrazenia]",
	title: "Nadpis",
	authors: "Autori",
	contributors: "Prispievatelia",
	id: "ID",
	close: "[zatvoriť]",
	updated: "Aktualizované",
	summary: "Zhrnutie",
	content: "Obsah"
})
);

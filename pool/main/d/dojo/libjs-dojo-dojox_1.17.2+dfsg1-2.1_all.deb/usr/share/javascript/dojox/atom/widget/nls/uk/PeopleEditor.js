define(
"dojox/atom/widget/nls/uk/PeopleEditor", ({
	add: "Додати",
	addAuthor: "Додати автора",
	addContributor: "Додати учасника"
})
);

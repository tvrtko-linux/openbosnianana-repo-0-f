define(
"dojox/atom/widget/nls/zh-tw/FeedViewerEntry", ({
	deleteButton: "[刪除]"
})
);

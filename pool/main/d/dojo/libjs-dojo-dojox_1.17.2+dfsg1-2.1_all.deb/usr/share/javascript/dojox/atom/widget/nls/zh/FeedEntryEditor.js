define(
"dojox/atom/widget/nls/zh/FeedEntryEditor", ({
	doNew: "[新建]",
	edit: "[编辑]",
	save: "[保存]",
	cancel: "[取消]"
})
);

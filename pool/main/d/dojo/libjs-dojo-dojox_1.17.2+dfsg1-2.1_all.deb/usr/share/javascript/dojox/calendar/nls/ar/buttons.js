define( "dojox/calendar/nls/ar/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "اليوم",
	dayButton: "‏اليوم‏",
	weekButton: "أسبوع",
	fourDaysButton: "4 أيام",
	monthButton: "‏الشهر‏"
}
);

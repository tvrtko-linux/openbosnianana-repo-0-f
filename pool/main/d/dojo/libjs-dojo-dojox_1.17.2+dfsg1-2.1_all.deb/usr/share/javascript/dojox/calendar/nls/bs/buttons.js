define("dojox/calendar/nls/bs/buttons", {        
//begin v1.x content
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Danas",
	dayButton: "Dan",
	weekButton: "Sedmica",
	fourDaysButton: "4 dana",
	monthButton: "Mjesec"
//end v1.x content
});


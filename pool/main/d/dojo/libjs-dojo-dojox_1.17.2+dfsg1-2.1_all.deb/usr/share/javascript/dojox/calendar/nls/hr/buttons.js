define( "dojox/calendar/nls/hr/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Danas",
	dayButton: "Dan",
	weekButton: "Tjedan",
	fourDaysButton: "4 dana",
	monthButton: "Mjesec"
}
);

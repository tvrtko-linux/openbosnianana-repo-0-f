define( "dojox/calendar/nls/id/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Hari Ini",
	dayButton: "Hari",
	weekButton: "Minggu",
	fourDaysButton: "4 Hari",
	monthButton: "Bulan"
}
);


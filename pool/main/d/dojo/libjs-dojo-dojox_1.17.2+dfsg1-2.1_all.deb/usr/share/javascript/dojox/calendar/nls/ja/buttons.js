define( "dojox/calendar/nls/ja/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "今日",
	dayButton: "日",
	weekButton: "週",
	fourDaysButton: "4 日間",
	monthButton: "月"
}
);

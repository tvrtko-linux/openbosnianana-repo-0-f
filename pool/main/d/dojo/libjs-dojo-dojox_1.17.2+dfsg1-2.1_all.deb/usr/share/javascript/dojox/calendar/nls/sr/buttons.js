define("dojox/calendar/nls/sr/buttons", {        
//begin v1.x content
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Danas",
	dayButton: "Dan",
	weekButton: "Nedelja",
	fourDaysButton: "4 dana",
	monthButton: "Mesec"
//end v1.x content
});


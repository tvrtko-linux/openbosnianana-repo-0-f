define( "dojox/calendar/nls/sv/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "I dag",
	dayButton: "Dag",
	weekButton: "Vecka",
	fourDaysButton: "4 dagar",
	monthButton: "Månad"
}
);

define( "dojox/calendar/nls/tr/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Bugün",
	dayButton: "Gün",
	weekButton: "Hafta",
	fourDaysButton: "4 Gün",
	monthButton: "Ay"
}
);

define( "dojox/calendar/nls/zh-tw/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "今天",
	dayButton: "天",
	weekButton: "周",
	fourDaysButton: "4 天",
	monthButton: "月"
}
);

#ifndef __DOLFIN_REFINEMENT_H
#define __DOLFIN_REFINEMENT_H

// DOLFIN mesh refinement interface

#include <dolfin/refinement/refine.h>

#endif

#pragma once

// DOLFINX_MPC interface
#include <ContactConstraint.h>
#include <MultiPointConstraint.h>
#include <SlipConstraint.h>
#include <assemble_matrix.h>
#include <utils.h>
#include <lifting.h>
#include <assemble_vector.h>
# -*- coding: iso-8859-1 -*-
# this file is automatically created by setup.py
install_purelib = '/usr/lib/python3/dist-packages'
install_platlib = '/usr/lib/python3/dist-packages'
install_lib = '/usr/lib/python3/dist-packages'
install_headers = '/usr/include/python3.8/dosage'
install_scripts = '/usr/bin'
config_dir = '/usr/share/dosage'
install_data = '/usr'
name = 'dosage'
version = '2.15'
author = 'Tristan Seligmann, Jonathan Jacobs, Bastian Kleineidam, Tobias Gruetzmacher, Dirk Reiners'
author_email = 'UNKNOWN'
maintainer = 'Bastian Kleineidam'
maintainer_email = 'bastian.kleineidam@web.de'
url = 'http://wummel.github.io/dosage/'
license = 'MIT'
description = 'a comic strip downloader and archiver'
long_description = 'UNKNOWN'
keywords = ['comic', 'webcomic', 'downloader', 'archiver']
platforms = ['UNKNOWN']
fullname = 'dosage-2.15'
contact = 'Bastian Kleineidam'
contact_email = 'bastian.kleineidam@web.de'
release_date = "3.7.2014"

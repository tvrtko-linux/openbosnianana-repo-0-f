(** @canonical Dose_debian.Apt *)
module Apt = Dose_debian__Apt


(** @canonical Dose_debian.Architecture *)
module Architecture = Dose_debian__Architecture


(** @canonical Dose_debian.Debcudf *)
module Debcudf = Dose_debian__Debcudf


(** @canonical Dose_debian.Debutil *)
module Debutil = Dose_debian__Debutil


(** @canonical Dose_debian.Edsp *)
module Edsp = Dose_debian__Edsp


(** @canonical Dose_debian.Evolution *)
module Evolution = Dose_debian__Evolution


(** @canonical Dose_debian.Packages *)
module Packages = Dose_debian__Packages


(** @canonical Dose_debian.Release *)
module Release = Dose_debian__Release


(** @canonical Dose_debian.Sources *)
module Sources = Dose_debian__Sources

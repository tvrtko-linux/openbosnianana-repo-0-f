(** @canonical Dose_extra.Criteria *)
module Criteria = Dose_extra__Criteria


(** @canonical Dose_extra.Criteria_lexer *)
module Criteria_lexer = Dose_extra__Criteria_lexer


(** @canonical Dose_extra.Criteria_parser *)
module Criteria_parser = Dose_extra__Criteria_parser


(** @canonical Dose_extra.Criteria_types *)
module Criteria_types = Dose_extra__Criteria_types


(** @canonical Dose_extra.Format822 *)
module Format822 = Dose_extra__Format822


(** @canonical Dose_extra.Format822_lexer *)
module Format822_lexer = Dose_extra__Format822_lexer


(** @canonical Dose_extra.Format822_parser *)
module Format822_parser = Dose_extra__Format822_parser


(** @canonical Dose_extra.Input *)
module Input = Dose_extra__Input


(** @canonical Dose_extra.Url *)
module Url = Dose_extra__Url

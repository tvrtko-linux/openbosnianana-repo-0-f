(** @canonical Dose_npm.Npm_lexer *)
module Npm_lexer = Dose_npm__Npm_lexer


(** @canonical Dose_npm.Npm_parser *)
module Npm_parser = Dose_npm__Npm_parser


(** @canonical Dose_npm.Npmcudf *)
module Npmcudf = Dose_npm__Npmcudf


(** @canonical Dose_npm.Packages *)
module Packages = Dose_npm__Packages

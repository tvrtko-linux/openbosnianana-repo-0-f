type token =
  | TILDE
  | CARET
  | OR
  | EOL
  | HYPHEN
  | STAR
  | COMMA
  | COLON
  | QUOTE
  | LCURLY
  | RCURLY
  | IDENT of (string)
  | RELOP of (string)

open Parsing;;
let _ = parse_error;;
# 2 "src/npm/npm_parser.mly"

(*
range-set  ::= range ( logical-or range ) *
logical-or ::= ( ' ' ) * '||' ( ' ' ) *

range      ::= hyphen | simple ( ' ' simple ) * | ''

hyphen     ::= partial ' - ' partial

simple     ::= primitive | partial | tilde | caret
tilde      ::= '~' partial
caret      ::= '^' partial

primitive  ::= ( '<' | '>' | '>=' | '<=' | '=' | ) partial

partial    ::= xr ( '.' xr ( '.' xr qualifier ? )? )?
xr         ::= 'x' | 'X' | '*' | nr
nr         ::= '0' | ['1'-'9'] ( ['0'-'9'] ) *
qualifier  ::= ( '-' pre )? ( '+' build )?
pre        ::= parts
build      ::= parts
parts      ::= part ( '.' part ) *
part       ::= nr | [-0-9A-Za-z]+

*)

open Dose_versioning

(*type atom = (string * SemverNode.version) option*)

let incr_str x = string_of_int ((int_of_string x) + 1)
let range v1 v2 = [
  (Some (">=", SemverNode.compose v1));
  (Some ("<", SemverNode.compose v2)) ]

let normalize_version version =
  try
    match SemverNode.parse_raw_version version with
    | (("x"|"X"|"*"), "", "", pre, build) ->
        let v1 = SemverNode.convert ("0","0","0",pre,build) in
        [(Some (">=", SemverNode.compose v1))]
    | (("x"|"X"|"*"), ("x"|"X"|"*"), ("x"|"X"|"*"), pre, build) ->
        let v1 = SemverNode.convert ("0","0","0",pre,build) in
        [(Some (">=", SemverNode.compose v1))]
    | (("x"|"X"|"*"), ("x"|"X"|"*"), "", pre, build) ->
        let v1 = SemverNode.convert ("0","0","0",pre,build) in
        [(Some (">=", SemverNode.compose v1))]
    |(x1, ("x"|"*"), "", pre, build) ->
        let v1 = SemverNode.convert (x1,"0","0",pre,build) in
        let v2 = SemverNode.convert (incr_str x1,"0","0",pre,build) in
        range v1 v2

    |(x1, ("x"|"X"|"*"|""), ("x"|"X"|"*"|""), pre, build) ->
        let v1 = SemverNode.convert (x1,"0","0",pre,build) in
        let v2 = SemverNode.convert (incr_str x1,"0","0",pre,build) in
        range v1 v2

    |(x1, x2, ("x"|"X"|"*"|""), pre, build) ->
        let v1 = SemverNode.convert (x1,x2,"0",pre,build) in
        let v2 = SemverNode.convert (x1,incr_str x2,"0",pre,build) in
        range v1 v2

    |(("x"|"X"|"*"|" "), _, _, pre, build) ->
        let v1 = SemverNode.convert ("0","0","0",pre,build) in
        [(Some (">=", SemverNode.compose v1))]

    | (_, _, _, _, _) as v->
        [Some ("=", SemverNode.(compose (convert v)))]
  with Invalid_argument _ ->
    [Some ("=", version)]

let normalize_tilde version =
  match SemverNode.parse_raw_version version with
  | (x1,(""|"*"|"x"|"X"),(""|"*"|"x"|"X"),pre,build) ->
    let v1 = SemverNode.convert (x1,"0","0",pre,build) in
    let v2 = SemverNode.convert (incr_str x1,"0","0",[],[]) in
    range v1 v2

  | (x1,x2,(""|"*"|"x"|"X"),pre,build) ->
    let v1 = SemverNode.convert (x1,x2,"0",pre,build) in
    let v2 = SemverNode.convert (x1,incr_str x2,"0",[],[]) in
    range v1 v2

  | (x1,x2,_,_pre,_build) as parsed ->
    let v1 = SemverNode.convert parsed in
    let v2 = SemverNode.convert (x1,incr_str x2,"0",[],[]) in
    range v1 v2

let normalize_caret version =
  let caret_normal version =
    let parsed = SemverNode.parse_raw_version version in
    let two_zeros = ref false in
    let parsed_list =
      match parsed with
      | (x1,("x"|"X"|"*"|""),_,_,_) -> two_zeros := true; [x1; "0"; "0"]
      | (x1,x2,("x"|"X"|"*"|""),_,_) -> [x1; x2; "0"]
      | (x1,x2,x3,_,_) -> [x1; x2; x3]
    in
    let (major,minor,patch) =
      let found = ref false in
      let check_update n = if !found then "0" else (found := true; incr_str n) in
      let generate_range x = if x <> "0" then check_update x else "0" in
      let generated = List.map generate_range parsed_list in
      if List.for_all (fun x -> x = "0") generated then
        if !two_zeros then ("1", "0", "0")
        else ("0", "1", "0")
        else
          match generated with
          |[x1;x2;x3] -> (x1,x2,x3)
          |_ -> assert false
    in
    let v1 =
      match parsed_list with
      | [x1;x2;x3] -> SemverNode.convert (x1, x2, x3, [], [])
      | _          -> assert false
    in
    let v2 = SemverNode.convert (major,minor,patch,[],[]) in
    range v1 v2
  in
  let caret_star =
    let v1 = SemverNode.convert ("0","0","0",[],[]) in
    [(Some (">=", SemverNode.compose v1))]
  in
  if version = "*"
    then caret_star
    else caret_normal version


let normalize_hypen version1 version2 =
  let v1 = SemverNode.parse_version version1 in
  let v2 = SemverNode.parse_version version2 in
  range v1 v2

let normalize_primitive op version =
  try
    let v = SemverNode.parse_version version in
    [Some (op, SemverNode.compose v)]
  with Invalid_argument _ ->
    [List.nth (normalize_version version) 0]

let to_cnf ll =
  let return a = [a] in
  let bind m f = List.flatten (List.map f m) in
  let rec permutation = function
    |[] -> return []
    |h::t ->
        bind (permutation t) (fun t1 ->
          List.map (fun h1 -> h1 :: t1) h
        )
  in
  permutation ll

let normalize_depend name constr =
  List.map (fun conj ->
    List.map (fun c -> ((name,None),c)) conj
  ) (to_cnf constr)

# 177 "src/npm/npm_parser.ml"
let yytransl_const = [|
  257 (* TILDE *);
  258 (* CARET *);
  259 (* OR *);
  260 (* EOL *);
  261 (* HYPHEN *);
  262 (* STAR *);
  263 (* COMMA *);
  264 (* COLON *);
  265 (* QUOTE *);
  266 (* LCURLY *);
  267 (* RCURLY *);
    0|]

let yytransl_block = [|
  268 (* IDENT *);
  269 (* RELOP *);
    0|]

let yylhs = "\255\255\
\002\000\001\000\003\000\004\000\006\000\006\000\005\000\007\000\
\008\000\008\000\008\000\009\000\009\000\009\000\010\000\010\000\
\010\000\010\000\010\000\011\000\011\000\000\000\000\000\000\000"

let yylen = "\002\000\
\002\000\002\000\002\000\003\000\001\000\003\000\005\000\003\000\
\000\000\001\000\003\000\000\000\001\000\002\000\002\000\002\000\
\002\000\002\000\001\000\002\000\000\000\002\000\002\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\000\000\000\000\022\000\000\000\000\000\
\000\000\023\000\000\000\024\000\000\000\000\000\000\000\002\000\
\000\000\000\000\001\000\000\000\003\000\008\000\000\000\004\000\
\006\000\000\000\000\000\019\000\000\000\000\000\000\000\000\000\
\000\000\016\000\017\000\000\000\015\000\018\000\007\000\000\000\
\014\000\020\000\011\000"

let yydgoto = "\004\000\
\006\000\010\000\012\000\011\000\013\000\014\000\008\000\031\000\
\032\000\033\000\037\000"

let yysindex = "\023\000\
\250\254\253\254\250\254\000\000\006\255\000\000\015\255\019\255\
\250\254\000\000\024\255\000\000\022\255\026\255\023\255\000\000\
\025\255\020\255\000\000\250\254\000\000\000\000\008\255\000\000\
\000\000\021\255\027\255\000\000\030\255\028\255\029\255\033\255\
\008\255\000\000\000\000\031\255\000\000\000\000\000\000\008\255\
\000\000\000\000\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\002\255\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\013\255\000\000\
\000\000\000\000\000\000\000\000\255\254\000\000\000\000\032\255\
\014\255\000\000\000\000\000\000\000\000\000\000\000\000\013\255\
\000\000\000\000\000\000"

let yygindex = "\000\000\
\000\000\000\000\000\000\000\000\036\000\251\255\000\000\002\000\
\011\000\000\000\000\000"

let yytablesize = 44
let yytable = "\021\000\
\021\000\021\000\005\000\018\000\021\000\005\000\009\000\021\000\
\026\000\027\000\021\000\021\000\005\000\028\000\025\000\012\000\
\012\000\015\000\016\000\029\000\030\000\009\000\012\000\002\000\
\003\000\001\000\017\000\019\000\020\000\021\000\024\000\022\000\
\034\000\023\000\036\000\040\000\007\000\039\000\035\000\038\000\
\010\000\043\000\042\000\041\000"

let yycheck = "\001\001\
\002\001\003\001\009\001\009\000\006\001\004\001\010\001\009\001\
\001\001\002\001\012\001\013\001\011\001\006\001\020\000\003\001\
\003\001\012\001\004\001\012\001\013\001\009\001\009\001\001\000\
\002\000\003\000\008\001\004\001\007\001\004\001\011\001\009\001\
\012\001\009\001\005\001\003\001\001\000\009\001\012\001\012\001\
\009\001\040\000\012\001\033\000"

let yynames_const = "\
  TILDE\000\
  CARET\000\
  OR\000\
  EOL\000\
  HYPHEN\000\
  STAR\000\
  COMMA\000\
  COLON\000\
  QUOTE\000\
  LCURLY\000\
  RCURLY\000\
  "

let yynames_block = "\
  IDENT\000\
  RELOP\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'depends) in
    Obj.repr(
# 179 "src/npm/npm_parser.mly"
                           ( _1 )
# 282 "src/npm/npm_parser.ml"
               : Dose_pef.Packages_types.vpkgformula))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'depend) in
    Obj.repr(
# 181 "src/npm/npm_parser.mly"
                           ( _1 )
# 289 "src/npm/npm_parser.ml"
               : Dose_pef.Packages_types.vpkg list list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'dependlist) in
    Obj.repr(
# 182 "src/npm/npm_parser.mly"
                                 ( _1 )
# 296 "src/npm/npm_parser.ml"
               : Dose_pef.Packages_types.vpkgformula))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'dependlist) in
    Obj.repr(
# 184 "src/npm/npm_parser.mly"
                                  ( _2 )
# 303 "src/npm/npm_parser.ml"
               : 'depends))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'depend) in
    Obj.repr(
# 187 "src/npm/npm_parser.mly"
                          ( _1 )
# 310 "src/npm/npm_parser.ml"
               : 'dependlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'depend) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'dependlist) in
    Obj.repr(
# 188 "src/npm/npm_parser.mly"
                            ( _1 @ _3 )
# 318 "src/npm/npm_parser.ml"
               : 'dependlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : 'name) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'rangelist) in
    Obj.repr(
# 192 "src/npm/npm_parser.mly"
                                   ( normalize_depend _1 _4 (* vpkgformula *) )
# 326 "src/npm/npm_parser.ml"
               : 'depend))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : string) in
    Obj.repr(
# 195 "src/npm/npm_parser.mly"
                            ( _2 )
# 333 "src/npm/npm_parser.ml"
               : 'name))
; (fun __caml_parser_env ->
    Obj.repr(
# 199 "src/npm/npm_parser.mly"
                            ( [] )
# 339 "src/npm/npm_parser.ml"
               : 'rangelist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'simplelist) in
    Obj.repr(
# 200 "src/npm/npm_parser.mly"
                            ( [_1] )
# 346 "src/npm/npm_parser.ml"
               : 'rangelist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'simplelist) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'rangelist) in
    Obj.repr(
# 201 "src/npm/npm_parser.mly"
                            ( _1 :: _3 (*vpkg list list *) )
# 354 "src/npm/npm_parser.ml"
               : 'rangelist))
; (fun __caml_parser_env ->
    Obj.repr(
# 205 "src/npm/npm_parser.mly"
                             ( [] )
# 360 "src/npm/npm_parser.ml"
               : 'simplelist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'partial) in
    Obj.repr(
# 206 "src/npm/npm_parser.mly"
                             ( _1 )
# 367 "src/npm/npm_parser.ml"
               : 'simplelist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'partial) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'simplelist) in
    Obj.repr(
# 207 "src/npm/npm_parser.mly"
                             ( _1 @ _2 (* vpkg list *) )
# 375 "src/npm/npm_parser.ml"
               : 'simplelist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'range) in
    Obj.repr(
# 211 "src/npm/npm_parser.mly"
                      ( match _2 with
                        |None    -> normalize_version _1 (* vpkg list *)
                        |Some v2 -> normalize_hypen _1 v2
                      )
# 386 "src/npm/npm_parser.ml"
               : 'partial))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 215 "src/npm/npm_parser.mly"
                      ( normalize_tilde _2 )
# 393 "src/npm/npm_parser.ml"
               : 'partial))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 216 "src/npm/npm_parser.mly"
                      ( normalize_caret _2 )
# 400 "src/npm/npm_parser.ml"
               : 'partial))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 217 "src/npm/npm_parser.mly"
                      ( normalize_primitive _1 _2 )
# 408 "src/npm/npm_parser.ml"
               : 'partial))
; (fun __caml_parser_env ->
    Obj.repr(
# 218 "src/npm/npm_parser.mly"
                      ( [None] )
# 414 "src/npm/npm_parser.ml"
               : 'partial))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 222 "src/npm/npm_parser.mly"
                      ( Some _2 )
# 421 "src/npm/npm_parser.ml"
               : 'range))
; (fun __caml_parser_env ->
    Obj.repr(
# 223 "src/npm/npm_parser.mly"
                      ( None )
# 427 "src/npm/npm_parser.ml"
               : 'range))
(* Entry depend_top *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry depends_top *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry dependlist_top *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let depend_top (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 3 lexfun lexbuf : Dose_pef.Packages_types.vpkg list list)
let depends_top (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : Dose_pef.Packages_types.vpkgformula)
let dependlist_top (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 2 lexfun lexbuf : Dose_pef.Packages_types.vpkgformula)
;;
# 226 "src/npm/npm_parser.mly"

open Dose_extra

let dependlist_top = Format822.error_wrapper "dependlist" dependlist_top
let depends_top = Format822.error_wrapper "depends" depends_top
let depend_top = Format822.error_wrapper "depend" depend_top


# 469 "src/npm/npm_parser.ml"

(** @canonical Dose_opam2.Opamcudf *)
module Opamcudf = Dose_opam2__Opamcudf


(** @canonical Dose_opam2.Packages *)
module Packages = Dose_opam2__Packages

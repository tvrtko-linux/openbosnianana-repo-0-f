(** @canonical Dose_opencsw.Cswcudf *)
module Cswcudf = Dose_opencsw__Cswcudf


(** @canonical Dose_opencsw.Packages *)
module Packages = Dose_opencsw__Packages

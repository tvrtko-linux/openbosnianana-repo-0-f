(** @canonical Dose_pef.Packages *)
module Packages = Dose_pef__Packages


(** @canonical Dose_pef.Packages_lexer *)
module Packages_lexer = Dose_pef__Packages_lexer


(** @canonical Dose_pef.Packages_parser *)
module Packages_parser = Dose_pef__Packages_parser


(** @canonical Dose_pef.Packages_types *)
module Packages_types = Dose_pef__Packages_types


(** @canonical Dose_pef.Pefcudf *)
module Pefcudf = Dose_pef__Pefcudf


(** @canonical Dose_pef.Printer *)
module Printer = Dose_pef__Printer

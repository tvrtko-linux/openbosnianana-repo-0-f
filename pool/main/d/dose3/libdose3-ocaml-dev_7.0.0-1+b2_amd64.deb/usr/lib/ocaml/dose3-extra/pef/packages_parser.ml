type token =
  | IDENT of (string)
  | VIDENT of (string)
  | STRING of (string)
  | RELOP of (string)
  | LBRACKET
  | RBRACKET
  | LPAREN
  | RPAREN
  | LT
  | GT
  | COMMA
  | PIPE
  | EQ
  | BANG
  | PLUS
  | MINUS
  | COLON
  | SLASH
  | EOL

open Parsing;;
let _ = parse_error;;
# 3 "src/pef/packages_parser.mly"

open ExtLib
open Dose_common
open Dose_extra

(* hash cons table *)
let h = Util.StringHashtbl.create 10000

let parse_vpkgname name =
  try
    match String.split name ":" with
    |n,"any" -> (n,Some "any")
    |n,"native" -> (n,Some "native")
    |_,"" -> raise Parsing.Parse_error
    |n,a -> (n,Some a)
  with ExtString.Invalid_string -> (name,None)

# 43 "src/pef/packages_parser.ml"
let yytransl_const = [|
  261 (* LBRACKET *);
  262 (* RBRACKET *);
  263 (* LPAREN *);
  264 (* RPAREN *);
  265 (* LT *);
  266 (* GT *);
  267 (* COMMA *);
  268 (* PIPE *);
  269 (* EQ *);
  270 (* BANG *);
  271 (* PLUS *);
  272 (* MINUS *);
  273 (* COLON *);
  274 (* SLASH *);
  275 (* EOL *);
    0|]

let yytransl_block = [|
  257 (* IDENT *);
  258 (* VIDENT *);
  259 (* STRING *);
  260 (* RELOP *);
    0|]

let yylhs = "\255\255\
\001\000\002\000\004\000\005\000\006\000\007\000\008\000\009\000\
\010\000\012\000\011\000\003\000\013\000\014\000\015\000\015\000\
\025\000\025\000\025\000\025\000\016\000\026\000\026\000\017\000\
\018\000\018\000\027\000\027\000\019\000\019\000\019\000\028\000\
\028\000\028\000\029\000\029\000\029\000\029\000\021\000\021\000\
\032\000\032\000\032\000\020\000\020\000\020\000\033\000\033\000\
\033\000\034\000\034\000\030\000\030\000\035\000\035\000\031\000\
\031\000\036\000\036\000\038\000\038\000\037\000\037\000\039\000\
\039\000\039\000\024\000\024\000\040\000\040\000\023\000\023\000\
\023\000\041\000\041\000\041\000\022\000\022\000\042\000\042\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000"

let yylen = "\002\000\
\002\000\002\000\002\000\002\000\002\000\002\000\002\000\002\000\
\002\000\002\000\002\000\002\000\001\000\001\000\001\000\004\000\
\001\000\001\000\001\000\001\000\001\000\000\000\004\000\002\000\
\000\000\001\000\001\000\003\000\000\000\001\000\003\000\000\000\
\001\000\003\000\001\000\004\000\002\000\005\000\000\000\001\000\
\000\000\001\000\003\000\000\000\001\000\003\000\000\000\001\000\
\003\000\002\000\001\000\000\000\001\000\001\000\002\000\000\000\
\001\000\003\000\004\000\002\000\001\000\000\000\001\000\000\000\
\001\000\002\000\000\000\001\000\001\000\002\000\002\000\002\000\
\001\000\001\000\003\000\003\000\000\000\001\000\001\000\002\000\
\002\000\002\000\002\000\002\000\002\000\002\000\002\000\002\000\
\002\000\002\000\002\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\013\000\081\000\000\000\
\014\000\082\000\000\000\000\000\083\000\000\000\068\000\000\000\
\084\000\000\000\021\000\085\000\000\000\086\000\000\000\000\000\
\087\000\000\000\000\000\026\000\088\000\000\000\000\000\000\000\
\089\000\000\000\000\000\000\000\000\000\090\000\000\000\000\000\
\040\000\000\000\000\000\091\000\000\000\000\000\073\000\092\000\
\000\000\000\000\078\000\001\000\002\000\070\000\012\000\000\000\
\003\000\004\000\000\000\024\000\005\000\000\000\006\000\000\000\
\007\000\000\000\000\000\000\000\037\000\057\000\008\000\000\000\
\000\000\009\000\000\000\071\000\072\000\000\000\000\000\011\000\
\010\000\080\000\000\000\017\000\018\000\019\000\020\000\000\000\
\028\000\034\000\031\000\051\000\000\000\000\000\000\000\053\000\
\061\000\000\000\000\000\000\000\063\000\049\000\046\000\043\000\
\075\000\076\000\016\000\000\000\050\000\000\000\055\000\060\000\
\000\000\066\000\023\000\038\000\059\000"

let yydgoto = "\013\000\
\015\000\018\000\021\000\025\000\028\000\030\000\033\000\037\000\
\041\000\046\000\052\000\056\000\016\000\019\000\026\000\031\000\
\042\000\035\000\039\000\043\000\047\000\057\000\058\000\022\000\
\096\000\068\000\036\000\040\000\044\000\102\000\077\000\049\000\
\045\000\103\000\104\000\078\000\107\000\108\000\109\000\023\000\
\055\000\059\000"

let yysindex = "\073\000\
\015\255\018\255\032\255\035\255\042\255\042\255\042\255\042\255\
\042\255\042\255\007\255\007\255\000\000\000\000\000\000\044\255\
\000\000\000\000\049\255\032\255\000\000\051\255\000\000\064\255\
\000\000\053\255\000\000\000\000\067\255\000\000\080\255\069\255\
\000\000\078\255\071\255\000\000\000\000\079\255\073\255\082\255\
\000\000\009\255\075\255\083\255\085\255\000\000\081\255\086\255\
\000\000\042\255\042\255\000\000\250\254\084\255\000\000\000\000\
\087\255\007\255\000\000\000\000\000\000\000\000\000\000\018\255\
\000\000\000\000\031\255\000\000\000\000\042\255\000\000\042\255\
\000\000\042\255\012\255\014\255\000\000\000\000\000\000\042\255\
\042\255\000\000\042\255\000\000\000\000\018\255\097\255\000\000\
\000\000\000\000\091\255\000\000\000\000\000\000\000\000\018\255\
\000\000\000\000\000\000\000\000\100\255\096\255\012\255\000\000\
\000\000\103\255\095\255\014\255\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\099\255\000\000\101\255\000\000\000\000\
\101\255\000\000\000\000\000\000\000\000"

let yyrindex = "\000\000\
\000\000\000\000\089\255\000\000\000\000\000\000\090\255\254\254\
\019\255\092\255\000\000\093\255\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\069\255\000\000\000\000\000\000\094\255\
\000\000\000\000\000\000\000\000\000\000\000\000\020\255\000\000\
\000\000\098\255\000\000\000\000\000\000\023\255\000\000\102\255\
\000\000\034\255\000\000\043\255\104\255\000\000\000\000\105\255\
\000\000\000\000\000\000\000\000\005\255\000\000\000\000\000\000\
\000\000\075\255\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\045\255\
\000\000\254\254\108\255\106\255\000\000\000\000\000\000\047\255\
\019\255\000\000\107\255\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\109\255\000\000\
\000\000\000\000\000\000\110\255\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\036\255\000\000\000\000\
\040\255\000\000\000\000\000\000\000\000"

let yygindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\197\255\000\000\255\255\
\251\255\000\000\044\000\038\000\000\000\000\000\111\000\000\000\
\000\000\000\000\055\000\056\000\246\255\000\000\009\000\046\000\
\050\000\000\000\028\000\011\000\000\000\000\000\025\000\114\000\
\010\000\077\000"

let yytablesize = 135
let yytable = "\048\000\
\032\000\034\000\038\000\029\000\091\000\074\000\086\000\027\000\
\032\000\053\000\053\000\087\000\100\000\075\000\105\000\014\000\
\029\000\076\000\017\000\074\000\074\000\050\000\051\000\074\000\
\022\000\101\000\113\000\106\000\022\000\047\000\022\000\022\000\
\020\000\033\000\092\000\024\000\116\000\044\000\022\000\093\000\
\094\000\033\000\027\000\095\000\035\000\035\000\036\000\036\000\
\053\000\053\000\058\000\058\000\035\000\048\000\036\000\032\000\
\053\000\047\000\058\000\084\000\085\000\048\000\060\000\032\000\
\034\000\047\000\038\000\061\000\038\000\063\000\064\000\065\000\
\048\000\001\000\002\000\004\000\005\000\006\000\007\000\008\000\
\009\000\010\000\011\000\012\000\003\000\066\000\067\000\069\000\
\070\000\071\000\072\000\073\000\074\000\079\000\080\000\081\000\
\083\000\114\000\115\000\082\000\117\000\118\000\088\000\120\000\
\121\000\089\000\123\000\067\000\025\000\076\000\039\000\077\000\
\015\000\052\000\054\000\062\000\027\000\099\000\111\000\064\000\
\030\000\054\000\045\000\042\000\097\000\041\000\124\000\098\000\
\112\000\110\000\119\000\125\000\122\000\062\000\090\000"

let yycheck = "\010\000\
\006\000\007\000\008\000\005\000\064\000\001\001\013\001\001\001\
\011\001\011\000\012\000\018\001\001\001\005\001\001\001\001\001\
\019\001\009\001\001\001\015\001\016\001\015\001\016\001\019\001\
\005\001\014\001\086\000\014\001\009\001\011\001\011\001\012\001\
\001\001\011\001\004\001\001\001\096\000\019\001\019\001\009\001\
\010\001\019\001\001\001\013\001\011\001\012\001\011\001\012\001\
\050\000\051\000\011\001\012\001\019\001\011\001\019\001\011\001\
\058\000\011\001\019\001\050\000\051\000\019\001\019\001\019\001\
\070\000\019\001\072\000\019\001\074\000\019\001\007\001\019\001\
\083\000\001\000\002\000\003\000\004\000\005\000\006\000\007\000\
\008\000\009\000\010\000\011\000\012\000\019\001\007\001\019\001\
\011\001\019\001\012\001\019\001\011\001\019\001\012\001\011\001\
\011\001\001\001\008\001\019\001\001\001\006\001\019\001\001\001\
\010\001\019\001\008\001\019\001\019\001\009\001\019\001\019\001\
\019\001\006\001\006\001\010\001\019\001\074\000\081\000\010\001\
\019\001\011\000\019\001\019\001\070\000\019\001\118\000\072\000\
\083\000\080\000\103\000\121\000\108\000\020\000\058\000"

let yynames_const = "\
  LBRACKET\000\
  RBRACKET\000\
  LPAREN\000\
  RPAREN\000\
  LT\000\
  GT\000\
  COMMA\000\
  PIPE\000\
  EQ\000\
  BANG\000\
  PLUS\000\
  MINUS\000\
  COLON\000\
  SLASH\000\
  EOL\000\
  "

let yynames_block = "\
  IDENT\000\
  VIDENT\000\
  STRING\000\
  RELOP\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'pkgname) in
    Obj.repr(
# 53 "src/pef/packages_parser.mly"
                         ( _1 )
# 238 "src/pef/packages_parser.ml"
               : Packages_types.name))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'version) in
    Obj.repr(
# 54 "src/pef/packages_parser.mly"
                         ( _1 )
# 245 "src/pef/packages_parser.ml"
               : Packages_types.version))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'source) in
    Obj.repr(
# 55 "src/pef/packages_parser.mly"
                       ( _1 )
# 252 "src/pef/packages_parser.ml"
               : Packages_types.source))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'vpkgname) in
    Obj.repr(
# 57 "src/pef/packages_parser.mly"
                           ( _1 )
# 259 "src/pef/packages_parser.ml"
               : Packages_types.vpkgname))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'vpkg) in
    Obj.repr(
# 58 "src/pef/packages_parser.mly"
                   ( _1 )
# 266 "src/pef/packages_parser.ml"
               : Packages_types.vpkg))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'vpkglist) in
    Obj.repr(
# 60 "src/pef/packages_parser.mly"
                           ( _1 )
# 273 "src/pef/packages_parser.ml"
               : Packages_types.vpkglist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'vpkgformula) in
    Obj.repr(
# 61 "src/pef/packages_parser.mly"
                                 ( _1 )
# 280 "src/pef/packages_parser.ml"
               : Packages_types.vpkgformula))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'builddepsformula) in
    Obj.repr(
# 63 "src/pef/packages_parser.mly"
                                           ( _1 )
# 287 "src/pef/packages_parser.ml"
               : Packages_types.builddepsformula))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'builddepslist) in
    Obj.repr(
# 64 "src/pef/packages_parser.mly"
                                     ( _1 )
# 294 "src/pef/packages_parser.ml"
               : Packages_types.builddepslist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'reqlist) in
    Obj.repr(
# 66 "src/pef/packages_parser.mly"
                             ( _1 )
# 301 "src/pef/packages_parser.ml"
               : Packages_types.vpkgreq list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'request) in
    Obj.repr(
# 67 "src/pef/packages_parser.mly"
                         ( _1 )
# 308 "src/pef/packages_parser.ml"
               : Packages_types.vpkgreq))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'archlist) in
    Obj.repr(
# 68 "src/pef/packages_parser.mly"
                           ( _1 )
# 315 "src/pef/packages_parser.ml"
               : Packages_types.architecture list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 72 "src/pef/packages_parser.mly"
               ( _1 )
# 322 "src/pef/packages_parser.ml"
               : 'pkgname))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 73 "src/pef/packages_parser.mly"
               ( Util.hashcons h _1 )
# 329 "src/pef/packages_parser.ml"
               : 'version))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 76 "src/pef/packages_parser.mly"
                                ( (_1,None) )
# 336 "src/pef/packages_parser.ml"
               : 'source))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 3 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'version) in
    Obj.repr(
# 77 "src/pef/packages_parser.mly"
                                ( (_1,Some (_3)) )
# 344 "src/pef/packages_parser.ml"
               : 'source))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 80 "src/pef/packages_parser.mly"
                ( _1 )
# 351 "src/pef/packages_parser.ml"
               : 'relop))
; (fun __caml_parser_env ->
    Obj.repr(
# 81 "src/pef/packages_parser.mly"
                ( "<" )
# 357 "src/pef/packages_parser.ml"
               : 'relop))
; (fun __caml_parser_env ->
    Obj.repr(
# 82 "src/pef/packages_parser.mly"
                ( ">" )
# 363 "src/pef/packages_parser.ml"
               : 'relop))
; (fun __caml_parser_env ->
    Obj.repr(
# 83 "src/pef/packages_parser.mly"
                ( "=" )
# 369 "src/pef/packages_parser.ml"
               : 'relop))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 88 "src/pef/packages_parser.mly"
                ( parse_vpkgname _1 )
# 376 "src/pef/packages_parser.ml"
               : 'vpkgname))
; (fun __caml_parser_env ->
    Obj.repr(
# 91 "src/pef/packages_parser.mly"
                               ( None )
# 382 "src/pef/packages_parser.ml"
               : 'constr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : 'relop) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'version) in
    Obj.repr(
# 92 "src/pef/packages_parser.mly"
                               ( Some (_2, _3) )
# 390 "src/pef/packages_parser.ml"
               : 'constr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'vpkgname) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'constr) in
    Obj.repr(
# 95 "src/pef/packages_parser.mly"
                      ( (_1, _2) )
# 398 "src/pef/packages_parser.ml"
               : 'vpkg))
; (fun __caml_parser_env ->
    Obj.repr(
# 98 "src/pef/packages_parser.mly"
                ( [] )
# 404 "src/pef/packages_parser.ml"
               : 'vpkglist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'vpkglist_ne) in
    Obj.repr(
# 99 "src/pef/packages_parser.mly"
                ( _1 )
# 411 "src/pef/packages_parser.ml"
               : 'vpkglist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'vpkg) in
    Obj.repr(
# 103 "src/pef/packages_parser.mly"
                                ( [ _1 ] )
# 418 "src/pef/packages_parser.ml"
               : 'vpkglist_ne))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'vpkg) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'vpkglist_ne) in
    Obj.repr(
# 104 "src/pef/packages_parser.mly"
                                ( _1 :: _3 )
# 426 "src/pef/packages_parser.ml"
               : 'vpkglist_ne))
; (fun __caml_parser_env ->
    Obj.repr(
# 108 "src/pef/packages_parser.mly"
                                  ( [ ] )
# 432 "src/pef/packages_parser.ml"
               : 'vpkgformula))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'or_formula) in
    Obj.repr(
# 109 "src/pef/packages_parser.mly"
                                  ( [ _1 ] )
# 439 "src/pef/packages_parser.ml"
               : 'vpkgformula))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'or_formula) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'vpkgformula) in
    Obj.repr(
# 110 "src/pef/packages_parser.mly"
                                  ( _1 :: _3 )
# 447 "src/pef/packages_parser.ml"
               : 'vpkgformula))
; (fun __caml_parser_env ->
    Obj.repr(
# 114 "src/pef/packages_parser.mly"
                                ( [ ] )
# 453 "src/pef/packages_parser.ml"
               : 'or_formula))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'vpkg) in
    Obj.repr(
# 115 "src/pef/packages_parser.mly"
                                ( [ _1 ] )
# 460 "src/pef/packages_parser.ml"
               : 'or_formula))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'vpkg) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'or_formula) in
    Obj.repr(
# 116 "src/pef/packages_parser.mly"
                                ( _1 :: _3 )
# 468 "src/pef/packages_parser.ml"
               : 'or_formula))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'vpkg) in
    Obj.repr(
# 122 "src/pef/packages_parser.mly"
                                        ( (_1,[],[]) )
# 475 "src/pef/packages_parser.ml"
               : 'buidldep))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 3 : 'vpkg) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'buildarchlist) in
    Obj.repr(
# 123 "src/pef/packages_parser.mly"
                                        ( (_1,_3,[]) )
# 483 "src/pef/packages_parser.ml"
               : 'buidldep))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'vpkg) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'buildprofileformula) in
    Obj.repr(
# 124 "src/pef/packages_parser.mly"
                                        ( (_1,[],_2) )
# 491 "src/pef/packages_parser.ml"
               : 'buidldep))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : 'vpkg) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'buildarchlist) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'buildprofileformula) in
    Obj.repr(
# 125 "src/pef/packages_parser.mly"
                                                            ( (_1,_3,_5) )
# 500 "src/pef/packages_parser.ml"
               : 'buidldep))
; (fun __caml_parser_env ->
    Obj.repr(
# 129 "src/pef/packages_parser.mly"
                     ( [] )
# 506 "src/pef/packages_parser.ml"
               : 'builddepslist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'builddepslist_ne) in
    Obj.repr(
# 130 "src/pef/packages_parser.mly"
                     ( _1 )
# 513 "src/pef/packages_parser.ml"
               : 'builddepslist))
; (fun __caml_parser_env ->
    Obj.repr(
# 134 "src/pef/packages_parser.mly"
                                     ( [ ] )
# 519 "src/pef/packages_parser.ml"
               : 'builddepslist_ne))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'buidldep) in
    Obj.repr(
# 135 "src/pef/packages_parser.mly"
                                     ( [ _1 ] )
# 526 "src/pef/packages_parser.ml"
               : 'builddepslist_ne))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'buidldep) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'builddepslist_ne) in
    Obj.repr(
# 136 "src/pef/packages_parser.mly"
                                     ( _1 :: _3 )
# 534 "src/pef/packages_parser.ml"
               : 'builddepslist_ne))
; (fun __caml_parser_env ->
    Obj.repr(
# 140 "src/pef/packages_parser.mly"
                                                   ( [ ] )
# 540 "src/pef/packages_parser.ml"
               : 'builddepsformula))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'builddeps_or_formula) in
    Obj.repr(
# 141 "src/pef/packages_parser.mly"
                                                   ( [ _1 ] )
# 547 "src/pef/packages_parser.ml"
               : 'builddepsformula))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'builddeps_or_formula) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'builddepsformula) in
    Obj.repr(
# 142 "src/pef/packages_parser.mly"
                                                   ( _1 :: _3 )
# 555 "src/pef/packages_parser.ml"
               : 'builddepsformula))
; (fun __caml_parser_env ->
    Obj.repr(
# 146 "src/pef/packages_parser.mly"
                                         ( [ ] )
# 561 "src/pef/packages_parser.ml"
               : 'builddeps_or_formula))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'buidldep) in
    Obj.repr(
# 147 "src/pef/packages_parser.mly"
                                         ( [ _1 ] )
# 568 "src/pef/packages_parser.ml"
               : 'builddeps_or_formula))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'buidldep) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'builddeps_or_formula) in
    Obj.repr(
# 148 "src/pef/packages_parser.mly"
                                         ( _1 :: _3 )
# 576 "src/pef/packages_parser.ml"
               : 'builddeps_or_formula))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 154 "src/pef/packages_parser.mly"
                           ( (false,_2) )
# 583 "src/pef/packages_parser.ml"
               : 'buildarch))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 155 "src/pef/packages_parser.mly"
                           ( (true,_1)  )
# 590 "src/pef/packages_parser.ml"
               : 'buildarch))
; (fun __caml_parser_env ->
    Obj.repr(
# 159 "src/pef/packages_parser.mly"
                     ( [] )
# 596 "src/pef/packages_parser.ml"
               : 'buildarchlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'buildarchlist_ne) in
    Obj.repr(
# 160 "src/pef/packages_parser.mly"
                     ( _1 )
# 603 "src/pef/packages_parser.ml"
               : 'buildarchlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'buildarch) in
    Obj.repr(
# 164 "src/pef/packages_parser.mly"
                               ( [ _1 ] )
# 610 "src/pef/packages_parser.ml"
               : 'buildarchlist_ne))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'buildarch) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'buildarchlist_ne) in
    Obj.repr(
# 165 "src/pef/packages_parser.mly"
                               ( _1 :: _2 )
# 618 "src/pef/packages_parser.ml"
               : 'buildarchlist_ne))
; (fun __caml_parser_env ->
    Obj.repr(
# 171 "src/pef/packages_parser.mly"
                           ( [] )
# 624 "src/pef/packages_parser.ml"
               : 'buildprofileformula))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'buildprofileformula_ne) in
    Obj.repr(
# 172 "src/pef/packages_parser.mly"
                           ( _1 )
# 631 "src/pef/packages_parser.ml"
               : 'buildprofileformula))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'buildprofilelist) in
    Obj.repr(
# 176 "src/pef/packages_parser.mly"
                           ( [ _2 ] )
# 638 "src/pef/packages_parser.ml"
               : 'buildprofileformula_ne))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : 'buildprofilelist) in
    let _4 = (Parsing.peek_val __caml_parser_env 0 : 'buildprofileformula_ne) in
    Obj.repr(
# 177 "src/pef/packages_parser.mly"
                                                  ( _2 :: _4 )
# 646 "src/pef/packages_parser.ml"
               : 'buildprofileformula_ne))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 181 "src/pef/packages_parser.mly"
                           ( (false,_2) )
# 653 "src/pef/packages_parser.ml"
               : 'buildprofile))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 182 "src/pef/packages_parser.mly"
                           ( (true,_1)  )
# 660 "src/pef/packages_parser.ml"
               : 'buildprofile))
; (fun __caml_parser_env ->
    Obj.repr(
# 186 "src/pef/packages_parser.mly"
                        ( [] )
# 666 "src/pef/packages_parser.ml"
               : 'buildprofilelist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'buildprofilelist_ne) in
    Obj.repr(
# 187 "src/pef/packages_parser.mly"
                        ( _1 )
# 673 "src/pef/packages_parser.ml"
               : 'buildprofilelist))
; (fun __caml_parser_env ->
    Obj.repr(
# 191 "src/pef/packages_parser.mly"
                                      ( [ ] )
# 679 "src/pef/packages_parser.ml"
               : 'buildprofilelist_ne))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'buildprofile) in
    Obj.repr(
# 192 "src/pef/packages_parser.mly"
                                      ( [ _1 ] )
# 686 "src/pef/packages_parser.ml"
               : 'buildprofilelist_ne))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'buildprofile) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'buildprofilelist_ne) in
    Obj.repr(
# 193 "src/pef/packages_parser.mly"
                                      ( _1 :: _2 )
# 694 "src/pef/packages_parser.ml"
               : 'buildprofilelist_ne))
; (fun __caml_parser_env ->
    Obj.repr(
# 199 "src/pef/packages_parser.mly"
                ( [] )
# 700 "src/pef/packages_parser.ml"
               : 'archlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'archlist_ne) in
    Obj.repr(
# 200 "src/pef/packages_parser.mly"
                ( _1 )
# 707 "src/pef/packages_parser.ml"
               : 'archlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 204 "src/pef/packages_parser.mly"
                            ( [ _1 ] )
# 714 "src/pef/packages_parser.ml"
               : 'archlist_ne))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'archlist_ne) in
    Obj.repr(
# 205 "src/pef/packages_parser.mly"
                            ( _1 :: _2 )
# 722 "src/pef/packages_parser.ml"
               : 'archlist_ne))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'req_aux) in
    Obj.repr(
# 211 "src/pef/packages_parser.mly"
                        ( let (vpkg,suite) = _2 in (Some Packages_types.I,vpkg,suite) )
# 729 "src/pef/packages_parser.ml"
               : 'request))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'req_aux) in
    Obj.repr(
# 212 "src/pef/packages_parser.mly"
                        ( let (vpkg,suite) = _2 in (Some Packages_types.R,vpkg,suite) )
# 736 "src/pef/packages_parser.ml"
               : 'request))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'req_aux) in
    Obj.repr(
# 213 "src/pef/packages_parser.mly"
                        ( let (vpkg,suite) = _1 in (None,vpkg,suite) )
# 743 "src/pef/packages_parser.ml"
               : 'request))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'vpkgname) in
    Obj.repr(
# 217 "src/pef/packages_parser.mly"
                         ( ((_1,None),None) )
# 750 "src/pef/packages_parser.ml"
               : 'req_aux))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'vpkgname) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'version) in
    Obj.repr(
# 218 "src/pef/packages_parser.mly"
                         ( ((_1,Some("=",_3)),None) )
# 758 "src/pef/packages_parser.ml"
               : 'req_aux))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'vpkgname) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 219 "src/pef/packages_parser.mly"
                         ( ((_1,None),Some _3) )
# 766 "src/pef/packages_parser.ml"
               : 'req_aux))
; (fun __caml_parser_env ->
    Obj.repr(
# 223 "src/pef/packages_parser.mly"
               ( [] )
# 772 "src/pef/packages_parser.ml"
               : 'reqlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'reqlist_ne) in
    Obj.repr(
# 224 "src/pef/packages_parser.mly"
               ( _1 )
# 779 "src/pef/packages_parser.ml"
               : 'reqlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'request) in
    Obj.repr(
# 228 "src/pef/packages_parser.mly"
                            ( [ _1 ] )
# 786 "src/pef/packages_parser.ml"
               : 'reqlist_ne))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'request) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'reqlist_ne) in
    Obj.repr(
# 229 "src/pef/packages_parser.mly"
                            ( _1 :: _2 )
# 794 "src/pef/packages_parser.ml"
               : 'reqlist_ne))
(* Entry pkgname_top *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry version_top *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry archlist_top *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry source_top *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry vpkgname_top *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry vpkg_top *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry vpkglist_top *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry vpkgformula_top *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry builddepsformula_top *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry builddepslist_top *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry request_top *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
(* Entry requestlist_top *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let pkgname_top (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : Packages_types.name)
let version_top (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 2 lexfun lexbuf : Packages_types.version)
let archlist_top (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 12 lexfun lexbuf : Packages_types.architecture list)
let source_top (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 3 lexfun lexbuf : Packages_types.source)
let vpkgname_top (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 4 lexfun lexbuf : Packages_types.vpkgname)
let vpkg_top (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 5 lexfun lexbuf : Packages_types.vpkg)
let vpkglist_top (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 6 lexfun lexbuf : Packages_types.vpkglist)
let vpkgformula_top (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 7 lexfun lexbuf : Packages_types.vpkgformula)
let builddepsformula_top (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 8 lexfun lexbuf : Packages_types.builddepsformula)
let builddepslist_top (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 9 lexfun lexbuf : Packages_types.builddepslist)
let request_top (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 10 lexfun lexbuf : Packages_types.vpkgreq)
let requestlist_top (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 11 lexfun lexbuf : Packages_types.vpkgreq list)
;;
# 233 "src/pef/packages_parser.mly"

let pkgname_top = Format822.error_wrapper "pkgname" pkgname_top
let version_top = Format822.error_wrapper "version" version_top
let vpkg_top = Format822.error_wrapper "vpkg" vpkg_top
let vpkglist_top = Format822.error_wrapper "vpkglist" vpkglist_top
let vpkgformula_top = Format822.error_wrapper "vpkgformula" vpkgformula_top
let source_top = Format822.error_wrapper "source" source_top
let request_top = Format822.error_wrapper "request" request_top
let requestlist_top = Format822.error_wrapper "requestlist" requestlist_top
# 873 "src/pef/packages_parser.ml"

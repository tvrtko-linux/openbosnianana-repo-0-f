(** @canonical Dose_algo.Defaultgraphs *)
module Defaultgraphs = Dose_algo__Defaultgraphs


(** @canonical Dose_algo.Depsolver *)
module Depsolver = Dose_algo__Depsolver


(** @canonical Dose_algo.Depsolver_int *)
module Depsolver_int = Dose_algo__Depsolver_int


(** @canonical Dose_algo.Diagnostic *)
module Diagnostic = Dose_algo__Diagnostic


(** @canonical Dose_algo.Dominators *)
module Dominators = Dose_algo__Dominators


(** @canonical Dose_algo.Flatten *)
module Flatten = Dose_algo__Flatten


(** @canonical Dose_algo.Statistics *)
module Statistics = Dose_algo__Statistics


(** @canonical Dose_algo.Strongconflicts *)
module Strongconflicts = Dose_algo__Strongconflicts


(** @canonical Dose_algo.Strongconflicts_int *)
module Strongconflicts_int = Dose_algo__Strongconflicts_int


(** @canonical Dose_algo.Strongdeps *)
module Strongdeps = Dose_algo__Strongdeps

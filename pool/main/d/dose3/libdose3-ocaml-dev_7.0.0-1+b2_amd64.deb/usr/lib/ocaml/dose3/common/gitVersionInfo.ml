let commit_hash = "unknown"
let committer_date = "not-available"

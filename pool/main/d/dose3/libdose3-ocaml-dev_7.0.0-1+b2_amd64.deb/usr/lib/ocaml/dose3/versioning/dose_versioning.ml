(** @canonical Dose_versioning.Debian *)
module Debian = Dose_versioning__Debian


(** @canonical Dose_versioning.Semver *)
module Semver = Dose_versioning__Semver


(** @canonical Dose_versioning.SemverNode *)
module SemverNode = Dose_versioning__SemverNode


(** @canonical Dose_versioning.Utils *)
module Utils = Dose_versioning__Utils

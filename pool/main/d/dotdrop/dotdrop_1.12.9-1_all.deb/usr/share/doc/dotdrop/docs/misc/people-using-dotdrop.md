For more examples, see how people are using dotdrop:

* [https://github.com/open-dynaMIX/dotfiles](https://github.com/open-dynaMIX/dotfiles)
* [https://github.com/japorized/dotfiles](https://github.com/japorized/dotfiles)
* [https://github.com/whitelynx/dotfiles](https://github.com/whitelynx/dotfiles)
* [https://github.com/Eluminae/dotfiles](https://github.com/Eluminae/dotfiles)
* [https://github.com/davla/dotfiles](https://github.com/davla/dotfiles)

Dotfiles repositories using dotdrop on [GitHub](https://github.com/topics/dotdrop?o=desc&s=updated).

Or search directly on [GitHub](https://github.com/search?q=filename%3Aconfig.yaml+dotdrop&type=Code) for config examples.

#ifndef OSTREAM_NULL_H
#define OSTREAM_NULL_H

/* Create an output stream that ignores all the writes. */
struct ostream *o_stream_create_null(void);

#endif

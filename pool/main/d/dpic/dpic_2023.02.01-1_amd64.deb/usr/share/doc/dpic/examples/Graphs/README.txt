Type `make' to invoke dpic -v on tgraph.pic, producing tgraph.svg,
which can be viewed in a browser.

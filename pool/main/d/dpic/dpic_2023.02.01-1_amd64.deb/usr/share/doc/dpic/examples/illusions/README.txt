Try the following (assuming m4 and Circuit_macros have been installed):

m4 svg.m4 illusions.m4 | dpic -v > illusions.svg

View the result in a browser.

Drascula: The Vampire Strikes Back (International Pack)
-------------------------------------------------------
Copyright (C) 1996-2010 Alcachofa Soft S.L.

Octobre 3rd, 2010
*****************
These are files for the game Drascula: The Vampire Strikes Back which was kindly
freewared by Alcachofa Soft S.L. and particularly thanks to support of
Emilio de Paz.

This pack requires English Drascula pack and ScummVM version 0.12.0, except for
the French version which requires ScummVM version 1.2.1. English Drascula pack
and ScummVM can both be downloaded from

  http://www.scummvm.org

To use, unpack this archive to a folder where you unpacked English Drascula
pack, then run ScummVM, press Add Game, and point ScummVM to that folder -- it
will autodetect it and will offer language to select. Then the game will appear
in game list. Then select the game entry and press Start to play. In order to 
play the game in other language, press Add Game once again and select desired
language. The game list will have separate entries for each added language.

Also there is provided separately a music pack for this game which adds musical
score to the gameplay.


Enjoy this game,
ScummVM Team

********************************************************************************
The Legal Stuff:

DRASCULA adaptation for SCUMMVM.

Preamble:
  Basically, give this game away, share it with your friends. Don't remove this
Readme, or pretend that you wrote it. You can include it in a software
collection, like a Linux distribution or coverdisk (which may be sold), but
using it in things like commercial adventure game collections without asking is
just playing dirty. You can modify the gamedata for such purposes as compressing
audio. This preamble is not legally binding, but is to clarify the intent of
the following licence.

Licence:
 1) You may distribute "DRASCULA" for free on any medium, provided this Readme
and all associated copyright notices and disclaimers are left intact.

 2) You may charge a reasonable copying fee for this archive, and may
distribute it in aggregate as part of a larger and possibly commercial software
distribution (such as a Linux distribution or magazine coverdisk). You must
provide proper attribution and ensure that this Readme and all associated
copyright notices and disclaimers are left intact.

 3) You may not charge a fee for the game itself. This includes reselling the
game as an individual item.

 4) You may modify the game as you wish.  You may also distribute modified
versions under the terms set forth in this licence, but with the additional
requirement that the work is marked with a prominent notice which states that
it is a modified version.

 5) All game content is Copyright (C) Alcachofa Soft S.L.
    The ScummVM engine is Copyright (C) The ScummVM Team (www.scummvm.org).

 6) THE GAME DATA IN THIS ARCHIVE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING AND NOT LIMITED TO ANY IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

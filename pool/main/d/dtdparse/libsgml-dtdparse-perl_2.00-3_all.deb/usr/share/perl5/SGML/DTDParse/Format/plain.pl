# $Id: plain.pl,v 2.1 2005/07/02 23:51:18 ehood Exp $

# Set default display options (these settings override the settings
# in dtd2*, and may subsequently be overridden by command line options.
#

# you can reassign options here to override default values...
$option{'synopsis'} = 1;

1;

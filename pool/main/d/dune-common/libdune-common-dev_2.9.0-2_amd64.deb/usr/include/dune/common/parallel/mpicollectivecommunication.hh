// SPDX-FileCopyrightInfo: Copyright (C) DUNE Project contributors, see file LICENSE.md in module root
// SPDX-License-Identifier: LicenseRef-GPL-2.0-only-with-DUNE-exception
// Will be removed after the 2.7 release
#warning "Deprecated header, use #include <dune/common/parallel/mpicommunication.hh> instead!"
#include <dune/common/parallel/mpicommunication.hh>

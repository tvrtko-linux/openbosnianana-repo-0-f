/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.in by autoheader.  */

/* DVBStreamer Major version number */
#define DVBSTREAMER_MAJOR 2

/* DVBStreamer Micro version number */
#define DVBSTREAMER_MICRO 1

/* DVBStreamer Minor version number */
#define DVBSTREAMER_MINOR 1

/* Define this to plugins directory location */
#define DVBSTREAMER_PLUGINDIR "/usr/lib/dvbstreamer/plugins"

/* Define this to plugin directory relative to execution prefix */
#define DVBSTREAMER_REL_PLUGINDIR "lib/dvbstreamer/plugins"

/* DVBStreamer combined version number as an int */
#define DVBSTREAMER_VERSION ((DVBSTREAMER_MAJOR<<24) | (DVBSTREAMER_MINOR<<16) | DVBSTREAMER_MICRO )

/* Enable ATSC support */
#define ENABLE_ATSC 1

/* Enable DVB support */
#define ENABLE_DVB 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Frontend enum exists for 2G modulation */
#define HAVE_FE_CAN_2G_MODULATION 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the `ltdl' library (-lltdl). */
#define HAVE_LIBLTDL 1

/* Define to 1 if you have the `readline' library (-lreadline). */
#define HAVE_LIBREADLINE 1

/* Define to 1 if you have the `sqlite3' library (-lsqlite3). */
#define HAVE_LIBSQLITE3 1

/* Define to 1 if you have the `yaml' library (-lyaml). */
#define HAVE_LIBYAML 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Support for variadic macros */
#define HAVE_VARIADIC_MACROS 1

/* libiconv's prototype takes a const char * */
#define ICONV_INPUT_CAST char **

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Name of package */
#define PACKAGE "dvbstreamer"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define this to data directory location */
#define PACKAGE_DATA_DIR "/usr/share"

/* Define this to Docs directory location */
#define PACKAGE_DOC_DIR "/usr/doc/dvbstreamer"

/* Define to the full name of this package. */
#define PACKAGE_NAME "dvbstreamer"

/* Define this to source directory location */
#define PACKAGE_SOURCE_DIR "/dummy"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "dvbstreamer 2.1.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "dvbstreamer"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "2.1.0"

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Use getaddrinfo for address resolution */
#define USE_GETADDRINFO 1

/* Version number of package */
#define VERSION "2.1.0"

# Introduction

* [Installation](02_Installation.md)
* [Simulating Reads](03_Simulating_Reads.md)
* [Evaluating Mappings](04_Evaluating_Mappings.md) 

Welcome to DWGSIM.
----

Documentation can be found in the [docs folder](docs/01_Introduction.md)

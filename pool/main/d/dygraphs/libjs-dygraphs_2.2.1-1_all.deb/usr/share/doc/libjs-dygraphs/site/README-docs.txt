Online sources of some of these documents locally mirrored
so these can be used without needing to visit external services:

• datahandler-proposal.pdf
  https://docs.google.com/document/d/1IWmX4oDbQbVtUoRNzSRG3yMpoBQ7LseVCQhGnuOZz_A
• hairlines-annotations.pdf
  https://docs.google.com/document/d/1OHNE8BNNmMtFlRQ969DACIYIJ9VVJ7w3dSPRJDEeIew
• legend-formatter.md
  https://github.com/danvk/dygraphs/pull/683
• smooth-plotter.md + smooth-plotter-p*
  https://github.com/danvk/dygraphs/pull/469

#pragma once

#ifdef _MSC_VER
#pragma message("WARNING! #include \"MaterialStream.h\" is deprecated. Use #include \"Stream.h\" instead")
#else
#warning "WARNING! #include \"MaterialStream.h\" is deprecated. Use #include \"Stream.h\" instead"
#endif

#include "Stream.h"

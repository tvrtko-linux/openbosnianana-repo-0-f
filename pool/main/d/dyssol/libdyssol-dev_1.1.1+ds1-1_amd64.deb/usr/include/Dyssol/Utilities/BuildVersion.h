#pragma once
const char CURRENT_BUILD_VERSION[] = " ";

#ifdef E_TYPEDEFS

#else
# ifndef E_COMP_X_DEVICES_H
#  define E_COMP_X_DEVICES_H
#  include <Ecore_X.h>
#  include "e_atoms.h"

E_API void e_comp_x_devices_config_apply(Eina_Bool force);

# endif
#endif

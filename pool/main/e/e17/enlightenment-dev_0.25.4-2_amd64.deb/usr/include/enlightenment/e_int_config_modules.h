#ifdef E_TYPEDEFS
#else
#ifndef E_INT_CONFIG_MODULES_H
#define E_INT_CONFIG_MODULES_H

E_API E_Config_Dialog *e_int_config_modules(Evas_Object *parent, const char *params);

#endif
#endif

#ifdef E_TYPEDEFS
#else
# ifndef E_WATCHDOG_H
#  define E_WATCHDOG_H

E_API void e_watchdog_begin(void);
E_API void e_watchdog_end(void);

# endif
#endif

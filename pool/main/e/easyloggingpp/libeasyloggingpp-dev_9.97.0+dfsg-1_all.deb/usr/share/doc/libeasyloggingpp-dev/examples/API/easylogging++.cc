#include "../../src/easylogging++.cc"

#include <Python.h>

int main() {
  return 0;
}

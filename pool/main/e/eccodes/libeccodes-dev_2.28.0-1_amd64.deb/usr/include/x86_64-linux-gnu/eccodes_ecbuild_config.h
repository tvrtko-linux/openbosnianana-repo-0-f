/*
 * (C) Copyright 2011- ECMWF.
 *
 * This software is licensed under the terms of the Apache Licence Version 2.0
 * which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
 * In applying this licence, ECMWF does not waive the privileges and immunities
 * granted to it by virtue of its status as an intergovernmental organisation nor
 * does it submit to any jurisdiction.
 */

#ifndef ECCODES_ecbuild_config_h
#define ECCODES_ecbuild_config_h

/* ecbuild info */

#ifndef ECBUILD_VERSION_STR
#define ECBUILD_VERSION_STR "3.7.0"
#endif
#ifndef ECBUILD_VERSION
#define ECBUILD_VERSION "3.7.0"
#endif
#ifndef ECBUILD_MACROS_DIR
#define ECBUILD_MACROS_DIR  "/usr/share/ecbuild/cmake"
#endif

/* config info */

#define ECCODES_OS_NAME          "Linux-5.10.0-21-amd64"
#define ECCODES_OS_BITS          64
#define ECCODES_OS_BITS_STR      "64"
#define ECCODES_OS_STR           "linux.64"
#define ECCODES_OS_VERSION       "5.10.0-21-amd64"
#define ECCODES_SYS_PROCESSOR    "x86_64"

#define ECCODES_BUILD_TIMESTAMP  "20230226062027"
#define ECCODES_BUILD_TYPE       "Release"

#define ECCODES_C_COMPILER_ID      "GNU"
#define ECCODES_C_COMPILER_VERSION "12.2.0"

#define ECCODES_CXX_COMPILER_ID      ""
#define ECCODES_CXX_COMPILER_VERSION ""

#define ECCODES_C_COMPILER       "/usr/bin/cc"
#define ECCODES_C_FLAGS          "-g -O2 -ffile-prefix-map=/build/eccodes-A5LkTc/eccodes-2.28.0=. -fstack-protector-strong -Wformat -Werror=format-security -Wdate-time -D_FORTIFY_SOURCE=2  -Wdate-time -D_FORTIFY_SOURCE=2 -pipe -fopenmp -O3 -DNDEBUG"

#define ECCODES_CXX_COMPILER     ""
#define ECCODES_CXX_FLAGS        ""

/* Needed for finding per package config files */

#define ECCODES_INSTALL_DIR       "/usr"
#define ECCODES_INSTALL_BIN_DIR   "/usr/bin"
#define ECCODES_INSTALL_LIB_DIR   "/usr/lib/x86_64-linux-gnu"
#define ECCODES_INSTALL_DATA_DIR  "/usr/share/eccodes"

#define ECCODES_DEVELOPER_SRC_DIR "/build/eccodes-A5LkTc/eccodes-2.28.0"
#define ECCODES_DEVELOPER_BIN_DIR "/build/eccodes-A5LkTc/eccodes-2.28.0/debian/build"

/* Fortran support */

#if 1

#define ECCODES_Fortran_COMPILER_ID      "GNU"
#define ECCODES_Fortran_COMPILER_VERSION "12.2.0"

#define ECCODES_Fortran_COMPILER "/usr/bin/gfortran"
#define ECCODES_Fortran_FLAGS    "-g -O2 -ffile-prefix-map=/build/eccodes-A5LkTc/eccodes-2.28.0=. -fstack-protector-strong -fopenmp -O3 -DNDEBUG -funroll-all-loops -finline-functions"

#endif

#endif /* ECCODES_ecbuild_config_h */

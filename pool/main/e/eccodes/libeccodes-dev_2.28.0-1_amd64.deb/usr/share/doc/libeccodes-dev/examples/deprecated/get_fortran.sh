#!/bin/sh

. ./include.sh

${examples_dir}/get_fortran > /dev/null



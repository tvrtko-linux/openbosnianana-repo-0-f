#!/bin/sh

. ./include.sh

${examples_dir}/keys_iterator_fortran > /dev/null



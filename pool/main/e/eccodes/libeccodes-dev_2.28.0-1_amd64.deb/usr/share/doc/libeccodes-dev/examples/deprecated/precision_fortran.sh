#!/bin/sh

. ./include.sh

${examples_dir}/precision_fortran > /dev/null



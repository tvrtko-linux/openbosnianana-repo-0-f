#!/bin/sh

. ./include.sh

${examples_dir}/set > /dev/null



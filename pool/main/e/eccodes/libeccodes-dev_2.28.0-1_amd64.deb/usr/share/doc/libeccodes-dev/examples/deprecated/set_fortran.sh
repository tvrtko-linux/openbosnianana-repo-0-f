#!/bin/sh

. ./include.sh

${examples_dir}/set_fortran > /dev/null



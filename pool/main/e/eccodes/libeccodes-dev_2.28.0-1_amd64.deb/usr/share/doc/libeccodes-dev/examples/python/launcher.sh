#!/bin/sh

PYTHONPATH=../../python
python $1

var searchData=
[
  ['environment_20variables',['Environment variables',['../group__environment.html',1,'']]],
  ['error_20codes',['Error codes',['../group__errors.html',1,'']]]
];

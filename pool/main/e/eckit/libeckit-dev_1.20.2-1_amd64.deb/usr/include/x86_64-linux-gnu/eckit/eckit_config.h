#ifndef eckit_config_h
#define eckit_config_h

#include "eckit/eckit_ecbuild_config.h"

#include "eckit/eckit_version.h"

// endiness

#define eckit_BIG_ENDIAN       0
#define ECKIT_BIG_ENDIAN       0 /* backward compatibility */

#define eckit_LITTLE_ENDIAN    1
#define ECKIT_LITTLE_ENDIAN    1 /* backward compatibility */

// system

#define ECKIT_SIZEOF_TIME_T    8

#define eckit_HAVE_DLFCN_H
#define eckit_HAVE_DLADDR
#define eckit_HAVE_MAP_ANONYMOUS
#define eckit_HAVE_MAP_ANON
/* #undef eckit_HAVE_FUNOPEN */
#define eckit_HAVE_FSYNC
#define eckit_HAVE_FDATASYNC
/* #undef eckit_HAVE_F_FULLFSYNC */
#define eckit_HAVE_FMEMOPEN
/* #undef eckit_HAVE_DLINFO */
#define eckit_HAVE_FOPENCOOKIE
#define eckit_HAVE_EXECINFO_BACKTRACE
#define eckit_HAVE_CXXABI_H
#define eckit_HAVE_GMTIME_R
#define eckit_HAVE_READDIR_R
#define eckit_HAVE_DIRFD
#define eckit_HAVE_DIRENT_D_TYPE
#define eckit_HAVE_CXX_INT_128
#define eckit_HAVE_AIO
#define eckit_HAVE_UNICODE
#define eckit_HAVE_XXHASH

// external packages

/* #undef eckit_HAVE_ARMADILLO */
/* #undef eckit_HAVE_CUDA */
#define eckit_HAVE_EIGEN
#define eckit_HAVE_LAPACK
/* #undef eckit_HAVE_VIENNACL */
#define eckit_HAVE_OMP
#define eckit_HAVE_SSL
#define eckit_HAVE_CURL
/* #undef eckit_HAVE_JEMALLOC */

#define eckit_HAVE_MKL 0
#define ECKIT_HAVE_MKL 0 /* backward compatibility */

#define eckit_HAVE_MPI 1
#define ECKIT_HAVE_MPI 1 /* backward compatibility */

// Have we built certain libraries

#define eckit_HAVE_ECKIT_CMD
#define eckit_HAVE_ECKIT_SQL
/* #undef eckit_HAVE_ECKIT_MPI */

#endif // eckit_config_h

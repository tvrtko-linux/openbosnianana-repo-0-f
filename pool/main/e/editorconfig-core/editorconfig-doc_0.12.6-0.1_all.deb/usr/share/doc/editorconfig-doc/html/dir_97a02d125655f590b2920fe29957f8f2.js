var dir_97a02d125655f590b2920fe29957f8f2 =
[
    [ "editorconfig.h", "editorconfig_8h.html", "editorconfig_8h" ],
    [ "editorconfig_handle.h", "editorconfig__handle_8h.html", "editorconfig__handle_8h" ]
];
var editorconfig__handle_8h =
[
    [ "editorconfig_handle", "editorconfig__handle_8h.html#a0c51d798e0e22051d0057a567245010c", null ],
    [ "editorconfig_handle_destroy", "editorconfig__handle_8h.html#add8960b396594d796843df56a6fd0cfe", null ],
    [ "editorconfig_handle_get_conf_file_name", "editorconfig__handle_8h.html#a3437ec9166cef3aadd049bd864281932", null ],
    [ "editorconfig_handle_get_err_file", "editorconfig__handle_8h.html#abce33e41c30612762b6e9a47bbd98172", null ],
    [ "editorconfig_handle_get_name_value", "editorconfig__handle_8h.html#ad8330caee21b6aaacfa9fc95792b0389", null ],
    [ "editorconfig_handle_get_name_value_count", "editorconfig__handle_8h.html#a5a589c0471ca6651d09823595ddd3ea2", null ],
    [ "editorconfig_handle_get_version", "editorconfig__handle_8h.html#ab54f0467f75b91cd17e2569f11c38c74", null ],
    [ "editorconfig_handle_init", "editorconfig__handle_8h.html#a8e3f1681e835a2946ba93b341ebc3dca", null ],
    [ "editorconfig_handle_set_conf_file_name", "editorconfig__handle_8h.html#a345fc52f7cc06dc8d35685ef4904013b", null ],
    [ "editorconfig_handle_set_version", "editorconfig__handle_8h.html#a4f0ce0493d8ef361387109ff3539eb9d", null ]
];
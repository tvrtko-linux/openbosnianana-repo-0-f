var searchData=
[
  ['editorconfig_5fparse_5fmemory_5ferror_0',['EDITORCONFIG_PARSE_MEMORY_ERROR',['../editorconfig_8h.html#a492500afec561a16fc6e8e23b261abaf',1,'editorconfig.h']]],
  ['editorconfig_5fparse_5fnot_5ffull_5fpath_1',['EDITORCONFIG_PARSE_NOT_FULL_PATH',['../editorconfig_8h.html#a7a8131a3c229adb8eba19262e981b0f7',1,'editorconfig.h']]],
  ['editorconfig_5fparse_5fversion_5ftoo_5fnew_2',['EDITORCONFIG_PARSE_VERSION_TOO_NEW',['../editorconfig_8h.html#afe623becaffb01263d1b22bd320f7916',1,'editorconfig.h']]]
];

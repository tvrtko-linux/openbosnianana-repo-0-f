var searchData=
[
  ['editorconfig_2eh_0',['editorconfig.h',['../editorconfig_8h.html',1,'']]],
  ['editorconfig_5fhandle_2eh_1',['editorconfig_handle.h',['../editorconfig__handle_8h.html',1,'']]]
];

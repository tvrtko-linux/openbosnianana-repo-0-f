var searchData=
[
  ['editorconfig_5fget_5ferror_5fmsg_0',['editorconfig_get_error_msg',['../editorconfig_8h.html#a62c02a92e8148f4db86e86f798d368b0',1,'editorconfig.h']]],
  ['editorconfig_5fget_5fversion_1',['editorconfig_get_version',['../editorconfig_8h.html#a5c5961b81ee3d6cd296dc8f1e6d7c6d0',1,'editorconfig.h']]],
  ['editorconfig_5fget_5fversion_5fsuffix_2',['editorconfig_get_version_suffix',['../editorconfig_8h.html#a004c193bf2328e215ae34f439b5fdeef',1,'editorconfig.h']]],
  ['editorconfig_5fhandle_5fdestroy_3',['editorconfig_handle_destroy',['../editorconfig__handle_8h.html#add8960b396594d796843df56a6fd0cfe',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5fget_5fconf_5ffile_5fname_4',['editorconfig_handle_get_conf_file_name',['../editorconfig__handle_8h.html#a3437ec9166cef3aadd049bd864281932',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5fget_5ferr_5ffile_5',['editorconfig_handle_get_err_file',['../editorconfig__handle_8h.html#abce33e41c30612762b6e9a47bbd98172',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5fget_5fname_5fvalue_6',['editorconfig_handle_get_name_value',['../editorconfig__handle_8h.html#ad8330caee21b6aaacfa9fc95792b0389',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5fget_5fname_5fvalue_5fcount_7',['editorconfig_handle_get_name_value_count',['../editorconfig__handle_8h.html#a5a589c0471ca6651d09823595ddd3ea2',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5fget_5fversion_8',['editorconfig_handle_get_version',['../editorconfig__handle_8h.html#ab54f0467f75b91cd17e2569f11c38c74',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5finit_9',['editorconfig_handle_init',['../editorconfig__handle_8h.html#a8e3f1681e835a2946ba93b341ebc3dca',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5fset_5fconf_5ffile_5fname_10',['editorconfig_handle_set_conf_file_name',['../editorconfig__handle_8h.html#a345fc52f7cc06dc8d35685ef4904013b',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5fset_5fversion_11',['editorconfig_handle_set_version',['../editorconfig__handle_8h.html#a4f0ce0493d8ef361387109ff3539eb9d',1,'editorconfig_handle.h']]],
  ['editorconfig_5fparse_12',['editorconfig_parse',['../editorconfig_8h.html#add6bebe96bf90c48fef01cf5300ddf92',1,'editorconfig.h']]]
];

var searchData=
[
  ['editorconfig_20c_20core_20documentation_0',['EditorConfig C Core Documentation',['../index.html',1,'']]],
  ['editorconfig_20command_1',['EditorConfig Command',['../editorconfig.html',1,'']]],
  ['editorconfig_20file_20format_2',['EditorConfig File Format',['../editorconfig-format.html',1,'']]]
];

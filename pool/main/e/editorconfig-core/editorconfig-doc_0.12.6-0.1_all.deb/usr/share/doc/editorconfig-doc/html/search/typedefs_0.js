var searchData=
[
  ['editorconfig_5fhandle_0',['editorconfig_handle',['../editorconfig__handle_8h.html#a0c51d798e0e22051d0057a567245010c',1,'editorconfig_handle.h']]]
];

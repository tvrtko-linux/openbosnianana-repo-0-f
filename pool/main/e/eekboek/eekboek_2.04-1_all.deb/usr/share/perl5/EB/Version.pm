# This file is generated. Do not edit!
package EB::Version;
our $VERSION = "2.04";
print "$VERSION\n" unless caller;

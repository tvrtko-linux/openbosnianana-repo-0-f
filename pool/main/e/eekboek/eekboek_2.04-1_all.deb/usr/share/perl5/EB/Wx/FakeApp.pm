#! perl

package main;

our $app;

# Note: a non-null $app is a signal for EB to load the GUI version of
# the Locale module.

$app = {};

1;

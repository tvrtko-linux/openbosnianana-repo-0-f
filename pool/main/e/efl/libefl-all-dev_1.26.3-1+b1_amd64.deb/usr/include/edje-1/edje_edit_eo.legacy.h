#ifndef _EDJE_EDIT_EO_LEGACY_H_
#define _EDJE_EDIT_EO_LEGACY_H_

#ifndef _EDJE_EDIT_EO_CLASS_TYPE
#define _EDJE_EDIT_EO_CLASS_TYPE

typedef Eo Edje_Edit;

#endif

#ifndef _EDJE_EDIT_EO_TYPES
#define _EDJE_EDIT_EO_TYPES


#endif

#endif

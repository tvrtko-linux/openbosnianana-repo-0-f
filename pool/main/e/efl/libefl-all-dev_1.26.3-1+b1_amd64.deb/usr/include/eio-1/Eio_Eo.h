/* This include has been added to support Eo in Eio */
#include <Eo.h>

#ifdef __cplusplus
extern "C" {
#endif

#include "efl_io_manager.eo.h"
#include "eio_sentry.eo.h"
#include "efl_io_model.eo.h"

#ifdef __cplusplus
}
#endif

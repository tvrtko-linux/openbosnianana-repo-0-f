#ifndef _EFL_UI_BUTTON_EO_LEGACY_H_
#define _EFL_UI_BUTTON_EO_LEGACY_H_

#ifndef _EFL_UI_BUTTON_EO_CLASS_TYPE
#define _EFL_UI_BUTTON_EO_CLASS_TYPE

typedef Eo Efl_Ui_Button;

#endif

#ifndef _EFL_UI_BUTTON_EO_TYPES
#define _EFL_UI_BUTTON_EO_TYPES


#endif

#endif

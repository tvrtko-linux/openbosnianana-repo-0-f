#ifndef _EFL_UI_FLIP_LEGACY_EO_LEGACY_H_
#define _EFL_UI_FLIP_LEGACY_EO_LEGACY_H_

#ifndef _EFL_UI_FLIP_LEGACY_EO_CLASS_TYPE
#define _EFL_UI_FLIP_LEGACY_EO_CLASS_TYPE

typedef Eo Efl_Ui_Flip_Legacy;

#endif

#ifndef _EFL_UI_FLIP_LEGACY_EO_TYPES
#define _EFL_UI_FLIP_LEGACY_EO_TYPES


#endif

#endif

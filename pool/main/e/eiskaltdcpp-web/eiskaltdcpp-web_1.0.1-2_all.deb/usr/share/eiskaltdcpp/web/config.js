/*global define */
define([], function () {
    'use strict';
    return {
        "jsonrpc" : {
            "host" : "127.0.0.1",
            "port" : "3121"
        },
        "debugLevel" : 3
    };
});

Introduction:

	This package contains unmodified versions of sound files from FlylinkDC++ project

	FlylinkDC++ is a free Open Source program licensed under GPL 2

	FlylinkDC++ websites:
		https://www.flylinkdc.ru/
		https://github.com/pavel-pimenov/flylinkdc-r5xx


You can feel FREE to use, modify, redistribute and all that allowed by GPL 2 license


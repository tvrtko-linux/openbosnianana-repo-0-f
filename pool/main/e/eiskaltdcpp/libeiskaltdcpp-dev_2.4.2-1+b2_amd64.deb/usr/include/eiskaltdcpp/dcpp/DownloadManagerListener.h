/*
 * Copyright (C) 2001-2019 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#pragma once

#include "typedefs.h"

namespace dcpp {

/**
 * Use this listener interface to get progress information for downloads.
 *
 * @remarks All methods are sending a pointer to a Download but the receiver
 * (TransferView) is not using any of the methods in Download, only methods
 * from its super class, Transfer. The listener functions should send Transfer
 * objects instead.
 *
 * Changing this will will cause a problem with Download::List which is used
 * in the on Tick function. One solution is reimplement on Tick to call once
 * for every Downloads, sending one Download at a time. But maybe updating the
 * GUI is not DownloadManagers problem at all???
 */
class DownloadManagerListener {
public:
    virtual ~DownloadManagerListener() { }
    template<int I> struct X { enum { TYPE = I }; };

    typedef X<0> Complete;
    typedef X<1> Failed;
    typedef X<2> Starting;
    typedef X<3> Tick;
    typedef X<4> Requesting;

    /**
     * This is the first message sent before a download starts.
     * No other messages will be sent before this.
     */
    virtual void on(Requesting, Download*) noexcept { }

    /**
     * This is the first message sent before a download starts.
     */
    virtual void on(Starting, Download*) noexcept { }

    /**
     * Sent once a second if something has actually been downloaded.
     */
    virtual void on(Tick, const DownloadList&) noexcept { }

    /**
     * This is the last message sent before a download is deleted.
     * No more messages will be sent after it.
     */
    virtual void on(Complete, Download*) noexcept { }

    /**
     * This indicates some sort of failure with a particular download.
     * No more messages will be sent after it.
     *
     * @remarks Should send an error code instead of a string and let the GUI
     * display an error string.
     */
    virtual void on(Failed, Download*, const string&) noexcept { }
};

} // namespace dcpp

# v0.8.0 -> v0.9.0

- The signature of the ```Event::setOrganizer``` method was changed:
Now there is is only one parameter that must be an instance of ```Property\Organizer```.

# v0.7.0 -> v0.8.0

- The signature of the ```Event::setOrganizer``` method was changed: Now there are
two parameters name and email instead of an already formatted string.

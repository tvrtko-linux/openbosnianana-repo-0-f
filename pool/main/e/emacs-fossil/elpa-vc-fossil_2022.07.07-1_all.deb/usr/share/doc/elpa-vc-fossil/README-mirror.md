# vc-fossil
VC Mode for Emacs to work with the Fossil SCM

This is mirrored from https://tumbleweed.nu/r/vc-fossil/ -- please
file all bug reports there, the Github mirror is only sporadically for
non-GNU ELPA.

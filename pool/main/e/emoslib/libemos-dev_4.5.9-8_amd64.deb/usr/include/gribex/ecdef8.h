C
C Copyright 1981-2016 ECMWF.
C
C This software is licensed under the terms of the Apache Licence 
C Version 2.0 which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
C
C In applying this licence, ECMWF does not waive the privileges and immunities 
C granted to it by virtue of its status as an intergovernmental organisation 
C nor does it submit to any jurisdiction.
C
C!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
C       
C                   ECMWF local GRIB use definition 8.
C
C                   ECMWF re-analysis data
C                   ----------------------
C
C
C                   Word
C                   ----
C                    38    as for definition 1.  
C
C                    39    Type.
C
C                    40    Stream.
C
C                    41    as for definition 1.  
C
C                    42-54 Unsigned integers in range (0-255)
C
C!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
C

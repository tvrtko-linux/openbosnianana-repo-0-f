C Copyright 1981-2016 ECMWF.
C
C This software is licensed under the terms of the Apache Licence 
C Version 2.0 which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
C
C In applying this licence, ECMWF does not waive the privileges and immunities 
C granted to it by virtue of its status as an intergovernmental organisation 
C nor does it submit to any jurisdiction.
C
      INTEGER QG032(32)
      DATA QG032/
     X  20,  27,  36,  40,  45,  50,  60,  64,  72,  75,  80,  90,
     X  90,  96, 100, 108, 108, 120, 120, 120, 128, 128, 128, 128,
     X 128, 128, 128, 128, 128, 128, 128, 128 /

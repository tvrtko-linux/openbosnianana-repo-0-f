C Copyright 1981-2016 ECMWF.
C
C This software is licensed under the terms of the Apache Licence 
C Version 2.0 which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
C
C In applying this licence, ECMWF does not waive the privileges and immunities 
C granted to it by virtue of its status as an intergovernmental organisation 
C nor does it submit to any jurisdiction.
C
      INTEGER QG048(48)
      DATA QG048/
     X  20,  25,  36, 40,
     X  45,  50,  60, 60,
     X  72,  75,  80, 90,
     X  96, 100, 108, 120,
     X 120, 120, 128, 135,
     X 144, 144, 160, 160,
     X 160, 160, 160, 180,
     X 180, 180, 180, 180,
     X 192, 192, 192, 192,
     X 192, 192, 192, 192,
     X 192, 192, 192, 192,
     X 192, 192, 192, 192 /

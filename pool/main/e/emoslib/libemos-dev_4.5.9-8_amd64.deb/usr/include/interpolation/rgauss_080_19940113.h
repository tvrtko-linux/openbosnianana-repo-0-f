C Copyright 1981-2016 ECMWF.
C
C This software is licensed under the terms of the Apache Licence 
C Version 2.0 which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
C
C In applying this licence, ECMWF does not waive the privileges and immunities 
C granted to it by virtue of its status as an intergovernmental organisation 
C nor does it submit to any jurisdiction.
C
      INTEGER QG08012(80)
      DATA QG08012/
     X  12 ,  16 ,  20 ,  24,
     X  30 ,  36 ,  45 ,  50,
     X  60 ,  64 ,  72 ,  75,
     X  80 ,  90 ,  96 , 100,
     X 108 , 120 , 120 , 128,
     X 128 , 135 , 144 , 144,
     X 150 , 160 , 162 , 180,
     X 180 , 180 , 192 , 192,
     X 192 , 200 , 216 , 216,
     X 216 , 216 , 225 , 225,
     X 240 , 240 , 240 , 256,
     X 256 , 256 , 256 , 288,
     X 288 , 288 , 288 , 288,
     X 288 , 288 , 288 , 288,
     X 288 , 300 , 300 , 300,
     X 300 , 300 , 320 , 320,
     X 320 , 320 , 320 , 320,
     X 320 , 320 , 320 , 320,
     X 320 , 320 , 320 , 320,
     X 320 , 320 , 320 , 320 /

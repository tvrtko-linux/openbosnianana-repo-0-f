C Copyright 1981-2016 ECMWF.
C
C This software is licensed under the terms of the Apache Licence 
C Version 2.0 which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
C
C In applying this licence, ECMWF does not waive the privileges and immunities 
C granted to it by virtue of its status as an intergovernmental organisation 
C nor does it submit to any jurisdiction.
C
      INTEGER QG096(96)
      DATA QG096/
     X 18 , 25 , 36 , 40,
     X 45 , 50 , 60 , 64,
     X 72 , 72 , 80 , 90,
     X 96 , 100 , 108 , 120,
     X 120 , 125 , 135 , 144,
     X 144 , 150 , 160 , 160,
     X 180 , 180 , 180 , 192,
     X 192 , 200 , 200 , 216,
     X 216 , 225 , 225 , 240,
     X 240 , 240 , 250 , 250,
     X 256 , 270 , 270 , 270,
     X 288 , 288 , 288 , 288,
     X 300 , 300 , 300 , 320,
     X 320 , 320 , 320 , 320,
     X 324 , 360 , 360 , 360,
     X 360 , 360 , 360 , 360,
     X 360 , 360 , 360 , 360,
     X 375 , 375 , 375 , 375,
     X 375 , 375 , 375 , 384,
     X 384 , 384 , 384 , 384,
     X 384 , 384 , 384 , 384,
     X 384 , 384 , 384 , 384,
     X 384 , 384 , 384 , 384,
     X 384 , 384 , 384 , 384 / 

C Copyright 1981-2016 ECMWF.
C
C This software is licensed under the terms of the Apache Licence 
C Version 2.0 which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
C
C In applying this licence, ECMWF does not waive the privileges and immunities 
C granted to it by virtue of its status as an intergovernmental organisation 
C nor does it submit to any jurisdiction.
C
      INTEGER QG200(200)
      DATA QG200/
     X  18,  25,  36,  40,
     X  45,  50,  60,  64,
     X  72,  72,  75,  81,
     X  90,  96, 100, 108,
     X 120, 125, 128, 135,
     X 144, 150, 160, 160,
     X 180, 180, 180, 192,
     X 192, 200, 216, 216,
     X 225, 225, 240, 240,
     X 243, 250, 256, 270,
     X 270, 288, 288, 288,
     X 300, 300, 320, 320,
     X 320, 320, 360, 360,
     X 360, 360, 360, 360,
     X 375, 375, 375, 384,
     X 400, 400, 400, 400,
     X 432, 432, 432, 432,
     X 432, 450, 450, 450,
     X 480, 480, 480, 480,
     X 480, 480, 486, 500,
     X 500, 500, 512, 512,
     X 512, 540, 540, 540,
     X 540, 540, 576, 576,
     X 576, 576, 576, 576,
     X 576, 576, 600, 600,
     X 600, 600, 600, 640,
     X 640, 640, 640, 640,
     X 640, 640, 640, 640,
     X 640, 648, 648, 675,
     X 675, 675, 675, 675,
     X 675, 675, 720, 720,
     X 720, 720, 720, 720,
     X 720, 720, 720, 720,
     X 720, 720, 720, 720,
     X 729, 729, 729, 750,
     X 750, 750, 750, 750,
     X 750, 750, 750, 768,
     X 768, 768, 768, 768,
     X 768, 768, 768, 800,
     X 800, 800, 800, 800,
     X 800, 800, 800, 800,
     X 800, 800, 800, 800,
     X 800, 800, 800, 800,
     X 800, 800, 800, 800,
     X 800, 800, 800, 800,
     X 800, 800, 800, 800,
     X 800, 800, 800, 800,
     X 800, 800, 800, 800,
     X 800, 800, 800, 800,
     X 800, 800, 800, 800 /

/*
 * (C) Copyright 2011- ECMWF.
 *
 * This software is licensed under the terms of the Apache Licence Version 2.0
 * which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
 * In applying this licence, ECMWF does not waive the privileges and immunities
 * granted to it by virtue of its status as an intergovernmental organisation nor
 * does it submit to any jurisdiction.
 */

#ifndef libemos_ecbuild_config_h
#define libemos_ecbuild_config_h

/* ecbuild info */

#ifndef ECBUILD_VERSION_STR
#define ECBUILD_VERSION_STR "2.9.4"
#endif
#ifndef ECBUILD_MACROS_DIR
#define ECBUILD_MACROS_DIR  "/build/emoslib-BhfGh5/emoslib-4.5.9/cmake"
#endif

/* config info */

#define LIBEMOS_OS_NAME          "Linux-5.10.0-21-amd64"
#define LIBEMOS_OS_BITS          64
#define LIBEMOS_OS_BITS_STR      "64"
#define LIBEMOS_OS_STR           "linux.64"
#define LIBEMOS_OS_VERSION       "5.10.0-21-amd64"
#define LIBEMOS_SYS_PROCESSOR    "x86_64"

#define LIBEMOS_BUILD_TIMESTAMP  "20230326104741"
#define LIBEMOS_BUILD_TYPE       "Release"

#define LIBEMOS_C_COMPILER_ID      "GNU"
#define LIBEMOS_C_COMPILER_VERSION "12.2.0"

#define LIBEMOS_CXX_COMPILER_ID      "GNU"
#define LIBEMOS_CXX_COMPILER_VERSION "12.2.0"

#define LIBEMOS_C_COMPILER       "/usr/bin/cc"
#define LIBEMOS_C_FLAGS          "-g -O2 -ffile-prefix-map=/build/emoslib-BhfGh5/emoslib-4.5.9=. -fstack-protector-strong -Wformat -Werror=format-security -Wdate-time -D_FORTIFY_SOURCE=2 -pipe -O3 -DNDEBUG"

#define LIBEMOS_CXX_COMPILER     "/usr/bin/c++"
#define LIBEMOS_CXX_FLAGS        "-g -O2 -ffile-prefix-map=/build/emoslib-BhfGh5/emoslib-4.5.9=. -fstack-protector-strong -Wformat -Werror=format-security -Wdate-time -D_FORTIFY_SOURCE=2 -pipe -O3 -DNDEBUG"

/* Needed for finding per package config files */

#define LIBEMOS_INSTALL_DIR       "/build/emoslib-BhfGh5/emoslib-4.5.9/debian/tmp"
#define LIBEMOS_INSTALL_BIN_DIR   "/build/emoslib-BhfGh5/emoslib-4.5.9/debian/tmp/bin"
#define LIBEMOS_INSTALL_LIB_DIR   "/build/emoslib-BhfGh5/emoslib-4.5.9/debian/tmp/lib"
#define LIBEMOS_INSTALL_DATA_DIR  "/build/emoslib-BhfGh5/emoslib-4.5.9/debian/tmp/share/libemos"

#define LIBEMOS_DEVELOPER_SRC_DIR "/build/emoslib-BhfGh5/emoslib-4.5.9"
#define LIBEMOS_DEVELOPER_BIN_DIR "/build/emoslib-BhfGh5/emoslib-4.5.9/obj-x86_64-linux-gnu"

#define EC_HAVE_FORTRAN

#ifdef EC_HAVE_FORTRAN

#define LIBEMOS_Fortran_COMPILER_ID      "GNU"
#define LIBEMOS_Fortran_COMPILER_VERSION "12.2.0"

#define LIBEMOS_Fortran_COMPILER "/usr/bin/gfortran"
#define LIBEMOS_Fortran_FLAGS    "-g -O2 -ffile-prefix-map=/build/emoslib-BhfGh5/emoslib-4.5.9=. -fstack-protector-strong  -fallow-invalid-boz -fallow-argument-mismatch -ffixed-line-length-none -fcray-pointer -fno-second-underscore -Wuninitialized -Wunused-variable -DSHAREDMEMORY   -O3 -DNDEBUG -funroll-all-loops -finline-functions -O2"

#endif

/* #undef BOOST_UNIT_TEST_FRAMEWORK_HEADER_ONLY */
#define BOOST_UNIT_TEST_FRAMEWORK_LINKED

#endif /* libemos_ecbuild_config_h */

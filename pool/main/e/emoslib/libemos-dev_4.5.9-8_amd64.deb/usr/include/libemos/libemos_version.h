#ifndef libemos_version_h
#define libemos_version_h

#define LIBEMOS_VERSION_STR "4.5.9"
#define LIBEMOS_VERSION     "4.5.9"

#define LIBEMOS_MAJOR_VERSION 4
#define LIBEMOS_MINOR_VERSION 5
#define LIBEMOS_PATCH_VERSION 9

const char * libemos_version();

unsigned int libemos_version_int();

const char * libemos_version_str();

const char * libemos_git_sha1();

#endif // libemos_version_h

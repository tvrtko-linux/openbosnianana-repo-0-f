var searchData=
[
  ['features_20and_20architecture_0',['Features and Architecture',['../Features.html',1,'']]],
  ['frequently_20answered_20questions_1',['Frequently Answered Questions',['../FAQ.html',1,'']]]
];

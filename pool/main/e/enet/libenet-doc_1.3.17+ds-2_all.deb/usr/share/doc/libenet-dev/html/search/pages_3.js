var searchData=
[
  ['installation_0',['Installation',['../Installation.html',1,'']]],
  ['irc_20channel_1',['IRC Channel',['../IRCChannel.html',1,'']]]
];

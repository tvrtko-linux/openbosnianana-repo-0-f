.. image:: https://gitlab.com/entangle/entangle/badges/master/pipeline.svg
     :target: https://gitlab.com/entangle/entangle/pipelines
     :alt: GitLab CI Build Status

.. image:: https://translate.fedoraproject.org/widgets/entangle/-/master/svg-badge.svg
     :target: https://translate.fedoraproject.org/engage/entangle/
     :alt: Translation status

===========================================
Entangle: Tethered Camera Control & Capture
===========================================

Entangle is an application which uses GTK and libgphoto2 to provide a
graphical interface for tethered photography with digital cameras.

It includes control over camera shooting and configuration settings
and 'hands off' shooting directly from the controlling computer.

Installation
============

The Entangle package uses the Meson build system available from:

https://mesonbuild.com/

As a quick start you can do

::

   meson build-dir
   ninja -C build-dir all
   sudo ninja -C build-dir install

which will install into the prefix `/usr/local`

To install into a private user specific location

::

   meson build-dir --prefix=$HOME/entangle
   ninja -C build-dir all
   ninja -C build-dir install

Note that if not installing in the system prefix "/usr", GTK will
probably have trouble finding the gsettings files and the GI
typelib files needed by the plugins. To fix this set some
environment variables

* `XDG_DATA_DIRS` variable to point to the data directory,
   which is usually `$prefix/share` where `$prefix` is the
   arg given to meson. eg

   ::

      XDG_DATA_DIRS=/usr/share:/usr/local/share:$HOME/entangle/share
      export XDG_DATA_DIRS

* `GI_TYPELIB_PATH` variable to point to the gobject introspection
   typelib repository which is usually `$prefix/lib/girepository-1.0`
   Some distros will need `lib64` instead of `lib`.

   ::

      GI_TYPELIB_PATH=$HOME/entangle/lib/girepository-1.0
      export GI_TYPELIB_PATH

OS distro packagers should use the `--disable-schemas-compile` arg
to configure to skip the compilation stage for schema files if
installing to the `/usr` prefix

Building entangle requires the following external packages to
be present

::

   meson                 >= 0.41.0
   glib2                 >= 2.26.0
   gdk-pixbf             >= 2.12.0
   gtk3                  >= 3.22.0
   libgphoto2            >= 2.4.11
   gudev                 >= 145
   gobject-introspection >= 1.54.0
   lcms2                 >= 2.0
   libpeas               >= 0.5.5
   gexiv2                >= 0.2.2
   LibRaw                >= 0.9.0
   adwaita-icon-theme


Communication
=============

To communicate with the development team, or to post patches
there is a technical mailing list:

https://groups.google.com/forum/#!forum/entangle-devel

Bugs found when using an OS distribution's binary packages should
be reported to the OS vendors' own bug tracker first. Otherwise
they can be reported to

https://gitlab.com/entangle/entangle/issues

The latest entangle code can be found in GIT at:

https://gitlab.com/entangle/entangle

For further information visit

https://entangle-photo.org/

Translators please see `po/README.rst <po/README.rst>`_ for more guidance.

UI shortcuts
============

There are a number of shortcuts available for common operations

* `s` - Trigger the shutter, to shoot a picture
* `p` - Toggle `live view` preview mode
* `esc` - Cancel the current operation
* `m` - Toggle aspect ratio image mask
* `h` - Toggle linear / logarithmic histogram
* `a` - Drive autofocus during preview
* `,` or `.` - Drive manual focus during preview (fine control)
* `<` or `>` - Drive manual focus during preview (coarse control)

License
=======

Entangle is distributed under the terms of the GNU GPL v3+, except
for the Logo which is under the Creative Commons 1.0 Public
Domain Dedication.

Please see the COPYING file for the complete GPLv3+ license
terms, or visit `GNU Licenses <https://www.gnu.org/licenses/>`_.

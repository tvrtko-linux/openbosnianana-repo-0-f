-- File    : hello.lua
-- Purpose : Brief demonstration of Luerl basics - execution of a file.
-- See     : ./hello.erl

print("Hello, File!")
-- File    : hello2-1.lua
-- Purpose : Demonstration of Luerl interface.
-- See     : ./examples/hello/hello2.erl

print("(6) Hello, File 'hello2-1'!")
-- File    : hello2-2.lua
-- Purpose : Demonstration of Luerl interface.
-- See     : ./examples/hello/hello2.erl

return 2137 * 42
-- File    : hello2-5.lua
-- Purpose : Demonstration of Luerl interface.
-- See     : ./examples/hello/hello2.erl

print ("(26) hello2-5.lua talking. a: " .. a)
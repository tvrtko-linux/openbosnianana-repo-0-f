-- File    : hello2-6.lua
-- Purpose : Demonstration of Luerl interface.
-- See     : ./examples/hello/hello2.erl

a = 'new contents of a'
print('(27) (a) ' .. a)
return a
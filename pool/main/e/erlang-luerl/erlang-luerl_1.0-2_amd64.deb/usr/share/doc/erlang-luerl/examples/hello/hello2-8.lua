-- File    : hello2-8.lua
-- Purpose : Demonstration of Luerl interface.
-- See     : ./examples/hello/hello2.erl

function old() print "(33) old" end

print "(32) News!"
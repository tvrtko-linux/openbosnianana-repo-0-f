Load {{ loads[0] }}, {{ loads[1] }}, {{ loads[2] }}

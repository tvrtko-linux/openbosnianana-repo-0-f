# Just the current version of Errbot.
# It is used for deployment on pypi AND for version checking at plugin load time.
VERSION = "6.1.7"

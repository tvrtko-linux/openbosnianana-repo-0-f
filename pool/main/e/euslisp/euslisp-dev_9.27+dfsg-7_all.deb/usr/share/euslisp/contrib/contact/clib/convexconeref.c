extern cone_inter();

convexcone()
{
    cone_inter();
}

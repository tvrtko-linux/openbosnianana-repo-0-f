/*								*/	
/*	Vector and Matrix Calculation Header			*/
/*								*/
/*			Ver.1.0, Jan.18,1988.			*/
/*								*/

#include <stdio.h>
#define MAX 16

typedef float REAL;
typedef REAL VECTOR[MAX];
typedef VECTOR MATRIX[MAX];

extern int func1(int);
int func2(int n){return (func1(n)+10);}

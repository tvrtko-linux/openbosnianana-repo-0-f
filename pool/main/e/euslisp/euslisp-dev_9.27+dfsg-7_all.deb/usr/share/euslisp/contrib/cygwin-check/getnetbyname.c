#include <netdb.h>

main(){
  cygwin32_getnetbyname("");
  getnetbyname("");  
}

#include <sys/file.h>

main(){
  lockf(0,0,0);
}

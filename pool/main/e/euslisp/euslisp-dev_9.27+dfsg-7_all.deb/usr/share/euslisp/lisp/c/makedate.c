char *makedate="Thu, 03 Sep 2020 07:38:01 +0000";
char *gitrevision="";
char *compilehost="";

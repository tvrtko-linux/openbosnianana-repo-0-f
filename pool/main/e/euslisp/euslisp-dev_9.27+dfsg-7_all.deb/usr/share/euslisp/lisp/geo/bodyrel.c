/* ./bodyrel.c :  entry=bodyrel */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "bodyrel.h"
#pragma init (register_bodyrel)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___bodyrel();
extern pointer build_quote_vector();
static int register_bodyrel()
  { add_module_initializer("___bodyrel", ___bodyrel);}

static pointer bodyrelF3903coplanar_fe_intersection();
static pointer bodyrelF3904find_next_segment();
static pointer bodyrelF3905find_loop();
static pointer bodyrelF3906punch_hole();
static pointer bodyrelF3907construct_polygon();
static pointer bodyrelF3908remove_non_overlapping_border();
static pointer bodyrelF3909coplanar_ff_intersection();
static pointer bodyrelF3910face_();
static pointer bodyrelF3911face_();
static pointer bodyrelF3912non_coplanar_fe_relation();
static pointer bodyrelF3913ff_relation();
static pointer bodyrelF3914bb_relation();
static pointer bodyrelF3915make_lines();
static pointer bodyrelF3916copy_face();

/*coplanar-fe-intersection*/
static pointer bodyrelF3903coplanar_fe_intersection(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto bodyrelENT3920;}
	local[0]= fqv[0];
bodyrelENT3920:
	if (n>=4) { local[1]=(argv[3]); goto bodyrelENT3919;}
	local[1]= loadglobal(fqv[1]);
bodyrelENT3919:
bodyrelENT3918:
	if (n>4) maerror();
	local[2]= argv[1]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)COPYSEQ(ctx,1,local+2); /*copy-seq*/
	local[2]= w;
	local[3]= argv[1]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)COPYSEQ(ctx,1,local+3); /*copy-seq*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)SQRT(ctx,1,local+10); /*sqrt*/
	local[10]= w;
	local[11]= NIL;
	local[12]= argv[0];
	local[13]= fqv[2];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
bodyrelWHL3921:
	if (local[12]==NIL) goto bodyrelWHX3922;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12] = (w)->c.cons.cdr;
	w = local[13];
	local[11] = w;
	local[13]= local[11];
	local[14]= fqv[3];
	local[15]= argv[1];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,4,local+13); /*send*/
	local[5] = w;
	w = local[5];
	if (!iscons(w)) goto bodyrelIF3924;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= fqv[4];
	ctx->vsp=local+15;
	w=(pointer)EQ(ctx,2,local+13); /*eql*/
	if (w==NIL) goto bodyrelIF3926;
	local[13]= local[11];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	w = local[4];
	ctx->vsp=local+14;
	local[4] = cons(ctx,local[13],w);
	local[13]= local[4];
	goto bodyrelIF3927;
bodyrelIF3926:
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w = local[4];
	ctx->vsp=local+14;
	local[4] = cons(ctx,local[13],w);
	local[13]= local[4];
bodyrelIF3927:
	goto bodyrelIF3925;
bodyrelIF3924:
	local[13]= NIL;
bodyrelIF3925:
	goto bodyrelWHL3921;
bodyrelWHX3922:
	local[13]= NIL;
bodyrelBLK3923:
	w = NIL;
	if (local[4]!=NIL) goto bodyrelIF3928;
	local[11]= argv[0];
	local[12]= fqv[5];
	local[13]= argv[1]->c.obj.iv[1];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[5] = w;
	local[11]= NIL;
	local[12]= local[5];
	if (local[0]!=local[12]) goto bodyrelIF3930;
	local[12]= NIL;
	local[13]= local[2];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,3,local+12); /*list*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	local[12]= w;
	goto bodyrelIF3931;
bodyrelIF3930:
	local[12]= NIL;
bodyrelIF3931:
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,2,local+11); /*list*/
	ctx->vsp=local+11;
	local[0]=w;
	goto bodyrelBLK3917;
	goto bodyrelIF3929;
bodyrelIF3928:
	local[11]= NIL;
bodyrelIF3929:
	local[11]= local[4];
	local[12]= (pointer)get_sym_func(fqv[6]);
	ctx->vsp=local+13;
	local[13]= makeclosure(codevec,quotevec,bodyrelCLO3932,env,argv,local);
	ctx->vsp=local+14;
	w=(pointer)SORT(ctx,3,local+11); /*sort*/
	local[4] = w;
	local[11]= local[4];
	local[12]= makeflt(1.0000000000000000000000e+00);
	w = NIL;
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)NCONC(ctx,2,local+11); /*nconc*/
	local[6] = makeflt(0.0000000000000000000000e+00);
	local[11]= NIL;
	local[12]= local[4];
bodyrelWHL3933:
	if (local[12]==NIL) goto bodyrelWHX3934;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12] = (w)->c.cons.cdr;
	w = local[13];
	local[11] = w;
	w = local[11];
	if (!iscons(w)) goto bodyrelIF3936;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	goto bodyrelIF3937;
bodyrelIF3936:
	local[13]= local[11];
bodyrelIF3937:
	local[7] = local[13];
	local[13]= local[6];
	local[14]= local[7];
	local[15]= local[1];
	ctx->vsp=local+16;
	w=(*ftab[0])(ctx,3,local+13,&ftab[0],fqv[7]); /*eps<*/
	if (w==NIL) goto bodyrelIF3938;
	local[13]= argv[0];
	local[14]= fqv[5];
	local[15]= argv[1];
	local[16]= fqv[8];
	local[17]= local[6];
	local[18]= local[7];
	ctx->vsp=local+19;
	w=(pointer)PLUS(ctx,2,local+17); /*+*/
	local[17]= w;
	local[18]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+19;
	w=(pointer)QUOTIENT(ctx,2,local+17); /*/*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[5] = w;
	local[13]= local[5];
	if (local[0]!=local[13]) goto bodyrelIF3940;
	local[13]= T;
	local[14]= argv[1];
	local[15]= fqv[8];
	local[16]= local[6];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= w;
	local[15]= argv[1];
	local[16]= fqv[8];
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,3,local+13); /*list*/
	local[13]= w;
	w = local[9];
	ctx->vsp=local+14;
	local[9] = cons(ctx,local[13],w);
	local[13]= local[9];
	goto bodyrelIF3941;
bodyrelIF3940:
	local[13]= NIL;
bodyrelIF3941:
	local[6] = local[7];
	local[13]= local[6];
	goto bodyrelIF3939;
bodyrelIF3938:
	local[13]= NIL;
bodyrelIF3939:
	w = local[11];
	if (!iscons(w)) goto bodyrelIF3942;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.car;
	local[13]= local[6];
	local[14]= local[7];
	local[15]= local[1];
	ctx->vsp=local+16;
	w=(*ftab[1])(ctx,3,local+13,&ftab[1],fqv[9]); /*eps<>*/
	if (w==NIL) goto bodyrelIF3944;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= argv[1];
	local[15]= argv[1];
	local[16]= fqv[8];
	local[17]= local[6];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	local[16]= argv[1];
	local[17]= fqv[8];
	local[18]= local[7];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,3,local+16); /*send*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,4,local+13); /*list*/
	local[13]= w;
	w = local[8];
	ctx->vsp=local+14;
	local[8] = cons(ctx,local[13],w);
	local[13]= local[8];
	goto bodyrelIF3945;
bodyrelIF3944:
	local[13]= NIL;
bodyrelIF3945:
	local[6] = local[7];
	local[13]= local[6];
	goto bodyrelIF3943;
bodyrelIF3942:
	local[13]= NIL;
bodyrelIF3943:
	goto bodyrelWHL3933;
bodyrelWHX3934:
	local[13]= NIL;
bodyrelBLK3935:
	w = NIL;
	local[11]= local[8];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,2,local+11); /*list*/
	local[0]= w;
bodyrelBLK3917:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer bodyrelCLO3932(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!isnum(w)) goto bodyrelIF3946;
	local[0]= argv[0];
	goto bodyrelIF3947;
bodyrelIF3946:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
bodyrelIF3947:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*find-next-segment*/
static pointer bodyrelF3904find_next_segment(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeflt(1.0000000000000000000000e+20);
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[1];
bodyrelWHL3949:
	if (local[3]==NIL) goto bodyrelWHX3950;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= argv[0];
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)VDISTANCE(ctx,2,local+4); /*distance*/
	local[4]= w;
	local[5]= argv[0];
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)VDISTANCE(ctx,2,local+5); /*distance*/
	local[5]= w;
	local[6]= local[4];
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)MIN(ctx,2,local+6); /*min*/
	local[6]= w;
	local[7]= local[6];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto bodyrelIF3952;
	local[1] = local[2];
	local[0] = local[6];
	local[7]= local[0];
	goto bodyrelIF3953;
bodyrelIF3952:
	local[7]= NIL;
bodyrelIF3953:
	w = local[7];
	goto bodyrelWHL3949;
bodyrelWHX3950:
	local[4]= NIL;
bodyrelBLK3951:
	w = NIL;
	local[2]= local[0];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto bodyrelIF3954;
	local[2]= local[1];
	goto bodyrelIF3955;
bodyrelIF3954:
	local[2]= NIL;
bodyrelIF3955:
	w = local[2];
	local[0]= w;
bodyrelBLK3948:
	ctx->vsp=local; return(local[0]);}

/*find-loop*/
static pointer bodyrelF3905find_loop(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto bodyrelENT3958;}
	local[0]= loadglobal(fqv[10]);
bodyrelENT3958:
bodyrelENT3957:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= loadglobal(fqv[11]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= NIL;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[9];
	local[2] = w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.car;
	local[9]= local[4];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[1] = w;
bodyrelWHL3959:
	local[9]= local[5];
	local[10]= argv[0];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)bodyrelF3904find_next_segment(ctx,3,local+9); /*find-next-segment*/
	local[6] = w;
	if (local[6]==NIL) goto bodyrelWHX3960;
	local[9]= local[6];
	local[10]= argv[0];
	local[11]= fqv[12];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(*ftab[2])(ctx,4,local+9,&ftab[2],fqv[13]); /*delete*/
	argv[0] = w;
	local[3] = local[5];
	local[9]= local[5];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,2,local+9,&ftab[3],fqv[14]); /*eps-v=*/
	if (w==NIL) goto bodyrelIF3962;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.car;
	local[9]= local[5];
	goto bodyrelIF3963;
bodyrelIF3962:
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.car;
	local[9]= local[5];
bodyrelIF3963:
	local[9]= local[3];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	local[9]= w;
	w = local[1];
	ctx->vsp=local+10;
	local[1] = cons(ctx,local[9],w);
	goto bodyrelWHL3959;
bodyrelWHX3960:
	local[9]= NIL;
bodyrelBLK3961:
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)NREVERSE(ctx,1,local+9); /*nreverse*/
	local[1] = w;
	local[9]= local[4];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,2,local+9,&ftab[3],fqv[14]); /*eps-v=*/
	if (w!=NIL) goto bodyrelCON3965;
	local[9]= NIL;
	local[10]= local[1];
bodyrelWHL3966:
	if (local[10]==NIL) goto bodyrelWHX3967;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	ctx->vsp=local+13;
	w=(*ftab[4])(ctx,2,local+11,&ftab[4],fqv[15]); /*make-line*/
	local[11]= w;
	w = local[8];
	ctx->vsp=local+12;
	local[8] = cons(ctx,local[11],w);
	goto bodyrelWHL3966;
bodyrelWHX3967:
	local[11]= NIL;
bodyrelBLK3968:
	w = NIL;
	local[9]= local[8];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	local[9]= w;
	goto bodyrelCON3964;
bodyrelCON3965:
	local[9]= (pointer)get_sym_func(fqv[16]);
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[1] = w;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(*ftab[5])(ctx,1,local+9,&ftab[5],fqv[17]); /*face-normal-vector*/
	local[9]= w;
	local[10]= argv[1];
	ctx->vsp=local+11;
	w=(pointer)VINNERPRODUCT(ctx,2,local+9); /*v.*/
	local[9]= w;
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[9]);
	if (left >= right) goto bodyrelIF3970;}
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)NREVERSE(ctx,1,local+9); /*nreverse*/
	local[1] = w;
	local[9]= local[1];
	goto bodyrelIF3971;
bodyrelIF3970:
	local[9]= NIL;
bodyrelIF3971:
	local[9]= loadglobal(fqv[11]);
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= fqv[18];
	local[12]= fqv[19];
	local[13]= local[1];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,4,local+10); /*send*/
	w = local[9];
	local[7] = w;
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[9]= w;
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	local[9]= w;
	goto bodyrelCON3964;
bodyrelCON3969:
	local[9]= NIL;
bodyrelCON3964:
	w = local[9];
	local[0]= w;
bodyrelBLK3956:
	ctx->vsp=local; return(local[0]);}

/*punch-hole*/
static pointer bodyrelF3906punch_hole(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= fqv[19];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	ctx->vsp=local+1;
	w=(pointer)REVERSE(ctx,1,local+0); /*reverse*/
	local[0]= w;
	local[1]= loadglobal(fqv[20]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[18];
	local[4]= fqv[19];
	local[5]= local[0];
	local[6]= fqv[21];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[22];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[0]= w;
bodyrelBLK3972:
	ctx->vsp=local; return(local[0]);}

/*construct-polygon*/
static pointer bodyrelF3907construct_polygon(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto bodyrelENT3975;}
	local[0]= loadglobal(fqv[10]);
bodyrelENT3975:
bodyrelENT3974:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
bodyrelWHL3976:
	if (argv[0]==NIL) goto bodyrelWHX3977;
	local[7]= argv[0];
	local[8]= argv[1];
	ctx->vsp=local+9;
	w=(pointer)bodyrelF3905find_loop(ctx,2,local+7); /*find-loop*/
	local[4] = w;
	local[7]= NIL;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
bodyrelWHL3979:
	if (local[8]==NIL) goto bodyrelWHX3980;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= local[7];
	local[10]= loadglobal(fqv[23]);
	ctx->vsp=local+11;
	w=(pointer)DERIVEDP(ctx,2,local+9); /*derivedp*/
	if (w==NIL) goto bodyrelIF3982;
	local[9]= local[7];
	w = local[2];
	ctx->vsp=local+10;
	local[2] = cons(ctx,local[9],w);
	local[9]= local[2];
	goto bodyrelIF3983;
bodyrelIF3982:
	local[9]= local[7];
	w = local[1];
	ctx->vsp=local+10;
	local[1] = cons(ctx,local[9],w);
	local[9]= local[1];
bodyrelIF3983:
	goto bodyrelWHL3979;
bodyrelWHX3980:
	local[9]= NIL;
bodyrelBLK3981:
	w = NIL;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.car;
	goto bodyrelWHL3976;
bodyrelWHX3977:
	local[7]= NIL;
bodyrelBLK3978:
	local[7]= NIL;
	local[8]= local[1];
bodyrelWHL3984:
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto bodyrelWHX3985;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= NIL;
	local[10]= local[8];
bodyrelWHL3987:
	if (local[10]==NIL) goto bodyrelWHX3988;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	local[11]= local[7];
	local[12]= fqv[5];
	local[13]= local[9];
	local[14]= fqv[24];
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	local[12]= fqv[0];
	ctx->vsp=local+13;
	w=(pointer)EQ(ctx,2,local+11); /*eql*/
	if (w==NIL) goto bodyrelCON3991;
	local[11]= local[7];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)bodyrelF3906punch_hole(ctx,2,local+11); /*punch-hole*/
	local[11]= local[9];
	local[12]= local[1];
	local[13]= fqv[12];
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(*ftab[2])(ctx,4,local+11,&ftab[2],fqv[13]); /*delete*/
	local[1] = w;
	local[11]= local[1];
	goto bodyrelCON3990;
bodyrelCON3991:
	local[11]= local[9];
	local[12]= fqv[5];
	local[13]= local[7];
	local[14]= fqv[24];
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	local[12]= fqv[0];
	ctx->vsp=local+13;
	w=(pointer)EQ(ctx,2,local+11); /*eql*/
	if (w==NIL) goto bodyrelCON3992;
	local[11]= local[9];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)bodyrelF3906punch_hole(ctx,2,local+11); /*punch-hole*/
	local[11]= local[7];
	local[12]= local[1];
	local[13]= fqv[12];
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(*ftab[2])(ctx,4,local+11,&ftab[2],fqv[13]); /*delete*/
	local[1] = w;
	local[11]= local[1];
	goto bodyrelCON3990;
bodyrelCON3992:
	local[11]= NIL;
bodyrelCON3990:
	goto bodyrelWHL3987;
bodyrelWHX3988:
	local[11]= NIL;
bodyrelBLK3989:
	w = NIL;
	goto bodyrelWHL3984;
bodyrelWHX3985:
	local[9]= NIL;
bodyrelBLK3986:
	w = local[9];
	local[7]= local[1];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)NCONC(ctx,2,local+7); /*nconc*/
	local[0]= w;
bodyrelBLK3973:
	ctx->vsp=local; return(local[0]);}

/*remove-non-overlapping-border*/
static pointer bodyrelF3908remove_non_overlapping_border(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[25];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= fqv[25];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[2];
bodyrelWHL3994:
	if (local[4]==NIL) goto bodyrelWHX3995;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= local[5];
	local[8]= fqv[26];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+7); /*v**/
	local[7]= w;
	local[8]= local[6];
	local[9]= fqv[26];
	local[10]= argv[1];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+8); /*v**/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)VINNERPRODUCT(ctx,2,local+7); /*v.*/
	local[7]= w;
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[7]);
	if (left <= right) goto bodyrelIF3997;}
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
	w = local[2];
	ctx->vsp=local+8;
	local[2] = cons(ctx,local[7],w);
	local[7]= local[2];
	goto bodyrelIF3998;
bodyrelIF3997:
	local[7]= NIL;
bodyrelIF3998:
	w = local[7];
	goto bodyrelWHL3994;
bodyrelWHX3995:
	local[5]= NIL;
bodyrelBLK3996:
	w = NIL;
	w = local[2];
	local[0]= w;
bodyrelBLK3993:
	ctx->vsp=local; return(local[0]);}

/*coplanar-ff-intersection*/
static pointer bodyrelF3909coplanar_ff_intersection(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto bodyrelENT4002;}
	local[0]= fqv[0];
bodyrelENT4002:
	if (n>=4) { local[1]=(argv[3]); goto bodyrelENT4001;}
	local[1]= loadglobal(fqv[1]);
bodyrelENT4001:
bodyrelENT4000:
	if (n>4) maerror();
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= argv[0];
	local[10]= fqv[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
bodyrelWHL4003:
	if (local[9]==NIL) goto bodyrelWHX4004;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= argv[1];
	local[11]= local[8];
	local[12]= local[0];
	local[13]= local[1];
	ctx->vsp=local+14;
	w=(pointer)bodyrelF3903coplanar_fe_intersection(ctx,4,local+10); /*coplanar-fe-intersection*/
	local[6] = w;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto bodyrelIF4006;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)NCONC(ctx,2,local+10); /*nconc*/
	local[4] = w;
	local[10]= local[4];
	goto bodyrelIF4007;
bodyrelIF4006:
	local[10]= NIL;
bodyrelIF4007:
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto bodyrelIF4008;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)NCONC(ctx,2,local+10); /*nconc*/
	local[2] = w;
	local[10]= local[2];
	goto bodyrelIF4009;
bodyrelIF4008:
	local[10]= NIL;
bodyrelIF4009:
	goto bodyrelWHL4003;
bodyrelWHX4004:
	local[10]= NIL;
bodyrelBLK4005:
	w = NIL;
	if (local[4]==NIL) goto bodyrelIF4010;
	local[7] = T;
	local[8]= local[7];
	goto bodyrelIF4011;
bodyrelIF4010:
	local[8]= NIL;
bodyrelIF4011:
	if (T==NIL) goto bodyrelIF4012;
	local[8]= argv[1];
	local[9]= argv[0];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)bodyrelF3908remove_non_overlapping_border(ctx,3,local+8); /*remove-non-overlapping-border*/
	local[4] = w;
	local[8]= local[4];
	goto bodyrelIF4013;
bodyrelIF4012:
	local[8]= (pointer)get_sym_func(fqv[27]);
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)MAPCAR(ctx,2,local+8); /*mapcar*/
	local[4] = w;
	local[8]= local[4];
bodyrelIF4013:
	local[8]= NIL;
	local[9]= argv[1];
	local[10]= fqv[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
bodyrelWHL4014:
	if (local[9]==NIL) goto bodyrelWHX4015;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= argv[0];
	local[11]= local[8];
	local[12]= local[0];
	local[13]= local[1];
	ctx->vsp=local+14;
	w=(pointer)bodyrelF3903coplanar_fe_intersection(ctx,4,local+10); /*coplanar-fe-intersection*/
	local[6] = w;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto bodyrelIF4017;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)NCONC(ctx,2,local+10); /*nconc*/
	local[5] = w;
	local[10]= local[5];
	goto bodyrelIF4018;
bodyrelIF4017:
	local[10]= NIL;
bodyrelIF4018:
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto bodyrelIF4019;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)NCONC(ctx,2,local+10); /*nconc*/
	local[2] = w;
	local[10]= local[2];
	goto bodyrelIF4020;
bodyrelIF4019:
	local[10]= NIL;
bodyrelIF4020:
	goto bodyrelWHL4014;
bodyrelWHX4015:
	local[10]= NIL;
bodyrelBLK4016:
	w = NIL;
	if (local[5]==NIL) goto bodyrelIF4021;
	local[7] = T;
	local[8]= local[7];
	goto bodyrelIF4022;
bodyrelIF4021:
	local[8]= NIL;
bodyrelIF4022:
	if (T==NIL) goto bodyrelIF4023;
	local[8]= argv[0];
	local[9]= argv[1];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)bodyrelF3908remove_non_overlapping_border(ctx,3,local+8); /*remove-non-overlapping-border*/
	local[5] = w;
	local[8]= local[5];
	goto bodyrelIF4024;
bodyrelIF4023:
	local[8]= (pointer)get_sym_func(fqv[27]);
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)MAPCAR(ctx,2,local+8); /*mapcar*/
	local[5] = w;
	local[8]= local[5];
bodyrelIF4024:
	local[8]= local[4];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)NCONC(ctx,2,local+8); /*nconc*/
	local[3] = w;
	local[8]= local[3];
	local[9]= fqv[28];
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,bodyrelCLO4025,env,argv,local);
	ctx->vsp=local+11;
	w=(*ftab[6])(ctx,3,local+8,&ftab[6],fqv[29]); /*remove-duplicates*/
	local[3] = w;
	if (local[7]!=NIL) goto bodyrelCON4027;
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,bodyrelCLO4028,env,argv,local);
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[7])(ctx,2,local+8,&ftab[7],fqv[30]); /*every*/
	if (w==NIL) goto bodyrelCON4027;
	local[8]= argv[0];
	local[9]= fqv[5];
	local[10]= argv[1];
	local[11]= fqv[24];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= w;
	local[11]= makeflt(1.0000000000000000208167e-03);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= w;
	local[9]= argv[1];
	local[10]= fqv[5];
	local[11]= argv[0];
	local[12]= fqv[24];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	local[12]= makeflt(1.0000000000000000208167e-03);
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= w;
	local[10]= local[0];
	local[11]= fqv[0];
	ctx->vsp=local+12;
	w=(pointer)EQ(ctx,2,local+10); /*eql*/
	if (w==NIL) goto bodyrelCON4030;
	local[10]= local[8];
	local[11]= fqv[0];
	ctx->vsp=local+12;
	w=(pointer)EQ(ctx,2,local+10); /*eql*/
	if (w==NIL) goto bodyrelCON4032;
	local[10]= argv[1];
	goto bodyrelCON4031;
bodyrelCON4032:
	local[10]= local[9];
	local[11]= fqv[0];
	ctx->vsp=local+12;
	w=(pointer)EQ(ctx,2,local+10); /*eql*/
	if (w==NIL) goto bodyrelCON4033;
	local[10]= argv[0];
	goto bodyrelCON4031;
bodyrelCON4033:
	local[10]= NIL;
	goto bodyrelCON4031;
bodyrelCON4034:
	local[10]= NIL;
bodyrelCON4031:
	goto bodyrelCON4029;
bodyrelCON4030:
	local[10]= local[0];
	local[11]= fqv[31];
	ctx->vsp=local+12;
	w=(pointer)EQ(ctx,2,local+10); /*eql*/
	if (w==NIL) goto bodyrelCON4035;
	local[10]= local[8];
	local[11]= fqv[0];
	ctx->vsp=local+12;
	w=(pointer)EQ(ctx,2,local+10); /*eql*/
	if (w==NIL) goto bodyrelCON4037;
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	local[10]= w;
	goto bodyrelCON4036;
bodyrelCON4037:
	local[10]= local[9];
	local[11]= fqv[0];
	ctx->vsp=local+12;
	w=(pointer)EQ(ctx,2,local+10); /*eql*/
	if (w==NIL) goto bodyrelCON4038;
	local[10]= argv[1];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	local[10]= w;
	goto bodyrelCON4036;
bodyrelCON4038:
	local[10]= argv[0];
	local[11]= argv[1];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,2,local+10); /*list*/
	local[10]= w;
	goto bodyrelCON4036;
bodyrelCON4039:
	local[10]= NIL;
bodyrelCON4036:
	goto bodyrelCON4029;
bodyrelCON4035:
	local[10]= NIL;
bodyrelCON4029:
	w = local[10];
	local[8]= w;
	goto bodyrelCON4026;
bodyrelCON4027:
	local[8]= (pointer)get_sym_func(fqv[32]);
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)MAPCAR(ctx,2,local+8); /*mapcar*/
	local[8]= w;
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)NCONC(ctx,2,local+8); /*nconc*/
	local[8]= w;
	local[9]= argv[0];
	local[10]= fqv[25];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)bodyrelF3907construct_polygon(ctx,2,local+8); /*construct-polygon*/
	local[8]= w;
	goto bodyrelCON4026;
bodyrelCON4040:
	local[8]= NIL;
bodyrelCON4026:
	w = local[8];
	local[0]= w;
bodyrelBLK3999:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer bodyrelCLO4025(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= env->c.clo.env2[1];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,3,local+0,&ftab[3],fqv[14]); /*eps-v=*/
	local[0]= w;
	if (w==NIL) goto bodyrelAND4042;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= env->c.clo.env2[1];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,3,local+0,&ftab[3],fqv[14]); /*eps-v=*/
	local[0]= w;
bodyrelAND4042:
	if (local[0]!=NIL) goto bodyrelOR4041;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= env->c.clo.env2[1];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,3,local+0,&ftab[3],fqv[14]); /*eps-v=*/
	local[0]= w;
	if (w==NIL) goto bodyrelAND4043;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= env->c.clo.env2[1];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,3,local+0,&ftab[3],fqv[14]); /*eps-v=*/
	local[0]= w;
bodyrelAND4043:
bodyrelOR4041:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer bodyrelCLO4028(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (((w)->c.cons.car)==NIL?T:NIL);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*face**/
static pointer bodyrelF3910face_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto bodyrelENT4046;}
	local[0]= loadglobal(fqv[1]);
bodyrelENT4046:
bodyrelENT4045:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= argv[1];
	local[3]= fqv[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)bodyrelF3909coplanar_ff_intersection(ctx,4,local+1); /*coplanar-ff-intersection*/
	local[0]= w;
bodyrelBLK4044:
	ctx->vsp=local; return(local[0]);}

/*face+*/
static pointer bodyrelF3911face_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto bodyrelENT4049;}
	local[0]= loadglobal(fqv[1]);
bodyrelENT4049:
bodyrelENT4048:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= argv[1];
	local[3]= fqv[31];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)bodyrelF3909coplanar_ff_intersection(ctx,4,local+1); /*coplanar-ff-intersection*/
	local[0]= w;
bodyrelBLK4047:
	ctx->vsp=local; return(local[0]);}

/*non-coplanar-fe-relation*/
static pointer bodyrelF3912non_coplanar_fe_relation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto bodyrelENT4052;}
	local[0]= loadglobal(fqv[1]);
bodyrelENT4052:
bodyrelENT4051:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[33];
	local[3]= argv[1]->c.obj.iv[1];
	local[4]= argv[1]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= argv[1];
	local[3]= fqv[8];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= NIL;
	local[4]= local[1];
	local[5]= makeflt(0.0000000000000000000000e+00);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[8])(ctx,3,local+4,&ftab[8],fqv[34]); /*eps=*/
	if (w!=NIL) goto bodyrelOR4055;
	local[4]= local[1];
	local[5]= makeflt(1.0000000000000000000000e+00);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[8])(ctx,3,local+4,&ftab[8],fqv[34]); /*eps=*/
	if (w!=NIL) goto bodyrelOR4055;
	goto bodyrelCON4054;
bodyrelOR4055:
	local[4]= argv[0];
	local[5]= fqv[5];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[3] = w;
	local[4]= local[3];
	local[5]= fqv[35];
	ctx->vsp=local+6;
	w=(*ftab[9])(ctx,2,local+4,&ftab[9],fqv[36]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	goto bodyrelCON4053;
bodyrelCON4054:
	local[4]= makeflt(0.0000000000000000000000e+00);
	local[5]= local[1];
	local[6]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)LESSP(ctx,3,local+4); /*<*/
	if (w==NIL) goto bodyrelCON4056;
	local[4]= argv[0];
	local[5]= fqv[5];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[3] = w;
	local[4]= local[3];
	local[5]= local[4];
	if (fqv[0]!=local[5]) goto bodyrelIF4057;
	local[5]= argv[0];
	local[6]= fqv[37];
	local[7]= argv[1]->c.obj.iv[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	if (w==NIL) goto bodyrelIF4059;
	local[5]= argv[0];
	local[6]= fqv[37];
	local[7]= argv[1]->c.obj.iv[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	if (w==NIL) goto bodyrelIF4059;
	local[5]= fqv[38];
	goto bodyrelIF4060;
bodyrelIF4059:
	local[5]= fqv[39];
bodyrelIF4060:
	goto bodyrelIF4058;
bodyrelIF4057:
	local[5]= local[4];
	if (fqv[40]!=local[5]) goto bodyrelIF4061;
	local[5]= fqv[38];
	goto bodyrelIF4062;
bodyrelIF4061:
	local[5]= local[4];
	if (fqv[31]!=local[5]) goto bodyrelIF4063;
	local[5]= NIL;
	goto bodyrelIF4064;
bodyrelIF4063:
	local[5]= NIL;
bodyrelIF4064:
bodyrelIF4062:
bodyrelIF4058:
	w = local[5];
	local[4]= w;
	goto bodyrelCON4053;
bodyrelCON4056:
	local[4]= NIL;
	goto bodyrelCON4053;
bodyrelCON4065:
	local[4]= NIL;
bodyrelCON4053:
	w = local[4];
	local[0]= w;
bodyrelBLK4050:
	ctx->vsp=local; return(local[0]);}

/*ff-relation*/
static pointer bodyrelF3913ff_relation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto bodyrelENT4068;}
	local[0]= loadglobal(fqv[1]);
bodyrelENT4068:
bodyrelENT4067:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[1]->c.obj.iv[1];
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= argv[1]->c.obj.iv[2];
	local[5]= argv[0]->c.obj.iv[4];
	local[6]= argv[1]->c.obj.iv[4];
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= local[1];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)VINNERPRODUCT(ctx,2,local+13); /*v.*/
	local[13]= w;
	local[14]= makeflt(1.0000000000000000000000e+00);
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(*ftab[8])(ctx,3,local+13,&ftab[8],fqv[34]); /*eps=*/
	if (w==NIL) goto bodyrelCON4070;
	local[13]= local[3];
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(*ftab[8])(ctx,2,local+13,&ftab[8],fqv[34]); /*eps=*/
	if (w==NIL) goto bodyrelIF4071;
	local[13]= fqv[41];
	local[14]= fqv[42];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,2,local+13); /*list*/
	local[9] = w;
	local[13]= local[9];
	goto bodyrelIF4072;
bodyrelIF4071:
	w = NIL;
	ctx->vsp=local+13;
	local[0]=w;
	goto bodyrelBLK4066;
bodyrelIF4072:
	goto bodyrelCON4069;
bodyrelCON4070:
	local[13]= local[1];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)VINNERPRODUCT(ctx,2,local+13); /*v.*/
	local[13]= w;
	local[14]= makeflt(-1.0000000000000000000000e+00);
	ctx->vsp=local+15;
	w=(*ftab[8])(ctx,2,local+13,&ftab[8],fqv[34]); /*eps=*/
	if (w==NIL) goto bodyrelCON4073;
	local[13]= local[3];
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,1,local+14); /*-*/
	local[14]= w;
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(*ftab[8])(ctx,3,local+13,&ftab[8],fqv[34]); /*eps=*/
	if (w==NIL) goto bodyrelIF4074;
	local[13]= fqv[41];
	local[14]= fqv[43];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,2,local+13); /*list*/
	local[9] = w;
	local[13]= local[9];
	goto bodyrelIF4075;
bodyrelIF4074:
	w = NIL;
	ctx->vsp=local+13;
	local[0]=w;
	goto bodyrelBLK4066;
bodyrelIF4075:
	goto bodyrelCON4069;
bodyrelCON4073:
	local[13]= NIL;
bodyrelCON4069:
	if (local[9]==NIL) goto bodyrelIF4076;
	local[13]= argv[0];
	local[14]= argv[1];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(pointer)bodyrelF3910face_(ctx,3,local+13); /*face**/
	local[10] = w;
	local[13]= local[10];
	local[14]= loadglobal(fqv[11]);
	ctx->vsp=local+15;
	w=(pointer)DERIVEDP(ctx,2,local+13); /*derivedp*/
	if (w==NIL) goto bodyrelCON4079;
	local[13]= local[9];
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)APPEND(ctx,2,local+13); /*append*/
	ctx->vsp=local+13;
	local[0]=w;
	goto bodyrelBLK4066;
	goto bodyrelCON4078;
bodyrelCON4079:
	ctx->vsp=local+13;
	local[13]= makeclosure(codevec,quotevec,bodyrelCLO4081,env,argv,local);
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(*ftab[10])(ctx,2,local+13,&ftab[10],fqv[44]); /*some*/
	if (w==NIL) goto bodyrelCON4080;
	local[13]= local[9];
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)APPEND(ctx,2,local+13); /*append*/
	ctx->vsp=local+13;
	local[0]=w;
	goto bodyrelBLK4066;
	goto bodyrelCON4078;
bodyrelCON4080:
	ctx->vsp=local+13;
	local[13]= makeclosure(codevec,quotevec,bodyrelCLO4083,env,argv,local);
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(*ftab[7])(ctx,2,local+13,&ftab[7],fqv[30]); /*every*/
	if (w==NIL) goto bodyrelCON4082;
	local[13]= fqv[45];
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,2,local+13); /*list*/
	ctx->vsp=local+13;
	local[0]=w;
	goto bodyrelBLK4066;
	goto bodyrelCON4078;
bodyrelCON4082:
	local[13]= NIL;
bodyrelCON4078:
	goto bodyrelIF4077;
bodyrelIF4076:
	local[13]= NIL;
bodyrelIF4077:
	local[13]= NIL;
	local[14]= local[5];
bodyrelWHL4084:
	if (local[14]==NIL) goto bodyrelWHX4085;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14] = (w)->c.cons.cdr;
	w = local[15];
	local[13] = w;
	local[15]= argv[1];
	local[16]= local[13];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)bodyrelF3912non_coplanar_fe_relation(ctx,3,local+15); /*non-coplanar-fe-relation*/
	local[11] = w;
	local[15]= local[11];
	if (fqv[39]!=local[15]) goto bodyrelIF4087;
	local[15]= T;
	local[16]= fqv[46];
	local[17]= argv[1];
	local[18]= local[13];
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,4,local+15); /*format*/
	local[15]= fqv[39];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	local[0]=w;
	goto bodyrelBLK4066;
	goto bodyrelIF4088;
bodyrelIF4087:
	local[15]= NIL;
bodyrelIF4088:
	if (local[11]==NIL) goto bodyrelIF4089;
	local[15]= local[11];
	w = local[10];
	ctx->vsp=local+16;
	local[10] = cons(ctx,local[15],w);
	local[15]= local[10];
	goto bodyrelIF4090;
bodyrelIF4089:
	local[15]= NIL;
bodyrelIF4090:
	goto bodyrelWHL4084;
bodyrelWHX4085:
	local[15]= NIL;
bodyrelBLK4086:
	w = NIL;
	local[13]= NIL;
	local[14]= local[6];
bodyrelWHL4091:
	if (local[14]==NIL) goto bodyrelWHX4092;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14] = (w)->c.cons.cdr;
	w = local[15];
	local[13] = w;
	local[15]= argv[0];
	local[16]= local[13];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)bodyrelF3912non_coplanar_fe_relation(ctx,3,local+15); /*non-coplanar-fe-relation*/
	local[11] = w;
	local[15]= local[11];
	if (fqv[39]!=local[15]) goto bodyrelIF4094;
	local[15]= T;
	local[16]= fqv[47];
	local[17]= argv[0];
	local[18]= local[13];
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,4,local+15); /*format*/
	local[15]= fqv[39];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	local[0]=w;
	goto bodyrelBLK4066;
	goto bodyrelIF4095;
bodyrelIF4094:
	local[15]= NIL;
bodyrelIF4095:
	if (local[11]==NIL) goto bodyrelIF4096;
	local[15]= local[11];
	w = local[10];
	ctx->vsp=local+16;
	local[10] = cons(ctx,local[15],w);
	local[15]= local[10];
	goto bodyrelIF4097;
bodyrelIF4096:
	local[15]= NIL;
bodyrelIF4097:
	goto bodyrelWHL4091;
bodyrelWHX4092:
	local[15]= NIL;
bodyrelBLK4093:
	w = NIL;
	ctx->vsp=local+13;
	local[13]= makeclosure(codevec,quotevec,bodyrelCLO4100,env,argv,local);
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(*ftab[7])(ctx,2,local+13,&ftab[7],fqv[30]); /*every*/
	if (w==NIL) goto bodyrelCON4099;
	local[13]= fqv[48];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	local[13]= w;
	goto bodyrelCON4098;
bodyrelCON4099:
	local[13]= local[10];
	goto bodyrelCON4098;
bodyrelCON4101:
	local[13]= NIL;
bodyrelCON4098:
	w = local[13];
	local[0]= w;
bodyrelBLK4066:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer bodyrelCLO4081(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[11]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer bodyrelCLO4083(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[23]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer bodyrelCLO4100(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = ((fqv[38])==(local[0])?T:NIL);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*bb-relation*/
static pointer bodyrelF3914bb_relation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto bodyrelENT4104;}
	local[0]= loadglobal(fqv[49]);
bodyrelENT4104:
bodyrelENT4103:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[50];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= argv[0];
	local[9]= fqv[51];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= argv[1];
	local[10]= fqv[51];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= NIL;
	if (local[1]==NIL) goto bodyrelIF4105;
	local[12]= argv[0];
	local[13]= fqv[52];
	local[14]= local[1];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[2] = w;
	local[12]= argv[1];
	local[13]= fqv[52];
	local[14]= local[1];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[3] = w;
	local[12]= local[8];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(*ftab[11])(ctx,2,local+12,&ftab[11],fqv[53]); /*intersection*/
	local[8] = w;
	local[12]= local[9];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(*ftab[11])(ctx,2,local+12,&ftab[11],fqv[53]); /*intersection*/
	local[9] = w;
	local[12]= argv[0];
	local[13]= fqv[54];
	local[14]= local[1];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[4] = w;
	local[12]= argv[1];
	local[13]= fqv[54];
	local[14]= local[1];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[5] = w;
	local[12]= NIL;
	local[13]= local[2];
bodyrelWHL4107:
	if (local[13]==NIL) goto bodyrelWHX4108;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13] = (w)->c.cons.cdr;
	w = local[14];
	local[12] = w;
	local[14]= local[12];
	local[15]= fqv[55];
	local[16]= local[0];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[11] = w;
	local[14]= local[11];
	local[15]= fqv[56];
	local[16]= local[0];
	local[17]= T;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,4,local+14); /*send*/
	local[14]= NIL;
	local[15]= local[3];
bodyrelWHL4110:
	if (local[15]==NIL) goto bodyrelWHX4111;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.cdr;
	w = local[16];
	local[14] = w;
	local[16]= local[14];
	local[17]= fqv[55];
	local[18]= local[0];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,3,local+16); /*send*/
	local[16]= w;
	local[17]= fqv[57];
	local[18]= local[11];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,3,local+16); /*send*/
	if (w==NIL) goto bodyrelOR4115;
	goto bodyrelIF4113;
bodyrelOR4115:
	local[7] = NIL;
	local[16]= local[7];
	goto bodyrelIF4114;
bodyrelIF4113:
	local[16]= local[12];
	local[17]= local[14];
	local[18]= local[0];
	ctx->vsp=local+19;
	w=(pointer)bodyrelF3913ff_relation(ctx,3,local+16); /*ff-relation*/
	local[7] = w;
	local[16]= local[7];
bodyrelIF4114:
	if (local[7]!=NIL) goto bodyrelCON4117;
	local[16]= NIL;
	goto bodyrelCON4116;
bodyrelCON4117:
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	if (fqv[48]!=local[16]) goto bodyrelCON4118;
	local[16]= NIL;
	goto bodyrelCON4116;
bodyrelCON4118:
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	if (fqv[41]!=local[16]) goto bodyrelCON4119;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	if (fqv[43]!=local[16]) goto bodyrelCON4119;
	local[16]= fqv[58];
	local[17]= local[12];
	local[18]= local[14];
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.cdr;
	ctx->vsp=local+20;
	w=(pointer)LIST_STAR(ctx,4,local+16); /*list**/
	local[16]= w;
	w = local[6];
	ctx->vsp=local+17;
	local[6] = cons(ctx,local[16],w);
	local[16]= local[6];
	goto bodyrelCON4116;
bodyrelCON4119:
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	if (fqv[45]!=local[16]) goto bodyrelCON4120;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	if (fqv[42]!=local[16]) goto bodyrelCON4120;
	local[16]= fqv[45];
	local[17]= local[12];
	local[18]= local[14];
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,3,local+16); /*list*/
	local[16]= w;
	w = local[6];
	ctx->vsp=local+17;
	local[6] = cons(ctx,local[16],w);
	local[16]= local[6];
	goto bodyrelCON4116;
bodyrelCON4120:
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	if (fqv[41]!=local[16]) goto bodyrelCON4121;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	if (fqv[42]!=local[16]) goto bodyrelCON4121;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	local[17]= loadglobal(fqv[11]);
	ctx->vsp=local+18;
	w=(pointer)DERIVEDP(ctx,2,local+16); /*derivedp*/
	if (w==NIL) goto bodyrelCON4121;
	w = fqv[39];
	ctx->vsp=local+16;
	local[0]=w;
	goto bodyrelBLK4102;
	goto bodyrelCON4116;
bodyrelCON4121:
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	if (fqv[39]!=local[16]) goto bodyrelCON4122;
	w = fqv[39];
	ctx->vsp=local+16;
	local[0]=w;
	goto bodyrelBLK4102;
	goto bodyrelCON4116;
bodyrelCON4122:
	local[16]= local[12];
	local[17]= local[14];
	local[18]= local[7];
	ctx->vsp=local+19;
	w=(pointer)LIST_STAR(ctx,3,local+16); /*list**/
	local[16]= w;
	w = local[6];
	ctx->vsp=local+17;
	local[6] = cons(ctx,local[16],w);
	local[16]= local[6];
	goto bodyrelCON4116;
bodyrelCON4123:
	local[16]= NIL;
bodyrelCON4116:
	goto bodyrelWHL4110;
bodyrelWHX4111:
	local[16]= NIL;
bodyrelBLK4112:
	w = NIL;
	goto bodyrelWHL4107;
bodyrelWHX4108:
	local[14]= NIL;
bodyrelBLK4109:
	w = NIL;
	local[12]= local[6];
	goto bodyrelIF4106;
bodyrelIF4105:
	local[12]= NIL;
bodyrelIF4106:
	w = local[12];
	local[0]= w;
bodyrelBLK4102:
	ctx->vsp=local; return(local[0]);}

/*make-lines*/
static pointer bodyrelF3915make_lines(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,bodyrelCLO4125,env,argv,local);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
bodyrelBLK4124:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer bodyrelCLO4125(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= (pointer)get_sym_func(fqv[15]);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)APPLY(ctx,2,local+0); /*apply*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*copy-face*/
static pointer bodyrelF3916copy_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,bodyrelFLET4127,env,argv,local);
	local[1]= loadglobal(fqv[59]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[18];
	local[4]= fqv[19];
	local[5]= argv[0];
	w = local[0];
	ctx->vsp=local+6;
	w=bodyrelFLET4127(ctx,1,local+5,w);
	local[5]= w;
	local[6]= fqv[60];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,bodyrelCLO4128,env,argv,local);
	local[8]= local[0];
	local[9]= argv[0];
	local[10]= fqv[60];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MAPCAR(ctx,2,local+8); /*mapcar*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	w = local[1];
	local[0]= w;
bodyrelBLK4126:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer bodyrelFLET4127(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
	local[4]= fqv[19];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
bodyrelWHL4129:
	if (local[3]==NIL) goto bodyrelWHX4130;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)COPYSEQ(ctx,1,local+4); /*copy-seq*/
	local[4]= w;
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	goto bodyrelWHL4129;
bodyrelWHX4130:
	local[4]= NIL;
bodyrelBLK4131:
	w = local[1];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer bodyrelCLO4128(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[20]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[18];
	local[3]= fqv[19];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___bodyrel(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[61];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto bodyrelIF4132;
	local[0]= fqv[62];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[63],w);
	goto bodyrelIF4133;
bodyrelIF4132:
	local[0]= fqv[64];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
bodyrelIF4133:
	local[0]= fqv[65];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[66],module,bodyrelF3903coplanar_fe_intersection,fqv[67]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[68],module,bodyrelF3904find_next_segment,fqv[69]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[70],module,bodyrelF3905find_loop,fqv[71]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[72],module,bodyrelF3906punch_hole,fqv[73]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[74],module,bodyrelF3907construct_polygon,fqv[75]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[76],module,bodyrelF3908remove_non_overlapping_border,fqv[77]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[78],module,bodyrelF3909coplanar_ff_intersection,fqv[79]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[80],module,bodyrelF3910face_,fqv[81]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[82],module,bodyrelF3911face_,fqv[83]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[84],module,bodyrelF3912non_coplanar_fe_relation,fqv[85]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[86],module,bodyrelF3913ff_relation,fqv[87]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[88],module,bodyrelF3914bb_relation,fqv[89]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[90],module,bodyrelF3915make_lines,fqv[91]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[92],module,bodyrelF3916copy_face,fqv[93]);
	local[0]= fqv[94];
	local[1]= fqv[95];
	ctx->vsp=local+2;
	w=(*ftab[12])(ctx,2,local+0,&ftab[12],fqv[96]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<13; i++) ftab[i]=fcallx;
}

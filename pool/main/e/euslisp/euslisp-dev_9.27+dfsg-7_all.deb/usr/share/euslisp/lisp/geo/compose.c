/* ./compose.c :  entry=compose */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "compose.h"
#pragma init (register_compose)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___compose();
extern pointer build_quote_vector();
static int register_compose()
  { add_module_initializer("___compose", ___compose);}

static pointer composeF2108intersecting_edges();
static pointer composeF2109cut_body();
static pointer composeF2110insert_intersections();
static pointer composeF2111make_edge_segments();
static pointer composeF2112intersecting_segments();
static pointer composeF2113sort_edges_by_face();
static pointer composeF2114make_crossing_edges();
static pointer composeF2115add_alist();
static pointer composeF2116merge_segments();
static pointer composeF2117find_connecting_edge();
static pointer composeF2118construct_faces();
static pointer composeF2119initial_intersection_list();
static pointer composeF2120make_vertex_edge_htab();
static pointer composeF2121copy_add_vertex();
static pointer composeF2122find_colinear_int();
static pointer composeF2123contacting_faces();
static pointer composeF2124aligned_faces();
static pointer composeF2125find_equivalent_edge();
static pointer composeF2126unify_vertex();
static pointer composeF2127merge_edges_if_colinear();
static pointer composeF2128merge_contacting_faces();
static pointer composeF2129merge_aligned_faces();
static pointer composeF2130compose_body();
static pointer composeF2131set_original_face();
static pointer composeF2132body_();
static pointer composeF2133body_();
static pointer composeF2134body_();
static pointer composeF2135body_interference();
static pointer composeF2136body_();

/*intersecting-edges*/
static pointer composeF2108intersecting_edges(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[1];
composeWHL2138:
	if (local[3]==NIL) goto composeWHX2139;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= argv[0];
	local[5]= fqv[0];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[1] = w;
	if (local[1]==NIL) goto composeIF2141;
	local[4]= makeflt(0.0000000000000000000000e+00);
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)LSEQP(ctx,3,local+4); /*<=*/
	if (w==NIL) goto composeIF2141;
	local[4]= local[2];
	w = local[1];
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	w = local[0];
	ctx->vsp=local+5;
	local[0] = cons(ctx,local[4],w);
	local[4]= local[0];
	goto composeIF2142;
composeIF2141:
	local[4]= NIL;
composeIF2142:
	goto composeWHL2138;
composeWHX2139:
	local[4]= NIL;
composeBLK2140:
	w = NIL;
	w = local[0];
	local[0]= w;
composeBLK2137:
	ctx->vsp=local; return(local[0]);}

/*cut-body*/
static pointer composeF2109cut_body(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= argv[1];
	local[8]= argv[0];
	local[9]= fqv[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)composeF2108intersecting_edges(ctx,2,local+7); /*intersecting-edges*/
	local[1] = w;
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)composeF2113sort_edges_by_face(ctx,1,local+7); /*sort-edges-by-face*/
	local[0] = w;
	local[7]= NIL;
	local[8]= local[0];
composeWHL2144:
	if (local[8]==NIL) goto composeWHX2145;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.cdr;
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[0])(ctx,1,local+9,&ftab[0],fqv[2]); /*oddp*/
	if (w==NIL) goto composeIF2147;
	local[9]= fqv[3];
	ctx->vsp=local+10;
	w=(pointer)SIGERROR(ctx,1,local+9); /*error*/
	local[9]= w;
	goto composeIF2148;
composeIF2147:
	local[9]= NIL;
composeIF2148:
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	local[9]= local[5];
	local[10]= fqv[4];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= argv[1];
	local[11]= fqv[4];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+9); /*v**/
	local[3] = w;
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[1])(ctx,1,local+9,&ftab[1],fqv[5]); /*maxindex*/
	local[2] = w;
	local[9]= local[1];
	local[10]= local[3];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,2,local+10); /*aref*/
	local[10]= w;
	local[11]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+12;
	w=(pointer)GREATERP(ctx,2,local+10); /*>*/
	if (w==NIL) goto composeIF2149;
	local[10]= (pointer)get_sym_func(fqv[6]);
	goto composeIF2150;
composeIF2149:
	local[10]= (pointer)get_sym_func(fqv[7]);
composeIF2150:
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,composeCLO2151,env,argv,local);
	ctx->vsp=local+12;
	w=(pointer)SORT(ctx,3,local+9); /*sort*/
	local[1] = w;
composeWHL2152:
	if (local[1]==NIL) goto composeWHX2153;
	local[9]= loadglobal(fqv[8]);
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= fqv[9];
	local[12]= fqv[10];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= fqv[11];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	local[16]= fqv[12];
	local[17]= argv[1];
	local[18]= fqv[13];
	local[19]= local[5];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,10,local+10); /*send*/
	w = local[9];
	local[9]= w;
	w = local[4];
	ctx->vsp=local+10;
	local[4] = cons(ctx,local[9],w);
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	goto composeWHL2152;
composeWHX2153:
	local[9]= NIL;
composeBLK2154:
	goto composeWHL2144;
composeWHX2145:
	local[9]= NIL;
composeBLK2146:
	w = NIL;
	local[7]= argv[1];
	w = local[4];
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)composeF2118construct_faces(ctx,1,local+7); /*construct-faces*/
	local[0]= w;
composeBLK2143:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer composeCLO2151(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= env->c.clo.env2[2];
	ctx->vsp=local+2;
	w=(pointer)AREF(ctx,2,local+0); /*aref*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*insert-intersections*/
static pointer composeF2110insert_intersections(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,composeFLET2156,env,argv,local);
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[1];
composeWHL2157:
	if (local[5]==NIL) goto composeWHX2158;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[4];
	local[7]= fqv[14];
	local[8]= makeflt(9.9999999999999950039964e-03);
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[15];
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	if (w==NIL) goto composeIF2160;
	local[6]= NIL;
	local[7]= argv[0];
composeWHL2162:
	if (local[7]==NIL) goto composeWHX2163;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[4];
	local[9]= fqv[0];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[1] = w;
	w = local[1];
	if (!iscons(w)) goto composeIF2165;
	local[8]= local[4];
	local[9]= fqv[16];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	if (w!=NIL) goto composeIF2165;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
composeWHL2167:
	if (local[3]==NIL) goto composeWHX2168;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[2])(ctx,2,local+8,&ftab[2],fqv[17]); /*eps=*/
	if (w==NIL) goto composeCON2171;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[4];
	w = local[0];
	ctx->vsp=local+11;
	w=composeFLET2156(ctx,3,local+8,w);
	w = NIL;
	ctx->vsp=local+8;
	local[8]=w;
	goto composeBLK2169;
	goto composeCON2170;
composeCON2171:
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto composeCON2172;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+10;
	w=(*ftab[2])(ctx,2,local+8,&ftab[2],fqv[17]); /*eps=*/
	if (w==NIL) goto composeIF2173;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[4];
	w = local[0];
	ctx->vsp=local+11;
	w=composeFLET2156(ctx,3,local+8,w);
	w = NIL;
	ctx->vsp=local+8;
	local[8]=w;
	goto composeBLK2169;
	goto composeIF2174;
composeIF2173:
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[8];
	local[8]= w;
composeIF2174:
	goto composeCON2170;
composeCON2172:
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)GREATERP(ctx,2,local+8); /*>*/
	if (w==NIL) goto composeCON2175;
	local[8]= local[3];
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)RPLACD(ctx,2,local+8); /*rplacd*/
	local[8]= local[3];
	local[9]= local[1];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)NCONC(ctx,2,local+9); /*nconc*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)RPLACA(ctx,2,local+8); /*rplaca*/
	w = NIL;
	ctx->vsp=local+8;
	local[8]=w;
	goto composeBLK2169;
	goto composeCON2170;
composeCON2175:
	local[8]= NIL;
composeCON2170:
	goto composeWHL2167;
composeWHX2168:
	local[8]= NIL;
composeBLK2169:
	goto composeIF2166;
composeIF2165:
	local[8]= NIL;
composeIF2166:
	goto composeWHL2162;
composeWHX2163:
	local[8]= NIL;
composeBLK2164:
	w = argv[0];
	local[6]= w;
	goto composeIF2161;
composeIF2160:
	local[6]= NIL;
composeIF2161:
	goto composeWHL2157;
composeWHX2158:
	local[6]= NIL;
composeBLK2159:
	w = NIL;
	local[0]= w;
composeBLK2155:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer composeFLET2156(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr!=NIL) goto composeIF2176;
	local[0]= argv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	local[0]= w;
	goto composeIF2177;
composeIF2176:
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	local[2]= argv[2];
	local[3]= fqv[4];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VINNERPRODUCT(ctx,2,local+1); /*v.*/
	local[1]= makeflt((double)fabs(fltval(w)));
	local[2]= local[0];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= fqv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)VINNERPRODUCT(ctx,2,local+2); /*v.*/
	{ double left,right;
		right=fltval(makeflt((double)fabs(fltval(w)))); left=fltval(local[1]);
	if (left <= right) goto composeIF2178;}
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)RPLACA(ctx,2,local+1); /*rplaca*/
	local[1]= w;
	goto composeIF2179;
composeIF2178:
	local[1]= NIL;
composeIF2179:
	w = local[1];
	local[0]= w;
composeIF2177:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*make-edge-segments*/
static pointer composeF2111make_edge_segments(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= argv[0];
composeWHL2181:
	if (local[10]==NIL) goto composeWHX2182;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[11];
	local[6] = w;
composeWHL2184:
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto composeWHX2185;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[11];
	local[3] = w;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.car;
	local[11]= makeflt(5.0000000000000000000000e-01);
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(*ftab[3])(ctx,4,local+11,&ftab[3],fqv[19]); /*midpoint*/
	local[11]= argv[1];
	local[12]= fqv[20];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[5] = w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.car;
	local[11]= local[5];
	if (argv[2]==local[11]) goto composeOR2189;
	local[11]= local[5];
	if (fqv[21]==local[11]) goto composeOR2189;
	goto composeIF2187;
composeOR2189:
	local[11]= loadglobal(fqv[8]);
	ctx->vsp=local+12;
	w=(pointer)INSTANTIATE(ctx,1,local+11); /*instantiate*/
	local[11]= w;
	local[12]= local[11];
	local[13]= fqv[9];
	local[14]= fqv[10];
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	local[16]= fqv[11];
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	local[18]= fqv[12];
	local[19]= local[6]->c.obj.iv[3];
	local[20]= fqv[13];
	local[21]= local[6]->c.obj.iv[4];
	local[22]= fqv[22];
	local[23]= local[6]->c.obj.iv[6];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,12,local+12); /*send*/
	w = local[11];
	local[1] = w;
	local[11]= local[6];
	local[12]= local[1];
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	local[15]= local[5];
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,7,local+11); /*list*/
	local[11]= w;
	w = local[0];
	ctx->vsp=local+12;
	local[0] = cons(ctx,local[11],w);
	local[11]= local[0];
	goto composeIF2188;
composeIF2187:
	local[11]= NIL;
composeIF2188:
	goto composeWHL2184;
composeWHX2185:
	local[11]= NIL;
composeBLK2186:
	goto composeWHL2181;
composeWHX2182:
	local[11]= NIL;
composeBLK2183:
	w = NIL;
	w = local[0];
	local[0]= w;
composeBLK2180:
	ctx->vsp=local; return(local[0]);}

/*intersecting-segments*/
static pointer composeF2112intersecting_segments(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,composeCLO2191,env,argv,local);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
composeBLK2190:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer composeCLO2191(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car!=NIL) goto composeOR2194;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[4])(ctx,1,local+0,&ftab[4],fqv[23]); /*fourth*/
	if (w!=NIL) goto composeOR2194;
	goto composeIF2192;
composeOR2194:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[5])(ctx,1,local+0,&ftab[5],fqv[24]); /*fifth*/
	local[0]= w;
	if (fqv[21]==local[0]) goto composeIF2192;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto composeIF2193;
composeIF2192:
	local[0]= NIL;
composeIF2193:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*sort-edges-by-face*/
static pointer composeF2113sort_edges_by_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[0];
composeWHL2196:
	if (local[5]==NIL) goto composeWHX2197;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
	local[6]= local[3]->c.obj.iv[3];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)ASSQ(ctx,2,local+6); /*assq*/
	local[1] = w;
	if (local[1]!=NIL) goto composeIF2199;
	local[6]= local[3]->c.obj.iv[3];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	w = local[0];
	ctx->vsp=local+7;
	local[0] = cons(ctx,local[6],w);
	local[6]= local[0];
	goto composeIF2200;
composeIF2199:
	local[6]= local[1];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)NCONC(ctx,2,local+6); /*nconc*/
	local[6]= w;
composeIF2200:
	local[6]= local[3]->c.obj.iv[4];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)ASSQ(ctx,2,local+6); /*assq*/
	local[1] = w;
	if (local[1]!=NIL) goto composeIF2201;
	local[6]= local[3]->c.obj.iv[4];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	w = local[0];
	ctx->vsp=local+7;
	local[0] = cons(ctx,local[6],w);
	local[6]= local[0];
	goto composeIF2202;
composeIF2201:
	local[6]= local[1];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)NCONC(ctx,2,local+6); /*nconc*/
	local[6]= w;
composeIF2202:
	goto composeWHL2196;
composeWHX2197:
	local[6]= NIL;
composeBLK2198:
	w = NIL;
	w = local[0];
	local[0]= w;
composeBLK2195:
	ctx->vsp=local; return(local[0]);}

/*make-crossing-edges*/
static pointer composeF2114make_crossing_edges(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= NIL;
	local[15]= NIL;
	local[16]= NIL;
	local[17]= NIL;
	local[18]= argv[0];
composeWHL2204:
	if (local[18]==NIL) goto composeWHX2205;
	w=local[18];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	w=local[18];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18] = (w)->c.cons.cdr;
	w = local[19];
	local[17] = w;
	w = local[17];
	if (iscons(w)) goto composeIF2207;
	local[19]= fqv[25];
	local[20]= local[17];
	ctx->vsp=local+21;
	w=(pointer)SIGERROR(ctx,2,local+19); /*error*/
	local[19]= w;
	goto composeIF2208;
composeIF2207:
	local[19]= NIL;
composeIF2208:
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.car;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	local[19]= local[0];
	local[20]= fqv[4];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,2,local+19); /*send*/
	local[13] = w;
	local[1] = NIL;
	local[19]= NIL;
	local[20]= local[2];
composeWHL2209:
	if (local[20]==NIL) goto composeWHX2210;
	w=local[20];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	w=local[20];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20] = (w)->c.cons.cdr;
	w = local[21];
	local[19] = w;
	w = local[19];
	if (iscons(w)) goto composeIF2212;
	local[21]= fqv[26];
	local[22]= local[19];
	ctx->vsp=local+23;
	w=(pointer)SIGERROR(ctx,2,local+21); /*error*/
	local[21]= w;
	goto composeIF2213;
composeIF2212:
	local[21]= NIL;
composeIF2213:
	w=local[19];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto composeIF2214;
	w=local[19];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	local[22]= local[1];
	ctx->vsp=local+23;
	w=(*ftab[6])(ctx,2,local+21,&ftab[6],fqv[27]); /*member*/
	if (w!=NIL) goto composeIF2214;
	w=local[19];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	w = local[1];
	ctx->vsp=local+22;
	local[1] = cons(ctx,local[21],w);
	local[21]= local[1];
	goto composeIF2215;
composeIF2214:
	local[21]= NIL;
composeIF2215:
	local[21]= local[19];
	ctx->vsp=local+22;
	w=(*ftab[4])(ctx,1,local+21,&ftab[4],fqv[23]); /*fourth*/
	if (w==NIL) goto composeIF2216;
	local[21]= local[19];
	ctx->vsp=local+22;
	w=(*ftab[4])(ctx,1,local+21,&ftab[4],fqv[23]); /*fourth*/
	local[21]= w;
	local[22]= local[1];
	ctx->vsp=local+23;
	w=(*ftab[6])(ctx,2,local+21,&ftab[6],fqv[27]); /*member*/
	if (w!=NIL) goto composeIF2216;
	local[21]= local[19];
	ctx->vsp=local+22;
	w=(*ftab[4])(ctx,1,local+21,&ftab[4],fqv[23]); /*fourth*/
	local[21]= w;
	w = local[1];
	ctx->vsp=local+22;
	local[1] = cons(ctx,local[21],w);
	local[21]= local[1];
	goto composeIF2217;
composeIF2216:
	local[21]= NIL;
composeIF2217:
	goto composeWHL2209;
composeWHX2210:
	local[21]= NIL;
composeBLK2211:
	w = NIL;
	local[19]= NIL;
	local[20]= local[1];
composeWHL2218:
	if (local[20]==NIL) goto composeWHX2219;
	w=local[20];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	w=local[20];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20] = (w)->c.cons.cdr;
	w = local[21];
	local[19] = w;
	local[9] = NIL;
	local[10] = NIL;
	local[21]= NIL;
	local[22]= local[2];
composeWHL2221:
	if (local[22]==NIL) goto composeWHX2222;
	w=local[22];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	w=local[22];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22] = (w)->c.cons.cdr;
	w = local[23];
	local[21] = w;
	w=local[21];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.car;
	w=local[21];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	if (local[19]!=local[23]) goto composeCON2225;
	local[23]= local[21];
	ctx->vsp=local+24;
	w=(*ftab[7])(ctx,1,local+23,&ftab[7],fqv[28]); /*sixth*/
	local[23]= w;
	local[24]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+25;
	w=(*ftab[8])(ctx,2,local+23,&ftab[8],fqv[29]); /*eps<>*/
	if (w==NIL) goto composeCON2225;
	local[23]= local[4]->c.obj.iv[1];
	w = local[9];
	ctx->vsp=local+24;
	local[9] = cons(ctx,local[23],w);
	local[23]= local[9];
	goto composeCON2224;
composeCON2225:
	local[23]= local[21];
	ctx->vsp=local+24;
	w=(*ftab[4])(ctx,1,local+23,&ftab[4],fqv[23]); /*fourth*/
	local[23]= w;
	if (local[19]!=local[23]) goto composeCON2226;
	local[23]= local[21];
	ctx->vsp=local+24;
	w=(*ftab[9])(ctx,1,local+23,&ftab[9],fqv[30]); /*seventh*/
	local[23]= w;
	local[24]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+25;
	w=(*ftab[8])(ctx,2,local+23,&ftab[8],fqv[29]); /*eps<>*/
	if (w==NIL) goto composeCON2226;
	local[23]= local[4]->c.obj.iv[2];
	w = local[9];
	ctx->vsp=local+24;
	local[9] = cons(ctx,local[23],w);
	local[23]= local[9];
	goto composeCON2224;
composeCON2226:
	local[23]= NIL;
composeCON2224:
	goto composeWHL2221;
composeWHX2222:
	local[23]= NIL;
composeBLK2223:
	w = NIL;
	local[21]= NIL;
	local[22]= local[19];
	local[23]= argv[1];
	ctx->vsp=local+24;
	w=(pointer)ASSQ(ctx,2,local+22); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.cdr;
composeWHL2227:
	if (local[22]==NIL) goto composeWHX2228;
	w=local[22];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	w=local[22];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22] = (w)->c.cons.cdr;
	w = local[23];
	local[21] = w;
	w=local[21];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.car;
	w=local[21];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	if (local[0]!=local[23]) goto composeCON2231;
	local[23]= local[21];
	ctx->vsp=local+24;
	w=(*ftab[7])(ctx,1,local+23,&ftab[7],fqv[28]); /*sixth*/
	local[23]= w;
	local[24]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+25;
	w=(*ftab[8])(ctx,2,local+23,&ftab[8],fqv[29]); /*eps<>*/
	if (w==NIL) goto composeCON2231;
	local[23]= local[4]->c.obj.iv[1];
	w = local[10];
	ctx->vsp=local+24;
	local[10] = cons(ctx,local[23],w);
	local[23]= local[10];
	goto composeCON2230;
composeCON2231:
	local[23]= local[21];
	ctx->vsp=local+24;
	w=(*ftab[4])(ctx,1,local+23,&ftab[4],fqv[23]); /*fourth*/
	local[23]= w;
	if (local[0]!=local[23]) goto composeCON2232;
	local[23]= local[21];
	ctx->vsp=local+24;
	w=(*ftab[9])(ctx,1,local+23,&ftab[9],fqv[30]); /*seventh*/
	local[23]= w;
	local[24]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+25;
	w=(*ftab[8])(ctx,2,local+23,&ftab[8],fqv[29]); /*eps<>*/
	if (w==NIL) goto composeCON2232;
	local[23]= local[4]->c.obj.iv[2];
	w = local[10];
	ctx->vsp=local+24;
	local[10] = cons(ctx,local[23],w);
	local[23]= local[10];
	goto composeCON2230;
composeCON2232:
	local[23]= NIL;
composeCON2230:
	goto composeWHL2227;
composeWHX2228:
	local[23]= NIL;
composeBLK2229:
	w = NIL;
	local[21]= *(ovafptr(local[19],fqv[31]));
	local[22]= *(ovafptr(local[0],fqv[31]));
	ctx->vsp=local+23;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+21); /*v**/
	local[5] = w;
	local[21]= local[5];
	ctx->vsp=local+22;
	w=(*ftab[1])(ctx,1,local+21,&ftab[1],fqv[5]); /*maxindex*/
	local[6] = w;
	local[21]= argv[3];
	if (fqv[32]!=local[21]) goto composeIF2233;
	local[21]= local[5];
	local[22]= local[6];
	ctx->vsp=local+23;
	w=(pointer)AREF(ctx,2,local+21); /*aref*/
	local[21]= w;
	local[22]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+23;
	w=(pointer)LESSP(ctx,2,local+21); /*<*/
	if (w==NIL) goto composeIF2235;
	local[21]= (pointer)get_sym_func(fqv[33]);
	goto composeIF2236;
composeIF2235:
	local[21]= (pointer)get_sym_func(fqv[34]);
composeIF2236:
	goto composeIF2234;
composeIF2233:
	local[21]= local[5];
	local[22]= local[6];
	ctx->vsp=local+23;
	w=(pointer)AREF(ctx,2,local+21); /*aref*/
	local[21]= w;
	local[22]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+23;
	w=(pointer)LESSP(ctx,2,local+21); /*<*/
	if (w==NIL) goto composeIF2237;
	local[21]= (pointer)get_sym_func(fqv[34]);
	goto composeIF2238;
composeIF2237:
	local[21]= (pointer)get_sym_func(fqv[33]);
composeIF2238:
composeIF2234:
	local[7] = local[21];
	local[21]= local[9];
	local[22]= local[10];
	ctx->vsp=local+23;
	w=(pointer)APPEND(ctx,2,local+21); /*append*/
	local[21]= w;
	local[22]= local[7];
	ctx->vsp=local+23;
	local[23]= makeclosure(codevec,quotevec,composeCLO2239,env,argv,local);
	ctx->vsp=local+24;
	w=(pointer)SORT(ctx,3,local+21); /*sort*/
	local[8] = w;
	local[21]= local[8];
	local[22]= fqv[35];
	local[23]= (pointer)get_sym_func(fqv[36]);
	ctx->vsp=local+24;
	w=(*ftab[10])(ctx,3,local+21,&ftab[10],fqv[37]); /*remove-duplicates*/
	local[8] = w;
	local[14] = NIL;
composeWHL2240:
	if (local[8]==NIL) goto composeWHX2241;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[21];
	local[11] = w;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[21];
	local[12] = w;
	if (local[11]==NIL) goto composeIF2243;
	if (local[12]==NIL) goto composeIF2243;
	local[21]= local[0];
	local[22]= fqv[38];
	local[23]= makeflt(5.0000000000000000000000e-01);
	local[24]= local[11];
	local[25]= local[12];
	ctx->vsp=local+26;
	w=(*ftab[3])(ctx,3,local+23,&ftab[3],fqv[19]); /*midpoint*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,3,local+21); /*send*/
	if (w!=NIL) goto composeIF2243;
	local[21]= local[19];
	local[22]= fqv[38];
	local[23]= makeflt(5.0000000000000000000000e-01);
	local[24]= local[11];
	local[25]= local[12];
	ctx->vsp=local+26;
	w=(*ftab[3])(ctx,3,local+23,&ftab[3],fqv[19]); /*midpoint*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,3,local+21); /*send*/
	if (w!=NIL) goto composeIF2243;
	if (argv[2]!=NIL) goto composeOR2245;
	local[21]= local[11];
	w = local[9];
	if (memq(local[21],w)==NIL) goto composeAND2246;
	local[21]= local[12];
	w = local[9];
	if (memq(local[21],w)==NIL) goto composeAND2246;
	goto composeOR2245;
composeAND2246:
	goto composeIF2243;
composeOR2245:
	local[21]= loadglobal(fqv[8]);
	ctx->vsp=local+22;
	w=(pointer)INSTANTIATE(ctx,1,local+21); /*instantiate*/
	local[21]= w;
	local[22]= local[21];
	local[23]= fqv[9];
	local[24]= fqv[10];
	local[25]= local[11];
	local[26]= fqv[11];
	local[27]= local[12];
	local[28]= fqv[12];
	local[29]= local[0];
	local[30]= fqv[13];
	local[31]= local[19];
	local[32]= fqv[39];
	local[33]= NIL;
	ctx->vsp=local+34;
	w=(pointer)SEND(ctx,12,local+22); /*send*/
	w = local[21];
	local[4] = w;
	local[21]= local[4];
	w = local[14];
	ctx->vsp=local+22;
	local[14] = cons(ctx,local[21],w);
	local[21]= local[14];
	goto composeIF2244;
composeIF2243:
	local[21]= NIL;
composeIF2244:
	goto composeWHL2240;
composeWHX2241:
	local[21]= NIL;
composeBLK2242:
	if (local[14]==NIL) goto composeIF2247;
	local[21]= local[0];
	w = local[14];
	ctx->vsp=local+22;
	local[21]= cons(ctx,local[21],w);
	w = local[15];
	ctx->vsp=local+22;
	local[15] = cons(ctx,local[21],w);
	local[21]= local[19];
	local[22]= local[14];
	ctx->vsp=local+23;
	w=(pointer)COPYSEQ(ctx,1,local+22); /*copy-seq*/
	ctx->vsp=local+22;
	local[21]= cons(ctx,local[21],w);
	w = local[16];
	ctx->vsp=local+22;
	local[16] = cons(ctx,local[21],w);
	local[21]= local[16];
	goto composeIF2248;
composeIF2247:
	local[21]= NIL;
composeIF2248:
	goto composeWHL2218;
composeWHX2219:
	local[21]= NIL;
composeBLK2220:
	w = NIL;
	goto composeWHL2204;
composeWHX2205:
	local[19]= NIL;
composeBLK2206:
	w = NIL;
	local[17]= local[15];
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,2,local+17); /*list*/
	local[0]= w;
composeBLK2203:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer composeCLO2239(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[6];
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*add-alist*/
static pointer composeF2115add_alist(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)ASSQ(ctx,2,local+0); /*assq*/
	local[0]= w;
	if (local[0]!=NIL) goto composeIF2250;
	local[1]= argv[0];
	local[2]= argv[1];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(*ftab[11])(ctx,3,local+1,&ftab[11],fqv[40]); /*acons*/
	local[1]= w;
	goto composeIF2251;
composeIF2250:
	local[1]= local[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)NCONC(ctx,2,local+1); /*nconc*/
	local[1]= argv[2];
composeIF2251:
	w = local[1];
	local[0]= w;
composeBLK2249:
	ctx->vsp=local; return(local[0]);}

/*merge-segments*/
static pointer composeF2116merge_segments(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= argv[0];
composeWHL2253:
	if (local[1]==NIL) goto composeWHX2254;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= (pointer)get_sym_func(fqv[41]);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)RPLACD(ctx,2,local+2); /*rplacd*/
	goto composeWHL2253;
composeWHX2254:
	local[2]= NIL;
composeBLK2255:
	w = NIL;
	local[0]= NIL;
	local[1]= argv[1];
composeWHL2256:
	if (local[1]==NIL) goto composeWHX2257;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)composeF2115add_alist(ctx,3,local+2); /*add-alist*/
	argv[0] = w;
	goto composeWHL2256;
composeWHX2257:
	local[2]= NIL;
composeBLK2258:
	w = NIL;
	local[0]= NIL;
	local[1]= argv[2];
composeWHL2259:
	if (local[1]==NIL) goto composeWHX2260;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)composeF2115add_alist(ctx,3,local+2); /*add-alist*/
	argv[0] = w;
	goto composeWHL2259;
composeWHX2260:
	local[2]= NIL;
composeBLK2261:
	w = NIL;
	w = argv[0];
	local[0]= w;
composeBLK2252:
	ctx->vsp=local; return(local[0]);}

/*find-connecting-edge*/
static pointer composeF2117find_connecting_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto composeENT2264;}
	local[0]= (pointer)get_sym_func(fqv[42]);
composeENT2264:
composeENT2263:
	if (n>3) maerror();
	local[1]= local[0];
	if ((pointer)get_sym_func(fqv[42])!=local[1]) goto composeIF2265;
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,composeCLO2267,env,argv,local);
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,2,local+1,&ftab[12],fqv[43]); /*find-if*/
	local[1]= w;
	goto composeIF2266;
composeIF2265:
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,composeCLO2268,env,argv,local);
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,2,local+1,&ftab[12],fqv[43]); /*find-if*/
	local[1]= w;
composeIF2266:
	w = local[1];
	local[0]= w;
composeBLK2262:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer composeCLO2267(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[0]= ((env->c.clo.env1[0])==(local[0])?T:NIL);
	if (local[0]!=NIL) goto composeOR2269;
	local[0]= argv[0]->c.obj.iv[2];
	local[0]= ((env->c.clo.env1[0])==(local[0])?T:NIL);
composeOR2269:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer composeCLO2268(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[0];
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= env->c.clo.env1[0];
	ctx->vsp=local+3;
	w=(pointer)FUNCALL(ctx,3,local+0); /*funcall*/
	local[0]= w;
	if (w!=NIL) goto composeOR2270;
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= env->c.clo.env1[0];
	ctx->vsp=local+2;
	w=(pointer)FUNCALL(ctx,2,local+0); /*funcall*/
	local[0]= w;
composeOR2270:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*construct-faces*/
static pointer composeF2118construct_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)COPYSEQ(ctx,1,local+0); /*copy-seq*/
	local[0]= w;
	storeglobal(fqv[44],w);
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
composeWHL2272:
	if (local[4]==NIL) goto composeWHX2273;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[5]= w;
	local[6]= local[5];
	local[7]= fqv[10];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	local[7]= local[6];
	local[8]= NIL;
	local[9]= NIL;
	local[10]= loadglobal(fqv[45]);
	ctx->vsp=local+11;
	w=(pointer)INSTANTIATE(ctx,1,local+10); /*instantiate*/
	local[10]= w;
	local[11]= NIL;
composeWHL2275:
	if (local[5]==NIL) goto composeWHX2276;
	local[12]= local[5];
	local[13]= fqv[11];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[8] = w;
	local[12]= local[5];
	local[13]= fqv[46];
	local[14]= local[7];
	local[15]= local[8];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,5,local+12); /*send*/
	local[12]= local[5];
	w = local[9];
	ctx->vsp=local+13;
	local[9] = cons(ctx,local[12],w);
	local[12]= local[5];
	local[13]= local[4];
	local[14]= fqv[47];
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(*ftab[13])(ctx,4,local+12,&ftab[13],fqv[48]); /*delete*/
	local[4] = w;
	local[12]= local[8];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)composeF2117find_connecting_edge(ctx,2,local+12); /*find-connecting-edge*/
	local[5] = w;
	local[7] = local[8];
	goto composeWHL2275;
composeWHX2276:
	local[12]= NIL;
composeBLK2277:
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)NREVERSE(ctx,1,local+12); /*nreverse*/
	local[9] = w;
	local[12]= local[3];
	local[13]= fqv[49];
	ctx->vsp=local+14;
	w=(*ftab[14])(ctx,2,local+12,&ftab[14],fqv[50]); /*find-method*/
	if (w==NIL) goto composeIF2278;
	local[12]= local[3];
	local[13]= fqv[49];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[11] = w;
	local[12]= local[11];
	goto composeIF2279;
composeIF2278:
	local[12]= NIL;
composeIF2279:
	local[12]= local[10];
	local[13]= fqv[9];
	local[14]= fqv[1];
	local[15]= local[9];
	local[16]= fqv[49];
	local[17]= local[11];
	local[18]= fqv[51];
	if (local[11]==NIL) goto composeIF2280;
	local[19]= local[11];
	local[20]= fqv[51];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,2,local+19); /*send*/
	local[19]= w;
	goto composeIF2281;
composeIF2280:
	local[19]= NIL;
composeIF2281:
	local[20]= fqv[52];
	local[21]= local[3];
	local[22]= fqv[52];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,10,local+12); /*send*/
	local[12]= local[3];
	local[13]= fqv[4];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	local[13]= local[10];
	local[14]= fqv[4];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)VINNERPRODUCT(ctx,2,local+12); /*v.*/
	local[12]= w;
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[12]);
	if (left >= right) goto composeCON2283;}
	local[12]= local[10];
	w = local[9];
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	w = local[1];
	ctx->vsp=local+13;
	local[1] = cons(ctx,local[12],w);
	local[12]= local[1];
	goto composeCON2282;
composeCON2283:
	local[12]= local[10];
	w = local[0];
	ctx->vsp=local+13;
	local[0] = cons(ctx,local[12],w);
	local[12]= local[0];
	goto composeCON2282;
composeCON2284:
	local[12]= NIL;
composeCON2282:
	w = local[12];
	goto composeWHL2272;
composeWHX2273:
	local[5]= NIL;
composeBLK2274:
	if (local[1]==NIL) goto composeIF2285;
	if (loadglobal(fqv[53])==NIL) goto composeIF2287;
	local[5]= T;
	local[6]= fqv[54];
	local[7]= local[0];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[5]= w;
	goto composeIF2288;
composeIF2287:
	local[5]= NIL;
composeIF2288:
	local[5]= NIL;
	local[6]= local[1];
composeWHL2289:
	if (local[6]==NIL) goto composeWHX2290;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= NIL;
	local[8]= local[0];
composeWHL2293:
	if (local[8]==NIL) goto composeWHX2294;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= local[7];
	local[10]= fqv[20];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= *(ovafptr((w)->c.cons.car,fqv[55]));
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	if (fqv[56]!=local[9]) goto composeIF2296;
	local[9]= NIL;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.cdr;
composeWHL2298:
	if (local[10]==NIL) goto composeWHX2299;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	local[11]= local[9];
	local[12]= fqv[46];
	local[13]= local[9];
	local[14]= fqv[10];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	local[14]= local[9];
	local[15]= fqv[11];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= w;
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,5,local+11); /*send*/
	goto composeWHL2298;
composeWHX2299:
	local[11]= NIL;
composeBLK2300:
	w = NIL;
	local[9]= loadglobal(fqv[57]);
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= fqv[9];
	local[12]= fqv[1];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.cdr;
	local[14]= fqv[58];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,6,local+10); /*send*/
	w = local[9];
	local[2] = w;
	local[9]= local[7];
	local[10]= fqv[59];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	w = NIL;
	ctx->vsp=local+9;
	local[7]=w;
	goto composeBLK2292;
	goto composeIF2297;
composeIF2296:
	local[9]= NIL;
composeIF2297:
	goto composeWHL2293;
composeWHX2294:
	local[9]= NIL;
composeBLK2295:
	w = NIL;
	local[7]= local[0];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	storeglobal(fqv[60],w);
	local[7]= fqv[61];
	ctx->vsp=local+8;
	w=(pointer)SIGERROR(ctx,1,local+7); /*error*/
	local[7]= w;
composeBLK2292:
	goto composeWHL2289;
composeWHX2290:
	local[7]= NIL;
composeBLK2291:
	w = NIL;
	local[5]= w;
	goto composeIF2286;
composeIF2285:
	local[5]= NIL;
composeIF2286:
	w = local[0];
	local[0]= w;
composeBLK2271:
	ctx->vsp=local; return(local[0]);}

/*initial-intersection-list*/
static pointer composeF2119initial_intersection_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
composeWHL2302:
	if (local[3]==NIL) goto composeWHX2303;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	local[5]= makeflt(0.0000000000000000000000e+00);
	local[6]= local[2]->c.obj.iv[1];
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(*ftab[15])(ctx,2,local+6,&ftab[15],fqv[62]); /*gethash*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,2,local+5); /*list*/
	local[5]= w;
	local[6]= makeflt(1.0000000000000000000000e+00);
	local[7]= local[2]->c.obj.iv[2];
	local[8]= argv[1];
	ctx->vsp=local+9;
	w=(*ftab[15])(ctx,2,local+7,&ftab[15],fqv[62]); /*gethash*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,3,local+4); /*list*/
	local[4]= w;
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	goto composeWHL2302;
composeWHX2303:
	local[4]= NIL;
composeBLK2304:
	w = local[1];
	local[0]= w;
composeBLK2301:
	ctx->vsp=local; return(local[0]);}

/*make-vertex-edge-htab*/
static pointer composeF2120make_vertex_edge_htab(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[16])(ctx,1,local+5,&ftab[16],fqv[63]); /*bodyp*/
	if (w==NIL) goto composeCON2307;
	local[1] = argv[0]->c.obj.iv[11];
	local[0] = argv[0]->c.obj.iv[10];
	local[5]= local[0];
	goto composeCON2306;
composeCON2307:
	local[5]= (pointer)get_sym_func(fqv[64]);
	local[6]= argv[0];
	local[7]= fqv[65];
	ctx->vsp=local+8;
	w=(*ftab[17])(ctx,2,local+6,&ftab[17],fqv[66]); /*send-all*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,2,local+5); /*apply*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[10])(ctx,1,local+5,&ftab[10],fqv[37]); /*remove-duplicates*/
	local[1] = w;
	local[5]= (pointer)get_sym_func(fqv[64]);
	local[6]= argv[0];
	local[7]= fqv[67];
	ctx->vsp=local+8;
	w=(*ftab[17])(ctx,2,local+6,&ftab[17],fqv[66]); /*send-all*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,2,local+5); /*apply*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[10])(ctx,1,local+5,&ftab[10],fqv[37]); /*remove-duplicates*/
	local[0] = w;
	local[5]= local[0];
	goto composeCON2306;
composeCON2308:
	local[5]= NIL;
composeCON2306:
	local[5]= fqv[68];
	local[6]= makeint((eusinteger_t)2L);
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	{ eusinteger_t i,j;
		j=intval(w); i=intval(local[6]);
		local[6]=(makeint(i * j));}
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[18])(ctx,2,local+5,&ftab[18],fqv[69]); /*make-hash-table*/
	local[2] = w;
	local[5]= NIL;
	local[6]= local[0];
composeWHL2309:
	if (local[6]==NIL) goto composeWHX2310;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[3] = local[5]->c.obj.iv[1];
	local[4] = local[5]->c.obj.iv[2];
	local[7]= local[3];
	local[8]= local[2];
	local[9]= local[5];
	local[10]= local[3];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(*ftab[15])(ctx,2,local+10,&ftab[15],fqv[62]); /*gethash*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(*ftab[19])(ctx,3,local+7,&ftab[19],fqv[70]); /*sethash*/
	local[7]= local[4];
	local[8]= local[2];
	local[9]= local[5];
	local[10]= local[4];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(*ftab[15])(ctx,2,local+10,&ftab[15],fqv[62]); /*gethash*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(*ftab[19])(ctx,3,local+7,&ftab[19],fqv[70]); /*sethash*/
	goto composeWHL2309;
composeWHX2310:
	local[7]= NIL;
composeBLK2311:
	w = NIL;
	w = local[2];
	local[0]= w;
composeBLK2305:
	ctx->vsp=local; return(local[0]);}

/*copy-add-vertex*/
static pointer composeF2121copy_add_vertex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,composeCLO2313,env,argv,local);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,2,local+0,&ftab[20],fqv[71]); /*maphash*/
	local[0]= w;
composeBLK2312:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer composeCLO2313(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env1[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)COPYSEQ(ctx,1,local+2); /*copy-seq*/
	local[2]= w;
	w = argv[1];
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,3,local+0,&ftab[19],fqv[70]); /*sethash*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*find-colinear-int*/
static pointer composeF2122find_colinear_int(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
composeWHL2315:
	if (local[2]==NIL) goto composeWHX2316;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= NIL;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
composeWHL2318:
	if (local[4]==NIL) goto composeWHX2319;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[72];
	ctx->vsp=local+7;
	w=(pointer)EQ(ctx,2,local+5); /*eql*/
	if (w==NIL) goto composeIF2321;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)LIST_STAR(ctx,2,local+5); /*list**/
	local[5]= w;
	w = local[0];
	ctx->vsp=local+6;
	local[0] = cons(ctx,local[5],w);
	local[5]= local[0];
	goto composeIF2322;
composeIF2321:
	local[5]= NIL;
composeIF2322:
	goto composeWHL2318;
composeWHX2319:
	local[5]= NIL;
composeBLK2320:
	w = NIL;
	goto composeWHL2315;
composeWHX2316:
	local[3]= NIL;
composeBLK2317:
	w = NIL;
	w = local[0];
	local[0]= w;
composeBLK2314:
	ctx->vsp=local; return(local[0]);}

/*contacting-faces*/
static pointer composeF2123contacting_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= argv[0];
	local[9]= loadglobal(fqv[73]);
	ctx->vsp=local+10;
	w=(pointer)DERIVEDP(ctx,2,local+8); /*derivedp*/
	if (w==NIL) goto composeIF2324;
	local[0] = argv[0]->c.obj.iv[9];
	local[8]= local[0];
	goto composeIF2325;
composeIF2324:
	local[8]= NIL;
composeIF2325:
	local[8]= argv[1];
	local[9]= loadglobal(fqv[73]);
	ctx->vsp=local+10;
	w=(pointer)DERIVEDP(ctx,2,local+8); /*derivedp*/
	if (w==NIL) goto composeIF2326;
	local[1] = argv[1]->c.obj.iv[9];
	local[8]= local[1];
	goto composeIF2327;
composeIF2326:
	local[8]= NIL;
composeIF2327:
	local[8]= NIL;
	local[9]= local[0];
composeWHL2328:
	if (local[9]==NIL) goto composeWHX2329;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= NIL;
	local[11]= local[1];
composeWHL2331:
	if (local[11]==NIL) goto composeWHX2332;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= local[8];
	local[13]= fqv[74];
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[2] = w;
	if (local[2]==NIL) goto composeIF2334;
	local[12]= (pointer)get_sym_func(fqv[75]);
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)MAPCAR(ctx,2,local+12); /*mapcar*/
	local[6] = w;
	local[12]= (pointer)get_sym_func(fqv[75]);
	local[13]= (pointer)get_sym_func(fqv[64]);
	local[14]= (pointer)get_sym_func(fqv[76]);
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)MAPCAR(ctx,2,local+14); /*mapcar*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)APPLY(ctx,2,local+13); /*apply*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)MAPCAR(ctx,2,local+12); /*mapcar*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[10])(ctx,1,local+12,&ftab[10],fqv[37]); /*remove-duplicates*/
	local[7] = w;
	local[12]= local[2];
	w = fqv[77];
	if (memq(local[12],w)==NIL) goto composeCON2337;
	local[12]= local[8];
	local[13]= local[10];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,3,local+12); /*list*/
	local[12]= w;
	w = local[5];
	ctx->vsp=local+13;
	local[5] = cons(ctx,local[12],w);
	local[12]= local[5];
	goto composeCON2336;
composeCON2337:
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	if (makeint((eusinteger_t)1L)==local[12]) goto composeOR2339;
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	if (makeint((eusinteger_t)1L)==local[12]) goto composeOR2339;
	goto composeCON2338;
composeOR2339:
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)composeF2122find_colinear_int(ctx,1,local+12); /*find-colinear-int*/
	local[4] = w;
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	if (makeint((eusinteger_t)1L)!=local[12]) goto composeIF2340;
	local[12]= T;
	local[13]= fqv[78];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,2,local+12); /*format*/
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.car;
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(*ftab[4])(ctx,1,local+12,&ftab[4],fqv[23]); /*fourth*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,2,local+12,&ftab[2],fqv[17]); /*eps=*/
	if (w==NIL) goto composeCON2343;
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(*ftab[4])(ctx,1,local+12,&ftab[4],fqv[23]); /*fourth*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,2,local+12,&ftab[2],fqv[17]); /*eps=*/
	if (w==NIL) goto composeCON2343;
	local[12]= local[10];
	local[13]= fqv[20];
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	local[15]= fqv[79];
	local[16]= local[8];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	local[13]= fqv[56];
	ctx->vsp=local+14;
	w=(pointer)EQ(ctx,2,local+12); /*eql*/
	if (w==NIL) goto composeCON2343;
	local[12]= local[8];
	local[13]= local[10];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)LIST_STAR(ctx,3,local+12); /*list**/
	local[12]= w;
	w = local[5];
	ctx->vsp=local+13;
	local[5] = cons(ctx,local[12],w);
	local[12]= local[5];
	goto composeCON2342;
composeCON2343:
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,1,local+12,&ftab[5],fqv[24]); /*fifth*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,2,local+12,&ftab[2],fqv[17]); /*eps=*/
	if (w==NIL) goto composeCON2344;
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,1,local+12,&ftab[5],fqv[24]); /*fifth*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,2,local+12,&ftab[2],fqv[17]); /*eps=*/
	if (w==NIL) goto composeCON2344;
	local[12]= local[8];
	local[13]= fqv[20];
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	local[15]= fqv[79];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	local[13]= fqv[56];
	ctx->vsp=local+14;
	w=(pointer)EQ(ctx,2,local+12); /*eql*/
	if (w==NIL) goto composeCON2344;
	local[12]= local[8];
	local[13]= local[10];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)LIST_STAR(ctx,3,local+12); /*list**/
	local[12]= w;
	w = local[5];
	ctx->vsp=local+13;
	local[5] = cons(ctx,local[12],w);
	local[12]= local[5];
	goto composeCON2342;
composeCON2344:
	local[12]= NIL;
composeCON2342:
	goto composeIF2341;
composeIF2340:
	local[12]= local[8];
	local[13]= local[10];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)LIST_STAR(ctx,3,local+12); /*list**/
	local[12]= w;
	w = local[5];
	ctx->vsp=local+13;
	local[5] = cons(ctx,local[12],w);
	local[12]= local[5];
composeIF2341:
	goto composeCON2336;
composeCON2338:
	local[12]= local[8];
	local[13]= local[10];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)LIST_STAR(ctx,3,local+12); /*list**/
	local[12]= w;
	w = local[5];
	ctx->vsp=local+13;
	local[5] = cons(ctx,local[12],w);
	local[12]= local[5];
	goto composeCON2336;
composeCON2345:
	local[12]= NIL;
composeCON2336:
	goto composeIF2335;
composeIF2334:
	local[12]= NIL;
composeIF2335:
	goto composeWHL2331;
composeWHX2332:
	local[12]= NIL;
composeBLK2333:
	w = NIL;
	goto composeWHL2328;
composeWHX2329:
	local[10]= NIL;
composeBLK2330:
	w = NIL;
	w = local[5];
	local[0]= w;
composeBLK2323:
	ctx->vsp=local; return(local[0]);}

/*aligned-faces*/
static pointer composeF2124aligned_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= argv[0];
	local[8]= loadglobal(fqv[73]);
	ctx->vsp=local+9;
	w=(pointer)DERIVEDP(ctx,2,local+7); /*derivedp*/
	if (w==NIL) goto composeIF2347;
	local[0] = argv[0]->c.obj.iv[9];
	local[7]= local[0];
	goto composeIF2348;
composeIF2347:
	local[7]= NIL;
composeIF2348:
	local[7]= argv[1];
	local[8]= loadglobal(fqv[73]);
	ctx->vsp=local+9;
	w=(pointer)DERIVEDP(ctx,2,local+7); /*derivedp*/
	if (w==NIL) goto composeIF2349;
	local[1] = argv[1]->c.obj.iv[9];
	local[7]= local[1];
	goto composeIF2350;
composeIF2349:
	local[7]= NIL;
composeIF2350:
	local[7]= NIL;
	local[8]= local[0];
composeWHL2351:
	if (local[8]==NIL) goto composeWHX2352;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= NIL;
	local[10]= local[1];
composeWHL2354:
	if (local[10]==NIL) goto composeWHX2355;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	local[11]= local[7];
	local[12]= fqv[80];
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[2] = w;
	if (local[2]==NIL) goto composeIF2357;
	local[11]= local[7];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,2,local+11); /*list*/
	local[11]= w;
	w = local[4];
	ctx->vsp=local+12;
	local[4] = cons(ctx,local[11],w);
	local[11]= local[4];
	goto composeIF2358;
composeIF2357:
	local[11]= NIL;
composeIF2358:
	goto composeWHL2354;
composeWHX2355:
	local[11]= NIL;
composeBLK2356:
	w = NIL;
	goto composeWHL2351;
composeWHX2352:
	local[9]= NIL;
composeBLK2353:
	w = NIL;
	w = local[4];
	local[0]= w;
composeBLK2346:
	ctx->vsp=local; return(local[0]);}

/*find-equivalent-edge*/
static pointer composeF2125find_equivalent_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[1];
composeWHL2360:
	if (local[1]==NIL) goto composeWHX2361;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= local[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(*ftab[21])(ctx,2,local+2,&ftab[21],fqv[36]); /*eps-v=*/
	if (w==NIL) goto composeAND2366;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(*ftab[21])(ctx,2,local+2,&ftab[21],fqv[36]); /*eps-v=*/
	if (w==NIL) goto composeAND2366;
	goto composeOR2365;
composeAND2366:
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= local[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(*ftab[21])(ctx,2,local+2,&ftab[21],fqv[36]); /*eps-v=*/
	if (w==NIL) goto composeAND2367;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(*ftab[21])(ctx,2,local+2,&ftab[21],fqv[36]); /*eps-v=*/
	if (w==NIL) goto composeAND2367;
	goto composeOR2365;
composeAND2367:
	goto composeIF2363;
composeOR2365:
	w = local[0];
	ctx->vsp=local+2;
	local[0]=w;
	goto composeBLK2359;
	goto composeIF2364;
composeIF2363:
	local[2]= NIL;
composeIF2364:
	goto composeWHL2360;
composeWHX2361:
	local[2]= NIL;
composeBLK2362:
	w = NIL;
	local[0]= w;
composeBLK2359:
	ctx->vsp=local; return(local[0]);}

/*unify-vertex*/
static pointer composeF2126unify_vertex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= (pointer)get_sym_func(fqv[64]);
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,composeCLO2369,env,argv,local);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPLY(ctx,2,local+0); /*apply*/
	local[0]= w;
	local[1]= fqv[35];
	local[2]= (pointer)get_sym_func(fqv[36]);
	ctx->vsp=local+3;
	w=(*ftab[10])(ctx,3,local+0,&ftab[10],fqv[37]); /*remove-duplicates*/
	local[0]= w;
	local[1]= NIL;
	local[2]= argv[0];
composeWHL2370:
	if (local[2]==NIL) goto composeWHX2371;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1]->c.obj.iv[1];
	local[4]= local[0];
	local[5]= fqv[35];
	local[6]= (pointer)get_sym_func(fqv[36]);
	ctx->vsp=local+7;
	w=(*ftab[6])(ctx,4,local+3,&ftab[6],fqv[27]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= local[3];
	w = local[1];
	w->c.obj.iv[1] = local[4];
	local[3]= local[1]->c.obj.iv[2];
	local[4]= local[0];
	local[5]= fqv[35];
	local[6]= (pointer)get_sym_func(fqv[36]);
	ctx->vsp=local+7;
	w=(*ftab[6])(ctx,4,local+3,&ftab[6],fqv[27]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= local[3];
	w = local[1];
	w->c.obj.iv[2] = local[4];
	goto composeWHL2370;
composeWHX2371:
	local[3]= NIL;
composeBLK2372:
	w = NIL;
	local[0]= w;
composeBLK2368:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer composeCLO2369(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[81];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*merge-edges-if-colinear*/
static pointer composeF2127merge_edges_if_colinear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	if (argv[0]==NIL) goto composeIF2374;
	if (argv[1]==NIL) goto composeIF2374;
	local[0]= argv[0];
	local[1]= fqv[82];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	if (w==NIL) goto composeIF2374;
	local[0]= argv[1]->c.obj.iv[1];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[36]); /*eps-v=*/
	if (w==NIL) goto composeCON2377;
	local[0]= argv[1]->c.obj.iv[2];
	local[1]= local[0];
	w = argv[0];
	w->c.obj.iv[1] = local[1];
	goto composeCON2376;
composeCON2377:
	local[0]= argv[1]->c.obj.iv[1];
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[36]); /*eps-v=*/
	if (w==NIL) goto composeCON2378;
	local[0]= argv[1]->c.obj.iv[2];
	local[1]= local[0];
	w = argv[0];
	w->c.obj.iv[2] = local[1];
	goto composeCON2376;
composeCON2378:
	local[0]= argv[1]->c.obj.iv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[36]); /*eps-v=*/
	if (w==NIL) goto composeCON2379;
	local[0]= argv[1]->c.obj.iv[1];
	local[1]= local[0];
	w = argv[0];
	w->c.obj.iv[1] = local[1];
	goto composeCON2376;
composeCON2379:
	local[0]= argv[1]->c.obj.iv[2];
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[36]); /*eps-v=*/
	if (w==NIL) goto composeCON2380;
	local[0]= argv[1]->c.obj.iv[1];
	local[1]= local[0];
	w = argv[0];
	w->c.obj.iv[2] = local[1];
	goto composeCON2376;
composeCON2380:
	w = NIL;
	ctx->vsp=local+0;
	local[0]=w;
	goto composeBLK2373;
	goto composeCON2376;
composeCON2381:
	local[0]= NIL;
composeCON2376:
	local[0]= NIL;
	local[1]= argv[3];
composeWHL2382:
	if (local[1]==NIL) goto composeWHX2383;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= argv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[13])(ctx,2,local+2,&ftab[13],fqv[48]); /*delete*/
	goto composeWHL2382;
composeWHX2383:
	local[2]= NIL;
composeBLK2384:
	w = NIL;
	local[0]= argv[1];
	goto composeIF2375;
composeIF2374:
	local[0]= NIL;
composeIF2375:
	w = local[0];
	local[0]= w;
composeBLK2373:
	ctx->vsp=local; return(local[0]);}

/*merge-contacting-faces*/
static pointer composeF2128merge_contacting_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[83]); /*assoc*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(*ftab[22])(ctx,2,local+1,&ftab[22],fqv[83]); /*assoc*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.cdr;
composeWHL2386:
	if (local[9]==NIL) goto composeWHX2387;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[8];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.cdr;
	ctx->vsp=local+12;
	w=(pointer)composeF2125find_equivalent_edge(ctx,2,local+10); /*find-equivalent-edge*/
	local[2] = w;
	if (local[2]==NIL) goto composeCON2390;
	local[10]= local[2];
	local[11]= fqv[84];
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[3] = w;
	local[10]= local[8];
	local[11]= fqv[84];
	local[12]= argv[1];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[4] = w;
	local[10]= local[3];
	local[11]= fqv[4];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= local[4];
	local[12]= fqv[4];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[21])(ctx,2,local+10,&ftab[21],fqv[36]); /*eps-v=*/
	if (w==NIL) goto composeCON2392;
	local[10]= local[3];
	local[11]= argv[2];
	ctx->vsp=local+12;
	w=(*ftab[22])(ctx,2,local+10,&ftab[22],fqv[83]); /*assoc*/
	local[5] = w;
	local[10]= local[4];
	local[11]= argv[3];
	ctx->vsp=local+12;
	w=(*ftab[22])(ctx,2,local+10,&ftab[22],fqv[83]); /*assoc*/
	local[6] = w;
	local[10]= local[2];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(*ftab[13])(ctx,2,local+10,&ftab[13],fqv[48]); /*delete*/
	local[10]= local[8];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(*ftab[13])(ctx,2,local+10,&ftab[13],fqv[48]); /*delete*/
	local[10]= local[2];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(*ftab[13])(ctx,2,local+10,&ftab[13],fqv[48]); /*delete*/
	local[10]= local[8];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(*ftab[13])(ctx,2,local+10,&ftab[13],fqv[48]); /*delete*/
	local[10]= local[8]->c.obj.iv[1];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.cdr;
	ctx->vsp=local+12;
	w=(pointer)composeF2117find_connecting_edge(ctx,2,local+10); /*find-connecting-edge*/
	local[10]= w;
	local[11]= local[8]->c.obj.iv[2];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.cdr;
	ctx->vsp=local+13;
	w=(pointer)composeF2117find_connecting_edge(ctx,2,local+11); /*find-connecting-edge*/
	local[11]= w;
	local[12]= local[2]->c.obj.iv[1];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.cdr;
	ctx->vsp=local+14;
	w=(pointer)composeF2117find_connecting_edge(ctx,2,local+12); /*find-connecting-edge*/
	local[12]= w;
	local[13]= local[2]->c.obj.iv[2];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.cdr;
	ctx->vsp=local+15;
	w=(pointer)composeF2117find_connecting_edge(ctx,2,local+13); /*find-connecting-edge*/
	local[13]= w;
	local[14]= local[12];
	local[15]= local[10];
	local[16]= argv[2];
	local[17]= argv[3];
	ctx->vsp=local+18;
	w=(pointer)composeF2127merge_edges_if_colinear(ctx,4,local+14); /*merge-edges-if-colinear*/
	local[14]= local[12];
	local[15]= local[11];
	local[16]= argv[2];
	local[17]= argv[3];
	ctx->vsp=local+18;
	w=(pointer)composeF2127merge_edges_if_colinear(ctx,4,local+14); /*merge-edges-if-colinear*/
	local[14]= local[13];
	local[15]= local[10];
	local[16]= argv[2];
	local[17]= argv[3];
	ctx->vsp=local+18;
	w=(pointer)composeF2127merge_edges_if_colinear(ctx,4,local+14); /*merge-edges-if-colinear*/
	local[14]= local[13];
	local[15]= local[11];
	local[16]= argv[2];
	local[17]= argv[3];
	ctx->vsp=local+18;
	w=(pointer)composeF2127merge_edges_if_colinear(ctx,4,local+14); /*merge-edges-if-colinear*/
	local[10]= NIL;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.cdr;
composeWHL2393:
	if (local[11]==NIL) goto composeWHX2394;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= local[10]->c.obj.iv[3];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)EQ(ctx,2,local+12); /*eql*/
	if (w!=NIL) goto composeOR2398;
	local[12]= local[10]->c.obj.iv[4];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)EQ(ctx,2,local+12); /*eql*/
	if (w!=NIL) goto composeOR2398;
	goto composeIF2396;
composeOR2398:
	local[12]= local[10];
	local[13]= fqv[85];
	local[14]= local[4];
	local[15]= local[3];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,4,local+12); /*send*/
	local[12]= w;
	goto composeIF2397;
composeIF2396:
	local[12]= NIL;
composeIF2397:
	goto composeWHL2393;
composeWHX2394:
	local[12]= NIL;
composeBLK2395:
	w = NIL;
	local[10]= local[5];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.cdr;
	ctx->vsp=local+12;
	w=(pointer)NCONC(ctx,2,local+10); /*nconc*/
	local[10]= local[6];
	local[11]= argv[3];
	ctx->vsp=local+12;
	w=(*ftab[13])(ctx,2,local+10,&ftab[13],fqv[48]); /*delete*/
	argv[3] = w;
	local[10]= local[5];
	w = local[7];
	ctx->vsp=local+11;
	local[7] = cons(ctx,local[10],w);
	local[10]= local[7];
	goto composeCON2391;
composeCON2392:
	local[10]= local[8];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(*ftab[13])(ctx,2,local+10,&ftab[13],fqv[48]); /*delete*/
	local[10]= local[2];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(*ftab[13])(ctx,2,local+10,&ftab[13],fqv[48]); /*delete*/
	local[10]= local[2];
	local[11]= fqv[85];
	local[12]= argv[0];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,4,local+10); /*send*/
	local[10]= w;
	goto composeCON2391;
composeCON2399:
	local[10]= NIL;
composeCON2391:
	goto composeCON2389;
composeCON2390:
	local[10]= argv[0];
	local[11]= fqv[20];
	local[12]= local[8];
	local[13]= fqv[86];
	local[14]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= w;
	local[11]= fqv[32];
	ctx->vsp=local+12;
	w=(pointer)EQ(ctx,2,local+10); /*eql*/
	local[10]= w;
	if (w!=NIL) goto composeCON2389;
composeCON2400:
	local[10]= local[8];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(*ftab[6])(ctx,2,local+10,&ftab[6],fqv[27]); /*member*/
	if (w!=NIL) goto composeCON2401;
	local[10]= local[8];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(*ftab[13])(ctx,2,local+10,&ftab[13],fqv[48]); /*delete*/
	local[10]= local[0];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)NCONC(ctx,2,local+10); /*nconc*/
	local[10]= local[8];
	local[11]= fqv[85];
	local[12]= argv[1];
	local[13]= argv[0];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,4,local+10); /*send*/
	local[10]= w;
	goto composeCON2389;
composeCON2401:
	local[10]= fqv[87];
	local[11]= argv[0];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(*ftab[23])(ctx,3,local+10,&ftab[23],fqv[88]); /*warn*/
	local[10]= w;
	goto composeCON2389;
composeCON2402:
	local[10]= NIL;
composeCON2389:
	goto composeWHL2386;
composeWHX2387:
	local[10]= NIL;
composeBLK2388:
	w = NIL;
	local[8]= NIL;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.cdr;
composeWHL2403:
	if (local[9]==NIL) goto composeWHX2404;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= argv[1];
	local[11]= fqv[20];
	local[12]= local[8];
	local[13]= fqv[86];
	local[14]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= w;
	local[11]= fqv[56];
	ctx->vsp=local+12;
	w=(pointer)EQ(ctx,2,local+10); /*eql*/
	if (w==NIL) goto composeCON2407;
	local[10]= local[8];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(*ftab[13])(ctx,2,local+10,&ftab[13],fqv[48]); /*delete*/
	local[10]= local[1];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)NCONC(ctx,2,local+10); /*nconc*/
	local[10]= local[8];
	local[11]= fqv[85];
	local[12]= argv[0];
	local[13]= argv[1];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,4,local+10); /*send*/
	local[10]= local[8];
	local[11]= fqv[84];
	local[12]= argv[1];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= w;
	local[11]= argv[2];
	ctx->vsp=local+12;
	w=(*ftab[22])(ctx,2,local+10,&ftab[22],fqv[83]); /*assoc*/
	local[10]= w;
	w = local[7];
	ctx->vsp=local+11;
	local[7] = cons(ctx,local[10],w);
	local[10]= local[7];
	goto composeCON2406;
composeCON2407:
	local[10]= NIL;
composeCON2406:
	goto composeWHL2403;
composeWHX2404:
	local[10]= NIL;
composeBLK2405:
	w = NIL;
	local[8]= (pointer)get_sym_func(fqv[64]);
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.cdr;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.cdr;
	local[11]= (pointer)get_sym_func(fqv[76]);
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)MAPCAR(ctx,2,local+11); /*mapcar*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)APPLY(ctx,4,local+8); /*apply*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)composeF2126unify_vertex(ctx,1,local+8); /*unify-vertex*/
	w = argv[3];
	local[0]= w;
composeBLK2385:
	ctx->vsp=local; return(local[0]);}

/*merge-aligned-faces*/
static pointer composeF2129merge_aligned_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[83]); /*assoc*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(*ftab[22])(ctx,2,local+1,&ftab[22],fqv[83]); /*assoc*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	storeglobal(fqv[89],local[0]);
	local[6]= local[1];
	storeglobal(fqv[90],local[6]);
	if (loadglobal(fqv[53])==NIL) goto composeIF2409;
	local[6]= fqv[91];
	ctx->vsp=local+7;
	w=(*ftab[24])(ctx,1,local+6,&ftab[24],fqv[92]); /*break*/
	local[6]= w;
	goto composeIF2410;
composeIF2409:
	local[6]= NIL;
composeIF2410:
	local[6]= NIL;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
composeWHL2411:
	if (local[7]==NIL) goto composeWHX2412;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[6];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.cdr;
	ctx->vsp=local+10;
	w=(pointer)composeF2125find_equivalent_edge(ctx,2,local+8); /*find-equivalent-edge*/
	local[2] = w;
	if (local[2]==NIL) goto composeCON2415;
	local[8]= local[6];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[48]); /*delete*/
	local[8]= local[6];
	local[9]= local[6];
	local[10]= fqv[84];
	local[11]= argv[1];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	local[10]= argv[3];
	ctx->vsp=local+11;
	w=(*ftab[22])(ctx,2,local+9,&ftab[22],fqv[83]); /*assoc*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[48]); /*delete*/
	local[8]= w;
	goto composeCON2414;
composeCON2415:
	local[8]= argv[0];
	local[9]= fqv[20];
	local[10]= local[6];
	local[11]= fqv[86];
	local[12]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= fqv[56];
	ctx->vsp=local+10;
	w=(pointer)EQ(ctx,2,local+8); /*eql*/
	if (w==NIL) goto composeCON2416;
	local[8]= local[6];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[48]); /*delete*/
	local[8]= local[6];
	local[9]= local[6];
	local[10]= fqv[84];
	local[11]= argv[1];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	local[10]= argv[3];
	ctx->vsp=local+11;
	w=(*ftab[22])(ctx,2,local+9,&ftab[22],fqv[83]); /*assoc*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[48]); /*delete*/
	local[8]= w;
	goto composeCON2414;
composeCON2416:
	local[8]= local[6];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[48]); /*delete*/
	local[8]= local[0];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)NCONC(ctx,2,local+8); /*nconc*/
	local[8]= local[6];
	local[9]= fqv[85];
	local[10]= argv[1];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= w;
	goto composeCON2414;
composeCON2417:
	local[8]= NIL;
composeCON2414:
	goto composeWHL2411;
composeWHX2412:
	local[8]= NIL;
composeBLK2413:
	w = NIL;
	local[6]= NIL;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
composeWHL2418:
	if (local[7]==NIL) goto composeWHX2419;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= argv[1];
	local[9]= fqv[20];
	local[10]= local[6];
	local[11]= fqv[86];
	local[12]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= fqv[56];
	ctx->vsp=local+10;
	w=(pointer)EQ(ctx,2,local+8); /*eql*/
	if (w==NIL) goto composeCON2422;
	local[8]= local[6];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[48]); /*delete*/
	local[8]= local[6];
	local[9]= local[6];
	local[10]= fqv[84];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	local[10]= argv[2];
	ctx->vsp=local+11;
	w=(*ftab[22])(ctx,2,local+9,&ftab[22],fqv[83]); /*assoc*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[48]); /*delete*/
	local[8]= w;
	goto composeCON2421;
composeCON2422:
	local[8]= NIL;
composeCON2421:
	goto composeWHL2418;
composeWHX2419:
	local[8]= NIL;
composeBLK2420:
	w = NIL;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto composeIF2423;
	local[6]= fqv[93];
	ctx->vsp=local+7;
	w=(pointer)SIGERROR(ctx,1,local+6); /*error*/
	local[6]= w;
	goto composeIF2424;
composeIF2423:
	local[6]= NIL;
composeIF2424:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	local[4] = local[3];
composeWHL2425:
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto composeWHX2426;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[6];
	local[2] = w;
	local[6]= NIL;
	local[7]= NIL;
composeTAG2429:
	local[7] = local[3];
composeTAG2430:
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	if (local[6]!=NIL) goto composeCON2432;
	w = NIL;
	ctx->vsp=local+8;
	local[6]=w;
	goto composeBLK2428;
	goto composeCON2431;
composeCON2432:
	local[8]= local[2];
	local[9]= local[6];
	local[10]= argv[2];
	local[11]= argv[3];
	ctx->vsp=local+12;
	w=(pointer)composeF2127merge_edges_if_colinear(ctx,4,local+8); /*merge-edges-if-colinear*/
	if (w==NIL) goto composeCON2433;
	local[8]= local[6];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[48]); /*delete*/
	local[3] = w;
	local[8]= NIL;
	local[9]= argv[2];
composeWHL2434:
	if (local[9]==NIL) goto composeWHX2435;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[6];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(*ftab[13])(ctx,2,local+10,&ftab[13],fqv[48]); /*delete*/
	goto composeWHL2434;
composeWHX2435:
	local[10]= NIL;
composeBLK2436:
	w = NIL;
	ctx->vsp=local+8;
	goto composeTAG2429;
	goto composeCON2431;
composeCON2433:
	ctx->vsp=local+8;
	goto composeTAG2430;
	goto composeCON2431;
composeCON2437:
	local[8]= NIL;
composeCON2431:
	w = NIL;
	local[6]= w;
composeBLK2428:
	goto composeWHL2425;
composeWHX2426:
	local[6]= NIL;
composeBLK2427:
	local[6]= NIL;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
composeWHL2438:
	if (local[7]==NIL) goto composeWHX2439;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[6];
	local[9]= fqv[84];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[4] = w;
	local[8]= local[4];
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(*ftab[22])(ctx,2,local+8,&ftab[22],fqv[83]); /*assoc*/
	local[4] = w;
	if (local[4]==NIL) goto composeIF2441;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	w = local[5];
	ctx->vsp=local+9;
	local[5] = cons(ctx,local[8],w);
	local[8]= local[5];
	goto composeIF2442;
composeIF2441:
	local[8]= local[4];
	local[9]= argv[3];
	ctx->vsp=local+10;
	w=(*ftab[22])(ctx,2,local+8,&ftab[22],fqv[83]); /*assoc*/
	local[4] = w;
	if (local[4]==NIL) goto composeIF2443;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	w = local[5];
	ctx->vsp=local+9;
	local[5] = cons(ctx,local[8],w);
	local[8]= local[5];
	goto composeIF2444;
composeIF2443:
	local[8]= NIL;
composeIF2444:
composeIF2442:
	goto composeWHL2438;
composeWHX2439:
	local[8]= NIL;
composeBLK2440:
	w = NIL;
	local[6]= (pointer)get_sym_func(fqv[64]);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,3,local+6); /*apply*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[10])(ctx,1,local+6,&ftab[10],fqv[37]); /*remove-duplicates*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)composeF2126unify_vertex(ctx,1,local+6); /*unify-vertex*/
	if (loadglobal(fqv[53])==NIL) goto composeIF2445;
	local[6]= fqv[94];
	ctx->vsp=local+7;
	w=(*ftab[24])(ctx,1,local+6,&ftab[24],fqv[92]); /*break*/
	local[6]= w;
	goto composeIF2446;
composeIF2445:
	local[6]= NIL;
composeIF2446:
	w = local[6];
	w = argv[3];
	local[0]= w;
composeBLK2408:
	ctx->vsp=local; return(local[0]);}

/*compose-body*/
static pointer composeF2130compose_body(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[95];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[1];
	local[1]= fqv[95];
	ctx->vsp=local+2;
	w=(*ftab[14])(ctx,2,local+0,&ftab[14],fqv[50]); /*find-method*/
	if (w==NIL) goto composeIF2448;
	local[0]= argv[1];
	local[1]= fqv[95];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto composeIF2449;
composeIF2448:
	local[0]= NIL;
composeIF2449:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)composeF2120make_vertex_edge_htab(ctx,1,local+0); /*make-vertex-edge-htab*/
	local[0]= w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)composeF2120make_vertex_edge_htab(ctx,1,local+1); /*make-vertex-edge-htab*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[96];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[1];
	local[4]= fqv[96];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[1];
	local[6]= fqv[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= argv[0];
	local[9]= fqv[97];
	local[10]= argv[1];
	local[11]= makeflt(9.9999999999999950039964e-03);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= w;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= NIL;
	local[15]= NIL;
	local[16]= NIL;
	local[17]= NIL;
	local[18]= NIL;
	local[19]= NIL;
	local[20]= NIL;
	local[21]= NIL;
	local[22]= NIL;
	local[23]= NIL;
	ctx->vsp=local+24;
	w=(pointer)RUNTIME(ctx,0,local+24); /*unix:runtime*/
	local[16] = w;
	local[24]= local[0];
	ctx->vsp=local+25;
	w=(pointer)composeF2121copy_add_vertex(ctx,1,local+24); /*copy-add-vertex*/
	local[24]= local[1];
	ctx->vsp=local+25;
	w=(pointer)composeF2121copy_add_vertex(ctx,1,local+24); /*copy-add-vertex*/
	ctx->vsp=local+24;
	w=(pointer)RUNTIME(ctx,0,local+24); /*unix:runtime*/
	local[17] = w;
	local[24]= local[4];
	local[25]= local[0];
	ctx->vsp=local+26;
	w=(pointer)composeF2119initial_intersection_list(ctx,2,local+24); /*initial-intersection-list*/
	local[6] = w;
	local[24]= local[5];
	local[25]= local[1];
	ctx->vsp=local+26;
	w=(pointer)composeF2119initial_intersection_list(ctx,2,local+24); /*initial-intersection-list*/
	local[7] = w;
	ctx->vsp=local+24;
	w=(pointer)RUNTIME(ctx,0,local+24); /*unix:runtime*/
	local[18] = w;
	local[24]= local[6];
	local[25]= local[3];
	local[26]= local[8];
	ctx->vsp=local+27;
	w=(pointer)composeF2110insert_intersections(ctx,3,local+24); /*insert-intersections*/
	local[24]= local[7];
	local[25]= local[2];
	local[26]= local[8];
	ctx->vsp=local+27;
	w=(pointer)composeF2110insert_intersections(ctx,3,local+24); /*insert-intersections*/
	ctx->vsp=local+24;
	w=(pointer)RUNTIME(ctx,0,local+24); /*unix:runtime*/
	local[19] = w;
	storeglobal(fqv[98],local[6]);
	local[24]= local[7];
	storeglobal(fqv[99],local[24]);
	local[24]= local[6];
	local[25]= argv[1];
	local[26]= argv[2];
	ctx->vsp=local+27;
	w=(pointer)composeF2111make_edge_segments(ctx,3,local+24); /*make-edge-segments*/
	local[9] = w;
	local[24]= local[7];
	local[25]= argv[0];
	local[26]= argv[2];
	ctx->vsp=local+27;
	w=(pointer)composeF2111make_edge_segments(ctx,3,local+24); /*make-edge-segments*/
	local[10] = w;
	ctx->vsp=local+24;
	w=(pointer)RUNTIME(ctx,0,local+24); /*unix:runtime*/
	local[20] = w;
	local[24]= local[9];
	ctx->vsp=local+25;
	w=(pointer)composeF2112intersecting_segments(ctx,1,local+24); /*intersecting-segments*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)composeF2113sort_edges_by_face(ctx,1,local+24); /*sort-edges-by-face*/
	local[6] = w;
	local[24]= local[10];
	ctx->vsp=local+25;
	w=(pointer)composeF2112intersecting_segments(ctx,1,local+24); /*intersecting-segments*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)composeF2113sort_edges_by_face(ctx,1,local+24); /*sort-edges-by-face*/
	local[7] = w;
	ctx->vsp=local+24;
	w=(pointer)RUNTIME(ctx,0,local+24); /*unix:runtime*/
	local[21] = w;
	local[24]= local[9];
	ctx->vsp=local+25;
	w=(pointer)composeF2113sort_edges_by_face(ctx,1,local+24); /*sort-edges-by-face*/
	local[9] = w;
	local[24]= local[10];
	ctx->vsp=local+25;
	w=(pointer)composeF2113sort_edges_by_face(ctx,1,local+24); /*sort-edges-by-face*/
	local[10] = w;
	ctx->vsp=local+24;
	w=(pointer)RUNTIME(ctx,0,local+24); /*unix:runtime*/
	local[22] = w;
	local[24]= local[6];
	local[25]= local[10];
	local[26]= T;
	local[27]= argv[2];
	ctx->vsp=local+28;
	w=(pointer)composeF2114make_crossing_edges(ctx,4,local+24); /*make-crossing-edges*/
	local[12] = w;
	local[24]= local[7];
	local[25]= local[9];
	local[26]= NIL;
	local[27]= argv[2];
	ctx->vsp=local+28;
	w=(pointer)composeF2114make_crossing_edges(ctx,4,local+24); /*make-crossing-edges*/
	local[13] = w;
	storeglobal(fqv[100],local[9]);
	local[24]= local[10];
	storeglobal(fqv[101],local[24]);
	storeglobal(fqv[102],local[12]);
	local[24]= local[13];
	storeglobal(fqv[103],local[24]);
	if (loadglobal(fqv[53])==NIL) goto composeIF2450;
	local[24]= T;
	local[25]= fqv[104];
	ctx->vsp=local+26;
	w=(pointer)XFORMAT(ctx,2,local+24); /*format*/
	local[24]= fqv[105];
	ctx->vsp=local+25;
	w=(*ftab[24])(ctx,1,local+24,&ftab[24],fqv[92]); /*break*/
	local[24]= w;
	goto composeIF2451;
composeIF2450:
	local[24]= NIL;
composeIF2451:
	local[24]= local[9];
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[25]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26]= (w)->c.cons.car;
	ctx->vsp=local+27;
	w=(pointer)composeF2116merge_segments(ctx,3,local+24); /*merge-segments*/
	local[9] = w;
	local[24]= local[10];
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[25]= (w)->c.cons.car;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26]= (w)->c.cons.car;
	ctx->vsp=local+27;
	w=(pointer)composeF2116merge_segments(ctx,3,local+24); /*merge-segments*/
	local[10] = w;
	storeglobal(fqv[100],local[9]);
	local[24]= local[10];
	storeglobal(fqv[101],local[24]);
	local[24]= argv[1];
	local[25]= loadglobal(fqv[73]);
	ctx->vsp=local+26;
	w=(pointer)DERIVEDP(ctx,2,local+24); /*derivedp*/
	if (w==NIL) goto composeIF2452;
	local[24]= argv[0];
	local[25]= argv[1];
	ctx->vsp=local+26;
	w=(pointer)composeF2123contacting_faces(ctx,2,local+24); /*contacting-faces*/
	local[14] = w;
	local[24]= local[14];
	goto composeIF2453;
composeIF2452:
	local[24]= NIL;
composeIF2453:
	if (local[14]==NIL) goto composeIF2454;
	local[24]= loadglobal(fqv[106]);
	local[25]= fqv[107];
	local[26]= local[14];
	ctx->vsp=local+27;
	w=(pointer)LENGTH(ctx,1,local+26); /*length*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)XFORMAT(ctx,3,local+24); /*format*/
	if (loadglobal(fqv[53])==NIL) goto composeIF2456;
	local[24]= fqv[108];
	ctx->vsp=local+25;
	w=(*ftab[24])(ctx,1,local+24,&ftab[24],fqv[92]); /*break*/
	local[24]= w;
	goto composeIF2457;
composeIF2456:
	local[24]= NIL;
composeIF2457:
	local[24]= NIL;
	local[25]= local[14];
composeWHL2458:
	if (local[25]==NIL) goto composeWHX2459;
	w=local[25];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26]= (w)->c.cons.car;
	w=local[25];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[25] = (w)->c.cons.cdr;
	w = local[26];
	local[24] = w;
	w=local[24];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26]= (w)->c.cons.car;
	w=local[24];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[27]= (w)->c.cons.car;
	local[28]= local[9];
	local[29]= local[10];
	ctx->vsp=local+30;
	w=(pointer)composeF2128merge_contacting_faces(ctx,4,local+26); /*merge-contacting-faces*/
	local[10] = w;
	goto composeWHL2458;
composeWHX2459:
	local[26]= NIL;
composeBLK2460:
	w = NIL;
	local[24]= w;
	goto composeIF2455;
composeIF2454:
	local[24]= NIL;
composeIF2455:
	local[24]= (pointer)get_sym_func(fqv[76]);
	local[25]= local[9];
	ctx->vsp=local+26;
	w=(*ftab[25])(ctx,2,local+24,&ftab[25],fqv[109]); /*delete-if-not*/
	local[9] = w;
	local[24]= (pointer)get_sym_func(fqv[76]);
	local[25]= local[10];
	ctx->vsp=local+26;
	w=(*ftab[25])(ctx,2,local+24,&ftab[25],fqv[109]); /*delete-if-not*/
	local[10] = w;
	storeglobal(fqv[100],local[9]);
	local[24]= local[10];
	storeglobal(fqv[101],local[24]);
	local[24]= (pointer)get_sym_func(fqv[75]);
	local[25]= local[9];
	ctx->vsp=local+26;
	w=(pointer)MAPCAR(ctx,2,local+24); /*mapcar*/
	local[24]= w;
	local[25]= (pointer)get_sym_func(fqv[75]);
	local[26]= local[10];
	ctx->vsp=local+27;
	w=(pointer)MAPCAR(ctx,2,local+25); /*mapcar*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)composeF2124aligned_faces(ctx,2,local+24); /*aligned-faces*/
	local[15] = w;
	if (local[15]==NIL) goto composeIF2461;
	local[24]= loadglobal(fqv[106]);
	local[25]= fqv[110];
	local[26]= local[15];
	ctx->vsp=local+27;
	w=(pointer)LENGTH(ctx,1,local+26); /*length*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)XFORMAT(ctx,3,local+24); /*format*/
	local[24]= NIL;
	local[25]= local[15];
composeWHL2463:
	if (local[25]==NIL) goto composeWHX2464;
	w=local[25];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26]= (w)->c.cons.car;
	w=local[25];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[25] = (w)->c.cons.cdr;
	w = local[26];
	local[24] = w;
	w=local[24];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26]= (w)->c.cons.car;
	w=local[24];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[27]= (w)->c.cons.car;
	local[28]= local[9];
	local[29]= local[10];
	ctx->vsp=local+30;
	w=(pointer)composeF2129merge_aligned_faces(ctx,4,local+26); /*merge-aligned-faces*/
	goto composeWHL2463;
composeWHX2464:
	local[26]= NIL;
composeBLK2465:
	w = NIL;
	local[24]= w;
	goto composeIF2462;
composeIF2461:
	local[24]= NIL;
composeIF2462:
	local[24]= NIL;
	storeglobal(fqv[111],local[24]);
	if (loadglobal(fqv[53])==NIL) goto composeIF2466;
	local[24]= T;
	local[25]= fqv[112];
	ctx->vsp=local+26;
	w=(pointer)XFORMAT(ctx,2,local+24); /*format*/
	local[24]= fqv[113];
	ctx->vsp=local+25;
	w=(*ftab[24])(ctx,1,local+24,&ftab[24],fqv[92]); /*break*/
	local[24]= w;
	goto composeIF2467;
composeIF2466:
	local[24]= NIL;
composeIF2467:
	local[24]= NIL;
	local[25]= local[9];
composeWHL2468:
	if (local[25]==NIL) goto composeWHX2469;
	w=local[25];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26]= (w)->c.cons.car;
	w=local[25];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[25] = (w)->c.cons.cdr;
	w = local[26];
	local[24] = w;
	if (loadglobal(fqv[53])==NIL) goto composeIF2471;
	local[26]= T;
	local[27]= fqv[114];
	local[28]= loadglobal(fqv[111]);
	ctx->vsp=local+29;
	w=(pointer)LENGTH(ctx,1,local+28); /*length*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)XFORMAT(ctx,3,local+26); /*format*/
	local[26]= w;
	goto composeIF2472;
composeIF2471:
	local[26]= NIL;
composeIF2472:
	local[26]= local[24];
	ctx->vsp=local+27;
	w=(pointer)composeF2118construct_faces(ctx,1,local+26); /*construct-faces*/
	local[26]= w;
	w = loadglobal(fqv[111]);
	ctx->vsp=local+27;
	local[26]= cons(ctx,local[26],w);
	storeglobal(fqv[111],local[26]);
	goto composeWHL2468;
composeWHX2469:
	local[26]= NIL;
composeBLK2470:
	w = NIL;
	local[24]= NIL;
	local[25]= local[10];
composeWHL2473:
	if (local[25]==NIL) goto composeWHX2474;
	w=local[25];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26]= (w)->c.cons.car;
	w=local[25];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[25] = (w)->c.cons.cdr;
	w = local[26];
	local[24] = w;
	if (loadglobal(fqv[53])==NIL) goto composeIF2476;
	local[26]= T;
	local[27]= fqv[115];
	local[28]= loadglobal(fqv[111]);
	ctx->vsp=local+29;
	w=(pointer)LENGTH(ctx,1,local+28); /*length*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)XFORMAT(ctx,3,local+26); /*format*/
	local[26]= w;
	goto composeIF2477;
composeIF2476:
	local[26]= NIL;
composeIF2477:
	local[26]= local[24];
	ctx->vsp=local+27;
	w=(pointer)composeF2118construct_faces(ctx,1,local+26); /*construct-faces*/
	local[26]= w;
	w = loadglobal(fqv[111]);
	ctx->vsp=local+27;
	local[26]= cons(ctx,local[26],w);
	storeglobal(fqv[111],local[26]);
	goto composeWHL2473;
composeWHX2474:
	local[26]= NIL;
composeBLK2475:
	w = NIL;
	local[24]= loadglobal(fqv[111]);
	ctx->vsp=local+25;
	w=(pointer)NREVERSE(ctx,1,local+24); /*nreverse*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(*ftab[26])(ctx,1,local+24,&ftab[26],fqv[116]); /*flatten*/
	local[24]= w;
	storeglobal(fqv[111],w);
	ctx->vsp=local+24;
	w=(pointer)RUNTIME(ctx,0,local+24); /*unix:runtime*/
	local[23] = w;
	if (loadglobal(fqv[53])==NIL) goto composeIF2478;
	local[24]= T;
	local[25]= fqv[117];
	local[26]= makeflt(1.6699999999999992628119e-02);
	local[27]= local[17];
	local[28]= local[16];
	ctx->vsp=local+29;
	w=(pointer)MINUS(ctx,2,local+27); /*-*/
	local[27]= w;
	ctx->vsp=local+28;
	w=(pointer)TIMES(ctx,2,local+26); /***/
	local[26]= w;
	local[27]= makeflt(1.6699999999999992628119e-02);
	local[28]= local[18];
	local[29]= local[17];
	ctx->vsp=local+30;
	w=(pointer)MINUS(ctx,2,local+28); /*-*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)TIMES(ctx,2,local+27); /***/
	local[27]= w;
	local[28]= makeflt(1.6699999999999992628119e-02);
	local[29]= local[19];
	local[30]= local[18];
	ctx->vsp=local+31;
	w=(pointer)MINUS(ctx,2,local+29); /*-*/
	local[29]= w;
	ctx->vsp=local+30;
	w=(pointer)TIMES(ctx,2,local+28); /***/
	local[28]= w;
	local[29]= makeflt(1.6699999999999992628119e-02);
	local[30]= local[20];
	local[31]= local[19];
	ctx->vsp=local+32;
	w=(pointer)MINUS(ctx,2,local+30); /*-*/
	local[30]= w;
	ctx->vsp=local+31;
	w=(pointer)TIMES(ctx,2,local+29); /***/
	local[29]= w;
	local[30]= makeflt(1.6699999999999992628119e-02);
	local[31]= local[21];
	local[32]= local[20];
	ctx->vsp=local+33;
	w=(pointer)MINUS(ctx,2,local+31); /*-*/
	local[31]= w;
	ctx->vsp=local+32;
	w=(pointer)TIMES(ctx,2,local+30); /***/
	local[30]= w;
	local[31]= makeflt(1.6699999999999992628119e-02);
	local[32]= local[22];
	local[33]= local[21];
	ctx->vsp=local+34;
	w=(pointer)MINUS(ctx,2,local+32); /*-*/
	local[32]= w;
	ctx->vsp=local+33;
	w=(pointer)TIMES(ctx,2,local+31); /***/
	local[31]= w;
	local[32]= makeflt(1.6699999999999992628119e-02);
	local[33]= local[23];
	local[34]= local[22];
	ctx->vsp=local+35;
	w=(pointer)MINUS(ctx,2,local+33); /*-*/
	local[33]= w;
	ctx->vsp=local+34;
	w=(pointer)TIMES(ctx,2,local+32); /***/
	local[32]= w;
	ctx->vsp=local+33;
	w=(pointer)XFORMAT(ctx,9,local+24); /*format*/
	local[24]= w;
	goto composeIF2479;
composeIF2478:
	local[24]= NIL;
composeIF2479:
	local[24]= loadglobal(fqv[118]);
	ctx->vsp=local+25;
	w=(pointer)INSTANTIATE(ctx,1,local+24); /*instantiate*/
	local[24]= w;
	local[25]= local[24];
	local[26]= fqv[9];
	local[27]= fqv[96];
	local[28]= loadglobal(fqv[111]);
	ctx->vsp=local+29;
	w=(pointer)SEND(ctx,4,local+25); /*send*/
	w = local[24];
	local[0]= w;
composeBLK2447:
	ctx->vsp=local; return(local[0]);}

/*set-original-face*/
static pointer composeF2131set_original_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[119];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[120];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,composeCLO2481,env,argv,local);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[0];
	local[7]= fqv[96];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
composeWHL2482:
	if (local[6]==NIL) goto composeWHX2483;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[5];
	local[8]= fqv[51];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[3] = w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(*ftab[27])(ctx,1,local+7,&ftab[27],fqv[121]); /*primitive-body-p*/
	if (w==NIL) goto composeCON2486;
	local[7]= local[3];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(*ftab[28])(ctx,2,local+7,&ftab[28],fqv[122]); /*position*/
	local[4] = w;
	if (local[4]==NIL) goto composeIF2487;
	local[7]= local[5];
	local[8]= fqv[49];
	local[9]= local[5];
	local[10]= fqv[49];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= local[3];
	local[11]= fqv[96];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[28])(ctx,2,local+9,&ftab[28],fqv[122]); /*position*/
	local[9]= w;
	local[10]= local[4];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)NTH(ctx,2,local+10); /*nth*/
	local[10]= w;
	local[11]= fqv[96];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)NTH(ctx,2,local+9); /*nth*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	goto composeIF2488;
composeIF2487:
	local[7]= NIL;
composeIF2488:
	goto composeCON2485;
composeCON2486:
	local[7]= fqv[123];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[23])(ctx,2,local+7,&ftab[23],fqv[88]); /*warn*/
	local[7]= w;
	goto composeCON2485;
composeCON2489:
	local[7]= NIL;
composeCON2485:
	local[7]= local[5];
	local[8]= fqv[51];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	goto composeWHL2482;
composeWHX2483:
	local[7]= NIL;
composeBLK2484:
	w = NIL;
	local[5]= NIL;
	local[6]= local[1];
composeWHL2490:
	if (local[6]==NIL) goto composeWHX2491;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[5];
	local[8]= T;
	local[9]= fqv[124];
	ctx->vsp=local+10;
	w=(pointer)PUTPROP(ctx,3,local+7); /*putprop*/
	local[7]= argv[0];
	local[8]= fqv[125];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	goto composeWHL2490;
composeWHX2491:
	local[7]= NIL;
composeBLK2492:
	w = NIL;
	w = local[1];
	local[0]= w;
composeBLK2480:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer composeCLO2481(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(pointer)GETPROP(ctx,2,local+0); /*get*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*body+*/
static pointer composeF2132body_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
composeRST2494:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= local[1];
	local[3]= fqv[126];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	local[3]= NIL;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
composeWHL2495:
	if (local[4]==NIL) goto composeWHX2496;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[1];
	local[6]= local[3];
	local[7]= fqv[32];
	ctx->vsp=local+8;
	w=(pointer)composeF2130compose_body(ctx,3,local+5); /*compose-body*/
	local[1] = w;
	local[5]= local[3];
	local[6]= fqv[126];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	goto composeWHL2495;
composeWHX2496:
	local[5]= NIL;
composeBLK2497:
	w = NIL;
	local[3]= local[1];
	local[4]= fqv[119];
	local[5]= fqv[127];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)NREVERSE(ctx,1,local+6); /*nreverse*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)composeF2131set_original_face(ctx,1,local+3); /*set-original-face*/
	w = local[1];
	local[0]= w;
composeBLK2493:
	ctx->vsp=local; return(local[0]);}

/*body**/
static pointer composeF2133body_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
composeRST2499:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[1];
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[126];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
composeWHL2500:
	if (local[0]==NIL) goto composeWHX2501;
	local[3]= local[1];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= fqv[56];
	ctx->vsp=local+6;
	w=(pointer)composeF2130compose_body(ctx,3,local+3); /*compose-body*/
	local[1] = w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[3];
	local[3]= w;
	local[4]= fqv[126];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	w = local[2];
	ctx->vsp=local+4;
	local[2] = cons(ctx,local[3],w);
	goto composeWHL2500;
composeWHX2501:
	local[3]= NIL;
composeBLK2502:
	local[3]= local[1];
	local[4]= fqv[119];
	local[5]= fqv[128];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)NREVERSE(ctx,1,local+6); /*nreverse*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)composeF2131set_original_face(ctx,1,local+3); /*set-original-face*/
	w = local[1];
	local[0]= w;
composeBLK2498:
	ctx->vsp=local; return(local[0]);}

/*body-*/
static pointer composeF2134body_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
composeRST2504:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= argv[0];
	local[2]= NIL;
	local[3]= argv[0];
	local[4]= fqv[129];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	ctx->vsp=local+3;
	w = makeclosure(codevec,quotevec,composeUWP2505,env,argv,local);
	local[3]=(pointer)(ctx->protfp); local[4]=w;
	ctx->protfp=(struct protectframe *)(local+3);
composeWHL2506:
	if (local[0]==NIL) goto composeWHX2507;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[126];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	local[5]= local[1];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[6];
	local[6]= w;
	local[7]= fqv[32];
	ctx->vsp=local+8;
	w=(pointer)composeF2130compose_body(ctx,3,local+5); /*compose-body*/
	local[1] = w;
	local[5]= T;
	local[6]= local[5];
	*(ovafptr(local[1],fqv[130])) = local[6];
	goto composeWHL2506;
composeWHX2507:
	local[5]= NIL;
composeBLK2508:
	w = local[5];
	ctx->vsp=local+5;
	composeUWP2505(ctx,0,local+5,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[3]= local[1];
	local[4]= fqv[129];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= local[1];
	local[4]= fqv[9];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= local[1];
	local[4]= fqv[119];
	local[5]= fqv[131];
	local[6]= argv[0];
	local[7]= fqv[126];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)NREVERSE(ctx,1,local+7); /*nreverse*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)composeF2131set_original_face(ctx,1,local+3); /*set-original-face*/
	w = local[1];
	local[0]= w;
composeBLK2503:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer composeUWP2505(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[129];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*body-interference*/
static pointer composeF2135body_interference(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
composeRST2510:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= local[0];
	local[2]= fqv[95];
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,2,local+1,&ftab[17],fqv[66]); /*send-all*/
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
composeWHL2511:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto composeWHX2512;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	local[1] = w;
	local[4]= NIL;
	local[5]= local[0];
composeWHL2514:
	if (local[5]==NIL) goto composeWHX2515;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[1];
	local[7]= fqv[132];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	if (w==NIL) goto composeIF2517;
	local[6]= local[4];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	w = local[3];
	ctx->vsp=local+7;
	local[3] = cons(ctx,local[6],w);
	local[6]= local[3];
	goto composeIF2518;
composeIF2517:
	local[6]= NIL;
composeIF2518:
	goto composeWHL2514;
composeWHX2515:
	local[6]= NIL;
composeBLK2516:
	w = NIL;
	goto composeWHL2511;
composeWHX2512:
	local[4]= NIL;
composeBLK2513:
	w = local[3];
	local[0]= w;
composeBLK2509:
	ctx->vsp=local; return(local[0]);}

/*:box*/
static pointer composeM2519plane_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[133]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[9];
	local[3]= makeflt(-9.9999999999999973840965e+29);
	local[4]= makeflt(-9.9999999999999973840965e+29);
	local[5]= makeflt(-9.9999999999999973840965e+29);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= makeflt(9.9999999999999973840965e+29);
	local[5]= makeflt(9.9999999999999973840965e+29);
	local[6]= makeflt(9.9999999999999973840965e+29);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
composeBLK2520:
	ctx->vsp=local; return(local[0]);}

/*:edges*/
static pointer composeM2521semi_space_edges(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = NIL;
	local[0]= w;
composeBLK2522:
	ctx->vsp=local; return(local[0]);}

/*:faces*/
static pointer composeM2523semi_space_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
composeBLK2524:
	ctx->vsp=local; return(local[0]);}

/*:box*/
static pointer composeM2525semi_space_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto composeENT2528;}
	local[0]= makeflt(0.0000000000000000000000e+00);
composeENT2528:
composeENT2527:
	if (n>3) maerror();
	local[1]= loadglobal(fqv[133]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[134];
	local[4]= makeflt(-9.9999999999999973840965e+29);
	local[5]= makeflt(-9.9999999999999973840965e+29);
	local[6]= makeflt(-9.9999999999999973840965e+29);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	local[5]= makeflt(9.9999999999999973840965e+29);
	local[6]= makeflt(9.9999999999999973840965e+29);
	local[7]= makeflt(9.9999999999999973840965e+29);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[0]= w;
composeBLK2526:
	ctx->vsp=local; return(local[0]);}

/*:insidep*/
static pointer composeM2529semi_space_insidep(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[135];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto composeIF2531;
	local[0]= fqv[56];
	goto composeIF2532;
composeIF2531:
	local[0]= fqv[32];
composeIF2532:
	w = local[0];
	local[0]= w;
composeBLK2530:
	ctx->vsp=local; return(local[0]);}

/*:primitive-face*/
static pointer composeM2533semi_space_primitive_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto composeENT2536;}
	local[0]= NIL;
composeENT2536:
composeENT2535:
	if (n>3) maerror();
	w = argv[0];
	local[0]= w;
composeBLK2534:
	ctx->vsp=local; return(local[0]);}

/*:body*/
static pointer composeM2537semi_space_body(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto composeENT2540;}
	local[0]= NIL;
composeENT2540:
composeENT2539:
	if (n>3) maerror();
	w = NIL;
	local[0]= w;
composeBLK2538:
	ctx->vsp=local; return(local[0]);}

/*:id*/
static pointer composeM2541semi_space_id(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto composeENT2544;}
	local[0]= NIL;
composeENT2544:
composeENT2543:
	if (n>3) maerror();
	w = NIL;
	local[0]= w;
composeBLK2542:
	ctx->vsp=local; return(local[0]);}

/*:on-edge*/
static pointer composeM2545semi_space_on_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto composeENT2548;}
	local[0]= NIL;
composeENT2548:
composeENT2547:
	if (n>4) maerror();
	w = NIL;
	local[0]= w;
composeBLK2546:
	ctx->vsp=local; return(local[0]);}

/*body/*/
static pointer composeF2136body_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[136]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[9];
	local[3]= *(ovafptr(argv[1],fqv[31]));
	local[4]= *(ovafptr(argv[1],fqv[137]));
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= fqv[56];
	ctx->vsp=local+4;
	w=(pointer)composeF2130compose_body(ctx,3,local+1); /*compose-body*/
	local[0]= w;
composeBLK2549:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___compose(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[138];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto composeIF2550;
	local[0]= fqv[139];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[140],w);
	goto composeIF2551;
composeIF2550:
	local[0]= fqv[141];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
composeIF2551:
	local[0]= fqv[142];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[143];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[144];
	local[1]= fqv[145];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto composeIF2552;
	local[0]= fqv[144];
	local[1]= fqv[145];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[144];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto composeIF2554;
	local[0]= fqv[144];
	local[1]= fqv[146];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto composeIF2555;
composeIF2554:
	local[0]= NIL;
composeIF2555:
	local[0]= fqv[144];
	goto composeIF2553;
composeIF2552:
	local[0]= NIL;
composeIF2553:
	local[0]= fqv[147];
	local[1]= fqv[145];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto composeIF2556;
	local[0]= fqv[147];
	local[1]= fqv[145];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[147];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto composeIF2558;
	local[0]= fqv[147];
	local[1]= fqv[146];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto composeIF2559;
composeIF2558:
	local[0]= NIL;
composeIF2559:
	local[0]= fqv[147];
	goto composeIF2557;
composeIF2556:
	local[0]= NIL;
composeIF2557:
	local[0]= fqv[111];
	local[1]= fqv[145];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto composeIF2560;
	local[0]= fqv[111];
	local[1]= fqv[145];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[111];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto composeIF2562;
	local[0]= fqv[111];
	local[1]= fqv[146];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto composeIF2563;
composeIF2562:
	local[0]= NIL;
composeIF2563:
	local[0]= fqv[111];
	goto composeIF2561;
composeIF2560:
	local[0]= NIL;
composeIF2561:
	local[0]= fqv[148];
	local[1]= fqv[145];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto composeIF2564;
	local[0]= fqv[148];
	local[1]= fqv[145];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[148];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto composeIF2566;
	local[0]= fqv[148];
	local[1]= fqv[146];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto composeIF2567;
composeIF2566:
	local[0]= NIL;
composeIF2567:
	local[0]= fqv[148];
	goto composeIF2565;
composeIF2564:
	local[0]= NIL;
composeIF2565:
	local[0]= fqv[8];
	local[1]= fqv[145];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto composeIF2568;
	local[0]= fqv[8];
	local[1]= fqv[145];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[8];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto composeIF2570;
	local[0]= fqv[8];
	local[1]= fqv[146];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto composeIF2571;
composeIF2570:
	local[0]= NIL;
composeIF2571:
	local[0]= fqv[8];
	goto composeIF2569;
composeIF2568:
	local[0]= NIL;
composeIF2569:
	local[0]= fqv[45];
	local[1]= fqv[145];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto composeIF2572;
	local[0]= fqv[45];
	local[1]= fqv[145];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[45];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto composeIF2574;
	local[0]= fqv[45];
	local[1]= fqv[146];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto composeIF2575;
composeIF2574:
	local[0]= NIL;
composeIF2575:
	local[0]= fqv[45];
	goto composeIF2573;
composeIF2572:
	local[0]= NIL;
composeIF2573:
	local[0]= fqv[57];
	local[1]= fqv[145];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto composeIF2576;
	local[0]= fqv[57];
	local[1]= fqv[145];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[57];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto composeIF2578;
	local[0]= fqv[57];
	local[1]= fqv[146];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto composeIF2579;
composeIF2578:
	local[0]= NIL;
composeIF2579:
	local[0]= fqv[57];
	goto composeIF2577;
composeIF2576:
	local[0]= NIL;
composeIF2577:
	local[0]= fqv[118];
	local[1]= fqv[145];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto composeIF2580;
	local[0]= fqv[118];
	local[1]= fqv[145];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[118];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto composeIF2582;
	local[0]= fqv[118];
	local[1]= fqv[146];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto composeIF2583;
composeIF2582:
	local[0]= NIL;
composeIF2583:
	local[0]= fqv[118];
	goto composeIF2581;
composeIF2580:
	local[0]= NIL;
composeIF2581:
	ctx->vsp=local+0;
	compfun(ctx,fqv[149],module,composeF2108intersecting_edges,fqv[150]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[151],module,composeF2109cut_body,fqv[152]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[153],module,composeF2110insert_intersections,fqv[154]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[155],module,composeF2111make_edge_segments,fqv[156]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[157],module,composeF2112intersecting_segments,fqv[158]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[159],module,composeF2113sort_edges_by_face,fqv[160]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[161],module,composeF2114make_crossing_edges,fqv[162]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[163],module,composeF2115add_alist,fqv[164]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[165],module,composeF2116merge_segments,fqv[166]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[167],module,composeF2117find_connecting_edge,fqv[168]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[169],module,composeF2118construct_faces,fqv[170]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[171],module,composeF2119initial_intersection_list,fqv[172]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[173],module,composeF2120make_vertex_edge_htab,fqv[174]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[175],module,composeF2121copy_add_vertex,fqv[176]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[177],module,composeF2122find_colinear_int,fqv[178]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[179],module,composeF2123contacting_faces,fqv[180]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[181],module,composeF2124aligned_faces,fqv[182]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[183],module,composeF2125find_equivalent_edge,fqv[184]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[185],module,composeF2126unify_vertex,fqv[186]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[187],module,composeF2127merge_edges_if_colinear,fqv[188]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[189],module,composeF2128merge_contacting_faces,fqv[190]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[191],module,composeF2129merge_aligned_faces,fqv[192]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[193],module,composeF2130compose_body,fqv[194]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[195],module,composeF2131set_original_face,fqv[196]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[197],module,composeF2132body_,fqv[198]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[199],module,composeF2133body_,fqv[200]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[201],module,composeF2134body_,fqv[202]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[203],module,composeF2135body_interference,fqv[204]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,composeM2519plane_box,fqv[14],fqv[205],fqv[206]);
	local[0]= fqv[136];
	local[1]= fqv[146];
	local[2]= fqv[136];
	local[3]= fqv[207];
	local[4]= loadglobal(fqv[205]);
	local[5]= fqv[208];
	local[6]= fqv[209];
	local[7]= fqv[210];
	local[8]= NIL;
	local[9]= fqv[211];
	local[10]= NIL;
	local[11]= fqv[68];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[212];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[29])(ctx,13,local+2,&ftab[29],fqv[213]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,composeM2521semi_space_edges,fqv[1],fqv[136],fqv[214]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,composeM2523semi_space_faces,fqv[96],fqv[136],fqv[215]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,composeM2525semi_space_box,fqv[14],fqv[136],fqv[216]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,composeM2529semi_space_insidep,fqv[20],fqv[136],fqv[217]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,composeM2533semi_space_primitive_face,fqv[49],fqv[136],fqv[218]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,composeM2537semi_space_body,fqv[51],fqv[136],fqv[219]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,composeM2541semi_space_id,fqv[52],fqv[136],fqv[220]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,composeM2545semi_space_on_edge,fqv[38],fqv[136],fqv[221]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[222],module,composeF2136body_,fqv[223]);
	local[0]= fqv[224];
	local[1]= fqv[225];
	ctx->vsp=local+2;
	w=(*ftab[30])(ctx,2,local+0,&ftab[30],fqv[226]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<31; i++) ftab[i]=fcallx;
}

/* ./geobody.c :  entry=geobody */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "geobody.h"
#pragma init (register_geobody)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___geobody();
extern pointer build_quote_vector();
static int register_geobody()
  { add_module_initializer("___geobody", ___geobody);}

static pointer geobodyF1084add_wings();

/*:update*/
static pointer geobodyM1085faceset_update(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (loadglobal(fqv[0])==NIL) goto geobodyIF1087;
	local[0]= loadglobal(fqv[1]);
	local[1]= fqv[2];
	local[2]= argv[0];
	local[3]= fqv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	goto geobodyIF1088;
geobodyIF1087:
	local[0]= NIL;
geobodyIF1088:
	local[0]= argv[0];
	local[1]= fqv[4];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[9];
geobodyWHL1089:
	if (local[1]==NIL) goto geobodyWHX1090;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	goto geobodyWHL1089;
geobodyWHX1090:
	local[2]= NIL;
geobodyBLK1091:
	w = NIL;
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[7]); /*remprop*/
	w = argv[0];
	local[0]= w;
geobodyBLK1086:
	ctx->vsp=local; return(local[0]);}

/*:vertices*/
static pointer geobodyM1092faceset_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[11];
	local[0]= w;
geobodyBLK1093:
	ctx->vsp=local; return(local[0]);}

/*:faces*/
static pointer geobodyM1094faceset_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
geobodyRST1096:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]==NIL) goto geobodyCON1098;
	local[1]= (pointer)get_sym_func(fqv[8]);
	local[2]= argv[0];
	local[3]= fqv[9];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto geobodyCON1097;
geobodyCON1098:
	local[1]= argv[0]->c.obj.iv[9];
	goto geobodyCON1097;
geobodyCON1099:
	local[1]= NIL;
geobodyCON1097:
	w = local[1];
	local[0]= w;
geobodyBLK1095:
	ctx->vsp=local; return(local[0]);}

/*:face*/
static pointer geobodyM1100faceset_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+2;
	w=(pointer)NTH(ctx,2,local+0); /*nth*/
	local[0]= w;
geobodyBLK1101:
	ctx->vsp=local; return(local[0]);}

/*:all-edges*/
static pointer geobodyM1102faceset_all_edges(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
geobodyBLK1103:
	ctx->vsp=local; return(local[0]);}

/*:edges*/
static pointer geobodyM1104faceset_edges(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
geobodyBLK1105:
	ctx->vsp=local; return(local[0]);}

/*:edge*/
static pointer geobodyM1106faceset_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	w=(pointer)NTH(ctx,2,local+0); /*nth*/
	local[0]= w;
geobodyBLK1107:
	ctx->vsp=local; return(local[0]);}

/*:vertex*/
static pointer geobodyM1108faceset_vertex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[11];
	ctx->vsp=local+2;
	w=(pointer)NTH(ctx,2,local+0); /*nth*/
	local[0]= w;
geobodyBLK1109:
	ctx->vsp=local; return(local[0]);}

/*:box*/
static pointer geobodyM1110faceset_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
geobodyBLK1111:
	ctx->vsp=local; return(local[0]);}

/*:color*/
static pointer geobodyM1112faceset_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geobodyENT1115;}
	local[0]= NIL;
geobodyENT1115:
geobodyENT1114:
	if (n>3) maerror();
	if (local[0]==NIL) goto geobodyIF1116;
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= fqv[10];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= w;
	goto geobodyIF1117;
geobodyIF1116:
	local[1]= argv[0];
	local[2]= fqv[10];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[1]= w;
geobodyIF1117:
	w = local[1];
	local[0]= w;
geobodyBLK1113:
	ctx->vsp=local; return(local[0]);}

/*:reflectance*/
static pointer geobodyM1118faceset_reflectance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geobodyENT1121;}
	local[0]= NIL;
geobodyENT1121:
geobodyENT1120:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= NIL;
	if (local[0]==NIL) goto geobodyIF1122;
	local[3]= argv[0];
	local[4]= local[0];
	local[5]= fqv[11];
	ctx->vsp=local+6;
	w=(pointer)PUTPROP(ctx,3,local+3); /*putprop*/
	local[3]= w;
	goto geobodyIF1123;
geobodyIF1122:
	local[3]= argv[0];
	local[4]= fqv[11];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[2] = w;
	if (local[2]==NIL) goto geobodyIF1124;
	local[3]= local[2];
	goto geobodyIF1125;
geobodyIF1124:
	local[3]= makeflt(5.0000000000000000000000e-01);
geobodyIF1125:
geobodyIF1123:
	w = local[3];
	local[0]= w;
geobodyBLK1119:
	ctx->vsp=local; return(local[0]);}

/*:diffusion*/
static pointer geobodyM1126faceset_diffusion(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geobodyENT1129;}
	local[0]= NIL;
geobodyENT1129:
geobodyENT1128:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= NIL;
	if (local[0]==NIL) goto geobodyIF1130;
	local[3]= argv[0];
	local[4]= local[0];
	local[5]= fqv[12];
	ctx->vsp=local+6;
	w=(pointer)PUTPROP(ctx,3,local+3); /*putprop*/
	local[3]= w;
	goto geobodyIF1131;
geobodyIF1130:
	local[3]= argv[0];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[2] = w;
	if (local[2]==NIL) goto geobodyIF1132;
	local[3]= local[2];
	goto geobodyIF1133;
geobodyIF1132:
	local[3]= makeflt(5.0000000000000000000000e-01);
geobodyIF1133:
geobodyIF1131:
	w = local[3];
	local[0]= w;
geobodyBLK1127:
	ctx->vsp=local; return(local[0]);}

/*:holes*/
static pointer geobodyM1134faceset_holes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= (pointer)get_sym_func(fqv[13]);
	local[1]= argv[0]->c.obj.iv[9];
	local[2]= fqv[14];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[15]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPLY(ctx,2,local+0); /*apply*/
	local[0]= w;
geobodyBLK1135:
	ctx->vsp=local; return(local[0]);}

/*:visible-faces*/
static pointer geobodyM1136faceset_visible_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= loadglobal(fqv[16]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto geobodyIF1138;
	local[0]= argv[2];
	local[1]= fqv[17];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[2] = w;
	local[0]= argv[2];
	goto geobodyIF1139;
geobodyIF1138:
	local[0]= NIL;
geobodyIF1139:
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,geobodyCLO1140,env,argv,local);
	local[1]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
geobodyBLK1137:
	ctx->vsp=local; return(local[0]);}

/*:visible-edges*/
static pointer geobodyM1141faceset_visible_edges(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[2];
	local[4]= loadglobal(fqv[16]);
	ctx->vsp=local+5;
	w=(pointer)DERIVEDP(ctx,2,local+3); /*derivedp*/
	if (w==NIL) goto geobodyIF1143;
	local[3]= argv[2];
	local[4]= fqv[17];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	argv[2] = w;
	local[3]= argv[2];
	goto geobodyIF1144;
geobodyIF1143:
	local[3]= NIL;
geobodyIF1144:
	local[3]= argv[0];
	local[4]= fqv[6];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[2] = w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)EQUAL(ctx,2,local+3); /*equal*/
	if (w==NIL) goto geobodyIF1145;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	goto geobodyIF1146;
geobodyIF1145:
	local[3]= fqv[18];
	local[4]= makeflt(1.5000000000000000000000e+00);
	local[5]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ROUND(ctx,1,local+4); /*round*/
	local[4]= w;
	local[5]= fqv[19];
	local[6]= (pointer)get_sym_func(fqv[20]);
	ctx->vsp=local+7;
	w=(*ftab[2])(ctx,4,local+3,&ftab[2],fqv[21]); /*make-hash-table*/
	local[3]= w;
	local[4]= NIL;
	local[5]= argv[0];
	local[6]= fqv[22];
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
geobodyWHL1147:
	if (local[5]==NIL) goto geobodyWHX1148;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= NIL;
	local[7]= local[4];
	local[8]= fqv[23];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
geobodyWHL1150:
	if (local[7]==NIL) goto geobodyWHX1151;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[6];
	local[9]= local[3];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,3,local+8,&ftab[3],fqv[24]); /*sethash*/
	goto geobodyWHL1150;
geobodyWHX1151:
	local[8]= NIL;
geobodyBLK1152:
	w = NIL;
	goto geobodyWHL1147;
geobodyWHX1148:
	local[6]= NIL;
geobodyBLK1149:
	w = NIL;
	local[4]= local[3];
	local[5]= fqv[25];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[2] = w;
	local[4]= argv[0];
	local[5]= argv[2];
	w = local[2];
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[6];
	ctx->vsp=local+7;
	w=(pointer)PUTPROP(ctx,3,local+4); /*putprop*/
	local[4]= local[3]->c.obj.iv[0];
	ctx->vsp=local+5;
	w=(pointer)RECLAIM(ctx,1,local+4); /*system:reclaim*/
	local[4]= local[3]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(pointer)RECLAIM(ctx,1,local+4); /*system:reclaim*/
	w = local[2];
	local[3]= w;
geobodyIF1146:
	w = local[3];
	local[0]= w;
geobodyBLK1142:
	ctx->vsp=local; return(local[0]);}

/*:contour-edges*/
static pointer geobodyM1153faceset_contour_edges(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[22];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[10];
geobodyWHL1155:
	if (local[4]==NIL) goto geobodyWHX1156;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3]->c.obj.iv[3];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,2,local+5,&ftab[4],fqv[26]); /*member*/
	if (w==NIL) goto geobodyCON1159;
	local[5]= local[3]->c.obj.iv[4];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,2,local+5,&ftab[4],fqv[26]); /*member*/
	if (w!=NIL) goto geobodyIF1160;
	local[5]= local[3];
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	local[5]= local[2];
	goto geobodyIF1161;
geobodyIF1160:
	local[5]= NIL;
geobodyIF1161:
	goto geobodyCON1158;
geobodyCON1159:
	local[5]= local[3]->c.obj.iv[4];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,2,local+5,&ftab[4],fqv[26]); /*member*/
	if (w==NIL) goto geobodyCON1162;
	local[5]= local[3]->c.obj.iv[3];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,2,local+5,&ftab[4],fqv[26]); /*member*/
	if (w!=NIL) goto geobodyIF1163;
	local[5]= local[3];
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	local[5]= local[2];
	goto geobodyIF1164;
geobodyIF1163:
	local[5]= NIL;
geobodyIF1164:
	goto geobodyCON1158;
geobodyCON1162:
	local[5]= NIL;
geobodyCON1158:
	goto geobodyWHL1155;
geobodyWHX1156:
	local[5]= NIL;
geobodyBLK1157:
	w = NIL;
	w = local[2];
	local[0]= w;
geobodyBLK1154:
	ctx->vsp=local; return(local[0]);}

/*:non-contour-edges*/
static pointer geobodyM1165faceset_non_contour_edges(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[22];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[10];
geobodyWHL1167:
	if (local[4]==NIL) goto geobodyWHX1168;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3]->c.obj.iv[3];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,2,local+5,&ftab[4],fqv[26]); /*member*/
	if (w==NIL) goto geobodyIF1170;
	local[5]= local[3]->c.obj.iv[4];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,2,local+5,&ftab[4],fqv[26]); /*member*/
	if (w==NIL) goto geobodyIF1170;
	local[5]= local[3];
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	local[5]= local[2];
	goto geobodyIF1171;
geobodyIF1170:
	local[5]= NIL;
geobodyIF1171:
	goto geobodyWHL1167;
geobodyWHX1168:
	local[5]= NIL;
geobodyBLK1169:
	w = NIL;
	w = local[2];
	local[0]= w;
geobodyBLK1166:
	ctx->vsp=local; return(local[0]);}

/*:common-box*/
static pointer geobodyM1172faceset_common_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geobodyENT1175;}
	local[0]= NIL;
geobodyENT1175:
geobodyENT1174:
	if (n>4) maerror();
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= fqv[27];
	local[3]= argv[2];
	local[4]= fqv[28];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
geobodyBLK1173:
	ctx->vsp=local; return(local[0]);}

/*:newbox*/
static pointer geobodyM1176faceset_newbox(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geobodyENT1179;}
	local[0]= loadglobal(fqv[29]);
geobodyENT1179:
geobodyENT1178:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[11];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[30]); /*make-bounding-box*/
	argv[0]->c.obj.iv[8] = w;
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
geobodyBLK1177:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyCLO1140(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[31];
	local[2]= env->c.clo.env1[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	if (w==NIL) goto geobodyIF1180;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto geobodyIF1181;
geobodyIF1180:
	local[0]= NIL;
geobodyIF1181:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:reset-vertices*/
static pointer geobodyM1182faceset_reset_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[12];
	local[1]= argv[0]->c.obj.iv[11];
	local[2]= argv[0]->c.obj.iv[5]->c.obj.iv[1];
	local[3]= argv[0]->c.obj.iv[5]->c.obj.iv[2];
geobodyWHL1184:
	if (local[0]==NIL) goto geobodyWHX1185;
	local[4]= local[2];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)TRANSFORM(ctx,3,local+4); /*transform*/
	local[4]= local[3];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)VPLUS(ctx,3,local+4); /*v+*/
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[4];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	goto geobodyWHL1184;
geobodyWHX1185:
	local[4]= NIL;
geobodyBLK1186:
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[32];
	local[6]= argv[0]->c.obj.iv[11];
	local[7]= loadglobal(fqv[29]);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = argv[0];
	local[0]= w;
geobodyBLK1183:
	ctx->vsp=local; return(local[0]);}

/*:translate-vertices*/
static pointer geobodyM1187faceset_translate_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[12];
geobodyWHL1189:
	if (local[1]==NIL) goto geobodyWHX1190;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)VPLUS(ctx,3,local+2); /*v+*/
	goto geobodyWHL1189;
geobodyWHX1190:
	local[2]= NIL;
geobodyBLK1191:
	w = NIL;
	local[0]= argv[0];
	local[1]= fqv[33];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = argv[0];
	local[0]= w;
geobodyBLK1188:
	ctx->vsp=local; return(local[0]);}

/*:rotate-vertices*/
static pointer geobodyM1192faceset_rotate_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[34]); /*float-vector-p*/
	if (w==NIL) goto geobodyIF1194;
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(*ftab[7])(ctx,2,local+1,&ftab[7],fqv[35]); /*rotation*/
	local[0] = w;
	local[1]= local[0];
	goto geobodyIF1195;
geobodyIF1194:
	local[1]= NIL;
geobodyIF1195:
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[12];
geobodyWHL1196:
	if (local[2]==NIL) goto geobodyWHX1197;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,1,local+3,&ftab[6],fqv[34]); /*float-vector-p*/
	if (w==NIL) goto geobodyIF1199;
	local[3]= local[0];
	local[4]= local[1];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)TRANSFORM(ctx,3,local+3); /*transform*/
	local[3]= w;
	goto geobodyIF1200;
geobodyIF1199:
	local[3]= local[1];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ROTVEC(ctx,4,local+3); /*rotate-vector*/
	local[3]= w;
geobodyIF1200:
	goto geobodyWHL1196;
geobodyWHX1197:
	local[3]= NIL;
geobodyBLK1198:
	w = NIL;
	local[0]= argv[0];
	local[1]= fqv[33];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = argv[0];
	local[0]= w;
geobodyBLK1193:
	ctx->vsp=local; return(local[0]);}

/*:magnify*/
static pointer geobodyM1201faceset_magnify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geobodyENT1204;}
	local[0]= NIL;
geobodyENT1204:
geobodyENT1203:
	if (n>4) maerror();
	if (local[0]==NIL) goto geobodyCON1206;
	local[1]= local[0];
	local[2]= fqv[36];
	ctx->vsp=local+3;
	w=(pointer)EQ(ctx,2,local+1); /*eql*/
	if (w==NIL) goto geobodyCON1208;
	local[1]= fqv[37];
	goto geobodyCON1207;
geobodyCON1208:
	local[1]= local[0];
	local[2]= fqv[38];
	ctx->vsp=local+3;
	w=(pointer)EQ(ctx,2,local+1); /*eql*/
	if (w==NIL) goto geobodyCON1209;
	local[1]= fqv[39];
	goto geobodyCON1207;
geobodyCON1209:
	local[1]= local[0];
	local[2]= fqv[40];
	ctx->vsp=local+3;
	w=(pointer)EQ(ctx,2,local+1); /*eql*/
	if (w==NIL) goto geobodyCON1210;
	local[1]= fqv[41];
	goto geobodyCON1207;
geobodyCON1210:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)VNORMALIZE(ctx,1,local+1); /*normalize-vector*/
	local[1]= w;
	goto geobodyCON1207;
geobodyCON1211:
	local[1]= NIL;
geobodyCON1207:
	local[0] = local[1];
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[12];
geobodyWHL1212:
	if (local[2]==NIL) goto geobodyWHX1213;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= argv[2];
	local[4]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	local[4]= local[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)VINNERPRODUCT(ctx,2,local+4); /*v.*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,2,local+3); /*scale*/
	local[3]= w;
	local[4]= local[1];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)VPLUS(ctx,3,local+3); /*v+*/
	goto geobodyWHL1212;
geobodyWHX1213:
	local[3]= NIL;
geobodyBLK1214:
	w = NIL;
	local[1]= w;
	goto geobodyCON1205;
geobodyCON1206:
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[12];
geobodyWHL1216:
	if (local[2]==NIL) goto geobodyWHX1217;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= argv[2];
	local[4]= local[1];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,3,local+3); /*scale*/
	goto geobodyWHL1216;
geobodyWHX1217:
	local[3]= NIL;
geobodyBLK1218:
	w = NIL;
	local[1]= w;
	goto geobodyCON1205;
geobodyCON1215:
	local[1]= NIL;
geobodyCON1205:
	local[1]= argv[0];
	local[2]= fqv[33];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = argv[0];
	local[0]= w;
geobodyBLK1202:
	ctx->vsp=local; return(local[0]);}

/*:faces-intersect-with-point-vector*/
static pointer geobodyM1219faceset_faces_intersect_with_point_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	w = argv[3];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[42],w);
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[0]->c.obj.iv[9];
geobodyWHL1221:
	if (local[6]==NIL) goto geobodyWHX1222;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[5];
	local[8]= fqv[43];
	local[9]= argv[2];
	local[10]= loadglobal(fqv[42]);
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[4] = w;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	if (fqv[44]!=local[7]) goto geobodyIF1224;
	local[7]= local[5];
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	w = local[3];
	ctx->vsp=local+8;
	local[3] = cons(ctx,local[7],w);
	local[7]= local[3];
	goto geobodyIF1225;
geobodyIF1224:
	local[7]= NIL;
geobodyIF1225:
	goto geobodyWHL1221;
geobodyWHX1222:
	local[7]= NIL;
geobodyBLK1223:
	w = NIL;
	w = local[3];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
geobodyBLK1220:
	ctx->vsp=local; return(local[0]);}

/*:distance*/
static pointer geobodyM1226faceset_distance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[2];
	local[4]= loadglobal(fqv[45]);
	ctx->vsp=local+5;
	w=(pointer)DERIVEDP(ctx,2,local+3); /*derivedp*/
	if (w==NIL) goto geobodyCON1229;
	local[0] = makeflt(9.9999999999999973840965e+29);
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[9];
geobodyWHL1230:
	if (local[4]==NIL) goto geobodyWHX1231;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3];
	local[6]= fqv[46];
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[2] = w;
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)ABS(ctx,1,local+5); /*abs*/
	local[5]= w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)ABS(ctx,1,local+6); /*abs*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LESSP(ctx,2,local+5); /*<*/
	if (w==NIL) goto geobodyIF1233;
	local[0] = local[2];
	local[1] = local[3];
	local[5]= local[1];
	goto geobodyIF1234;
geobodyIF1233:
	local[5]= NIL;
geobodyIF1234:
	goto geobodyWHL1230;
geobodyWHX1231:
	local[5]= NIL;
geobodyBLK1232:
	w = NIL;
	local[3]= w;
	goto geobodyCON1228;
geobodyCON1229:
	local[3]= argv[2];
	local[4]= loadglobal(fqv[47]);
	ctx->vsp=local+5;
	w=(pointer)DERIVEDP(ctx,2,local+3); /*derivedp*/
	if (w==NIL) goto geobodyCON1235;
	local[3]= argv[2];
	local[4]= fqv[46];
	w=argv[0]->c.obj.iv[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[0] = w;
	w=argv[0]->c.obj.iv[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.car;
	local[3]= NIL;
	w=argv[0]->c.obj.iv[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
geobodyWHL1236:
	if (local[4]==NIL) goto geobodyWHX1237;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= argv[2];
	local[6]= fqv[46];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[2] = w;
	local[5]= local[2];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)LESSP(ctx,2,local+5); /*<*/
	if (w==NIL) goto geobodyIF1239;
	local[0] = local[2];
	local[1] = local[3];
	local[5]= local[1];
	goto geobodyIF1240;
geobodyIF1239:
	local[5]= NIL;
geobodyIF1240:
	goto geobodyWHL1236;
geobodyWHX1237:
	local[5]= NIL;
geobodyBLK1238:
	w = NIL;
	local[3]= w;
	goto geobodyCON1228;
geobodyCON1235:
	local[3]= NIL;
geobodyCON1228:
	local[3]= local[0];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[8])(ctx,2,local+3,&ftab[8],fqv[48]); /*values*/
	local[0]= w;
geobodyBLK1227:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer geobodyM1241faceset_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
geobodyRST1243:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[49], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto geobodyKEY1244;
	local[1] = NIL;
geobodyKEY1244:
	if (n & (1<<1)) goto geobodyKEY1245;
	local[2] = NIL;
geobodyKEY1245:
	if (n & (1<<2)) goto geobodyKEY1246;
	local[3] = NIL;
geobodyKEY1246:
	if (n & (1<<3)) goto geobodyKEY1247;
	local[4] = NIL;
geobodyKEY1247:
	if (n & (1<<4)) goto geobodyKEY1248;
	local[5] = NIL;
geobodyKEY1248:
	if (n & (1<<5)) goto geobodyKEY1249;
	local[6] = NIL;
geobodyKEY1249:
	if (local[1]==NIL) goto geobodyIF1250;
	argv[0]->c.obj.iv[9] = local[1];
	if (local[2]!=NIL) goto geobodyIF1252;
	local[7]= (pointer)get_sym_func(fqv[13]);
	local[8]= local[1];
	local[9]= fqv[23];
	ctx->vsp=local+10;
	w=(*ftab[1])(ctx,2,local+8,&ftab[1],fqv[15]); /*send-all*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,2,local+7); /*apply*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,1,local+7,&ftab[9],fqv[50]); /*remove-duplicates*/
	argv[0]->c.obj.iv[10] = w;
	local[7]= argv[0]->c.obj.iv[10];
	goto geobodyIF1253;
geobodyIF1252:
	local[7]= NIL;
geobodyIF1253:
	if (local[3]!=NIL) goto geobodyIF1254;
	local[7]= (pointer)get_sym_func(fqv[13]);
	local[8]= local[1];
	local[9]= fqv[51];
	ctx->vsp=local+10;
	w=(*ftab[1])(ctx,2,local+8,&ftab[1],fqv[15]); /*send-all*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,2,local+7); /*apply*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,1,local+7,&ftab[9],fqv[50]); /*remove-duplicates*/
	argv[0]->c.obj.iv[11] = w;
	local[7]= argv[0]->c.obj.iv[11];
	goto geobodyIF1255;
geobodyIF1254:
	local[7]= NIL;
geobodyIF1255:
	goto geobodyIF1251;
geobodyIF1250:
	local[7]= NIL;
geobodyIF1251:
	local[7]= (pointer)get_sym_func(fqv[52]);
	local[8]= argv[0];
	local[9]= *(ovafptr(argv[1],fqv[53]));
	local[10]= fqv[32];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)APPLY(ctx,5,local+7); /*apply*/
	if (local[2]==NIL) goto geobodyIF1256;
	argv[0]->c.obj.iv[10] = local[2];
	local[7]= argv[0]->c.obj.iv[10];
	goto geobodyIF1257;
geobodyIF1256:
	local[7]= NIL;
geobodyIF1257:
	if (local[3]==NIL) goto geobodyIF1258;
	argv[0]->c.obj.iv[11] = local[3];
	local[7]= argv[0]->c.obj.iv[11];
	goto geobodyIF1259;
geobodyIF1258:
	local[7]= NIL;
geobodyIF1259:
	local[7]= loadglobal(fqv[54]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[32];
	local[10]= argv[0]->c.obj.iv[11];
	local[11]= loadglobal(fqv[29]);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	w = local[7];
	argv[0]->c.obj.iv[8] = w;
	if (argv[0]->c.obj.iv[12]!=NIL) goto geobodyIF1260;
	local[7]= NIL;
	goto geobodyIF1261;
geobodyIF1260:
	local[7]= NIL;
geobodyIF1261:
	local[7]= (pointer)get_sym_func(fqv[55]);
	local[8]= argv[0]->c.obj.iv[11];
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	argv[0]->c.obj.iv[12] = w;
	if (local[4]==NIL) goto geobodyIF1262;
	local[7]= argv[0];
	local[8]= local[4];
	local[9]= fqv[10];
	ctx->vsp=local+10;
	w=(pointer)PUTPROP(ctx,3,local+7); /*putprop*/
	local[7]= w;
	goto geobodyIF1263;
geobodyIF1262:
	local[7]= NIL;
geobodyIF1263:
	if (local[5]==NIL) goto geobodyIF1264;
	local[7]= argv[0];
	local[8]= local[5];
	local[9]= fqv[11];
	ctx->vsp=local+10;
	w=(pointer)PUTPROP(ctx,3,local+7); /*putprop*/
	local[7]= w;
	goto geobodyIF1265;
geobodyIF1264:
	local[7]= NIL;
geobodyIF1265:
	if (local[6]==NIL) goto geobodyIF1266;
	local[7]= argv[0];
	local[8]= local[6];
	local[9]= fqv[12];
	ctx->vsp=local+10;
	w=(pointer)PUTPROP(ctx,3,local+7); /*putprop*/
	local[7]= w;
	goto geobodyIF1267;
geobodyIF1266:
	local[7]= NIL;
geobodyIF1267:
	w = argv[0];
	local[0]= w;
geobodyBLK1242:
	ctx->vsp=local; return(local[0]);}

/*:translate-vertices*/
static pointer geobodyM1268body_translate_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[53]));
	local[2]= fqv[56];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SENDMESSAGE(ctx,4,local+0); /*send-message*/
	local[0]= argv[0]->c.obj.iv[15];
	local[1]= fqv[56];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	w = argv[0];
	local[0]= w;
geobodyBLK1269:
	ctx->vsp=local; return(local[0]);}

/*:rotate-vertices*/
static pointer geobodyM1270body_rotate_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[53]));
	local[2]= fqv[57];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,5,local+0); /*send-message*/
	local[0]= argv[0]->c.obj.iv[15];
	local[1]= fqv[57];
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	w = argv[0];
	local[0]= w;
geobodyBLK1271:
	ctx->vsp=local; return(local[0]);}

/*:magnify*/
static pointer geobodyM1272body_magnify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geobodyENT1275;}
	local[0]= NIL;
geobodyENT1275:
geobodyENT1274:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[53]));
	local[3]= fqv[58];
	local[4]= argv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SENDMESSAGE(ctx,5,local+1); /*send-message*/
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= fqv[58];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)EUSFLOAT(ctx,1,local+3); /*float*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,3,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)NCONC(ctx,2,local+1); /*nconc*/
	w = argv[0];
	local[0]= w;
geobodyBLK1273:
	ctx->vsp=local; return(local[0]);}

/*:euler*/
static pointer geobodyM1276body_euler(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[11];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[14];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= local[1];
	local[5]= makeint(-(intval(local[2])));
	local[6]= makeint(-(intval(local[0])));
	local[7]= makeint((eusinteger_t)2L);
	w = local[3];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	w = (pointer)((eusinteger_t)local[7] + (eusinteger_t)w);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	w = (pointer)((eusinteger_t)local[6] + (eusinteger_t)w);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	w = (pointer)((eusinteger_t)local[5] + (eusinteger_t)w);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[4]= (pointer)((eusinteger_t)local[4] + (eusinteger_t)w);
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[0]= w;
geobodyBLK1277:
	ctx->vsp=local; return(local[0]);}

/*:perimeter*/
static pointer geobodyM1278body_perimeter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= (pointer)get_sym_func(fqv[59]);
	local[1]= argv[0]->c.obj.iv[10];
	local[2]= fqv[60];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[15]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPLY(ctx,2,local+0); /*apply*/
	local[0]= w;
geobodyBLK1279:
	ctx->vsp=local; return(local[0]);}

/*:volume*/
static pointer geobodyM1280body_volume(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geobodyENT1283;}
	local[0]= fqv[61];
geobodyENT1283:
geobodyENT1282:
	if (n>3) maerror();
	local[1]= (pointer)get_sym_func(fqv[59]);
	local[2]= argv[0]->c.obj.iv[9];
	local[3]= fqv[62];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,3,local+2,&ftab[1],fqv[15]); /*send-all*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	local[0]= w;
geobodyBLK1281:
	ctx->vsp=local; return(local[0]);}

/*:centroid*/
static pointer geobodyM1284body_centroid(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geobodyENT1287;}
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
geobodyENT1287:
geobodyENT1286:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[9];
	local[2]= fqv[63];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,3,local+1,&ftab[1],fqv[15]); /*send-all*/
	local[1]= w;
	local[2]= (pointer)get_sym_func(fqv[59]);
	local[3]= (pointer)get_sym_func(fqv[64]);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,2,local+2); /*apply*/
	local[2]= w;
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,geobodyCLO1288,env,argv,local);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	local[5]= NIL;
	local[6]= local[3];
geobodyWHL1289:
	if (local[6]==NIL) goto geobodyWHX1290;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[5];
	local[8]= local[4];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)VPLUS(ctx,3,local+7); /*v+*/
	goto geobodyWHL1289;
geobodyWHX1290:
	local[7]= NIL;
geobodyBLK1291:
	w = NIL;
	local[5]= makeflt(1.0000000000000000000000e+00);
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= local[4];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)SCALEVEC(ctx,3,local+5); /*scale*/
	w = local[4];
	local[0]= w;
geobodyBLK1285:
	ctx->vsp=local; return(local[0]);}

/*:world-centroid*/
static pointer geobodyM1292body_world_centroid(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[65];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[66];
	local[2]= argv[0];
	local[3]= fqv[63];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
geobodyBLK1293:
	ctx->vsp=local; return(local[0]);}

/*:area*/
static pointer geobodyM1294body_area(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= (pointer)get_sym_func(fqv[59]);
	local[1]= argv[0]->c.obj.iv[9];
	local[2]= fqv[67];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[15]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPLY(ctx,2,local+0); /*apply*/
	local[0]= w;
geobodyBLK1295:
	ctx->vsp=local; return(local[0]);}

/*:extream-point*/
static pointer geobodyM1296body_extream_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w=argv[0]->c.obj.iv[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[2];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)VINNERPRODUCT(ctx,2,local+1); /*v.*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	w=argv[0]->c.obj.iv[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
geobodyWHL1298:
	if (local[4]==NIL) goto geobodyWHX1299;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= argv[2];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)VINNERPRODUCT(ctx,2,local+5); /*v.*/
	local[2] = w;
	local[5]= local[2];
	{ double left,right;
		right=fltval(local[1]); left=fltval(local[5]);
	if (left <= right) goto geobodyIF1301;}
	local[1] = local[2];
	local[0] = local[3];
	local[5]= local[0];
	goto geobodyIF1302;
geobodyIF1301:
	local[5]= NIL;
geobodyIF1302:
	goto geobodyWHL1298;
geobodyWHX1299:
	local[5]= NIL;
geobodyBLK1300:
	w = NIL;
	w = local[0];
	local[0]= w;
geobodyBLK1297:
	ctx->vsp=local; return(local[0]);}

/*:length*/
static pointer geobodyM1303body_length(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0];
	local[2]= fqv[68];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VINNERPRODUCT(ctx,2,local+0); /*v.*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[0];
	local[3]= fqv[68];
	local[4]= makeflt(-1.0000000000000000000000e+00);
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VINNERPRODUCT(ctx,2,local+1); /*v.*/
	{ double x,y;
		y=fltval(w); x=fltval(local[0]);
		local[0]=(makeflt(x - y));}
	w = local[0];
	local[0]= w;
geobodyBLK1304:
	ctx->vsp=local; return(local[0]);}

/*:supporting-faces*/
static pointer geobodyM1305body_supporting_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geobodyENT1308;}
	local[0]= makeflt(0.0000000000000000000000e+00);
	local[1]= makeflt(0.0000000000000000000000e+00);
	local[2]= makeflt(-1.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*floatvector*/
	local[0]= w;
geobodyENT1308:
geobodyENT1307:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[69];
	local[3]= argv[0];
	local[4]= fqv[63];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
geobodyBLK1306:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyCLO1288(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= (pointer)get_sym_func(fqv[70]);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)APPLY(ctx,2,local+0); /*apply*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:possibly-interfering-faces*/
static pointer geobodyM1309body_possibly_interfering_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,geobodyCLO1311,env,argv,local);
	local[1]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
geobodyBLK1310:
	ctx->vsp=local; return(local[0]);}

/*:possibly-interfering-edges*/
static pointer geobodyM1312body_possibly_interfering_edges(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,geobodyCLO1314,env,argv,local);
	local[1]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
geobodyBLK1313:
	ctx->vsp=local; return(local[0]);}

/*:intersect-face*/
static pointer geobodyM1315body_intersect_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[9];
geobodyWHL1317:
	if (local[1]==NIL) goto geobodyWHX1318;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= fqv[71];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	if (w!=NIL) goto geobodyOR1322;
	local[2]= argv[2];
	local[3]= fqv[71];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	if (w!=NIL) goto geobodyOR1322;
	goto geobodyIF1320;
geobodyOR1322:
	w = T;
	ctx->vsp=local+2;
	local[0]=w;
	goto geobodyBLK1316;
	goto geobodyIF1321;
geobodyIF1320:
	local[2]= NIL;
geobodyIF1321:
	goto geobodyWHL1317;
geobodyWHX1318:
	local[2]= NIL;
geobodyBLK1319:
	w = NIL;
	w = NIL;
	local[0]= w;
geobodyBLK1316:
	ctx->vsp=local; return(local[0]);}

/*:intersectp*/
static pointer geobodyM1323body_intersectp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= fqv[27];
	local[2]= argv[2];
	local[3]= fqv[28];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	if (local[0]==NIL) goto geobodyIF1325;
	local[3]= argv[0];
	local[4]= fqv[72];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[1] = w;
	local[3]= argv[2];
	local[4]= fqv[72];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[2] = w;
	local[3]= NIL;
	local[4]= local[1];
geobodyWHL1327:
	if (local[4]==NIL) goto geobodyWHX1328;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= NIL;
	local[6]= local[2];
geobodyWHL1330:
	if (local[6]==NIL) goto geobodyWHX1331;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[3];
	local[8]= fqv[28];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= fqv[27];
	local[9]= local[5];
	local[10]= fqv[28];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[0] = w;
	local[7]= local[3];
	local[8]= fqv[71];
	local[9]= local[5];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	if (w!=NIL) goto geobodyOR1335;
	local[7]= local[5];
	local[8]= fqv[71];
	local[9]= local[3];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	if (w!=NIL) goto geobodyOR1335;
	goto geobodyIF1333;
geobodyOR1335:
	w = T;
	ctx->vsp=local+7;
	local[0]=w;
	goto geobodyBLK1324;
	goto geobodyIF1334;
geobodyIF1333:
	local[7]= NIL;
geobodyIF1334:
	goto geobodyWHL1330;
geobodyWHX1331:
	local[7]= NIL;
geobodyBLK1332:
	w = NIL;
	goto geobodyWHL1327;
geobodyWHX1328:
	local[5]= NIL;
geobodyBLK1329:
	w = NIL;
	local[3]= w;
	goto geobodyIF1326;
geobodyIF1325:
	local[3]= NIL;
geobodyIF1326:
	w = local[3];
	local[0]= w;
geobodyBLK1324:
	ctx->vsp=local; return(local[0]);}

/*:intersectp2*/
static pointer geobodyM1336body_intersectp2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geobodyENT1339;}
	local[0]= loadglobal(fqv[73]);
geobodyENT1339:
geobodyENT1338:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[74];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	if (local[1]==NIL) goto geobodyIF1340;
	local[10]= argv[0];
	local[11]= fqv[72];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[2] = w;
	local[10]= argv[2];
	local[11]= fqv[72];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[3] = w;
	local[10]= argv[0];
	local[11]= fqv[75];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[4] = w;
	local[10]= argv[2];
	local[11]= fqv[75];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[5] = w;
	local[10]= NIL;
	local[11]= local[2];
geobodyWHL1342:
	if (local[11]==NIL) goto geobodyWHX1343;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= NIL;
	local[13]= local[5];
geobodyWHL1345:
	if (local[13]==NIL) goto geobodyWHX1346;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13] = (w)->c.cons.cdr;
	w = local[14];
	local[12] = w;
	local[14]= local[10];
	local[15]= fqv[76];
	local[16]= local[12];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	if (w==NIL) goto geobodyCON1349;
	if (local[8]!=NIL) goto geobodyIF1350;
	local[14]= NIL;
	local[15]= local[10];
	local[16]= fqv[23];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
geobodyWHL1352:
	if (local[15]==NIL) goto geobodyWHX1353;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.cdr;
	w = local[16];
	local[14] = w;
	local[16]= local[14];
	local[17]= fqv[77];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,3,local+16); /*send*/
	if (!iscons(w)) goto geobodyIF1355;
	local[16]= local[10];
	local[17]= fqv[78];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	local[17]= makeflt(1.0000000000000000000000e+00);
	local[18]= local[16];
	local[19]= local[12]->c.obj.iv[3];
	local[20]= fqv[78];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,2,local+19); /*send*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)VINNERPRODUCT(ctx,2,local+18); /*v.*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[10])(ctx,2,local+17,&ftab[10],fqv[79]); /*eps=*/
	if (w!=NIL) goto geobodyOR1359;
	local[17]= makeflt(1.0000000000000000000000e+00);
	local[18]= local[16];
	local[19]= local[12]->c.obj.iv[4];
	local[20]= fqv[78];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,2,local+19); /*send*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)VINNERPRODUCT(ctx,2,local+18); /*v.*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[10])(ctx,2,local+17,&ftab[10],fqv[79]); /*eps=*/
	if (w!=NIL) goto geobodyOR1359;
	goto geobodyIF1357;
geobodyOR1359:
	w = fqv[80];
	ctx->vsp=local+17;
	local[0]=w;
	goto geobodyBLK1337;
	goto geobodyIF1358;
geobodyIF1357:
	local[8] = fqv[81];
	w = local[8];
	ctx->vsp=local+17;
	local[16]=w;
	goto geobodyBLK1354;
geobodyIF1358:
	w = local[17];
	local[16]= w;
	goto geobodyIF1356;
geobodyIF1355:
	local[16]= NIL;
geobodyIF1356:
	goto geobodyWHL1352;
geobodyWHX1353:
	local[16]= NIL;
geobodyBLK1354:
	w = NIL;
	local[14]= local[10];
	local[15]= fqv[82];
	local[16]= local[12]->c.obj.iv[1];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	if (w==NIL) goto geobodyIF1360;
	local[14]= local[10];
	local[15]= fqv[78];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	local[15]= makeflt(1.0000000000000000000000e+00);
	local[16]= local[14];
	local[17]= local[12]->c.obj.iv[3];
	local[18]= fqv[78];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)VINNERPRODUCT(ctx,2,local+16); /*v.*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(*ftab[10])(ctx,2,local+15,&ftab[10],fqv[79]); /*eps=*/
	if (w!=NIL) goto geobodyOR1364;
	local[15]= makeflt(1.0000000000000000000000e+00);
	local[16]= local[14];
	local[17]= local[12]->c.obj.iv[4];
	local[18]= fqv[78];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)VINNERPRODUCT(ctx,2,local+16); /*v.*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(*ftab[10])(ctx,2,local+15,&ftab[10],fqv[79]); /*eps=*/
	if (w!=NIL) goto geobodyOR1364;
	goto geobodyIF1362;
geobodyOR1364:
	w = fqv[80];
	ctx->vsp=local+15;
	local[0]=w;
	goto geobodyBLK1337;
	goto geobodyIF1363;
geobodyIF1362:
	local[8] = fqv[81];
	local[15]= local[8];
geobodyIF1363:
	w = local[15];
	local[14]= w;
	goto geobodyIF1361;
geobodyIF1360:
	local[14]= NIL;
geobodyIF1361:
	goto geobodyIF1351;
geobodyIF1350:
	local[14]= NIL;
geobodyIF1351:
	goto geobodyCON1348;
geobodyCON1349:
	local[14]= local[10];
	local[15]= fqv[27];
	local[16]= local[12]->c.obj.iv[1];
	local[17]= local[12]->c.obj.iv[2];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,4,local+14); /*send*/
	local[6] = w;
	local[14]= local[6];
	if (loadglobal(fqv[83])==local[14]) goto geobodyIF1366;
	local[14]= makeflt(0.0000000000000000000000e+00);
	local[15]= local[6];
	local[16]= makeflt(1.0000000000000000000000e+00);
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(*ftab[11])(ctx,4,local+14,&ftab[11],fqv[84]); /*eps-in-range*/
	if (w==NIL) goto geobodyIF1366;
	local[14]= local[12];
	local[15]= fqv[85];
	local[16]= local[6];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[7] = w;
	local[14]= local[10];
	local[15]= fqv[82];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[9] = w;
	local[14]= local[6];
	local[15]= makeflt(0.0000000000000000000000e+00);
	local[16]= local[0];
	ctx->vsp=local+17;
	w=(*ftab[10])(ctx,3,local+14,&ftab[10],fqv[79]); /*eps=*/
	if (w!=NIL) goto geobodyOR1370;
	local[14]= local[6];
	local[15]= makeflt(1.0000000000000000000000e+00);
	local[16]= local[0];
	ctx->vsp=local+17;
	w=(*ftab[10])(ctx,3,local+14,&ftab[10],fqv[79]); /*eps=*/
	if (w!=NIL) goto geobodyOR1370;
	goto geobodyCON1369;
geobodyOR1370:
	local[14]= local[9];
	local[15]= fqv[86];
	ctx->vsp=local+16;
	w=(*ftab[4])(ctx,2,local+14,&ftab[4],fqv[26]); /*member*/
	if (w==NIL) goto geobodyCON1369;
	local[8] = fqv[81];
	local[14]= local[8];
	goto geobodyCON1368;
geobodyCON1369:
	local[14]= local[9];
	local[15]= local[14];
	if (fqv[44]!=local[15]) goto geobodyIF1372;
	w = fqv[80];
	ctx->vsp=local+15;
	local[0]=w;
	goto geobodyBLK1337;
	goto geobodyIF1373;
geobodyIF1372:
	local[15]= local[14];
	if (fqv[87]!=local[15]) goto geobodyIF1374;
	local[8] = fqv[81];
	local[15]= local[8];
	goto geobodyIF1375;
geobodyIF1374:
	local[15]= NIL;
geobodyIF1375:
geobodyIF1373:
	w = local[15];
	local[14]= w;
	goto geobodyCON1368;
geobodyCON1371:
	local[14]= NIL;
geobodyCON1368:
	goto geobodyIF1367;
geobodyIF1366:
	local[14]= NIL;
geobodyIF1367:
	goto geobodyCON1348;
geobodyCON1365:
	local[14]= NIL;
geobodyCON1348:
	goto geobodyWHL1345;
geobodyWHX1346:
	local[14]= NIL;
geobodyBLK1347:
	w = NIL;
	goto geobodyWHL1342;
geobodyWHX1343:
	local[12]= NIL;
geobodyBLK1344:
	w = NIL;
	local[10]= NIL;
	local[11]= local[3];
geobodyWHL1376:
	if (local[11]==NIL) goto geobodyWHX1377;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= NIL;
	local[13]= local[5];
geobodyWHL1379:
	if (local[13]==NIL) goto geobodyWHX1380;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13] = (w)->c.cons.cdr;
	w = local[14];
	local[12] = w;
	local[14]= local[10];
	local[15]= fqv[76];
	local[16]= local[12];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	if (w==NIL) goto geobodyCON1383;
	if (local[8]!=NIL) goto geobodyIF1384;
	local[14]= NIL;
	local[15]= local[10];
	local[16]= fqv[23];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
geobodyWHL1386:
	if (local[15]==NIL) goto geobodyWHX1387;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.cdr;
	w = local[16];
	local[14] = w;
	local[16]= local[14];
	local[17]= fqv[77];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,3,local+16); /*send*/
	if (!iscons(w)) goto geobodyIF1389;
	local[16]= local[10];
	local[17]= fqv[78];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	local[17]= makeflt(1.0000000000000000000000e+00);
	local[18]= local[16];
	local[19]= local[12]->c.obj.iv[3];
	local[20]= fqv[78];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,2,local+19); /*send*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)VINNERPRODUCT(ctx,2,local+18); /*v.*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[10])(ctx,2,local+17,&ftab[10],fqv[79]); /*eps=*/
	if (w!=NIL) goto geobodyOR1393;
	local[17]= makeflt(1.0000000000000000000000e+00);
	local[18]= local[16];
	local[19]= local[12]->c.obj.iv[4];
	local[20]= fqv[78];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,2,local+19); /*send*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)VINNERPRODUCT(ctx,2,local+18); /*v.*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[10])(ctx,2,local+17,&ftab[10],fqv[79]); /*eps=*/
	if (w!=NIL) goto geobodyOR1393;
	goto geobodyIF1391;
geobodyOR1393:
	w = fqv[80];
	ctx->vsp=local+17;
	local[0]=w;
	goto geobodyBLK1337;
	goto geobodyIF1392;
geobodyIF1391:
	local[8] = fqv[81];
	w = local[8];
	ctx->vsp=local+17;
	local[16]=w;
	goto geobodyBLK1388;
geobodyIF1392:
	w = local[17];
	local[16]= w;
	goto geobodyIF1390;
geobodyIF1389:
	local[16]= NIL;
geobodyIF1390:
	goto geobodyWHL1386;
geobodyWHX1387:
	local[16]= NIL;
geobodyBLK1388:
	w = NIL;
	local[14]= local[10];
	local[15]= fqv[82];
	local[16]= local[12]->c.obj.iv[1];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	if (w==NIL) goto geobodyIF1394;
	local[14]= local[10];
	local[15]= fqv[78];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	local[15]= makeflt(1.0000000000000000000000e+00);
	local[16]= local[14];
	local[17]= local[12]->c.obj.iv[3];
	local[18]= fqv[78];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)VINNERPRODUCT(ctx,2,local+16); /*v.*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(*ftab[10])(ctx,2,local+15,&ftab[10],fqv[79]); /*eps=*/
	if (w!=NIL) goto geobodyOR1398;
	local[15]= makeflt(1.0000000000000000000000e+00);
	local[16]= local[14];
	local[17]= local[12]->c.obj.iv[4];
	local[18]= fqv[78];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)VINNERPRODUCT(ctx,2,local+16); /*v.*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(*ftab[10])(ctx,2,local+15,&ftab[10],fqv[79]); /*eps=*/
	if (w!=NIL) goto geobodyOR1398;
	goto geobodyIF1396;
geobodyOR1398:
	w = fqv[80];
	ctx->vsp=local+15;
	local[0]=w;
	goto geobodyBLK1337;
	goto geobodyIF1397;
geobodyIF1396:
	local[8] = fqv[81];
	local[15]= local[8];
geobodyIF1397:
	w = local[15];
	local[14]= w;
	goto geobodyIF1395;
geobodyIF1394:
	local[14]= NIL;
geobodyIF1395:
	goto geobodyIF1385;
geobodyIF1384:
	local[14]= NIL;
geobodyIF1385:
	goto geobodyCON1382;
geobodyCON1383:
	local[14]= local[10];
	local[15]= fqv[27];
	local[16]= local[12]->c.obj.iv[1];
	local[17]= local[12]->c.obj.iv[2];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,4,local+14); /*send*/
	local[6] = w;
	local[14]= local[6];
	if (loadglobal(fqv[83])==local[14]) goto geobodyIF1400;
	local[14]= makeflt(0.0000000000000000000000e+00);
	local[15]= local[6];
	local[16]= makeflt(1.0000000000000000000000e+00);
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(*ftab[11])(ctx,4,local+14,&ftab[11],fqv[84]); /*eps-in-range*/
	if (w==NIL) goto geobodyIF1400;
	local[14]= local[12];
	local[15]= fqv[85];
	local[16]= local[6];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[7] = w;
	local[14]= local[10];
	local[15]= fqv[82];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[9] = w;
	local[14]= local[6];
	local[15]= makeflt(0.0000000000000000000000e+00);
	local[16]= local[0];
	ctx->vsp=local+17;
	w=(*ftab[10])(ctx,3,local+14,&ftab[10],fqv[79]); /*eps=*/
	if (w!=NIL) goto geobodyOR1404;
	local[14]= local[6];
	local[15]= makeflt(1.0000000000000000000000e+00);
	local[16]= local[0];
	ctx->vsp=local+17;
	w=(*ftab[10])(ctx,3,local+14,&ftab[10],fqv[79]); /*eps=*/
	if (w!=NIL) goto geobodyOR1404;
	goto geobodyCON1403;
geobodyOR1404:
	local[14]= local[9];
	local[15]= fqv[88];
	ctx->vsp=local+16;
	w=(*ftab[4])(ctx,2,local+14,&ftab[4],fqv[26]); /*member*/
	if (w==NIL) goto geobodyCON1403;
	local[8] = fqv[81];
	local[14]= local[8];
	goto geobodyCON1402;
geobodyCON1403:
	local[14]= local[9];
	local[15]= local[14];
	if (fqv[44]!=local[15]) goto geobodyIF1406;
	w = fqv[80];
	ctx->vsp=local+15;
	local[0]=w;
	goto geobodyBLK1337;
	goto geobodyIF1407;
geobodyIF1406:
	local[15]= local[14];
	if (fqv[87]!=local[15]) goto geobodyIF1408;
	local[8] = fqv[81];
	local[15]= local[8];
	goto geobodyIF1409;
geobodyIF1408:
	local[15]= NIL;
geobodyIF1409:
geobodyIF1407:
	w = local[15];
	local[14]= w;
	goto geobodyCON1402;
geobodyCON1405:
	local[14]= NIL;
geobodyCON1402:
	goto geobodyIF1401;
geobodyIF1400:
	local[14]= NIL;
geobodyIF1401:
	goto geobodyCON1382;
geobodyCON1399:
	local[14]= NIL;
geobodyCON1382:
	goto geobodyWHL1379;
geobodyWHX1380:
	local[14]= NIL;
geobodyBLK1381:
	w = NIL;
	goto geobodyWHL1376;
geobodyWHX1377:
	local[12]= NIL;
geobodyBLK1378:
	w = NIL;
	local[10]= local[8];
	goto geobodyIF1341;
geobodyIF1340:
	local[10]= NIL;
geobodyIF1341:
	w = local[10];
	local[0]= w;
geobodyBLK1337:
	ctx->vsp=local; return(local[0]);}

/*:insidep*/
static pointer geobodyM1410body_insidep(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geobodyENT1413;}
	local[0]= loadglobal(fqv[89]);
geobodyENT1413:
geobodyENT1412:
	if (n>4) maerror();
	if (argv[0]->c.obj.iv[14]!=NIL) goto geobodyIF1414;
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= fqv[90];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	if (w!=NIL) goto geobodyIF1414;
	w = fqv[91];
	ctx->vsp=local+1;
	local[0]=w;
	goto geobodyBLK1411;
	goto geobodyIF1415;
geobodyIF1414:
	local[1]= NIL;
geobodyIF1415:
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	if (argv[0]->c.obj.iv[13]==NIL) goto geobodyCON1417;
	local[5]= NIL;
	local[6]= argv[0]->c.obj.iv[9];
geobodyWHL1418:
	if (local[6]==NIL) goto geobodyWHX1419;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[5];
	local[8]= fqv[92];
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[1] = w;
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ABS(ctx,1,local+7); /*abs*/
	local[7]= w;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto geobodyCON1422;
	local[7]= local[5];
	local[8]= fqv[82];
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[3] = w;
	local[7]= local[3];
	if (fqv[91]!=local[7]) goto geobodyIF1423;
	w = fqv[91];
	ctx->vsp=local+7;
	local[0]=w;
	goto geobodyBLK1411;
	goto geobodyIF1424;
geobodyIF1423:
	w = fqv[87];
	ctx->vsp=local+7;
	local[0]=w;
	goto geobodyBLK1411;
geobodyIF1424:
	goto geobodyCON1421;
geobodyCON1422:
	local[7]= local[1];
	local[8]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+9;
	w=(pointer)GREATERP(ctx,2,local+7); /*>*/
	if (w==NIL) goto geobodyCON1425;
	w = fqv[91];
	ctx->vsp=local+7;
	local[0]=w;
	goto geobodyBLK1411;
	goto geobodyCON1421;
geobodyCON1425:
	local[7]= NIL;
geobodyCON1421:
	goto geobodyWHL1418;
geobodyWHX1419:
	local[7]= NIL;
geobodyBLK1420:
	w = NIL;
	local[5]= fqv[44];
	goto geobodyCON1416;
geobodyCON1417:
	local[3] = NIL;
geobodyWHL1427:
	if (local[3]!=NIL) goto geobodyWHX1428;
	ctx->vsp=local+5;
	w=(*ftab[12])(ctx,0,local+5,&ftab[12],fqv[93]); /*random-normalized-vector*/
	local[2] = w;
	local[4] = makeint((eusinteger_t)0L);
	local[5]= NIL;
	local[6]= argv[0]->c.obj.iv[9];
geobodyWHL1430:
	if (local[6]==NIL) goto geobodyWHX1431;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[5];
	local[8]= fqv[92];
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ABS(ctx,1,local+7); /*abs*/
	local[7]= w;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto geobodyIF1433;
	local[7]= local[5];
	local[8]= fqv[82];
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	if (fqv[91]==local[7]) goto geobodyIF1433;
	w = fqv[87];
	ctx->vsp=local+7;
	local[0]=w;
	goto geobodyBLK1411;
	goto geobodyIF1434;
geobodyIF1433:
	local[7]= NIL;
geobodyIF1434:
	local[7]= local[5];
	local[8]= fqv[43];
	local[9]= argv[2];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[3] = w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= local[7];
	if (fqv[44]!=local[8]) goto geobodyIF1435;
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[4] = w;
	local[8]= local[4];
	goto geobodyIF1436;
geobodyIF1435:
	local[8]= local[7];
	if (fqv[91]!=local[8]) goto geobodyIF1437;
	local[8]= NIL;
	goto geobodyIF1438;
geobodyIF1437:
	if (T==NIL) goto geobodyIF1439;
	local[3] = NIL;
	w = NIL;
	ctx->vsp=local+8;
	local[7]=w;
	goto geobodyBLK1432;
	goto geobodyIF1440;
geobodyIF1439:
	local[8]= NIL;
geobodyIF1440:
geobodyIF1438:
geobodyIF1436:
	w = local[8];
	goto geobodyWHL1430;
geobodyWHX1431:
	local[7]= NIL;
geobodyBLK1432:
	w = NIL;
	goto geobodyWHL1427;
geobodyWHX1428:
	local[5]= NIL;
geobodyBLK1429:
	if (argv[0]->c.obj.iv[14]!=NIL) goto geobodyIF1441;
	local[5]= local[4];
	ctx->vsp=local+6;
	w=(*ftab[13])(ctx,1,local+5,&ftab[13],fqv[94]); /*oddp*/
	if (w==NIL) goto geobodyIF1443;
	local[5]= fqv[44];
	goto geobodyIF1444;
geobodyIF1443:
	local[5]= fqv[91];
geobodyIF1444:
	goto geobodyIF1442;
geobodyIF1441:
	local[5]= local[4];
	ctx->vsp=local+6;
	w=(*ftab[13])(ctx,1,local+5,&ftab[13],fqv[94]); /*oddp*/
	if (w==NIL) goto geobodyIF1445;
	local[5]= fqv[91];
	goto geobodyIF1446;
geobodyIF1445:
	local[5]= fqv[44];
geobodyIF1446:
geobodyIF1442:
	goto geobodyCON1416;
geobodyCON1426:
	local[5]= NIL;
geobodyCON1416:
	w = local[5];
	local[0]= w;
geobodyBLK1411:
	ctx->vsp=local; return(local[0]);}

/*:evert*/
static pointer geobodyM1447body_evert(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[9];
	local[1]= fqv[95];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[15]); /*send-all*/
	local[0]= argv[0]->c.obj.iv[10];
	local[1]= fqv[95];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[15]); /*send-all*/
	argv[0]->c.obj.iv[14] = ((argv[0]->c.obj.iv[14])==NIL?T:NIL);
	if (argv[0]->c.obj.iv[14]==NIL) goto geobodyCON1450;
	local[0]= loadglobal(fqv[54]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[96];
	local[3]= makeflt(-1.0000000000000000000000e+10);
	local[4]= makeflt(-1.0000000000000000000000e+10);
	local[5]= makeflt(-1.0000000000000000000000e+10);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= makeflt(1.0000000000000000000000e+10);
	local[5]= makeflt(1.0000000000000000000000e+10);
	local[6]= makeflt(1.0000000000000000000000e+10);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	argv[0]->c.obj.iv[8] = w;
	argv[0]->c.obj.iv[13] = NIL;
	local[0]= argv[0]->c.obj.iv[13];
	goto geobodyCON1449;
geobodyCON1450:
	local[0]= argv[0];
	local[1]= fqv[97];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[98];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto geobodyCON1449;
geobodyCON1451:
	local[0]= NIL;
geobodyCON1449:
	w = argv[0]->c.obj.iv[14];
	local[0]= w;
geobodyBLK1448:
	ctx->vsp=local; return(local[0]);}

/*:set-convexp*/
static pointer geobodyM1452body_set_convexp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,geobodyCLO1456,env,argv,local);
	local[1]= argv[0]->c.obj.iv[10];
	local[2]= fqv[99];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[15]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[14])(ctx,2,local+0,&ftab[14],fqv[100]); /*every*/
	if (w==NIL) goto geobodyIF1454;
	argv[0]->c.obj.iv[13] = T;
	local[0]= argv[0]->c.obj.iv[13];
	goto geobodyIF1455;
geobodyIF1454:
	local[0]= NIL;
geobodyIF1455:
	local[0]= argv[0]->c.obj.iv[9];
	local[1]= fqv[98];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[15]); /*send-all*/
	w = argv[0];
	local[0]= w;
geobodyBLK1453:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyCLO1311(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[101];
	local[2]= env->c.clo.env1[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	if (w==NIL) goto geobodyIF1457;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto geobodyIF1458;
geobodyIF1457:
	local[0]= NIL;
geobodyIF1458:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyCLO1314(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[101];
	local[2]= env->c.clo.env1[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	if (w==NIL) goto geobodyIF1459;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto geobodyIF1460;
geobodyIF1459:
	local[0]= NIL;
geobodyIF1460:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyCLO1456(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:get-face*/
static pointer geobodyM1461body_get_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geobodyENT1466;}
	local[0]= NIL;
geobodyENT1466:
	if (n>=4) { local[1]=(argv[3]); goto geobodyENT1465;}
	local[1]= NIL;
geobodyENT1465:
	if (n>=5) { local[2]=(argv[4]); goto geobodyENT1464;}
	local[2]= NIL;
geobodyENT1464:
geobodyENT1463:
	if (n>5) maerror();
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(*ftab[15])(ctx,1,local+7,&ftab[15],fqv[102]); /*bodyp*/
	if (w==NIL) goto geobodyCON1468;
	local[7]= NIL;
	local[8]= argv[0]->c.obj.iv[9];
geobodyWHL1469:
	if (local[8]==NIL) goto geobodyWHX1470;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= local[7];
	local[10]= fqv[103];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	if (local[0]!=local[9]) goto geobodyIF1472;
	local[9]= local[7];
	w = local[3];
	ctx->vsp=local+10;
	local[3] = cons(ctx,local[9],w);
	local[9]= local[3];
	goto geobodyIF1473;
geobodyIF1472:
	local[9]= NIL;
geobodyIF1473:
	goto geobodyWHL1469;
geobodyWHX1470:
	local[9]= NIL;
geobodyBLK1471:
	w = NIL;
	local[7]= w;
	goto geobodyCON1467;
geobodyCON1468:
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(*ftab[16])(ctx,1,local+7,&ftab[16],fqv[104]); /*keywordp*/
	if (w==NIL) goto geobodyCON1474;
	local[7]= NIL;
	local[8]= argv[0]->c.obj.iv[9];
geobodyWHL1475:
	if (local[8]==NIL) goto geobodyWHX1476;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= local[7];
	local[10]= fqv[105];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	if (local[0]!=local[9]) goto geobodyIF1478;
	local[9]= local[7];
	w = local[3];
	ctx->vsp=local+10;
	local[3] = cons(ctx,local[9],w);
	local[9]= local[3];
	goto geobodyIF1479;
geobodyIF1478:
	local[9]= NIL;
geobodyIF1479:
	goto geobodyWHL1475;
geobodyWHX1476:
	local[9]= NIL;
geobodyBLK1477:
	w = NIL;
	local[7]= w;
	goto geobodyCON1467;
geobodyCON1474:
	local[7]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+8;
	w=(pointer)COPYSEQ(ctx,1,local+7); /*copy-seq*/
	local[3] = w;
	local[7]= local[3];
	goto geobodyCON1467;
geobodyCON1480:
	local[7]= NIL;
geobodyCON1467:
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(*ftab[17])(ctx,1,local+7,&ftab[17],fqv[106]); /*facep*/
	if (w==NIL) goto geobodyCON1482;
	local[7]= NIL;
	local[8]= local[3];
geobodyWHL1483:
	if (local[8]==NIL) goto geobodyWHX1484;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= local[7];
	local[10]= fqv[107];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	if (local[1]!=local[9]) goto geobodyIF1486;
	local[9]= local[7];
	w = local[4];
	ctx->vsp=local+10;
	local[4] = cons(ctx,local[9],w);
	local[9]= local[4];
	goto geobodyIF1487;
geobodyIF1486:
	local[9]= NIL;
geobodyIF1487:
	goto geobodyWHL1483;
geobodyWHX1484:
	local[9]= NIL;
geobodyBLK1485:
	w = NIL;
	local[7]= w;
	goto geobodyCON1481;
geobodyCON1482:
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(*ftab[16])(ctx,1,local+7,&ftab[16],fqv[104]); /*keywordp*/
	if (w==NIL) goto geobodyCON1488;
	local[7]= NIL;
	local[8]= local[3];
geobodyWHL1489:
	if (local[8]==NIL) goto geobodyWHX1490;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= local[7];
	local[10]= fqv[108];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.car;
	local[9]= local[6];
	if (local[1]==local[9]) goto geobodyOR1494;
	local[9]= local[1];
	if (fqv[109]!=local[9]) goto geobodyAND1495;
	local[9]= local[6];
	local[10]= fqv[110];
	ctx->vsp=local+11;
	w=(*ftab[4])(ctx,2,local+9,&ftab[4],fqv[26]); /*member*/
	if (w==NIL) goto geobodyAND1495;
	goto geobodyOR1494;
geobodyAND1495:
	goto geobodyIF1492;
geobodyOR1494:
	local[9]= local[7];
	w = local[4];
	ctx->vsp=local+10;
	local[4] = cons(ctx,local[9],w);
	local[9]= local[4];
	goto geobodyIF1493;
geobodyIF1492:
	local[9]= NIL;
geobodyIF1493:
	goto geobodyWHL1489;
geobodyWHX1490:
	local[9]= NIL;
geobodyBLK1491:
	w = NIL;
	local[7]= w;
	goto geobodyCON1481;
geobodyCON1488:
	local[4] = local[3];
	local[7]= local[4];
	goto geobodyCON1481;
geobodyCON1496:
	local[7]= NIL;
geobodyCON1481:
	if (local[2]==NIL) goto geobodyCON1498;
	local[7]= NIL;
	local[8]= local[4];
geobodyWHL1499:
	if (local[8]==NIL) goto geobodyWHX1500;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= local[7];
	local[10]= fqv[108];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	if (local[2]!=local[9]) goto geobodyIF1502;
	local[9]= local[7];
	w = local[5];
	ctx->vsp=local+10;
	local[5] = cons(ctx,local[9],w);
	local[9]= local[5];
	goto geobodyIF1503;
geobodyIF1502:
	local[9]= NIL;
geobodyIF1503:
	goto geobodyWHL1499;
geobodyWHX1500:
	local[9]= NIL;
geobodyBLK1501:
	w = NIL;
	local[7]= local[5];
	goto geobodyCON1497;
geobodyCON1498:
	local[7]= local[4];
	goto geobodyCON1497;
geobodyCON1504:
	local[7]= NIL;
geobodyCON1497:
	w = local[7];
	local[0]= w;
geobodyBLK1462:
	ctx->vsp=local; return(local[0]);}

/*:primitive-body-p*/
static pointer geobodyM1505body_primitive_body_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= (iscons(w)?T:NIL);
	if (local[0]==NIL) goto geobodyAND1507;
	w=argv[0]->c.obj.iv[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(*ftab[16])(ctx,1,local+0,&ftab[16],fqv[104]); /*keywordp*/
	local[0]= w;
geobodyAND1507:
	w = local[0];
	local[0]= w;
geobodyBLK1506:
	ctx->vsp=local; return(local[0]);}

/*:primitive-bodies*/
static pointer geobodyM1508body_primitive_bodies(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geobodyENT1512;}
	local[0]= NIL;
geobodyENT1512:
	if (n>=4) { local[1]=(argv[3]); goto geobodyENT1511;}
	local[1]= NIL;
geobodyENT1511:
geobodyENT1510:
	if (n>4) maerror();
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,geobodyFLET1513,env,argv,local);
	local[3]= NIL;
	local[4]= local[0];
	local[5]= local[4];
	if (fqv[111]!=local[5]) goto geobodyIF1514;
	local[5]= argv[0];
	local[6]= fqv[112];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
	local[5]= local[3];
	goto geobodyIF1515;
geobodyIF1514:
	local[5]= local[4];
	if (fqv[113]!=local[5]) goto geobodyIF1516;
	local[5]= argv[0];
	local[6]= fqv[112];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
	local[5]= local[3];
	goto geobodyIF1517;
geobodyIF1516:
	if (T==NIL) goto geobodyIF1518;
	local[5]= argv[0];
	w = local[2];
	ctx->vsp=local+6;
	w=geobodyFLET1513(ctx,1,local+5,w);
	local[3] = w;
	local[5]= local[3];
	goto geobodyIF1519;
geobodyIF1518:
	local[5]= NIL;
geobodyIF1519:
geobodyIF1517:
geobodyIF1515:
	w = local[5];
	if (local[1]==NIL) goto geobodyCON1521;
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,geobodyCLO1522,env,argv,local);
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(*ftab[18])(ctx,2,local+4,&ftab[18],fqv[114]); /*collect-if*/
	local[4]= w;
	goto geobodyCON1520;
geobodyCON1521:
	local[4]= local[3];
	goto geobodyCON1520;
geobodyCON1523:
	local[4]= NIL;
geobodyCON1520:
	w = local[4];
	local[0]= w;
geobodyBLK1509:
	ctx->vsp=local; return(local[0]);}

/*:csg*/
static pointer geobodyM1524body_csg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geobodyENT1527;}
	local[0]= NIL;
geobodyENT1527:
geobodyENT1526:
	if (n>3) maerror();
	if (local[0]==NIL) goto geobodyIF1528;
	argv[0]->c.obj.iv[15] = local[0];
	local[1]= argv[0]->c.obj.iv[15];
	goto geobodyIF1529;
geobodyIF1528:
	local[1]= argv[0]->c.obj.iv[15];
geobodyIF1529:
	w = local[1];
	local[0]= w;
geobodyBLK1525:
	ctx->vsp=local; return(local[0]);}

/*:copy-csg*/
static pointer geobodyM1530body_copy_csg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,geobodyFLET1532,env,argv,local);
	local[1]= argv[0];
	local[2]= fqv[115];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (w==NIL) goto geobodyIF1533;
	local[1]= argv[0];
	w = local[0];
	ctx->vsp=local+2;
	w=geobodyFLET1532(ctx,1,local+1,w);
	local[1]= w;
	goto geobodyIF1534;
geobodyIF1533:
	local[1]= argv[0]->c.obj.iv[15];
	w = local[0];
	ctx->vsp=local+2;
	w=geobodyFLET1532(ctx,1,local+1,w);
	local[1]= w;
geobodyIF1534:
	w = local[1];
	local[0]= w;
geobodyBLK1531:
	ctx->vsp=local; return(local[0]);}

/*:body-type*/
static pointer geobodyM1535body_body_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[116];
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[26]); /*member*/
	if (w==NIL) goto geobodyIF1537;
	local[0]= fqv[117];
	w=argv[0]->c.obj.iv[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	goto geobodyIF1538;
geobodyIF1537:
	w=argv[0]->c.obj.iv[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
geobodyIF1538:
	w = local[0];
	local[0]= w;
geobodyBLK1536:
	ctx->vsp=local; return(local[0]);}

/*:creation-form*/
static pointer geobodyM1539body_creation_form(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,geobodyFLET1541,env,argv,local);
	local[1]= argv[0];
	local[2]= fqv[115];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (w==NIL) goto geobodyIF1542;
	local[1]= argv[0];
	w = local[0];
	ctx->vsp=local+2;
	w=geobodyFLET1541(ctx,1,local+1,w);
	local[1]= w;
	goto geobodyIF1543;
geobodyIF1542:
	local[1]= argv[0]->c.obj.iv[15];
	w = local[0];
	ctx->vsp=local+2;
	w=geobodyFLET1541(ctx,1,local+1,w);
	local[1]= w;
geobodyIF1543:
	w = local[1];
	local[0]= w;
geobodyBLK1540:
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer geobodyM1544body_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[53]));
	local[2]= fqv[118];
	local[3]= argv[2];
	local[4]= argv[0];
	local[5]= fqv[119];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,5,local+0); /*send-message*/
	local[0]= w;
geobodyBLK1545:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer geobodyM1546body_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
geobodyRST1548:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[120], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto geobodyKEY1549;
	local[1] = NIL;
geobodyKEY1549:
	if (n & (1<<1)) goto geobodyKEY1550;
	local[2] = NIL;
geobodyKEY1550:
	if (n & (1<<2)) goto geobodyKEY1551;
	local[3] = NIL;
geobodyKEY1551:
	local[4]= (pointer)get_sym_func(fqv[52]);
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[53]));
	local[7]= fqv[32];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,5,local+4); /*apply*/
	local[4]= argv[0]->c.obj.iv[10];
	local[5]= fqv[121];
	ctx->vsp=local+6;
	w=(*ftab[1])(ctx,2,local+4,&ftab[1],fqv[15]); /*send-all*/
	if (local[1]==NIL) goto geobodyIF1552;
	local[4]= argv[0]->c.obj.iv[10];
	local[5]= fqv[122];
	ctx->vsp=local+6;
	w=(*ftab[1])(ctx,2,local+4,&ftab[1],fqv[15]); /*send-all*/
	local[4]= w;
	goto geobodyIF1553;
geobodyIF1552:
	local[4]= NIL;
geobodyIF1553:
	local[4]= (pointer)get_sym_func(fqv[123]);
	local[5]= argv[0]->c.obj.iv[10];
	local[6]= fqv[99];
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,2,local+5,&ftab[1],fqv[15]); /*send-all*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[14])(ctx,2,local+4,&ftab[14],fqv[100]); /*every*/
	if (w==NIL) goto geobodyIF1554;
	argv[0]->c.obj.iv[13] = T;
	local[4]= argv[0]->c.obj.iv[13];
	goto geobodyIF1555;
geobodyIF1554:
	local[4]= NIL;
geobodyIF1555:
	if (argv[0]->c.obj.iv[11]==NIL) goto geobodyIF1556;
	if (argv[0]->c.obj.iv[9]==NIL) goto geobodyIF1556;
	local[4]= argv[0];
	local[5]= argv[0];
	local[6]= fqv[63];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[63];
	ctx->vsp=local+7;
	w=(pointer)PUTPROP(ctx,3,local+4); /*putprop*/
	local[4]= argv[0];
	local[5]= argv[0];
	local[6]= fqv[62];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[62];
	ctx->vsp=local+7;
	w=(pointer)PUTPROP(ctx,3,local+4); /*putprop*/
	local[4]= w;
	goto geobodyIF1557;
geobodyIF1556:
	local[4]= NIL;
geobodyIF1557:
	if (local[2]==NIL) goto geobodyIF1558;
	local[4]= argv[0]->c.obj.iv[9];
	local[5]= fqv[124];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,3,local+4,&ftab[1],fqv[15]); /*send-all*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	argv[0]->c.obj.iv[15] = w;
	local[4]= argv[0]->c.obj.iv[15];
	goto geobodyIF1559;
geobodyIF1558:
	local[4]= NIL;
geobodyIF1559:
	w = argv[0];
	local[0]= w;
geobodyBLK1547:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyFLET1513(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[19])(ctx,1,local+0,&ftab[19],fqv[125]); /*primitive-body-p*/
	if (w==NIL) goto geobodyCON1561;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto geobodyCON1560;
geobodyCON1561:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto geobodyCON1562;
	local[0]= env->c.clo.env2[2];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w==NIL) goto geobodyCON1564;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	goto geobodyCON1563;
geobodyCON1564:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	goto geobodyCON1563;
geobodyCON1565:
	local[1]= NIL;
geobodyCON1563:
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
	goto geobodyCON1560;
geobodyCON1562:
	local[0]= env->c.clo.env2[2];
	local[1]= argv[0];
	local[2]= fqv[126];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
	goto geobodyCON1560;
geobodyCON1566:
	local[0]= NIL;
geobodyCON1560:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyCLO1522(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[119];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w = env->c.clo.env2[1];
	if (!iscons(w)) goto geobodyIF1567;
	local[2]= local[1];
	local[3]= env->c.clo.env2[1];
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,2,local+2,&ftab[4],fqv[26]); /*member*/
	local[2]= w;
	goto geobodyIF1568;
geobodyIF1567:
	local[2]= env->c.clo.env2[1];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)EQ(ctx,2,local+2); /*eql*/
	local[2]= w;
geobodyIF1568:
	w = local[2];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyFLET1532(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto geobodyCON1570;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,geobodyCLO1571,env,argv,local);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	goto geobodyCON1569;
geobodyCON1570:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[15])(ctx,1,local+0,&ftab[15],fqv[102]); /*bodyp*/
	if (w==NIL) goto geobodyCON1572;
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
	local[4]= fqv[65];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= argv[0];
	local[4]= fqv[127];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[1] = w;
	if (local[1]==NIL) goto geobodyIF1573;
	local[3]= local[1];
	local[4]= fqv[128];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto geobodyIF1574;
geobodyIF1573:
	local[3]= NIL;
geobodyIF1574:
	local[3]= argv[0];
	local[4]= fqv[129];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[2] = w;
	local[3]= argv[0];
	local[4]= fqv[130];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)COPYOBJ(ctx,1,local+3); /*copy-object*/
	local[0] = w;
	if (local[1]==NIL) goto geobodyIF1575;
	local[3]= local[1];
	local[4]= fqv[131];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto geobodyIF1576;
geobodyIF1575:
	local[3]= NIL;
geobodyIF1576:
	local[3]= NIL;
	local[4]= local[2];
geobodyWHL1577:
	if (local[4]==NIL) goto geobodyWHX1578;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= argv[0];
	local[6]= fqv[131];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	goto geobodyWHL1577;
geobodyWHX1578:
	local[5]= NIL;
geobodyBLK1579:
	w = NIL;
	local[3]= local[0];
	local[4]= fqv[65];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= NIL;
	local[4]= local[0]->c.obj.iv[9];
geobodyWHL1580:
	if (local[4]==NIL) goto geobodyWHX1581;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3];
	local[6]= fqv[107];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	goto geobodyWHL1580;
geobodyWHX1581:
	local[5]= NIL;
geobodyBLK1582:
	w = NIL;
	local[3]= local[0];
	local[4]= argv[0];
	local[5]= fqv[132];
	ctx->vsp=local+6;
	w=(pointer)PUTPROP(ctx,3,local+3); /*putprop*/
	w = local[0];
	local[0]= w;
	goto geobodyCON1569;
geobodyCON1572:
	local[0]= NIL;
geobodyCON1569:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyCLO1571(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = env->c.clo.env0->c.clo.env2[0];
	ctx->vsp=local+1;
	w=geobodyFLET1532(ctx,1,local+0,w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyFLET1541(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto geobodyCON1584;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	if (fqv[59]!=local[0]) goto geobodyCON1586;
	local[0]= fqv[133];
	local[1]= env->c.clo.env2[0];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST_STAR(ctx,2,local+0); /*list**/
	local[0]= w;
	goto geobodyCON1585;
geobodyCON1586:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	if (fqv[134]!=local[0]) goto geobodyCON1587;
	local[0]= fqv[135];
	local[1]= env->c.clo.env2[0];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST_STAR(ctx,2,local+0); /*list**/
	local[0]= w;
	goto geobodyCON1585;
geobodyCON1587:
	local[0]= NIL;
geobodyCON1585:
	goto geobodyCON1583;
geobodyCON1584:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[15])(ctx,1,local+0,&ftab[15],fqv[102]); /*bodyp*/
	if (w==NIL) goto geobodyCON1588;
	local[0]= argv[0];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= local[1];
	if (fqv[136]!=local[2]) goto geobodyIF1589;
	local[2]= fqv[137];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	goto geobodyIF1590;
geobodyIF1589:
	local[2]= local[1];
	if (fqv[138]!=local[2]) goto geobodyIF1591;
	local[2]= fqv[139];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= fqv[140];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[20])(ctx,1,local+6,&ftab[20],fqv[141]); /*cdddr*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST_STAR(ctx,5,local+2); /*list**/
	local[2]= w;
	goto geobodyIF1592;
geobodyIF1591:
	if (T==NIL) goto geobodyIF1593;
	local[2]= fqv[142];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,2,local+2); /*error*/
	local[2]= w;
	goto geobodyIF1594;
geobodyIF1593:
	local[2]= NIL;
geobodyIF1594:
geobodyIF1592:
geobodyIF1590:
	w = local[2];
	local[0] = w;
	local[1]= local[0];
	local[2]= fqv[3];
	local[3]= argv[0];
	local[4]= fqv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPEND(ctx,2,local+1); /*append*/
	local[1]= fqv[8];
	local[2]= local[0];
	local[3]= fqv[143];
	local[4]= argv[0];
	local[5]= fqv[65];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[144];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
	goto geobodyCON1583;
geobodyCON1588:
	local[0]= NIL;
geobodyCON1583:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:replace-shape*/
static pointer geobodyM1595body_replace_shape(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[4];
geobodyWHL1597:
	if (local[1]==NIL) goto geobodyWHX1598;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= fqv[132];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	if (w==NIL) goto geobodyIF1600;
	local[2]= argv[0];
	local[3]= fqv[128];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto geobodyIF1601;
geobodyIF1600:
	local[2]= NIL;
geobodyIF1601:
	goto geobodyWHL1597;
geobodyWHX1598:
	local[2]= NIL;
geobodyBLK1599:
	w = NIL;
	argv[0]->c.obj.iv[9] = argv[2]->c.obj.iv[9];
	argv[0]->c.obj.iv[10] = argv[2]->c.obj.iv[10];
	argv[0]->c.obj.iv[11] = argv[2]->c.obj.iv[11];
	argv[0]->c.obj.iv[12] = argv[2]->c.obj.iv[12];
	argv[0]->c.obj.iv[8] = argv[2]->c.obj.iv[8];
	argv[0]->c.obj.iv[13] = argv[2]->c.obj.iv[13];
	argv[0]->c.obj.iv[15] = argv[2]->c.obj.iv[15];
	local[0]= argv[0];
	local[1]= NIL;
	local[2]= fqv[6];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= argv[0];
	local[1]= fqv[65];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[145];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[12];
geobodyWHL1602:
	if (local[1]==NIL) goto geobodyWHX1603;
	local[2]= local[1];
	local[3]= local[0];
	local[4]= fqv[66];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)RPLACA2(ctx,2,local+2); /*rplaca2*/
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	goto geobodyWHL1602;
geobodyWHX1603:
	local[2]= NIL;
geobodyBLK1604:
	w = local[2];
	local[0]= argv[0]->c.obj.iv[9];
	local[1]= fqv[124];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,3,local+0,&ftab[1],fqv[15]); /*send-all*/
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[146];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
geobodyWHL1605:
	if (local[1]==NIL) goto geobodyWHX1606;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= argv[0];
	local[3]= fqv[131];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	goto geobodyWHL1605;
geobodyWHX1606:
	local[2]= NIL;
geobodyBLK1607:
	w = NIL;
	w = argv[0];
	local[0]= w;
geobodyBLK1596:
	ctx->vsp=local; return(local[0]);}

/*:+*/
static pointer geobodyM1608body__(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
geobodyRST1610:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0];
	local[2]= fqv[147];
	local[3]= (pointer)get_sym_func(fqv[133]);
	local[4]= argv[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,3,local+3); /*apply*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
geobodyBLK1609:
	ctx->vsp=local; return(local[0]);}

/*:-*/
static pointer geobodyM1611body__(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
geobodyRST1613:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0];
	local[2]= fqv[147];
	local[3]= (pointer)get_sym_func(fqv[135]);
	local[4]= argv[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,3,local+3); /*apply*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
geobodyBLK1612:
	ctx->vsp=local; return(local[0]);}

/*:**/
static pointer geobodyM1614body__(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
geobodyRST1616:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0];
	local[2]= fqv[147];
	local[3]= (pointer)get_sym_func(fqv[148]);
	local[4]= argv[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,3,local+3); /*apply*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
geobodyBLK1615:
	ctx->vsp=local; return(local[0]);}

/*:primitive-groups*/
static pointer geobodyM1617body_primitive_groups(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,geobodyFLET1619,env,argv,local);
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,geobodyFLET1620,env,argv,local);
	local[2]= argv[0];
	local[3]= fqv[115];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	if (w==NIL) goto geobodyIF1621;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	goto geobodyIF1622;
geobodyIF1621:
	local[2]= argv[0]->c.obj.iv[15];
	w = local[0];
	ctx->vsp=local+3;
	w=geobodyFLET1619(ctx,1,local+2,w);
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[15];
	w = local[1];
	ctx->vsp=local+4;
	w=geobodyFLET1620(ctx,1,local+3,w);
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
geobodyIF1622:
	w = local[2];
	local[0]= w;
geobodyBLK1618:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyFLET1619(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto geobodyCON1624;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	if (fqv[59]!=local[0]) goto geobodyCON1626;
	local[0]= env->c.clo.env2[0];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
	goto geobodyCON1625;
geobodyCON1626:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	if (fqv[134]!=local[0]) goto geobodyCON1627;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[21])(ctx,1,local+0,&ftab[21],fqv[149]); /*caadr*/
	local[0]= w;
	w = env->c.clo.env2[0];
	ctx->vsp=local+1;
	w=geobodyFLET1619(ctx,1,local+0,w);
	local[0]= w;
	local[1]= env->c.clo.env2[1];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[22])(ctx,1,local+2,&ftab[22],fqv[150]); /*cdadr*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAN(ctx,2,local+1); /*mapcan*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	local[0]= w;
	goto geobodyCON1625;
geobodyCON1627:
	local[0]= NIL;
geobodyCON1625:
	goto geobodyCON1623;
geobodyCON1624:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[19])(ctx,1,local+0,&ftab[19],fqv[125]); /*primitive-body-p*/
	if (w==NIL) goto geobodyCON1628;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto geobodyCON1623;
geobodyCON1628:
	local[0]= NIL;
geobodyCON1623:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyFLET1620(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto geobodyIF1629;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	if (fqv[59]!=local[0]) goto geobodyCON1632;
	local[0]= env->c.clo.env2[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
	goto geobodyCON1631;
geobodyCON1632:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	if (fqv[134]!=local[0]) goto geobodyCON1633;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[21])(ctx,1,local+0,&ftab[21],fqv[149]); /*caadr*/
	local[0]= w;
	w = env->c.clo.env2[1];
	ctx->vsp=local+1;
	w=geobodyFLET1620(ctx,1,local+0,w);
	local[0]= w;
	local[1]= env->c.clo.env2[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[22])(ctx,1,local+2,&ftab[22],fqv[150]); /*cdadr*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAN(ctx,2,local+1); /*mapcan*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	local[0]= w;
	goto geobodyCON1631;
geobodyCON1633:
	local[0]= NIL;
geobodyCON1631:
	goto geobodyIF1630;
geobodyIF1629:
	local[0]= NIL;
geobodyIF1630:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:constraint*/
static pointer geobodyM1634body_constraint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[27];
	local[4]= argv[2];
	local[5]= fqv[28];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	if (w==NIL) goto geobodyIF1636;
	local[2]= argv[0];
	local[3]= fqv[151];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[152];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)NCONC(ctx,2,local+2); /*nconc*/
	local[0] = w;
	local[2]= argv[2];
	local[3]= fqv[151];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= fqv[152];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)NCONC(ctx,2,local+2); /*nconc*/
	local[1] = w;
	local[2]= loadglobal(fqv[153]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[32];
	local[5]= fqv[154];
	local[6]= argv[0];
	local[7]= fqv[155];
	local[8]= argv[2];
	local[9]= fqv[156];
	local[10]= local[0];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(*ftab[23])(ctx,2,local+10,&ftab[23],fqv[157]); /*contact-to-constraint*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,8,local+3); /*send*/
	w = local[2];
	local[2]= w;
	goto geobodyIF1637;
geobodyIF1636:
	local[2]= NIL;
geobodyIF1637:
	w = local[2];
	local[0]= w;
geobodyBLK1635:
	ctx->vsp=local; return(local[0]);}

/*:contact-vertices*/
static pointer geobodyM1638body_contact_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= fqv[27];
	local[2]= argv[2];
	local[3]= fqv[28];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	if (local[0]==NIL) goto geobodyIF1640;
	local[1]= argv[0];
	local[2]= fqv[158];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= fqv[159];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= local[1];
geobodyWHL1642:
	if (local[7]==NIL) goto geobodyWHX1643;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= NIL;
	local[9]= local[2];
geobodyWHL1645:
	if (local[9]==NIL) goto geobodyWHX1646;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[8];
	local[11]= fqv[160];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= w;
	if (fqv[91]==local[10]) goto geobodyIF1648;
	local[10]= loadglobal(fqv[161]);
	ctx->vsp=local+11;
	w=(pointer)INSTANTIATE(ctx,1,local+10); /*instantiate*/
	local[10]= w;
	local[11]= local[10];
	local[12]= fqv[32];
	local[13]= fqv[162];
	local[14]= local[6];
	local[15]= fqv[163];
	local[16]= local[8];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,6,local+11); /*send*/
	w = local[10];
	local[10]= w;
	w = local[3];
	ctx->vsp=local+11;
	local[3] = cons(ctx,local[10],w);
	w = local[3];
	ctx->vsp=local+10;
	local[10]=w;
	goto geobodyBLK1647;
	goto geobodyIF1649;
geobodyIF1648:
	local[10]= NIL;
geobodyIF1649:
	goto geobodyWHL1645;
geobodyWHX1646:
	local[10]= NIL;
geobodyBLK1647:
	w = NIL;
	goto geobodyWHL1642;
geobodyWHX1643:
	local[8]= NIL;
geobodyBLK1644:
	w = NIL;
	local[6]= NIL;
	local[7]= local[3];
geobodyWHL1650:
	if (local[7]==NIL) goto geobodyWHX1651;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= NIL;
	local[9]= argv[0]->c.obj.iv[10];
geobodyWHL1653:
	if (local[9]==NIL) goto geobodyWHX1654;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[6]->c.obj.iv[0];
	local[11]= local[8]->c.obj.iv[1];
	ctx->vsp=local+12;
	w=(pointer)EQUAL(ctx,2,local+10); /*equal*/
	if (w!=NIL) goto geobodyOR1658;
	local[10]= local[6]->c.obj.iv[0];
	local[11]= local[8]->c.obj.iv[2];
	ctx->vsp=local+12;
	w=(pointer)EQUAL(ctx,2,local+10); /*equal*/
	if (w!=NIL) goto geobodyOR1658;
	goto geobodyIF1656;
geobodyOR1658:
	local[10]= local[8];
	w = local[6]->c.obj.iv[3];
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= local[10];
	w = local[6];
	w->c.obj.iv[3] = local[11];
	goto geobodyIF1657;
geobodyIF1656:
	local[10]= NIL;
geobodyIF1657:
	goto geobodyWHL1653;
geobodyWHX1654:
	local[10]= NIL;
geobodyBLK1655:
	w = NIL;
	goto geobodyWHL1650;
geobodyWHX1651:
	local[8]= NIL;
geobodyBLK1652:
	w = NIL;
	local[6]= NIL;
	local[7]= local[3];
geobodyWHL1659:
	if (local[7]==NIL) goto geobodyWHX1660;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[6];
	local[9]= fqv[164];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	goto geobodyWHL1659;
geobodyWHX1660:
	local[8]= NIL;
geobodyBLK1661:
	w = NIL;
	w = local[3];
	local[1]= w;
	goto geobodyIF1641;
geobodyIF1640:
	local[1]= NIL;
geobodyIF1641:
	w = local[1];
	local[0]= w;
geobodyBLK1639:
	ctx->vsp=local; return(local[0]);}

/*:contact-edges*/
static pointer geobodyM1662body_contact_edges(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= fqv[27];
	local[2]= argv[2];
	local[3]= fqv[28];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	if (local[0]==NIL) goto geobodyIF1664;
	local[1]= argv[0];
	local[2]= fqv[165];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= fqv[159];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= local[1];
geobodyWHL1666:
	if (local[7]==NIL) goto geobodyWHX1667;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= NIL;
	local[9]= local[2];
geobodyWHL1669:
	if (local[9]==NIL) goto geobodyWHX1670;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[8];
	local[11]= fqv[166];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[3] = w;
	if (local[3]==NIL) goto geobodyIF1672;
	local[10]= local[3];
	local[11]= local[4];
	local[12]= fqv[167];
	ctx->vsp=local+13;
	local[13]= makeclosure(codevec,quotevec,geobodyCLO1674,env,argv,local);
	ctx->vsp=local+14;
	w=(*ftab[24])(ctx,4,local+10,&ftab[24],fqv[168]); /*find*/
	if (w!=NIL) goto geobodyIF1672;
	local[10]= local[6]->c.obj.iv[5];
	ctx->vsp=local+11;
	w=(*ftab[25])(ctx,1,local+10,&ftab[25],fqv[123]); /*plusp*/
	if (w==NIL) goto geobodyIF1675;
	local[10]= loadglobal(fqv[161]);
	ctx->vsp=local+11;
	w=(pointer)INSTANTIATE(ctx,1,local+10); /*instantiate*/
	local[10]= w;
	local[11]= local[10];
	local[12]= fqv[32];
	local[13]= fqv[162];
	local[14]= local[3];
	local[15]= fqv[163];
	local[16]= local[8];
	local[17]= fqv[169];
	local[18]= local[6];
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,1,local+18); /*list*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,1,local+18); /*list*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,8,local+11); /*send*/
	w = local[10];
	local[10]= w;
	w = local[4];
	ctx->vsp=local+11;
	local[4] = cons(ctx,local[10],w);
	local[10]= local[4];
	goto geobodyIF1676;
geobodyIF1675:
	local[10]= loadglobal(fqv[161]);
	ctx->vsp=local+11;
	w=(pointer)INSTANTIATE(ctx,1,local+10); /*instantiate*/
	local[10]= w;
	local[11]= local[10];
	local[12]= fqv[32];
	local[13]= fqv[162];
	local[14]= local[3];
	local[15]= fqv[163];
	local[16]= local[8];
	local[17]= fqv[169];
	local[18]= local[6]->c.obj.iv[3];
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,1,local+18); /*list*/
	local[18]= w;
	local[19]= local[6]->c.obj.iv[4];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,2,local+18); /*list*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,8,local+11); /*send*/
	w = local[10];
	local[10]= w;
	w = local[4];
	ctx->vsp=local+11;
	local[4] = cons(ctx,local[10],w);
	local[10]= local[4];
geobodyIF1676:
	goto geobodyIF1673;
geobodyIF1672:
	local[10]= NIL;
geobodyIF1673:
	goto geobodyWHL1669;
geobodyWHX1670:
	local[10]= NIL;
geobodyBLK1671:
	w = NIL;
	goto geobodyWHL1666;
geobodyWHX1667:
	local[8]= NIL;
geobodyBLK1668:
	w = NIL;
	w = local[4];
	local[1]= w;
	goto geobodyIF1665;
geobodyIF1664:
	local[1]= NIL;
geobodyIF1665:
	w = local[1];
	local[0]= w;
geobodyBLK1663:
	ctx->vsp=local; return(local[0]);}

/*:possibly-contacting-vertices*/
static pointer geobodyM1677body_possibly_contacting_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,geobodyCLO1679,env,argv,local);
	local[1]= argv[0]->c.obj.iv[11];
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
geobodyBLK1678:
	ctx->vsp=local; return(local[0]);}

/*:possibly-contacting-edges*/
static pointer geobodyM1680body_possibly_contacting_edges(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,geobodyCLO1682,env,argv,local);
	local[1]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
geobodyBLK1681:
	ctx->vsp=local; return(local[0]);}

/*:possibly-contacting-faces*/
static pointer geobodyM1683body_possibly_contacting_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,geobodyCLO1685,env,argv,local);
	local[1]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
geobodyBLK1684:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyCLO1674(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1]->c.obj.iv[0];
	local[2]= loadglobal(fqv[29]);
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,3,local+0,&ftab[26],fqv[170]); /*eps-v=*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyCLO1679(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[2];
	local[1]= fqv[90];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	if (w==NIL) goto geobodyIF1686;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto geobodyIF1687;
geobodyIF1686:
	local[0]= NIL;
geobodyIF1687:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyCLO1682(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[101];
	local[2]= env->c.clo.env1[2];
	local[3]= loadglobal(fqv[29]);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	if (w==NIL) goto geobodyIF1688;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto geobodyIF1689;
geobodyIF1688:
	local[0]= NIL;
geobodyIF1689:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geobodyCLO1685(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[101];
	local[2]= env->c.clo.env1[2];
	local[3]= loadglobal(fqv[29]);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	if (w==NIL) goto geobodyIF1690;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto geobodyIF1691;
geobodyIF1690:
	local[0]= NIL;
geobodyIF1691:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:radius*/
static pointer geobodyM1692sphere_radius(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geobodyENT1695;}
	local[0]= NIL;
geobodyENT1695:
geobodyENT1694:
	if (n>3) maerror();
	if (local[0]==NIL) goto geobodyIF1696;
	argv[0]->c.obj.iv[8] = local[0];
	local[1]= argv[0]->c.obj.iv[8];
	goto geobodyIF1697;
geobodyIF1696:
	local[1]= NIL;
geobodyIF1697:
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
geobodyBLK1693:
	ctx->vsp=local; return(local[0]);}

/*:inner*/
static pointer geobodyM1698sphere_inner(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)VDISTANCE(ctx,2,local+0); /*distance*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	local[0]= w;
geobodyBLK1699:
	ctx->vsp=local; return(local[0]);}

/*:volume*/
static pointer geobodyM1700sphere_volume(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeflt(4.0000000000000000000000e+00);
	local[1]= makeflt(3.1415926535897931159980e+00);
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,5,local+0); /***/
	local[0]= w;
	local[1]= makeint((eusinteger_t)3L);
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
geobodyBLK1701:
	ctx->vsp=local; return(local[0]);}

/*:intersect-line*/
static pointer geobodyM1702sphere_intersect_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)VMINUS(ctx,2,local+1); /*v-*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[171];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= local[0];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)VMINUS(ctx,2,local+3); /*v-*/
	local[3]= w;
	local[4]= local[1];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)VINNERPRODUCT(ctx,2,local+4); /*v.*/
	local[4]= w;
	local[5]= local[1];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)VINNERPRODUCT(ctx,2,local+5); /*v.*/
	local[5]= w;
	local[6]= local[3];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)VINNERPRODUCT(ctx,2,local+6); /*v.*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[8];
	local[8]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	local[7]= local[5];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= local[4];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	local[8]= local[7];
	local[9]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto geobodyIF1704;
	local[8]= NIL;
	goto geobodyIF1705;
geobodyIF1704:
	local[8]= local[5];
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)SQRT(ctx,1,local+9); /*sqrt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	local[9]= argv[2];
	local[10]= argv[3];
	ctx->vsp=local+11;
	w=(*ftab[27])(ctx,3,local+8,&ftab[27],fqv[172]); /*midpoint*/
	local[8]= w;
	local[9]= local[5];
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(pointer)SQRT(ctx,1,local+10); /*sqrt*/
	local[10]= makeflt(-(fltval(w)));
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	local[10]= argv[2];
	local[11]= argv[3];
	ctx->vsp=local+12;
	w=(*ftab[27])(ctx,3,local+9,&ftab[27],fqv[172]); /*midpoint*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,2,local+8); /*list*/
	local[8]= w;
geobodyIF1705:
	w = local[8];
	local[0]= w;
geobodyBLK1703:
	ctx->vsp=local; return(local[0]);}

/*:closest-point*/
static pointer geobodyM1706sphere_closest_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[171];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= argv[2];
	local[3]= argv[0];
	local[4]= fqv[171];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)VMINUS(ctx,2,local+2); /*v-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VNORMALIZE(ctx,1,local+2); /*normalize-vector*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,2,local+1); /*scale*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VPLUS(ctx,2,local+0); /*v+*/
	local[0]= w;
geobodyBLK1707:
	ctx->vsp=local; return(local[0]);}

/*:intersect-with-body*/
static pointer geobodyM1708sphere_intersect_with_body(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= argv[2];
	local[2]= fqv[173];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
geobodyWHL1710:
	if (local[1]==NIL) goto geobodyWHX1711;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)VDISTANCE(ctx,2,local+2); /*distance*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto geobodyIF1713;
	w = T;
	ctx->vsp=local+2;
	local[0]=w;
	goto geobodyBLK1709;
	goto geobodyIF1714;
geobodyIF1713:
	local[2]= NIL;
geobodyIF1714:
	goto geobodyWHL1710;
geobodyWHX1711:
	local[2]= NIL;
geobodyBLK1712:
	w = NIL;
	w = NIL;
	local[0]= w;
geobodyBLK1709:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer geobodyM1715sphere_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[174], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto geobodyKEY1717;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[0] = w;
geobodyKEY1717:
	if (n & (1<<1)) goto geobodyKEY1718;
	local[1] = makeflt(1.0000000000000000000000e+00);
geobodyKEY1718:
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[53]));
	local[4]= fqv[32];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,3,local+2); /*send-message*/
	argv[0]->c.obj.iv[2] = local[0];
	argv[0]->c.obj.iv[8] = local[1];
	w = argv[0];
	local[0]= w;
geobodyBLK1716:
	ctx->vsp=local; return(local[0]);}

/*add-wings*/
static pointer geobodyF1084add_wings(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[0]->c.obj.iv[10];
geobodyWHL1720:
	if (local[5]==NIL) goto geobodyWHX1721;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= loadglobal(fqv[175]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[32];
	local[9]= fqv[176];
	local[10]= local[4]->c.obj.iv[3];
	local[11]= fqv[177];
	local[12]= local[4]->c.obj.iv[4];
	local[13]= fqv[178];
	local[14]= local[4]->c.obj.iv[1];
	local[15]= fqv[179];
	local[16]= local[4]->c.obj.iv[2];
	local[17]= fqv[99];
	local[18]= local[4]->c.obj.iv[5];
	local[19]= fqv[180];
	local[20]= local[4];
	local[21]= fqv[180];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,2,local+20); /*send*/
	local[20]= w;
	local[21]= fqv[181];
	local[22]= local[4];
	local[23]= fqv[181];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,2,local+22); /*send*/
	local[22]= w;
	local[23]= fqv[182];
	local[24]= local[4];
	local[25]= fqv[182];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,2,local+24); /*send*/
	local[24]= w;
	local[25]= fqv[183];
	local[26]= local[4];
	local[27]= fqv[183];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,2,local+26); /*send*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,20,local+7); /*send*/
	w = local[6];
	local[3] = w;
	local[6]= local[4];
	local[7]= local[3];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(*ftab[28])(ctx,3,local+6,&ftab[28],fqv[184]); /*acons*/
	local[1] = w;
	goto geobodyWHL1720;
geobodyWHX1721:
	local[6]= NIL;
geobodyBLK1722:
	w = NIL;
	local[4]= NIL;
	local[5]= local[1];
geobodyWHL1723:
	if (local[5]==NIL) goto geobodyWHX1724;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	local[6]= local[3];
	local[7]= fqv[32];
	local[8]= fqv[180];
	local[9]= local[3]->c.obj.iv[7];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)ASSQ(ctx,2,local+9); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.cdr;
	local[10]= fqv[182];
	local[11]= local[3]->c.obj.iv[9];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)ASSQ(ctx,2,local+11); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.cdr;
	local[12]= fqv[181];
	local[13]= local[3]->c.obj.iv[8];
	local[14]= local[1];
	ctx->vsp=local+15;
	w=(pointer)ASSQ(ctx,2,local+13); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.cdr;
	local[14]= fqv[183];
	local[15]= local[3]->c.obj.iv[10];
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)ASSQ(ctx,2,local+15); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.cdr;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,10,local+6); /*send*/
	goto geobodyWHL1723;
geobodyWHX1724:
	local[6]= NIL;
geobodyBLK1725:
	w = NIL;
	local[4]= NIL;
	local[5]= argv[0];
	local[6]= fqv[185];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
geobodyWHL1726:
	if (local[5]==NIL) goto geobodyWHX1727;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[0] = NIL;
	local[6]= NIL;
	local[7]= local[4];
	local[8]= fqv[186];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
geobodyWHL1729:
	if (local[7]==NIL) goto geobodyWHX1730;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[6];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)ASSQ(ctx,2,local+8); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	w = local[0];
	ctx->vsp=local+9;
	local[0] = cons(ctx,local[8],w);
	goto geobodyWHL1729;
geobodyWHX1730:
	local[8]= NIL;
geobodyBLK1731:
	w = NIL;
	local[6]= local[0];
	local[7]= local[6];
	w = local[4];
	w->c.obj.iv[4] = local[7];
	local[6]= NIL;
	local[7]= local[4];
	local[8]= fqv[14];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
geobodyWHL1732:
	if (local[7]==NIL) goto geobodyWHX1733;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[0] = NIL;
	local[8]= NIL;
	local[9]= local[6];
	local[10]= fqv[186];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
geobodyWHL1735:
	if (local[9]==NIL) goto geobodyWHX1736;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[8];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)ASSQ(ctx,2,local+10); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.cdr;
	w = local[0];
	ctx->vsp=local+11;
	local[0] = cons(ctx,local[10],w);
	goto geobodyWHL1735;
geobodyWHX1736:
	local[10]= NIL;
geobodyBLK1737:
	w = NIL;
	local[8]= local[0];
	local[9]= local[8];
	w = local[6];
	w->c.obj.iv[4] = local[9];
	goto geobodyWHL1732;
geobodyWHX1733:
	local[8]= NIL;
geobodyBLK1734:
	w = NIL;
	goto geobodyWHL1726;
geobodyWHX1727:
	local[6]= NIL;
geobodyBLK1728:
	w = NIL;
	local[4]= (pointer)get_sym_func(fqv[187]);
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	local[5]= w;
	w = argv[0];
	w->c.obj.iv[10] = local[5];
	w = argv[0];
	local[0]= w;
geobodyBLK1719:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___geobody(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[188];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto geobodyIF1738;
	local[0]= fqv[189];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[190],w);
	goto geobodyIF1739;
geobodyIF1738:
	local[0]= fqv[191];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
geobodyIF1739:
	local[0]= fqv[192];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[193];
	local[1]= fqv[194];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[195]); /*require*/
	local[0]= fqv[196];
	local[1]= fqv[197];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geobodyIF1740;
	local[0]= fqv[196];
	local[1]= fqv[197];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[196];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto geobodyIF1742;
	local[0]= fqv[196];
	local[1]= fqv[198];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto geobodyIF1743;
geobodyIF1742:
	local[0]= NIL;
geobodyIF1743:
	local[0]= fqv[196];
	goto geobodyIF1741;
geobodyIF1740:
	local[0]= NIL;
geobodyIF1741:
	local[0]= fqv[199];
	local[1]= fqv[197];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geobodyIF1744;
	local[0]= fqv[199];
	local[1]= fqv[197];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[199];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto geobodyIF1746;
	local[0]= fqv[199];
	local[1]= fqv[198];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto geobodyIF1747;
geobodyIF1746:
	local[0]= NIL;
geobodyIF1747:
	local[0]= fqv[199];
	goto geobodyIF1745;
geobodyIF1744:
	local[0]= NIL;
geobodyIF1745:
	local[0]= fqv[200];
	local[1]= fqv[197];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geobodyIF1748;
	local[0]= fqv[200];
	local[1]= fqv[197];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[200];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto geobodyIF1750;
	local[0]= fqv[200];
	local[1]= fqv[198];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto geobodyIF1751;
geobodyIF1750:
	local[0]= NIL;
geobodyIF1751:
	local[0]= fqv[200];
	goto geobodyIF1749;
geobodyIF1748:
	local[0]= NIL;
geobodyIF1749:
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1085faceset_update,fqv[33],fqv[201],fqv[202]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1092faceset_vertices,fqv[173],fqv[201],fqv[203]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1094faceset_faces,fqv[185],fqv[201],fqv[204]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1100faceset_face,fqv[205],fqv[201],fqv[206]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1102faceset_all_edges,fqv[23],fqv[201],fqv[207]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1104faceset_edges,fqv[186],fqv[201],fqv[208]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1106faceset_edge,fqv[209],fqv[201],fqv[210]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1108faceset_vertex,fqv[211],fqv[201],fqv[212]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1110faceset_box,fqv[28],fqv[201],fqv[213]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1112faceset_color,fqv[10],fqv[201],fqv[214]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1118faceset_reflectance,fqv[11],fqv[201],fqv[215]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1126faceset_diffusion,fqv[12],fqv[201],fqv[216]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1134faceset_holes,fqv[14],fqv[201],fqv[217]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1136faceset_visible_faces,fqv[22],fqv[201],fqv[218]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1141faceset_visible_edges,fqv[6],fqv[201],fqv[219]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1153faceset_contour_edges,fqv[220],fqv[201],fqv[221]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1165faceset_non_contour_edges,fqv[222],fqv[201],fqv[223]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1172faceset_common_box,fqv[74],fqv[201],fqv[224]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1176faceset_newbox,fqv[97],fqv[201],fqv[225]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1182faceset_reset_vertices,fqv[4],fqv[201],fqv[226]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1187faceset_translate_vertices,fqv[56],fqv[201],fqv[227]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1192faceset_rotate_vertices,fqv[57],fqv[201],fqv[228]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1201faceset_magnify,fqv[58],fqv[201],fqv[229]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1219faceset_faces_intersect_with_point_vector,fqv[69],fqv[201],fqv[230]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1226faceset_distance,fqv[46],fqv[201],fqv[231]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1241faceset_init,fqv[32],fqv[201],fqv[232]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1268body_translate_vertices,fqv[56],fqv[233],fqv[234]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1270body_rotate_vertices,fqv[57],fqv[233],fqv[235]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1272body_magnify,fqv[58],fqv[233],fqv[236]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1276body_euler,fqv[237],fqv[233],fqv[238]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1278body_perimeter,fqv[239],fqv[233],fqv[240]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1280body_volume,fqv[62],fqv[233],fqv[241]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1284body_centroid,fqv[63],fqv[233],fqv[242]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1292body_world_centroid,fqv[243],fqv[233],fqv[244]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1294body_area,fqv[67],fqv[233],fqv[245]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1296body_extream_point,fqv[68],fqv[233],fqv[246]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1303body_length,fqv[60],fqv[233],fqv[247]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1305body_supporting_faces,fqv[248],fqv[233],fqv[249]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1309body_possibly_interfering_faces,fqv[72],fqv[233],fqv[250]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1312body_possibly_interfering_edges,fqv[75],fqv[233],fqv[251]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1315body_intersect_face,fqv[71],fqv[233],fqv[252]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1323body_intersectp,fqv[253],fqv[233],fqv[254]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1336body_intersectp2,fqv[255],fqv[233],fqv[256]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1410body_insidep,fqv[82],fqv[233],fqv[257]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1447body_evert,fqv[258],fqv[233],fqv[259]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1452body_set_convexp,fqv[98],fqv[233],fqv[260]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1461body_get_face,fqv[9],fqv[233],fqv[261]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1505body_primitive_body_p,fqv[115],fqv[233],fqv[262]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1508body_primitive_bodies,fqv[146],fqv[233],fqv[263]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1524body_csg,fqv[126],fqv[233],fqv[264]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1530body_copy_csg,fqv[265],fqv[233],fqv[266]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1535body_body_type,fqv[119],fqv[233],fqv[267]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1539body_creation_form,fqv[268],fqv[233],fqv[269]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1544body_prin1,fqv[118],fqv[233],fqv[270]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1546body_init,fqv[32],fqv[233],fqv[271]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1595body_replace_shape,fqv[147],fqv[233],fqv[272]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1608body__,fqv[111],fqv[233],fqv[273]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1611body__,fqv[113],fqv[233],fqv[274]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1614body__,fqv[275],fqv[233],fqv[276]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1617body_primitive_groups,fqv[112],fqv[233],fqv[277]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1634body_constraint,fqv[278],fqv[233],fqv[279]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1638body_contact_vertices,fqv[151],fqv[233],fqv[280]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1662body_contact_edges,fqv[152],fqv[233],fqv[281]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1677body_possibly_contacting_vertices,fqv[158],fqv[233],fqv[282]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1680body_possibly_contacting_edges,fqv[165],fqv[233],fqv[283]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1683body_possibly_contacting_faces,fqv[159],fqv[233],fqv[284]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1692sphere_radius,fqv[285],fqv[286],fqv[287]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1698sphere_inner,fqv[90],fqv[286],fqv[288]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1700sphere_volume,fqv[62],fqv[286],fqv[289]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1702sphere_intersect_line,fqv[77],fqv[286],fqv[290]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1706sphere_closest_point,fqv[291],fqv[286],fqv[292]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1708sphere_intersect_with_body,fqv[293],fqv[286],fqv[294]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geobodyM1715sphere_init,fqv[32],fqv[286],fqv[295]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[296],module,geobodyF1084add_wings,fqv[297]);
	local[0]= fqv[298];
	local[1]= fqv[299];
	ctx->vsp=local+2;
	w=(*ftab[30])(ctx,2,local+0,&ftab[30],fqv[300]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<31; i++) ftab[i]=fcallx;
}

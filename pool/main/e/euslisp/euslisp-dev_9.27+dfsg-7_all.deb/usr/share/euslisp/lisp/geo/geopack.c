/* ./geopack.c :  entry=geopack */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "geopack.h"
#pragma init (register_geopack)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___geopack();
extern pointer build_quote_vector();
static int register_geopack()
  { add_module_initializer("___geopack", ___geopack);}

static pointer geopackF3vplus();
static pointer geopackF4vector_mean();
static pointer geopackF5direction_vector();
static pointer geopackF6triangle();
static pointer geopackF7triangle_normal();
static pointer geopackF8vector_angle();
static pointer geopackF9face_normal_vector();
static pointer geopackF10farthest();
static pointer geopackF11farthest_pair();
static pointer geopackF12maxindex();
static pointer geopackF13random_vector();
static pointer geopackF14random_normalized_vector();
static pointer geopackF15random_vector2();
static pointer geopackF16random_vectors();
static pointer geopackF17edgep();
static pointer geopackF18facep();
static pointer geopackF19bodyp();
static pointer geopackF20primitive_body_p();
static pointer geopackF21n_2();
static pointer geopackF22eps_();
static pointer geopackF23eps_();
static pointer geopackF24eps_();
static pointer geopackF25eps__();
static pointer geopackF26eps__();
static pointer geopackF27eps__();
static pointer geopackF28eps_zero();
static pointer geopackF29eps_in_range();
static pointer geopackF30eps_v_();
static pointer geopackF31eps_coords_();
static pointer geopackF32make_bounding_box();
static pointer geopackF33make_big_bounding_box();
static pointer geopackF34bounding_box_intersection();
static pointer geopackF35bounding_box_union();
static pointer geopackF36make_line();
static pointer geopackF37winged_edge_p();
static pointer geopackF38make_plane();
static pointer geopackF39make_polygon();

/*vplus*/
static pointer geopackF3vplus(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[0]);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,2,local+0); /*instantiate*/
	local[0]= w;
	local[1]= NIL;
	local[2]= argv[0];
geopackWHL41:
	if (local[2]==NIL) goto geopackWHX42;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	local[4]= local[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)VPLUS(ctx,3,local+3); /*v+*/
	goto geopackWHL41;
geopackWHX42:
	local[3]= NIL;
geopackBLK43:
	w = NIL;
	w = local[0];
	local[0]= w;
geopackBLK40:
	ctx->vsp=local; return(local[0]);}

/*vector-mean*/
static pointer geopackF4vector_mean(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)geopackF3vplus(ctx,1,local+1); /*vplus*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)SCALEVEC(ctx,2,local+0); /*scale*/
	local[0]= w;
geopackBLK44:
	ctx->vsp=local; return(local[0]);}

/*direction-vector*/
static pointer geopackF5direction_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)VMINUS(ctx,2,local+0); /*v-*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)VNORMALIZE(ctx,1,local+0); /*normalize-vector*/
	local[0]= w;
geopackBLK45:
	ctx->vsp=local; return(local[0]);}

/*triangle*/
static pointer geopackF6triangle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT48;}
	local[0]= fqv[1];
geopackENT48:
geopackENT47:
	if (n>4) maerror();
	local[1]= argv[1];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)VMINUS(ctx,2,local+1); /*v-*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)VMINUS(ctx,2,local+2); /*v-*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SCA3PROD(ctx,3,local+1); /*v.**/
	local[0]= w;
geopackBLK46:
	ctx->vsp=local; return(local[0]);}

/*triangle-normal*/
static pointer geopackF7triangle_normal(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)VMINUS(ctx,2,local+0); /*v-*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)VMINUS(ctx,2,local+1); /*v-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+0); /*v**/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)VNORMALIZE(ctx,1,local+0); /*normalize-vector*/
	local[0]= w;
geopackBLK49:
	ctx->vsp=local; return(local[0]);}

/*vector-angle*/
static pointer geopackF8vector_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT53;}
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+0); /*v**/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)VNORMALIZE(ctx,1,local+0); /*normalize-vector*/
	local[0]= w;
geopackENT53:
	if (n>=4) { local[1]=(argv[3]); goto geopackENT52;}
	local[1]= makeflt(9.9999999999999964869129e-11);
geopackENT52:
geopackENT51:
	if (n>4) maerror();
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+2); /*v**/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VNORM2(ctx,1,local+2); /*norm2*/
	local[2]= w;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto geopackIF54;
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)VINNERPRODUCT(ctx,2,local+2); /*v.*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto geopackIF56;
	local[2]= makeflt(0.0000000000000000000000e+00);
	goto geopackIF57;
geopackIF56:
	local[2]= makeflt(3.1415926535897931159980e+00);
geopackIF57:
	w = local[2];
	ctx->vsp=local+2;
	local[0]=w;
	goto geopackBLK50;
	goto geopackIF55;
geopackIF54:
	local[2]= NIL;
geopackIF55:
	local[2]= local[0];
	local[3]= argv[0];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)SCA3PROD(ctx,3,local+2); /*v.**/
	local[2]= w;
	local[3]= argv[0];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)VINNERPRODUCT(ctx,2,local+3); /*v.*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ATAN(ctx,2,local+2); /*atan*/
	local[0]= w;
geopackBLK50:
	ctx->vsp=local; return(local[0]);}

/*face-normal-vector*/
static pointer geopackF9face_normal_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= NIL;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
geopackWHL59:
	if (local[2]==NIL) goto geopackWHX60;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[5];
	local[1] = w;
	local[5]= local[0];
	local[6]= local[1];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+5); /*v**/
	local[5]= w;
	local[6]= local[4];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)VPLUS(ctx,3,local+5); /*v+*/
	local[0] = local[1];
	goto geopackWHL59;
geopackWHX60:
	local[5]= NIL;
geopackBLK61:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.car;
	local[5]= local[0];
	local[6]= local[1];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+5); /*v**/
	local[5]= w;
	local[6]= local[4];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)VPLUS(ctx,3,local+5); /*v+*/
	local[5]= local[4];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)VNORMALIZE(ctx,2,local+5); /*normalize-vector*/
	local[0]= w;
geopackBLK58:
	ctx->vsp=local; return(local[0]);}

/*farthest*/
static pointer geopackF10farthest(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[1] = (w)->c.cons.cdr;
	w = local[0];
	local[0]= w;
	local[1]= argv[0];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)VDISTANCE(ctx,2,local+1); /*distance*/
	local[1]= w;
	local[2]= makeflt(0.0000000000000000000000e+00);
	local[3]= NIL;
	local[4]= argv[1];
geopackWHL63:
	if (local[4]==NIL) goto geopackWHX64;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= argv[0];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)VDISTANCE(ctx,2,local+5); /*distance*/
	local[2] = w;
	local[5]= local[2];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto geopackIF66;
	local[0] = local[3];
	local[1] = local[2];
	local[5]= local[1];
	goto geopackIF67;
geopackIF66:
	local[5]= NIL;
geopackIF67:
	goto geopackWHL63;
geopackWHX64:
	local[5]= NIL;
geopackBLK65:
	w = NIL;
	w = local[0];
	local[0]= w;
geopackBLK62:
	ctx->vsp=local; return(local[0]);}

/*farthest-pair*/
static pointer geopackF11farthest_pair(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[0];
	local[0]= w;
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)geopackF10farthest(ctx,2,local+2); /*farthest*/
	local[2]= w;
	local[3]= local[0];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)VDISTANCE(ctx,2,local+3); /*distance*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
geopackWHL69:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto geopackWHX70;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[7];
	local[4] = w;
	local[7]= local[4];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)geopackF10farthest(ctx,2,local+7); /*farthest*/
	local[5] = w;
	local[7]= local[4];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)VDISTANCE(ctx,2,local+7); /*distance*/
	local[6] = w;
	local[7]= local[6];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)GREATERP(ctx,2,local+7); /*>*/
	if (w==NIL) goto geopackIF72;
	local[0] = local[4];
	local[2] = local[5];
	local[3] = local[6];
	local[7]= local[3];
	goto geopackIF73;
geopackIF72:
	local[7]= NIL;
geopackIF73:
	goto geopackWHL69;
geopackWHX70:
	local[7]= NIL;
geopackBLK71:
	local[7]= local[0];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[0]= w;
geopackBLK68:
	ctx->vsp=local; return(local[0]);}

/*maxindex*/
static pointer geopackF12maxindex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)1L));
	  w=makeflt(local[1]->c.fvec.fv[i]);}
	local[1]= makeflt((double)fabs(fltval(w)));
	local[2]= argv[0];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)0L));
	  w=makeflt(local[2]->c.fvec.fv[i]);}
	{ double left,right;
		right=fltval(makeflt((double)fabs(fltval(w)))); left=fltval(local[1]);
	if (left <= right) goto geopackIF75;}
	local[0] = makeint((eusinteger_t)1L);
	local[1]= local[0];
	goto geopackIF76;
geopackIF75:
	local[1]= NIL;
geopackIF76:
	local[1]= argv[0];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)2L));
	  w=makeflt(local[1]->c.fvec.fv[i]);}
	local[1]= makeflt((double)fabs(fltval(w)));
	local[2]= argv[0];
	{ register eusinteger_t i=intval(local[0]);
	  w=makeflt(local[2]->c.fvec.fv[i]);}
	{ double left,right;
		right=fltval(makeflt((double)fabs(fltval(w)))); left=fltval(local[1]);
	if (left <= right) goto geopackIF77;}
	local[0] = makeint((eusinteger_t)2L);
	local[1]= local[0];
	goto geopackIF78;
geopackIF77:
	local[1]= NIL;
geopackIF78:
	w = local[0];
	local[0]= w;
geopackBLK74:
	ctx->vsp=local; return(local[0]);}

/*random-vector*/
static pointer geopackF13random_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto geopackENT81;}
	local[0]= makeflt(1.0000000000000000000000e+00);
geopackENT81:
geopackENT80:
	if (n>1) maerror();
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)RANDOM(ctx,1,local+2); /*random*/
	local[2]= w;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)RANDOM(ctx,1,local+3); /*random*/
	local[3]= w;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)RANDOM(ctx,1,local+4); /*random*/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[0]= w;
geopackBLK79:
	ctx->vsp=local; return(local[0]);}

/*random-normalized-vector*/
static pointer geopackF14random_normalized_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+1;
	w=(pointer)RANDOM(ctx,1,local+0); /*random*/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(pointer)RANDOM(ctx,1,local+1); /*random*/
	local[1]= w;
	local[2]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)RANDOM(ctx,1,local+2); /*random*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)VNORMALIZE(ctx,1,local+0); /*normalize-vector*/
	local[0]= w;
geopackBLK82:
	ctx->vsp=local; return(local[0]);}

/*random-vector2*/
static pointer geopackF15random_vector2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto geopackENT85;}
	local[0]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+1;
	w=(pointer)RANDOM(ctx,1,local+0); /*random*/
	local[0]= w;
geopackENT85:
geopackENT84:
	if (n>1) maerror();
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)1L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	local[3]= makeflt(6.2831853071795862319959e+00);
	ctx->vsp=local+4;
	w=(pointer)RANDOM(ctx,1,local+3); /*random*/
	local[3]= w;
	local[4]= fqv[2];
	ctx->vsp=local+5;
	w=(pointer)ROTVEC(ctx,3,local+2); /*rotate-vector*/
	local[2]= w;
	local[3]= makeflt(6.2831853071795862319959e+00);
	ctx->vsp=local+4;
	w=(pointer)RANDOM(ctx,1,local+3); /*random*/
	local[3]= w;
	local[4]= fqv[3];
	ctx->vsp=local+5;
	w=(pointer)ROTVEC(ctx,3,local+2); /*rotate-vector*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,2,local+1); /*scale*/
	local[0]= w;
geopackBLK83:
	ctx->vsp=local; return(local[0]);}

/*random-vectors*/
static pointer geopackF16random_vectors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto geopackIF87;
	local[0]= NIL;
	goto geopackIF88;
geopackIF87:
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(pointer)geopackF13random_vector(ctx,1,local+0); /*random-vector*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	local[1]= w;
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)geopackF16random_vectors(ctx,2,local+1); /*random-vectors*/
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
geopackIF88:
	w = local[0];
	local[0]= w;
geopackBLK86:
	ctx->vsp=local; return(local[0]);}

/*edgep*/
static pointer geopackF17edgep(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[4]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
geopackBLK89:
	ctx->vsp=local; return(local[0]);}

/*facep*/
static pointer geopackF18facep(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[5]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
geopackBLK90:
	ctx->vsp=local; return(local[0]);}

/*bodyp*/
static pointer geopackF19bodyp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[6]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
geopackBLK91:
	ctx->vsp=local; return(local[0]);}

/*primitive-body-p*/
static pointer geopackF20primitive_body_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)geopackF19bodyp(ctx,1,local+0); /*bodyp*/
	local[0]= w;
	if (w==NIL) goto geopackAND93;
	local[0]= argv[0];
	local[1]= fqv[7];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
geopackAND93:
	w = local[0];
	local[0]= w;
geopackBLK92:
	ctx->vsp=local; return(local[0]);}

/*n^2*/
static pointer geopackF21n_2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
geopackBLK94:
	ctx->vsp=local; return(local[0]);}

/*eps=*/
static pointer geopackF22eps_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT97;}
	local[0]= loadglobal(fqv[8]);
geopackENT97:
geopackENT96:
	if (n>3) maerror();
	local[1]= argv[0];
	{ double x,y;
		y=fltval(argv[1]); x=fltval(local[1]);
		local[1]=(makeflt(x - y));}
	local[1]= makeflt((double)fabs(fltval(local[1])));
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	local[0]= w;
geopackBLK95:
	ctx->vsp=local; return(local[0]);}

/*eps<*/
static pointer geopackF23eps_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT100;}
	local[0]= loadglobal(fqv[8]);
geopackENT100:
geopackENT99:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= argv[1];
	{ double x,y;
		y=fltval(local[0]); x=fltval(local[2]);
		local[2]=(makeflt(x - y));}
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	local[0]= w;
geopackBLK98:
	ctx->vsp=local; return(local[0]);}

/*eps>*/
static pointer geopackF24eps_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT103;}
	local[0]= loadglobal(fqv[8]);
geopackENT103:
geopackENT102:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= argv[1];
	{ double x,y;
		y=fltval(local[0]); x=fltval(local[2]);
		local[2]=(makeflt(x + y));}
	ctx->vsp=local+3;
	w=(pointer)GREATERP(ctx,2,local+1); /*>*/
	local[0]= w;
geopackBLK101:
	ctx->vsp=local; return(local[0]);}

/*eps<=*/
static pointer geopackF25eps__(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT106;}
	local[0]= loadglobal(fqv[8]);
geopackENT106:
geopackENT105:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= argv[1];
	{ double x,y;
		y=fltval(local[0]); x=fltval(local[2]);
		local[2]=(makeflt(x + y));}
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	local[0]= w;
geopackBLK104:
	ctx->vsp=local; return(local[0]);}

/*eps>=*/
static pointer geopackF26eps__(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT109;}
	local[0]= loadglobal(fqv[8]);
geopackENT109:
geopackENT108:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= argv[1];
	{ double x,y;
		y=fltval(local[0]); x=fltval(local[2]);
		local[2]=(makeflt(x - y));}
	ctx->vsp=local+3;
	w=(pointer)GREATERP(ctx,2,local+1); /*>*/
	local[0]= w;
geopackBLK107:
	ctx->vsp=local; return(local[0]);}

/*eps<>*/
static pointer geopackF27eps__(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT112;}
	local[0]= loadglobal(fqv[8]);
geopackENT112:
geopackENT111:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= argv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)geopackF22eps_(ctx,3,local+1); /*eps=*/
	w = ((w)==NIL?T:NIL);
	local[0]= w;
geopackBLK110:
	ctx->vsp=local; return(local[0]);}

/*eps-zero*/
static pointer geopackF28eps_zero(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto geopackENT115;}
	local[0]= loadglobal(fqv[8]);
geopackENT115:
geopackENT114:
	if (n>2) maerror();
	local[1]= argv[0];
	local[2]= makeflt(0.0000000000000000000000e+00);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)geopackF22eps_(ctx,3,local+1); /*eps=*/
	local[0]= w;
geopackBLK113:
	ctx->vsp=local; return(local[0]);}

/*eps-in-range*/
static pointer geopackF29eps_in_range(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT118;}
	local[0]= loadglobal(fqv[8]);
geopackENT118:
geopackENT117:
	if (n>4) maerror();
	local[1]= argv[0];
	{ double x,y;
		y=fltval(local[0]); x=fltval(local[1]);
		local[1]=(makeflt(x - y));}
	local[2]= argv[1];
	local[3]= argv[2];
	{ double x,y;
		y=fltval(local[0]); x=fltval(local[3]);
		local[3]=(makeflt(x + y));}
	ctx->vsp=local+4;
	w=(pointer)LSEQP(ctx,3,local+1); /*<=*/
	local[0]= w;
geopackBLK116:
	ctx->vsp=local; return(local[0]);}

/*eps-v=*/
static pointer geopackF30eps_v_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT121;}
	local[0]= loadglobal(fqv[8]);
geopackENT121:
geopackENT120:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)VDISTANCE(ctx,2,local+1); /*distance*/
	local[1]= w;
	local[2]= makeflt(0.0000000000000000000000e+00);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)geopackF22eps_(ctx,3,local+1); /*eps=*/
	local[0]= w;
geopackBLK119:
	ctx->vsp=local; return(local[0]);}

/*eps-coords=*/
static pointer geopackF31eps_coords_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT125;}
	local[0]= loadglobal(fqv[8]);
geopackENT125:
	if (n>=4) { local[1]=(argv[3]); goto geopackENT124;}
	local[1]= local[0];
geopackENT124:
geopackENT123:
	if (n>4) maerror();
	local[2]= NIL;
	local[3]= argv[0];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,2,local+3,&ftab[0],fqv[9]); /*coordinates-distance*/
	local[3]= w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	local[4]= w;
	if (w==NIL) goto geopackAND126;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (((w)->c.cons.car)==NIL?T:NIL);
	if (local[4]!=NIL) goto geopackOR127;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	local[4]= w;
geopackOR127:
geopackAND126:
	w = local[4];
	local[0]= w;
geopackBLK122:
	ctx->vsp=local; return(local[0]);}

/*:box*/
static pointer geopackM128bounding_box_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT131;}
	local[0]= NIL;
geopackENT131:
geopackENT130:
	if (n>3) maerror();
	if (local[0]==NIL) goto geopackIF132;
	local[1]= argv[0];
	local[2]= fqv[10];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto geopackIF133;
geopackIF132:
	local[1]= argv[0];
geopackIF133:
	w = local[1];
	local[0]= w;
geopackBLK129:
	ctx->vsp=local; return(local[0]);}

/*:minpoint*/
static pointer geopackM134bounding_box_minpoint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[0];
	local[0]= w;
geopackBLK135:
	ctx->vsp=local; return(local[0]);}

/*:maxpoint*/
static pointer geopackM136bounding_box_maxpoint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
geopackBLK137:
	ctx->vsp=local; return(local[0]);}

/*:center*/
static pointer geopackM138bounding_box_center(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeflt(5.0000000000000000000000e-01);
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,3,local+0,&ftab[1],fqv[11]); /*midpoint*/
	local[0]= w;
geopackBLK139:
	ctx->vsp=local; return(local[0]);}

/*:diagonal*/
static pointer geopackM140bounding_box_diagonal(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+2;
	w=(pointer)VMINUS(ctx,2,local+0); /*v-*/
	local[0]= w;
geopackBLK141:
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer geopackM142bounding_box_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT145;}
	local[0]= T;
geopackENT145:
geopackENT144:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[12]));
	local[3]= fqv[13];
	local[4]= local[0];
	local[5]= NIL;
	local[6]= fqv[14];
	local[7]= argv[0]->c.obj.iv[0];
	local[8]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SENDMESSAGE(ctx,5,local+1); /*send-message*/
	local[0]= w;
geopackBLK143:
	ctx->vsp=local; return(local[0]);}

/*:inner*/
static pointer geopackM146bounding_box_inner(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)VLESSP(ctx,2,local+0); /*v<*/
	local[0]= w;
	if (w==NIL) goto geopackAND148;
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+2;
	w=(pointer)VGREATERP(ctx,2,local+0); /*v>*/
	local[0]= w;
geopackAND148:
	w = local[0];
	local[0]= w;
geopackBLK147:
	ctx->vsp=local; return(local[0]);}

/*:intersection*/
static pointer geopackM149bounding_box_intersection(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT152;}
	local[0]= NIL;
geopackENT152:
geopackENT151:
	if (n>4) maerror();
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= argv[2]->c.obj.iv[0];
	ctx->vsp=local+3;
	w=(pointer)VMAX(ctx,2,local+1); /*vmax*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[2]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)VMIN(ctx,2,local+2); /*vmin*/
	local[2]= w;
	if (local[0]==NIL) goto geopackIF153;
	local[3]= local[0];
	local[4]= local[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[0] = w;
	local[3]= local[1];
	local[4]= local[0];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)VMINUS(ctx,3,local+3); /*v-*/
	local[3]= local[2];
	local[4]= local[0];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)VPLUS(ctx,3,local+3); /*v+*/
	local[3]= w;
	goto geopackIF154;
geopackIF153:
	local[3]= NIL;
geopackIF154:
	local[3]= local[1];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)VLESSP(ctx,2,local+3); /*v<*/
	if (w==NIL) goto geopackIF155;
	local[3]= loadglobal(fqv[15]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[16];
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = local[3];
	local[3]= w;
	goto geopackIF156;
geopackIF155:
	local[3]= NIL;
geopackIF156:
	w = local[3];
	local[0]= w;
geopackBLK150:
	ctx->vsp=local; return(local[0]);}

/*:union*/
static pointer geopackM157bounding_box_union(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT160;}
	local[0]= NIL;
geopackENT160:
geopackENT159:
	if (n>4) maerror();
	local[1]= loadglobal(fqv[15]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[16];
	local[4]= argv[0]->c.obj.iv[0];
	local[5]= argv[2]->c.obj.iv[0];
	ctx->vsp=local+6;
	w=(pointer)VMIN(ctx,2,local+4); /*vmin*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[1];
	local[6]= argv[2]->c.obj.iv[1];
	ctx->vsp=local+7;
	w=(pointer)VMAX(ctx,2,local+5); /*vmax*/
	local[5]= w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	w = local[1];
	local[0]= w;
geopackBLK158:
	ctx->vsp=local; return(local[0]);}

/*:intersection-p*/
static pointer geopackM161bounding_box_intersection_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= argv[2]->c.obj.iv[0];
	ctx->vsp=local+2;
	w=(pointer)VMAX(ctx,2,local+0); /*vmax*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[2]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)VMIN(ctx,2,local+1); /*vmin*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VLESSP(ctx,2,local+0); /*v<*/
	local[0]= w;
geopackBLK162:
	ctx->vsp=local; return(local[0]);}

/*:grow*/
static pointer geopackM163bounding_box_grow(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT166;}
	local[0]= NIL;
geopackENT166:
geopackENT165:
	if (n>4) maerror();
	if (local[0]==NIL) goto geopackIF167;
	local[1]= argv[2];
	local[2]= argv[2];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	goto geopackIF168;
geopackIF167:
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+4;
	w=(pointer)VMINUS(ctx,2,local+2); /*v-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,2,local+1); /*scale*/
	local[1]= w;
geopackIF168:
	argv[2] = local[1];
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= argv[2];
	local[3]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+4;
	w=(pointer)VMINUS(ctx,3,local+1); /*v-*/
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[2];
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,3,local+1); /*v+*/
	w = argv[0];
	local[0]= w;
geopackBLK164:
	ctx->vsp=local; return(local[0]);}

/*:volume*/
static pointer geopackM169bounding_box_volume(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+2;
	w=(pointer)VMINUS(ctx,2,local+0); /*v-*/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[1]= w;
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,2,local+2); /*aref*/
	local[2]= w;
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,3,local+1); /***/
	local[0]= w;
geopackBLK170:
	ctx->vsp=local; return(local[0]);}

/*:extream-point*/
static pointer geopackM171bounding_box_extream_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= loadglobal(fqv[0]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,2,local+1); /*instantiate*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[0];
geopackWHL173:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto geopackWHX174;
	local[4]= local[1];
	local[5]= local[2];
	local[6]= argv[2];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)GREATERP(ctx,2,local+6); /*>*/
	if (w==NIL) goto geopackIF176;
	local[6]= argv[0]->c.obj.iv[1];
	goto geopackIF177;
geopackIF176:
	local[6]= argv[0]->c.obj.iv[0];
geopackIF177:
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,3,local+4); /*aset*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto geopackWHL173;
geopackWHX174:
	local[4]= NIL;
geopackBLK175:
	w = NIL;
	w = local[1];
	local[0]= w;
geopackBLK172:
	ctx->vsp=local; return(local[0]);}

/*:below*/
static pointer geopackM178bounding_box_below(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT181;}
	local[0]= fqv[17];
geopackENT181:
geopackENT180:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[18];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= fqv[18];
	local[4]= makeflt(-1.0000000000000000000000e+00);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= local[0];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)VINNERPRODUCT(ctx,2,local+3); /*v.*/
	local[3]= w;
	local[4]= local[0];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)VINNERPRODUCT(ctx,2,local+4); /*v.*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	local[0]= w;
geopackBLK179:
	ctx->vsp=local; return(local[0]);}

/*:corners*/
static pointer geopackM182bounding_box_corners(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)2L);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[2])(ctx,2,local+4,&ftab[2],fqv[19]); /*expt*/
	local[4]= w;
geopackWHL184:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto geopackWHX185;
	local[5]= loadglobal(fqv[0]);
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,2,local+5); /*instantiate*/
	local[1] = w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[2];
geopackWHL187:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto geopackWHX188;
	local[7]= local[1];
	local[8]= local[5];
	local[9]= local[5];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)LOGBITP(ctx,2,local+9); /*logbitp*/
	if (w==NIL) goto geopackIF190;
	local[9]= argv[0]->c.obj.iv[1];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,2,local+9); /*aref*/
	local[9]= w;
	goto geopackIF191;
geopackIF190:
	local[9]= argv[0]->c.obj.iv[0];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,2,local+9); /*aref*/
	local[9]= w;
geopackIF191:
	ctx->vsp=local+10;
	w=(pointer)ASET(ctx,3,local+7); /*aset*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto geopackWHL187;
geopackWHX188:
	local[7]= NIL;
geopackBLK189:
	w = NIL;
	local[5]= local[1];
	w = local[0];
	ctx->vsp=local+6;
	local[0] = cons(ctx,local[5],w);
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto geopackWHL184;
geopackWHX185:
	local[5]= NIL;
geopackBLK186:
	w = NIL;
	w = local[0];
	local[0]= w;
geopackBLK183:
	ctx->vsp=local; return(local[0]);}

/*:body*/
static pointer geopackM192bounding_box_body(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+1;
	w=(pointer)COPYSEQ(ctx,1,local+0); /*copy-seq*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+2;
	w=(pointer)COPYSEQ(ctx,1,local+1); /*copy-seq*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+3;
	w=(pointer)COPYSEQ(ctx,1,local+2); /*copy-seq*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+4;
	w=(pointer)COPYSEQ(ctx,1,local+3); /*copy-seq*/
	local[3]= w;
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)1L);
	local[6]= argv[0]->c.obj.iv[1];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,3,local+4); /*aset*/
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)1L);
	local[6]= argv[0]->c.obj.iv[1];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,3,local+4); /*aset*/
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[1];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,3,local+4); /*aset*/
	local[4]= local[3];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[1];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,3,local+4); /*aset*/
	local[4]= local[0];
	local[5]= local[1];
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,4,local+4); /*list*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[1];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[0];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[3])(ctx,2,local+4,&ftab[3],fqv[20]); /*make-prism*/
	local[0]= w;
geopackBLK193:
	ctx->vsp=local; return(local[0]);}

/*:init2*/
static pointer geopackM194bounding_box_init2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto geopackENT197;}
	local[0]= NIL;
geopackENT197:
geopackENT196:
	if (n>5) maerror();
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)VMIN(ctx,2,local+1); /*vmin*/
	argv[0]->c.obj.iv[0] = w;
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)VMAX(ctx,2,local+1); /*vmax*/
	argv[0]->c.obj.iv[1] = w;
	if (local[0]==NIL) goto geopackIF198;
	local[1]= argv[0];
	local[2]= fqv[10];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto geopackIF199;
geopackIF198:
	local[1]= NIL;
geopackIF199:
	w = argv[0];
	local[0]= w;
geopackBLK195:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer geopackM200bounding_box_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT203;}
	local[0]= NIL;
geopackENT203:
geopackENT202:
	if (n>4) maerror();
	local[1]= (pointer)get_sym_func(fqv[21]);
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	argv[0]->c.obj.iv[0] = w;
	local[1]= (pointer)get_sym_func(fqv[22]);
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	argv[0]->c.obj.iv[1] = w;
	if (local[0]==NIL) goto geopackIF204;
	local[1]= argv[0];
	local[2]= fqv[10];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto geopackIF205;
geopackIF204:
	local[1]= NIL;
geopackIF205:
	w = argv[0];
	local[0]= w;
geopackBLK201:
	ctx->vsp=local; return(local[0]);}

/*make-bounding-box*/
static pointer geopackF32make_bounding_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto geopackENT208;}
	local[0]= loadglobal(fqv[23]);
geopackENT208:
geopackENT207:
	if (n>2) maerror();
	local[1]= loadglobal(fqv[15]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[24];
	local[4]= argv[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[0]= w;
geopackBLK206:
	ctx->vsp=local; return(local[0]);}

/*make-big-bounding-box*/
static pointer geopackF33make_big_bounding_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= makeflt(-1.0000000000000000000000e+20);
	local[1]= makeflt(-1.0000000000000000000000e+20);
	local[2]= makeflt(-1.0000000000000000000000e+20);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000000000e+20);
	local[2]= makeflt(1.0000000000000000000000e+20);
	local[3]= makeflt(1.0000000000000000000000e+20);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)geopackF32make_bounding_box(ctx,1,local+0); /*make-bounding-box*/
	local[0]= w;
geopackBLK209:
	ctx->vsp=local; return(local[0]);}

/*bounding-box-intersection*/
static pointer geopackF34bounding_box_intersection(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto geopackENT212;}
	local[0]= loadglobal(fqv[23]);
geopackENT212:
geopackENT211:
	if (n>2) maerror();
	local[1]= NIL;
	local[2]= NIL;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[3];
	local[3]= w;
	local[4]= fqv[25];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[2] = w;
	local[3]= NIL;
	local[4]= argv[0];
geopackWHL213:
	if (local[4]==NIL) goto geopackWHX214;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[2];
	local[6]= fqv[26];
	local[7]= local[3];
	local[8]= fqv[25];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[2] = w;
	if (local[2]!=NIL) goto geopackIF216;
	w = NIL;
	ctx->vsp=local+5;
	local[0]=w;
	goto geopackBLK210;
	goto geopackIF217;
geopackIF216:
	local[5]= NIL;
geopackIF217:
	goto geopackWHL213;
geopackWHX214:
	local[5]= NIL;
geopackBLK215:
	w = NIL;
	w = local[2];
	local[0]= w;
geopackBLK210:
	ctx->vsp=local; return(local[0]);}

/*bounding-box-union*/
static pointer geopackF35bounding_box_union(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto geopackENT220;}
	local[0]= loadglobal(fqv[23]);
geopackENT220:
geopackENT219:
	if (n>2) maerror();
	local[1]= NIL;
	local[2]= NIL;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[3];
	local[3]= w;
	local[4]= fqv[25];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[2] = w;
	local[3]= NIL;
	local[4]= argv[0];
geopackWHL221:
	if (local[4]==NIL) goto geopackWHX222;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[2];
	local[6]= fqv[27];
	local[7]= local[3];
	local[8]= fqv[25];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[2] = w;
	goto geopackWHL221;
geopackWHX222:
	local[5]= NIL;
geopackBLK223:
	w = NIL;
	w = local[2];
	local[0]= w;
geopackBLK218:
	ctx->vsp=local; return(local[0]);}

/*:nvertex*/
static pointer geopackM224line_nvertex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT227;}
	local[0]= NIL;
geopackENT227:
geopackENT226:
	if (n>3) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
geopackBLK225:
	ctx->vsp=local; return(local[0]);}

/*:pvertex*/
static pointer geopackM228line_pvertex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT231;}
	local[0]= NIL;
geopackENT231:
geopackENT230:
	if (n>3) maerror();
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
geopackBLK229:
	ctx->vsp=local; return(local[0]);}

/*:vertices*/
static pointer geopackM232line_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
geopackBLK233:
	ctx->vsp=local; return(local[0]);}

/*:eq*/
static pointer geopackM234line_eq(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2]->c.obj.iv[1];
	local[0]= ((argv[0]->c.obj.iv[1])==(local[0])?T:NIL);
	if (local[0]==NIL) goto geopackAND236;
	local[0]= argv[2]->c.obj.iv[2];
	local[0]= ((argv[0]->c.obj.iv[2])==(local[0])?T:NIL);
geopackAND236:
	w = local[0];
	local[0]= w;
geopackBLK235:
	ctx->vsp=local; return(local[0]);}

/*:eql*/
static pointer geopackM237line_eql(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2]->c.obj.iv[1];
	local[0]= ((argv[0]->c.obj.iv[1])==(local[0])?T:NIL);
	if (local[0]==NIL) goto geopackAND240;
	local[0]= argv[2]->c.obj.iv[2];
	local[0]= ((argv[0]->c.obj.iv[2])==(local[0])?T:NIL);
geopackAND240:
	if (local[0]!=NIL) goto geopackOR239;
	local[0]= argv[2]->c.obj.iv[1];
	local[0]= ((argv[0]->c.obj.iv[2])==(local[0])?T:NIL);
	if (local[0]==NIL) goto geopackAND241;
	local[0]= argv[2]->c.obj.iv[2];
	local[0]= ((argv[0]->c.obj.iv[1])==(local[0])?T:NIL);
geopackAND241:
geopackOR239:
	w = local[0];
	local[0]= w;
geopackBLK238:
	ctx->vsp=local; return(local[0]);}

/*:equall*/
static pointer geopackM242line_equall(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2]->c.obj.iv[1];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)EQUAL(ctx,2,local+0); /*equal*/
	local[0]= w;
	if (w==NIL) goto geopackAND245;
	local[0]= argv[2]->c.obj.iv[2];
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)EQUAL(ctx,2,local+0); /*equal*/
	local[0]= w;
geopackAND245:
	if (local[0]!=NIL) goto geopackOR244;
	local[0]= argv[2]->c.obj.iv[1];
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)EQUAL(ctx,2,local+0); /*equal*/
	local[0]= w;
	if (w==NIL) goto geopackAND246;
	local[0]= argv[2]->c.obj.iv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)EQUAL(ctx,2,local+0); /*equal*/
	local[0]= w;
geopackAND246:
geopackOR244:
	w = local[0];
	local[0]= w;
geopackBLK243:
	ctx->vsp=local; return(local[0]);}

/*:parameter*/
static pointer geopackM247line_parameter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)VMINUS(ctx,2,local+0); /*v-*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)VMINUS(ctx,2,local+1); /*v-*/
	local[1]= w;
	local[2]= local[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)VINNERPRODUCT(ctx,2,local+2); /*v.*/
	local[2]= w;
	local[3]= local[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)VINNERPRODUCT(ctx,2,local+3); /*v.*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[0]= w;
geopackBLK248:
	ctx->vsp=local; return(local[0]);}

/*:point*/
static pointer geopackM249line_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,3,local+0,&ftab[1],fqv[11]); /*midpoint*/
	local[0]= w;
geopackBLK250:
	ctx->vsp=local; return(local[0]);}

/*:box*/
static pointer geopackM251line_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT254;}
	local[0]= NIL;
geopackENT254:
geopackENT253:
	if (n>3) maerror();
	local[1]= loadglobal(fqv[15]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[16];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= argv[0]->c.obj.iv[2];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	w = local[1];
	local[0]= w;
geopackBLK252:
	ctx->vsp=local; return(local[0]);}

/*:boxtest*/
static pointer geopackM255line_boxtest(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT258;}
	local[0]= NIL;
geopackENT258:
geopackENT257:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[25];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= fqv[28];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	w = local[2];
	local[0]= w;
geopackBLK256:
	ctx->vsp=local; return(local[0]);}

/*:length*/
static pointer geopackM259line_length(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)VDISTANCE(ctx,2,local+0); /*distance*/
	local[0]= w;
geopackBLK260:
	ctx->vsp=local; return(local[0]);}

/*:end-point*/
static pointer geopackM261line_end_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	if (argv[2]!=local[0]) goto geopackIF263;
	local[0]= argv[2];
	goto geopackIF264;
geopackIF263:
	local[0]= argv[0]->c.obj.iv[2];
	if (argv[2]!=local[0]) goto geopackIF265;
	local[0]= argv[2];
	goto geopackIF266;
geopackIF265:
	local[0]= NIL;
geopackIF266:
geopackIF264:
	w = local[0];
	local[0]= w;
geopackBLK262:
	ctx->vsp=local; return(local[0]);}

/*:direction*/
static pointer geopackM267line_direction(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)VMINUS(ctx,2,local+0); /*v-*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)VNORMALIZE(ctx,1,local+0); /*normalize-vector*/
	local[0]= w;
geopackBLK268:
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer geopackM269line_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,geopackFLET271,env,argv,local);
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[12]));
	local[3]= fqv[13];
	local[4]= argv[2];
	local[5]= argv[0]->c.obj.iv[1];
	w = local[0];
	ctx->vsp=local+6;
	w=geopackFLET271(ctx,1,local+5,w);
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[2];
	w = local[0];
	ctx->vsp=local+7;
	w=geopackFLET271(ctx,1,local+6,w);
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SENDMESSAGE(ctx,6,local+1); /*send-message*/
	local[0]= w;
geopackBLK270:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer geopackM272line_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[29], &argv[2], n-2, local+0, 1);
	if (n & (1<<0)) goto geopackKEY274;
	local[0] = NIL;
geopackKEY274:
	if (n & (1<<1)) goto geopackKEY275;
	local[1] = NIL;
geopackKEY275:
	if (local[0]==NIL) goto geopackIF276;
	argv[0]->c.obj.iv[1] = local[0];
	local[2]= argv[0]->c.obj.iv[1];
	goto geopackIF277;
geopackIF276:
	local[2]= NIL;
geopackIF277:
	if (local[1]==NIL) goto geopackIF278;
	argv[0]->c.obj.iv[2] = local[1];
	local[2]= argv[0]->c.obj.iv[2];
	goto geopackIF279;
geopackIF278:
	local[2]= NIL;
geopackIF279:
	w = argv[0];
	local[0]= w;
geopackBLK273:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geopackFLET271(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeint((eusinteger_t)30L);
	ctx->vsp=local+1;
	w=(*ftab[4])(ctx,1,local+0,&ftab[4],fqv[30]); /*make-string-output-stream*/
	local[0]= w;
	local[1]= fqv[31];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)PRINC(ctx,2,local+1); /*princ*/
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
geopackWHL280:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto geopackWHX281;
	local[3]= local[0];
	local[4]= fqv[32];
	local[5]= argv[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto geopackWHL280;
geopackWHX281:
	local[3]= NIL;
geopackBLK282:
	w = NIL;
	local[1]= local[0]->c.obj.iv[3];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	local[1]= w;
	local[2]= w;
	w = local[0];
	w->c.obj.iv[3] = local[2];
	local[1]= fqv[33];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)PRINC(ctx,2,local+1); /*princ*/
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,1,local+1,&ftab[5],fqv[34]); /*get-output-stream-string*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:foot*/
static pointer geopackM283line_foot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)VMINUS(ctx,2,local+1); /*v-*/
	local[1]= w;
	local[2]= local[1];
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)VMINUS(ctx,2,local+3); /*v-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)VINNERPRODUCT(ctx,2,local+2); /*v.*/
	local[2]= w;
	local[3]= local[1];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)VINNERPRODUCT(ctx,2,local+3); /*v.*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[0]= w;
geopackBLK284:
	ctx->vsp=local; return(local[0]);}

/*:common-perpendicular*/
static pointer geopackM285line_common_perpendicular(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= argv[2]->c.obj.iv[2];
	local[10]= argv[2]->c.obj.iv[1];
	ctx->vsp=local+11;
	w=(pointer)VMINUS(ctx,2,local+9); /*v-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)VNORM(ctx,1,local+9); /*norm*/
	local[1] = w;
	local[9]= local[1];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[1] = w;
	local[9]= argv[0]->c.obj.iv[2];
	local[10]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+11;
	w=(pointer)VMINUS(ctx,2,local+9); /*v-*/
	local[9]= w;
	local[10]= argv[2]->c.obj.iv[2];
	local[11]= argv[2]->c.obj.iv[1];
	ctx->vsp=local+12;
	w=(pointer)VMINUS(ctx,2,local+10); /*v-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)VINNERPRODUCT(ctx,2,local+9); /*v.*/
	local[2] = w;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[3] = w;
	local[9]= argv[0]->c.obj.iv[2];
	local[10]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+11;
	w=(pointer)VMINUS(ctx,2,local+9); /*v-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)VNORM(ctx,1,local+9); /*norm*/
	local[4] = w;
	local[9]= local[4];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[4] = w;
	local[9]= local[2];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	local[10]= local[1];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[0] = w;
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)ABS(ctx,1,local+9); /*abs*/
	local[9]= w;
	local[10]= loadglobal(fqv[35]);
	ctx->vsp=local+11;
	w=(pointer)LESSP(ctx,2,local+9); /*<*/
	if (w==NIL) goto geopackIF287;
	w = fqv[36];
	ctx->vsp=local+9;
	local[0]=w;
	goto geopackBLK286;
	goto geopackIF288;
geopackIF287:
	local[9]= argv[0]->c.obj.iv[2];
	local[10]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+11;
	w=(pointer)VMINUS(ctx,2,local+9); /*v-*/
	local[9]= w;
	local[10]= argv[2]->c.obj.iv[1];
	local[11]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+12;
	w=(pointer)VMINUS(ctx,2,local+10); /*v-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)VINNERPRODUCT(ctx,2,local+9); /*v.*/
	local[5] = w;
	local[9]= argv[2]->c.obj.iv[2];
	local[10]= argv[2]->c.obj.iv[1];
	ctx->vsp=local+11;
	w=(pointer)VMINUS(ctx,2,local+9); /*v-*/
	local[9]= w;
	local[10]= argv[2]->c.obj.iv[1];
	local[11]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+12;
	w=(pointer)VMINUS(ctx,2,local+10); /*v-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)VINNERPRODUCT(ctx,2,local+9); /*v.*/
	local[6] = w;
	local[9]= argv[0];
	local[10]= fqv[37];
	local[11]= local[1];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	local[12]= local[2];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[7] = w;
	local[9]= argv[2];
	local[10]= fqv[37];
	local[11]= local[3];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	local[12]= local[4];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[8] = w;
	local[9]= local[7];
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	ctx->vsp=local+9;
	local[0]=w;
	goto geopackBLK286;
geopackIF288:
	w = local[9];
	local[0]= w;
geopackBLK286:
	ctx->vsp=local; return(local[0]);}

/*:distance-point*/
static pointer geopackM289line_distance_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[38];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto geopackCON292;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)VDISTANCE(ctx,2,local+2); /*distance*/
	local[2]= w;
	goto geopackCON291;
geopackCON292:
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto geopackCON293;
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)VDISTANCE(ctx,2,local+2); /*distance*/
	local[2]= w;
	goto geopackCON291;
geopackCON293:
	local[2]= argv[0];
	local[3]= fqv[37];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)VDISTANCE(ctx,2,local+2); /*distance*/
	local[2]= w;
	goto geopackCON291;
geopackCON294:
	local[2]= NIL;
geopackCON291:
	w = local[2];
	local[0]= w;
geopackBLK290:
	ctx->vsp=local; return(local[0]);}

/*:distance-line*/
static pointer geopackM295line_distance_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= *(ovafptr(argv[2],fqv[39]));
	local[1]= *(ovafptr(argv[2],fqv[40]));
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= argv[0]->c.obj.iv[2];
	local[15]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+16;
	w=(pointer)VMINUS(ctx,2,local+14); /*v-*/
	local[14]= w;
	local[15]= local[1];
	local[16]= local[0];
	ctx->vsp=local+17;
	w=(pointer)VMINUS(ctx,2,local+15); /*v-*/
	local[15]= w;
	local[16]= local[14];
	local[17]= local[15];
	ctx->vsp=local+18;
	w=(pointer)VINNERPRODUCT(ctx,2,local+16); /*v.*/
	local[16]= w;
	local[17]= local[14];
	local[18]= local[14];
	ctx->vsp=local+19;
	w=(pointer)VINNERPRODUCT(ctx,2,local+17); /*v.*/
	local[17]= w;
	local[18]= local[15];
	local[19]= local[15];
	ctx->vsp=local+20;
	w=(pointer)VINNERPRODUCT(ctx,2,local+18); /*v.*/
	local[18]= w;
	local[19]= argv[0]->c.obj.iv[1];
	local[20]= local[0];
	ctx->vsp=local+21;
	w=(pointer)VMINUS(ctx,2,local+19); /*v-*/
	local[19]= w;
	local[20]= local[16];
	{ double x,y;
		y=fltval(local[16]); x=fltval(local[20]);
		local[20]=(makeflt(x * y));}
	local[21]= local[17];
	{ double x,y;
		y=fltval(local[18]); x=fltval(local[21]);
		local[21]=(makeflt(x * y));}
	{ double x,y;
		y=fltval(local[21]); x=fltval(local[20]);
		local[20]=(makeflt(x - y));}
	local[7] = local[20];
	local[20]= local[7];
	ctx->vsp=local+21;
	w=(pointer)ABS(ctx,1,local+20); /*abs*/
	local[20]= w;
	local[21]= makeflt(9.9999999999999991239646e-05);
	ctx->vsp=local+22;
	w=(pointer)GREATERP(ctx,2,local+20); /*>*/
	if (w==NIL) goto geopackIF297;
	local[20]= local[19];
	local[21]= local[14];
	ctx->vsp=local+22;
	w=(pointer)VINNERPRODUCT(ctx,2,local+20); /*v.*/
	local[12] = w;
	local[20]= local[19];
	local[21]= local[15];
	ctx->vsp=local+22;
	w=(pointer)VINNERPRODUCT(ctx,2,local+20); /*v.*/
	local[13] = w;
	local[20]= local[18];
	local[21]= local[12];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= local[16];
	local[22]= local[13];
	ctx->vsp=local+23;
	w=(pointer)TIMES(ctx,2,local+21); /***/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)MINUS(ctx,1,local+21); /*-*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	local[21]= local[7];
	ctx->vsp=local+22;
	w=(pointer)QUOTIENT(ctx,2,local+20); /*/*/
	local[2] = w;
	local[20]= local[16];
	local[21]= local[12];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= local[17];
	local[22]= local[13];
	ctx->vsp=local+23;
	w=(pointer)TIMES(ctx,2,local+21); /***/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)MINUS(ctx,1,local+21); /*-*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	local[21]= local[7];
	ctx->vsp=local+22;
	w=(pointer)QUOTIENT(ctx,2,local+20); /*/*/
	local[3] = w;
	local[20]= makeflt(0.0000000000000000000000e+00);
	local[21]= local[2];
	local[22]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+23;
	w=(pointer)LESSP(ctx,3,local+20); /*<*/
	if (w==NIL) goto geopackIF299;
	local[20]= makeflt(0.0000000000000000000000e+00);
	local[21]= local[3];
	local[22]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+23;
	w=(pointer)LESSP(ctx,3,local+20); /*<*/
	if (w==NIL) goto geopackIF299;
	local[20]= argv[0];
	local[21]= fqv[37];
	local[22]= local[2];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[20]= w;
	local[21]= argv[2];
	local[22]= fqv[37];
	local[23]= local[3];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,3,local+21); /*send*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)VDISTANCE(ctx,2,local+20); /*distance*/
	ctx->vsp=local+20;
	local[0]=w;
	goto geopackBLK296;
	goto geopackIF300;
geopackIF299:
	local[20]= NIL;
geopackIF300:
	goto geopackIF298;
geopackIF297:
	local[20]= NIL;
geopackIF298:
	local[20]= argv[0];
	local[21]= fqv[41];
	local[22]= local[0];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[8] = w;
	local[20]= argv[0];
	local[21]= fqv[41];
	local[22]= local[1];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[9] = w;
	local[20]= argv[2];
	local[21]= fqv[41];
	local[22]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[10] = w;
	local[20]= argv[2];
	local[21]= fqv[41];
	local[22]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[11] = w;
	local[20]= local[8];
	local[21]= local[9];
	local[22]= local[10];
	local[23]= local[11];
	ctx->vsp=local+24;
	w=(pointer)MIN(ctx,4,local+20); /*min*/
	local[0]= w;
geopackBLK296:
	ctx->vsp=local; return(local[0]);}

/*:distance*/
static pointer geopackM301line_distance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0];
	local[2]= fqv[37];
	local[3]= argv[0];
	local[4]= fqv[38];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VDISTANCE(ctx,2,local+0); /*distance*/
	local[0]= w;
geopackBLK302:
	ctx->vsp=local; return(local[0]);}

/*:distance*/
static pointer geopackM303line_distance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[6])(ctx,1,local+0,&ftab[6],fqv[42]); /*float-vector-p*/
	if (w==NIL) goto geopackCON306;
	local[0]= argv[0];
	local[1]= fqv[41];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto geopackCON305;
geopackCON306:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[43]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto geopackCON307;
	local[0]= argv[0];
	local[1]= fqv[44];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto geopackCON305;
geopackCON307:
	local[0]= NIL;
geopackCON305:
	w = local[0];
	local[0]= w;
geopackBLK304:
	ctx->vsp=local; return(local[0]);}

/*:colinear-point*/
static pointer geopackM308line_colinear_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT311;}
	local[0]= loadglobal(fqv[45]);
geopackENT311:
geopackENT310:
	if (n>4) maerror();
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[2];
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[7])(ctx,4,local+1,&ftab[7],fqv[46]); /*colinear-p*/
	local[0]= w;
geopackBLK309:
	ctx->vsp=local; return(local[0]);}

/*:on-line-point*/
static pointer geopackM312line_on_line_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT315;}
	local[0]= loadglobal(fqv[45]);
geopackENT315:
geopackENT314:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)VDISTANCE(ctx,2,local+3); /*distance*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+6;
	w=(pointer)VDISTANCE(ctx,2,local+4); /*distance*/
	{ double x,y;
		y=fltval(w); x=fltval(local[3]);
		local[3]=(makeflt(x + y));}
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+6;
	w=(pointer)VDISTANCE(ctx,2,local+4); /*distance*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)geopackF25eps__(ctx,3,local+3); /*eps<=*/
	local[0]= w;
geopackBLK313:
	ctx->vsp=local; return(local[0]);}

/*:colinear-line*/
static pointer geopackM316line_colinear_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT319;}
	local[0]= loadglobal(fqv[45]);
geopackENT319:
geopackENT318:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[47];
	local[3]= argv[2]->c.obj.iv[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[47];
	local[4]= argv[2]->c.obj.iv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	local[3]= local[1];
	if (local[3]==NIL) goto geopackAND320;
	local[3]= local[2];
	if (local[3]==NIL) goto geopackAND320;
	local[3]= T;
geopackAND320:
	w = local[3];
	local[0]= w;
geopackBLK317:
	ctx->vsp=local; return(local[0]);}

/*:colinear-line-intersection*/
static pointer geopackM321line_colinear_line_intersection(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2]->c.obj.iv[1];
	local[1]= argv[2]->c.obj.iv[2];
	local[2]= argv[0];
	local[3]= fqv[48];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[48];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)GREATERP(ctx,2,local+6); /*>*/
	if (w==NIL) goto geopackIF323;
	local[6]= local[2];
	local[7]= local[3];
	local[3] = local[6];
	local[2] = local[7];
	w = NIL;
	local[6]= w;
	goto geopackIF324;
geopackIF323:
	local[6]= NIL;
geopackIF324:
	local[6]= local[3];
	local[7]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)LESSP(ctx,2,local+6); /*<*/
	if (w!=NIL) goto geopackOR327;
	local[6]= local[2];
	local[7]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)GREATERP(ctx,2,local+6); /*>*/
	if (w!=NIL) goto geopackOR327;
	goto geopackCON326;
geopackOR327:
	local[6]= NIL;
	goto geopackCON325;
geopackCON326:
	local[6]= makeflt(0.0000000000000000000000e+00);
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)MAX(ctx,2,local+6); /*max*/
	local[4] = w;
	local[6]= makeflt(1.0000000000000000000000e+00);
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)MIN(ctx,2,local+6); /*min*/
	local[5] = w;
	local[6]= argv[0];
	local[7]= fqv[37];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[37];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)geopackF36make_line(ctx,2,local+6); /*make-line*/
	local[6]= w;
	goto geopackCON325;
geopackCON328:
	local[6]= NIL;
geopackCON325:
	w = local[6];
	local[0]= w;
geopackBLK322:
	ctx->vsp=local; return(local[0]);}

/*:coplanar*/
static pointer geopackM329line_coplanar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT332;}
	local[0]= loadglobal(fqv[45]);
geopackENT332:
geopackENT331:
	if (n>4) maerror();
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= argv[2]->c.obj.iv[1];
	local[4]= argv[2]->c.obj.iv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[8])(ctx,5,local+1,&ftab[8],fqv[49]); /*coplanar-p*/
	local[0]= w;
geopackBLK330:
	ctx->vsp=local; return(local[0]);}

/*:project*/
static pointer geopackM333line_project(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[50];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= fqv[50];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
geopackBLK334:
	ctx->vsp=local; return(local[0]);}

/*:intersection*/
static pointer geopackM335line_intersection(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[2]->c.obj.iv[1];
	local[3]= argv[2]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)LINEINTERSECTION3(ctx,4,local+0); /*line-intersection3*/
	local[0]= w;
geopackBLK336:
	ctx->vsp=local; return(local[0]);}

/*:intersect-line*/
static pointer geopackM337line_intersect_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT340;}
	local[0]= loadglobal(fqv[35]);
geopackENT340:
geopackENT339:
	if (n>4) maerror();
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= argv[2]->c.obj.iv[1];
	local[4]= argv[2]->c.obj.iv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LINEINTERSECTION3(ctx,5,local+1); /*line-intersection3*/
	local[1]= w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	if (local[1]!=NIL) goto geopackCON342;
	local[8]= argv[0];
	local[9]= fqv[47];
	local[10]= argv[2]->c.obj.iv[1];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[2] = w;
	if (local[2]!=NIL) goto geopackIF343;
	w = fqv[36];
	ctx->vsp=local+8;
	local[0]=w;
	goto geopackBLK338;
	goto geopackIF344;
geopackIF343:
	local[8]= NIL;
geopackIF344:
	local[8]= argv[0];
	local[9]= fqv[47];
	local[10]= argv[2]->c.obj.iv[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[3] = w;
	if (local[3]!=NIL) goto geopackIF345;
	w = fqv[36];
	ctx->vsp=local+8;
	local[0]=w;
	goto geopackBLK338;
	goto geopackIF346;
geopackIF345:
	local[8]= NIL;
geopackIF346:
	local[8]= local[3];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto geopackIF347;
	local[8]= local[3];
	local[9]= local[2];
	local[2] = local[8];
	local[3] = local[9];
	w = NIL;
	local[8]= w;
	goto geopackIF348;
geopackIF347:
	local[8]= NIL;
geopackIF348:
	local[8]= local[3];
	local[9]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+10;
	w=(pointer)geopackF23eps_(ctx,2,local+8); /*eps<*/
	if (w!=NIL) goto geopackOR351;
	local[8]= local[2];
	local[9]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+10;
	w=(pointer)geopackF24eps_(ctx,2,local+8); /*eps>*/
	if (w!=NIL) goto geopackOR351;
	goto geopackIF349;
geopackOR351:
	w = fqv[51];
	ctx->vsp=local+8;
	local[0]=w;
	goto geopackBLK338;
	goto geopackIF350;
geopackIF349:
	local[8]= NIL;
geopackIF350:
	local[8]= argv[2];
	local[9]= fqv[47];
	local[10]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[6] = w;
	local[8]= argv[2];
	local[9]= fqv[47];
	local[10]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[7] = w;
	if (local[6]==NIL) goto geopackAND354;
	if (local[7]==NIL) goto geopackAND354;
	goto geopackIF352;
geopackAND354:
	w = fqv[36];
	ctx->vsp=local+8;
	local[0]=w;
	goto geopackBLK338;
	goto geopackIF353;
geopackIF352:
	local[8]= NIL;
geopackIF353:
	local[8]= local[7];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto geopackIF355;
	local[8]= local[7];
	local[9]= local[6];
	local[6] = local[8];
	local[7] = local[9];
	w = NIL;
	local[8]= w;
	goto geopackIF356;
geopackIF355:
	local[8]= NIL;
geopackIF356:
	local[8]= fqv[52];
	local[9]= makeflt(0.0000000000000000000000e+00);
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)MAX(ctx,2,local+9); /*max*/
	local[9]= w;
	local[10]= makeflt(1.0000000000000000000000e+00);
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)MIN(ctx,2,local+10); /*min*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	local[9]= w;
	local[10]= makeflt(0.0000000000000000000000e+00);
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)MAX(ctx,2,local+10); /*max*/
	local[10]= w;
	local[11]= makeflt(1.0000000000000000000000e+00);
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)MIN(ctx,2,local+11); /*min*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,2,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,3,local+8); /*list*/
	local[8]= w;
	goto geopackCON341;
geopackCON342:
	local[8]= makeflt(0.0000000000000000000000e+00);
	local[9]= local[2];
	local[10]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(pointer)geopackF29eps_in_range(ctx,3,local+8); /*eps-in-range*/
	if (w==NIL) goto geopackCON357;
	local[8]= makeflt(0.0000000000000000000000e+00);
	local[9]= local[3];
	local[10]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(pointer)geopackF29eps_in_range(ctx,3,local+8); /*eps-in-range*/
	if (w==NIL) goto geopackCON357;
	local[8]= fqv[53];
	local[9]= local[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,3,local+8); /*list*/
	local[8]= w;
	goto geopackCON341;
geopackCON357:
	local[8]= NIL;
	goto geopackCON341;
geopackCON358:
	local[8]= NIL;
geopackCON341:
	w = local[8];
	local[0]= w;
geopackBLK338:
	ctx->vsp=local; return(local[0]);}

/*make-line*/
static pointer geopackF36make_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[43]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[24];
	local[3]= fqv[54];
	local[4]= argv[0];
	local[5]= fqv[55];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	w = local[0];
	local[0]= w;
geopackBLK359:
	ctx->vsp=local; return(local[0]);}

/*:faces*/
static pointer geopackM360edge_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
geopackBLK361:
	ctx->vsp=local; return(local[0]);}

/*:pvertex*/
static pointer geopackM362edge_pvertex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	if (argv[0]->c.obj.iv[3]!=local[0]) goto geopackCON365;
	local[0]= argv[0]->c.obj.iv[1];
	goto geopackCON364;
geopackCON365:
	local[0]= argv[2];
	if (argv[0]->c.obj.iv[4]!=local[0]) goto geopackCON366;
	local[0]= argv[0]->c.obj.iv[2];
	goto geopackCON364;
geopackCON366:
	local[0]= fqv[56];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
	goto geopackCON364;
geopackCON367:
	local[0]= NIL;
geopackCON364:
	w = local[0];
	local[0]= w;
geopackBLK363:
	ctx->vsp=local; return(local[0]);}

/*:nvertex*/
static pointer geopackM368edge_nvertex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	if (argv[0]->c.obj.iv[3]!=local[0]) goto geopackCON371;
	local[0]= argv[0]->c.obj.iv[2];
	goto geopackCON370;
geopackCON371:
	local[0]= argv[2];
	if (argv[0]->c.obj.iv[4]!=local[0]) goto geopackCON372;
	local[0]= argv[0]->c.obj.iv[1];
	goto geopackCON370;
geopackCON372:
	local[0]= fqv[57];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
	goto geopackCON370;
geopackCON373:
	local[0]= NIL;
geopackCON370:
	w = local[0];
	local[0]= w;
geopackBLK369:
	ctx->vsp=local; return(local[0]);}

/*:next-edge*/
static pointer geopackM374edge_next_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[58];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
geopackBLK375:
	ctx->vsp=local; return(local[0]);}

/*:next-vertex*/
static pointer geopackM376edge_next_vertex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[58];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[55];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
geopackBLK377:
	ctx->vsp=local; return(local[0]);}

/*:direction*/
static pointer geopackM378edge_direction(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT381;}
	local[0]= argv[0]->c.obj.iv[3];
geopackENT381:
geopackENT380:
	if (n>3) maerror();
	local[1]= local[0];
	if (argv[0]->c.obj.iv[3]!=local[1]) goto geopackCON383;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)VMINUS(ctx,2,local+1); /*v-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VNORMALIZE(ctx,1,local+1); /*normalize-vector*/
	local[1]= w;
	goto geopackCON382;
geopackCON383:
	local[1]= local[0];
	if (argv[0]->c.obj.iv[4]!=local[1]) goto geopackCON384;
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)VMINUS(ctx,2,local+1); /*v-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VNORMALIZE(ctx,1,local+1); /*normalize-vector*/
	local[1]= w;
	goto geopackCON382;
geopackCON384:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)geopackF18facep(ctx,1,local+1); /*facep*/
	if (w==NIL) goto geopackCON385;
	local[1]= NIL;
	local[2]= local[0];
	local[3]= fqv[59];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
geopackWHL386:
	if (local[2]==NIL) goto geopackWHX387;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= argv[0];
	local[4]= local[1];
	local[5]= fqv[60];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	if (memq(local[3],w)==NIL) goto geopackIF389;
	local[3]= argv[0];
	local[4]= fqv[61];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	ctx->vsp=local+3;
	local[0]=w;
	goto geopackBLK379;
	goto geopackIF390;
geopackIF389:
	local[3]= NIL;
geopackIF390:
	goto geopackWHL386;
geopackWHX387:
	local[3]= NIL;
geopackBLK388:
	w = NIL;
	local[1]= fqv[62];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
	goto geopackCON382;
geopackCON385:
	local[1]= fqv[63];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
	goto geopackCON382;
geopackCON391:
	local[1]= NIL;
geopackCON382:
	w = local[1];
	local[0]= w;
geopackBLK379:
	ctx->vsp=local; return(local[0]);}

/*:next-edge-angle*/
static pointer geopackM392edge_next_edge_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[61];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= fqv[58];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[61];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= fqv[64];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)geopackF8vector_angle(ctx,3,local+0); /*vector-angle*/
	local[0]= w;
geopackBLK393:
	ctx->vsp=local; return(local[0]);}

/*:previous-edge-angle*/
static pointer geopackM394edge_previous_edge_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[61];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= fqv[65];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[61];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= fqv[64];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)geopackF8vector_angle(ctx,3,local+0); /*vector-angle*/
	local[0]= w;
geopackBLK395:
	ctx->vsp=local; return(local[0]);}

/*:body*/
static pointer geopackM396edge_body(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[3]==NIL) goto geopackCON399;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[66];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto geopackCON398;
geopackCON399:
	if (argv[0]->c.obj.iv[4]==NIL) goto geopackCON400;
	local[0]= argv[0]->c.obj.iv[4];
	local[1]= fqv[66];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto geopackCON398;
geopackCON400:
	local[0]= NIL;
geopackCON398:
	w = local[0];
	local[0]= w;
geopackBLK397:
	ctx->vsp=local; return(local[0]);}

/*:pface*/
static pointer geopackM401edge_pface(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geopackCON404;
	local[0]= argv[3];
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geopackCON404;
	local[0]= argv[0]->c.obj.iv[3];
	goto geopackCON403;
geopackCON404:
	local[0]= argv[3];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geopackCON405;
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geopackCON405;
	local[0]= argv[0]->c.obj.iv[4];
	goto geopackCON403;
geopackCON405:
	local[0]= fqv[67];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
	goto geopackCON403;
geopackCON406:
	local[0]= NIL;
geopackCON403:
	w = local[0];
	local[0]= w;
geopackBLK402:
	ctx->vsp=local; return(local[0]);}

/*:nface*/
static pointer geopackM407edge_nface(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geopackCON410;
	local[0]= argv[3];
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geopackCON410;
	local[0]= argv[0]->c.obj.iv[4];
	goto geopackCON409;
geopackCON410:
	local[0]= argv[3];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geopackCON411;
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geopackCON411;
	local[0]= argv[0]->c.obj.iv[3];
	goto geopackCON409;
geopackCON411:
	local[0]= fqv[68];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
	goto geopackCON409;
geopackCON412:
	local[0]= NIL;
geopackCON409:
	w = local[0];
	local[0]= w;
geopackBLK408:
	ctx->vsp=local; return(local[0]);}

/*:another-face*/
static pointer geopackM413edge_another_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	if (argv[0]->c.obj.iv[3]!=local[0]) goto geopackIF415;
	local[0]= argv[0]->c.obj.iv[4];
	goto geopackIF416;
geopackIF415:
	local[0]= argv[2];
	if (argv[0]->c.obj.iv[4]!=local[0]) goto geopackIF417;
	local[0]= argv[0]->c.obj.iv[3];
	goto geopackIF418;
geopackIF417:
	local[0]= fqv[69];
	ctx->vsp=local+1;
	w=(*ftab[9])(ctx,1,local+0,&ftab[9],fqv[70]); /*warn*/
	local[0]= w;
geopackIF418:
geopackIF416:
	w = local[0];
	local[0]= w;
geopackBLK414:
	ctx->vsp=local; return(local[0]);}

/*:binormal*/
static pointer geopackM419edge_binormal(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	if (argv[0]->c.obj.iv[3]!=local[0]) goto geopackCON422;
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)VMINUS(ctx,2,local+0); /*v-*/
	local[0]= w;
	goto geopackCON421;
geopackCON422:
	local[0]= argv[2];
	if (argv[0]->c.obj.iv[4]!=local[0]) goto geopackCON423;
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)VMINUS(ctx,2,local+0); /*v-*/
	local[0]= w;
	goto geopackCON421;
geopackCON423:
	local[0]= argv[0];
	local[1]= fqv[71];
	local[2]= fqv[72];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto geopackCON421;
geopackCON424:
	local[0]= NIL;
geopackCON421:
	local[1]= argv[2];
	local[2]= fqv[64];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+0); /*v**/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)VNORMALIZE(ctx,1,local+0); /*normalize-vector*/
	local[0]= w;
geopackBLK420:
	ctx->vsp=local; return(local[0]);}

/*:angle*/
static pointer geopackM425edge_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
geopackBLK426:
	ctx->vsp=local; return(local[0]);}

/*:approximated-p*/
static pointer geopackM427edge_approximated_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[6];
	w = makeint((eusinteger_t)1L);
	local[0]= (pointer)((eusinteger_t)local[0] & (eusinteger_t)w);
	w = ((makeint((eusinteger_t)1L))==(local[0])?T:NIL);
	local[0]= w;
geopackBLK428:
	ctx->vsp=local; return(local[0]);}

/*:flags*/
static pointer geopackM429edge_flags(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[6];
	local[0]= w;
geopackBLK430:
	ctx->vsp=local; return(local[0]);}

/*:contourp*/
static pointer geopackM431edge_contourp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[0]->c.obj.iv[3]==NIL) goto geopackIF433;
	if (argv[0]->c.obj.iv[4]==NIL) goto geopackIF433;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[73];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[4];
	local[2]= fqv[73];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= local[0];
	local[3]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	local[2]= w;
	if (w==NIL) goto geopackAND436;
	local[2]= local[1];
	local[3]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	local[2]= w;
geopackAND436:
	if (local[2]!=NIL) goto geopackOR435;
	local[2]= local[0];
	local[3]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	local[2]= w;
	if (w==NIL) goto geopackAND437;
	local[2]= local[1];
	local[3]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	local[2]= w;
geopackAND437:
geopackOR435:
	w = local[2];
	local[0]= w;
	goto geopackIF434;
geopackIF433:
	local[0]= T;
geopackIF434:
	w = local[0];
	local[0]= w;
geopackBLK432:
	ctx->vsp=local; return(local[0]);}

/*:set-approximated-flag*/
static pointer geopackM438edge_set_approximated_flag(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT441;}
	local[0]= makeflt(6.9999999999999973354647e-01);
geopackENT441:
geopackENT440:
	if (n>3) maerror();
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,1,local+1); /*-*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[5];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,3,local+1); /*<*/
	if (w==NIL) goto geopackIF442;
	local[1]= argv[0]->c.obj.iv[6];
	w = makeint((eusinteger_t)1L);
	argv[0]->c.obj.iv[6] = (pointer)((eusinteger_t)local[1] | (eusinteger_t)w);
	local[1]= argv[0]->c.obj.iv[6];
	goto geopackIF443;
geopackIF442:
	local[1]= argv[0]->c.obj.iv[6];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)LOGNOT(ctx,1,local+2); /*lognot*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LOGAND(ctx,2,local+1); /*logand*/
	argv[0]->c.obj.iv[6] = w;
	local[1]= argv[0]->c.obj.iv[6];
geopackIF443:
	w = local[1];
	local[0]= w;
geopackBLK439:
	ctx->vsp=local; return(local[0]);}

/*:invert*/
static pointer geopackM444edge_invert(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[0] = argv[0]->c.obj.iv[4];
	argv[0]->c.obj.iv[4] = argv[0]->c.obj.iv[3];
	argv[0]->c.obj.iv[3] = local[0];
	w = argv[0]->c.obj.iv[3];
	w = argv[0];
	local[0]= w;
geopackBLK445:
	ctx->vsp=local; return(local[0]);}

/*:set-angle*/
static pointer geopackM446edge_set_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3]->c.obj.iv[1];
	local[1]= argv[0]->c.obj.iv[4]->c.obj.iv[1];
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)VMINUS(ctx,2,local+2); /*v-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VNORMALIZE(ctx,1,local+2); /*normalize-vector*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)geopackF8vector_angle(ctx,3,local+0); /*vector-angle*/
	argv[0]->c.obj.iv[5] = w;
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
geopackBLK447:
	ctx->vsp=local; return(local[0]);}

/*:set-face*/
static pointer geopackM448edge_set_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[2];
	if (argv[0]->c.obj.iv[1]!=local[0]) goto geopackCON451;
	local[0]= argv[3];
	if (argv[0]->c.obj.iv[2]!=local[0]) goto geopackCON451;
	argv[0]->c.obj.iv[3] = argv[4];
	local[0]= argv[0]->c.obj.iv[3];
	goto geopackCON450;
geopackCON451:
	local[0]= argv[3];
	if (argv[0]->c.obj.iv[1]!=local[0]) goto geopackCON452;
	local[0]= argv[2];
	if (argv[0]->c.obj.iv[2]!=local[0]) goto geopackCON452;
	argv[0]->c.obj.iv[4] = argv[4];
	local[0]= argv[0]->c.obj.iv[4];
	goto geopackCON450;
geopackCON452:
	local[0]= argv[0];
	local[1]= fqv[71];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto geopackCON450;
geopackCON453:
	local[0]= NIL;
geopackCON450:
	w = local[0];
	local[0]= w;
geopackBLK449:
	ctx->vsp=local; return(local[0]);}

/*:contact*/
static pointer geopackM454edge_contact(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[75];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= loadglobal(fqv[23]);
	local[2]= loadglobal(fqv[76]);
	local[3]= local[0];
	if (fqv[36]==local[3]) goto geopackIF456;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)VMINUS(ctx,2,local+3); /*v-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)VNORM(ctx,1,local+3); /*norm*/
	local[3]= w;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	if (w==NIL) goto geopackIF458;
	local[3]= local[2];
	local[4]= argv[0];
	local[5]= fqv[48];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000000000e+00);
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,3,local+3); /*<*/
	if (w==NIL) goto geopackIF458;
	local[3]= makeflt(-1.0000000000000000000000e+00);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= argv[2];
	local[5]= fqv[48];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000000000e+00);
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,3,local+3); /*<*/
	if (w==NIL) goto geopackIF458;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	goto geopackIF459;
geopackIF458:
	local[3]= NIL;
geopackIF459:
	goto geopackIF457;
geopackIF456:
	local[3]= NIL;
geopackIF457:
	w = local[3];
	local[0]= w;
geopackBLK455:
	ctx->vsp=local; return(local[0]);}

/*:neighborpoints*/
static pointer geopackM460edge_neighborpoints(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[77];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= makeflt(2.0000000000000000000000e+00);
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,2,local+1); /*scale*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[77];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VMINUS(ctx,2,local+1); /*v-*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= *(ovafptr(argv[0]->c.obj.iv[3],fqv[78]));
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+6;
	w=(pointer)VMINUS(ctx,2,local+4); /*v-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+3); /*v**/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,2,local+2); /*v+*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= *(ovafptr(argv[0]->c.obj.iv[4],fqv[78]));
	local[5]= argv[0]->c.obj.iv[1];
	local[6]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+7;
	w=(pointer)VMINUS(ctx,2,local+5); /*v-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+4); /*v**/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)VPLUS(ctx,2,local+3); /*v+*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,4,local+0); /*list*/
	local[0]= w;
geopackBLK461:
	ctx->vsp=local; return(local[0]);}

/*:anothervertex*/
static pointer geopackM462edge_anothervertex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)VMINUS(ctx,2,local+0); /*v-*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)VNORM(ctx,1,local+0); /*norm*/
	local[0]= makeflt((double)fabs(fltval(w)));
	local[1]= loadglobal(fqv[79]);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto geopackIF464;
	local[0]= argv[0]->c.obj.iv[1];
	goto geopackIF465;
geopackIF464:
	local[0]= argv[0]->c.obj.iv[2];
geopackIF465:
	w = local[0];
	local[0]= w;
geopackBLK463:
	ctx->vsp=local; return(local[0]);}

/*:color*/
static pointer geopackM466edge_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT469;}
	local[0]= NIL;
geopackENT469:
geopackENT468:
	if (n>3) maerror();
	if (local[0]==NIL) goto geopackIF470;
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= fqv[80];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= w;
	goto geopackIF471;
geopackIF470:
	local[1]= argv[0];
	local[2]= fqv[80];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[0] = w;
	if (local[0]==NIL) goto geopackIF472;
	local[1]= local[0];
	goto geopackIF473;
geopackIF472:
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[80];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
geopackIF473:
geopackIF471:
	w = local[1];
	local[0]= w;
geopackBLK467:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer geopackM474edge_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
geopackRST476:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[81], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto geopackKEY477;
	local[1] = NIL;
geopackKEY477:
	if (n & (1<<1)) goto geopackKEY478;
	local[2] = NIL;
geopackKEY478:
	if (n & (1<<2)) goto geopackKEY479;
	local[3] = NIL;
geopackKEY479:
	if (n & (1<<3)) goto geopackKEY480;
	local[4] = NIL;
geopackKEY480:
	if (n & (1<<4)) goto geopackKEY481;
	local[5] = makeint((eusinteger_t)0L);
geopackKEY481:
	local[6]= (pointer)get_sym_func(fqv[82]);
	local[7]= argv[0];
	local[8]= *(ovafptr(argv[1],fqv[12]));
	local[9]= fqv[24];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,5,local+6); /*apply*/
	if (local[1]==NIL) goto geopackIF482;
	argv[0]->c.obj.iv[3] = local[1];
	local[6]= argv[0]->c.obj.iv[3];
	goto geopackIF483;
geopackIF482:
	local[6]= NIL;
geopackIF483:
	if (local[2]==NIL) goto geopackIF484;
	argv[0]->c.obj.iv[4] = local[2];
	local[6]= argv[0]->c.obj.iv[4];
	goto geopackIF485;
geopackIF484:
	local[6]= NIL;
geopackIF485:
	if (local[3]==NIL) goto geopackIF486;
	argv[0]->c.obj.iv[5] = local[3];
	local[6]= argv[0]->c.obj.iv[5];
	goto geopackIF487;
geopackIF486:
	local[6]= NIL;
geopackIF487:
	argv[0]->c.obj.iv[6] = local[5];
	if (local[4]==NIL) goto geopackIF488;
	local[6]= argv[0];
	local[7]= fqv[83];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	goto geopackIF489;
geopackIF488:
	local[6]= NIL;
geopackIF489:
	w = argv[0];
	local[0]= w;
geopackBLK475:
	ctx->vsp=local; return(local[0]);}

/*:center-coordinates*/
static pointer geopackM490edge_center_coordinates(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)VMINUS(ctx,2,local+0); /*v-*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)VNORMALIZE(ctx,1,local+0); /*normalize-vector*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[84];
	ctx->vsp=local+3;
	w=(pointer)VDISTANCE(ctx,2,local+1); /*distance*/
	local[1]= w;
	{ double left,right;
		right=fltval(makeflt(9.9999999999999991239646e-05)); left=fltval(local[1]);
	if (left >= right) goto geopackIF492;}
	local[1]= fqv[85];
	goto geopackIF493;
geopackIF492:
	local[1]= fqv[86];
geopackIF493:
	local[2]= local[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+2); /*v**/
	local[2]= w;
	local[3]= local[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+3); /*v**/
	local[1] = w;
	local[3]= loadglobal(fqv[87]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[24];
	local[6]= fqv[88];
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(*ftab[10])(ctx,3,local+7,&ftab[10],fqv[89]); /*matrix*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TRANSPOSE(ctx,1,local+7); /*transpose*/
	local[7]= w;
	local[8]= fqv[90];
	local[9]= makeflt(5.0000000000000000000000e-01);
	local[10]= argv[0]->c.obj.iv[2];
	local[11]= argv[0]->c.obj.iv[1];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)VPLUS(ctx,3,local+10); /*v+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,2,local+9); /*scale*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,6,local+4); /*send*/
	w = local[3];
	local[0]= w;
geopackBLK491:
	ctx->vsp=local; return(local[0]);}

/*:pwing*/
static pointer geopackM494edge_pwing(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[91];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= local[0];
geopackWHL496:
	if (local[2]==NIL) goto geopackWHX497;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	if (argv[0]==local[3]) goto geopackIF499;
	local[3]= local[1]->c.obj.iv[1];
	if (argv[0]->c.obj.iv[1]==local[3]) goto geopackOR501;
	local[3]= local[1]->c.obj.iv[2];
	if (argv[0]->c.obj.iv[1]==local[3]) goto geopackOR501;
	goto geopackIF499;
geopackOR501:
	w = local[1];
	ctx->vsp=local+3;
	local[0]=w;
	goto geopackBLK495;
	goto geopackIF500;
geopackIF499:
	local[3]= NIL;
geopackIF500:
	goto geopackWHL496;
geopackWHX497:
	local[3]= NIL;
geopackBLK498:
	w = NIL;
	local[1]= fqv[92];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[0]= w;
geopackBLK495:
	ctx->vsp=local; return(local[0]);}

/*:pcwing*/
static pointer geopackM502edge_pcwing(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[91];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= local[0];
geopackWHL504:
	if (local[2]==NIL) goto geopackWHX505;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	if (argv[0]==local[3]) goto geopackIF507;
	local[3]= local[1]->c.obj.iv[1];
	if (argv[0]->c.obj.iv[2]==local[3]) goto geopackOR509;
	local[3]= local[1]->c.obj.iv[2];
	if (argv[0]->c.obj.iv[2]==local[3]) goto geopackOR509;
	goto geopackIF507;
geopackOR509:
	w = local[1];
	ctx->vsp=local+3;
	local[0]=w;
	goto geopackBLK503;
	goto geopackIF508;
geopackIF507:
	local[3]= NIL;
geopackIF508:
	goto geopackWHL504;
geopackWHX505:
	local[3]= NIL;
geopackBLK506:
	w = NIL;
	local[1]= fqv[93];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[0]= w;
geopackBLK503:
	ctx->vsp=local; return(local[0]);}

/*:nwing*/
static pointer geopackM510edge_nwing(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[4];
	local[1]= fqv[91];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= local[0];
geopackWHL512:
	if (local[2]==NIL) goto geopackWHX513;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	if (argv[0]==local[3]) goto geopackIF515;
	local[3]= local[1]->c.obj.iv[1];
	if (argv[0]->c.obj.iv[2]==local[3]) goto geopackOR517;
	local[3]= local[1]->c.obj.iv[2];
	if (argv[0]->c.obj.iv[2]==local[3]) goto geopackOR517;
	goto geopackIF515;
geopackOR517:
	w = local[1];
	ctx->vsp=local+3;
	local[0]=w;
	goto geopackBLK511;
	goto geopackIF516;
geopackIF515:
	local[3]= NIL;
geopackIF516:
	goto geopackWHL512;
geopackWHX513:
	local[3]= NIL;
geopackBLK514:
	w = NIL;
	local[1]= fqv[94];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[0]= w;
geopackBLK511:
	ctx->vsp=local; return(local[0]);}

/*:ncwing*/
static pointer geopackM518edge_ncwing(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[4];
	local[1]= fqv[91];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= local[0];
geopackWHL520:
	if (local[2]==NIL) goto geopackWHX521;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	if (argv[0]==local[3]) goto geopackIF523;
	local[3]= local[1]->c.obj.iv[1];
	if (argv[0]->c.obj.iv[1]==local[3]) goto geopackOR525;
	local[3]= local[1]->c.obj.iv[2];
	if (argv[0]->c.obj.iv[1]==local[3]) goto geopackOR525;
	goto geopackIF523;
geopackOR525:
	w = local[1];
	ctx->vsp=local+3;
	local[0]=w;
	goto geopackBLK519;
	goto geopackIF524;
geopackIF523:
	local[3]= NIL;
geopackIF524:
	goto geopackWHL520;
geopackWHX521:
	local[3]= NIL;
geopackBLK522:
	w = NIL;
	local[1]= fqv[95];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[0]= w;
geopackBLK519:
	ctx->vsp=local; return(local[0]);}

/*:connected-vertex*/
static pointer geopackM526edge_connected_vertex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2]->c.obj.iv[1];
	if (argv[0]->c.obj.iv[1]!=local[0]) goto geopackCON529;
	local[0]= argv[0]->c.obj.iv[1];
	goto geopackCON528;
geopackCON529:
	local[0]= argv[2]->c.obj.iv[1];
	if (argv[0]->c.obj.iv[2]!=local[0]) goto geopackCON530;
	local[0]= argv[0]->c.obj.iv[2];
	goto geopackCON528;
geopackCON530:
	local[0]= argv[2]->c.obj.iv[2];
	if (argv[0]->c.obj.iv[1]!=local[0]) goto geopackCON531;
	local[0]= argv[0]->c.obj.iv[1];
	goto geopackCON528;
geopackCON531:
	local[0]= argv[2]->c.obj.iv[2];
	if (argv[0]->c.obj.iv[2]!=local[0]) goto geopackCON532;
	local[0]= argv[0]->c.obj.iv[2];
	goto geopackCON528;
geopackCON532:
	local[0]= fqv[96];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
	goto geopackCON528;
geopackCON533:
	local[0]= NIL;
geopackCON528:
	w = local[0];
	local[0]= w;
geopackBLK527:
	ctx->vsp=local; return(local[0]);}

/*:replace-face*/
static pointer geopackM534edge_replace_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geopackCON537;
	argv[0]->c.obj.iv[3] = argv[3];
	local[0]= argv[0]->c.obj.iv[3];
	goto geopackCON536;
geopackCON537:
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geopackCON538;
	argv[0]->c.obj.iv[4] = argv[3];
	local[0]= argv[0]->c.obj.iv[4];
	goto geopackCON536;
geopackCON538:
	local[0]= fqv[97];
	local[1]= argv[0];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,3,local+0); /*error*/
	local[0]= w;
	goto geopackCON536;
geopackCON539:
	local[0]= NIL;
geopackCON536:
	w = local[0];
	local[0]= w;
geopackBLK535:
	ctx->vsp=local; return(local[0]);}

/*winged-edge-p*/
static pointer geopackF37winged_edge_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[98]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
geopackBLK540:
	ctx->vsp=local; return(local[0]);}

/*:set-wings*/
static pointer geopackM541winged_edge_set_wings(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[12]));
	local[2]= fqv[99];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	argv[0]->c.obj.iv[7] = w;
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[12]));
	local[2]= fqv[100];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	argv[0]->c.obj.iv[9] = w;
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[12]));
	local[2]= fqv[101];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	argv[0]->c.obj.iv[8] = w;
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[12]));
	local[2]= fqv[102];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	argv[0]->c.obj.iv[10] = w;
	w = argv[0];
	local[0]= w;
geopackBLK542:
	ctx->vsp=local; return(local[0]);}

/*:pwing*/
static pointer geopackM543winged_edge_pwing(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[7];
	local[0]= w;
geopackBLK544:
	ctx->vsp=local; return(local[0]);}

/*:nwing*/
static pointer geopackM545winged_edge_nwing(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[9];
	local[0]= w;
geopackBLK546:
	ctx->vsp=local; return(local[0]);}

/*:pcwing*/
static pointer geopackM547winged_edge_pcwing(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
geopackBLK548:
	ctx->vsp=local; return(local[0]);}

/*:ncwing*/
static pointer geopackM549winged_edge_ncwing(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
geopackBLK550:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer geopackM551winged_edge_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
geopackRST553:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[103], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto geopackKEY554;
	local[1] = NIL;
geopackKEY554:
	if (n & (1<<1)) goto geopackKEY555;
	local[2] = NIL;
geopackKEY555:
	if (n & (1<<2)) goto geopackKEY556;
	local[3] = NIL;
geopackKEY556:
	if (n & (1<<3)) goto geopackKEY557;
	local[4] = NIL;
geopackKEY557:
	local[5]= (pointer)get_sym_func(fqv[82]);
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[12]));
	local[8]= fqv[24];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)APPLY(ctx,5,local+5); /*apply*/
	if (local[1]==NIL) goto geopackIF558;
	argv[0]->c.obj.iv[7] = local[1];
	local[5]= argv[0]->c.obj.iv[7];
	goto geopackIF559;
geopackIF558:
	local[5]= NIL;
geopackIF559:
	if (local[2]==NIL) goto geopackIF560;
	argv[0]->c.obj.iv[9] = local[2];
	local[5]= argv[0]->c.obj.iv[9];
	goto geopackIF561;
geopackIF560:
	local[5]= NIL;
geopackIF561:
	if (local[3]==NIL) goto geopackIF562;
	argv[0]->c.obj.iv[8] = local[3];
	local[5]= argv[0]->c.obj.iv[8];
	goto geopackIF563;
geopackIF562:
	local[5]= NIL;
geopackIF563:
	if (local[4]==NIL) goto geopackIF564;
	argv[0]->c.obj.iv[10] = local[4];
	local[5]= argv[0]->c.obj.iv[10];
	goto geopackIF565;
geopackIF564:
	local[5]= NIL;
geopackIF565:
	w = argv[0];
	local[0]= w;
geopackBLK552:
	ctx->vsp=local; return(local[0]);}

/*:id*/
static pointer geopackM566plane_id(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = NIL;
	local[0]= w;
geopackBLK567:
	ctx->vsp=local; return(local[0]);}

/*:normal*/
static pointer geopackM568plane_normal(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
geopackBLK569:
	ctx->vsp=local; return(local[0]);}

/*:distance*/
static pointer geopackM570plane_distance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)VINNERPRODUCT(ctx,2,local+0); /*v.*/
	local[0]= w;
	{ double x,y;
		y=fltval(argv[0]->c.obj.iv[2]); x=fltval(local[0]);
		local[0]=(makeflt(x + y));}
	w = local[0];
	local[0]= w;
geopackBLK571:
	ctx->vsp=local; return(local[0]);}

/*:plane-distance*/
static pointer geopackM572plane_plane_distance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)VINNERPRODUCT(ctx,2,local+0); /*v.*/
	local[0]= w;
	{ double x,y;
		y=fltval(argv[0]->c.obj.iv[2]); x=fltval(local[0]);
		local[0]=(makeflt(x + y));}
	w = local[0];
	local[0]= w;
geopackBLK573:
	ctx->vsp=local; return(local[0]);}

/*:on-plane-p*/
static pointer geopackM574plane_on_plane_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT577;}
	local[0]= loadglobal(fqv[8]);
geopackENT577:
geopackENT576:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[104];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ABS(ctx,1,local+1); /*abs*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)geopackF25eps__(ctx,2,local+1); /*eps<=*/
	local[0]= w;
geopackBLK575:
	ctx->vsp=local; return(local[0]);}

/*:coplanar-point*/
static pointer geopackM578plane_coplanar_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT581;}
	local[0]= loadglobal(fqv[45]);
geopackENT581:
geopackENT580:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)VINNERPRODUCT(ctx,2,local+1); /*v.*/
	local[1]= w;
	{ double x,y;
		y=fltval(argv[0]->c.obj.iv[2]); x=fltval(local[1]);
		local[1]=(makeflt(x + y));}
	local[2]= makeflt(0.0000000000000000000000e+00);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)geopackF22eps_(ctx,3,local+1); /*eps=*/
	local[0]= w;
geopackBLK579:
	ctx->vsp=local; return(local[0]);}

/*:coplanar-line*/
static pointer geopackM582plane_coplanar_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT585;}
	local[0]= loadglobal(fqv[45]);
geopackENT585:
geopackENT584:
	if (n>4) maerror();
	local[1]= argv[2]->c.obj.iv[1];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)VINNERPRODUCT(ctx,2,local+1); /*v.*/
	local[1]= w;
	{ double x,y;
		y=fltval(argv[0]->c.obj.iv[2]); x=fltval(local[1]);
		local[1]=(makeflt(x + y));}
	local[2]= makeflt(0.0000000000000000000000e+00);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)geopackF22eps_(ctx,3,local+1); /*eps=*/
	local[1]= w;
	if (w==NIL) goto geopackAND586;
	local[1]= argv[2]->c.obj.iv[2];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)VINNERPRODUCT(ctx,2,local+1); /*v.*/
	local[1]= w;
	{ double x,y;
		y=fltval(argv[0]->c.obj.iv[2]); x=fltval(local[1]);
		local[1]=(makeflt(x + y));}
	local[2]= makeflt(0.0000000000000000000000e+00);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)geopackF22eps_(ctx,3,local+1); /*eps=*/
	local[1]= w;
geopackAND586:
	w = local[1];
	local[0]= w;
geopackBLK583:
	ctx->vsp=local; return(local[0]);}

/*:intersection*/
static pointer geopackM587plane_intersection(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)VINNERPRODUCT(ctx,2,local+0); /*v.*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)VINNERPRODUCT(ctx,2,local+1); /*v.*/
	local[1]= w;
	local[2]= local[1];
	{ double x,y;
		y=fltval(makeflt(-(fltval(local[0])))); x=fltval(local[2]);
		local[2]=(makeflt(x + y));}
	local[3]= argv[0]->c.obj.iv[2];
	{ double x,y;
		y=fltval(local[1]); x=fltval(local[3]);
		local[3]=(makeflt(x + y));}
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[0]= w;
geopackBLK588:
	ctx->vsp=local; return(local[0]);}

/*:intersect-edge*/
static pointer geopackM589plane_intersect_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[26];
	local[2]= argv[2]->c.obj.iv[1];
	local[3]= argv[2]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	local[2]= local[0];
	local[3]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)geopackF29eps_in_range(ctx,3,local+1); /*eps-in-range*/
	if (w==NIL) goto geopackIF591;
	local[1]= local[0];
	local[2]= argv[2];
	local[3]= fqv[37];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	goto geopackIF592;
geopackIF591:
	local[1]= makeflt(0.0000000000000000000000e+00);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)NUMEQUAL(ctx,2,local+1); /*=*/
	if (w!=NIL) goto geopackOR595;
	local[1]= makeflt(1.0000000000000000000000e+00);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)NUMEQUAL(ctx,2,local+1); /*=*/
	if (w!=NIL) goto geopackOR595;
	goto geopackIF593;
geopackOR595:
	local[1]= T;
	local[2]= fqv[105];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= w;
	goto geopackIF594;
geopackIF593:
	local[1]= NIL;
geopackIF594:
geopackIF592:
	w = local[1];
	local[0]= w;
geopackBLK590:
	ctx->vsp=local; return(local[0]);}

/*:foot*/
static pointer geopackM596plane_foot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)VINNERPRODUCT(ctx,2,local+0); /*v.*/
	local[0]= w;
	{ double x,y;
		y=fltval(argv[0]->c.obj.iv[2]); x=fltval(local[0]);
		local[0]=(makeflt(x + y));}
	local[1]= argv[2];
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)SCALEVEC(ctx,2,local+2); /*scale*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VMINUS(ctx,2,local+1); /*v-*/
	local[0]= w;
geopackBLK597:
	ctx->vsp=local; return(local[0]);}

/*:original-body*/
static pointer geopackM598plane_original_body(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = NIL;
	local[0]= w;
geopackBLK599:
	ctx->vsp=local; return(local[0]);}

/*:brightness*/
static pointer geopackM600plane_brightness(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)VINNERPRODUCT(ctx,2,local+1); /*v.*/
	local[1]= w;
	local[2]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
geopackBLK601:
	ctx->vsp=local; return(local[0]);}

/*:project*/
static pointer geopackM602plane_project(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT605;}
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
geopackENT605:
geopackENT604:
	if (n>3) maerror();
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(pointer)VINNERPRODUCT(ctx,2,local+3); /*v.*/
	{ double x,y;
		y=fltval(w); x=fltval(local[2]);
		local[2]=(makeflt(x + y));}
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)SCALEVEC(ctx,2,local+2); /*scale*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VMINUS(ctx,2,local+1); /*v-*/
	local[0]= w;
geopackBLK603:
	ctx->vsp=local; return(local[0]);}

/*:separation*/
static pointer geopackM606plane_separation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= argv[2];
geopackWHL608:
	if (local[4]==NIL) goto geopackWHX609;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= argv[0];
	local[6]= fqv[73];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[0] = w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ABS(ctx,1,local+5); /*abs*/
	local[5]= w;
	local[6]= loadglobal(fqv[79]);
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto geopackIF611;
	local[5]= local[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[11])(ctx,1,local+5,&ftab[11],fqv[106]); /*minusp*/
	if (w==NIL) goto geopackIF613;
	w = NIL;
	ctx->vsp=local+5;
	local[0]=w;
	goto geopackBLK607;
	goto geopackIF614;
geopackIF613:
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ABS(ctx,1,local+5); /*abs*/
	local[5]= w;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ABS(ctx,1,local+6); /*abs*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto geopackIF615;
	local[1] = local[0];
	local[5]= local[1];
	goto geopackIF616;
geopackIF615:
	local[5]= NIL;
geopackIF616:
geopackIF614:
	goto geopackIF612;
geopackIF611:
	local[5]= NIL;
geopackIF612:
	goto geopackWHL608;
geopackWHX609:
	local[5]= NIL;
geopackBLK610:
	w = NIL;
	local[3]= NIL;
	local[4]= argv[3];
geopackWHL617:
	if (local[4]==NIL) goto geopackWHX618;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= argv[0];
	local[6]= fqv[73];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[0] = w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ABS(ctx,1,local+5); /*abs*/
	local[5]= w;
	local[6]= loadglobal(fqv[79]);
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto geopackIF620;
	local[5]= local[0];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[11])(ctx,1,local+5,&ftab[11],fqv[106]); /*minusp*/
	if (w==NIL) goto geopackIF622;
	w = NIL;
	ctx->vsp=local+5;
	local[0]=w;
	goto geopackBLK607;
	goto geopackIF623;
geopackIF622:
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ABS(ctx,1,local+5); /*abs*/
	local[5]= w;
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)ABS(ctx,1,local+6); /*abs*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto geopackIF624;
	local[2] = local[0];
	local[5]= local[2];
	goto geopackIF625;
geopackIF624:
	local[5]= NIL;
geopackIF625:
geopackIF623:
	goto geopackIF621;
geopackIF620:
	local[5]= NIL;
geopackIF621:
	goto geopackWHL617;
geopackWHX618:
	local[5]= NIL;
geopackBLK619:
	w = NIL;
	local[3]= local[1];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[11])(ctx,1,local+3,&ftab[11],fqv[106]); /*minusp*/
	if (w==NIL) goto geopackIF626;
	local[3]= local[1];
	local[4]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,2,local+3); /*scale*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)VNORMALIZE(ctx,1,local+3); /*normalize-vector*/
	local[3]= w;
	goto geopackIF627;
geopackIF626:
	local[3]= NIL;
geopackIF627:
	w = local[3];
	local[0]= w;
geopackBLK607:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer geopackM628plane_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	argv[0]->c.obj.iv[1] = argv[2];
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(*ftab[6])(ctx,1,local+0,&ftab[6],fqv[42]); /*float-vector-p*/
	if (w==NIL) goto geopackIF630;
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)VINNERPRODUCT(ctx,2,local+0); /*v.*/
	argv[0]->c.obj.iv[2] = makeflt(-(fltval(w)));
	local[0]= argv[0]->c.obj.iv[2];
	goto geopackIF631;
geopackIF630:
	w = argv[3];
	if (!isnum(w)) goto geopackIF632;
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)EUSFLOAT(ctx,1,local+0); /*float*/
	argv[0]->c.obj.iv[2] = w;
	local[0]= argv[0]->c.obj.iv[2];
	goto geopackIF633;
geopackIF632:
	local[0]= fqv[107];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
geopackIF633:
geopackIF631:
	w = argv[0];
	local[0]= w;
geopackBLK629:
	ctx->vsp=local; return(local[0]);}

/*:face*/
static pointer geopackM634polygon_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0];
	local[0]= w;
geopackBLK635:
	ctx->vsp=local; return(local[0]);}

/*:edges*/
static pointer geopackM636polygon_edges(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
geopackBLK637:
	ctx->vsp=local; return(local[0]);}

/*:edge*/
static pointer geopackM638polygon_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(pointer)NTH(ctx,2,local+0); /*nth*/
	local[0]= w;
geopackBLK639:
	ctx->vsp=local; return(local[0]);}

/*:all-edges*/
static pointer geopackM640polygon_all_edges(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
geopackBLK641:
	ctx->vsp=local; return(local[0]);}

/*:vertices*/
static pointer geopackM642polygon_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
geopackBLK643:
	ctx->vsp=local; return(local[0]);}

/*:vertex*/
static pointer geopackM644polygon_vertex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+2;
	w=(pointer)NTH(ctx,2,local+0); /*nth*/
	local[0]= w;
geopackBLK645:
	ctx->vsp=local; return(local[0]);}

/*:next-edge*/
static pointer geopackM646polygon_next_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[4];
	argv[2] = memq(local[0],w);
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto geopackIF648;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	goto geopackIF649;
geopackIF648:
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
geopackIF649:
	w = local[0];
	local[0]= w;
geopackBLK647:
	ctx->vsp=local; return(local[0]);}

/*:previous-edge*/
static pointer geopackM650polygon_previous_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	if (argv[2]!=local[0]) goto geopackIF652;
	local[0]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+1;
	w=(*ftab[12])(ctx,1,local+0,&ftab[12],fqv[108]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	goto geopackIF653;
geopackIF652:
	local[0]= argv[0]->c.obj.iv[4];
geopackWHL654:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto geopackWHX655;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)EQ(ctx,2,local+1); /*eql*/
	if (w==NIL) goto geopackIF657;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	ctx->vsp=local+1;
	local[0]=w;
	goto geopackBLK651;
	goto geopackIF658;
geopackIF657:
	local[1]= NIL;
geopackIF658:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[1];
	goto geopackWHL654;
geopackWHX655:
	local[1]= NIL;
geopackBLK656:
	w = local[1];
	local[0]= w;
geopackIF653:
	w = local[0];
	local[0]= w;
geopackBLK651:
	ctx->vsp=local; return(local[0]);}

/*:adjacent-faces*/
static pointer geopackM659polygon_adjacent_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[0]->c.obj.iv[4];
geopackWHL661:
	if (local[5]==NIL) goto geopackWHX662;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[2] = local[4]->c.obj.iv[3];
	local[3] = local[4]->c.obj.iv[4];
	local[6]= local[2];
	if (argv[0]!=local[6]) goto geopackIF664;
	local[6]= local[3];
	goto geopackIF665;
geopackIF664:
	local[6]= local[2];
geopackIF665:
	w = local[1];
	ctx->vsp=local+7;
	local[1] = cons(ctx,local[6],w);
	goto geopackWHL661;
geopackWHX662:
	local[6]= NIL;
geopackBLK663:
	w = NIL;
	w = local[1];
	local[0]= w;
geopackBLK660:
	ctx->vsp=local; return(local[0]);}

/*:convexp*/
static pointer geopackM666polygon_convexp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
geopackBLK667:
	ctx->vsp=local; return(local[0]);}

/*:box*/
static pointer geopackM668polygon_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT671;}
	local[0]= NIL;
geopackENT671:
geopackENT670:
	if (n>3) maerror();
	local[1]= loadglobal(fqv[15]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[24];
	local[4]= argv[0]->c.obj.iv[5];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[0]= w;
geopackBLK669:
	ctx->vsp=local; return(local[0]);}

/*:boxtest*/
static pointer geopackM672polygon_boxtest(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT675;}
	local[0]= NIL;
geopackENT675:
geopackENT674:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= fqv[25];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[26];
	local[3]= loadglobal(fqv[15]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[24];
	local[6]= argv[0]->c.obj.iv[5];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = local[3];
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
geopackBLK673:
	ctx->vsp=local; return(local[0]);}

/*:vertices-mean*/
static pointer geopackM676polygon_vertices_mean(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	ctx->vsp=local+1;
	w=(pointer)geopackF4vector_mean(ctx,1,local+0); /*vector-mean*/
	local[0]= w;
geopackBLK677:
	ctx->vsp=local; return(local[0]);}

/*:distance*/
static pointer geopackM678polygon_distance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[104];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,1,local+1,&ftab[13],fqv[109]); /*signum*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[38];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[0] = w;
	local[2]= local[1];
	local[3]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)NUMEQUAL(ctx,2,local+2); /*=*/
	if (w==NIL) goto geopackIF680;
	local[2]= argv[0];
	local[3]= fqv[110];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	w = fqv[111];
	if (memq(local[2],w)==NIL) goto geopackIF682;
	local[2]= makeflt(0.0000000000000000000000e+00);
	goto geopackIF683;
geopackIF682:
	local[2]= (pointer)get_sym_func(fqv[112]);
	local[3]= argv[0]->c.obj.iv[4];
	local[4]= fqv[73];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(*ftab[14])(ctx,3,local+3,&ftab[14],fqv[113]); /*send-all*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,2,local+2); /*apply*/
	local[2]= w;
geopackIF683:
	goto geopackIF681;
geopackIF680:
	local[2]= local[1];
	local[3]= argv[0];
	local[4]= fqv[110];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	w = fqv[114];
	if (memq(local[3],w)==NIL) goto geopackIF684;
	local[3]= local[0];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)VDISTANCE(ctx,2,local+3); /*distance*/
	local[3]= w;
	goto geopackIF685;
geopackIF684:
	local[3]= (pointer)get_sym_func(fqv[112]);
	local[4]= argv[0]->c.obj.iv[4];
	local[5]= fqv[73];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[14])(ctx,3,local+4,&ftab[14],fqv[113]); /*send-all*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,2,local+3); /*apply*/
	local[3]= w;
geopackIF685:
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
geopackIF681:
	w = local[2];
	local[0]= w;
geopackBLK679:
	ctx->vsp=local; return(local[0]);}

/*:area*/
static pointer geopackM686polygon_area(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)geopackF4vector_mean(ctx,1,local+1); /*vector-mean*/
	local[1]= w;
	local[2]= makeflt(0.0000000000000000000000e+00);
geopackWHL688:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto geopackWHX689;
	local[3]= local[2];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= local[1];
	local[7]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+8;
	w=(pointer)geopackF6triangle(ctx,4,local+4); /*triangle*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[2] = w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[3];
	goto geopackWHL688;
geopackWHX689:
	local[3]= NIL;
geopackBLK690:
	local[3]= local[2];
	local[4]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[0]= w;
geopackBLK687:
	ctx->vsp=local; return(local[0]);}

/*:perimeter*/
static pointer geopackM691polygon_perimeter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= (pointer)get_sym_func(fqv[115]);
	local[1]= argv[0]->c.obj.iv[4];
	local[2]= fqv[116];
	ctx->vsp=local+3;
	w=(*ftab[14])(ctx,2,local+1,&ftab[14],fqv[113]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPLY(ctx,2,local+0); /*apply*/
	local[0]= w;
geopackBLK692:
	ctx->vsp=local; return(local[0]);}

/*:volume*/
static pointer geopackM693polygon_volume(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT696;}
	local[0]= fqv[117];
geopackENT696:
geopackENT695:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[104];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[118];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= makeflt(-3.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[0]= w;
geopackBLK694:
	ctx->vsp=local; return(local[0]);}

/*:centroid*/
static pointer geopackM697polygon_centroid(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT700;}
	local[0]= NIL;
geopackENT700:
geopackENT699:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[5];
	local[2]= NIL;
	local[3]= NIL;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)geopackF4vector_mean(ctx,1,local+4); /*vector-mean*/
	local[4]= w;
	local[5]= makeflt(0.0000000000000000000000e+00);
	local[6]= makeflt(0.0000000000000000000000e+00);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
geopackWHL701:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto geopackWHX702;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[9];
	local[2] = w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
	local[9]= local[2];
	local[10]= local[3];
	local[11]= local[4];
	local[12]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+13;
	w=(pointer)geopackF6triangle(ctx,4,local+9); /*triangle*/
	local[5] = w;
	local[9]= local[6];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[6] = w;
	local[9]= local[2];
	local[10]= local[3];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)VPLUS(ctx,3,local+9); /*v+*/
	local[9]= local[4];
	local[10]= local[8];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)VPLUS(ctx,3,local+9); /*v+*/
	local[9]= local[7];
	local[10]= local[5];
	local[11]= makeflt(3.0000000000000000000000e+00);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)SCALEVEC(ctx,2,local+10); /*scale*/
	local[10]= w;
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)VPLUS(ctx,3,local+9); /*v+*/
	goto geopackWHL701;
geopackWHX702:
	local[9]= NIL;
geopackBLK703:
	local[9]= makeflt(1.0000000000000000000000e+00);
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,2,local+9); /*scale*/
	local[7] = w;
	local[9]= local[6];
	local[10]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[6] = w;
	if (local[0]==NIL) goto geopackIF704;
	local[9]= local[6];
	local[10]= argv[0];
	local[11]= fqv[104];
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	local[10]= makeflt(-3.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	local[10]= makeflt(7.5000000000000000000000e-01);
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)SCALEVEC(ctx,2,local+10); /*scale*/
	local[10]= w;
	local[11]= makeflt(2.5000000000000000000000e-01);
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)SCALEVEC(ctx,2,local+11); /*scale*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)VPLUS(ctx,2,local+10); /*v+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	local[9]= w;
	goto geopackIF705;
geopackIF704:
	local[9]= local[6];
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	local[9]= w;
geopackIF705:
	w = local[9];
	local[0]= w;
geopackBLK698:
	ctx->vsp=local; return(local[0]);}

/*:color*/
static pointer geopackM706polygon_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT709;}
	local[0]= NIL;
geopackENT709:
geopackENT708:
	if (n>3) maerror();
	if (local[0]==NIL) goto geopackIF710;
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= fqv[80];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= w;
	goto geopackIF711;
geopackIF710:
	local[1]= NIL;
geopackIF711:
	local[1]= argv[0];
	local[2]= fqv[80];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[0]= w;
geopackBLK707:
	ctx->vsp=local; return(local[0]);}

/*:insidep*/
static pointer geopackM712polygon_insidep(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT715;}
	local[0]= loadglobal(fqv[8]);
geopackENT715:
	w = local[0];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
geopackENT714:
	if (n>4) maerror();
	local[3]= NIL;
	local[4]= NIL;
	local[5]= makeflt(0.0000000000000000000000e+00);
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	if (argv[0]->c.obj.iv[3]==NIL) goto geopackCON717;
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.car;
	local[9]= NIL;
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.cdr;
geopackWHL718:
	if (local[10]==NIL) goto geopackWHX719;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	local[11]= local[4];
	local[12]= local[9];
	local[13]= argv[2];
	local[14]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+15;
	w=(pointer)geopackF6triangle(ctx,4,local+11); /*triangle*/
	local[7] = w;
	local[11]= local[7];
	local[12]= local[4];
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)VDISTANCE(ctx,2,local+12); /*distance*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)geopackF28eps_zero(ctx,1,local+11); /*eps-zero*/
	if (w==NIL) goto geopackCON722;
	local[11]= local[9];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)VMINUS(ctx,2,local+11); /*v-*/
	local[11]= w;
	local[12]= argv[2];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)VMINUS(ctx,2,local+12); /*v-*/
	local[12]= w;
	local[13]= local[11];
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)VINNERPRODUCT(ctx,2,local+13); /*v.*/
	local[13]= w;
	local[14]= local[11];
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(pointer)VINNERPRODUCT(ctx,2,local+14); /*v.*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[6] = w;
	local[11]= makeflt(0.0000000000000000000000e+00);
	local[12]= local[6];
	local[13]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+14;
	w=(pointer)geopackF29eps_in_range(ctx,3,local+11); /*eps-in-range*/
	if (w==NIL) goto geopackIF723;
	w = fqv[119];
	ctx->vsp=local+11;
	unwind(ctx,local+0);
	local[0]=w;
	goto geopackBLK713;
	goto geopackIF724;
geopackIF723:
	local[11]= NIL;
geopackIF724:
	goto geopackCON721;
geopackCON722:
	local[11]= local[7];
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[11]);
	if (left >= right) goto geopackCON725;}
	w = fqv[51];
	ctx->vsp=local+11;
	unwind(ctx,local+0);
	local[0]=w;
	goto geopackBLK713;
	goto geopackCON721;
geopackCON725:
	local[11]= NIL;
geopackCON721:
	local[4] = local[9];
	goto geopackWHL718;
geopackWHX719:
	local[11]= NIL;
geopackBLK720:
	w = NIL;
	local[9]= fqv[120];
	goto geopackCON716;
geopackCON717:
	local[9]= argv[0];
	local[10]= fqv[121];
	local[11]= argv[2];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	if (w==NIL) goto geopackIF727;
	w = fqv[119];
	ctx->vsp=local+9;
	unwind(ctx,local+0);
	local[0]=w;
	goto geopackBLK713;
	goto geopackIF728;
geopackIF727:
	local[9]= NIL;
geopackIF728:
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,geopackCLO729,env,argv,local);
	local[10]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[8] = w;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[4] = w;
geopackWHL730:
	if (local[8]==NIL) goto geopackWHX731;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[3] = w;
	local[9]= local[3];
	local[10]= local[4];
	local[11]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+12;
	w=(pointer)geopackF8vector_angle(ctx,3,local+9); /*vector-angle*/
	local[7] = w;
	local[9]= makeflt((double)fabs(fltval(local[7])));
	local[10]= makeflt(3.1415926535897931159980e+00);
	ctx->vsp=local+11;
	w=(pointer)geopackF22eps_(ctx,2,local+9); /*eps=*/
	if (w==NIL) goto geopackIF733;
	w = fqv[119];
	ctx->vsp=local+9;
	unwind(ctx,local+0);
	local[0]=w;
	goto geopackBLK713;
	goto geopackIF734;
geopackIF733:
	local[9]= NIL;
geopackIF734:
	local[9]= local[5];
	{ double x,y;
		y=fltval(local[7]); x=fltval(local[9]);
		local[9]=(makeflt(x + y));}
	local[5] = local[9];
	local[4] = local[3];
	goto geopackWHL730;
geopackWHX731:
	local[9]= NIL;
geopackBLK732:
	local[9]= makeflt((double)fabs(fltval(local[5])));
	{ double left,right;
		right=fltval(makeflt(3.1415926535897931159980e+00)); left=fltval(local[9]);
	if (left <= right) goto geopackIF735;}
	local[9]= fqv[120];
	goto geopackIF736;
geopackIF735:
	local[9]= fqv[51];
geopackIF736:
	goto geopackCON716;
geopackCON726:
	local[9]= NIL;
geopackCON716:
	w = local[9];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
geopackBLK713:
	ctx->vsp=local; return(local[0]);}

/*:intersect-point-vector*/
static pointer geopackM737polygon_intersect_point_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)VINNERPRODUCT(ctx,2,local+0); /*v.*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= makeflt((double)fabs(fltval(local[0])));
	local[4]= loadglobal(fqv[35]);
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	if (w==NIL) goto geopackIF739;
	w = fqv[122];
	ctx->vsp=local+3;
	local[0]=w;
	goto geopackBLK738;
	goto geopackIF740;
geopackIF739:
	local[3]= NIL;
geopackIF740:
	local[3]= makeflt(0.0000000000000000000000e+00);
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)VINNERPRODUCT(ctx,2,local+4); /*v.*/
	local[4]= w;
	{ double x,y;
		y=fltval(argv[0]->c.obj.iv[2]); x=fltval(local[4]);
		local[4]=(makeflt(x + y));}
	{ double x,y;
		y=fltval(makeflt(-(fltval(local[4])))); x=fltval(local[3]);
		local[3]=(makeflt(x + y));}
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[1] = w;
	local[3]= local[1];
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[3]);
	if (left >= right) goto geopackIF741;}
	w = fqv[123];
	ctx->vsp=local+3;
	local[0]=w;
	goto geopackBLK738;
	goto geopackIF742;
geopackIF741:
	local[3]= NIL;
geopackIF742:
	local[3]= argv[2];
	local[4]= local[1];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)VPLUS(ctx,2,local+3); /*v+*/
	local[2] = w;
	local[3]= argv[0];
	local[4]= fqv[110];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[0]= w;
geopackBLK738:
	ctx->vsp=local; return(local[0]);}

/*:intersect-line*/
static pointer geopackM743polygon_intersect_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[26];
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= makeflt(0.0000000000000000000000e+00);
	local[4]= local[0];
	local[5]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+6;
	w=(pointer)geopackF29eps_in_range(ctx,3,local+3); /*eps-in-range*/
	if (w==NIL) goto geopackIF745;
	local[3]= argv[0];
	local[4]= fqv[110];
	local[5]= local[0];
	local[6]= argv[2];
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(*ftab[1])(ctx,3,local+5,&ftab[1],fqv[11]); /*midpoint*/
	local[1] = w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	w = fqv[124];
	if (memq(local[3],w)==NIL) goto geopackIF745;
	local[3]= local[0];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[3]= w;
	goto geopackIF746;
geopackIF745:
	local[3]= NIL;
geopackIF746:
	w = local[3];
	local[0]= w;
geopackBLK744:
	ctx->vsp=local; return(local[0]);}

/*:intersect-edge*/
static pointer geopackM747polygon_intersect_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[125];
	local[2]= argv[2]->c.obj.iv[1];
	local[3]= argv[2]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
geopackBLK748:
	ctx->vsp=local; return(local[0]);}

/*:intersect-face*/
static pointer geopackM749polygon_intersect_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT752;}
	local[0]= argv[0];
	local[1]= fqv[25];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[26];
	local[2]= argv[2];
	local[3]= fqv[25];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
geopackENT752:
geopackENT751:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[4];
geopackWHL753:
	if (local[2]==NIL) goto geopackWHX754;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	if (local[0]==NIL) goto geopackIF756;
	local[3]= local[0];
	local[4]= fqv[28];
	local[5]= local[1];
	local[6]= fqv[25];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	if (w==NIL) goto geopackIF756;
	local[3]= argv[2];
	local[4]= fqv[126];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	if (w==NIL) goto geopackIF756;
	w = T;
	ctx->vsp=local+3;
	local[0]=w;
	goto geopackBLK750;
	goto geopackIF757;
geopackIF756:
	local[3]= NIL;
geopackIF757:
	goto geopackWHL753;
geopackWHX754:
	local[3]= NIL;
geopackBLK755:
	w = NIL;
	w = NIL;
	local[0]= w;
geopackBLK750:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer geopackCLO729(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[2];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)geopackF5direction_vector(ctx,2,local+0); /*direction-vector*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:visible*/
static pointer geopackM758polygon_visible(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[104];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto geopackIF760;
	local[0]= argv[0];
	goto geopackIF761;
geopackIF760:
	local[0]= NIL;
geopackIF761:
	w = local[0];
	local[0]= w;
geopackBLK759:
	ctx->vsp=local; return(local[0]);}

/*:transform-normal*/
static pointer geopackM762polygon_transform_normal(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[127];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= local[0]->c.obj.iv[2];
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)VINNERPRODUCT(ctx,2,local+2); /*v.*/
	{ double x,y;
		y=fltval(w); x=fltval(local[1]);
		local[1]=(makeflt(x + y));}
	argv[0]->c.obj.iv[2] = local[1];
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= local[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)TRANSFORM(ctx,2,local+1); /*transform*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
geopackBLK763:
	ctx->vsp=local; return(local[0]);}

/*:reset-normal*/
static pointer geopackM764polygon_reset_normal(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	ctx->vsp=local+1;
	w=(pointer)geopackF9face_normal_vector(ctx,1,local+0); /*face-normal-vector*/
	argv[0]->c.obj.iv[1] = w;
	local[0]= argv[0]->c.obj.iv[1];
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)VINNERPRODUCT(ctx,2,local+0); /*v.*/
	argv[0]->c.obj.iv[2] = makeflt(-(fltval(w)));
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
geopackBLK765:
	ctx->vsp=local; return(local[0]);}

/*:set-convexp*/
static pointer geopackM766polygon_set_convexp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	argv[0]->c.obj.iv[3] = T;
geopackWHL768:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto geopackWHX769;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[1];
	local[1]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(pointer)geopackF6triangle(ctx,4,local+1); /*triangle*/
	local[1]= w;
	local[2]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto geopackIF771;
	argv[0]->c.obj.iv[3] = NIL;
	local[0] = NIL;
	local[1]= local[0];
	goto geopackIF772;
geopackIF771:
	local[1]= NIL;
geopackIF772:
	goto geopackWHL768;
geopackWHX769:
	local[1]= NIL;
geopackBLK770:
	w = local[1];
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
geopackBLK767:
	ctx->vsp=local; return(local[0]);}

/*:invert*/
static pointer geopackM773polygon_invert(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+1;
	w=(pointer)NREVERSE(ctx,1,local+0); /*nreverse*/
	argv[0]->c.obj.iv[5] = w;
	local[0]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+1;
	w=(pointer)NREVERSE(ctx,1,local+0); /*nreverse*/
	argv[0]->c.obj.iv[4] = w;
	local[0]= makeflt(-1.0000000000000000000000e+00);
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,3,local+0); /*scale*/
	local[0]= makeflt(-1.0000000000000000000000e+00);
	local[1]= argv[0]->c.obj.iv[6];
	local[2]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,3,local+0); /*scale*/
	local[0]= makeflt(-1.0000000000000000000000e+00);
	{ double x,y;
		y=fltval(argv[0]->c.obj.iv[2]); x=fltval(local[0]);
		local[0]=(makeflt(x * y));}
	argv[0]->c.obj.iv[2] = local[0];
	local[0]= makeflt(-1.0000000000000000000000e+00);
	{ double x,y;
		y=fltval(argv[0]->c.obj.iv[7]); x=fltval(local[0]);
		local[0]=(makeflt(x * y));}
	argv[0]->c.obj.iv[7] = local[0];
	local[0]= argv[0];
	local[1]= fqv[128];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
geopackBLK774:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer geopackM775polygon_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[129], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto geopackKEY777;
	local[0] = NIL;
geopackKEY777:
	if (n & (1<<1)) goto geopackKEY778;
	local[1] = NIL;
geopackKEY778:
	if (n & (1<<2)) goto geopackKEY779;
	local[2] = NIL;
geopackKEY779:
	if (n & (1<<3)) goto geopackKEY780;
	local[3] = NIL;
geopackKEY780:
	if (local[1]==NIL) goto geopackCON782;
	argv[0]->c.obj.iv[4] = local[1];
	if (local[0]!=NIL) goto geopackCON784;
	local[4]= NIL;
	local[5]= local[1];
geopackWHL785:
	if (local[5]==NIL) goto geopackWHX786;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[4];
	local[7]= fqv[55];
	local[8]= argv[0];
	local[9]= fqv[130];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	w = local[0];
	ctx->vsp=local+7;
	local[0] = cons(ctx,local[6],w);
	goto geopackWHL785;
geopackWHX786:
	local[6]= NIL;
geopackBLK787:
	w = NIL;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)NREVERSE(ctx,1,local+4); /*nreverse*/
	local[0] = w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= fqv[54];
	local[6]= argv[0];
	local[7]= fqv[130];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	w = local[0];
	ctx->vsp=local+5;
	argv[0]->c.obj.iv[5] = cons(ctx,local[4],w);
	local[4]= argv[0]->c.obj.iv[5];
	goto geopackCON783;
geopackCON784:
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[12])(ctx,1,local+4,&ftab[12],fqv[108]); /*last*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPEND(ctx,2,local+4); /*append*/
	argv[0]->c.obj.iv[5] = w;
	local[4]= argv[0]->c.obj.iv[5];
	goto geopackCON783;
geopackCON788:
	local[4]= NIL;
geopackCON783:
	goto geopackCON781;
geopackCON782:
	if (local[0]==NIL) goto geopackCON789;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[12])(ctx,1,local+4,&ftab[12],fqv[108]); /*last*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPEND(ctx,2,local+4); /*append*/
	argv[0]->c.obj.iv[5] = w;
geopackWHL790:
	if (local[0]==NIL) goto geopackWHX791;
	local[4]= loadglobal(fqv[131]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= local[4];
	local[6]= fqv[24];
	local[7]= fqv[54];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[8];
	local[8]= w;
	local[9]= fqv[55];
	if (local[0]==NIL) goto geopackIF793;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	goto geopackIF794;
geopackIF793:
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
geopackIF794:
	local[11]= fqv[132];
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,8,local+5); /*send*/
	w = local[4];
	local[4]= w;
	w = argv[0]->c.obj.iv[4];
	ctx->vsp=local+5;
	argv[0]->c.obj.iv[4] = cons(ctx,local[4],w);
	goto geopackWHL790;
geopackWHX791:
	local[4]= NIL;
geopackBLK792:
	local[4]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+5;
	w=(pointer)NREVERSE(ctx,1,local+4); /*nreverse*/
	argv[0]->c.obj.iv[4] = w;
	local[4]= argv[0]->c.obj.iv[4];
	goto geopackCON781;
geopackCON789:
	local[4]= NIL;
geopackCON781:
	if (local[2]==NIL) goto geopackIF795;
	argv[0]->c.obj.iv[1] = local[2];
	local[4]= argv[0]->c.obj.iv[1];
	goto geopackIF796;
geopackIF795:
	local[4]= argv[0];
	local[5]= fqv[133];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
geopackIF796:
	if (local[3]==NIL) goto geopackIF797;
	argv[0]->c.obj.iv[2] = local[3];
	local[4]= argv[0]->c.obj.iv[2];
	goto geopackIF798;
geopackIF797:
	local[4]= NIL;
geopackIF798:
	local[4]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(pointer)COPYSEQ(ctx,1,local+4); /*copy-seq*/
	argv[0]->c.obj.iv[6] = w;
	argv[0]->c.obj.iv[7] = argv[0]->c.obj.iv[2];
	local[4]= argv[0];
	local[5]= fqv[128];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	w = argv[0];
	local[0]= w;
geopackBLK776:
	ctx->vsp=local; return(local[0]);}

/*:on-vertex*/
static pointer geopackM799polygon_on_vertex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT802;}
	local[0]= loadglobal(fqv[23]);
geopackENT802:
	w = local[0];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
geopackENT801:
	if (n>4) maerror();
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.cdr;
geopackWHL803:
	if (local[6]==NIL) goto geopackWHX804;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= argv[2];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)geopackF30eps_v_(ctx,2,local+7); /*eps-v=*/
	if (w==NIL) goto geopackIF806;
	local[7]= local[5];
	w = local[4];
	ctx->vsp=local+8;
	local[4] = cons(ctx,local[7],w);
	local[7]= local[4];
	goto geopackIF807;
geopackIF806:
	local[7]= NIL;
geopackIF807:
	goto geopackWHL803;
geopackWHX804:
	local[7]= NIL;
geopackBLK805:
	w = NIL;
	local[5]= local[4];
	ctx->vsp=local+6;
	unbindx(ctx,1);
	w = local[5];
	local[0]= w;
geopackBLK800:
	ctx->vsp=local; return(local[0]);}

/*:on-edge*/
static pointer geopackM808polygon_on_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT811;}
	local[0]= loadglobal(fqv[23]);
geopackENT811:
geopackENT810:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[4];
geopackWHL812:
	if (local[4]==NIL) goto geopackWHX813;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3];
	local[6]= fqv[134];
	local[7]= argv[2];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	if (w==NIL) goto geopackIF815;
	local[5]= local[3];
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	local[5]= local[2];
	goto geopackIF816;
geopackIF815:
	local[5]= NIL;
geopackIF816:
	goto geopackWHL812;
geopackWHX813:
	local[5]= NIL;
geopackBLK814:
	w = NIL;
	w = local[2];
	local[0]= w;
geopackBLK809:
	ctx->vsp=local; return(local[0]);}

/*:coplanar-distance*/
static pointer geopackM817polygon_coplanar_distance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[110];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[135];
	ctx->vsp=local+2;
	w=(*ftab[15])(ctx,2,local+0,&ftab[15],fqv[136]); /*member*/
	if (w==NIL) goto geopackIF819;
	local[0]= fqv[120];
	goto geopackIF820;
geopackIF819:
	local[0]= (pointer)get_sym_func(fqv[112]);
	local[1]= argv[0]->c.obj.iv[4];
	local[2]= fqv[73];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(*ftab[14])(ctx,3,local+1,&ftab[14],fqv[113]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPLY(ctx,2,local+0); /*apply*/
	local[0]= w;
geopackIF820:
	w = local[0];
	local[0]= w;
geopackBLK818:
	ctx->vsp=local; return(local[0]);}

/*:coplanar-intersections*/
static pointer geopackM821polygon_coplanar_intersections(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT824;}
	local[0]= loadglobal(fqv[45]);
geopackENT824:
geopackENT823:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)geopackF34bounding_box_intersection(ctx,2,local+1); /*bounding-box-intersection*/
	local[1]= w;
	local[2]= NIL;
	if (local[1]!=NIL) goto geopackIF825;
	w = NIL;
	ctx->vsp=local+3;
	local[0]=w;
	goto geopackBLK822;
	goto geopackIF826;
geopackIF825:
	local[3]= NIL;
geopackIF826:
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[4];
geopackWHL827:
	if (local[4]==NIL) goto geopackWHX828;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= argv[2];
	local[9]= fqv[60];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
geopackWHL830:
	if (local[8]==NIL) goto geopackWHX831;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= local[3];
	local[10]= fqv[125];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[6] = w;
	w = local[6];
	if (!iscons(w)) goto geopackIF833;
	local[9]= local[7];
	w = local[6];
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	w = local[5];
	ctx->vsp=local+10;
	local[5] = cons(ctx,local[9],w);
	local[9]= local[5];
	goto geopackIF834;
geopackIF833:
	local[9]= NIL;
geopackIF834:
	goto geopackWHL830;
geopackWHX831:
	local[9]= NIL;
geopackBLK832:
	w = NIL;
	if (local[5]==NIL) goto geopackIF835;
	local[7]= local[3];
	w = local[5];
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	w = local[2];
	ctx->vsp=local+8;
	local[2] = cons(ctx,local[7],w);
	local[7]= local[2];
	goto geopackIF836;
geopackIF835:
	local[7]= NIL;
geopackIF836:
	w = local[7];
	goto geopackWHL827;
geopackWHX828:
	local[5]= NIL;
geopackBLK829:
	w = NIL;
	if (local[2]==NIL) goto geopackIF837;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	ctx->vsp=local+3;
	local[0]=w;
	goto geopackBLK822;
	goto geopackIF838;
geopackIF837:
	local[3]= NIL;
geopackIF838:
	local[3]= NIL;
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
geopackWHL839:
	if (local[4]==NIL) goto geopackWHX840;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[1];
	local[6]= fqv[137];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	if (w==NIL) goto geopackIF842;
	local[5]= argv[2];
	local[6]= fqv[110];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	w = fqv[138];
	if (memq(local[5],w)==NIL) goto geopackIF842;
	w = fqv[139];
	ctx->vsp=local+5;
	local[0]=w;
	goto geopackBLK822;
	goto geopackIF843;
geopackIF842:
	local[5]= NIL;
geopackIF843:
	goto geopackWHL839;
geopackWHX840:
	local[5]= NIL;
geopackBLK841:
	w = NIL;
	local[3]= NIL;
	local[4]= argv[2];
	local[5]= fqv[140];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
geopackWHL844:
	if (local[4]==NIL) goto geopackWHX845;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[1];
	local[6]= fqv[137];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	if (w==NIL) goto geopackIF847;
	local[5]= argv[0];
	local[6]= fqv[110];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	w = fqv[141];
	if (memq(local[5],w)==NIL) goto geopackIF847;
	w = fqv[142];
	ctx->vsp=local+5;
	local[0]=w;
	goto geopackBLK822;
	goto geopackIF848;
geopackIF847:
	local[5]= NIL;
geopackIF848:
	goto geopackWHL844;
geopackWHX845:
	local[5]= NIL;
geopackBLK846:
	w = NIL;
	w = NIL;
	local[0]= w;
geopackBLK822:
	ctx->vsp=local; return(local[0]);}

/*:contact-edge*/
static pointer geopackM849polygon_contact_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT852;}
	local[0]= loadglobal(fqv[23]);
geopackENT852:
geopackENT851:
	if (n>4) maerror();
	local[1]= argv[2]->c.obj.iv[1];
	local[2]= argv[2]->c.obj.iv[2];
	local[3]= argv[0];
	local[4]= fqv[104];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[104];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ABS(ctx,1,local+5); /*abs*/
	local[5]= w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w!=NIL) goto geopackOR855;
	local[5]= local[4];
	ctx->vsp=local+6;
	w=(pointer)ABS(ctx,1,local+5); /*abs*/
	local[5]= w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w!=NIL) goto geopackOR855;
	local[5]= argv[0];
	local[6]= fqv[143];
	local[7]= argv[2];
	local[8]= makeflt(1.0000000000000000208167e-03);
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	if (w==NIL) goto geopackOR855;
	goto geopackCON854;
geopackOR855:
	local[5]= fqv[51];
	goto geopackCON853;
geopackCON854:
	local[5]= argv[0];
	local[6]= fqv[110];
	local[7]= local[1];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[120];
	ctx->vsp=local+7;
	w=(pointer)EQ(ctx,2,local+5); /*eql*/
	if (w!=NIL) goto geopackOR857;
	local[5]= argv[0];
	local[6]= fqv[110];
	local[7]= local[2];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)EQ(ctx,1,local+5); /*eql*/
	if (w!=NIL) goto geopackOR857;
	goto geopackCON856;
geopackOR857:
	local[5]= T;
	goto geopackCON853;
geopackCON856:
	local[5]= NIL;
geopackCON853:
	w = local[5];
	local[0]= w;
geopackBLK850:
	ctx->vsp=local; return(local[0]);}

/*:contact-plane*/
static pointer geopackM858polygon_contact_plane(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT861;}
	local[0]= loadglobal(fqv[23]);
geopackENT861:
geopackENT860:
	if (n>4) maerror();
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[2];
	local[3]= fqv[64];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VINNERPRODUCT(ctx,2,local+1); /*v.*/
	local[1]= w;
	local[2]= makeflt(-1.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)geopackF22eps_(ctx,2,local+1); /*eps=*/
	if (w==NIL) goto geopackIF862;
	local[1]= makeflt(-(fltval(argv[0]->c.obj.iv[2])));
	local[2]= argv[2]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)geopackF22eps_(ctx,2,local+1); /*eps=*/
	if (w==NIL) goto geopackIF862;
	local[1]= argv[0];
	local[2]= fqv[144];
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto geopackIF863;
geopackIF862:
	local[1]= NIL;
geopackIF863:
	w = local[1];
	local[0]= w;
geopackBLK859:
	ctx->vsp=local; return(local[0]);}

/*:contact-point*/
static pointer geopackM864polygon_contact_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT867;}
	local[0]= loadglobal(fqv[23]);
geopackENT867:
geopackENT866:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[104];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= local[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ABS(ctx,1,local+3); /*abs*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto geopackIF868;
	local[2]= fqv[51];
	goto geopackIF869;
geopackIF868:
	local[2]= argv[0];
	local[3]= fqv[110];
	local[4]= argv[2];
	local[5]= local[1];
	local[6]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,2,local+5); /*scale*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VMINUS(ctx,2,local+4); /*v-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
geopackIF869:
	w = local[2];
	local[0]= w;
geopackBLK865:
	ctx->vsp=local; return(local[0]);}

/*:contactp*/
static pointer geopackM870polygon_contactp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT873;}
	local[0]= loadglobal(fqv[23]);
geopackENT873:
geopackENT872:
	if (n>4) maerror();
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[42]); /*float-vector-p*/
	if (w==NIL) goto geopackCON875;
	local[1]= argv[0];
	local[2]= fqv[145];
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto geopackCON874;
geopackCON875:
	local[1]= argv[2];
	local[2]= loadglobal(fqv[43]);
	ctx->vsp=local+3;
	w=(pointer)DERIVEDP(ctx,2,local+1); /*derivedp*/
	if (w==NIL) goto geopackCON876;
	local[1]= argv[0];
	local[2]= fqv[146];
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto geopackCON874;
geopackCON876:
	local[1]= argv[2];
	local[2]= loadglobal(fqv[147]);
	ctx->vsp=local+3;
	w=(pointer)DERIVEDP(ctx,2,local+1); /*derivedp*/
	if (w==NIL) goto geopackCON877;
	local[1]= argv[0];
	local[2]= fqv[148];
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto geopackCON874;
geopackCON877:
	local[1]= NIL;
geopackCON874:
	w = local[1];
	local[0]= w;
geopackBLK871:
	ctx->vsp=local; return(local[0]);}

/*:aligned-plane*/
static pointer geopackM878polygon_aligned_plane(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	local[2]= fqv[64];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VINNERPRODUCT(ctx,2,local+0); /*v.*/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(pointer)geopackF22eps_(ctx,2,local+0); /*eps=*/
	if (w==NIL) goto geopackIF880;
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= argv[2]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)geopackF22eps_(ctx,2,local+0); /*eps=*/
	if (w==NIL) goto geopackIF880;
	local[0]= argv[0];
	local[1]= fqv[144];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto geopackIF881;
geopackIF880:
	local[0]= NIL;
geopackIF881:
	w = local[0];
	local[0]= w;
geopackBLK879:
	ctx->vsp=local; return(local[0]);}

/*:insidep*/
static pointer geopackM882face_insidep(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT885;}
	local[0]= makeflt(1.0000000000000000208167e-03);
geopackENT885:
geopackENT884:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[12]));
	local[3]= fqv[110];
	local[4]= argv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SENDMESSAGE(ctx,5,local+1); /*send-message*/
	local[1]= w;
	local[2]= local[1];
	if (fqv[120]==local[2]) goto geopackIF886;
	local[2]= local[1];
	goto geopackIF887;
geopackIF886:
	local[2]= NIL;
	local[3]= argv[0]->c.obj.iv[8];
geopackWHL888:
	if (local[3]==NIL) goto geopackWHX889;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	local[5]= fqv[110];
	local[6]= argv[2];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[1] = w;
	local[4]= local[1];
	if (fqv[120]!=local[4]) goto geopackIF891;
	w = fqv[51];
	ctx->vsp=local+4;
	local[0]=w;
	goto geopackBLK883;
	goto geopackIF892;
geopackIF891:
	local[4]= local[1];
	if (fqv[119]!=local[4]) goto geopackIF893;
	w = fqv[119];
	ctx->vsp=local+4;
	local[0]=w;
	goto geopackBLK883;
	goto geopackIF894;
geopackIF893:
	local[4]= NIL;
geopackIF894:
geopackIF892:
	goto geopackWHL888;
geopackWHX889:
	local[4]= NIL;
geopackBLK890:
	w = NIL;
	local[2]= fqv[120];
geopackIF887:
	w = local[2];
	local[0]= w;
geopackBLK883:
	ctx->vsp=local; return(local[0]);}

/*:distance*/
static pointer geopackM895face_distance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[104];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,1,local+1,&ftab[13],fqv[109]); /*signum*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[38];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[0] = w;
	local[2]= local[1];
	local[3]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)NUMEQUAL(ctx,2,local+2); /*=*/
	if (w==NIL) goto geopackIF897;
	local[2]= argv[0];
	local[3]= fqv[110];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	w = fqv[149];
	if (memq(local[2],w)==NIL) goto geopackIF899;
	local[2]= makeflt(0.0000000000000000000000e+00);
	goto geopackIF900;
geopackIF899:
	local[2]= (pointer)get_sym_func(fqv[112]);
	local[3]= argv[0];
	local[4]= fqv[91];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[73];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(*ftab[14])(ctx,3,local+3,&ftab[14],fqv[113]); /*send-all*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,2,local+2); /*apply*/
	local[2]= w;
geopackIF900:
	goto geopackIF898;
geopackIF897:
	local[2]= local[1];
	local[3]= argv[0];
	local[4]= fqv[110];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	w = fqv[150];
	if (memq(local[3],w)==NIL) goto geopackIF901;
	local[3]= local[0];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)VDISTANCE(ctx,2,local+3); /*distance*/
	local[3]= w;
	goto geopackIF902;
geopackIF901:
	local[3]= (pointer)get_sym_func(fqv[112]);
	local[4]= argv[0];
	local[5]= fqv[91];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[73];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[14])(ctx,3,local+4,&ftab[14],fqv[113]); /*send-all*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,2,local+3); /*apply*/
	local[3]= w;
geopackIF902:
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
geopackIF898:
	w = local[2];
	local[0]= w;
geopackBLK896:
	ctx->vsp=local; return(local[0]);}

/*:area*/
static pointer geopackM903face_area(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[12]));
	local[2]= fqv[118];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	local[0]= w;
	local[1]= (pointer)get_sym_func(fqv[115]);
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[118];
	ctx->vsp=local+4;
	w=(*ftab[14])(ctx,2,local+2,&ftab[14],fqv[113]); /*send-all*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
geopackBLK904:
	ctx->vsp=local; return(local[0]);}

/*:centroid*/
static pointer geopackM905face_centroid(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT908;}
	local[0]= NIL;
geopackENT908:
geopackENT907:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[12]));
	local[3]= fqv[151];
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,4,local+1); /*send-message*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[151];
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(*ftab[14])(ctx,3,local+2,&ftab[14],fqv[113]); /*send-all*/
	local[2]= w;
	local[3]= (pointer)get_sym_func(fqv[152]);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,2,local+3); /*apply*/
	local[3]= w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= (pointer)get_sym_func(fqv[115]);
	local[6]= (pointer)get_sym_func(fqv[153]);
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,2,local+5); /*apply*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	local[5]= NIL;
	local[6]= local[2];
geopackWHL909:
	if (local[6]==NIL) goto geopackWHX910;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[3];
	local[8]= (pointer)get_sym_func(fqv[152]);
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)APPLY(ctx,2,local+8); /*apply*/
	local[8]= w;
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)VMINUS(ctx,3,local+7); /*v-*/
	goto geopackWHL909;
geopackWHX910:
	local[7]= NIL;
geopackBLK911:
	w = NIL;
	if (local[0]==NIL) goto geopackIF912;
	local[5]= local[4];
	local[6]= argv[0];
	local[7]= fqv[104];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	local[6]= makeflt(-3.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= makeflt(2.5000000000000000000000e-01);
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,2,local+7); /*scale*/
	local[7]= w;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(*ftab[1])(ctx,3,local+6,&ftab[1],fqv[11]); /*midpoint*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,2,local+5); /*list*/
	local[5]= w;
	goto geopackIF913;
geopackIF912:
	local[5]= local[4];
	local[6]= makeflt(1.0000000000000000000000e+00);
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SCALEVEC(ctx,2,local+6); /*scale*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,2,local+5); /*list*/
	local[5]= w;
geopackIF913:
	w = local[5];
	local[0]= w;
geopackBLK906:
	ctx->vsp=local; return(local[0]);}

/*:on-vertex*/
static pointer geopackM914face_on_vertex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT917;}
	local[0]= loadglobal(fqv[23]);
geopackENT917:
	w = local[0];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
geopackENT916:
	if (n>4) maerror();
	local[3]= NIL;
	local[4]= NIL;
	local[5]= (pointer)get_sym_func(fqv[154]);
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[12]));
	local[8]= fqv[121];
	local[9]= argv[2];
	local[10]= loadglobal(fqv[8]);
	ctx->vsp=local+11;
	w=(pointer)SENDMESSAGE(ctx,5,local+6); /*send-message*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[8];
	local[8]= fqv[121];
	local[9]= argv[2];
	local[10]= loadglobal(fqv[8]);
	ctx->vsp=local+11;
	w=(*ftab[14])(ctx,4,local+7,&ftab[14],fqv[113]); /*send-all*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,3,local+5); /*apply*/
	local[5]= w;
	ctx->vsp=local+6;
	unbindx(ctx,1);
	w = local[5];
	local[0]= w;
geopackBLK915:
	ctx->vsp=local; return(local[0]);}

/*:on-edge*/
static pointer geopackM918face_on_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT921;}
	local[0]= loadglobal(fqv[23]);
geopackENT921:
geopackENT920:
	if (n>4) maerror();
	local[1]= (pointer)get_sym_func(fqv[154]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[12]));
	local[4]= fqv[155];
	local[5]= argv[2];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SENDMESSAGE(ctx,5,local+2); /*send-message*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[155];
	local[5]= argv[2];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[14])(ctx,4,local+3,&ftab[14],fqv[113]); /*send-all*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,3,local+1); /*apply*/
	local[0]= w;
geopackBLK919:
	ctx->vsp=local; return(local[0]);}

/*:invert*/
static pointer geopackM922face_invert(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[12]));
	local[2]= fqv[156];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= fqv[156];
	ctx->vsp=local+2;
	w=(*ftab[14])(ctx,2,local+0,&ftab[14],fqv[113]); /*send-all*/
	local[0]= w;
geopackBLK923:
	ctx->vsp=local; return(local[0]);}

/*:holes*/
static pointer geopackM924face_holes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
geopackBLK925:
	ctx->vsp=local; return(local[0]);}

/*:enter-hole*/
static pointer geopackM926face_enter_hole(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[8];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[8] = cons(ctx,local[0],w);
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
geopackBLK927:
	ctx->vsp=local; return(local[0]);}

/*:transform-normal*/
static pointer geopackM928face_transform_normal(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[12]));
	local[2]= fqv[157];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SENDMESSAGE(ctx,4,local+0); /*send-message*/
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= fqv[157];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[14])(ctx,3,local+0,&ftab[14],fqv[113]); /*send-all*/
	local[0]= w;
geopackBLK929:
	ctx->vsp=local; return(local[0]);}

/*:reset-normal*/
static pointer geopackM930face_reset_normal(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[12]));
	local[2]= fqv[133];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= fqv[133];
	ctx->vsp=local+2;
	w=(*ftab[14])(ctx,2,local+0,&ftab[14],fqv[113]); /*send-all*/
	local[0]= w;
geopackBLK931:
	ctx->vsp=local; return(local[0]);}

/*:face*/
static pointer geopackM932face_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0];
	local[0]= w;
geopackBLK933:
	ctx->vsp=local; return(local[0]);}

/*:all-edges*/
static pointer geopackM934face_all_edges(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[4];
	local[1]= (pointer)get_sym_func(fqv[158]);
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[60];
	ctx->vsp=local+4;
	w=(*ftab[14])(ctx,2,local+2,&ftab[14],fqv[113]); /*send-all*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
geopackBLK935:
	ctx->vsp=local; return(local[0]);}

/*:all-vertices*/
static pointer geopackM936face_all_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= (pointer)get_sym_func(fqv[158]);
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[140];
	ctx->vsp=local+4;
	w=(*ftab[14])(ctx,2,local+2,&ftab[14],fqv[113]); /*send-all*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
geopackBLK937:
	ctx->vsp=local; return(local[0]);}

/*:body*/
static pointer geopackM938face_body(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT941;}
	local[0]= NIL;
geopackENT941:
geopackENT940:
	if (n>3) maerror();
	if (local[0]==NIL) goto geopackIF942;
	argv[0]->c.obj.iv[9] = local[0];
	local[1]= argv[0]->c.obj.iv[9];
	goto geopackIF943;
geopackIF942:
	local[1]= argv[0]->c.obj.iv[9];
geopackIF943:
	w = local[1];
	local[0]= w;
geopackBLK939:
	ctx->vsp=local; return(local[0]);}

/*:primitive-face*/
static pointer geopackM944face_primitive_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT947;}
	local[0]= NIL;
geopackENT947:
geopackENT946:
	if (n>3) maerror();
	if (local[0]==NIL) goto geopackIF948;
	argv[0]->c.obj.iv[10] = local[0];
	local[1]= argv[0]->c.obj.iv[10];
	goto geopackIF949;
geopackIF948:
	local[1]= NIL;
geopackIF949:
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
geopackBLK945:
	ctx->vsp=local; return(local[0]);}

/*:primitive-body*/
static pointer geopackM950face_primitive_body(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[10];
	local[1]= fqv[66];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
geopackBLK951:
	ctx->vsp=local; return(local[0]);}

/*:id*/
static pointer geopackM952face_id(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT955;}
	local[0]= NIL;
geopackENT955:
geopackENT954:
	if (n>3) maerror();
	if (local[0]==NIL) goto geopackIF956;
	argv[0]->c.obj.iv[11] = local[0];
	local[1]= argv[0]->c.obj.iv[11];
	goto geopackIF957;
geopackIF956:
	local[1]= argv[0]->c.obj.iv[11];
geopackIF957:
	w = local[1];
	local[0]= w;
geopackBLK953:
	ctx->vsp=local; return(local[0]);}

/*:face-id*/
static pointer geopackM958face_face_id(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[10];
	local[1]= fqv[66];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[159];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w = argv[0]->c.obj.iv[11];
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
geopackBLK959:
	ctx->vsp=local; return(local[0]);}

/*:primitive-body-type*/
static pointer geopackM960face_primitive_body_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[10];
	local[1]= fqv[66];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[160];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
geopackBLK961:
	ctx->vsp=local; return(local[0]);}

/*:body-type*/
static pointer geopackM962face_body_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[9];
	local[1]= fqv[160];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
geopackBLK963:
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer geopackM964face_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= (pointer)get_sym_func(fqv[82]);
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[12]));
	local[3]= fqv[13];
	local[4]= argv[2];
	if (argv[0]->c.obj.iv[9]==NIL) goto geopackIF966;
	local[5]= argv[0]->c.obj.iv[9];
	local[6]= fqv[160];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	goto geopackIF967;
geopackIF966:
	local[5]= fqv[161];
geopackIF967:
	local[6]= argv[0]->c.obj.iv[11];
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,7,local+0); /*apply*/
	local[0]= w;
geopackBLK965:
	ctx->vsp=local; return(local[0]);}

/*:copied-primitive-face-p*/
static pointer geopackM968face_copied_primitive_face_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[9];
	local[1]= fqv[162];
	ctx->vsp=local+2;
	w=(pointer)GETPROP(ctx,2,local+0); /*get*/
	local[0]= w;
geopackBLK969:
	ctx->vsp=local; return(local[0]);}

/*:primitive-body*/
static pointer geopackM970face_primitive_body(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[10];
	local[1]= fqv[66];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
geopackBLK971:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer geopackM972face_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[163], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto geopackKEY974;
	local[0] = NIL;
geopackKEY974:
	if (n & (1<<1)) goto geopackKEY975;
	local[1] = NIL;
geopackKEY975:
	if (n & (1<<2)) goto geopackKEY976;
	local[2] = NIL;
geopackKEY976:
	if (n & (1<<3)) goto geopackKEY977;
	local[3] = NIL;
geopackKEY977:
	if (n & (1<<4)) goto geopackKEY978;
	local[4] = NIL;
geopackKEY978:
	if (n & (1<<5)) goto geopackKEY979;
	local[5] = NIL;
geopackKEY979:
	if (n & (1<<6)) goto geopackKEY980;
	local[6] = NIL;
geopackKEY980:
	if (n & (1<<7)) goto geopackKEY981;
	local[7] = argv[0];
geopackKEY981:
	argv[0]->c.obj.iv[8] = local[4];
	local[8]= local[4];
	local[9]= fqv[130];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[14])(ctx,3,local+8,&ftab[14],fqv[113]); /*send-all*/
	if (local[5]==NIL) goto geopackIF982;
	argv[0]->c.obj.iv[11] = local[5];
	local[8]= argv[0]->c.obj.iv[11];
	goto geopackIF983;
geopackIF982:
	local[8]= NIL;
geopackIF983:
	argv[0]->c.obj.iv[10] = local[7];
	if (local[6]==NIL) goto geopackIF984;
	argv[0]->c.obj.iv[9] = local[6];
	local[8]= argv[0]->c.obj.iv[9];
	goto geopackIF985;
geopackIF984:
	local[8]= NIL;
geopackIF985:
	local[8]= argv[0];
	local[9]= *(ovafptr(argv[1],fqv[12]));
	local[10]= fqv[24];
	local[11]= fqv[64];
	local[12]= local[0];
	local[13]= fqv[73];
	local[14]= local[1];
	local[15]= fqv[60];
	local[16]= local[2];
	local[17]= fqv[140];
	local[18]= local[3];
	ctx->vsp=local+19;
	w=(pointer)SENDMESSAGE(ctx,11,local+8); /*send-message*/
	w = argv[0];
	local[0]= w;
geopackBLK973:
	ctx->vsp=local; return(local[0]);}

/*:reflectance*/
static pointer geopackM986face_reflectance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT989;}
	local[0]= NIL;
geopackENT989:
geopackENT988:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= NIL;
	if (local[0]==NIL) goto geopackIF990;
	local[3]= argv[0];
	local[4]= local[0];
	local[5]= fqv[164];
	ctx->vsp=local+6;
	w=(pointer)PUTPROP(ctx,3,local+3); /*putprop*/
	local[3]= w;
	goto geopackIF991;
geopackIF990:
	local[3]= argv[0];
	local[4]= fqv[164];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[2] = w;
	if (local[2]==NIL) goto geopackIF992;
	local[3]= local[2];
	goto geopackIF993;
geopackIF992:
	local[3]= argv[0]->c.obj.iv[9];
	local[4]= fqv[164];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
geopackIF993:
geopackIF991:
	w = local[3];
	local[0]= w;
geopackBLK987:
	ctx->vsp=local; return(local[0]);}

/*:diffusion*/
static pointer geopackM994face_diffusion(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT997;}
	local[0]= NIL;
geopackENT997:
geopackENT996:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= NIL;
	if (local[0]==NIL) goto geopackIF998;
	local[3]= argv[0];
	local[4]= local[0];
	local[5]= fqv[165];
	ctx->vsp=local+6;
	w=(pointer)PUTPROP(ctx,3,local+3); /*putprop*/
	local[3]= w;
	goto geopackIF999;
geopackIF998:
	local[3]= argv[0];
	local[4]= fqv[165];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[2] = w;
	if (local[2]==NIL) goto geopackIF1000;
	local[3]= local[2];
	goto geopackIF1001;
geopackIF1000:
	local[3]= argv[0]->c.obj.iv[9];
	local[4]= fqv[165];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
geopackIF1001:
geopackIF999:
	w = local[3];
	local[0]= w;
geopackBLK995:
	ctx->vsp=local; return(local[0]);}

/*:color*/
static pointer geopackM1002face_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT1005;}
	local[0]= NIL;
geopackENT1005:
geopackENT1004:
	if (n>3) maerror();
	if (local[0]==NIL) goto geopackIF1006;
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= fqv[80];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= w;
	goto geopackIF1007;
geopackIF1006:
	local[1]= argv[0];
	local[2]= fqv[80];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[0] = w;
	if (local[0]==NIL) goto geopackIF1008;
	local[1]= local[0];
	goto geopackIF1009;
geopackIF1008:
	if (argv[0]->c.obj.iv[9]==NIL) goto geopackIF1010;
	local[1]= argv[0]->c.obj.iv[9];
	local[2]= fqv[80];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto geopackIF1011;
geopackIF1010:
	local[1]= NIL;
geopackIF1011:
geopackIF1009:
geopackIF1007:
	w = local[1];
	local[0]= w;
geopackBLK1003:
	ctx->vsp=local; return(local[0]);}

/*:contact-edge*/
static pointer geopackM1012face_contact_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= *(ovafptr(argv[0],fqv[78]));
	local[2]= argv[2]->c.obj.iv[2];
	local[3]= argv[2]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)VMINUS(ctx,2,local+2); /*v-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VINNERPRODUCT(ctx,2,local+1); /*v.*/
	local[1]= makeflt((double)fabs(fltval(w)));
	local[2]= loadglobal(fqv[23]);
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto geopackIF1014;
	w = NIL;
	ctx->vsp=local+1;
	local[0]=w;
	goto geopackBLK1013;
	goto geopackIF1015;
geopackIF1014:
	local[1]= NIL;
geopackIF1015:
	local[1]= NIL;
	local[2]= argv[0];
	local[3]= fqv[91];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
geopackWHL1016:
	if (local[2]==NIL) goto geopackWHX1017;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= argv[2];
	local[4]= fqv[166];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[0] = w;
	if (local[0]==NIL) goto geopackIF1019;
	w = local[0];
	ctx->vsp=local+3;
	local[0]=w;
	goto geopackBLK1013;
	goto geopackIF1020;
geopackIF1019:
	local[3]= NIL;
geopackIF1020:
	goto geopackWHL1016;
geopackWHX1017:
	local[3]= NIL;
geopackBLK1018:
	w = NIL;
	local[0]= w;
geopackBLK1013:
	ctx->vsp=local; return(local[0]);}

/*:contact-point*/
static pointer geopackM1021face_contact_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto geopackENT1024;}
	local[0]= loadglobal(fqv[23]);
geopackENT1024:
geopackENT1023:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[12]));
	local[3]= fqv[145];
	local[4]= argv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SENDMESSAGE(ctx,5,local+1); /*send-message*/
	local[1]= w;
	local[2]= local[1];
	if (fqv[120]==local[2]) goto geopackIF1025;
	local[2]= local[1];
	goto geopackIF1026;
geopackIF1025:
	local[2]= NIL;
	local[3]= argv[0]->c.obj.iv[8];
geopackWHL1027:
	if (local[3]==NIL) goto geopackWHX1028;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	local[5]= fqv[145];
	local[6]= argv[2];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[1] = w;
	local[4]= local[1];
	if (fqv[120]!=local[4]) goto geopackIF1030;
	w = fqv[51];
	ctx->vsp=local+4;
	local[0]=w;
	goto geopackBLK1022;
	goto geopackIF1031;
geopackIF1030:
	local[4]= local[1];
	if (fqv[119]!=local[4]) goto geopackIF1032;
	w = fqv[119];
	ctx->vsp=local+4;
	local[0]=w;
	goto geopackBLK1022;
	goto geopackIF1033;
geopackIF1032:
	local[4]= NIL;
geopackIF1033:
geopackIF1031:
	goto geopackWHL1027;
geopackWHX1028:
	local[4]= NIL;
geopackBLK1029:
	w = NIL;
	local[2]= fqv[120];
geopackIF1026:
	w = local[2];
	local[0]= w;
geopackBLK1022:
	ctx->vsp=local; return(local[0]);}

/*:face*/
static pointer geopackM1034hole_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto geopackENT1037;}
	local[0]= NIL;
geopackENT1037:
geopackENT1036:
	if (n>3) maerror();
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)geopackF18facep(ctx,1,local+1); /*facep*/
	if (w==NIL) goto geopackIF1038;
	argv[0]->c.obj.iv[8] = local[0];
	local[1]= argv[0]->c.obj.iv[8];
	goto geopackIF1039;
geopackIF1038:
	local[1]= NIL;
geopackIF1039:
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
geopackBLK1035:
	ctx->vsp=local; return(local[0]);}

/*:hollowed-faces*/
static pointer geopackM1040hole_hollowed_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[4];
geopackWHL1042:
	if (local[2]==NIL) goto geopackWHX1043;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1]->c.obj.iv[3];
	local[4]= local[1]->c.obj.iv[4];
	local[5]= local[3];
	if (argv[0]->c.obj.iv[8]==local[5]) goto geopackIF1045;
	local[5]= local[3];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[16])(ctx,2,local+5,&ftab[16],fqv[167]); /*adjoin*/
	local[0] = w;
	local[5]= local[0];
	goto geopackIF1046;
geopackIF1045:
	local[5]= NIL;
geopackIF1046:
	local[5]= local[4];
	if (argv[0]->c.obj.iv[8]==local[5]) goto geopackIF1047;
	local[5]= local[4];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[16])(ctx,2,local+5,&ftab[16],fqv[167]); /*adjoin*/
	local[0] = w;
	local[5]= local[0];
	goto geopackIF1048;
geopackIF1047:
	local[5]= NIL;
geopackIF1048:
	w = local[5];
	goto geopackWHL1042;
geopackWHX1043:
	local[3]= NIL;
geopackBLK1044:
	w = NIL;
	w = local[0];
	local[0]= w;
geopackBLK1041:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer geopackM1049hole_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[168], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto geopackKEY1051;
	local[0] = NIL;
geopackKEY1051:
	if (n & (1<<1)) goto geopackKEY1052;
	local[1] = NIL;
geopackKEY1052:
	if (n & (1<<2)) goto geopackKEY1053;
	local[2] = NIL;
geopackKEY1053:
	if (n & (1<<3)) goto geopackKEY1054;
	local[3] = NIL;
geopackKEY1054:
	if (n & (1<<4)) goto geopackKEY1055;
	local[4] = NIL;
geopackKEY1055:
	argv[0]->c.obj.iv[8] = local[4];
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[12]));
	local[7]= fqv[24];
	local[8]= fqv[64];
	local[9]= local[0];
	local[10]= fqv[73];
	local[11]= local[1];
	local[12]= fqv[60];
	local[13]= local[2];
	local[14]= fqv[140];
	local[15]= local[3];
	ctx->vsp=local+16;
	w=(pointer)SENDMESSAGE(ctx,11,local+5); /*send-message*/
	w = argv[0];
	local[0]= w;
geopackBLK1050:
	ctx->vsp=local; return(local[0]);}

/*make-plane*/
static pointer geopackF38make_plane(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[169], &argv[0], n-0, local+0, 0);
	if (n & (1<<0)) goto geopackKEY1057;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[0] = w;
geopackKEY1057:
	if (n & (1<<1)) goto geopackKEY1058;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[1] = w;
geopackKEY1058:
	if (n & (1<<2)) goto geopackKEY1059;
	local[2] = NIL;
geopackKEY1059:
	w = local[1];
	if (!iscons(w)) goto geopackIF1060;
	local[3]= local[1];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)geopackF9face_normal_vector(ctx,2,local+3); /*face-normal-vector*/
	local[0] = w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.car;
	local[3]= local[1];
	goto geopackIF1061;
geopackIF1060:
	local[3]= NIL;
geopackIF1061:
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)VNORMALIZE(ctx,1,local+3); /*normalize-vector*/
	local[0] = w;
	if (local[2]==NIL) goto geopackIF1062;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,1,local+3); /*-*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,2,local+3); /*scale*/
	local[1] = w;
	local[3]= local[1];
	goto geopackIF1063;
geopackIF1062:
	local[3]= NIL;
geopackIF1063:
	local[3]= loadglobal(fqv[147]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[24];
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = local[3];
	local[0]= w;
geopackBLK1056:
	ctx->vsp=local; return(local[0]);}

/*make-polygon*/
static pointer geopackF39make_polygon(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
geopackRST1065:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= loadglobal(fqv[170]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[24];
	local[4]= fqv[140];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[0]= w;
geopackBLK1064:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___geopack(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[171];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto geopackIF1066;
	local[0]= fqv[172];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[173],w);
	goto geopackIF1067;
geopackIF1066:
	local[0]= fqv[174];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
geopackIF1067:
	local[0]= fqv[175];
	local[1]= fqv[176];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[177]); /*require*/
	local[0]= fqv[178];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[131];
	local[1]= fqv[179];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geopackIF1068;
	local[0]= fqv[131];
	local[1]= fqv[179];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[131];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto geopackIF1070;
	local[0]= fqv[131];
	local[1]= fqv[180];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto geopackIF1071;
geopackIF1070:
	local[0]= NIL;
geopackIF1071:
	local[0]= fqv[131];
	goto geopackIF1069;
geopackIF1068:
	local[0]= NIL;
geopackIF1069:
	local[0]= fqv[181];
	local[1]= fqv[179];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geopackIF1072;
	local[0]= fqv[181];
	local[1]= fqv[179];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[181];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto geopackIF1074;
	local[0]= fqv[181];
	local[1]= fqv[180];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto geopackIF1075;
geopackIF1074:
	local[0]= NIL;
geopackIF1075:
	local[0]= fqv[181];
	goto geopackIF1073;
geopackIF1072:
	local[0]= NIL;
geopackIF1073:
	local[0]= fqv[182];
	local[1]= fqv[179];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geopackIF1076;
	local[0]= fqv[182];
	local[1]= fqv[179];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[182];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto geopackIF1078;
	local[0]= fqv[182];
	local[1]= fqv[180];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto geopackIF1079;
geopackIF1078:
	local[0]= NIL;
geopackIF1079:
	local[0]= fqv[182];
	goto geopackIF1077;
geopackIF1076:
	local[0]= NIL;
geopackIF1077:
	local[0]= fqv[183];
	local[1]= fqv[179];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto geopackIF1080;
	local[0]= fqv[183];
	local[1]= fqv[179];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[183];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto geopackIF1082;
	local[0]= fqv[183];
	local[1]= fqv[180];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto geopackIF1083;
geopackIF1082:
	local[0]= NIL;
geopackIF1083:
	local[0]= fqv[183];
	goto geopackIF1081;
geopackIF1080:
	local[0]= NIL;
geopackIF1081:
	local[0]= fqv[35];
	local[1]= fqv[184];
	local[2]= makeflt(9.9999999999999950039964e-03);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[45];
	local[1]= fqv[184];
	local[2]= makeflt(9.9999999999999950039964e-03);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[8];
	local[1]= fqv[184];
	local[2]= makeflt(4.9999999999999975019982e-03);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[23];
	local[1]= fqv[184];
	local[2]= makeflt(8.0000000000000001665335e-03);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[76];
	local[1]= fqv[184];
	local[2]= makeflt(1.0000000000000000208167e-03);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[79];
	local[1]= fqv[184];
	local[2]= makeflt(9.9999999999999977795540e-02);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[185];
	ctx->vsp=local+1;
	w=(pointer)PROCLAIM(ctx,1,local+0); /*proclaim*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[186],module,geopackF3vplus,fqv[187]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[188],module,geopackF4vector_mean,fqv[189]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[190],module,geopackF5direction_vector,fqv[191]);
	local[0]= fqv[192];
	local[1]= fqv[180];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[193];
	local[1]= fqv[180];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[194],module,geopackF6triangle,fqv[195]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[196],module,geopackF7triangle_normal,fqv[197]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[198],module,geopackF8vector_angle,fqv[199]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[200],module,geopackF9face_normal_vector,fqv[201]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[202],module,geopackF10farthest,fqv[203]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[204],module,geopackF11farthest_pair,fqv[205]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[206],module,geopackF12maxindex,fqv[207]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[208],module,geopackF13random_vector,fqv[209]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[210],module,geopackF14random_normalized_vector,fqv[211]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[212],module,geopackF15random_vector2,fqv[213]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[214],module,geopackF16random_vectors,fqv[215]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[216],module,geopackF17edgep,fqv[217]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[218],module,geopackF18facep,fqv[219]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[220],module,geopackF19bodyp,fqv[221]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[222],module,geopackF20primitive_body_p,fqv[223]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[224],module,geopackF21n_2,fqv[225]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[226],module,geopackF22eps_,fqv[227]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[228],module,geopackF23eps_,fqv[229]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[230],module,geopackF24eps_,fqv[231]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[232],module,geopackF25eps__,fqv[233]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[234],module,geopackF26eps__,fqv[235]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[236],module,geopackF27eps__,fqv[237]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[238],module,geopackF28eps_zero,fqv[239]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[240],module,geopackF29eps_in_range,fqv[241]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[242],module,geopackF30eps_v_,fqv[243]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[244],module,geopackF31eps_coords_,fqv[245]);
	local[0]= loadglobal(fqv[15]);
	storeglobal(fqv[246],local[0]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM128bounding_box_box,fqv[25],fqv[15],fqv[247]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM134bounding_box_minpoint,fqv[248],fqv[15],fqv[249]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM136bounding_box_maxpoint,fqv[250],fqv[15],fqv[251]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM138bounding_box_center,fqv[252],fqv[15],fqv[253]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM140bounding_box_diagonal,fqv[254],fqv[15],fqv[255]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM142bounding_box_prin1,fqv[13],fqv[15],fqv[256]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM146bounding_box_inner,fqv[137],fqv[15],fqv[257]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM149bounding_box_intersection,fqv[26],fqv[15],fqv[258]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM157bounding_box_union,fqv[27],fqv[15],fqv[259]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM161bounding_box_intersection_p,fqv[28],fqv[15],fqv[260]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM163bounding_box_grow,fqv[10],fqv[15],fqv[261]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM169bounding_box_volume,fqv[262],fqv[15],fqv[263]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM171bounding_box_extream_point,fqv[18],fqv[15],fqv[264]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM178bounding_box_below,fqv[265],fqv[15],fqv[266]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM182bounding_box_corners,fqv[267],fqv[15],fqv[268]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM192bounding_box_body,fqv[66],fqv[15],fqv[269]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM194bounding_box_init2,fqv[16],fqv[15],fqv[270]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM200bounding_box_init,fqv[24],fqv[15],fqv[271]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[272],module,geopackF32make_bounding_box,fqv[273]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[274],module,geopackF33make_big_bounding_box,fqv[275]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[276],module,geopackF34bounding_box_intersection,fqv[277]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[278],module,geopackF35bounding_box_union,fqv[279]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM224line_nvertex,fqv[55],fqv[43],fqv[280]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM228line_pvertex,fqv[54],fqv[43],fqv[281]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM232line_vertices,fqv[140],fqv[43],fqv[282]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM234line_eq,fqv[283],fqv[43],fqv[284]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM237line_eql,fqv[285],fqv[43],fqv[286]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM242line_equall,fqv[287],fqv[43],fqv[288]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM247line_parameter,fqv[48],fqv[43],fqv[289]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM249line_point,fqv[37],fqv[43],fqv[290]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM251line_box,fqv[25],fqv[43],fqv[291]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM255line_boxtest,fqv[143],fqv[43],fqv[292]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM259line_length,fqv[116],fqv[43],fqv[293]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM261line_end_point,fqv[294],fqv[43],fqv[295]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM267line_direction,fqv[61],fqv[43],fqv[296]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM269line_prin1,fqv[13],fqv[43],fqv[297]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM272line_init,fqv[24],fqv[43],fqv[298]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM283line_foot,fqv[38],fqv[43],fqv[299]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM285line_common_perpendicular,fqv[75],fqv[43],fqv[300]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM289line_distance_point,fqv[41],fqv[43],fqv[301]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM295line_distance_line,fqv[44],fqv[43],fqv[302]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM301line_distance,fqv[73],fqv[43],fqv[303]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM303line_distance,fqv[73],fqv[43],fqv[304]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM308line_colinear_point,fqv[47],fqv[43],fqv[305]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM312line_on_line_point,fqv[134],fqv[43],fqv[306]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM316line_colinear_line,fqv[307],fqv[43],fqv[308]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM321line_colinear_line_intersection,fqv[309],fqv[43],fqv[310]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM329line_coplanar,fqv[311],fqv[43],fqv[312]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM333line_project,fqv[50],fqv[43],fqv[313]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM335line_intersection,fqv[26],fqv[43],fqv[314]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM337line_intersect_line,fqv[125],fqv[43],fqv[315]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[316],module,geopackF36make_line,fqv[317]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM360edge_faces,fqv[318],fqv[4],fqv[319]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM362edge_pvertex,fqv[54],fqv[4],fqv[320]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM368edge_nvertex,fqv[55],fqv[4],fqv[321]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM374edge_next_edge,fqv[58],fqv[4],fqv[322]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM376edge_next_vertex,fqv[323],fqv[4],fqv[324]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM378edge_direction,fqv[61],fqv[4],fqv[325]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM392edge_next_edge_angle,fqv[326],fqv[4],fqv[327]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM394edge_previous_edge_angle,fqv[328],fqv[4],fqv[329]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM396edge_body,fqv[66],fqv[4],fqv[330]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM401edge_pface,fqv[132],fqv[4],fqv[331]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM407edge_nface,fqv[332],fqv[4],fqv[333]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM413edge_another_face,fqv[334],fqv[4],fqv[335]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM419edge_binormal,fqv[336],fqv[4],fqv[337]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM425edge_angle,fqv[338],fqv[4],fqv[339]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM427edge_approximated_p,fqv[340],fqv[4],fqv[341]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM429edge_flags,fqv[342],fqv[4],fqv[343]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM431edge_contourp,fqv[344],fqv[4],fqv[345]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM438edge_set_approximated_flag,fqv[83],fqv[4],fqv[346]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM444edge_invert,fqv[156],fqv[4],fqv[347]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM446edge_set_angle,fqv[348],fqv[4],fqv[349]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM448edge_set_face,fqv[350],fqv[4],fqv[351]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM454edge_contact,fqv[166],fqv[4],fqv[352]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM460edge_neighborpoints,fqv[353],fqv[4],fqv[354]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM462edge_anothervertex,fqv[77],fqv[4],fqv[355]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM466edge_color,fqv[80],fqv[4],fqv[356]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM474edge_init,fqv[24],fqv[4],fqv[357]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM490edge_center_coordinates,fqv[358],fqv[4],fqv[359]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM494edge_pwing,fqv[99],fqv[4],fqv[360]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM502edge_pcwing,fqv[101],fqv[4],fqv[361]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM510edge_nwing,fqv[100],fqv[4],fqv[362]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM518edge_ncwing,fqv[102],fqv[4],fqv[363]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM526edge_connected_vertex,fqv[364],fqv[4],fqv[365]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM534edge_replace_face,fqv[366],fqv[4],fqv[367]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[368],module,geopackF37winged_edge_p,fqv[369]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM541winged_edge_set_wings,fqv[370],fqv[98],fqv[371]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM543winged_edge_pwing,fqv[99],fqv[98],fqv[372]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM545winged_edge_nwing,fqv[100],fqv[98],fqv[373]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM547winged_edge_pcwing,fqv[101],fqv[98],fqv[374]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM549winged_edge_ncwing,fqv[102],fqv[98],fqv[375]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM551winged_edge_init,fqv[24],fqv[98],fqv[376]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM566plane_id,fqv[377],fqv[147],fqv[378]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM568plane_normal,fqv[64],fqv[147],fqv[379]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM570plane_distance,fqv[73],fqv[147],fqv[380]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM572plane_plane_distance,fqv[104],fqv[147],fqv[381]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM574plane_on_plane_p,fqv[382],fqv[147],fqv[383]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM578plane_coplanar_point,fqv[384],fqv[147],fqv[385]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM582plane_coplanar_line,fqv[386],fqv[147],fqv[387]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM587plane_intersection,fqv[26],fqv[147],fqv[388]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM589plane_intersect_edge,fqv[126],fqv[147],fqv[389]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM596plane_foot,fqv[38],fqv[147],fqv[390]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM598plane_original_body,fqv[391],fqv[147],fqv[392]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM600plane_brightness,fqv[393],fqv[147],fqv[394]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM602plane_project,fqv[50],fqv[147],fqv[395]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM606plane_separation,fqv[396],fqv[147],fqv[397]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM628plane_init,fqv[24],fqv[147],fqv[398]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM634polygon_face,fqv[130],fqv[170],fqv[399]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM636polygon_edges,fqv[60],fqv[170],fqv[400]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM638polygon_edge,fqv[401],fqv[170],fqv[402]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM640polygon_all_edges,fqv[91],fqv[170],fqv[403]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM642polygon_vertices,fqv[140],fqv[170],fqv[404]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM644polygon_vertex,fqv[405],fqv[170],fqv[406]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM646polygon_next_edge,fqv[58],fqv[170],fqv[407]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM650polygon_previous_edge,fqv[65],fqv[170],fqv[408]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM659polygon_adjacent_faces,fqv[409],fqv[170],fqv[410]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM666polygon_convexp,fqv[411],fqv[170],fqv[412]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM668polygon_box,fqv[25],fqv[170],fqv[413]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM672polygon_boxtest,fqv[143],fqv[170],fqv[414]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM676polygon_vertices_mean,fqv[415],fqv[170],fqv[416]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM678polygon_distance,fqv[73],fqv[170],fqv[417]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM686polygon_area,fqv[118],fqv[170],fqv[418]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM691polygon_perimeter,fqv[419],fqv[170],fqv[420]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM693polygon_volume,fqv[262],fqv[170],fqv[421]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM697polygon_centroid,fqv[151],fqv[170],fqv[422]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM706polygon_color,fqv[80],fqv[170],fqv[423]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM712polygon_insidep,fqv[110],fqv[170],fqv[424]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM737polygon_intersect_point_vector,fqv[425],fqv[170],fqv[426]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM743polygon_intersect_line,fqv[125],fqv[170],fqv[427]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM747polygon_intersect_edge,fqv[126],fqv[170],fqv[428]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM749polygon_intersect_face,fqv[429],fqv[170],fqv[430]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM758polygon_visible,fqv[431],fqv[170],fqv[432]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM762polygon_transform_normal,fqv[157],fqv[170],fqv[433]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM764polygon_reset_normal,fqv[133],fqv[170],fqv[434]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM766polygon_set_convexp,fqv[128],fqv[170],fqv[435]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM773polygon_invert,fqv[156],fqv[170],fqv[436]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM775polygon_init,fqv[24],fqv[170],fqv[437]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM799polygon_on_vertex,fqv[121],fqv[170],fqv[438]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM808polygon_on_edge,fqv[155],fqv[170],fqv[439]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM817polygon_coplanar_distance,fqv[440],fqv[170],fqv[441]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM821polygon_coplanar_intersections,fqv[144],fqv[170],fqv[442]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM849polygon_contact_edge,fqv[146],fqv[170],fqv[443]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM858polygon_contact_plane,fqv[148],fqv[170],fqv[444]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM864polygon_contact_point,fqv[145],fqv[170],fqv[445]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM870polygon_contactp,fqv[446],fqv[170],fqv[447]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM878polygon_aligned_plane,fqv[448],fqv[170],fqv[449]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM882face_insidep,fqv[110],fqv[5],fqv[450]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM895face_distance,fqv[73],fqv[5],fqv[451]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM903face_area,fqv[118],fqv[5],fqv[452]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM905face_centroid,fqv[151],fqv[5],fqv[453]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM914face_on_vertex,fqv[121],fqv[5],fqv[454]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM918face_on_edge,fqv[155],fqv[5],fqv[455]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM922face_invert,fqv[156],fqv[5],fqv[456]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM924face_holes,fqv[59],fqv[5],fqv[457]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM926face_enter_hole,fqv[458],fqv[5],fqv[459]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM928face_transform_normal,fqv[157],fqv[5],fqv[460]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM930face_reset_normal,fqv[133],fqv[5],fqv[461]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM932face_face,fqv[130],fqv[5],fqv[462]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM934face_all_edges,fqv[91],fqv[5],fqv[463]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM936face_all_vertices,fqv[464],fqv[5],fqv[465]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM938face_body,fqv[66],fqv[5],fqv[466]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM944face_primitive_face,fqv[467],fqv[5],fqv[468]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM950face_primitive_body,fqv[469],fqv[5],fqv[470]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM952face_id,fqv[377],fqv[5],fqv[471]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM958face_face_id,fqv[472],fqv[5],fqv[473]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM960face_primitive_body_type,fqv[474],fqv[5],fqv[475]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM962face_body_type,fqv[160],fqv[5],fqv[476]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM964face_prin1,fqv[13],fqv[5],fqv[477]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM968face_copied_primitive_face_p,fqv[478],fqv[5],fqv[479]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM970face_primitive_body,fqv[469],fqv[5],fqv[480]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM972face_init,fqv[24],fqv[5],fqv[481]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM986face_reflectance,fqv[164],fqv[5],fqv[482]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM994face_diffusion,fqv[165],fqv[5],fqv[483]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM1002face_color,fqv[80],fqv[5],fqv[484]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM1012face_contact_edge,fqv[146],fqv[5],fqv[485]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM1021face_contact_point,fqv[145],fqv[5],fqv[486]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM1034hole_face,fqv[130],fqv[487],fqv[488]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM1040hole_hollowed_faces,fqv[489],fqv[487],fqv[490]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,geopackM1049hole_init,fqv[24],fqv[487],fqv[491]);
	local[0]= fqv[131];
	local[1]= fqv[180];
	local[2]= loadglobal(fqv[4]);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[181];
	local[1]= fqv[180];
	local[2]= loadglobal(fqv[5]);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[492];
	local[1]= fqv[180];
	local[2]= loadglobal(fqv[487]);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[182];
	local[1]= fqv[180];
	local[2]= loadglobal(fqv[6]);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[493],module,geopackF38make_plane,fqv[494]);
	local[0]= fqv[495];
	local[1]= fqv[496];
	ctx->vsp=local+2;
	w=(pointer)geopackF38make_plane(ctx,0,local+2); /*make-plane*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[497];
	local[1]= fqv[496];
	local[2]= fqv[64];
	local[3]= fqv[498];
	ctx->vsp=local+4;
	w=(pointer)geopackF38make_plane(ctx,2,local+2); /*make-plane*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[499];
	local[1]= fqv[496];
	local[2]= fqv[64];
	local[3]= fqv[500];
	ctx->vsp=local+4;
	w=(pointer)geopackF38make_plane(ctx,2,local+2); /*make-plane*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[501],module,geopackF39make_polygon,fqv[502]);
	local[0]= fqv[503];
	local[1]= fqv[504];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[505]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<19; i++) ftab[i]=fcallx;
}

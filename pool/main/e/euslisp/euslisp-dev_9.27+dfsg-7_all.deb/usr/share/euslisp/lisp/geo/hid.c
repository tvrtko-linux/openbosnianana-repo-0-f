/* ./hid.c :  entry=hid */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "hid.h"
#pragma init (register_hid)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___hid();
extern pointer build_quote_vector();
static int register_hid()
  { add_module_initializer("___hid", ___hid);}

static pointer hidF2715check_visibility();
static pointer hidF2716make_face_image();
static pointer hidF2717set_contour_intersections();
static pointer hidF2718set_non_contour_intersections();
static pointer hidF2719curved_edge_image_p();
static pointer hidF2720hid2();

/*check-visibility*/
static pointer hidF2715check_visibility(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= NIL;
	local[1]= makeflt(0.0000000000000000000000e+00);
	w = local[1];
	ctx->vsp=local+2;
	bindspecial(ctx,fqv[0],w);
	local[5]= NIL;
	local[6]= loadglobal(fqv[1]);
hidWHL2722:
	if (local[6]==NIL) goto hidWHX2723;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[0] = local[5]->c.obj.iv[2];
	local[7]= local[0];
	if (argv[0]==local[7]) goto hidIF2725;
	local[7]= local[0];
	if (argv[1]==local[7]) goto hidIF2725;
	local[7]= local[5];
	local[8]= fqv[2];
	local[9]= argv[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	if (w==NIL) goto hidIF2725;
	local[7]= local[0];
	local[8]= fqv[3];
	local[9]= argv[2];
	local[10]= argv[4];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	if (w==NIL) goto hidIF2725;
	w = NIL;
	ctx->vsp=local+7;
	unwind(ctx,local+0);
	local[0]=w;
	goto hidBLK2721;
	goto hidIF2726;
hidIF2725:
	local[7]= NIL;
hidIF2726:
	goto hidWHL2722;
hidWHX2723:
	local[7]= NIL;
hidBLK2724:
	w = NIL;
	local[5]= T;
	ctx->vsp=local+6;
	unbindx(ctx,1);
	w = local[5];
	local[0]= w;
hidBLK2721:
	ctx->vsp=local; return(local[0]);}

/*:edge3*/
static pointer hidM2727edge_image_edge3(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[0];
	local[0]= w;
hidBLK2728:
	ctx->vsp=local; return(local[0]);}

/*:vertices*/
static pointer hidM2729edge_image_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
hidBLK2730:
	ctx->vsp=local; return(local[0]);}

/*:color*/
static pointer hidM2731edge_image_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[4];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
hidBLK2732:
	ctx->vsp=local; return(local[0]);}

/*:homo2real*/
static pointer hidM2733edge_image_homo2real(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)3L));
	  w=makeflt(local[1]->c.fvec.fv[i]);}
	{ double x,y;
		y=fltval(w); x=fltval(local[0]);
		local[0]=(makeflt(x * y));}
	local[1]= local[0];
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[2];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)3L));
	  w=makeflt(local[3]->c.fvec.fv[i]);}
	local[3]= w;
	local[4]= makeflt(1.0000000000000000000000e+00);
	{ double x,y;
		y=fltval(argv[2]); x=fltval(local[4]);
		local[4]=(makeflt(x - y));}
	{ double x,y;
		y=fltval(local[4]); x=fltval(local[3]);
		local[3]=(makeflt(x * y));}
	{ double x,y;
		y=fltval(local[3]); x=fltval(local[2]);
		local[2]=(makeflt(x + y));}
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[0]= w;
hidBLK2734:
	ctx->vsp=local; return(local[0]);}

/*:add-segment*/
static pointer hidM2735edge_image_add_segment(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto hidENT2738;}
	local[0]= NIL;
hidENT2738:
hidENT2737:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)3L));
	  w=makeflt(local[2]->c.fvec.fv[i]);}
	{ double x,y;
		y=fltval(w); x=fltval(local[1]);
		local[1]=(makeflt(x * y));}
	local[2]= local[1];
	local[3]= local[1];
	local[4]= argv[0]->c.obj.iv[2];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)3L));
	  w=makeflt(local[4]->c.fvec.fv[i]);}
	local[4]= w;
	local[5]= makeflt(1.0000000000000000000000e+00);
	{ double x,y;
		y=fltval(makeflt(-(fltval(argv[2])))); x=fltval(local[5]);
		local[5]=(makeflt(x + y));}
	{ double x,y;
		y=fltval(local[5]); x=fltval(local[4]);
		local[4]=(makeflt(x * y));}
	{ double x,y;
		y=fltval(local[4]); x=fltval(local[3]);
		local[3]=(makeflt(x + y));}
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[1] = w;
	local[2]= local[1];
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[2]);
	if (left < right) goto hidIF2739;}
	local[2]= local[1];
	{ double left,right;
		right=fltval(makeflt(1.0000000000000000000000e+00)); left=fltval(local[2]);
	if (left > right) goto hidIF2739;}
	local[2]= argv[2];
	local[3]= local[1];
	local[4]= T;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,4,local+2); /*list*/
	local[2]= w;
	w = argv[0]->c.obj.iv[5];
	ctx->vsp=local+3;
	argv[0]->c.obj.iv[5] = cons(ctx,local[2],w);
	local[2]= argv[0]->c.obj.iv[5];
	goto hidIF2740;
hidIF2739:
	local[2]= NIL;
hidIF2740:
	w = local[2];
	local[0]= w;
hidBLK2736:
	ctx->vsp=local; return(local[0]);}

/*:projected-point*/
static pointer hidM2741edge_image_projected_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	{ double x,y;
		y=fltval(argv[2]); x=fltval(local[0]);
		local[0]=(makeflt(x - y));}
	local[1]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+2;
	w=(pointer)SCALEVEC(ctx,2,local+0); /*scale*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,2,local+1); /*scale*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VPLUS(ctx,2,local+0); /*v+*/
	local[0]= w;
hidBLK2742:
	ctx->vsp=local; return(local[0]);}

/*:projected-homo-point*/
static pointer hidM2743edge_image_projected_homo_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	{ double x,y;
		y=fltval(argv[2]); x=fltval(local[0]);
		local[0]=(makeflt(x - y));}
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)SCALEVEC(ctx,2,local+0); /*scale*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,2,local+1); /*scale*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VPLUS(ctx,2,local+0); /*v+*/
	local[0]= w;
hidBLK2744:
	ctx->vsp=local; return(local[0]);}

/*:intersecting-point*/
static pointer hidM2745edge_image_intersecting_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= argv[0]->c.obj.iv[4];
	local[2]= argv[2]->c.obj.iv[3];
	local[3]= argv[2]->c.obj.iv[4];
	local[4]= T;
	ctx->vsp=local+5;
	w=(pointer)LINEINTERSECTION(ctx,5,local+0); /*line-intersection*/
	local[0]= w;
	if (local[0]==NIL) goto hidIF2747;
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[5];
	local[3]= argv[0];
	local[4]= fqv[6];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto hidIF2748;
hidIF2747:
	local[1]= NIL;
hidIF2748:
	w = local[1];
	local[0]= w;
hidBLK2746:
	ctx->vsp=local; return(local[0]);}

/*:projected-intersection*/
static pointer hidM2749edge_image_projected_intersection(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= argv[0]->c.obj.iv[4];
	local[2]= argv[2]->c.obj.iv[3];
	local[3]= argv[2]->c.obj.iv[4];
	local[4]= T;
	ctx->vsp=local+5;
	w=(pointer)LINEINTERSECTION(ctx,5,local+0); /*line-intersection*/
	local[0]= w;
	if (local[0]==NIL) goto hidIF2751;
	local[1]= argv[0];
	local[2]= fqv[7];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	if (argv[3]==NIL) goto hidIF2753;
	local[1]= argv[2];
	local[2]= fqv[7];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto hidIF2754;
hidIF2753:
	local[1]= NIL;
hidIF2754:
	goto hidIF2752;
hidIF2751:
	local[1]= NIL;
hidIF2752:
	w = local[1];
	local[0]= w;
hidBLK2750:
	ctx->vsp=local; return(local[0]);}

/*:sort-segments*/
static pointer hidM2755edge_image_sort_segments(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= (pointer)get_sym_func(fqv[8]);
	local[2]= (pointer)get_sym_func(fqv[9]);
	ctx->vsp=local+3;
	w=(pointer)SORT(ctx,3,local+0); /*sort*/
	argv[0]->c.obj.iv[5] = w;
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
hidBLK2756:
	ctx->vsp=local; return(local[0]);}

/*:box*/
static pointer hidM2757edge_image_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[10]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[11];
	local[3]= argv[0]->c.obj.iv[3];
	local[4]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
hidBLK2758:
	ctx->vsp=local; return(local[0]);}

/*:contourp*/
static pointer hidM2759edge_image_contourp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[6];
	local[0]= w;
hidBLK2760:
	ctx->vsp=local; return(local[0]);}

/*:mark-visible-segments*/
static pointer hidM2761edge_image_mark_visible_segments(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[0]->c.obj.iv[3];
	local[5]= argv[0]->c.obj.iv[0]->c.obj.iv[4];
	local[6]= NIL;
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
hidWHL2763:
	if (local[7]==NIL) goto hidWHX2764;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= argv[0];
	local[9]= fqv[12];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	{ double x,y;
		y=fltval((w)->c.cons.car); x=fltval(local[10]);
		local[10]=(makeflt(x + y));}
	local[11]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[3] = w;
	local[8]= argv[0]->c.obj.iv[0];
	local[9]= fqv[5];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	{ double x,y;
		y=fltval((w)->c.cons.car); x=fltval(local[10]);
		local[10]=(makeflt(x + y));}
	local[11]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[1] = w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	local[9]= local[4];
	local[10]= local[5];
	local[11]= local[1];
	local[12]= local[3];
	local[13]= argv[2];
	ctx->vsp=local+14;
	w=(pointer)hidF2715check_visibility(ctx,5,local+9); /*check-visibility*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)RPLACA2(ctx,2,local+8); /*rplaca2*/
	local[0] = local[6];
	goto hidWHL2763;
hidWHX2764:
	local[8]= NIL;
hidBLK2765:
	w = NIL;
	local[0]= w;
hidBLK2762:
	ctx->vsp=local; return(local[0]);}

/*:visible-face*/
static pointer hidM2766edge_image_visible_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0]->c.obj.iv[3];
	local[1]= argv[0]->c.obj.iv[0]->c.obj.iv[4];
	local[2]= local[0];
	w = loadglobal(fqv[13]);
	if (memq(local[2],w)==NIL) goto hidIF2768;
	local[2]= local[0];
	goto hidIF2769;
hidIF2768:
	local[2]= local[1];
hidIF2769:
	w = local[2];
	local[0]= w;
hidBLK2767:
	ctx->vsp=local; return(local[0]);}

/*:collect-segments*/
static pointer hidM2770edge_image_collect_segments(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.cdr;
hidWHL2772:
	if (local[6]==NIL) goto hidWHX2773;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	if (argv[2]!=local[7]) goto hidIF2775;
	local[7]= argv[0];
	local[8]= fqv[14];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[2] = w;
	local[7]= argv[0];
	local[8]= fqv[14];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[3] = w;
	local[7]= local[2];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)HOMO_VPCLIP(ctx,2,local+7); /*homo-viewport-clip*/
	local[4] = w;
	if (local[4]==NIL) goto hidIF2777;
	local[7]= local[4];
	w = local[0];
	ctx->vsp=local+8;
	local[0] = cons(ctx,local[7],w);
	local[7]= local[0];
	goto hidIF2778;
hidIF2777:
	local[7]= NIL;
hidIF2778:
	goto hidIF2776;
hidIF2775:
	local[7]= NIL;
hidIF2776:
	local[1] = local[5];
	goto hidWHL2772;
hidWHX2773:
	local[7]= NIL;
hidBLK2774:
	w = NIL;
	w = local[0];
	local[0]= w;
hidBLK2771:
	ctx->vsp=local; return(local[0]);}

/*:visible-segments*/
static pointer hidM2779edge_image_visible_segments(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= T;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
hidBLK2780:
	ctx->vsp=local; return(local[0]);}

/*:invisible-segments*/
static pointer hidM2781edge_image_invisible_segments(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= NIL;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
hidBLK2782:
	ctx->vsp=local; return(local[0]);}

/*:project*/
static pointer hidM2783edge_image_project(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto hidENT2786;}
	local[0]= argv[3];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
hidENT2786:
hidENT2785:
	if (n>5) maerror();
	argv[0]->c.obj.iv[0] = argv[2];
	local[1]= argv[3];
	local[2]= fqv[17];
	local[3]= argv[2]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	argv[0]->c.obj.iv[1] = w;
	local[1]= argv[3];
	local[2]= fqv[17];
	local[3]= argv[2]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	argv[0]->c.obj.iv[2] = w;
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)HOMO2NORMAL(ctx,1,local+1); /*homo2normal*/
	argv[0]->c.obj.iv[3] = w;
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)HOMO2NORMAL(ctx,1,local+1); /*homo2normal*/
	argv[0]->c.obj.iv[4] = w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	local[2]= makeflt(0.0000000000000000000000e+00);
	local[3]= T;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[1]= w;
	local[2]= makeflt(1.0000000000000000000000e+00);
	local[3]= makeflt(1.0000000000000000000000e+00);
	local[4]= T;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,3,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	argv[0]->c.obj.iv[5] = w;
	local[1]= argv[2];
	local[2]= fqv[18];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	argv[0]->c.obj.iv[6] = w;
	w = argv[0];
	local[0]= w;
hidBLK2784:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer hidM2787edge_image_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[19], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto hidKEY2789;
	local[0] = NIL;
hidKEY2789:
	if (n & (1<<1)) goto hidKEY2790;
	local[1] = NIL;
hidKEY2790:
	if (n & (1<<2)) goto hidKEY2791;
	local[2] = NIL;
hidKEY2791:
	if (n & (1<<3)) goto hidKEY2792;
	local[3] = NIL;
hidKEY2792:
	if (n & (1<<4)) goto hidKEY2793;
	local[4] = NIL;
hidKEY2793:
	if (local[0]==NIL) goto hidIF2794;
	argv[0]->c.obj.iv[0] = local[0];
	local[5]= argv[0]->c.obj.iv[0];
	goto hidIF2795;
hidIF2794:
	local[5]= NIL;
hidIF2795:
	if (local[1]==NIL) goto hidIF2796;
	argv[0]->c.obj.iv[1] = local[1];
	local[5]= argv[0]->c.obj.iv[1];
	goto hidIF2797;
hidIF2796:
	local[5]= NIL;
hidIF2797:
	if (local[2]==NIL) goto hidIF2798;
	argv[0]->c.obj.iv[2] = local[2];
	local[5]= argv[0]->c.obj.iv[2];
	goto hidIF2799;
hidIF2798:
	local[5]= NIL;
hidIF2799:
	if (local[3]==NIL) goto hidIF2800;
	argv[0]->c.obj.iv[3] = local[3];
	local[5]= argv[0]->c.obj.iv[3];
	goto hidIF2801;
hidIF2800:
	local[5]= NIL;
hidIF2801:
	if (local[4]==NIL) goto hidIF2802;
	argv[0]->c.obj.iv[4] = local[4];
	local[5]= argv[0]->c.obj.iv[4];
	goto hidIF2803;
hidIF2802:
	local[5]= NIL;
hidIF2803:
	w = argv[0];
	local[0]= w;
hidBLK2788:
	ctx->vsp=local; return(local[0]);}

/*:face3d*/
static pointer hidM2804face_image_face3d(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
hidBLK2805:
	ctx->vsp=local; return(local[0]);}

/*:possibly-hiding*/
static pointer hidM2806face_image_possibly_hiding(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[20];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
hidBLK2807:
	ctx->vsp=local; return(local[0]);}

/*:boxtest*/
static pointer hidM2808face_image_boxtest(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[21];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
hidBLK2809:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer hidM2810face_image_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[3];
hidWHL2812:
	if (local[2]==NIL) goto hidWHX2813;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	if (local[1]==NIL) goto hidIF2815;
	local[3]= local[1];
	local[4]= fqv[22];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[0];
	goto hidIF2816;
hidIF2815:
	local[3]= NIL;
hidIF2816:
	goto hidWHL2812;
hidWHX2813:
	local[3]= NIL;
hidBLK2814:
	w = NIL;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,1,local+1,&ftab[0],fqv[23]); /*flatten*/
	local[0] = w;
	argv[0]->c.obj.iv[2] = argv[2];
	argv[0]->c.obj.iv[1] = argv[3];
	local[1]= loadglobal(fqv[10]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[24];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	w = local[1];
	argv[0]->c.obj.iv[0] = w;
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[25];
	local[3]= makeflt(9.9999999999999950039964e-03);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[0]->c.obj.iv[1];
	local[2]= makeint((eusinteger_t)2L);
	local[3]= makeflt(1.0000000000000000000000e+20);
	ctx->vsp=local+4;
	w=(pointer)ASET(ctx,3,local+1); /*aset*/
	w = argv[0];
	local[0]= w;
hidBLK2811:
	ctx->vsp=local; return(local[0]);}

/*make-face-image*/
static pointer hidF2716make_face_image(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[26]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[24];
	local[3]= argv[0];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,hidCLO2818,env,argv,local);
	local[5]= argv[0];
	local[6]= fqv[27];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	w = local[0];
	local[0]= w;
hidBLK2817:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer hidCLO2818(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env1[1];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[28]); /*gethash*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*set-contour-intersections*/
static pointer hidF2717set_contour_intersections(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
hidWHL2820:
	if (argv[0]==NIL) goto hidWHX2821;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[0];
	local[0]= w;
	local[1]= local[0]->c.obj.iv[0];
	local[2]= local[1]->c.obj.iv[3];
	local[3]= local[1]->c.obj.iv[4];
	if (local[2]==NIL) goto hidIF2823;
	local[4]= local[2]->c.obj.iv[4];
	goto hidIF2824;
hidIF2823:
	local[4]= NIL;
hidIF2824:
	if (local[3]==NIL) goto hidIF2825;
	local[5]= local[3]->c.obj.iv[4];
	goto hidIF2826;
hidIF2825:
	local[5]= NIL;
hidIF2826:
	local[6]= NIL;
	local[7]= argv[0];
hidWHL2827:
	if (local[7]==NIL) goto hidWHX2828;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[6]->c.obj.iv[0];
	w = local[4];
	if (memq(local[8],w)!=NIL) goto hidIF2830;
	local[8]= local[6]->c.obj.iv[0];
	w = local[5];
	if (memq(local[8],w)!=NIL) goto hidIF2830;
	local[8]= local[0];
	local[9]= fqv[29];
	local[10]= local[6];
	local[11]= T;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= w;
	goto hidIF2831;
hidIF2830:
	local[8]= NIL;
hidIF2831:
	goto hidWHL2827;
hidWHX2828:
	local[8]= NIL;
hidBLK2829:
	w = NIL;
	goto hidWHL2820;
hidWHX2821:
	local[0]= NIL;
hidBLK2822:
	w = local[0];
	local[0]= w;
hidBLK2819:
	ctx->vsp=local; return(local[0]);}

/*set-non-contour-intersections*/
static pointer hidF2718set_non_contour_intersections(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0];
hidWHL2833:
	if (local[1]==NIL) goto hidWHX2834;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0]->c.obj.iv[0];
	local[3]= local[2]->c.obj.iv[3];
	local[4]= local[2]->c.obj.iv[4];
	if (local[3]==NIL) goto hidIF2836;
	local[5]= local[3]->c.obj.iv[4];
	goto hidIF2837;
hidIF2836:
	local[5]= NIL;
hidIF2837:
	if (local[4]==NIL) goto hidIF2838;
	local[6]= local[4]->c.obj.iv[4];
	goto hidIF2839;
hidIF2838:
	local[6]= NIL;
hidIF2839:
	local[7]= NIL;
	local[8]= argv[1];
hidWHL2840:
	if (local[8]==NIL) goto hidWHX2841;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= local[7]->c.obj.iv[0];
	w = local[5];
	if (memq(local[9],w)!=NIL) goto hidIF2843;
	local[9]= local[7]->c.obj.iv[0];
	w = local[6];
	if (memq(local[9],w)!=NIL) goto hidIF2843;
	local[9]= local[0];
	local[10]= fqv[29];
	local[11]= local[7];
	local[12]= NIL;
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= w;
	goto hidIF2844;
hidIF2843:
	local[9]= NIL;
hidIF2844:
	goto hidWHL2840;
hidWHX2841:
	local[9]= NIL;
hidBLK2842:
	w = NIL;
	goto hidWHL2833;
hidWHX2834:
	local[2]= NIL;
hidBLK2835:
	w = NIL;
	local[0]= w;
hidBLK2832:
	ctx->vsp=local; return(local[0]);}

/*curved-edge-image-p*/
static pointer hidF2719curved_edge_image_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[30]);
	if (local[0]==NIL) goto hidAND2846;
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[31];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
hidAND2846:
	w = local[0];
	local[0]= w;
hidBLK2845:
	ctx->vsp=local; return(local[0]);}

/*hid2*/
static pointer hidF2720hid2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto hidENT2849;}
	local[0]= NIL;
hidENT2849:
hidENT2848:
	if (n>3) maerror();
	local[1]= fqv[32];
	local[2]= makeint((eusinteger_t)100L);
	local[3]= fqv[33];
	local[4]= (pointer)get_sym_func(fqv[34]);
	local[5]= fqv[35];
	local[6]= (pointer)get_sym_func(fqv[36]);
	ctx->vsp=local+7;
	w=(*ftab[2])(ctx,6,local+1,&ftab[2],fqv[37]); /*make-hash-table*/
	local[1]= w;
	local[2]= argv[1];
	local[3]= fqv[16];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)RUNTIME(ctx,0,local+3); /*unix:runtime*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	storeglobal(fqv[13],NIL);
	storeglobal(fqv[1],NIL);
	storeglobal(fqv[38],NIL);
	storeglobal(fqv[39],NIL);
	storeglobal(fqv[40],NIL);
	storeglobal(fqv[41],NIL);
	storeglobal(fqv[42],NIL);
	local[8]= NIL;
	storeglobal(fqv[43],local[8]);
	local[8]= NIL;
	local[9]= argv[0];
hidWHL2850:
	if (local[9]==NIL) goto hidWHX2851;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= local[8];
	local[13]= loadglobal(fqv[44]);
	ctx->vsp=local+14;
	w=(pointer)DERIVEDP(ctx,2,local+12); /*derivedp*/
	if (w==NIL) goto hidIF2853;
	local[12]= local[8];
	local[13]= fqv[45];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	goto hidIF2854;
hidIF2853:
	local[12]= NIL;
hidIF2854:
	local[12]= NIL;
	local[13]= local[8];
	local[14]= loadglobal(fqv[44]);
	ctx->vsp=local+15;
	w=(pointer)DERIVEDP(ctx,2,local+13); /*derivedp*/
	if (w==NIL) goto hidIF2855;
	local[13]= local[8];
	local[14]= fqv[46];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	goto hidIF2856;
hidIF2855:
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	local[13]= w;
hidIF2856:
hidWHL2857:
	if (local[13]==NIL) goto hidWHX2858;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13] = (w)->c.cons.cdr;
	w = local[14];
	local[12] = w;
	local[14]= local[12];
	local[15]= fqv[47];
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= w;
	local[15]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+16;
	w=(pointer)GREATERP(ctx,2,local+14); /*>*/
	if (w==NIL) goto hidIF2860;
	local[14]= local[12];
	w = local[10];
	ctx->vsp=local+15;
	local[10] = cons(ctx,local[14],w);
	local[14]= local[10];
	goto hidIF2861;
hidIF2860:
	local[14]= NIL;
hidIF2861:
	goto hidWHL2857;
hidWHX2858:
	local[14]= NIL;
hidBLK2859:
	w = NIL;
	local[12]= (pointer)get_sym_func(fqv[48]);
	local[13]= local[10];
	local[14]= fqv[49];
	ctx->vsp=local+15;
	w=(*ftab[3])(ctx,2,local+13,&ftab[3],fqv[50]); /*send-all*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)APPLY(ctx,2,local+12); /*apply*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[4])(ctx,1,local+12,&ftab[4],fqv[51]); /*remove-duplicates*/
	local[11] = w;
	local[12]= loadglobal(fqv[39]);
	local[13]= local[8];
	local[14]= fqv[49];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(*ftab[5])(ctx,2,local+13,&ftab[5],fqv[52]); /*set-difference*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)NCONC(ctx,2,local+12); /*nconc*/
	storeglobal(fqv[39],w);
	local[12]= local[11];
	local[13]= loadglobal(fqv[38]);
	ctx->vsp=local+14;
	w=(pointer)NCONC(ctx,2,local+12); /*nconc*/
	storeglobal(fqv[38],w);
	local[12]= local[10];
	local[13]= loadglobal(fqv[13]);
	ctx->vsp=local+14;
	w=(pointer)NCONC(ctx,2,local+12); /*nconc*/
	local[12]= w;
	storeglobal(fqv[13],w);
	w = local[12];
	goto hidWHL2850;
hidWHX2851:
	local[10]= NIL;
hidBLK2852:
	w = NIL;
	local[8]= NIL;
	local[9]= loadglobal(fqv[38]);
hidWHL2862:
	if (local[9]==NIL) goto hidWHX2863;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= loadglobal(fqv[53]);
	ctx->vsp=local+11;
	w=(pointer)INSTANTIATE(ctx,1,local+10); /*instantiate*/
	local[10]= w;
	local[11]= local[10];
	local[12]= fqv[54];
	local[13]= local[8];
	local[14]= argv[1];
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,5,local+11); /*send*/
	w = local[10];
	local[10]= w;
	local[11]= local[10];
	local[12]= fqv[18];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	if (w==NIL) goto hidIF2865;
	local[11]= local[10];
	w = loadglobal(fqv[41]);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	storeglobal(fqv[41],local[11]);
	goto hidIF2866;
hidIF2865:
	local[11]= local[10];
	ctx->vsp=local+12;
	w=(pointer)hidF2719curved_edge_image_p(ctx,1,local+11); /*curved-edge-image-p*/
	if (w!=NIL) goto hidIF2867;
	local[11]= local[10];
	w = loadglobal(fqv[42]);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	storeglobal(fqv[42],local[11]);
	goto hidIF2868;
hidIF2867:
	local[11]= NIL;
hidIF2868:
hidIF2866:
	local[11]= local[8];
	local[12]= local[1];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(*ftab[6])(ctx,3,local+11,&ftab[6],fqv[55]); /*sethash*/
	goto hidWHL2862;
hidWHX2863:
	local[10]= NIL;
hidBLK2864:
	w = NIL;
	ctx->vsp=local+8;
	w=(pointer)RUNTIME(ctx,0,local+8); /*unix:runtime*/
	local[5] = w;
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,hidCLO2869,env,argv,local);
	local[9]= loadglobal(fqv[13]);
	ctx->vsp=local+10;
	w=(pointer)MAPCAR(ctx,2,local+8); /*mapcar*/
	local[8]= w;
	storeglobal(fqv[1],w);
	local[8]= loadglobal(fqv[41]);
	ctx->vsp=local+9;
	w=(pointer)hidF2717set_contour_intersections(ctx,1,local+8); /*set-contour-intersections*/
	local[8]= loadglobal(fqv[42]);
	local[9]= loadglobal(fqv[41]);
	ctx->vsp=local+10;
	w=(pointer)hidF2718set_non_contour_intersections(ctx,2,local+8); /*set-non-contour-intersections*/
	local[8]= loadglobal(fqv[53]);
	ctx->vsp=local+9;
	w=(pointer)INSTANTIATE(ctx,1,local+8); /*instantiate*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[24];
	local[11]= fqv[56];
	local[12]= fqv[57];
	local[13]= fqv[58];
	local[14]= fqv[59];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,6,local+9); /*send*/
	w = local[8];
	local[8]= w;
	w = local[4];
	ctx->vsp=local+9;
	local[4] = cons(ctx,local[8],w);
	local[8]= loadglobal(fqv[53]);
	ctx->vsp=local+9;
	w=(pointer)INSTANTIATE(ctx,1,local+8); /*instantiate*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[24];
	local[11]= fqv[56];
	local[12]= fqv[60];
	local[13]= fqv[58];
	local[14]= fqv[61];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,6,local+9); /*send*/
	w = local[8];
	local[8]= w;
	w = local[4];
	ctx->vsp=local+9;
	local[4] = cons(ctx,local[8],w);
	local[8]= loadglobal(fqv[53]);
	ctx->vsp=local+9;
	w=(pointer)INSTANTIATE(ctx,1,local+8); /*instantiate*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[24];
	local[11]= fqv[56];
	local[12]= fqv[62];
	local[13]= fqv[58];
	local[14]= fqv[63];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,6,local+9); /*send*/
	w = local[8];
	local[8]= w;
	w = local[4];
	ctx->vsp=local+9;
	local[4] = cons(ctx,local[8],w);
	local[8]= loadglobal(fqv[53]);
	ctx->vsp=local+9;
	w=(pointer)INSTANTIATE(ctx,1,local+8); /*instantiate*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[24];
	local[11]= fqv[56];
	local[12]= fqv[64];
	local[13]= fqv[58];
	local[14]= fqv[65];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,6,local+9); /*send*/
	w = local[8];
	local[8]= w;
	w = local[4];
	ctx->vsp=local+9;
	local[4] = cons(ctx,local[8],w);
	local[8]= NIL;
	local[9]= local[4];
hidWHL2870:
	if (local[9]==NIL) goto hidWHX2871;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= NIL;
	local[11]= loadglobal(fqv[41]);
hidWHL2873:
	if (local[11]==NIL) goto hidWHX2874;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= local[10];
	local[13]= fqv[29];
	local[14]= local[8];
	local[15]= NIL;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,4,local+12); /*send*/
	goto hidWHL2873;
hidWHX2874:
	local[12]= NIL;
hidBLK2875:
	w = NIL;
	local[10]= NIL;
	local[11]= loadglobal(fqv[42]);
hidWHL2876:
	if (local[11]==NIL) goto hidWHX2877;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= local[10];
	local[13]= fqv[29];
	local[14]= local[8];
	local[15]= NIL;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,4,local+12); /*send*/
	goto hidWHL2876;
hidWHX2877:
	local[12]= NIL;
hidBLK2878:
	w = NIL;
	goto hidWHL2870;
hidWHX2871:
	local[10]= NIL;
hidBLK2872:
	w = NIL;
	ctx->vsp=local+8;
	w=(pointer)RUNTIME(ctx,0,local+8); /*unix:runtime*/
	local[6] = w;
	local[8]= loadglobal(fqv[41]);
	local[9]= loadglobal(fqv[42]);
	ctx->vsp=local+10;
	w=(pointer)APPEND(ctx,2,local+8); /*append*/
	local[8]= w;
	storeglobal(fqv[66],w);
	local[8]= loadglobal(fqv[66]);
	local[9]= fqv[67];
	ctx->vsp=local+10;
	w=(*ftab[3])(ctx,2,local+8,&ftab[3],fqv[50]); /*send-all*/
	local[8]= loadglobal(fqv[66]);
	local[9]= fqv[68];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,3,local+8,&ftab[3],fqv[50]); /*send-all*/
	ctx->vsp=local+8;
	w=(pointer)RUNTIME(ctx,0,local+8); /*unix:runtime*/
	local[7] = w;
	local[8]= local[5];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	local[9]= local[6];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	local[10]= local[7];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,2,local+10); /*-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,3,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)PRINT(ctx,1,local+8); /*print*/
	local[0]= w;
hidBLK2847:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer hidCLO2869(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[1];
	local[2]= env->c.clo.env2[2];
	ctx->vsp=local+3;
	w=(pointer)hidF2716make_face_image(ctx,3,local+0); /*make-face-image*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___hid(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[69];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto hidIF2879;
	local[0]= fqv[70];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[71],w);
	goto hidIF2880;
hidIF2879:
	local[0]= fqv[72];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
hidIF2880:
	local[0]= fqv[73];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[13];
	local[1]= fqv[74];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto hidIF2881;
	local[0]= fqv[13];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[13];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto hidIF2883;
	local[0]= fqv[13];
	local[1]= fqv[75];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto hidIF2884;
hidIF2883:
	local[0]= NIL;
hidIF2884:
	local[0]= fqv[13];
	goto hidIF2882;
hidIF2881:
	local[0]= NIL;
hidIF2882:
	local[0]= fqv[1];
	local[1]= fqv[74];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto hidIF2885;
	local[0]= fqv[1];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[1];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto hidIF2887;
	local[0]= fqv[1];
	local[1]= fqv[75];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto hidIF2888;
hidIF2887:
	local[0]= NIL;
hidIF2888:
	local[0]= fqv[1];
	goto hidIF2886;
hidIF2885:
	local[0]= NIL;
hidIF2886:
	local[0]= fqv[38];
	local[1]= fqv[74];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto hidIF2889;
	local[0]= fqv[38];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[38];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto hidIF2891;
	local[0]= fqv[38];
	local[1]= fqv[75];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto hidIF2892;
hidIF2891:
	local[0]= NIL;
hidIF2892:
	local[0]= fqv[38];
	goto hidIF2890;
hidIF2889:
	local[0]= NIL;
hidIF2890:
	local[0]= fqv[41];
	local[1]= fqv[74];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto hidIF2893;
	local[0]= fqv[41];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[41];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto hidIF2895;
	local[0]= fqv[41];
	local[1]= fqv[75];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto hidIF2896;
hidIF2895:
	local[0]= NIL;
hidIF2896:
	local[0]= fqv[41];
	goto hidIF2894;
hidIF2893:
	local[0]= NIL;
hidIF2894:
	local[0]= fqv[66];
	local[1]= fqv[74];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto hidIF2897;
	local[0]= fqv[66];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[66];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto hidIF2899;
	local[0]= fqv[66];
	local[1]= fqv[75];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto hidIF2900;
hidIF2899:
	local[0]= NIL;
hidIF2900:
	local[0]= fqv[66];
	goto hidIF2898;
hidIF2897:
	local[0]= NIL;
hidIF2898:
	local[0]= fqv[43];
	local[1]= fqv[74];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto hidIF2901;
	local[0]= fqv[43];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[43];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto hidIF2903;
	local[0]= fqv[43];
	local[1]= fqv[75];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto hidIF2904;
hidIF2903:
	local[0]= NIL;
hidIF2904:
	local[0]= fqv[43];
	goto hidIF2902;
hidIF2901:
	local[0]= NIL;
hidIF2902:
	local[0]= fqv[42];
	local[1]= fqv[74];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto hidIF2905;
	local[0]= fqv[42];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[42];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto hidIF2907;
	local[0]= fqv[42];
	local[1]= fqv[75];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto hidIF2908;
hidIF2907:
	local[0]= NIL;
hidIF2908:
	local[0]= fqv[42];
	goto hidIF2906;
hidIF2905:
	local[0]= NIL;
hidIF2906:
	local[0]= fqv[39];
	local[1]= fqv[74];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto hidIF2909;
	local[0]= fqv[39];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[39];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto hidIF2911;
	local[0]= fqv[39];
	local[1]= fqv[75];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto hidIF2912;
hidIF2911:
	local[0]= NIL;
hidIF2912:
	local[0]= fqv[39];
	goto hidIF2910;
hidIF2909:
	local[0]= NIL;
hidIF2910:
	local[0]= fqv[40];
	local[1]= fqv[74];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto hidIF2913;
	local[0]= fqv[40];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[40];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto hidIF2915;
	local[0]= fqv[40];
	local[1]= fqv[75];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto hidIF2916;
hidIF2915:
	local[0]= NIL;
hidIF2916:
	local[0]= fqv[40];
	goto hidIF2914;
hidIF2913:
	local[0]= NIL;
hidIF2914:
	local[0]= fqv[30];
	local[1]= fqv[76];
	local[2]= T;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[77],module,hidF2715check_visibility,fqv[78]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2727edge_image_edge3,fqv[79],fqv[53],fqv[80]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2729edge_image_vertices,fqv[22],fqv[53],fqv[81]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2731edge_image_color,fqv[4],fqv[53],fqv[82]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2733edge_image_homo2real,fqv[6],fqv[53],fqv[83]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2735edge_image_add_segment,fqv[7],fqv[53],fqv[84]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2741edge_image_projected_point,fqv[12],fqv[53],fqv[85]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2743edge_image_projected_homo_point,fqv[14],fqv[53],fqv[86]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2745edge_image_intersecting_point,fqv[87],fqv[53],fqv[88]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2749edge_image_projected_intersection,fqv[29],fqv[53],fqv[89]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2755edge_image_sort_segments,fqv[67],fqv[53],fqv[90]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2757edge_image_box,fqv[91],fqv[53],fqv[92]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2759edge_image_contourp,fqv[18],fqv[53],fqv[93]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2761edge_image_mark_visible_segments,fqv[68],fqv[53],fqv[94]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2766edge_image_visible_face,fqv[95],fqv[53],fqv[96]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2770edge_image_collect_segments,fqv[15],fqv[53],fqv[97]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2779edge_image_visible_segments,fqv[98],fqv[53],fqv[99]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2781edge_image_invisible_segments,fqv[100],fqv[53],fqv[101]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2783edge_image_project,fqv[54],fqv[53],fqv[102]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2787edge_image_init,fqv[24],fqv[53],fqv[103]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2804face_image_face3d,fqv[104],fqv[26],fqv[105]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2806face_image_possibly_hiding,fqv[2],fqv[26],fqv[106]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2808face_image_boxtest,fqv[107],fqv[26],fqv[108]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hidM2810face_image_init,fqv[24],fqv[26],fqv[109]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[110],module,hidF2716make_face_image,fqv[111]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[112],module,hidF2717set_contour_intersections,fqv[113]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[114],module,hidF2718set_non_contour_intersections,fqv[115]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[116],module,hidF2719curved_edge_image_p,fqv[117]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[118],module,hidF2720hid2,fqv[119]);
	local[0]= fqv[120];
	local[1]= fqv[121];
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,2,local+0,&ftab[7],fqv[122]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<8; i++) ftab[i]=fcallx;
}

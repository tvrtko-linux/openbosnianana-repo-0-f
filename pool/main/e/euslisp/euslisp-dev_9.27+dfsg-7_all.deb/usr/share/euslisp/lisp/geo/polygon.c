/* ./polygon.c :  entry=polygon */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "polygon.h"
#pragma init (register_polygon)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___polygon();
extern pointer build_quote_vector();
static int register_polygon()
  { add_module_initializer("___polygon", ___polygon);}

static pointer polygonF2584make_polygon2d();
static pointer polygonF2585make_rectangle();
static pointer polygonF2586make_circle();

/*:vertices*/
static pointer polygonM2587polygon2d_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
polygonBLK2588:
	ctx->vsp=local; return(local[0]);}

/*:lines*/
static pointer polygonM2589polygon2d_lines(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
polygonBLK2590:
	ctx->vsp=local; return(local[0]);}

/*:edges*/
static pointer polygonM2591polygon2d_edges(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[9];
polygonWHL2593:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto polygonWHX2594;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[2]= w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	w = local[0];
	ctx->vsp=local+3;
	local[0] = cons(ctx,local[2],w);
	goto polygonWHL2593;
polygonWHX2594:
	local[2]= NIL;
polygonBLK2595:
	w = local[0];
	local[0]= w;
polygonBLK2592:
	ctx->vsp=local; return(local[0]);}

/*:drawners*/
static pointer polygonM2596polygon2d_drawners(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[0];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
polygonBLK2597:
	ctx->vsp=local; return(local[0]);}

/*:box*/
static pointer polygonM2598polygon2d_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[12];
	local[0]= w;
polygonBLK2599:
	ctx->vsp=local; return(local[0]);}

/*:boxtest*/
static pointer polygonM2600polygon2d_boxtest(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= loadglobal(fqv[1]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w!=NIL) goto polygonIF2602;
	local[0]= argv[2];
	local[1]= fqv[2];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[2] = w;
	local[0]= argv[2];
	goto polygonIF2603;
polygonIF2602:
	local[0]= NIL;
polygonIF2603:
	local[0]= argv[0]->c.obj.iv[12];
	local[1]= fqv[3];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
polygonBLK2601:
	ctx->vsp=local; return(local[0]);}

/*:update*/
static pointer polygonM2604polygon2d_update(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= argv[0]->c.obj.iv[9];
	local[2]= argv[0]->c.obj.iv[5]->c.obj.iv[1];
	local[3]= argv[0]->c.obj.iv[5]->c.obj.iv[2];
polygonWHL2606:
	if (local[0]==NIL) goto polygonWHX2607;
	local[4]= local[2];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)TRANSFORM(ctx,3,local+4); /*transform*/
	local[4]= local[3];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)VPLUS(ctx,3,local+4); /*v+*/
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[4];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	goto polygonWHL2606;
polygonWHX2607:
	local[4]= NIL;
polygonBLK2608:
	local[4]= argv[0]->c.obj.iv[12];
	local[5]= fqv[4];
	local[6]= argv[0]->c.obj.iv[9];
	local[7]= loadglobal(fqv[5]);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = argv[0];
	local[0]= w;
polygonBLK2605:
	ctx->vsp=local; return(local[0]);}

/*:set-convexp*/
static pointer polygonM2609polygon2d_set_convexp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[9];
	w=argv[0]->c.obj.iv[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	local[1]= (pointer)get_sym_func(fqv[6]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[0] = w;
	argv[0]->c.obj.iv[11] = T;
polygonWHL2611:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto polygonWHX2612;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[1];
	local[1]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,3,local+1,&ftab[0],fqv[7]); /*triangle*/
	local[1]= w;
	local[2]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto polygonIF2614;
	argv[0]->c.obj.iv[11] = NIL;
	local[0] = NIL;
	local[1]= local[0];
	goto polygonIF2615;
polygonIF2614:
	local[1]= NIL;
polygonIF2615:
	goto polygonWHL2611;
polygonWHX2612:
	local[1]= NIL;
polygonBLK2613:
	w = local[1];
	w = argv[0]->c.obj.iv[11];
	local[0]= w;
polygonBLK2610:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer polygonM2616polygon2d_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[8]));
	local[2]= fqv[4];
	local[3]= fqv[9];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,5,local+0); /*send-message*/
	local[0]= argv[2];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	argv[0]->c.obj.iv[9] = w;
	local[0]= (pointer)get_sym_func(fqv[10]);
	local[1]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	argv[0]->c.obj.iv[8] = w;
	local[0]= argv[0]->c.obj.iv[9];
	local[1]= makeflt(9.9999999999999950039964e-03);
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[11]); /*make-bounding-box*/
	argv[0]->c.obj.iv[12] = w;
	local[0]= argv[0]->c.obj.iv[9];
	argv[0]->c.obj.iv[10] = NIL;
polygonWHL2618:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto polygonWHX2619;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[1];
	local[1]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[12]); /*make-line*/
	local[1]= w;
	w = argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[10] = cons(ctx,local[1],w);
	goto polygonWHL2618;
polygonWHX2619:
	local[1]= NIL;
polygonBLK2620:
	w = local[1];
	local[0]= argv[0];
	local[1]= fqv[13];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = argv[0];
	local[0]= w;
polygonBLK2617:
	ctx->vsp=local; return(local[0]);}

/*:intersect-line*/
static pointer polygonM2621polygon2d_intersect_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto polygonENT2624;}
	local[0]= NIL;
polygonENT2624:
polygonENT2623:
	if (n>4) maerror();
	if (local[0]!=NIL) goto polygonIF2625;
	local[0] = argv[2]->c.obj.iv[2];
	argv[2] = argv[2]->c.obj.iv[1];
	local[1]= argv[2];
	goto polygonIF2626;
polygonIF2625:
	local[1]= NIL;
polygonIF2626:
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[0]->c.obj.iv[10];
polygonWHL2627:
	if (local[6]==NIL) goto polygonWHX2628;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[5]->c.obj.iv[1];
	local[8]= local[5]->c.obj.iv[2];
	local[9]= argv[2];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)LINEINTERSECTION(ctx,4,local+7); /*line-intersection*/
	local[1] = w;
	if (local[1]==NIL) goto polygonIF2630;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
	local[7]= makeflt(0.0000000000000000000000e+00);
	local[8]= local[2];
	local[9]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+10;
	w=(pointer)LSEQP(ctx,3,local+7); /*<=*/
	if (w==NIL) goto polygonIF2632;
	local[7]= makeflt(0.0000000000000000000000e+00);
	local[8]= local[3];
	local[9]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+10;
	w=(pointer)LSEQP(ctx,3,local+7); /*<=*/
	if (w==NIL) goto polygonIF2632;
	local[7]= local[2];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	w = local[4];
	ctx->vsp=local+8;
	local[4] = cons(ctx,local[7],w);
	local[7]= local[4];
	goto polygonIF2633;
polygonIF2632:
	local[7]= NIL;
polygonIF2633:
	goto polygonIF2631;
polygonIF2630:
	local[7]= NIL;
polygonIF2631:
	goto polygonWHL2627;
polygonWHX2628:
	local[7]= NIL;
polygonBLK2629:
	w = NIL;
	w = local[4];
	local[0]= w;
polygonBLK2622:
	ctx->vsp=local; return(local[0]);}

/*:on-edge*/
static pointer polygonM2634polygon2d_on_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto polygonENT2637;}
	local[0]= loadglobal(fqv[5]);
polygonENT2637:
polygonENT2636:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[10];
polygonWHL2638:
	if (local[4]==NIL) goto polygonWHX2639;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3];
	local[6]= fqv[14];
	local[7]= argv[2];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	if (w==NIL) goto polygonIF2641;
	local[5]= local[3];
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	local[5]= local[2];
	goto polygonIF2642;
polygonIF2641:
	local[5]= NIL;
polygonIF2642:
	goto polygonWHL2638;
polygonWHX2639:
	local[5]= NIL;
polygonBLK2640:
	w = NIL;
	w = local[2];
	local[0]= w;
polygonBLK2635:
	ctx->vsp=local; return(local[0]);}

/*:insidep*/
static pointer polygonM2643polygon2d_insidep(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	if (w==NIL) goto polygonIF2645;
	local[0]= fqv[16];
	goto polygonIF2646;
polygonIF2645:
	local[0]= argv[0];
	local[1]= fqv[17];
	local[2]= argv[2];
	local[3]= makeflt(1.0000000000000000000000e+10);
	ctx->vsp=local+4;
	w=(pointer)RANDOM(ctx,1,local+3); /*random*/
	local[3]= w;
	local[4]= makeflt(1.0000000000000000000000e+10);
	ctx->vsp=local+5;
	w=(pointer)RANDOM(ctx,1,local+4); /*random*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,2,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[3])(ctx,1,local+0,&ftab[3],fqv[18]); /*evenp*/
	local[0]= ((w)==NIL?T:NIL);
polygonIF2646:
	w = local[0];
	local[0]= w;
polygonBLK2644:
	ctx->vsp=local; return(local[0]);}

/*:intersect-polygon2d*/
static pointer polygonM2647polygon2d_intersect_polygon2d(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	if (w==NIL) goto polygonIF2649;
	local[0]= argv[2];
	local[1]= fqv[20];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[0]->c.obj.iv[10];
polygonWHL2651:
	if (local[5]==NIL) goto polygonWHX2652;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[1] = local[4]->c.obj.iv[1];
	local[2] = local[4]->c.obj.iv[2];
	local[6]= NIL;
	local[7]= local[0];
polygonWHL2654:
	if (local[7]==NIL) goto polygonWHX2655;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[1];
	local[9]= local[2];
	local[10]= local[6]->c.obj.iv[1];
	local[11]= local[6]->c.obj.iv[2];
	ctx->vsp=local+12;
	w=(pointer)LINEINTERSECTION(ctx,4,local+8); /*line-intersection*/
	local[3] = w;
	if (local[3]==NIL) goto polygonIF2657;
	local[8]= makeflt(0.0000000000000000000000e+00);
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= makeflt(1.0000000000000000000000e+00);
	local[11]= makeflt(-1.0000000000000000208167e-03);
	ctx->vsp=local+12;
	w=(*ftab[4])(ctx,4,local+8,&ftab[4],fqv[21]); /*eps-in-range*/
	if (w==NIL) goto polygonCON2660;
	local[8]= makeflt(0.0000000000000000000000e+00);
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= makeflt(1.0000000000000000000000e+00);
	local[11]= makeflt(-1.0000000000000000208167e-03);
	ctx->vsp=local+12;
	w=(*ftab[4])(ctx,4,local+8,&ftab[4],fqv[21]); /*eps-in-range*/
	if (w==NIL) goto polygonCON2660;
	w = T;
	ctx->vsp=local+8;
	local[0]=w;
	goto polygonBLK2648;
	goto polygonCON2659;
polygonCON2660:
	local[8]= NIL;
polygonCON2659:
	goto polygonIF2658;
polygonIF2657:
	local[8]= NIL;
polygonIF2658:
	goto polygonWHL2654;
polygonWHX2655:
	local[8]= NIL;
polygonBLK2656:
	w = NIL;
	goto polygonWHL2651;
polygonWHX2652:
	local[6]= NIL;
polygonBLK2653:
	w = NIL;
	local[4]= NIL;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= NIL;
	w=argv[0]->c.obj.iv[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.cdr;
polygonWHL2661:
	if (local[9]==NIL) goto polygonWHX2662;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= argv[2];
	local[11]= fqv[22];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[4] = w;
	local[10]= local[4];
	if (T!=local[10]) goto polygonCON2665;
	w = T;
	ctx->vsp=local+10;
	local[0]=w;
	goto polygonBLK2648;
	goto polygonCON2664;
polygonCON2665:
	local[10]= local[4];
	if (NIL!=local[10]) goto polygonCON2666;
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[6] = w;
	local[10]= local[6];
	goto polygonCON2664;
polygonCON2666:
	local[10]= local[4];
	if (fqv[16]!=local[10]) goto polygonCON2667;
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[7] = w;
	local[10]= local[7];
	goto polygonCON2664;
polygonCON2667:
	local[10]= NIL;
polygonCON2664:
	goto polygonWHL2661;
polygonWHX2662:
	local[10]= NIL;
polygonBLK2663:
	w = NIL;
	local[8]= NIL;
	local[9]= argv[2];
	local[10]= fqv[23];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.cdr;
polygonWHL2668:
	if (local[9]==NIL) goto polygonWHX2669;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= argv[0];
	local[11]= fqv[22];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[4] = w;
	local[10]= local[4];
	if (T!=local[10]) goto polygonCON2672;
	w = T;
	ctx->vsp=local+10;
	local[0]=w;
	goto polygonBLK2648;
	goto polygonCON2671;
polygonCON2672:
	local[10]= local[4];
	if (NIL!=local[10]) goto polygonCON2673;
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[6] = w;
	local[10]= local[6];
	goto polygonCON2671;
polygonCON2673:
	local[10]= local[4];
	if (fqv[16]!=local[10]) goto polygonCON2674;
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[7] = w;
	local[10]= local[7];
	goto polygonCON2671;
polygonCON2674:
	local[10]= NIL;
polygonCON2671:
	goto polygonWHL2668;
polygonWHX2669:
	local[10]= NIL;
polygonBLK2670:
	w = NIL;
	local[8]= local[7];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)GREATERP(ctx,2,local+8); /*>*/
	if (w==NIL) goto polygonIF2675;
	local[8]= fqv[16];
	goto polygonIF2676;
polygonIF2675:
	local[8]= NIL;
polygonIF2676:
	w = local[8];
	local[0]= w;
	goto polygonIF2650;
polygonIF2649:
	local[0]= NIL;
polygonIF2650:
	w = local[0];
	local[0]= w;
polygonBLK2648:
	ctx->vsp=local; return(local[0]);}

/*:distance-point*/
static pointer polygonM2677polygon2d_distance_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= (pointer)get_sym_func(fqv[24]);
	local[1]= argv[0]->c.obj.iv[10];
	local[2]= fqv[25];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(*ftab[5])(ctx,3,local+1,&ftab[5],fqv[26]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPLY(ctx,2,local+0); /*apply*/
	local[0]= w;
polygonBLK2678:
	ctx->vsp=local; return(local[0]);}

/*:distance*/
static pointer polygonM2679polygon2d_distance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[27];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	local[2]= loadglobal(fqv[5]);
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto polygonCON2682;
	local[1]= fqv[16];
	goto polygonCON2681;
polygonCON2682:
	local[1]= argv[0];
	local[2]= fqv[22];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	if (w==NIL) goto polygonCON2683;
	local[1]= fqv[28];
	goto polygonCON2681;
polygonCON2683:
	local[1]= local[0];
	goto polygonCON2681;
polygonCON2684:
	local[1]= NIL;
polygonCON2681:
	w = local[1];
	local[0]= w;
polygonBLK2680:
	ctx->vsp=local; return(local[0]);}

/*:3d*/
static pointer polygonM2685polygon2d_3d(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto polygonENT2689;}
	local[0]= makeflt(0.0000000000000000000000e+00);
polygonENT2689:
	if (n>=4) { local[1]=(argv[3]); goto polygonENT2688;}
	local[1]= loadglobal(fqv[29]);
polygonENT2688:
polygonENT2687:
	if (n>4) maerror();
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[4];
	local[5]= fqv[23];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,polygonCLO2690,env,argv,local);
	local[7]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+8;
	w=(pointer)BUTLAST(ctx,1,local+7); /*butlast*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	w = local[2];
	local[0]= w;
polygonBLK2686:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer polygonCLO2690(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)AREF(ctx,2,local+0); /*aref*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[1]= w;
	local[2]= env->c.clo.env2[0];
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:radius*/
static pointer polygonM2691circle2d_radius(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
polygonBLK2692:
	ctx->vsp=local; return(local[0]);}

/*:draw*/
static pointer polygonM2693circle2d_draw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[30];
	local[2]= argv[0];
	local[3]= fqv[31];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
polygonBLK2694:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer polygonM2695circle2d_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
polygonRST2697:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)EUSFLOAT(ctx,1,local+1); /*float*/
	argv[0]->c.obj.iv[8] = w;
	local[1]= (pointer)get_sym_func(fqv[32]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[8]));
	local[4]= fqv[4];
	local[5]= fqv[9];
	local[6]= makeint((eusinteger_t)2L);
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,7,local+1); /*apply*/
	w = argv[0];
	local[0]= w;
polygonBLK2696:
	ctx->vsp=local; return(local[0]);}

/*make-polygon2d*/
static pointer polygonF2584make_polygon2d(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
polygonRST2699:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= loadglobal(fqv[33]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[4];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	w = local[1];
	local[0]= w;
polygonBLK2698:
	ctx->vsp=local; return(local[0]);}

/*make-rectangle*/
static pointer polygonF2585make_rectangle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	local[2]= loadglobal(fqv[33]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[4];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,1,local+5); /*-*/
	local[5]= w;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,2,local+5); /*float-vector*/
	local[5]= w;
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,2,local+6); /*float-vector*/
	local[6]= w;
	local[7]= local[0];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,2,local+7); /*float-vector*/
	local[7]= w;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,2,local+8); /*float-vector*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,4,local+5); /*list*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	w = local[2];
	local[0]= w;
polygonBLK2700:
	ctx->vsp=local; return(local[0]);}

/*make-circle*/
static pointer polygonF2586make_circle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
polygonRST2702:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= (pointer)get_sym_func(fqv[34]);
	local[2]= loadglobal(fqv[35]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= fqv[4];
	local[4]= argv[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	local[0]= w;
polygonBLK2701:
	ctx->vsp=local; return(local[0]);}

/*:draw*/
static pointer polygonM2703polygon2d_draw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto polygonENT2706;}
	local[0]= NIL;
polygonENT2706:
polygonENT2705:
	if (n>4) maerror();
	if (local[0]==NIL) goto polygonIF2707;
	local[1]= argv[2];
	local[2]= fqv[36];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto polygonIF2708;
polygonIF2707:
	local[1]= NIL;
polygonIF2708:
	local[1]= argv[2];
	local[2]= fqv[37];
	w=argv[0]->c.obj.iv[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
polygonBLK2704:
	ctx->vsp=local; return(local[0]);}

/*:draw-fill*/
static pointer polygonM2709polygon2d_draw_fill(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto polygonENT2712;}
	local[0]= NIL;
polygonENT2712:
polygonENT2711:
	if (n>4) maerror();
	if (local[0]==NIL) goto polygonIF2713;
	local[1]= argv[2];
	local[2]= fqv[36];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto polygonIF2714;
polygonIF2713:
	local[1]= NIL;
polygonIF2714:
	local[1]= argv[2];
	local[2]= fqv[38];
	w=argv[0]->c.obj.iv[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
polygonBLK2710:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___polygon(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[39];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[33];
	local[1]= fqv[40];
	local[2]= fqv[33];
	local[3]= fqv[41];
	local[4]= loadglobal(fqv[42]);
	local[5]= fqv[43];
	local[6]= fqv[44];
	local[7]= fqv[45];
	local[8]= NIL;
	local[9]= fqv[46];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[48];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[6])(ctx,13,local+2,&ftab[6],fqv[49]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2587polygon2d_vertices,fqv[23],fqv[33],fqv[50]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2589polygon2d_lines,fqv[20],fqv[33],fqv[51]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2591polygon2d_edges,fqv[0],fqv[33],fqv[52]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2596polygon2d_drawners,fqv[53],fqv[33],fqv[54]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2598polygon2d_box,fqv[2],fqv[33],fqv[55]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2600polygon2d_boxtest,fqv[19],fqv[33],fqv[56]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2604polygon2d_update,fqv[57],fqv[33],fqv[58]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2609polygon2d_set_convexp,fqv[13],fqv[33],fqv[59]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2616polygon2d_init,fqv[4],fqv[33],fqv[60]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2621polygon2d_intersect_line,fqv[17],fqv[33],fqv[61]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2634polygon2d_on_edge,fqv[15],fqv[33],fqv[62]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2643polygon2d_insidep,fqv[22],fqv[33],fqv[63]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2647polygon2d_intersect_polygon2d,fqv[64],fqv[33],fqv[65]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2677polygon2d_distance_point,fqv[27],fqv[33],fqv[66]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2679polygon2d_distance,fqv[25],fqv[33],fqv[67]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2685polygon2d_3d,fqv[68],fqv[33],fqv[69]);
	local[0]= fqv[35];
	local[1]= fqv[40];
	local[2]= fqv[35];
	local[3]= fqv[41];
	local[4]= loadglobal(fqv[42]);
	local[5]= fqv[43];
	local[6]= fqv[70];
	local[7]= fqv[45];
	local[8]= NIL;
	local[9]= fqv[46];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[48];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[6])(ctx,13,local+2,&ftab[6],fqv[49]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2691circle2d_radius,fqv[71],fqv[35],fqv[72]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2693circle2d_draw,fqv[73],fqv[35],fqv[74]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2695circle2d_init,fqv[4],fqv[35],fqv[75]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[76],module,polygonF2584make_polygon2d,fqv[77]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[78],module,polygonF2585make_rectangle,fqv[79]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[80],module,polygonF2586make_circle,fqv[81]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2703polygon2d_draw,fqv[73],fqv[33],fqv[82]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,polygonM2709polygon2d_draw_fill,fqv[83],fqv[33],fqv[84]);
	local[0]= fqv[85];
	local[1]= fqv[86];
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,2,local+0,&ftab[7],fqv[87]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<8; i++) ftab[i]=fcallx;
}

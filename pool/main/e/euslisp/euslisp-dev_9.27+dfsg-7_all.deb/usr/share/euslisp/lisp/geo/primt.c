/* ./primt.c :  entry=primt */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "primt.h"
#pragma init (register_primt)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___primt();
extern pointer build_quote_vector();
static int register_primt()
  { add_module_initializer("___primt", ___primt);}

static pointer primtF1752find_extream();
static pointer primtF1753leftmost_point();
static pointer primtF1754rightmost_point();
static pointer primtF1755left_points();
static pointer primtF1756right_points();
static pointer primtF1757quickhull_left();
static pointer primtF1758quickhull_right();
static pointer primtF1759quickhull();
static pointer primtF1760find_coplanar_vertices();
static pointer primtF1761colinear_p();
static pointer primtF1762find_colinear_points();
static pointer primtF1763remove_colinears_from_circuit();
static pointer primtF1764coplanar_p();
static pointer primtF1765gift_wrapping();
static pointer primtF1766make_face_from_vertices();
static pointer primtF1767make_face_from_coplanar_vertices();
static pointer primtF1768tangent_foot();
static pointer primtF1769calc_p2_of_lowest_hull();
static pointer primtF1770calc_p3_of_lowest_hull();
static pointer primtF1771find_initial_hull();
static pointer primtF1772enclosed_vertexp();
static pointer primtF1773convex_hull_3d();
static pointer primtF1774rotate_vertices();
static pointer primtF1775make_side_faces();
static pointer primtF1776make_prism();
static pointer primtF1777make_conic_side_faces();
static pointer primtF1778make_cone();
static pointer primtF1779make_solid_of_revolution();
static pointer primtF1780make_torus();
static pointer primtF1781make_cylinder();
static pointer primtF1782make_cube();
static pointer primtF1783icosahedron_points();
static pointer primtF1784make_icosahedron();
static pointer primtF1785subdivide_facet();
static pointer primtF1786make_dodecahedron();
static pointer primtF1787make_gdome();
static pointer primtF1788make_body_from_vertices();
static pointer primtF1789assoc_coordinates_axes();

/*find-extream*/
static pointer primtF1752find_extream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[0];
	local[0]= w;
	local[1]= argv[1];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)FUNCALL(ctx,2,local+1); /*funcall*/
	local[1]= w;
	local[2]= NIL;
	local[3]= argv[0];
primtWHL1791:
	if (local[3]==NIL) goto primtWHX1792;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= argv[2];
	local[5]= argv[1];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)FUNCALL(ctx,2,local+5); /*funcall*/
	local[5]= w;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)FUNCALL(ctx,3,local+4); /*funcall*/
	if (w==NIL) goto primtIF1794;
	local[0] = local[2];
	local[4]= argv[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)FUNCALL(ctx,2,local+4); /*funcall*/
	local[1] = w;
	local[4]= local[1];
	goto primtIF1795;
primtIF1794:
	local[4]= NIL;
primtIF1795:
	goto primtWHL1791;
primtWHX1792:
	local[4]= NIL;
primtBLK1793:
	w = NIL;
	w = local[0];
	local[0]= w;
primtBLK1790:
	ctx->vsp=local; return(local[0]);}

/*leftmost-point*/
static pointer primtF1753leftmost_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,primtCLO1797,env,argv,local);
	local[2]= (pointer)get_sym_func(fqv[0]);
	ctx->vsp=local+3;
	w=(pointer)primtF1752find_extream(ctx,3,local+0); /*find-extream*/
	local[0]= w;
primtBLK1796:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer primtCLO1797(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env1[1];
	local[2]= env->c.clo.env1[2];
	local[3]= env->c.clo.env1[3];
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,4,local+0,&ftab[0],fqv[1]); /*triangle*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*rightmost-point*/
static pointer primtF1754rightmost_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,primtCLO1799,env,argv,local);
	local[2]= (pointer)get_sym_func(fqv[2]);
	ctx->vsp=local+3;
	w=(pointer)primtF1752find_extream(ctx,3,local+0); /*find-extream*/
	local[0]= w;
primtBLK1798:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer primtCLO1799(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env1[1];
	local[2]= env->c.clo.env1[2];
	local[3]= env->c.clo.env1[3];
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,4,local+0,&ftab[0],fqv[1]); /*triangle*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*left-points*/
static pointer primtF1755left_points(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,primtCLO1801,env,argv,local);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
primtBLK1800:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer primtCLO1801(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[1];
	local[1]= argv[0];
	local[2]= env->c.clo.env1[2];
	local[3]= env->c.clo.env1[3];
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,4,local+0,&ftab[0],fqv[1]); /*triangle*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto primtIF1802;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto primtIF1803;
primtIF1802:
	local[0]= NIL;
primtIF1803:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*right-points*/
static pointer primtF1756right_points(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,primtCLO1805,env,argv,local);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
primtBLK1804:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer primtCLO1805(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[1];
	local[1]= argv[0];
	local[2]= env->c.clo.env1[2];
	local[3]= env->c.clo.env1[3];
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,4,local+0,&ftab[0],fqv[1]); /*triangle*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto primtIF1806;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto primtIF1807;
primtIF1806:
	local[0]= NIL;
primtIF1807:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*quickhull-left*/
static pointer primtF1757quickhull_left(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	if (argv[0]!=NIL) goto primtCON1810;
	local[0]= argv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	ctx->vsp=local+0;
	local[0]=w;
	goto primtBLK1808;
	goto primtCON1809;
primtCON1810:
	local[0]= NIL;
primtCON1809:
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)primtF1753leftmost_point(ctx,4,local+0); /*leftmost-point*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= argv[1];
	local[3]= local[0];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)primtF1755left_points(ctx,4,local+1); /*left-points*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= local[0];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)primtF1755left_points(ctx,4,local+2); /*left-points*/
	local[2]= w;
	local[3]= NIL;
	local[4]= local[1];
	local[5]= argv[1];
	local[6]= local[0];
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(pointer)primtF1757quickhull_left(ctx,4,local+4); /*quickhull-left*/
	local[4]= w;
	local[5]= local[0];
	local[6]= local[2];
	local[7]= local[0];
	local[8]= argv[2];
	local[9]= argv[3];
	ctx->vsp=local+10;
	w=(pointer)primtF1757quickhull_left(ctx,4,local+6); /*quickhull-left*/
	local[6]= w;
	local[7]= fqv[3];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(*ftab[1])(ctx,4,local+5,&ftab[1],fqv[4]); /*delete*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)NCONC(ctx,2,local+4); /*nconc*/
	local[3] = w;
	w = local[3];
	local[0]= w;
primtBLK1808:
	ctx->vsp=local; return(local[0]);}

/*quickhull-right*/
static pointer primtF1758quickhull_right(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	if (argv[0]!=NIL) goto primtCON1813;
	local[0]= argv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	ctx->vsp=local+0;
	local[0]=w;
	goto primtBLK1811;
	goto primtCON1812;
primtCON1813:
	local[0]= NIL;
primtCON1812:
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)primtF1754rightmost_point(ctx,4,local+0); /*rightmost-point*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= argv[1];
	local[3]= local[0];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)primtF1756right_points(ctx,4,local+1); /*right-points*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= local[0];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)primtF1756right_points(ctx,4,local+2); /*right-points*/
	local[2]= w;
	local[3]= NIL;
	local[4]= local[0];
	local[5]= local[2];
	local[6]= local[0];
	local[7]= argv[2];
	local[8]= argv[3];
	ctx->vsp=local+9;
	w=(pointer)primtF1758quickhull_right(ctx,4,local+5); /*quickhull-right*/
	local[5]= w;
	local[6]= fqv[3];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(*ftab[1])(ctx,4,local+4,&ftab[1],fqv[4]); /*delete*/
	local[4]= w;
	local[5]= local[1];
	local[6]= argv[1];
	local[7]= local[0];
	local[8]= argv[3];
	ctx->vsp=local+9;
	w=(pointer)primtF1758quickhull_right(ctx,4,local+5); /*quickhull-right*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)NCONC(ctx,2,local+4); /*nconc*/
	local[3] = w;
	w = local[3];
	local[0]= w;
primtBLK1811:
	ctx->vsp=local; return(local[0]);}

/*quickhull*/
static pointer primtF1759quickhull(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto primtENT1816;}
	local[0]= fqv[5];
primtENT1816:
primtENT1815:
	if (n>2) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[0];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)0L));
	  w=makeflt(local[6]->c.fvec.fv[i]);}
	local[6]= makeflt((double)fabs(fltval(w)));
	local[7]= local[0];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)1L));
	  w=makeflt(local[7]->c.fvec.fv[i]);}
	{ double left,right;
		right=fltval(makeflt((double)fabs(fltval(w)))); left=fltval(local[6]);
	if (left <= right) goto primtIF1817;}
	local[5] = makeint((eusinteger_t)1L);
	local[6]= local[5];
	goto primtIF1818;
primtIF1817:
	local[6]= NIL;
primtIF1818:
	local[6]= argv[0];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,primtCLO1819,env,argv,local);
	local[8]= (pointer)get_sym_func(fqv[6]);
	ctx->vsp=local+9;
	w=(pointer)primtF1752find_extream(ctx,3,local+6); /*find-extream*/
	local[1] = w;
	local[6]= argv[0];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,primtCLO1820,env,argv,local);
	local[8]= (pointer)get_sym_func(fqv[7]);
	ctx->vsp=local+9;
	w=(pointer)primtF1752find_extream(ctx,3,local+6); /*find-extream*/
	local[2] = w;
	local[6]= argv[0];
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)primtF1755left_points(ctx,4,local+6); /*left-points*/
	local[6]= w;
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)primtF1757quickhull_left(ctx,4,local+6); /*quickhull-left*/
	local[3] = w;
	local[6]= argv[0];
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)primtF1756right_points(ctx,4,local+6); /*right-points*/
	local[6]= w;
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)primtF1758quickhull_right(ctx,4,local+6); /*quickhull-right*/
	local[4] = w;
	local[6]= local[1];
	local[7]= local[4];
	local[8]= fqv[3];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(*ftab[1])(ctx,4,local+6,&ftab[1],fqv[4]); /*delete*/
	local[4] = w;
	local[6]= local[2];
	local[7]= local[4];
	local[8]= fqv[3];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(*ftab[1])(ctx,4,local+6,&ftab[1],fqv[4]); /*delete*/
	local[4] = w;
	local[6]= local[3];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)NCONC(ctx,2,local+6); /*nconc*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)NREVERSE(ctx,1,local+6); /*nreverse*/
	local[0]= w;
primtBLK1814:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer primtCLO1819(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[5];
	ctx->vsp=local+2;
	w=(pointer)AREF(ctx,2,local+0); /*aref*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer primtCLO1820(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[5];
	ctx->vsp=local+2;
	w=(pointer)AREF(ctx,2,local+0); /*aref*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*find-coplanar-vertices*/
static pointer primtF1760find_coplanar_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,3,local+0,&ftab[2],fqv[8]); /*triangle-normal*/
	local[0]= w;
	local[1]= local[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)VINNERPRODUCT(ctx,2,local+1); /*v.*/
	local[1]= makeflt(-(fltval(w)));
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,primtCLO1822,env,argv,local);
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)MAPCAN(ctx,2,local+2); /*mapcan*/
	local[0]= w;
primtBLK1821:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer primtCLO1822(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= env->c.clo.env2[0];
	ctx->vsp=local+2;
	w=(pointer)VINNERPRODUCT(ctx,2,local+0); /*v.*/
	local[0]= w;
	local[1]= env->c.clo.env2[1];
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)ABS(ctx,1,local+0); /*abs*/
	local[0]= w;
	local[1]= loadglobal(fqv[9]);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto primtIF1823;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto primtIF1824;
primtIF1823:
	local[0]= NIL;
primtIF1824:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*colinear-p*/
static pointer primtF1761colinear_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto primtENT1827;}
	local[0]= loadglobal(fqv[9]);
primtENT1827:
	w = local[0];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[10],w);
primtENT1826:
	if (n>4) maerror();
	local[3]= argv[1];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)VMINUS(ctx,2,local+3); /*v-*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)VMINUS(ctx,2,local+4); /*v-*/
	local[4]= w;
	local[5]= local[3];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+5); /*v**/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VNORM(ctx,1,local+5); /*norm*/
	local[5]= w;
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)VNORM(ctx,1,local+6); /*norm*/
	local[6]= w;
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)VNORM(ctx,1,local+7); /*norm*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MAX(ctx,2,local+6); /*max*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= local[5];
	local[7]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(*ftab[3])(ctx,2,local+6,&ftab[3],fqv[11]); /*eps=*/
	if (w==NIL) goto primtIF1828;
	local[6]= local[3];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)VINNERPRODUCT(ctx,2,local+6); /*v.*/
	local[6]= w;
	local[7]= local[4];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)VINNERPRODUCT(ctx,2,local+7); /*v.*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	goto primtIF1829;
primtIF1828:
	local[6]= NIL;
primtIF1829:
	w = local[6];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
primtBLK1825:
	ctx->vsp=local; return(local[0]);}

/*find-colinear-points*/
static pointer primtF1762find_colinear_points(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
primtWHL1831:
	if (argv[0]==NIL) goto primtWHX1832;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[6];
	local[0] = w;
	local[3] = argv[0];
primtWHL1834:
	if (local[3]==NIL) goto primtWHX1835;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[6];
	local[1] = w;
	local[6]= NIL;
	local[7]= local[3];
primtWHL1837:
	if (local[7]==NIL) goto primtWHX1838;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[0];
	local[9]= local[1];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)primtF1761colinear_p(ctx,3,local+8); /*colinear-p*/
	local[4] = w;
	if (local[4]==NIL) goto primtIF1840;
	local[8]= local[4];
	local[9]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto primtCON1843;
	local[8]= local[0];
	goto primtCON1842;
primtCON1843:
	local[8]= local[4];
	local[9]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto primtCON1844;
	local[8]= local[1];
	goto primtCON1842;
primtCON1844:
	local[8]= local[6];
	goto primtCON1842;
primtCON1845:
	local[8]= NIL;
primtCON1842:
	w = local[5];
	ctx->vsp=local+9;
	local[5] = cons(ctx,local[8],w);
	local[8]= local[5];
	goto primtIF1841;
primtIF1840:
	local[8]= NIL;
primtIF1841:
	goto primtWHL1837;
primtWHX1838:
	local[8]= NIL;
primtBLK1839:
	w = NIL;
	goto primtWHL1834;
primtWHX1835:
	local[6]= NIL;
primtBLK1836:
	goto primtWHL1831;
primtWHX1832:
	local[6]= NIL;
primtBLK1833:
	w = local[5];
	local[0]= w;
primtBLK1830:
	ctx->vsp=local; return(local[0]);}

/*remove-colinears-from-circuit*/
static pointer primtF1763remove_colinears_from_circuit(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	w = makeint((eusinteger_t)3L);
	if ((eusinteger_t)local[0] > (eusinteger_t)w) goto primtCON1848;
	local[0]= argv[0];
	goto primtCON1847;
primtCON1848:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)primtF1761colinear_p(ctx,3,local+0); /*colinear-p*/
	if (w==NIL) goto primtCON1849;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	ctx->vsp=local+2;
	w=(pointer)primtF1763remove_colinears_from_circuit(ctx,1,local+1); /*remove-colinears-from-circuit*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	goto primtCON1847;
primtCON1849:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	ctx->vsp=local+2;
	w=(pointer)primtF1763remove_colinears_from_circuit(ctx,1,local+1); /*remove-colinears-from-circuit*/
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	goto primtCON1847;
primtCON1850:
	local[0]= NIL;
primtCON1847:
	w = local[0];
	local[0]= w;
primtBLK1846:
	ctx->vsp=local; return(local[0]);}

/*coplanar-p*/
static pointer primtF1764coplanar_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto primtENT1853;}
	local[0]= loadglobal(fqv[9]);
primtENT1853:
	w = local[0];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[10],w);
primtENT1852:
	if (n>5) maerror();
	local[3]= argv[1];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)VMINUS(ctx,2,local+3); /*v-*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(pointer)VMINUS(ctx,2,local+4); /*v-*/
	local[4]= w;
	local[5]= argv[3];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)VMINUS(ctx,2,local+5); /*v-*/
	local[5]= w;
	local[6]= local[3];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+6); /*v**/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)VNORMALIZE(ctx,1,local+6); /*normalize-vector*/
	local[6]= w;
	local[7]= local[6];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)VINNERPRODUCT(ctx,2,local+7); /*v.*/
	local[7]= w;
	local[8]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+9;
	w=(*ftab[3])(ctx,2,local+7,&ftab[3],fqv[11]); /*eps=*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
primtBLK1851:
	ctx->vsp=local; return(local[0]);}

/*gift-wrapping*/
static pointer primtF1765gift_wrapping(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[12];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= NIL;
	local[3]= loadglobal(fqv[13]);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= argv[4];
primtWHL1855:
	if (local[8]==NIL) goto primtWHX1856;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w = local[1];
	if (memq(local[9],w)!=NIL) goto primtIF1858;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= argv[1];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)VMINUS(ctx,3,local+9); /*v-*/
	local[9]= local[4];
	local[10]= argv[3];
	ctx->vsp=local+11;
	w=(pointer)VINNERPRODUCT(ctx,2,local+9); /*v.*/
	local[5] = w;
	local[9]= local[4];
	local[10]= argv[2];
	ctx->vsp=local+11;
	w=(pointer)VINNERPRODUCT(ctx,2,local+9); /*v.*/
	local[6] = w;
	local[9]= local[5];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[0] = w;
	local[9]= local[0];
	if (loadglobal(fqv[14])!=local[9]) goto primtIF1860;
	local[9]= T;
	local[10]= fqv[15];
	local[11]= local[0];
	local[12]= local[4];
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= local[5];
	local[15]= local[6];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,7,local+9); /*format*/
	w = fqv[16];
	ctx->vsp=local+9;
	local[0]=w;
	goto primtBLK1854;
	goto primtIF1861;
primtIF1860:
	local[9]= NIL;
primtIF1861:
	local[9]= local[0];
	local[10]= loadglobal(fqv[13]);
	ctx->vsp=local+11;
	w=(pointer)LESSP(ctx,2,local+9); /*<*/
	if (w!=NIL) goto primtIF1862;
	local[9]= local[0];
	{ double left,right;
		right=fltval(local[3]); left=fltval(local[9]);
	if (left < right) goto primtIF1862;}
	local[2] = local[7];
	local[3] = local[0];
	local[9]= local[3];
	goto primtIF1863;
primtIF1862:
	local[9]= NIL;
primtIF1863:
	goto primtIF1859;
primtIF1858:
	local[9]= NIL;
primtIF1859:
	goto primtWHL1855;
primtWHX1856:
	local[9]= NIL;
primtBLK1857:
	w = NIL;
	local[7]= local[3];
	storeglobal(fqv[17],local[7]);
	w = local[2];
	local[0]= w;
primtBLK1854:
	ctx->vsp=local; return(local[0]);}

/*make-face-from-vertices*/
static pointer primtF1766make_face_from_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[18]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,1,local+5,&ftab[4],fqv[19]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= NIL;
	local[7]= argv[0];
primtWHL1865:
	if (local[7]==NIL) goto primtWHX1866;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	local[8]= local[3];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(*ftab[5])(ctx,2,local+8,&ftab[5],fqv[20]); /*intersection*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	if (local[2]!=NIL) goto primtCON1869;
	local[8]= loadglobal(fqv[21]);
	ctx->vsp=local+9;
	w=(pointer)INSTANTIATE(ctx,1,local+8); /*instantiate*/
	local[2] = w;
	local[8]= local[2];
	local[9]= fqv[22];
	local[10]= fqv[23];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[24];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= fqv[25];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,8,local+8); /*send*/
	local[8]= local[5];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)NCONC(ctx,2,local+8); /*nconc*/
	local[8]= local[6];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)NCONC(ctx,2,local+8); /*nconc*/
	local[8]= w;
	goto primtCON1868;
primtCON1869:
	if (local[2]==NIL) goto primtCON1870;
	local[8]= local[2];
	local[9]= fqv[26];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,5,local+8); /*send*/
	local[8]= w;
	goto primtCON1868;
primtCON1870:
	local[8]= NIL;
primtCON1868:
	local[8]= local[2];
	w = local[1];
	ctx->vsp=local+9;
	local[1] = cons(ctx,local[8],w);
	local[5] = local[6];
	goto primtWHL1865;
primtWHX1866:
	local[8]= NIL;
primtBLK1867:
	w = NIL;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)NREVERSE(ctx,1,local+6); /*nreverse*/
	local[6]= local[0];
	local[7]= fqv[22];
	local[8]= fqv[27];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	w = local[0];
	local[0]= w;
primtBLK1864:
	ctx->vsp=local; return(local[0]);}

/*make-face-from-coplanar-vertices*/
static pointer primtF1767make_face_from_coplanar_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,3,local+0,&ftab[2],fqv[8]); /*triangle-normal*/
	local[0]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)primtF1760find_coplanar_vertices(ctx,4,local+1); /*find-coplanar-vertices*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	w = makeint((eusinteger_t)3L);
	if ((eusinteger_t)local[6] <= (eusinteger_t)w) goto primtCON1873;
	local[6]= (pointer)get_sym_func(fqv[28]);
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[2] = w;
	local[6]= local[2];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)primtF1759quickhull(ctx,2,local+6); /*quickhull*/
	local[3] = w;
	local[6]= local[3];
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	local[3] = w;
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)primtF1763remove_colinears_from_circuit(ctx,1,local+6); /*remove-colinears-from-circuit*/
	local[3] = w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	local[6]= NIL;
	local[7]= local[1];
primtWHL1874:
	if (local[7]==NIL) goto primtWHX1875;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w = local[3];
	if (memq(local[8],w)!=NIL) goto primtIF1877;
	local[8]= local[6];
	w = local[5];
	ctx->vsp=local+9;
	local[5] = cons(ctx,local[8],w);
	local[8]= local[5];
	goto primtIF1878;
primtIF1877:
	local[8]= NIL;
primtIF1878:
	goto primtWHL1874;
primtWHX1875:
	local[8]= NIL;
primtBLK1876:
	w = NIL;
	if (local[5]==NIL) goto primtIF1879;
	local[6]= NIL;
	local[7]= local[5];
primtWHL1881:
	if (local[7]==NIL) goto primtWHX1882;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= T;
	local[9]= fqv[29];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w = loadglobal(fqv[30]);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	storeglobal(fqv[30],local[8]);
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr!=NIL) goto primtIF1884;
	local[8]= local[6];
	local[9]= loadglobal(fqv[31]);
	local[10]= fqv[3];
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(*ftab[1])(ctx,4,local+8,&ftab[1],fqv[4]); /*delete*/
	local[8]= w;
	storeglobal(fqv[31],w);
	goto primtIF1885;
primtIF1884:
	local[8]= NIL;
primtIF1885:
	goto primtWHL1881;
primtWHX1882:
	local[8]= NIL;
primtBLK1883:
	w = NIL;
	local[6]= w;
	goto primtIF1880;
primtIF1879:
	local[6]= NIL;
primtIF1880:
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,primtCLO1886,env,argv,local);
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)MAPCAN(ctx,2,local+6); /*mapcan*/
	local[4] = w;
	local[6]= local[4];
	goto primtCON1872;
primtCON1873:
	local[6]= argv[0];
	local[7]= argv[1];
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,3,local+6); /*list*/
	local[4] = w;
	local[6]= local[4];
	goto primtCON1872;
primtCON1887:
	local[6]= NIL;
primtCON1872:
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)primtF1766make_face_from_vertices(ctx,1,local+6); /*make-face-from-vertices*/
	local[0]= w;
primtBLK1871:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer primtCLO1886(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[1];
	ctx->vsp=local+2;
	w=(pointer)ASSQ(ctx,2,local+0); /*assq*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*tangent-foot*/
static pointer primtF1768tangent_foot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)VMINUS(ctx,2,local+0); /*v-*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)VMINUS(ctx,2,local+1); /*v-*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)VNORM2(ctx,1,local+2); /*norm2*/
	local[2]= w;
	local[3]= local[0];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)VINNERPRODUCT(ctx,2,local+3); /*v.*/
	local[3]= w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	local[4]= argv[1];
	local[5]= local[3];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,2,local+5); /*scale*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VPLUS(ctx,2,local+4); /*v+*/
	local[0]= w;
primtBLK1888:
	ctx->vsp=local; return(local[0]);}

/*calc-p2-of-lowest-hull*/
static pointer primtF1769calc_p2_of_lowest_hull(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= makeflt(1.5707963267948965579990e+00);
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[1];
primtWHL1890:
	if (local[6]==NIL) goto primtWHX1891;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)VMINUS(ctx,2,local+7); /*v-*/
	local[4] = w;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)EQUAL(ctx,2,local+7); /*equal*/
	if (w!=NIL) goto primtIF1893;
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)VNORM(ctx,1,local+7); /*norm*/
	local[7]= w;
	{ double left,right;
		right=fltval(makeflt(9.9999999999999977795540e-02)); left=fltval(local[7]);
	if (left <= right) goto primtIF1893;}
	local[7]= makeflt(0.0000000000000000000000e+00);
	local[8]= local[4];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)NUMEQUAL(ctx,2,local+7); /*=*/
	if (w==NIL) goto primtAND1895;
	local[7]= makeflt(0.0000000000000000000000e+00);
	local[8]= local[4];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)NUMEQUAL(ctx,2,local+7); /*=*/
	if (w==NIL) goto primtAND1895;
	goto primtIF1893;
primtAND1895:
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)COPYOBJ(ctx,1,local+7); /*copy-object*/
	local[3] = w;
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)SETELT(ctx,3,local+7); /*setelt*/
	local[7]= makeflt(0.0000000000000000000000e+00);
	local[8]= local[4];
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)NUMEQUAL(ctx,2,local+7); /*=*/
	if (w==NIL) goto primtIF1896;
	local[2] = makeflt(0.0000000000000000000000e+00);
	local[7]= local[2];
	goto primtIF1897;
primtIF1896:
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)VNORMALIZE(ctx,1,local+7); /*normalize-vector*/
	local[7]= w;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)VNORMALIZE(ctx,1,local+8); /*normalize-vector*/
	local[8]= w;
	local[9]= local[4];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+9); /*v**/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)VNORMALIZE(ctx,1,local+9); /*normalize-vector*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[6])(ctx,3,local+7,&ftab[6],fqv[32]); /*vector-angle*/
	local[2] = w;
	local[7]= local[2];
primtIF1897:
	local[7]= local[2];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto primtIF1898;
	local[0] = local[5];
	local[1] = local[2];
	local[7]= local[1];
	goto primtIF1899;
primtIF1898:
	local[7]= NIL;
primtIF1899:
	goto primtIF1894;
primtIF1893:
	local[7]= NIL;
primtIF1894:
	goto primtWHL1890;
primtWHX1891:
	local[7]= NIL;
primtBLK1892:
	w = NIL;
	w = local[0];
	local[0]= w;
primtBLK1889:
	ctx->vsp=local; return(local[0]);}

/*calc-p3-of-lowest-hull*/
static pointer primtF1770calc_p3_of_lowest_hull(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= makeflt(3.1415926535897931159980e+00);
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= argv[2];
primtWHL1901:
	if (local[7]==NIL) goto primtWHX1902;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)EQUAL(ctx,2,local+8); /*equal*/
	if (w!=NIL) goto primtIF1904;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)EQUAL(ctx,2,local+8); /*equal*/
	if (w!=NIL) goto primtIF1904;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(pointer)primtF1768tangent_foot(ctx,3,local+8); /*tangent-foot*/
	local[0] = w;
	local[8]= local[0];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)VMINUS(ctx,2,local+8); /*v-*/
	local[4] = w;
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)VNORM(ctx,1,local+8); /*norm*/
	local[8]= w;
	{ double left,right;
		right=fltval(makeflt(1.9999999999999995559108e-01)); left=fltval(local[8]);
	if (left <= right) goto primtIF1906;}
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(*ftab[2])(ctx,3,local+8,&ftab[2],fqv[8]); /*triangle-normal*/
	local[5] = w;
	local[8]= local[5];
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto primtIF1908;
	local[8]= makeint((eusinteger_t)-1L);
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[5] = w;
	local[8]= local[5];
	goto primtIF1909;
primtIF1908:
	local[8]= NIL;
primtIF1909:
	local[8]= fqv[33];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)VMINUS(ctx,2,local+8); /*v-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)VNORM(ctx,1,local+8); /*norm*/
	local[8]= w;
	local[9]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+10;
	w=(*ftab[3])(ctx,2,local+8,&ftab[3],fqv[11]); /*eps=*/
	if (w==NIL) goto primtIF1910;
	local[3] = makeflt(0.0000000000000000000000e+00);
	local[8]= local[3];
	goto primtIF1911;
primtIF1910:
	local[8]= fqv[34];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)VNORMALIZE(ctx,1,local+9); /*normalize-vector*/
	local[9]= w;
	local[10]= fqv[35];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+10); /*v**/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)VNORMALIZE(ctx,1,local+10); /*normalize-vector*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[6])(ctx,3,local+8,&ftab[6],fqv[32]); /*vector-angle*/
	local[3] = w;
	local[8]= local[3];
primtIF1911:
	local[8]= local[3];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto primtIF1912;
	local[1] = local[6];
	local[2] = local[3];
	local[8]= local[2];
	goto primtIF1913;
primtIF1912:
	local[8]= NIL;
primtIF1913:
	goto primtIF1907;
primtIF1906:
	local[8]= NIL;
primtIF1907:
	goto primtIF1905;
primtIF1904:
	local[8]= NIL;
primtIF1905:
	goto primtWHL1901;
primtWHX1902:
	local[8]= NIL;
primtBLK1903:
	w = NIL;
	w = local[1];
	local[0]= w;
primtBLK1900:
	ctx->vsp=local; return(local[0]);}

/*find-initial-hull*/
static pointer primtF1771find_initial_hull(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,primtCLO1915,env,argv,local);
	local[2]= (pointer)get_sym_func(fqv[6]);
	ctx->vsp=local+3;
	w=(pointer)primtF1752find_extream(ctx,3,local+0); /*find-extream*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= local[0];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)primtF1769calc_p2_of_lowest_hull(ctx,2,local+4); /*calc-p2-of-lowest-hull*/
	local[1] = w;
	local[4]= local[0];
	local[5]= local[1];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)primtF1770calc_p3_of_lowest_hull(ctx,3,local+4); /*calc-p3-of-lowest-hull*/
	local[2] = w;
	if (local[2]!=NIL) goto primtIF1916;
	w = NIL;
	ctx->vsp=local+4;
	local[0]=w;
	goto primtBLK1914;
	goto primtIF1917;
primtIF1916:
	local[4]= NIL;
primtIF1917:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(*ftab[0])(ctx,3,local+4,&ftab[0],fqv[1]); /*triangle*/
	local[4]= w;
	local[5]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	if (w==NIL) goto primtIF1918;
	local[3] = local[1];
	local[1] = local[2];
	local[2] = local[3];
	local[4]= local[2];
	goto primtIF1919;
primtIF1918:
	local[4]= NIL;
primtIF1919:
primtWHL1920:
	local[4]= (pointer)get_sym_func(fqv[28]);
	local[5]= local[1];
	local[6]= local[0];
	local[7]= local[2];
	local[8]= local[1];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,5,local+5); /*list*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)primtF1763remove_colinears_from_circuit(ctx,1,local+4); /*remove-colinears-from-circuit*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	w = makeint((eusinteger_t)5L);
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto primtWHX1921;
	local[4]= local[2];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[7])(ctx,2,local+4,&ftab[7],fqv[36]); /*remove*/
	argv[0] = w;
	local[4]= local[0];
	local[5]= local[1];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)primtF1770calc_p3_of_lowest_hull(ctx,3,local+4); /*calc-p3-of-lowest-hull*/
	local[2] = w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(*ftab[0])(ctx,3,local+4,&ftab[0],fqv[1]); /*triangle*/
	local[4]= w;
	local[5]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	if (w==NIL) goto primtIF1923;
	local[3] = local[1];
	local[1] = local[2];
	local[2] = local[3];
	local[4]= local[2];
	goto primtIF1924;
primtIF1923:
	local[4]= NIL;
primtIF1924:
	goto primtWHL1920;
primtWHX1921:
	local[4]= NIL;
primtBLK1922:
	local[4]= local[0];
	local[5]= local[2];
	local[6]= local[1];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)primtF1767make_face_from_coplanar_vertices(ctx,4,local+4); /*make-face-from-coplanar-vertices*/
	local[0]= w;
primtBLK1914:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer primtCLO1915(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)AREF(ctx,2,local+0); /*aref*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*enclosed-vertexp*/
static pointer primtF1772enclosed_vertexp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= T;
	local[1]= NIL;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
primtWHL1926:
	if (local[2]==NIL) goto primtWHX1927;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= *(ovafptr(local[1],fqv[37]));
	if (local[3]==NIL) goto primtAND1929;
	local[3]= *(ovafptr(local[1],fqv[38]));
	if (local[3]==NIL) goto primtAND1929;
	local[3]= local[0];
primtAND1929:
	local[0] = local[3];
	goto primtWHL1926;
primtWHX1927:
	local[3]= NIL;
primtBLK1928:
	w = NIL;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	if (local[1]==NIL) goto primtAND1930;
	local[1]= local[0];
primtAND1930:
	w = local[1];
	local[0]= w;
primtBLK1925:
	ctx->vsp=local; return(local[0]);}

/*convex-hull-3d*/
static pointer primtF1773convex_hull_3d(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= NIL;
	local[15]= NIL;
	local[16]= NIL;
	storeglobal(fqv[39],argv[0]);
	local[17]= (pointer)get_sym_func(fqv[40]);
	local[18]= argv[0];
	ctx->vsp=local+19;
	w=(pointer)MAPCAR(ctx,2,local+17); /*mapcar*/
	storeglobal(fqv[31],w);
	storeglobal(fqv[41],NIL);
	storeglobal(fqv[30],NIL);
	local[17]= loadglobal(fqv[31]);
	ctx->vsp=local+18;
	w=(pointer)primtF1771find_initial_hull(ctx,1,local+17); /*find-initial-hull*/
	local[0] = w;
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	storeglobal(fqv[42],w);
	local[17]= local[0];
	local[18]= fqv[27];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)COPYSEQ(ctx,1,local+17); /*copy-seq*/
	local[14] = w;
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	local[13] = w;
	local[17]= NIL;
	local[18]= loadglobal(fqv[39]);
primtWHL1932:
	if (local[18]==NIL) goto primtWHX1933;
	w=local[18];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	w=local[18];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18] = (w)->c.cons.cdr;
	w = local[19];
	local[17] = w;
	local[19]= local[0];
	local[20]= fqv[43];
	local[21]= local[17];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= w;
	local[20]= makeflt(9.9999999999999991239646e-05);
	ctx->vsp=local+21;
	w=(pointer)GREATERP(ctx,2,local+19); /*>*/
	if (w==NIL) goto primtIF1935;
	local[19]= loadglobal(fqv[44]);
	local[20]= fqv[45];
	local[21]= local[17];
	local[22]= local[0];
	local[23]= fqv[43];
	local[24]= local[17];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)XFORMAT(ctx,4,local+19); /*format*/
	local[19]= local[17];
	local[20]= loadglobal(fqv[39]);
	local[21]= fqv[3];
	local[22]= makeint((eusinteger_t)1L);
	ctx->vsp=local+23;
	w=(*ftab[7])(ctx,4,local+19,&ftab[7],fqv[36]); /*remove*/
	local[19]= w;
	storeglobal(fqv[39],w);
	goto primtIF1936;
primtIF1935:
	local[19]= NIL;
primtIF1936:
	goto primtWHL1932;
primtWHX1933:
	local[19]= NIL;
primtBLK1934:
	w = NIL;
primtWHL1937:
	if (local[13]==NIL) goto primtWHX1938;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13] = (w)->c.cons.cdr;
	w = local[17];
	local[0] = w;
	local[17]= NIL;
	local[18]= local[0];
	local[19]= fqv[27];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,2,local+18); /*send*/
	local[18]= w;
primtWHL1940:
	if (local[18]==NIL) goto primtWHX1941;
	w=local[18];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	w=local[18];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18] = (w)->c.cons.cdr;
	w = local[19];
	local[17] = w;
	local[19]= local[17];
	w = local[14];
	if (memq(local[19],w)==NIL) goto primtCON1944;
	local[19]= local[17];
	local[20]= fqv[23];
	local[21]= local[0];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= w;
	local[20]= loadglobal(fqv[31]);
	ctx->vsp=local+21;
	w=(pointer)ASSQ(ctx,2,local+19); /*assq*/
	local[6] = w;
	local[19]= local[17];
	local[20]= fqv[24];
	local[21]= local[0];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= w;
	local[20]= loadglobal(fqv[31]);
	ctx->vsp=local+21;
	w=(pointer)ASSQ(ctx,2,local+19); /*assq*/
	local[7] = w;
	if (local[6]==NIL) goto primtOR1947;
	if (local[7]==NIL) goto primtOR1947;
	goto primtIF1945;
primtOR1947:
	storeglobal(fqv[46],local[17]);
	local[19]= local[0];
	storeglobal(fqv[47],local[19]);
	local[19]= fqv[48];
	ctx->vsp=local+20;
	w=(pointer)SIGERROR(ctx,1,local+19); /*error*/
	local[19]= w;
	goto primtIF1946;
primtIF1945:
	local[19]= NIL;
primtIF1946:
	local[19]= local[0];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= local[0];
	local[22]= fqv[49];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[21]= w;
	local[22]= local[17];
	local[23]= fqv[50];
	local[24]= local[0];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[22]= w;
	local[23]= loadglobal(fqv[31]);
	ctx->vsp=local+24;
	w=(pointer)primtF1765gift_wrapping(ctx,5,local+19); /*gift-wrapping*/
	local[8] = w;
	local[19]= local[0];
	local[20]= fqv[49];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,2,local+19); /*send*/
	local[19]= w;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	ctx->vsp=local+23;
	w=(*ftab[2])(ctx,3,local+20,&ftab[2],fqv[8]); /*triangle-normal*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+19); /*v**/
	local[19]= w;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	ctx->vsp=local+22;
	w=(pointer)VMINUS(ctx,2,local+20); /*v-*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)VINNERPRODUCT(ctx,2,local+19); /*v.*/
	local[19]= w;
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[19]);
	if (left >= right) goto primtIF1948;}
	local[9] = local[7];
	local[7] = local[8];
	local[8] = local[9];
	local[19]= local[8];
	goto primtIF1949;
primtIF1948:
	local[19]= NIL;
primtIF1949:
	if (*(ovafptr(local[17],fqv[37]))==NIL) goto primtIF1950;
	local[19]= *(ovafptr(local[17],fqv[37]));
	goto primtIF1951;
primtIF1950:
	local[19]= *(ovafptr(local[17],fqv[38]));
primtIF1951:
	local[20]= fqv[12];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,2,local+19); /*send*/
	local[16] = w;
	local[19]= (pointer)get_sym_func(fqv[40]);
	local[20]= local[16];
	local[21]= local[17];
	local[22]= fqv[12];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(*ftab[8])(ctx,2,local+20,&ftab[8],fqv[51]); /*set-difference*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)MAPCAR(ctx,2,local+19); /*mapcar*/
	local[16] = w;
	local[19]= local[6];
	local[20]= local[7];
	local[21]= local[8];
	local[22]= loadglobal(fqv[31]);
	local[23]= local[16];
	local[24]= fqv[52];
	local[25]= (pointer)get_sym_func(fqv[28]);
	ctx->vsp=local+26;
	w=(*ftab[8])(ctx,4,local+22,&ftab[8],fqv[51]); /*set-difference*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)primtF1767make_face_from_coplanar_vertices(ctx,4,local+19); /*make-face-from-coplanar-vertices*/
	local[11] = w;
	local[19]= local[11];
	local[20]= fqv[27];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,2,local+19); /*send*/
	local[10] = w;
	local[19]= NIL;
	local[20]= local[10];
primtWHL1952:
	if (local[20]==NIL) goto primtWHX1953;
	w=local[20];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	w=local[20];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20] = (w)->c.cons.cdr;
	w = local[21];
	local[19] = w;
	local[21]= local[19];
	w = local[14];
	if (memq(local[21],w)==NIL) goto primtCON1956;
	local[21]= local[19];
	local[22]= local[14];
	ctx->vsp=local+23;
	w=(*ftab[1])(ctx,2,local+21,&ftab[1],fqv[4]); /*delete*/
	local[14] = w;
	local[21]= local[19];
	w = local[15];
	ctx->vsp=local+22;
	local[15] = cons(ctx,local[21],w);
	local[21]= NIL;
	local[22]= NIL;
	local[23]= local[19];
	local[24]= fqv[12];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,2,local+23); /*send*/
	local[23]= w;
primtWHL1957:
	if (local[23]==NIL) goto primtWHX1958;
	w=local[23];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[24]= (w)->c.cons.car;
	w=local[23];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23] = (w)->c.cons.cdr;
	w = local[24];
	local[22] = w;
	local[24]= local[22];
	local[25]= loadglobal(fqv[31]);
	local[26]= fqv[52];
	local[27]= (pointer)get_sym_func(fqv[28]);
	ctx->vsp=local+28;
	w=(*ftab[9])(ctx,4,local+24,&ftab[9],fqv[53]); /*find*/
	local[21] = w;
	local[24]= local[21];
	ctx->vsp=local+25;
	w=(pointer)primtF1772enclosed_vertexp(ctx,1,local+24); /*enclosed-vertexp*/
	if (w==NIL) goto primtIF1960;
	local[24]= local[21];
	local[25]= loadglobal(fqv[31]);
	local[26]= fqv[3];
	local[27]= makeint((eusinteger_t)1L);
	ctx->vsp=local+28;
	w=(*ftab[1])(ctx,4,local+24,&ftab[1],fqv[4]); /*delete*/
	local[24]= w;
	storeglobal(fqv[31],w);
	goto primtIF1961;
primtIF1960:
	local[24]= NIL;
primtIF1961:
	goto primtWHL1957;
primtWHX1958:
	local[24]= NIL;
primtBLK1959:
	w = NIL;
	local[21]= w;
	goto primtCON1955;
primtCON1956:
	local[21]= local[19];
	w = local[15];
	if (memq(local[21],w)==NIL) goto primtCON1962;
	local[21]= loadglobal(fqv[44]);
	local[22]= fqv[54];
	local[23]= local[19];
	ctx->vsp=local+24;
	w=(pointer)XFORMAT(ctx,3,local+21); /*format*/
	local[21]= loadglobal(fqv[9]);
	local[22]= makeint((eusinteger_t)2L);
	ctx->vsp=local+23;
	w=(pointer)QUOTIENT(ctx,2,local+21); /*/*/
	local[21]= w;
	w = local[21];
	ctx->vsp=local+22;
	bindspecial(ctx,fqv[9],w);
	local[25]= loadglobal(fqv[44]);
	local[26]= fqv[55];
	local[27]= makeint((eusinteger_t)2L);
	local[28]= loadglobal(fqv[9]);
	ctx->vsp=local+29;
	w=(pointer)TIMES(ctx,2,local+27); /***/
	local[27]= w;
	local[28]= loadglobal(fqv[9]);
	ctx->vsp=local+29;
	w=(pointer)XFORMAT(ctx,4,local+25); /*format*/
	local[25]= loadglobal(fqv[9]);
	local[26]= makeflt(9.9999999999999991239646e-06);
	ctx->vsp=local+27;
	w=(pointer)LESSP(ctx,2,local+25); /*<*/
	if (w==NIL) goto primtIF1963;
	local[25]= fqv[56];
	ctx->vsp=local+26;
	w=(pointer)SIGERROR(ctx,1,local+25); /*error*/
	local[25]= w;
	goto primtIF1964;
primtIF1963:
	local[25]= argv[0];
	ctx->vsp=local+26;
	w=(pointer)primtF1773convex_hull_3d(ctx,1,local+25); /*convex-hull-3d*/
	ctx->vsp=local+25;
	unwind(ctx,local+0);
	local[0]=w;
	goto primtBLK1931;
primtIF1964:
	ctx->vsp=local+26;
	unbindx(ctx,1);
	w = local[25];
	local[21]= w;
	goto primtCON1955;
primtCON1962:
	local[21]= local[14];
	local[22]= local[19];
	ctx->vsp=local+23;
	w=(pointer)LIST(ctx,1,local+22); /*list*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)APPEND(ctx,2,local+21); /*append*/
	local[14] = w;
	local[21]= local[14];
	goto primtCON1955;
primtCON1965:
	local[21]= NIL;
primtCON1955:
	goto primtWHL1952;
primtWHX1953:
	local[21]= NIL;
primtBLK1954:
	w = NIL;
	local[19]= local[11];
	w = local[13];
	ctx->vsp=local+20;
	local[13] = cons(ctx,local[19],w);
	local[19]= loadglobal(fqv[42]);
	local[20]= local[11];
	ctx->vsp=local+21;
	w=(pointer)LIST(ctx,1,local+20); /*list*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)NCONC(ctx,2,local+19); /*nconc*/
	if (loadglobal(fqv[57])==NIL) goto primtIF1966;
	local[19]= loadglobal(fqv[42]);
	ctx->vsp=local+20;
	w=(pointer)LENGTH(ctx,1,local+19); /*length*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)PRINT(ctx,1,local+19); /*print*/
	local[19]= w;
	goto primtIF1967;
primtIF1966:
	local[19]= NIL;
primtIF1967:
	goto primtCON1943;
primtCON1944:
	local[19]= NIL;
primtCON1943:
	goto primtWHL1940;
primtWHX1941:
	local[19]= NIL;
primtBLK1942:
	w = NIL;
	goto primtWHL1937;
primtWHX1938:
	local[17]= NIL;
primtBLK1939:
	local[17]= (pointer)get_sym_func(fqv[58]);
	local[18]= loadglobal(fqv[42]);
	local[19]= fqv[27];
	ctx->vsp=local+20;
	w=(*ftab[10])(ctx,2,local+18,&ftab[10],fqv[59]); /*send-all*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)APPLY(ctx,2,local+17); /*apply*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(*ftab[11])(ctx,1,local+17,&ftab[11],fqv[60]); /*remove-duplicates*/
	local[17]= w;
	storeglobal(fqv[61],w);
	local[17]= (pointer)get_sym_func(fqv[58]);
	local[18]= loadglobal(fqv[42]);
	local[19]= fqv[12];
	ctx->vsp=local+20;
	w=(*ftab[10])(ctx,2,local+18,&ftab[10],fqv[59]); /*send-all*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)APPLY(ctx,2,local+17); /*apply*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(*ftab[11])(ctx,1,local+17,&ftab[11],fqv[60]); /*remove-duplicates*/
	local[17]= w;
	storeglobal(fqv[31],w);
	local[17]= loadglobal(fqv[62]);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,1,local+17); /*instantiate*/
	local[17]= w;
	local[18]= local[17];
	local[19]= fqv[22];
	local[20]= fqv[63];
	local[21]= loadglobal(fqv[42]);
	local[22]= fqv[27];
	local[23]= loadglobal(fqv[61]);
	local[24]= fqv[12];
	local[25]= loadglobal(fqv[31]);
	local[26]= fqv[64];
	local[27]= fqv[65];
	local[28]= loadglobal(fqv[31]);
	ctx->vsp=local+29;
	w=(pointer)LIST(ctx,2,local+27); /*list*/
	local[27]= w;
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,10,local+18); /*send*/
	w = local[17];
	local[17]= w;
	storeglobal(fqv[66],w);
	w = local[17];
	local[0]= w;
primtBLK1931:
	ctx->vsp=local; return(local[0]);}

/*rotate-vertices*/
static pointer primtF1774rotate_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)SUB1(ctx,1,local+4); /*1-*/
	local[4]= w;
primtWHL1969:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto primtWHX1970;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= local[2];
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(pointer)ROTVEC(ctx,3,local+5); /*rotate-vector*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	local[5]= w;
	w = local[0];
	ctx->vsp=local+6;
	local[0] = cons(ctx,local[5],w);
	local[5]= local[2];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[2] = w;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto primtWHL1969;
primtWHX1970:
	local[5]= NIL;
primtBLK1971:
	w = NIL;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	local[0]= w;
primtBLK1968:
	ctx->vsp=local; return(local[0]);}

/*make-side-faces*/
static pointer primtF1775make_side_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto primtENT1974;}
	local[0]= NIL;
primtENT1974:
primtENT1973:
	if (n>3) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= makeint((eusinteger_t)0L);
primtWHL1975:
	if (argv[1]==NIL) goto primtWHX1976;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[1] = (w)->c.cons.cdr;
	w = local[10];
	local[4] = w;
	if (argv[1]==NIL) goto primtIF1978;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	goto primtIF1979;
primtIF1978:
	local[10]= local[2];
primtIF1979:
	local[5] = local[10];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[10];
	local[7] = w;
	if (argv[0]==NIL) goto primtIF1980;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	goto primtIF1981;
primtIF1980:
	local[10]= local[1];
primtIF1981:
	local[6] = local[10];
	local[10]= local[4];
	local[11]= local[5];
	local[12]= local[6];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,4,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)primtF1766make_face_from_vertices(ctx,1,local+10); /*make-face-from-vertices*/
	local[8] = w;
	local[10]= local[8];
	local[11]= fqv[67];
	if (local[0]==NIL) goto primtIF1982;
	local[12]= fqv[68];
	local[13]= local[0];
	local[14]= local[9];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,3,local+12); /*list*/
	local[12]= w;
	goto primtIF1983;
primtIF1982:
	local[12]= fqv[68];
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,2,local+12); /*list*/
	local[12]= w;
primtIF1983:
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= local[9];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[9] = w;
	local[10]= local[8];
	w = local[3];
	ctx->vsp=local+11;
	local[3] = cons(ctx,local[10],w);
	goto primtWHL1975;
primtWHX1976:
	local[10]= NIL;
primtBLK1977:
	w = local[3];
	local[0]= w;
primtBLK1972:
	ctx->vsp=local; return(local[0]);}

/*make-prism*/
static pointer primtF1776make_prism(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
primtRST1985:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[69], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto primtKEY1986;
	local[2]= fqv[70];
	local[3]= argv[0];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,3,local+2); /*list*/
	local[1] = w;
primtKEY1986:
	w = argv[1];
	if (!isnum(w)) goto primtIF1987;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	argv[1] = w;
	local[2]= argv[1];
	goto primtIF1988;
primtIF1987:
	local[2]= NIL;
primtIF1988:
	local[2]= (pointer)get_sym_func(fqv[40]);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,primtCLO1989,env,argv,local);
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	local[4]= NIL;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)NREVERSE(ctx,1,local+5); /*nreverse*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)primtF1766make_face_from_vertices(ctx,1,local+5); /*make-face-from-vertices*/
	local[5]= w;
	w = local[4];
	ctx->vsp=local+6;
	local[4] = cons(ctx,local[5],w);
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[67];
	local[7]= fqv[71];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= local[4];
	local[6]= local[3];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)REVERSE(ctx,1,local+7); /*reverse*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)primtF1775make_side_faces(ctx,2,local+6); /*make-side-faces*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)NCONC(ctx,2,local+5); /*nconc*/
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)primtF1766make_face_from_vertices(ctx,1,local+5); /*make-face-from-vertices*/
	local[5]= w;
	w = local[4];
	ctx->vsp=local+6;
	local[4] = cons(ctx,local[5],w);
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[67];
	local[7]= fqv[72];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= (pointer)get_sym_func(fqv[73]);
	local[6]= loadglobal(fqv[62]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= fqv[22];
	local[8]= fqv[63];
	local[9]= local[4];
	local[10]= fqv[74];
	local[11]= T;
	local[12]= fqv[64];
	local[13]= local[1];
	local[14]= local[0];
	ctx->vsp=local+15;
	w=(pointer)APPLY(ctx,10,local+5); /*apply*/
	local[0]= w;
primtBLK1984:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer primtCLO1989(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env1[1];
	ctx->vsp=local+2;
	w=(pointer)VPLUS(ctx,2,local+0); /*v+*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*make-conic-side-faces*/
static pointer primtF1777make_conic_side_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto primtENT1992;}
	local[0]= NIL;
primtENT1992:
primtENT1991:
	if (n>3) maerror();
	local[1]= NIL;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= makeint((eusinteger_t)0L);
primtWHL1993:
	if (argv[1]==NIL) goto primtWHX1994;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[1] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	local[5]= argv[0];
	if (argv[1]==NIL) goto primtIF1996;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	goto primtIF1997;
primtIF1996:
	local[6]= local[2];
primtIF1997:
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,3,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)primtF1766make_face_from_vertices(ctx,1,local+4); /*make-face-from-vertices*/
	local[4]= w;
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= fqv[67];
	if (local[0]==NIL) goto primtIF1998;
	local[6]= fqv[68];
	local[7]= local[0];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,3,local+6); /*list*/
	local[6]= w;
	goto primtIF1999;
primtIF1998:
	local[6]= fqv[68];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
primtIF1999:
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[3] = w;
	goto primtWHL1993;
primtWHX1994:
	local[4]= NIL;
primtBLK1995:
	w = local[1];
	local[0]= w;
primtBLK1990:
	ctx->vsp=local; return(local[0]);}

/*make-cone*/
static pointer primtF1778make_cone(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
primtRST2001:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[75], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto primtKEY2002;
	local[1] = makeint((eusinteger_t)16L);
primtKEY2002:
	if (n & (1<<1)) goto primtKEY2003;
	local[2] = NIL;
primtKEY2003:
	if (n & (1<<2)) goto primtKEY2004;
	local[3] = NIL;
primtKEY2004:
	local[4]= NIL;
	local[5]= NIL;
	w = argv[1];
	if (!isnum(w)) goto primtIF2005;
	local[6]= argv[1];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
	local[7]= local[1];
	local[8]= makeflt(6.2831853071795862319959e+00);
	local[9]= fqv[76];
	ctx->vsp=local+10;
	w=(pointer)primtF1774rotate_vertices(ctx,4,local+6); /*rotate-vertices*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)NREVERSE(ctx,1,local+6); /*nreverse*/
	argv[1] = w;
	local[6]= argv[1];
	goto primtIF2006;
primtIF2005:
	local[6]= (pointer)get_sym_func(fqv[40]);
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	argv[1] = w;
	local[6]= argv[1];
primtIF2006:
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)primtF1766make_face_from_vertices(ctx,1,local+6); /*make-face-from-vertices*/
	local[5] = w;
	local[6]= local[5];
	local[7]= fqv[67];
	local[8]= fqv[72];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= (pointer)get_sym_func(fqv[73]);
	local[7]= loadglobal(fqv[62]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= fqv[22];
	local[9]= fqv[63];
	local[10]= local[5];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	local[11]= w;
	local[12]= argv[1];
	ctx->vsp=local+13;
	w=(pointer)primtF1777make_conic_side_faces(ctx,2,local+11); /*make-conic-side-faces*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[74];
	local[12]= T;
	local[13]= fqv[64];
	local[14]= fqv[77];
	local[15]= fqv[71];
	local[16]= (pointer)get_sym_func(fqv[28]);
	local[17]= argv[1];
	ctx->vsp=local+18;
	w=(pointer)MAPCAR(ctx,2,local+16); /*mapcar*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,3,local+14); /*list*/
	local[14]= w;
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(pointer)APPLY(ctx,10,local+6); /*apply*/
	local[0]= w;
primtBLK2000:
	ctx->vsp=local; return(local[0]);}

/*on-z-axis-p*/
static pointer primtF2007(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[2];
	local[1]= fqv[78];
	local[2]= fqv[79];
	local[3]= argv[0];
	local[4]= fqv[80];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[81];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
primtBLK2008:
	ctx->vsp=local; return(local[0]);}

/*make-solid-of-revolution*/
static pointer primtF1779make_solid_of_revolution(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
primtRST2010:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[82], &argv[1], n-1, local+1, 1);
	if (n & (1<<0)) goto primtKEY2011;
	local[1] = makeint((eusinteger_t)16L);
primtKEY2011:
	local[2]= (pointer)get_sym_func(fqv[40]);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= makeint((eusinteger_t)0L);
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,2,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ABS(ctx,1,local+7); /*abs*/
	local[7]= w;
	local[8]= makeflt(1.0000000000000000208167e-03);
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w!=NIL) goto primtIF2012;
	local[7]= local[3];
	local[8]= local[1];
	local[9]= makeflt(6.2831853071795862319959e+00);
	local[10]= fqv[76];
	ctx->vsp=local+11;
	w=(pointer)primtF1774rotate_vertices(ctx,4,local+7); /*rotate-vertices*/
	local[3] = w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)primtF1766make_face_from_vertices(ctx,1,local+7); /*make-face-from-vertices*/
	local[5] = w;
	local[7]= local[5];
	local[8]= fqv[67];
	local[9]= fqv[72];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	goto primtIF2013;
primtIF2012:
	local[7]= NIL;
primtIF2013:
primtWHL2014:
	if (local[2]==NIL) goto primtWHX2015;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[7];
	local[4] = w;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,2,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ABS(ctx,1,local+7); /*abs*/
	local[7]= w;
	local[8]= makeflt(1.0000000000000000208167e-03);
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w!=NIL) goto primtIF2017;
	local[7]= local[4];
	local[8]= local[1];
	local[9]= makeflt(6.2831853071795862319959e+00);
	local[10]= fqv[76];
	ctx->vsp=local+11;
	w=(pointer)primtF1774rotate_vertices(ctx,4,local+7); /*rotate-vertices*/
	local[4] = w;
	local[7]= local[4];
	goto primtIF2018;
primtIF2017:
	local[7]= NIL;
primtIF2018:
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr!=NIL) goto primtCON2020;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr!=NIL) goto primtIF2021;
	local[7]= fqv[83];
	ctx->vsp=local+8;
	w=(pointer)SIGERROR(ctx,1,local+7); /*error*/
	local[7]= w;
	goto primtIF2022;
primtIF2021:
	local[7]= NIL;
primtIF2022:
	local[7]= local[4];
	local[8]= local[3];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)primtF1777make_conic_side_faces(ctx,3,local+7); /*make-conic-side-faces*/
	local[7]= w;
	w = local[5];
	ctx->vsp=local+8;
	local[5] = cons(ctx,local[7],w);
	local[7]= local[5];
	goto primtCON2019;
primtCON2020:
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr!=NIL) goto primtCON2023;
	local[7]= local[3];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)REVERSE(ctx,1,local+8); /*reverse*/
	local[8]= w;
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)primtF1777make_conic_side_faces(ctx,3,local+7); /*make-conic-side-faces*/
	local[7]= w;
	w = local[5];
	ctx->vsp=local+8;
	local[5] = cons(ctx,local[7],w);
	local[7]= local[5];
	goto primtCON2019;
primtCON2023:
	local[7]= local[3];
	local[8]= local[4];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)primtF1775make_side_faces(ctx,3,local+7); /*make-side-faces*/
	local[7]= w;
	w = local[5];
	ctx->vsp=local+8;
	local[5] = cons(ctx,local[7],w);
	local[7]= local[5];
	goto primtCON2019;
primtCON2024:
	local[7]= NIL;
primtCON2019:
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[6] = w;
	local[3] = local[4];
	goto primtWHL2014;
primtWHX2015:
	local[7]= NIL;
primtBLK2016:
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto primtIF2025;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)LISTP(ctx,1,local+7); /*listp*/
	if (w==NIL) goto primtIF2025;
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)REVERSE(ctx,1,local+7); /*reverse*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)primtF1766make_face_from_vertices(ctx,1,local+7); /*make-face-from-vertices*/
	local[7]= w;
	w = local[5];
	ctx->vsp=local+8;
	local[5] = cons(ctx,local[7],w);
	local[7]= local[5];
	goto primtIF2026;
primtIF2025:
	local[7]= NIL;
primtIF2026:
	local[7]= (pointer)get_sym_func(fqv[73]);
	local[8]= loadglobal(fqv[62]);
	ctx->vsp=local+9;
	w=(pointer)INSTANTIATE(ctx,1,local+8); /*instantiate*/
	local[8]= w;
	local[9]= fqv[22];
	local[10]= fqv[63];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(*ftab[12])(ctx,1,local+11,&ftab[12],fqv[84]); /*flatten*/
	local[11]= w;
	local[12]= fqv[74];
	local[13]= T;
	local[14]= fqv[64];
	local[15]= fqv[85];
	local[16]= argv[0];
	local[17]= local[1];
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,3,local+15); /*list*/
	local[15]= w;
	local[16]= local[0];
	ctx->vsp=local+17;
	w=(pointer)APPLY(ctx,10,local+7); /*apply*/
	local[0]= w;
primtBLK2009:
	ctx->vsp=local; return(local[0]);}

/*make-torus*/
static pointer primtF1780make_torus(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
primtRST2028:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[86], &argv[1], n-1, local+1, 1);
	if (n & (1<<0)) goto primtKEY2029;
	local[1] = makeint((eusinteger_t)16L);
primtKEY2029:
	local[2]= NIL;
	local[3]= (pointer)get_sym_func(fqv[40]);
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	local[5]= local[1];
	local[6]= makeflt(6.2831853071795862319959e+00);
	local[7]= fqv[76];
	ctx->vsp=local+8;
	w=(pointer)primtF1774rotate_vertices(ctx,4,local+4); /*rotate-vertices*/
	local[4]= w;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= makeint((eusinteger_t)0L);
	local[5] = local[4];
primtWHL2030:
	if (local[3]==NIL) goto primtWHX2031;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[8];
	local[8]= w;
	local[9]= local[1];
	local[10]= makeflt(6.2831853071795862319959e+00);
	local[11]= fqv[76];
	ctx->vsp=local+12;
	w=(pointer)primtF1774rotate_vertices(ctx,4,local+8); /*rotate-vertices*/
	local[6] = w;
	local[8]= local[2];
	local[9]= local[5];
	local[10]= local[6];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)primtF1775make_side_faces(ctx,3,local+9); /*make-side-faces*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)NCONC(ctx,2,local+8); /*nconc*/
	local[2] = w;
	local[8]= local[7];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[7] = w;
	local[5] = local[6];
	goto primtWHL2030;
primtWHX2031:
	local[8]= NIL;
primtBLK2032:
	local[8]= local[2];
	local[9]= local[6];
	local[10]= local[4];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)primtF1775make_side_faces(ctx,3,local+9); /*make-side-faces*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)NCONC(ctx,2,local+8); /*nconc*/
	local[8]= (pointer)get_sym_func(fqv[73]);
	local[9]= loadglobal(fqv[62]);
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= fqv[22];
	local[11]= fqv[63];
	local[12]= local[2];
	local[13]= fqv[64];
	local[14]= fqv[87];
	local[15]= argv[0];
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,3,local+14); /*list*/
	local[14]= w;
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(pointer)APPLY(ctx,8,local+8); /*apply*/
	local[0]= w;
primtBLK2027:
	ctx->vsp=local; return(local[0]);}

/*make-cylinder*/
static pointer primtF1781make_cylinder(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
primtRST2034:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[88], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto primtKEY2035;
	local[1] = makeint((eusinteger_t)12L);
primtKEY2035:
	if (n & (1<<1)) goto primtKEY2036;
	local[2] = NIL;
primtKEY2036:
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)EUSFLOAT(ctx,1,local+3); /*float*/
	argv[0] = w;
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)EUSFLOAT(ctx,1,local+3); /*float*/
	argv[1] = w;
	local[3]= makeflt(6.2831853071795862319959e+00);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	if (local[2]==NIL) goto primtIF2037;
	local[4]= argv[0];
	local[5]= local[3];
	local[6]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)COS(ctx,1,local+5); /*cos*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	goto primtIF2038;
primtIF2037:
	local[4]= argv[0];
primtIF2038:
	local[5]= local[4];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	local[6]= local[5];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
	local[7]= NIL;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SUB1(ctx,1,local+9); /*1-*/
	local[9]= w;
primtWHL2039:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto primtWHX2040;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= local[3];
	local[12]= fqv[76];
	ctx->vsp=local+13;
	w=(pointer)ROTVEC(ctx,3,local+10); /*rotate-vector*/
	local[10]= w;
	w = local[6];
	ctx->vsp=local+11;
	local[6] = cons(ctx,local[10],w);
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto primtWHL2039;
primtWHX2040:
	local[10]= NIL;
primtBLK2041:
	w = NIL;
	local[8]= (pointer)get_sym_func(fqv[89]);
	local[9]= local[6];
	local[10]= argv[1];
	local[11]= fqv[64];
	local[12]= fqv[90];
	local[13]= local[4];
	local[14]= argv[1];
	local[15]= local[1];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,4,local+12); /*list*/
	local[12]= w;
	local[13]= local[0];
	ctx->vsp=local+14;
	w=(pointer)APPLY(ctx,6,local+8); /*apply*/
	local[7] = w;
	local[8]= local[7];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	local[12]= argv[1];
	ctx->vsp=local+13;
	w=(pointer)MKFLTVEC(ctx,3,local+10); /*float-vector*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[13])(ctx,2,local+9,&ftab[13],fqv[91]); /*make-line*/
	local[9]= w;
	local[10]= fqv[92];
	ctx->vsp=local+11;
	w=(pointer)PUTPROP(ctx,3,local+8); /*putprop*/
	w = local[7];
	local[0]= w;
primtBLK2033:
	ctx->vsp=local; return(local[0]);}

/*make-cube*/
static pointer primtF1782make_cube(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
primtRST2043:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)EUSFLOAT(ctx,1,local+1); /*float*/
	argv[0] = w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)EUSFLOAT(ctx,1,local+1); /*float*/
	argv[1] = w;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)EUSFLOAT(ctx,1,local+1); /*float*/
	argv[2] = w;
	local[1]= argv[0];
	local[2]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	local[2]= argv[1];
	local[3]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,1,local+3); /*-*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= local[1];
	local[10]= local[2];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[4] = w;
	local[9]= local[1];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,1,local+10); /*-*/
	local[10]= w;
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[5] = w;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[9]= w;
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,1,local+10); /*-*/
	local[10]= w;
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[6] = w;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[9]= w;
	local[10]= local[2];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[7] = w;
	local[9]= (pointer)get_sym_func(fqv[89]);
	local[10]= local[4];
	local[11]= local[5];
	local[12]= local[6];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,4,local+10); /*list*/
	local[10]= w;
	local[11]= argv[2];
	local[12]= fqv[64];
	local[13]= fqv[93];
	local[14]= argv[0];
	local[15]= argv[1];
	local[16]= argv[2];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,4,local+13); /*list*/
	local[13]= w;
	local[14]= local[0];
	ctx->vsp=local+15;
	w=(pointer)APPLY(ctx,6,local+9); /*apply*/
	local[8] = w;
	local[9]= NIL;
	local[10]= local[8];
	local[11]= fqv[94];
	local[12]= NIL;
	local[13]= fqv[68];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,4,local+10); /*send*/
	local[10]= w;
primtWHL2044:
	if (local[10]==NIL) goto primtWHX2045;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	local[11]= local[9];
	local[12]= fqv[67];
	local[13]= local[9];
	local[14]= fqv[67];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)1L);
	local[15]= local[9];
	local[16]= fqv[67];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)NTH(ctx,2,local+14); /*nth*/
	local[14]= w;
	local[15]= fqv[95];
	ctx->vsp=local+16;
	w=(pointer)NTH(ctx,2,local+14); /*nth*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)APPEND(ctx,2,local+13); /*append*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	goto primtWHL2044;
primtWHX2045:
	local[11]= NIL;
primtBLK2046:
	w = NIL;
	w = local[8];
	local[0]= w;
primtBLK2042:
	ctx->vsp=local; return(local[0]);}

/*icosahedron-points*/
static pointer primtF1783icosahedron_points(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto primtENT2049;}
	local[0]= makeflt(1.0000000000000000000000e+00);
primtENT2049:
primtENT2048:
	if (n>1) maerror();
	local[1]= makeflt(1.0000000000000000000000e+00);
	local[2]= makeflt(5.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)SQRT(ctx,1,local+2); /*sqrt*/
	{ double x,y;
		y=fltval(w); x=fltval(local[1]);
		local[1]=(makeflt(x + y));}
	local[2]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	local[2]= local[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)SQRT(ctx,1,local+3); /*sqrt*/
	local[3]= w;
	local[4]= makeflt(5.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)SQRT(ctx,1,local+4); /*sqrt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SQRT(ctx,1,local+4); /*sqrt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= local[0];
	local[4]= makeflt(1.0000000000000000000000e+00);
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SQRT(ctx,1,local+5); /*sqrt*/
	local[5]= w;
	local[6]= makeflt(5.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)SQRT(ctx,1,local+6); /*sqrt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SQRT(ctx,1,local+6); /*sqrt*/
	{ double x,y;
		y=fltval(w); x=fltval(local[5]);
		local[5]=(makeflt(x * y));}
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[2];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[2];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	local[8]= local[3];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
	local[9]= local[3];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,1,local+11); /*-*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[9]= w;
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,1,local+10); /*-*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)0L);
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)MKFLTVEC(ctx,3,local+10); /*float-vector*/
	local[10]= w;
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,1,local+11); /*-*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,1,local+13); /*-*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	local[12]= local[2];
	local[13]= local[3];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)MKFLTVEC(ctx,3,local+12); /*float-vector*/
	local[12]= w;
	local[13]= local[2];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,1,local+14); /*-*/
	local[14]= w;
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)MKFLTVEC(ctx,3,local+13); /*float-vector*/
	local[13]= w;
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,1,local+14); /*-*/
	local[14]= w;
	local[15]= local[3];
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[14]= w;
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)MINUS(ctx,1,local+15); /*-*/
	local[15]= w;
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(pointer)MINUS(ctx,1,local+16); /*-*/
	local[16]= w;
	local[17]= makeint((eusinteger_t)0L);
	ctx->vsp=local+18;
	w=(pointer)MKFLTVEC(ctx,3,local+15); /*float-vector*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,12,local+4); /*list*/
	local[0]= w;
primtBLK2047:
	ctx->vsp=local; return(local[0]);}

/*make-icosahedron*/
static pointer primtF1784make_icosahedron(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto primtENT2052;}
	local[0]= makeflt(1.0000000000000000000000e+00);
primtENT2052:
primtENT2051:
	if (n>1) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)primtF1783icosahedron_points(ctx,1,local+3); /*icosahedron-points*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)primtF1773convex_hull_3d(ctx,1,local+3); /*convex-hull-3d*/
	local[2] = w;
	local[3]= local[2];
	local[4]= fqv[96];
	local[5]= fqv[97];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,2,local+5); /*list*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	w = local[2];
	local[0]= w;
primtBLK2050:
	ctx->vsp=local; return(local[0]);}

/*subdivide-facet*/
static pointer primtF1785subdivide_facet(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[2] = w;
	local[3]= (pointer)get_sym_func(fqv[8]);
	local[4]= (pointer)get_sym_func(fqv[28]);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,2,local+3); /*apply*/
	local[3]= w;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)VINNERPRODUCT(ctx,2,local+3); /*v.*/
	local[3]= w;
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[3]);
	if (left >= right) goto primtIF2054;}
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[2] = w;
	local[3]= local[2];
	goto primtIF2055;
primtIF2054:
	local[3]= NIL;
primtIF2055:
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)primtF1766make_face_from_vertices(ctx,1,local+3); /*make-face-from-vertices*/
	local[3]= w;
	w = local[1];
	ctx->vsp=local+4;
	local[1] = cons(ctx,local[3],w);
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[2] = w;
	local[3]= (pointer)get_sym_func(fqv[8]);
	local[4]= (pointer)get_sym_func(fqv[28]);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,2,local+3); /*apply*/
	local[3]= w;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)VINNERPRODUCT(ctx,2,local+3); /*v.*/
	local[3]= w;
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[3]);
	if (left >= right) goto primtIF2056;}
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[2] = w;
	local[3]= local[2];
	goto primtIF2057;
primtIF2056:
	local[3]= NIL;
primtIF2057:
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)primtF1766make_face_from_vertices(ctx,1,local+3); /*make-face-from-vertices*/
	local[3]= w;
	w = local[1];
	ctx->vsp=local+4;
	local[1] = cons(ctx,local[3],w);
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[2] = w;
	local[3]= (pointer)get_sym_func(fqv[8]);
	local[4]= (pointer)get_sym_func(fqv[28]);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,2,local+3); /*apply*/
	local[3]= w;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)VINNERPRODUCT(ctx,2,local+3); /*v.*/
	local[3]= w;
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[3]);
	if (left >= right) goto primtIF2058;}
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[2] = w;
	local[3]= local[2];
	goto primtIF2059;
primtIF2058:
	local[3]= NIL;
primtIF2059:
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)primtF1766make_face_from_vertices(ctx,1,local+3); /*make-face-from-vertices*/
	local[3]= w;
	w = local[1];
	ctx->vsp=local+4;
	local[1] = cons(ctx,local[3],w);
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[2] = w;
	local[3]= (pointer)get_sym_func(fqv[8]);
	local[4]= (pointer)get_sym_func(fqv[28]);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,2,local+3); /*apply*/
	local[3]= w;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)VINNERPRODUCT(ctx,2,local+3); /*v.*/
	local[3]= w;
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[3]);
	if (left >= right) goto primtIF2060;}
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[2] = w;
	local[3]= local[2];
	goto primtIF2061;
primtIF2060:
	local[3]= NIL;
primtIF2061:
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)primtF1766make_face_from_vertices(ctx,1,local+3); /*make-face-from-vertices*/
	local[3]= w;
	w = local[1];
	ctx->vsp=local+4;
	local[1] = cons(ctx,local[3],w);
	w = local[1];
	local[0]= w;
primtBLK2053:
	ctx->vsp=local; return(local[0]);}

/*make-dodecahedron*/
static pointer primtF1786make_dodecahedron(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto primtENT2064;}
	local[0]= makeflt(1.0000000000000000000000e+00);
primtENT2064:
primtENT2063:
	if (n>1) maerror();
	ctx->vsp=local+1;
	w=(pointer)primtF1784make_icosahedron(ctx,0,local+1); /*make-icosahedron*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= local[1]->c.obj.iv[9];
primtWHL2065:
	if (local[6]==NIL) goto primtWHX2066;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	w=local[5]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
	ctx->vsp=local+8;
	w=(*ftab[14])(ctx,1,local+7,&ftab[14],fqv[98]); /*vector-mean*/
	local[2] = w;
	local[7]= local[0];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)VNORM(ctx,1,local+8); /*norm*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	local[8]= local[2];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,3,local+7); /*scale*/
	local[7]= local[2];
	w = local[3];
	ctx->vsp=local+8;
	local[3] = cons(ctx,local[7],w);
	goto primtWHL2065;
primtWHX2066:
	local[7]= NIL;
primtBLK2067:
	w = NIL;
	local[5]= local[3];
	storeglobal(fqv[99],local[5]);
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)primtF1773convex_hull_3d(ctx,1,local+5); /*convex-hull-3d*/
	local[4] = w;
	local[5]= local[4];
	local[6]= fqv[96];
	local[7]= fqv[100];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	w = local[4];
	local[0]= w;
primtBLK2062:
	ctx->vsp=local; return(local[0]);}

/*make-gdome*/
static pointer primtF1787make_gdome(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[101];
	local[1]= (pointer)get_sym_func(fqv[102]);
	ctx->vsp=local+2;
	w=(*ftab[15])(ctx,2,local+0,&ftab[15],fqv[103]); /*make-hash-table*/
	local[0]= w;
	local[1]= fqv[101];
	local[2]= (pointer)get_sym_func(fqv[102]);
	ctx->vsp=local+3;
	w=(*ftab[15])(ctx,2,local+1,&ftab[15],fqv[103]); /*make-hash-table*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	w=*(ovafptr(argv[0],fqv[104]));
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)VNORM(ctx,1,local+7); /*norm*/
	local[7]= w;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= *(ovafptr(argv[0],fqv[104]));
primtWHL2069:
	if (local[10]==NIL) goto primtWHX2070;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	local[11]= local[9];
	local[12]= local[0];
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)COPYOBJ(ctx,1,local+13); /*copy-object*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[16])(ctx,3,local+11,&ftab[16],fqv[105]); /*sethash*/
	goto primtWHL2069;
primtWHX2070:
	local[11]= NIL;
primtBLK2071:
	w = NIL;
	local[9]= NIL;
	local[10]= *(ovafptr(argv[0],fqv[106]));
primtWHL2072:
	if (local[10]==NIL) goto primtWHX2073;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	local[11]= local[7];
	local[12]= *(ovafptr(local[9],fqv[107]));
	local[13]= *(ovafptr(local[9],fqv[108]));
	ctx->vsp=local+14;
	w=(pointer)VPLUS(ctx,2,local+12); /*v+*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)VNORMALIZE(ctx,1,local+12); /*normalize-vector*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SCALEVEC(ctx,2,local+11); /*scale*/
	local[4] = w;
	local[11]= local[9];
	local[12]= local[1];
	local[13]= local[9];
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(*ftab[16])(ctx,3,local+11,&ftab[16],fqv[105]); /*sethash*/
	goto primtWHL2072;
primtWHX2073:
	local[11]= NIL;
primtBLK2074:
	w = NIL;
	local[9]= NIL;
	local[10]= *(ovafptr(argv[0],fqv[109]));
primtWHL2075:
	if (local[10]==NIL) goto primtWHX2076;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	local[4] = *(ovafptr(local[9],fqv[104]));
	local[5] = *(ovafptr(local[9],fqv[106]));
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(*ftab[17])(ctx,2,local+11,&ftab[17],fqv[110]); /*gethash*/
	local[11]= w;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= local[0];
	ctx->vsp=local+14;
	w=(*ftab[17])(ctx,2,local+12,&ftab[17],fqv[110]); /*gethash*/
	local[12]= w;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= local[0];
	ctx->vsp=local+15;
	w=(*ftab[17])(ctx,2,local+13,&ftab[17],fqv[110]); /*gethash*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,3,local+11); /*list*/
	local[2] = w;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(*ftab[17])(ctx,2,local+11,&ftab[17],fqv[110]); /*gethash*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.cdr;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= local[1];
	ctx->vsp=local+14;
	w=(*ftab[17])(ctx,2,local+12,&ftab[17],fqv[110]); /*gethash*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.cdr;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= local[1];
	ctx->vsp=local+15;
	w=(*ftab[17])(ctx,2,local+13,&ftab[17],fqv[110]); /*gethash*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.cdr;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,3,local+11); /*list*/
	local[3] = w;
	local[11]= *(ovafptr(local[9],fqv[111]));
	local[12]= local[2];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)primtF1785subdivide_facet(ctx,3,local+11); /*subdivide-facet*/
	local[11]= w;
	w = local[6];
	ctx->vsp=local+12;
	local[6] = cons(ctx,local[11],w);
	goto primtWHL2075;
primtWHX2076:
	local[11]= NIL;
primtBLK2077:
	w = NIL;
	local[9]= loadglobal(fqv[62]);
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= fqv[22];
	local[12]= fqv[63];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(*ftab[12])(ctx,1,local+13,&ftab[12],fqv[84]); /*flatten*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,4,local+10); /*send*/
	w = local[9];
	local[8] = w;
	local[9]= local[8];
	local[10]= fqv[96];
	local[11]= fqv[112];
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,2,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	w = local[8];
	local[0]= w;
primtBLK2068:
	ctx->vsp=local; return(local[0]);}

/*make-body-from-vertices*/
static pointer primtF1788make_body_from_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto primtENT2080;}
	local[0]= loadglobal(fqv[62]);
primtENT2080:
primtENT2079:
	if (n>2) maerror();
	local[1]= (pointer)get_sym_func(fqv[40]);
	local[2]= (pointer)get_sym_func(fqv[58]);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,2,local+2); /*apply*/
	local[2]= w;
	local[3]= fqv[101];
	local[4]= (pointer)get_sym_func(fqv[102]);
	ctx->vsp=local+5;
	w=(*ftab[11])(ctx,3,local+2,&ftab[11],fqv[60]); /*remove-duplicates*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[0];
primtWHL2081:
	if (local[5]==NIL) goto primtWHX2082;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= local[4];
primtWHL2084:
	if (local[8]==NIL) goto primtWHX2085;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= local[7];
	local[10]= local[1];
	local[11]= fqv[101];
	local[12]= (pointer)get_sym_func(fqv[102]);
	ctx->vsp=local+13;
	w=(*ftab[18])(ctx,4,local+9,&ftab[18],fqv[113]); /*assoc*/
	local[9]= w;
	w = local[6];
	ctx->vsp=local+10;
	local[6] = cons(ctx,local[9],w);
	goto primtWHL2084;
primtWHX2085:
	local[9]= NIL;
primtBLK2086:
	w = NIL;
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)NREVERSE(ctx,1,local+7); /*nreverse*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)primtF1766make_face_from_vertices(ctx,1,local+7); /*make-face-from-vertices*/
	local[7]= w;
	w = local[2];
	ctx->vsp=local+8;
	local[2] = cons(ctx,local[7],w);
	w = local[2];
	goto primtWHL2081;
primtWHX2082:
	local[6]= NIL;
primtBLK2083:
	w = NIL;
	local[4]= loadglobal(fqv[62]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= local[4];
	local[6]= fqv[22];
	local[7]= fqv[63];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)NREVERSE(ctx,1,local+8); /*nreverse*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	w = local[4];
	local[3] = w;
	local[4]= local[3];
	local[5]= fqv[96];
	local[6]= fqv[114];
	w = argv[0];
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	w = local[3];
	local[0]= w;
primtBLK2078:
	ctx->vsp=local; return(local[0]);}

/*:update*/
static pointer primtM2087coordinates_axes_update(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[7] = NIL;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
primtWHL2089:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto primtWHX2090;
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+4;
	w=(pointer)NTH(ctx,2,local+2); /*nth*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[115];
	local[5]= local[0];
	local[6]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+7;
	w=(pointer)NTH(ctx,2,local+5); /*nth*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[19])(ctx,2,local+2,&ftab[19],fqv[116]); /*replace*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto primtWHL2089;
primtWHX2090:
	local[2]= NIL;
primtBLK2091:
	w = NIL;
	local[0]= w;
primtBLK2088:
	ctx->vsp=local; return(local[0]);}

/*:magnify*/
static pointer primtM2092coordinates_axes_magnify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
primtWHL2094:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto primtWHX2095;
	local[2]= argv[2];
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+5;
	w=(pointer)NTH(ctx,2,local+3); /*nth*/
	local[3]= w;
	local[4]= local[0];
	local[5]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+6;
	w=(pointer)NTH(ctx,2,local+4); /*nth*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,3,local+2); /*scale*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto primtWHL2094;
primtWHX2095:
	local[2]= NIL;
primtBLK2096:
	w = NIL;
	local[0]= argv[0];
	local[1]= fqv[117];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = argv[0];
	local[0]= w;
primtBLK2093:
	ctx->vsp=local; return(local[0]);}

/*:drawners*/
static pointer primtM2097coordinates_axes_drawners(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[11];
	local[0]= w;
primtBLK2098:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer primtM2099coordinates_axes_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
primtRST2101:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	argv[0]->c.obj.iv[10] = NIL;
	argv[0]->c.obj.iv[11] = NIL;
	argv[0]->c.obj.iv[8] = argv[2];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	w = argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[10] = cons(ctx,local[1],w);
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	w = argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[10] = cons(ctx,local[1],w);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	w = argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[10] = cons(ctx,local[1],w);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	w = argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[10] = cons(ctx,local[1],w);
	local[1]= argv[2];
	local[2]= makeflt(5.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[2];
	local[4]= makeflt(7.9999999999999982236432e-01);
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	w = argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[10] = cons(ctx,local[1],w);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[2];
	local[3]= makeflt(5.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= makeflt(7.9999999999999982236432e-01);
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	w = argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[10] = cons(ctx,local[1],w);
	local[1]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	w=(pointer)NREVERSE(ctx,1,local+1); /*nreverse*/
	argv[0]->c.obj.iv[10] = w;
	local[1]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	w=(pointer)COPYOBJ(ctx,1,local+1); /*copy-object*/
	argv[0]->c.obj.iv[9] = w;
	w=argv[0]->c.obj.iv[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(*ftab[13])(ctx,2,local+1,&ftab[13],fqv[91]); /*make-line*/
	local[1]= w;
	w = argv[0]->c.obj.iv[11];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[11] = cons(ctx,local[1],w);
	w=argv[0]->c.obj.iv[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(*ftab[13])(ctx,2,local+1,&ftab[13],fqv[91]); /*make-line*/
	local[1]= w;
	w = argv[0]->c.obj.iv[11];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[11] = cons(ctx,local[1],w);
	w=argv[0]->c.obj.iv[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+3;
	w=(*ftab[20])(ctx,1,local+2,&ftab[20],fqv[118]); /*fourth*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[13])(ctx,2,local+1,&ftab[13],fqv[91]); /*make-line*/
	local[1]= w;
	w = argv[0]->c.obj.iv[11];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[11] = cons(ctx,local[1],w);
	local[1]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,1,local+1,&ftab[20],fqv[118]); /*fourth*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+3;
	w=(*ftab[21])(ctx,1,local+2,&ftab[21],fqv[119]); /*fifth*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[13])(ctx,2,local+1,&ftab[13],fqv[91]); /*make-line*/
	local[1]= w;
	w = argv[0]->c.obj.iv[11];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[11] = cons(ctx,local[1],w);
	local[1]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,1,local+1,&ftab[20],fqv[118]); /*fourth*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+3;
	w=(*ftab[22])(ctx,1,local+2,&ftab[22],fqv[120]); /*sixth*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[13])(ctx,2,local+1,&ftab[13],fqv[91]); /*make-line*/
	local[1]= w;
	w = argv[0]->c.obj.iv[11];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[11] = cons(ctx,local[1],w);
	local[1]= (pointer)get_sym_func(fqv[121]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[122]));
	local[4]= fqv[22];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	w = argv[0];
	local[0]= w;
primtBLK2100:
	ctx->vsp=local; return(local[0]);}

/*assoc-coordinates-axes*/
static pointer primtF1789assoc_coordinates_axes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto primtENT2105;}
	local[0]= makeint((eusinteger_t)1L);
primtENT2105:
	if (n>=3) { local[1]=(argv[2]); goto primtENT2104;}
	ctx->vsp=local+1;
	w=(*ftab[23])(ctx,0,local+1,&ftab[23],fqv[123]); /*coords*/
	local[1]= w;
primtENT2104:
primtENT2103:
	if (n>3) maerror();
	local[2]= loadglobal(fqv[124]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[22];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	w = local[2];
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[125];
	local[5]= local[2];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	w = local[2];
	local[0]= w;
primtBLK2102:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___primt(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[126];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto primtIF2106;
	local[0]= fqv[127];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[128],w);
	goto primtIF2107;
primtIF2106:
	local[0]= fqv[129];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
primtIF2107:
	local[0]= fqv[130];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[131];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[132],module,primtF1752find_extream,fqv[133]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[134],module,primtF1753leftmost_point,fqv[135]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[136],module,primtF1754rightmost_point,fqv[137]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[138],module,primtF1755left_points,fqv[139]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[140],module,primtF1756right_points,fqv[141]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[142],module,primtF1757quickhull_left,fqv[143]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[144],module,primtF1758quickhull_right,fqv[145]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[146],module,primtF1759quickhull,fqv[147]);
	local[0]= makeflt(1.0000000000000000208167e-03);
	storeglobal(fqv[9],local[0]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[148],module,primtF1760find_coplanar_vertices,fqv[149]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[150],module,primtF1761colinear_p,fqv[151]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[152],module,primtF1762find_colinear_points,fqv[153]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[154],module,primtF1763remove_colinears_from_circuit,fqv[155]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[156],module,primtF1764coplanar_p,fqv[157]);
	local[0]= fqv[13];
	local[1]= fqv[158];
	local[2]= makeflt(-1.0000000000000000000000e+00);
	local[3]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[159];
	local[1]= fqv[158];
	local[2]= makeflt(1.0000000000000000000000e+00);
	local[3]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	local[3]= fqv[14];
	local[4]= fqv[158];
	local[5]= makeflt(0.0000000000000000000000e+00);
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= NIL;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[160],module,primtF1765gift_wrapping,fqv[161]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[162],module,primtF1766make_face_from_vertices,fqv[163]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[164],module,primtF1767make_face_from_coplanar_vertices,fqv[165]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[166],module,primtF1768tangent_foot,fqv[167]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[168],module,primtF1769calc_p2_of_lowest_hull,fqv[169]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[170],module,primtF1770calc_p3_of_lowest_hull,fqv[171]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[172],module,primtF1771find_initial_hull,fqv[173]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[174],module,primtF1772enclosed_vertexp,fqv[175]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[176],module,primtF1773convex_hull_3d,fqv[177]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[178],module,primtF1774rotate_vertices,fqv[179]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[180],module,primtF1775make_side_faces,fqv[181]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[89],module,primtF1776make_prism,fqv[182]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[183],module,primtF1777make_conic_side_faces,fqv[184]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[185],module,primtF1778make_cone,fqv[186]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[187],module,primtF2007,fqv[188]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[189],module,primtF1779make_solid_of_revolution,fqv[190]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[191],module,primtF1780make_torus,fqv[192]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[193],module,primtF1781make_cylinder,fqv[194]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[195],module,primtF1782make_cube,fqv[196]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[197],module,primtF1783icosahedron_points,fqv[198]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[199],module,primtF1784make_icosahedron,fqv[200]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[201],module,primtF1785subdivide_facet,fqv[202]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[203],module,primtF1786make_dodecahedron,fqv[204]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[205],module,primtF1787make_gdome,fqv[206]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[207],module,primtF1788make_body_from_vertices,fqv[208]);
	local[0]= fqv[124];
	local[1]= fqv[158];
	local[2]= fqv[124];
	local[3]= fqv[209];
	local[4]= loadglobal(fqv[210]);
	local[5]= fqv[211];
	local[6]= fqv[212];
	local[7]= fqv[213];
	local[8]= NIL;
	local[9]= fqv[214];
	local[10]= NIL;
	local[11]= fqv[215];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[216];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[24])(ctx,13,local+2,&ftab[24],fqv[217]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,primtM2087coordinates_axes_update,fqv[117],fqv[124],fqv[218]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,primtM2092coordinates_axes_magnify,fqv[219],fqv[124],fqv[220]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,primtM2097coordinates_axes_drawners,fqv[221],fqv[124],fqv[222]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,primtM2099coordinates_axes_init,fqv[22],fqv[124],fqv[223]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[224],module,primtF1789assoc_coordinates_axes,fqv[225]);
	local[0]= fqv[226];
	local[1]= fqv[227];
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,2,local+0,&ftab[25],fqv[228]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<26; i++) ftab[i]=fcallx;
}

/* ./shadow.c :  entry=shadow */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "shadow.h"
#pragma init (register_shadow)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___shadow();
extern pointer build_quote_vector();
static int register_shadow()
  { add_module_initializer("___shadow", ___shadow);}

static pointer shadowF3735polygon_in_contact_p();
static pointer shadowF3736make_edges_from_vertices();
static pointer shadowF3737orthogonally_visible_faces();
static pointer shadowF3738make_polygon();
static pointer shadowF3739make_face_from_edge_loop();
static pointer shadowF3740change_to_hole();
static pointer shadowF3741project_shadow1();
static pointer shadowF3742remove_inner_loop();
static pointer shadowF3743project_shadow();
static pointer shadowF3744shadow_intersection();
static pointer shadowF3745closest_shadow();

/*do-combination*/
static pointer shadowF3746(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
shadowRST3748:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)GENSYM(ctx,1,local+3); /*gensym*/
	local[3]= w;
	local[4]= fqv[1];
	local[5]= local[3];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	local[5]= w;
	local[6]= fqv[2];
	local[7]= fqv[3];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[1];
	local[9]= local[1];
	local[10]= fqv[4];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[9]= w;
	local[10]= fqv[5];
	local[11]= local[2];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	w = local[0];
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	local[0]= w;
shadowBLK3747:
	ctx->vsp=local; return(local[0]);}

/*polygon-in-contact-p*/
static pointer shadowF3735polygon_in_contact_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[6];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= fqv[6];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= NIL;
	local[3]= local[0];
shadowWHL3750:
	if (local[3]==NIL) goto shadowWHX3751;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= NIL;
	local[5]= local[1];
shadowWHL3753:
	if (local[5]==NIL) goto shadowWHX3754;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[2];
	local[7]= fqv[7];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	if (w==NIL) goto shadowIF3756;
	local[6]= local[2];
	local[7]= fqv[8];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	if (w==NIL) goto shadowIF3756;
	w = T;
	ctx->vsp=local+6;
	local[0]=w;
	goto shadowBLK3749;
	goto shadowIF3757;
shadowIF3756:
	local[6]= NIL;
shadowIF3757:
	goto shadowWHL3753;
shadowWHX3754:
	local[6]= NIL;
shadowBLK3755:
	w = NIL;
	goto shadowWHL3750;
shadowWHX3751:
	local[4]= NIL;
shadowBLK3752:
	w = NIL;
	w = NIL;
	local[0]= w;
shadowBLK3749:
	ctx->vsp=local; return(local[0]);}

/*make-edges-from-vertices*/
static pointer shadowF3736make_edges_from_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
shadowWHL3759:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto shadowWHX3760;
	local[2]= loadglobal(fqv[9]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[10];
	local[5]= fqv[11];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[6];
	local[6]= w;
	local[7]= fqv[12];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,6,local+3); /*send*/
	w = local[2];
	local[2]= w;
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
	goto shadowWHL3759;
shadowWHX3760:
	local[2]= NIL;
shadowBLK3761:
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)NREVERSE(ctx,1,local+2); /*nreverse*/
	local[0]= w;
shadowBLK3758:
	ctx->vsp=local; return(local[0]);}

/*orthogonally-visible-faces*/
static pointer shadowF3737orthogonally_visible_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0];
	local[5]= fqv[13];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
shadowWHL3763:
	if (local[4]==NIL) goto shadowWHX3764;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= argv[1];
	local[6]= local[3]->c.obj.iv[1];
	ctx->vsp=local+7;
	w=(pointer)VINNERPRODUCT(ctx,2,local+5); /*v.*/
	local[5]= w;
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(*ftab[0])(ctx,2,local+5,&ftab[0],fqv[14]); /*eps<*/
	if (w==NIL) goto shadowIF3766;
	local[5]= local[3];
	w = local[1];
	ctx->vsp=local+6;
	local[1] = cons(ctx,local[5],w);
	local[5]= local[1];
	goto shadowIF3767;
shadowIF3766:
	local[5]= local[3];
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	local[5]= local[2];
shadowIF3767:
	goto shadowWHL3763;
shadowWHX3764:
	local[5]= NIL;
shadowBLK3765:
	w = NIL;
	local[3]= local[1];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[15]); /*values*/
	local[0]= w;
shadowBLK3762:
	ctx->vsp=local; return(local[0]);}

/*make-polygon*/
static pointer shadowF3738make_polygon(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
shadowRST3769:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= loadglobal(fqv[16]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[10];
	local[4]= fqv[17];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[0]= w;
shadowBLK3768:
	ctx->vsp=local; return(local[0]);}

/*make-face-from-edge-loop*/
static pointer shadowF3739make_face_from_edge_loop(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[18]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= NIL;
	local[2]= argv[0];
shadowWHL3771:
	if (local[2]==NIL) goto shadowWHX3772;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[0];
	local[4]= local[3];
	w = local[1];
	w->c.obj.iv[3] = local[4];
	goto shadowWHL3771;
shadowWHX3772:
	local[3]= NIL;
shadowBLK3773:
	w = NIL;
	local[1]= local[0];
	local[2]= fqv[10];
	local[3]= fqv[19];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
shadowBLK3770:
	ctx->vsp=local; return(local[0]);}

/*change-to-hole*/
static pointer shadowF3740change_to_hole(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[20]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[10];
	local[3]= fqv[17];
	local[4]= argv[0];
	local[5]= fqv[17];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
shadowBLK3774:
	ctx->vsp=local; return(local[0]);}

/*project-shadow1*/
static pointer shadowF3741project_shadow1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
	local[3]= fqv[13];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= NIL;
	w = local[3];
	ctx->vsp=local+3;
	bindspecial(ctx,fqv[21],w);
	local[6]= NIL;
	local[7]= argv[1];
	local[8]= fqv[22];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= local[7];
	ctx->vsp=local+9;
	w=(pointer)VMINUS(ctx,1,local+8); /*v-*/
	local[8]= w;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= NIL;
	local[15]= local[2];
shadowWHL3776:
	if (local[15]==NIL) goto shadowWHX3777;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.cdr;
	w = local[16];
	local[14] = w;
	local[16]= local[7];
	local[17]= local[14]->c.obj.iv[1];
	ctx->vsp=local+18;
	w=(pointer)VINNERPRODUCT(ctx,2,local+16); /*v.*/
	local[16]= w;
	local[17]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+18;
	w=(*ftab[0])(ctx,2,local+16,&ftab[0],fqv[14]); /*eps<*/
	if (w==NIL) goto shadowIF3779;
	local[16]= local[14];
	w = local[0];
	ctx->vsp=local+17;
	local[0] = cons(ctx,local[16],w);
	local[16]= local[0];
	goto shadowIF3780;
shadowIF3779:
	local[16]= local[14];
	w = local[1];
	ctx->vsp=local+17;
	local[1] = cons(ctx,local[16],w);
	local[16]= local[1];
shadowIF3780:
	goto shadowWHL3776;
shadowWHX3777:
	local[16]= NIL;
shadowBLK3778:
	w = NIL;
	local[14]= NIL;
	local[15]= local[0];
shadowWHL3781:
	if (local[15]==NIL) goto shadowWHX3782;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.cdr;
	w = local[16];
	local[14] = w;
	local[16]= NIL;
	local[17]= NIL;
	local[18]= NIL;
	local[19]= NIL;
	local[20]= NIL;
	local[21]= NIL;
	local[22]= local[14];
	local[23]= fqv[17];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,2,local+22); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.cdr;
shadowWHL3784:
	if (local[22]==NIL) goto shadowWHX3785;
	w=local[22];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	w=local[22];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22] = (w)->c.cons.cdr;
	w = local[23];
	local[21] = w;
	local[23]= argv[1];
	local[24]= fqv[23];
	local[25]= local[21];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,3,local+23); /*send*/
	local[23]= w;
	w = local[16];
	ctx->vsp=local+24;
	local[16] = cons(ctx,local[23],w);
	goto shadowWHL3784;
shadowWHX3785:
	local[23]= NIL;
shadowBLK3786:
	w = NIL;
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)NREVERSE(ctx,1,local+21); /*nreverse*/
	local[16] = w;
	local[21]= NIL;
	local[22]= local[14];
	local[23]= fqv[24];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,2,local+22); /*send*/
	local[22]= w;
shadowWHL3787:
	if (local[22]==NIL) goto shadowWHX3788;
	w=local[22];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	w=local[22];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22] = (w)->c.cons.cdr;
	w = local[23];
	local[21] = w;
	local[23]= NIL;
	local[24]= local[21];
	local[25]= fqv[17];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,2,local+24); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[24]= (w)->c.cons.cdr;
shadowWHL3790:
	if (local[24]==NIL) goto shadowWHX3791;
	w=local[24];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[25]= (w)->c.cons.car;
	w=local[24];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[24] = (w)->c.cons.cdr;
	w = local[25];
	local[23] = w;
	local[25]= argv[1];
	local[26]= fqv[23];
	local[27]= local[23];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,3,local+25); /*send*/
	local[25]= w;
	w = local[17];
	ctx->vsp=local+26;
	local[17] = cons(ctx,local[25],w);
	goto shadowWHL3790;
shadowWHX3791:
	local[25]= NIL;
shadowBLK3792:
	w = NIL;
	local[23]= local[17];
	ctx->vsp=local+24;
	w=(pointer)NREVERSE(ctx,1,local+23); /*nreverse*/
	local[23]= w;
	w = local[18];
	ctx->vsp=local+24;
	local[18] = cons(ctx,local[23],w);
	goto shadowWHL3787;
shadowWHX3788:
	local[23]= NIL;
shadowBLK3789:
	w = NIL;
	local[21]= local[18];
	ctx->vsp=local+22;
	w=(pointer)NREVERSE(ctx,1,local+21); /*nreverse*/
	local[18] = w;
	local[21]= NIL;
	local[22]= local[18];
shadowWHL3793:
	if (local[22]==NIL) goto shadowWHX3794;
	w=local[22];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	w=local[22];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22] = (w)->c.cons.cdr;
	w = local[23];
	local[21] = w;
	local[23]= loadglobal(fqv[20]);
	ctx->vsp=local+24;
	w=(pointer)INSTANTIATE(ctx,1,local+23); /*instantiate*/
	local[23]= w;
	local[24]= local[23];
	local[25]= fqv[10];
	local[26]= fqv[17];
	local[27]= local[21];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,4,local+24); /*send*/
	w = local[23];
	local[23]= w;
	w = local[19];
	ctx->vsp=local+24;
	local[19] = cons(ctx,local[23],w);
	goto shadowWHL3793;
shadowWHX3794:
	local[23]= NIL;
shadowBLK3795:
	w = NIL;
	local[21]= loadglobal(fqv[18]);
	ctx->vsp=local+22;
	w=(pointer)INSTANTIATE(ctx,1,local+21); /*instantiate*/
	local[21]= w;
	local[22]= local[21];
	local[23]= fqv[10];
	local[24]= fqv[17];
	local[25]= local[16];
	local[26]= fqv[24];
	local[27]= local[19];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,6,local+22); /*send*/
	w = local[21];
	local[21]= w;
	w = local[6];
	ctx->vsp=local+22;
	local[6] = cons(ctx,local[21],w);
	w = local[6];
	goto shadowWHL3781;
shadowWHX3782:
	local[16]= NIL;
shadowBLK3783:
	w = NIL;
	local[14]= local[6];
	local[15]= (pointer)get_sym_func(fqv[25]);
	ctx->vsp=local+16;
	local[16]= makeclosure(codevec,quotevec,shadowCLO3796,env,argv,local);
	ctx->vsp=local+17;
	w=(pointer)SORT(ctx,3,local+14); /*sort*/
	local[14]= NIL;
	local[15]= NIL;
	local[16]= NIL;
	local[17]= NIL;
	local[18]= NIL;
shadowWHL3797:
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto shadowWHX3798;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[19];
	local[15] = w;
	local[14] = NIL;
shadowWHL3801:
	if (local[6]==NIL) goto shadowWHX3802;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[19];
	local[16] = w;
	storeglobal(fqv[26],local[15]);
	local[19]= local[16];
	storeglobal(fqv[27],local[19]);
	local[19]= local[15];
	local[20]= local[16];
	ctx->vsp=local+21;
	w=(*ftab[2])(ctx,2,local+19,&ftab[2],fqv[28]); /*face+*/
	local[17] = w;
	ctx->vsp=local+19;
	local[19]= makeclosure(codevec,quotevec,shadowCLO3806,env,argv,local);
	local[20]= local[17];
	ctx->vsp=local+21;
	w=(*ftab[3])(ctx,2,local+19,&ftab[3],fqv[29]); /*member-if*/
	if (w==NIL) goto shadowIF3804;
	local[19]= fqv[30];
	ctx->vsp=local+20;
	w=(*ftab[4])(ctx,1,local+19,&ftab[4],fqv[31]); /*break*/
	local[19]= w;
	goto shadowIF3805;
shadowIF3804:
	local[19]= loadglobal(fqv[16]);
	local[20]= local[17];
	ctx->vsp=local+21;
	w=(*ftab[5])(ctx,2,local+19,&ftab[5],fqv[32]); /*collect-instances*/
	local[17] = w;
	local[19]= local[17];
shadowIF3805:
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr!=NIL) goto shadowCON3808;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	w = local[14];
	ctx->vsp=local+20;
	local[14] = cons(ctx,local[19],w);
	local[19]= local[14];
	local[20]= local[6];
	ctx->vsp=local+21;
	w=(pointer)NCONC(ctx,2,local+19); /*nconc*/
	w = NIL;
	ctx->vsp=local+19;
	local[19]=w;
	goto shadowBLK3800;
	goto shadowCON3807;
shadowCON3808:
	local[19]= local[16];
	w = local[14];
	ctx->vsp=local+20;
	local[14] = cons(ctx,local[19],w);
	local[19]= local[14];
	goto shadowCON3807;
shadowCON3809:
	local[19]= NIL;
shadowCON3807:
	goto shadowWHL3801;
shadowWHX3802:
	local[19]= NIL;
shadowBLK3803:
	local[19]= fqv[33];
	ctx->vsp=local+20;
	w=(pointer)SIGERROR(ctx,1,local+19); /*error*/
	local[19]= w;
shadowBLK3800:
	local[6] = local[14];
	goto shadowWHL3797;
shadowWHX3798:
	local[19]= NIL;
shadowBLK3799:
	w = local[19];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	ctx->vsp=local+15;
	unbindx(ctx,1);
	w = local[14];
	local[0]= w;
shadowBLK3775:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer shadowCLO3796(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[34];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer shadowCLO3806(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[35]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*remove-inner-loop*/
static pointer shadowF3742remove_inner_loop(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
shadowWHL3811:
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto shadowWHX3812;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[3]= w;
	local[4]= NIL;
	local[5]= local[2];
shadowWHL3814:
	if (local[5]==NIL) goto shadowWHX3815;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[3];
	local[7]= local[3];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(*ftab[6])(ctx,2,local+7,&ftab[6],fqv[36]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)EQ(ctx,2,local+6); /*eql*/
	if (w==NIL) goto shadowOR3819;
	local[6]= local[3];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)EQ(ctx,2,local+6); /*eql*/
	if (w==NIL) goto shadowOR3819;
	local[6]= local[4];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(*ftab[7])(ctx,1,local+7,&ftab[7],fqv[37]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)EQ(ctx,2,local+6); /*eql*/
	if (w==NIL) goto shadowOR3819;
	goto shadowIF3817;
shadowOR3819:
	local[6]= local[3]->c.obj.iv[1];
	local[7]= local[3]->c.obj.iv[2];
	local[8]= local[4]->c.obj.iv[1];
	local[9]= local[4]->c.obj.iv[2];
	local[10]= makeflt(1.0000000000000000208167e-03);
	ctx->vsp=local+11;
	w=(pointer)LINEINTERSECTION3(ctx,5,local+6); /*line-intersection3*/
	local[6]= w;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	if (local[6]==NIL) goto shadowIF3820;
	local[9]= makeflt(0.0000000000000000000000e+00);
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(*ftab[0])(ctx,2,local+9,&ftab[0],fqv[14]); /*eps<*/
	if (w==NIL) goto shadowIF3820;
	local[9]= local[7];
	local[10]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(*ftab[0])(ctx,2,local+9,&ftab[0],fqv[14]); /*eps<*/
	if (w==NIL) goto shadowIF3820;
	local[9]= makeflt(0.0000000000000000000000e+00);
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(*ftab[0])(ctx,2,local+9,&ftab[0],fqv[14]); /*eps<*/
	if (w==NIL) goto shadowIF3820;
	local[9]= local[8];
	local[10]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(*ftab[0])(ctx,2,local+9,&ftab[0],fqv[14]); /*eps<*/
	if (w==NIL) goto shadowIF3820;
	local[9]= local[3];
	local[10]= local[4];
	local[11]= local[3];
	local[12]= fqv[38];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	local[12]= local[7];
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,5,local+9); /*list*/
	local[9]= w;
	w = local[0];
	ctx->vsp=local+10;
	local[0] = cons(ctx,local[9],w);
	local[9]= local[3];
	w = local[1];
	ctx->vsp=local+10;
	local[1] = cons(ctx,local[9],w);
	local[9]= local[4];
	w = local[1];
	ctx->vsp=local+10;
	local[1] = cons(ctx,local[9],w);
	local[9]= local[1];
	goto shadowIF3821;
shadowIF3820:
	local[9]= NIL;
shadowIF3821:
	w = local[9];
	local[6]= w;
	goto shadowIF3818;
shadowIF3817:
	local[6]= NIL;
shadowIF3818:
	goto shadowWHL3814;
shadowWHX3815:
	local[6]= NIL;
shadowBLK3816:
	w = NIL;
	goto shadowWHL3811;
shadowWHX3812:
	local[3]= NIL;
shadowBLK3813:
	w = local[3];
	local[2]= NIL;
	local[3]= local[0];
shadowWHL3822:
	if (local[3]==NIL) goto shadowWHX3823;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= local[4]->c.obj.iv[2];
	local[7]= local[4]->c.obj.iv[1];
	ctx->vsp=local+8;
	w=(pointer)VMINUS(ctx,2,local+6); /*v-*/
	local[6]= w;
	local[7]= local[5]->c.obj.iv[2];
	local[8]= local[5]->c.obj.iv[1];
	ctx->vsp=local+9;
	w=(pointer)VMINUS(ctx,2,local+7); /*v-*/
	local[7]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= NIL;
	local[10]= argv[1];
	local[11]= local[6];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)SCA3PROD(ctx,3,local+10); /*v.**/
	local[10]= w;
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)LESSP(ctx,2,local+10); /*<*/
	if (w==NIL) goto shadowIF3825;
	local[10]= local[5];
	local[11]= local[4];
	local[4] = local[10];
	local[5] = local[11];
	w = NIL;
	local[10]= w;
	goto shadowIF3826;
shadowIF3825:
	local[10]= NIL;
shadowIF3826:
	local[10]= local[4];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(*ftab[6])(ctx,2,local+10,&ftab[6],fqv[36]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	if (local[9]!=NIL) goto shadowIF3827;
	local[9] = argv[0];
	local[10]= local[9];
	goto shadowIF3828;
shadowIF3827:
	local[10]= NIL;
shadowIF3828:
shadowWHL3829:
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	if (local[5]==local[10]) goto shadowWHX3830;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(*ftab[6])(ctx,2,local+10,&ftab[6],fqv[36]); /*member*/
	if (w==NIL) goto shadowIF3832;
	local[10]= fqv[39];
	ctx->vsp=local+11;
	w=(pointer)SIGERROR(ctx,1,local+10); /*error*/
	local[10]= w;
	goto shadowIF3833;
shadowIF3832:
	local[10]= NIL;
shadowIF3833:
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= argv[0];
	local[12]= fqv[40];
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,4,local+10,&ftab[8],fqv[41]); /*delete*/
	argv[0] = w;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	if (local[9]!=NIL) goto shadowIF3834;
	local[9] = argv[0];
	local[10]= local[9];
	goto shadowIF3835;
shadowIF3834:
	local[10]= NIL;
shadowIF3835:
	goto shadowWHL3829;
shadowWHX3830:
	local[10]= NIL;
shadowBLK3831:
	local[10]= local[8];
	local[11]= local[10];
	w = local[4];
	w->c.obj.iv[2] = local[11];
	local[10]= local[8];
	local[11]= local[10];
	w = local[5];
	w->c.obj.iv[1] = local[11];
	w = local[10];
	goto shadowWHL3822;
shadowWHX3823:
	local[4]= NIL;
shadowBLK3824:
	w = NIL;
	w = argv[0];
	local[0]= w;
shadowBLK3810:
	ctx->vsp=local; return(local[0]);}

/*project-shadow*/
static pointer shadowF3743project_shadow(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
	local[3]= fqv[13];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[1];
	local[7]= fqv[22];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)VMINUS(ctx,1,local+7); /*v-*/
	local[7]= w;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= NIL;
	local[15]= NIL;
	local[16]= NIL;
	local[17]= local[2];
shadowWHL3837:
	if (local[17]==NIL) goto shadowWHX3838;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17] = (w)->c.cons.cdr;
	w = local[18];
	local[16] = w;
	local[18]= local[6];
	local[19]= local[16]->c.obj.iv[1];
	ctx->vsp=local+20;
	w=(pointer)VINNERPRODUCT(ctx,2,local+18); /*v.*/
	local[18]= w;
	local[19]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+20;
	w=(*ftab[0])(ctx,2,local+18,&ftab[0],fqv[14]); /*eps<*/
	if (w==NIL) goto shadowIF3840;
	local[18]= local[16];
	w = local[0];
	ctx->vsp=local+19;
	local[0] = cons(ctx,local[18],w);
	local[18]= local[0];
	goto shadowIF3841;
shadowIF3840:
	local[18]= local[16];
	w = local[1];
	ctx->vsp=local+19;
	local[1] = cons(ctx,local[18],w);
	local[18]= local[1];
shadowIF3841:
	goto shadowWHL3837;
shadowWHX3838:
	local[18]= NIL;
shadowBLK3839:
	w = NIL;
	local[16]= NIL;
	local[17]= argv[0];
	local[18]= fqv[19];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
shadowWHL3842:
	if (local[17]==NIL) goto shadowWHX3843;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17] = (w)->c.cons.cdr;
	w = local[18];
	local[16] = w;
	local[18]= local[16]->c.obj.iv[3];
	local[19]= local[16]->c.obj.iv[4];
	local[20]= local[18];
	local[21]= local[0];
	ctx->vsp=local+22;
	w=(*ftab[6])(ctx,2,local+20,&ftab[6],fqv[36]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= local[19];
	local[22]= local[0];
	ctx->vsp=local+23;
	w=(*ftab[6])(ctx,2,local+21,&ftab[6],fqv[36]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	local[22]= NIL;
	if (local[20]==NIL) goto shadowCON3846;
	if (local[21]!=NIL) goto shadowCON3846;
	local[22] = local[20];
	local[23]= local[22];
	goto shadowCON3845;
shadowCON3846:
	if (local[20]!=NIL) goto shadowCON3847;
	if (local[21]==NIL) goto shadowCON3847;
	local[22] = local[21];
	local[23]= local[22];
	goto shadowCON3845;
shadowCON3847:
	local[22] = NIL;
	local[23]= local[22];
	goto shadowCON3845;
shadowCON3848:
	local[23]= NIL;
shadowCON3845:
	if (local[22]==NIL) goto shadowIF3849;
	local[23]= local[16];
	local[24]= local[22];
	ctx->vsp=local+25;
	w=(pointer)LIST(ctx,2,local+23); /*list*/
	local[23]= w;
	w = local[3];
	ctx->vsp=local+24;
	local[3] = cons(ctx,local[23],w);
	local[23]= local[3];
	goto shadowIF3850;
shadowIF3849:
	local[23]= NIL;
shadowIF3850:
	w = local[23];
	goto shadowWHL3842;
shadowWHX3843:
	local[18]= NIL;
shadowBLK3844:
	w = NIL;
	local[16]= NIL;
	local[17]= local[3];
shadowWHL3851:
	if (local[17]==NIL) goto shadowWHX3852;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17] = (w)->c.cons.cdr;
	w = local[18];
	local[16] = w;
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	local[19]= fqv[11];
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,3,local+18); /*send*/
	local[18]= w;
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	local[20]= fqv[12];
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= w;
	local[20]= local[18];
	local[21]= local[5];
	ctx->vsp=local+22;
	w=(*ftab[9])(ctx,2,local+20,&ftab[9],fqv[42]); /*assoc*/
	if (w!=NIL) goto shadowIF3854;
	local[20]= local[18];
	local[21]= argv[1];
	local[22]= fqv[23];
	local[23]= local[18];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,3,local+21); /*send*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)LIST(ctx,2,local+20); /*list*/
	local[20]= w;
	w = local[5];
	ctx->vsp=local+21;
	local[5] = cons(ctx,local[20],w);
	local[20]= local[5];
	goto shadowIF3855;
shadowIF3854:
	local[20]= NIL;
shadowIF3855:
	local[20]= local[19];
	local[21]= local[5];
	ctx->vsp=local+22;
	w=(*ftab[9])(ctx,2,local+20,&ftab[9],fqv[42]); /*assoc*/
	if (w!=NIL) goto shadowIF3856;
	local[20]= local[19];
	local[21]= argv[1];
	local[22]= fqv[23];
	local[23]= local[19];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,3,local+21); /*send*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)LIST(ctx,2,local+20); /*list*/
	local[20]= w;
	w = local[5];
	ctx->vsp=local+21;
	local[5] = cons(ctx,local[20],w);
	local[20]= local[5];
	goto shadowIF3857;
shadowIF3856:
	local[20]= NIL;
shadowIF3857:
	w = local[20];
	goto shadowWHL3851;
shadowWHX3852:
	local[18]= NIL;
shadowBLK3853:
	w = NIL;
	local[16]= NIL;
	local[17]= local[3];
shadowWHL3858:
	if (local[17]==NIL) goto shadowWHX3859;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17] = (w)->c.cons.cdr;
	w = local[18];
	local[16] = w;
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	local[19]= fqv[11];
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,3,local+18); /*send*/
	local[18]= w;
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	local[20]= fqv[12];
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= w;
	local[20]= loadglobal(fqv[9]);
	ctx->vsp=local+21;
	w=(pointer)INSTANTIATE(ctx,1,local+20); /*instantiate*/
	local[20]= w;
	local[21]= local[20];
	local[22]= fqv[10];
	local[23]= fqv[11];
	local[24]= local[18];
	local[25]= local[5];
	ctx->vsp=local+26;
	w=(*ftab[9])(ctx,2,local+24,&ftab[9],fqv[42]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[24]= (w)->c.cons.car;
	local[25]= fqv[12];
	local[26]= local[19];
	local[27]= local[5];
	ctx->vsp=local+28;
	w=(*ftab[9])(ctx,2,local+26,&ftab[9],fqv[42]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26]= (w)->c.cons.car;
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,6,local+21); /*send*/
	w = local[20];
	local[20]= w;
	w = local[8];
	ctx->vsp=local+21;
	local[8] = cons(ctx,local[20],w);
	w = local[8];
	goto shadowWHL3858;
shadowWHX3859:
	local[18]= NIL;
shadowBLK3860:
	w = NIL;
shadowWHL3861:
	if (local[8]==NIL) goto shadowWHX3862;
	local[13] = NIL;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[16];
	local[11] = w;
	local[16]= local[11];
	w = local[13];
	ctx->vsp=local+17;
	local[13] = cons(ctx,local[16],w);
	local[11] = local[11]->c.obj.iv[2];
shadowWHL3864:
	ctx->vsp=local+16;
	local[16]= makeclosure(codevec,quotevec,shadowCLO3867,env,argv,local);
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(*ftab[10])(ctx,2,local+16,&ftab[10],fqv[43]); /*find-if*/
	local[12] = w;
	if (local[12]==NIL) goto shadowWHX3865;
	local[16]= local[12];
	local[17]= local[8];
	local[18]= fqv[40];
	local[19]= makeint((eusinteger_t)1L);
	ctx->vsp=local+20;
	w=(*ftab[8])(ctx,4,local+16,&ftab[8],fqv[41]); /*delete*/
	local[8] = w;
	local[11] = local[12]->c.obj.iv[2];
	local[16]= local[12];
	w = local[13];
	ctx->vsp=local+17;
	local[13] = cons(ctx,local[16],w);
	goto shadowWHL3864;
shadowWHX3865:
	local[16]= NIL;
shadowBLK3866:
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)NREVERSE(ctx,1,local+16); /*nreverse*/
	local[16]= w;
	w = local[4];
	ctx->vsp=local+17;
	local[4] = cons(ctx,local[16],w);
	goto shadowWHL3861;
shadowWHX3862:
	local[16]= NIL;
shadowBLK3863:
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)NREVERSE(ctx,1,local+16); /*nreverse*/
	local[4] = w;
	local[16]= NIL;
	local[17]= local[4];
shadowWHL3868:
	if (local[17]==NIL) goto shadowWHX3869;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17] = (w)->c.cons.cdr;
	w = local[18];
	local[16] = w;
	local[18]= local[16];
	local[19]= local[6];
	ctx->vsp=local+20;
	w=(pointer)shadowF3742remove_inner_loop(ctx,2,local+18); /*remove-inner-loop*/
	local[18]= w;
	w = local[9];
	ctx->vsp=local+19;
	local[9] = cons(ctx,local[18],w);
	goto shadowWHL3868;
shadowWHX3869:
	local[18]= NIL;
shadowBLK3870:
	w = NIL;
	local[4] = local[9];
	local[16]= local[4];
	storeglobal(fqv[44],local[16]);
	local[14] = NIL;
	local[15] = NIL;
	local[16]= NIL;
	local[17]= local[4];
shadowWHL3871:
	if (local[17]==NIL) goto shadowWHX3872;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17] = (w)->c.cons.cdr;
	w = local[18];
	local[16] = w;
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)shadowF3739make_face_from_edge_loop(ctx,1,local+18); /*make-face-from-edge-loop*/
	local[18]= w;
	local[19]= local[6];
	local[20]= local[18];
	local[21]= fqv[22];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,2,local+20); /*send*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)VINNERPRODUCT(ctx,2,local+19); /*v.*/
	local[19]= w;
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[19]);
	if (left >= right) goto shadowIF3874;}
	local[19]= local[18];
	w = local[15];
	ctx->vsp=local+20;
	local[15] = cons(ctx,local[19],w);
	local[19]= local[15];
	goto shadowIF3875;
shadowIF3874:
	local[19]= local[18];
	ctx->vsp=local+20;
	w=(pointer)shadowF3740change_to_hole(ctx,1,local+19); /*change-to-hole*/
	local[19]= w;
	w = local[14];
	ctx->vsp=local+20;
	local[14] = cons(ctx,local[19],w);
	local[19]= local[14];
shadowIF3875:
	w = local[19];
	goto shadowWHL3871;
shadowWHX3872:
	local[18]= NIL;
shadowBLK3873:
	w = NIL;
	local[16]= NIL;
	local[17]= local[14];
shadowWHL3876:
	if (local[17]==NIL) goto shadowWHX3877;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17] = (w)->c.cons.cdr;
	w = local[18];
	local[16] = w;
	local[18]= NIL;
	local[19]= local[15];
shadowWHL3880:
	if (local[19]==NIL) goto shadowWHX3881;
	w=local[19];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	w=local[19];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19] = (w)->c.cons.cdr;
	w = local[20];
	local[18] = w;
	ctx->vsp=local+20;
	local[20]= makeclosure(codevec,quotevec,shadowCLO3885,env,argv,local);
	local[21]= local[16];
	local[22]= fqv[17];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(*ftab[11])(ctx,2,local+20,&ftab[11],fqv[45]); /*every*/
	if (w==NIL) goto shadowIF3883;
	local[20]= local[18];
	local[21]= fqv[46];
	local[22]= local[16];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[20]= local[16];
	local[21]= fqv[47];
	local[22]= local[18];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	w = NIL;
	ctx->vsp=local+20;
	local[18]=w;
	goto shadowBLK3879;
	goto shadowIF3884;
shadowIF3883:
	local[20]= NIL;
shadowIF3884:
	goto shadowWHL3880;
shadowWHX3881:
	local[20]= NIL;
shadowBLK3882:
	w = NIL;
	local[18]= w;
shadowBLK3879:
	goto shadowWHL3876;
shadowWHX3877:
	local[18]= NIL;
shadowBLK3878:
	w = NIL;
	local[10] = local[15];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)COPYSEQ(ctx,1,local+16); /*copy-seq*/
	local[16]= w;
	storeglobal(fqv[48],w);
	local[16]= NIL;
	local[17]= NIL;
	local[18]= NIL;
	local[19]= NIL;
	local[20]= NIL;
shadowWHL3886:
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto shadowWHX3887;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[21];
	local[17] = w;
	local[16] = NIL;
shadowWHL3890:
	if (local[10]==NIL) goto shadowWHX3891;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[21];
	local[18] = w;
	storeglobal(fqv[26],local[17]);
	local[21]= local[18];
	storeglobal(fqv[27],local[21]);
	local[21]= local[17];
	local[22]= local[18];
	ctx->vsp=local+23;
	w=(*ftab[2])(ctx,2,local+21,&ftab[2],fqv[28]); /*face+*/
	local[19] = w;
	ctx->vsp=local+21;
	local[21]= makeclosure(codevec,quotevec,shadowCLO3895,env,argv,local);
	local[22]= local[19];
	ctx->vsp=local+23;
	w=(*ftab[3])(ctx,2,local+21,&ftab[3],fqv[29]); /*member-if*/
	if (w==NIL) goto shadowIF3893;
	local[21]= fqv[49];
	ctx->vsp=local+22;
	w=(*ftab[4])(ctx,1,local+21,&ftab[4],fqv[31]); /*break*/
	local[21]= w;
	goto shadowIF3894;
shadowIF3893:
	local[21]= loadglobal(fqv[16]);
	local[22]= local[19];
	ctx->vsp=local+23;
	w=(*ftab[5])(ctx,2,local+21,&ftab[5],fqv[32]); /*collect-instances*/
	local[19] = w;
	local[21]= local[19];
shadowIF3894:
	w=local[19];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr!=NIL) goto shadowCON3897;
	w=local[19];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	w = local[16];
	ctx->vsp=local+22;
	local[16] = cons(ctx,local[21],w);
	local[21]= local[16];
	local[22]= local[10];
	ctx->vsp=local+23;
	w=(pointer)NCONC(ctx,2,local+21); /*nconc*/
	w = NIL;
	ctx->vsp=local+21;
	local[21]=w;
	goto shadowBLK3889;
	goto shadowCON3896;
shadowCON3897:
	local[21]= local[18];
	w = local[16];
	ctx->vsp=local+22;
	local[16] = cons(ctx,local[21],w);
	local[21]= local[16];
	goto shadowCON3896;
shadowCON3898:
	local[21]= NIL;
shadowCON3896:
	goto shadowWHL3890;
shadowWHX3891:
	local[21]= NIL;
shadowBLK3892:
	local[21]= fqv[50];
	ctx->vsp=local+22;
	w=(pointer)SIGERROR(ctx,1,local+21); /*error*/
	local[21]= w;
shadowBLK3889:
	local[10] = local[16];
	goto shadowWHL3886;
shadowWHX3887:
	local[21]= NIL;
shadowBLK3888:
	w = local[21];
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
shadowBLK3836:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer shadowCLO3867(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	w = ((env->c.clo.env2[11])==(local[0])?T:NIL);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer shadowCLO3885(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[18];
	local[1]= fqv[51];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[52];
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer shadowCLO3895(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[35]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*shadow-intersection*/
static pointer shadowF3744shadow_intersection(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)shadowF3743project_shadow(ctx,2,local+0); /*project-shadow*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)shadowF3743project_shadow(ctx,2,local+1); /*project-shadow*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[12])(ctx,2,local+0,&ftab[12],fqv[53]); /*face**/
	local[0]= w;
shadowBLK3899:
	ctx->vsp=local; return(local[0]);}

/*closest-shadow*/
static pointer shadowF3745closest_shadow(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= fqv[54];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= argv[1];
	local[3]= fqv[22];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)VMINUS(ctx,1,local+3); /*v-*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= argv[1];
	local[8]= fqv[55];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= NIL;
	w = NIL;
	local[0]= w;
shadowBLK3900:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___shadow(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[56];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto shadowIF3901;
	local[0]= fqv[57];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[58],w);
	goto shadowIF3902;
shadowIF3901:
	local[0]= fqv[59];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
shadowIF3902:
	local[0]= fqv[60];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compmacro(ctx,fqv[61],module,shadowF3746,fqv[62]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[63],module,shadowF3735polygon_in_contact_p,fqv[64]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[65],module,shadowF3736make_edges_from_vertices,fqv[66]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[67],module,shadowF3737orthogonally_visible_faces,fqv[68]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[69],module,shadowF3738make_polygon,fqv[70]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[71],module,shadowF3739make_face_from_edge_loop,fqv[72]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[73],module,shadowF3740change_to_hole,fqv[74]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[75],module,shadowF3741project_shadow1,fqv[76]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[77],module,shadowF3742remove_inner_loop,fqv[78]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[79],module,shadowF3743project_shadow,fqv[80]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[81],module,shadowF3744shadow_intersection,fqv[82]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[83],module,shadowF3745closest_shadow,fqv[84]);
	local[0]= fqv[85];
	local[1]= fqv[86];
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,2,local+0,&ftab[13],fqv[87]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<14; i++) ftab[i]=fcallx;
}

/* ./viewport.c :  entry=viewport */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "viewport.h"
#pragma init (register_viewport)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___viewport();
extern pointer build_quote_vector();
static int register_viewport()
  { add_module_initializer("___viewport", ___viewport);}

static pointer viewportF3202draw();
static pointer viewportF3203draw_tree();
static pointer viewportF3204erase();
static pointer viewportF3205draw_axis();
static pointer viewportF3206draw_arrow();
static pointer viewportF3207hid();
static pointer viewportF3208hidd();
static pointer viewportF3209cls();
static pointer viewportF3210draw_hid();
static pointer viewportF3211draw_step();
static pointer viewportF3212find_viewer();
static pointer viewportF3213view();

/*:xcenter*/
static pointer viewportM3214viewport_xcenter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto viewportENT3217;}
	local[0]= NIL;
viewportENT3217:
viewportENT3216:
	if (n>3) maerror();
	if (local[0]==NIL) goto viewportIF3218;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)ASET(ctx,3,local+1); /*aset*/
	local[1]= w;
	goto viewportIF3219;
viewportIF3218:
	local[1]= NIL;
viewportIF3219:
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[0]= w;
viewportBLK3215:
	ctx->vsp=local; return(local[0]);}

/*:ycenter*/
static pointer viewportM3220viewport_ycenter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto viewportENT3223;}
	local[0]= NIL;
viewportENT3223:
viewportENT3222:
	if (n>3) maerror();
	if (local[0]==NIL) goto viewportIF3224;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= makeint((eusinteger_t)1L);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)ASET(ctx,3,local+1); /*aset*/
	local[1]= w;
	goto viewportIF3225;
viewportIF3224:
	local[1]= NIL;
viewportIF3225:
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[0]= w;
viewportBLK3221:
	ctx->vsp=local; return(local[0]);}

/*:center*/
static pointer viewportM3226viewport_center(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto viewportENT3230;}
	local[0]= NIL;
viewportENT3230:
	if (n>=4) { local[1]=(argv[3]); goto viewportENT3229;}
	local[1]= local[0];
viewportENT3229:
viewportENT3228:
	if (n>4) maerror();
	w = local[0];
	if (!isnum(w)) goto viewportCON3232;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= makeint((eusinteger_t)1L);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= w;
	goto viewportCON3231;
viewportCON3232:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,1,local+2,&ftab[0],fqv[0]); /*float-vector-p*/
	if (w==NIL) goto viewportCON3233;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= makeint((eusinteger_t)1L);
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= w;
	goto viewportCON3231;
viewportCON3233:
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,2,local+2); /*aref*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,2,local+2); /*float-vector*/
	local[2]= w;
	goto viewportCON3231;
viewportCON3234:
	local[2]= NIL;
viewportCON3231:
	w = local[2];
	local[0]= w;
viewportBLK3227:
	ctx->vsp=local; return(local[0]);}

/*:width*/
static pointer viewportM3235viewport_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto viewportENT3238;}
	local[0]= NIL;
viewportENT3238:
viewportENT3237:
	if (n>3) maerror();
	if (local[0]==NIL) goto viewportIF3239;
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[0];
	local[5]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	local[1]= w;
	goto viewportIF3240;
viewportIF3239:
	local[1]= NIL;
viewportIF3240:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,3,local+1); /*aref*/
	local[1]= w;
	local[2]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[0]= w;
viewportBLK3236:
	ctx->vsp=local; return(local[0]);}

/*:height*/
static pointer viewportM3241viewport_height(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto viewportENT3244;}
	local[0]= NIL;
viewportENT3244:
viewportENT3243:
	if (n>3) maerror();
	if (local[0]==NIL) goto viewportIF3245;
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= makeint((eusinteger_t)1L);
	local[3]= makeint((eusinteger_t)1L);
	local[4]= local[0];
	local[5]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	local[1]= w;
	goto viewportIF3246;
viewportIF3245:
	local[1]= NIL;
viewportIF3246:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= makeint((eusinteger_t)1L);
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,3,local+1); /*aref*/
	local[1]= w;
	local[2]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[0]= w;
viewportBLK3242:
	ctx->vsp=local; return(local[0]);}

/*:size*/
static pointer viewportM3247viewport_size(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto viewportENT3251;}
	local[0]= NIL;
viewportENT3251:
	if (n>=4) { local[1]=(argv[3]); goto viewportENT3250;}
	local[1]= local[0];
viewportENT3250:
viewportENT3249:
	if (n>4) maerror();
	w = local[0];
	if (!isnum(w)) goto viewportCON3253;
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[0];
	local[6]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ASET(ctx,4,local+2); /*aset*/
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= makeint((eusinteger_t)1L);
	local[4]= makeint((eusinteger_t)1L);
	local[5]= local[1];
	local[6]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ASET(ctx,4,local+2); /*aset*/
	local[2]= w;
	goto viewportCON3252;
viewportCON3253:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,1,local+2,&ftab[0],fqv[0]); /*float-vector-p*/
	if (w==NIL) goto viewportCON3254;
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ASET(ctx,4,local+2); /*aset*/
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= makeint((eusinteger_t)1L);
	local[4]= makeint((eusinteger_t)1L);
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ASET(ctx,4,local+2); /*aset*/
	local[2]= w;
	goto viewportCON3252;
viewportCON3254:
	local[2]= makeflt(2.0000000000000000000000e+00);
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,3,local+3); /*aref*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= makeflt(2.0000000000000000000000e+00);
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= makeint((eusinteger_t)1L);
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,3,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,2,local+2); /*float-vector*/
	local[2]= w;
	goto viewportCON3252;
viewportCON3255:
	local[2]= NIL;
viewportCON3252:
	w = local[2];
	local[0]= w;
viewportBLK3248:
	ctx->vsp=local; return(local[0]);}

/*:screen-point-to-ndc*/
static pointer viewportM3256viewport_screen_point_to_ndc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)COPYSEQ(ctx,1,local+0); /*copy-seq*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,1,local+1,&ftab[1],fqv[1]); /*inverse-matrix*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)VMINUS(ctx,3,local+2); /*v-*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)TRANSFORM(ctx,3,local+1); /*transform*/
	local[0]= w;
viewportBLK3257:
	ctx->vsp=local; return(local[0]);}

/*:ndc-width-to-screen*/
static pointer viewportM3258viewport_ndc_width_to_screen(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,3,local+0); /*aref*/
	local[0]= w;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)ABS(ctx,1,local+0); /*abs*/
	local[0]= w;
viewportBLK3259:
	ctx->vsp=local; return(local[0]);}

/*:ndc-height-to-screen*/
static pointer viewportM3260viewport_ndc_height_to_screen(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= makeint((eusinteger_t)1L);
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,3,local+0); /*aref*/
	local[0]= w;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)ABS(ctx,1,local+0); /*abs*/
	local[0]= w;
viewportBLK3261:
	ctx->vsp=local; return(local[0]);}

/*:ndc-point-to-screen*/
static pointer viewportM3262viewport_ndc_point_to_screen(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	if (makeint((eusinteger_t)2L)!=local[0]) goto viewportIF3264;
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)AREF(ctx,2,local+0); /*aref*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[1]= w;
	local[2]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	goto viewportIF3265;
viewportIF3264:
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)COPYSEQ(ctx,1,local+0); /*copy-seq*/
	local[0]= w;
viewportIF3265:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= local[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)TRANSFORM(ctx,3,local+1); /*transform*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,3,local+1); /*v+*/
	local[0]= w;
viewportBLK3263:
	ctx->vsp=local; return(local[0]);}

/*:ndc-line-to-screen*/
static pointer viewportM3266viewport_ndc_line_to_screen(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto viewportENT3269;}
	local[0]= T;
viewportENT3269:
viewportENT3268:
	if (n>5) maerror();
	if (local[0]==NIL) goto viewportIF3270;
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)HOMO_VPCLIP(ctx,2,local+1); /*homo-viewport-clip*/
	argv[2] = w;
	if (argv[2]!=NIL) goto viewportIF3272;
	w = NIL;
	ctx->vsp=local+1;
	local[0]=w;
	goto viewportBLK3267;
	goto viewportIF3273;
viewportIF3272:
	local[1]= NIL;
viewportIF3273:
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[3] = (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.car;
	local[1]= argv[2];
	goto viewportIF3271;
viewportIF3270:
	local[1]= NIL;
viewportIF3271:
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	w = makeint((eusinteger_t)3L);
	if ((eusinteger_t)local[1] <= (eusinteger_t)w) goto viewportIF3274;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)HOMO2NORMAL(ctx,1,local+1); /*homo2normal*/
	argv[2] = w;
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)HOMO2NORMAL(ctx,1,local+1); /*homo2normal*/
	argv[3] = w;
	local[1]= argv[3];
	goto viewportIF3275;
viewportIF3274:
	local[1]= NIL;
viewportIF3275:
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	w = makeint((eusinteger_t)3L);
	if ((eusinteger_t)local[1] >= (eusinteger_t)w) goto viewportIF3276;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)HOMOGENIZE(ctx,1,local+1); /*homogenize*/
	argv[2] = w;
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)HOMOGENIZE(ctx,1,local+1); /*homogenize*/
	argv[3] = w;
	local[1]= argv[3];
	goto viewportIF3277;
viewportIF3276:
	local[1]= NIL;
viewportIF3277:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[2];
	local[3]= loadglobal(fqv[2]);
	ctx->vsp=local+4;
	w=(pointer)TRANSFORM(ctx,3,local+1); /*transform*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= loadglobal(fqv[2]);
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,3,local+1); /*v+*/
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[3];
	local[3]= loadglobal(fqv[3]);
	ctx->vsp=local+4;
	w=(pointer)TRANSFORM(ctx,3,local+1); /*transform*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= loadglobal(fqv[3]);
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,3,local+1); /*v+*/
	local[1]= loadglobal(fqv[2]);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[1]= w;
	local[2]= loadglobal(fqv[2]);
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,2,local+2); /*aref*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,2,local+1); /*float-vector*/
	local[1]= w;
	local[2]= loadglobal(fqv[3]);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,2,local+2); /*aref*/
	local[2]= w;
	local[3]= loadglobal(fqv[3]);
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,2,local+2); /*float-vector*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[0]= w;
viewportBLK3267:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer viewportM3278viewport_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
viewportRST3280:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[4], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto viewportKEY3281;
	local[1] = NIL;
viewportKEY3281:
	if (n & (1<<1)) goto viewportKEY3282;
	local[2] = NIL;
viewportKEY3282:
	if (n & (1<<2)) goto viewportKEY3283;
	local[3] = NIL;
viewportKEY3283:
	if (n & (1<<3)) goto viewportKEY3284;
	local[4] = NIL;
viewportKEY3284:
	if (local[3]==NIL) goto viewportIF3285;
	local[5]= argv[0];
	local[6]= fqv[5];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto viewportIF3286;
viewportIF3285:
	local[5]= NIL;
viewportIF3286:
	if (local[4]==NIL) goto viewportIF3287;
	local[5]= argv[0];
	local[6]= fqv[6];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto viewportIF3288;
viewportIF3287:
	local[5]= NIL;
viewportIF3288:
	if (local[1]==NIL) goto viewportIF3289;
	local[5]= argv[0];
	local[6]= fqv[7];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto viewportIF3290;
viewportIF3289:
	local[5]= NIL;
viewportIF3290:
	if (local[2]==NIL) goto viewportIF3291;
	local[5]= argv[0];
	local[6]= fqv[8];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto viewportIF3292;
viewportIF3291:
	local[5]= NIL;
viewportIF3292:
	local[5]= argv[0];
	local[6]= fqv[9];
	local[7]= argv[0]->c.obj.iv[1];
	local[8]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	w = argv[0];
	local[0]= w;
viewportBLK3279:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer viewportM3293viewport_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
viewportRST3295:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[10], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto viewportKEY3296;
	local[1] = makeint((eusinteger_t)3L);
viewportKEY3296:
	if (n & (1<<1)) goto viewportKEY3297;
	local[2] = makeint((eusinteger_t)100L);
viewportKEY3297:
	if (n & (1<<2)) goto viewportKEY3298;
	local[3] = makeint((eusinteger_t)100L);
viewportKEY3298:
	if (n & (1<<3)) goto viewportKEY3299;
	local[4] = makeint((eusinteger_t)200L);
viewportKEY3299:
	if (n & (1<<4)) goto viewportKEY3300;
	local[5] = makeint((eusinteger_t)200L);
viewportKEY3300:
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[11]));
	local[8]= fqv[12];
	local[9]= fqv[13];
	local[10]= makeint((eusinteger_t)3L);
	ctx->vsp=local+11;
	w=(pointer)SENDMESSAGE(ctx,5,local+6); /*send-message*/
	local[6]= argv[0];
	local[7]= fqv[5];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= argv[0];
	local[7]= fqv[6];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= argv[0];
	local[7]= fqv[7];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= argv[0];
	local[7]= fqv[8];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= argv[0];
	local[7]= fqv[9];
	local[8]= argv[0]->c.obj.iv[1];
	local[9]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	w = argv[0];
	local[0]= w;
viewportBLK3294:
	ctx->vsp=local; return(local[0]);}

/*:viewing*/
static pointer viewportM3301viewer_viewing(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
viewportRST3303:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]==NIL) goto viewportIF3304;
	local[1]= (pointer)get_sym_func(fqv[14]);
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,3,local+1); /*apply*/
	local[1]= w;
	goto viewportIF3305;
viewportIF3304:
	local[1]= argv[0]->c.obj.iv[1];
viewportIF3305:
	w = local[1];
	local[0]= w;
viewportBLK3302:
	ctx->vsp=local; return(local[0]);}

/*:viewsurface*/
static pointer viewportM3306viewer_viewsurface(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
viewportRST3308:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]==NIL) goto viewportIF3309;
	local[1]= (pointer)get_sym_func(fqv[14]);
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,3,local+1); /*apply*/
	local[1]= w;
	goto viewportIF3310;
viewportIF3309:
	local[1]= argv[0]->c.obj.iv[3];
viewportIF3310:
	w = local[1];
	local[0]= w;
viewportBLK3307:
	ctx->vsp=local; return(local[0]);}

/*:viewport*/
static pointer viewportM3311viewer_viewport(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
viewportRST3313:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]==NIL) goto viewportIF3314;
	local[1]= (pointer)get_sym_func(fqv[14]);
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,3,local+1); /*apply*/
	local[1]= w;
	goto viewportIF3315;
viewportIF3314:
	local[1]= argv[0]->c.obj.iv[2];
viewportIF3315:
	w = local[1];
	local[0]= w;
viewportBLK3312:
	ctx->vsp=local; return(local[0]);}

/*:flush*/
static pointer viewportM3316viewer_flush(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[15];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
viewportBLK3317:
	ctx->vsp=local; return(local[0]);}

/*:point-to-screen*/
static pointer viewportM3318viewer_point_to_screen(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= fqv[16];
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= fqv[17];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)HOMO2NORMAL(ctx,1,local+2); /*homo2normal*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
viewportBLK3319:
	ctx->vsp=local; return(local[0]);}

/*:draw-point-ndc*/
static pointer viewportM3320viewer_draw_point_ndc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto viewportENT3323;}
	local[0]= NIL;
viewportENT3323:
viewportENT3322:
	if (n>4) maerror();
	if (local[0]==NIL) goto viewportIF3324;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[18];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto viewportIF3325;
viewportIF3324:
	local[1]= NIL;
viewportIF3325:
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= fqv[16];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	argv[2] = w;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[19];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
viewportBLK3321:
	ctx->vsp=local; return(local[0]);}

/*:draw-line-ndc*/
static pointer viewportM3326viewer_draw_line_ndc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto viewportENT3330;}
	local[0]= T;
viewportENT3330:
	if (n>=6) { local[1]=(argv[5]); goto viewportENT3329;}
	local[1]= NIL;
viewportENT3329:
viewportENT3328:
	if (n>6) maerror();
	if (local[1]==NIL) goto viewportIF3331;
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= fqv[18];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto viewportIF3332;
viewportIF3331:
	local[2]= NIL;
viewportIF3332:
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[20];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	argv[2] = w;
	if (argv[2]==NIL) goto viewportIF3333;
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= fqv[21];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	goto viewportIF3334;
viewportIF3333:
	local[2]= NIL;
viewportIF3334:
	w = NIL;
	local[0]= w;
viewportBLK3327:
	ctx->vsp=local; return(local[0]);}

/*:draw-string-ndc*/
static pointer viewportM3335viewer_draw_string_ndc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	w = argv[3];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[22],w);
	if (n>=5) { local[3]=(argv[4]); goto viewportENT3338;}
	local[3]= NIL;
viewportENT3338:
viewportENT3337:
	if (n>5) maerror();
	if (local[3]==NIL) goto viewportIF3339;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[18];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto viewportIF3340;
viewportIF3339:
	local[4]= NIL;
viewportIF3340:
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= fqv[16];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	argv[2] = w;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[23];
	local[6]= argv[2];
	local[7]= loadglobal(fqv[22]);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	unbindx(ctx,1);
	w = local[4];
	local[0]= w;
viewportBLK3336:
	ctx->vsp=local; return(local[0]);}

/*:draw-image-string-ndc*/
static pointer viewportM3341viewer_draw_image_string_ndc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	w = argv[3];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[22],w);
	if (n>=5) { local[3]=(argv[4]); goto viewportENT3344;}
	local[3]= NIL;
viewportENT3344:
viewportENT3343:
	if (n>5) maerror();
	if (local[3]==NIL) goto viewportIF3345;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[18];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto viewportIF3346;
viewportIF3345:
	local[4]= NIL;
viewportIF3346:
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= fqv[16];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	argv[2] = w;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[24];
	local[6]= argv[2];
	local[7]= loadglobal(fqv[22]);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	unbindx(ctx,1);
	w = local[4];
	local[0]= w;
viewportBLK3342:
	ctx->vsp=local; return(local[0]);}

/*:draw-rectangle-ndc*/
static pointer viewportM3347viewer_draw_rectangle_ndc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	if (n>=6) { local[0]=(argv[5]); goto viewportENT3350;}
	local[0]= NIL;
viewportENT3350:
viewportENT3349:
	if (n>6) maerror();
	if (local[0]==NIL) goto viewportIF3351;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[18];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto viewportIF3352;
viewportIF3351:
	local[1]= NIL;
viewportIF3352:
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= fqv[16];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	argv[2] = w;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= fqv[25];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	argv[3] = w;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= fqv[26];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	argv[4] = w;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[27];
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
viewportBLK3348:
	ctx->vsp=local; return(local[0]);}

/*:draw-fill-rectangle-ndc*/
static pointer viewportM3353viewer_draw_fill_rectangle_ndc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	if (n>=6) { local[0]=(argv[5]); goto viewportENT3356;}
	local[0]= NIL;
viewportENT3356:
viewportENT3355:
	if (n>6) maerror();
	if (local[0]==NIL) goto viewportIF3357;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[18];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto viewportIF3358;
viewportIF3357:
	local[1]= NIL;
viewportIF3358:
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= fqv[16];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	argv[2] = w;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= fqv[25];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	argv[3] = w;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= fqv[26];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	argv[4] = w;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[28];
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
viewportBLK3354:
	ctx->vsp=local; return(local[0]);}

/*:draw-arc-ndc*/
static pointer viewportM3359viewer_draw_arc_ndc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	if (n>=6) { local[0]=(argv[5]); goto viewportENT3364;}
	local[0]= makeint((eusinteger_t)0L);
viewportENT3364:
	if (n>=7) { local[1]=(argv[6]); goto viewportENT3363;}
	local[1]= makeflt(6.2831853071795862319959e+00);
viewportENT3363:
	if (n>=8) { local[2]=(argv[7]); goto viewportENT3362;}
	local[2]= NIL;
viewportENT3362:
viewportENT3361:
	if (n>8) maerror();
	if (local[2]==NIL) goto viewportIF3365;
	local[3]= argv[0]->c.obj.iv[3];
	local[4]= fqv[18];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto viewportIF3366;
viewportIF3365:
	local[3]= NIL;
viewportIF3366:
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= fqv[16];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	argv[2] = w;
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= fqv[25];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	argv[3] = w;
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= fqv[26];
	local[5]= argv[4];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	argv[4] = w;
	local[3]= argv[0]->c.obj.iv[3];
	local[4]= fqv[29];
	local[5]= argv[2];
	local[6]= argv[3];
	local[7]= argv[4];
	local[8]= local[0];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,7,local+3); /*send*/
	local[0]= w;
viewportBLK3360:
	ctx->vsp=local; return(local[0]);}

/*:draw-fill-arc-ndc*/
static pointer viewportM3367viewer_draw_fill_arc_ndc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<7) maerror();
	if (n>=8) { local[0]=(argv[7]); goto viewportENT3370;}
	local[0]= NIL;
viewportENT3370:
viewportENT3369:
	if (n>8) maerror();
	if (local[0]==NIL) goto viewportIF3371;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[18];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto viewportIF3372;
viewportIF3371:
	local[1]= NIL;
viewportIF3372:
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= fqv[16];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	argv[2] = w;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= fqv[25];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	argv[3] = w;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= fqv[26];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	argv[4] = w;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[30];
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= argv[5];
	local[7]= argv[6];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,7,local+1); /*send*/
	local[0]= w;
viewportBLK3368:
	ctx->vsp=local; return(local[0]);}

/*:draw-polyline-ndc*/
static pointer viewportM3373viewer_draw_polyline_ndc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto viewportENT3376;}
	local[0]= NIL;
viewportENT3376:
viewportENT3375:
	if (n>4) maerror();
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[1];
	local[1]= w;
	local[2]= NIL;
viewportWHL3377:
	if (argv[2]==NIL) goto viewportWHX3378;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[3];
	local[2] = w;
	local[3]= argv[0];
	local[4]= fqv[31];
	local[5]= local[1];
	local[6]= local[2];
	local[7]= T;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,6,local+3); /*send*/
	local[1] = local[2];
	goto viewportWHL3377;
viewportWHX3378:
	local[3]= NIL;
viewportBLK3379:
	w = local[3];
	local[0]= w;
viewportBLK3374:
	ctx->vsp=local; return(local[0]);}

/*:draw-box-ndc*/
static pointer viewportM3380viewer_draw_box_ndc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto viewportENT3383;}
	local[0]= NIL;
viewportENT3383:
viewportENT3382:
	if (n>5) maerror();
	local[1]= argv[2];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)0L));
	  w=makeflt(local[1]->c.fvec.fv[i]);}
	local[1]= w;
	local[2]= argv[2];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)1L));
	  w=makeflt(local[2]->c.fvec.fv[i]);}
	local[2]= w;
	local[3]= argv[3];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)0L));
	  w=makeflt(local[3]->c.fvec.fv[i]);}
	local[3]= w;
	local[4]= argv[3];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)1L));
	  w=makeflt(local[4]->c.fvec.fv[i]);}
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[32];
	local[7]= local[1];
	local[8]= local[2];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	local[8]= local[3];
	local[9]= local[2];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
	local[9]= local[3];
	local[10]= local[4];
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[9]= w;
	local[10]= local[1];
	local[11]= local[4];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)MKFLTVEC(ctx,3,local+10); /*float-vector*/
	local[10]= w;
	local[11]= local[1];
	local[12]= local[2];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,5,local+7); /*list*/
	local[7]= w;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[0]= w;
viewportBLK3381:
	ctx->vsp=local; return(local[0]);}

/*:draw-star-ndc*/
static pointer viewportM3384viewer_draw_star_ndc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto viewportENT3388;}
	local[0]= makeflt(1.9999999999999990007993e-02);
viewportENT3388:
	if (n>=5) { local[1]=(argv[4]); goto viewportENT3387;}
	local[1]= NIL;
viewportENT3387:
viewportENT3386:
	if (n>5) maerror();
	local[2]= argv[0];
	local[3]= fqv[31];
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= argv[2];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	local[6]= T;
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[31];
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= argv[2];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	local[6]= T;
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[0]= w;
viewportBLK3385:
	ctx->vsp=local; return(local[0]);}

/*:draw-line*/
static pointer viewportM3389viewer_draw_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto viewportENT3393;}
	local[0]= T;
viewportENT3393:
	if (n>=6) { local[1]=(argv[5]); goto viewportENT3392;}
	local[1]= NIL;
viewportENT3392:
viewportENT3391:
	if (n>6) maerror();
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= fqv[17];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	argv[2] = w;
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= fqv[17];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	argv[3] = w;
	local[2]= argv[0];
	local[3]= fqv[31];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)RECLAIM(ctx,1,local+2); /*system:reclaim*/
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)RECLAIM(ctx,1,local+2); /*system:reclaim*/
	local[0]= w;
viewportBLK3390:
	ctx->vsp=local; return(local[0]);}

/*:draw-box*/
static pointer viewportM3394viewer_draw_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto viewportENT3398;}
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[5];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeflt(3.0000000000000000000000e+02);
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
viewportENT3398:
	if (n>=5) { local[1]=(argv[4]); goto viewportENT3397;}
	local[1]= NIL;
viewportENT3397:
viewportENT3396:
	if (n>5) maerror();
	local[2]= local[0];
	local[3]= local[0];
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[0] = w;
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= fqv[17];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)HOMO2NORMAL(ctx,1,local+2); /*homo2normal*/
	argv[2] = w;
	local[2]= argv[0];
	local[3]= fqv[33];
	local[4]= argv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)VMINUS(ctx,2,local+4); /*v-*/
	local[4]= w;
	local[5]= argv[2];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)VPLUS(ctx,2,local+5); /*v+*/
	local[5]= w;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	local[0]= w;
viewportBLK3395:
	ctx->vsp=local; return(local[0]);}

/*:draw-polyline*/
static pointer viewportM3399viewer_draw_polyline(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto viewportENT3402;}
	local[0]= NIL;
viewportENT3402:
viewportENT3401:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[32];
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,viewportCLO3403,env,argv,local);
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
viewportBLK3400:
	ctx->vsp=local; return(local[0]);}

/*:draw-arc*/
static pointer viewportM3404viewer_draw_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	if (n>=6) { local[0]=(argv[5]); goto viewportENT3409;}
	local[0]= makeint((eusinteger_t)0L);
viewportENT3409:
	if (n>=7) { local[1]=(argv[6]); goto viewportENT3408;}
	local[1]= makeflt(6.2831853071795862319959e+00);
viewportENT3408:
	if (n>=8) { local[2]=(argv[7]); goto viewportENT3407;}
	local[2]= NIL;
viewportENT3407:
viewportENT3406:
	if (n>8) maerror();
	local[3]= NIL;
	local[4]= NIL;
	if (local[2]==NIL) goto viewportIF3410;
	local[5]= argv[0]->c.obj.iv[3];
	local[6]= fqv[18];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto viewportIF3411;
viewportIF3410:
	local[5]= NIL;
viewportIF3411:
	local[5]= argv[0]->c.obj.iv[1];
	local[6]= fqv[17];
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	argv[2] = w;
	local[5]= argv[0]->c.obj.iv[1];
	local[6]= fqv[34];
	local[7]= argv[3];
	local[8]= argv[4];
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,2,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[4] = w;
	local[5]= argv[0];
	local[6]= fqv[35];
	local[7]= argv[2];
	local[8]= local[4];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,2,local+8); /*aref*/
	local[8]= w;
	local[9]= local[4];
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,2,local+9); /*aref*/
	local[9]= w;
	local[10]= local[0];
	local[11]= local[1];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,8,local+5); /*send*/
	local[0]= w;
viewportBLK3405:
	ctx->vsp=local; return(local[0]);}

/*:draw-fill-arc*/
static pointer viewportM3412viewer_draw_fill_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	if (n>=6) { local[0]=(argv[5]); goto viewportENT3417;}
	local[0]= makeint((eusinteger_t)0L);
viewportENT3417:
	if (n>=7) { local[1]=(argv[6]); goto viewportENT3416;}
	local[1]= makeflt(6.2831853071795862319959e+00);
viewportENT3416:
	if (n>=8) { local[2]=(argv[7]); goto viewportENT3415;}
	local[2]= NIL;
viewportENT3415:
viewportENT3414:
	if (n>8) maerror();
	local[3]= NIL;
	local[4]= NIL;
	if (local[2]==NIL) goto viewportIF3418;
	local[5]= argv[0]->c.obj.iv[3];
	local[6]= fqv[18];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto viewportIF3419;
viewportIF3418:
	local[5]= NIL;
viewportIF3419:
	local[5]= argv[0]->c.obj.iv[1];
	local[6]= fqv[17];
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	argv[2] = w;
	local[5]= argv[0]->c.obj.iv[1];
	local[6]= fqv[34];
	local[7]= argv[3];
	local[8]= argv[4];
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,2,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[4] = w;
	local[5]= argv[0];
	local[6]= fqv[36];
	local[7]= argv[2];
	local[8]= local[4];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,2,local+8); /*aref*/
	local[8]= w;
	local[9]= local[4];
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,2,local+9); /*aref*/
	local[9]= w;
	local[10]= local[0];
	local[11]= local[1];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,8,local+5); /*send*/
	local[0]= w;
viewportBLK3413:
	ctx->vsp=local; return(local[0]);}

/*:draw-arrow*/
static pointer viewportM3420viewer_draw_arrow(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto viewportENT3424;}
	local[0]= T;
viewportENT3424:
	if (n>=6) { local[1]=(argv[5]); goto viewportENT3423;}
	local[1]= NIL;
viewportENT3423:
viewportENT3422:
	ctx->vsp=local+2;
	n=parsekeyparams(fqv[37], &argv[6], n-6, local+2, 0);
	if (n & (1<<0)) goto viewportKEY3425;
	local[2] = fqv[38];
viewportKEY3425:
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= argv[0]->c.obj.iv[1];
	local[8]= fqv[17];
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	argv[2] = w;
	local[7]= argv[0]->c.obj.iv[1];
	local[8]= fqv[17];
	local[9]= argv[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	argv[3] = w;
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)HOMO2NORMAL(ctx,1,local+7); /*homo2normal*/
	argv[2] = w;
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(pointer)HOMO2NORMAL(ctx,1,local+7); /*homo2normal*/
	argv[3] = w;
	local[7]= argv[2];
	local[8]= argv[3];
	ctx->vsp=local+9;
	w=(pointer)VMINUS(ctx,2,local+7); /*v-*/
	local[3] = w;
	local[7]= makeflt(2.9999999999999982236432e-01);
	local[8]= local[3];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,3,local+7); /*scale*/
	local[7]= local[2];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[3];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= local[2];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[3];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[4] = w;
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+10;
	w=(pointer)SETELT(ctx,3,local+7); /*setelt*/
	local[7]= local[2];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[3];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,3,local+7); /*scale*/
	local[7]= argv[3];
	local[8]= makeflt(5.0000000000000000000000e-01);
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)VPLUS(ctx,2,local+7); /*v+*/
	local[7]= w;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)VPLUS(ctx,2,local+7); /*v+*/
	local[5] = w;
	local[7]= argv[3];
	local[8]= makeflt(-5.0000000000000000000000e-01);
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)VPLUS(ctx,2,local+7); /*v+*/
	local[7]= w;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)VPLUS(ctx,2,local+7); /*v+*/
	local[6] = w;
	local[7]= argv[0];
	local[8]= fqv[31];
	local[9]= argv[2];
	local[10]= argv[3];
	local[11]= local[0];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,6,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[31];
	local[9]= local[5];
	local[10]= argv[3];
	local[11]= local[0];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,6,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[31];
	local[9]= local[6];
	local[10]= argv[3];
	local[11]= local[0];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,6,local+7); /*send*/
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)RECLAIM(ctx,1,local+7); /*system:reclaim*/
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(pointer)RECLAIM(ctx,1,local+7); /*system:reclaim*/
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)RECLAIM(ctx,1,local+7); /*system:reclaim*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)RECLAIM(ctx,1,local+7); /*system:reclaim*/
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)RECLAIM(ctx,1,local+7); /*system:reclaim*/
	local[0]= w;
viewportBLK3421:
	ctx->vsp=local; return(local[0]);}

/*:pane*/
static pointer viewportM3426viewer_pane(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[33];
	local[2]= fqv[39];
	local[3]= fqv[40];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
viewportBLK3427:
	ctx->vsp=local; return(local[0]);}

/*:draw-star*/
static pointer viewportM3428viewer_draw_star(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto viewportENT3432;}
	local[0]= NIL;
viewportENT3432:
	if (n>=5) { local[1]=(argv[4]); goto viewportENT3431;}
	local[1]= NIL;
viewportENT3431:
viewportENT3430:
	if (n>5) maerror();
	if (local[0]!=NIL) goto viewportIF3433;
	local[0] = makeflt(1.9999999999999990007993e-02);
	local[2]= local[0];
	goto viewportIF3434;
viewportIF3433:
	local[2]= NIL;
viewportIF3434:
	local[2]= argv[0];
	local[3]= fqv[41];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= fqv[17];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)HOMO2NORMAL(ctx,1,local+4); /*homo2normal*/
	local[4]= w;
	local[5]= local[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	local[0]= w;
viewportBLK3429:
	ctx->vsp=local; return(local[0]);}

/*:draw-2dlnseg*/
static pointer viewportM3435viewer_draw_2dlnseg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[21];
	local[2]= argv[2];
	local[3]= fqv[42];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= fqv[43];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
viewportBLK3436:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer viewportCLO3403(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0]->c.obj.iv[1];
	local[1]= fqv[17];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:draw-edge-image*/
static pointer viewportM3437viewer_draw_edge_image(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto viewportENT3441;}
	local[0]= NIL;
viewportENT3441:
	if (n>=5) { local[1]=(argv[4]); goto viewportENT3440;}
	local[1]= argv[2];
	local[2]= fqv[18];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
viewportENT3440:
viewportENT3439:
	if (n>5) maerror();
	local[2]= NIL;
	local[3]= argv[2];
	local[4]= fqv[44];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
viewportWHL3442:
	if (local[3]==NIL) goto viewportWHX3443;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= argv[0];
	local[5]= fqv[31];
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= NIL;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,6,local+4); /*send*/
	goto viewportWHL3442;
viewportWHX3443:
	local[4]= NIL;
viewportBLK3444:
	w = NIL;
	if (local[0]==NIL) goto viewportIF3445;
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= fqv[45];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= NIL;
	local[3]= argv[2];
	local[4]= fqv[46];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
viewportWHL3447:
	if (local[3]==NIL) goto viewportWHX3448;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= argv[0];
	local[5]= fqv[31];
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= NIL;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,6,local+4); /*send*/
	goto viewportWHL3447;
viewportWHX3448:
	local[4]= NIL;
viewportBLK3449:
	w = NIL;
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= fqv[45];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto viewportIF3446;
viewportIF3445:
	local[2]= NIL;
viewportIF3446:
	w = local[2];
	local[0]= w;
viewportBLK3438:
	ctx->vsp=local; return(local[0]);}

/*:draw-edge*/
static pointer viewportM3450viewer_draw_edge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto viewportENT3453;}
	local[0]= NIL;
viewportENT3453:
viewportENT3452:
	if (n>4) maerror();
	if (local[0]==NIL) goto viewportIF3454;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[18];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto viewportIF3455;
viewportIF3454:
	local[1]= NIL;
viewportIF3455:
	local[1]= argv[0];
	local[2]= fqv[21];
	local[3]= argv[2]->c.obj.iv[1];
	local[4]= argv[2]->c.obj.iv[2];
	local[5]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
viewportBLK3451:
	ctx->vsp=local; return(local[0]);}

/*:draw-faces*/
static pointer viewportM3456viewer_draw_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto viewportENT3460;}
	local[0]= NIL;
viewportENT3460:
	if (n>=5) { local[1]=(argv[4]); goto viewportENT3459;}
	local[1]= NIL;
viewportENT3459:
viewportENT3458:
	if (n>5) maerror();
	local[2]= NIL;
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= fqv[47];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= argv[2];
viewportWHL3461:
	if (local[7]==NIL) goto viewportWHX3462;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	if (local[0]==NIL) goto viewportAND3466;
	local[8]= local[6];
	local[9]= fqv[48];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto viewportAND3466;
	goto viewportIF3464;
viewportAND3466:
	if (local[1]==NIL) goto viewportIF3467;
	local[8]= local[1];
	goto viewportIF3468;
viewportIF3467:
	local[8]= local[6];
	local[9]= fqv[18];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
viewportIF3468:
	local[5] = local[8];
	local[8]= NIL;
	local[9]= local[6];
	local[10]= fqv[49];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
viewportWHL3469:
	if (local[9]==NIL) goto viewportWHX3470;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[8];
	w = local[2];
	if (memq(local[10],w)!=NIL) goto viewportIF3472;
	local[10]= argv[0];
	local[11]= fqv[50];
	local[12]= local[8];
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,4,local+10); /*send*/
	local[10]= local[8];
	w = local[2];
	ctx->vsp=local+11;
	local[2] = cons(ctx,local[10],w);
	local[10]= local[2];
	goto viewportIF3473;
viewportIF3472:
	local[10]= NIL;
viewportIF3473:
	goto viewportWHL3469;
viewportWHX3470:
	local[10]= NIL;
viewportBLK3471:
	w = NIL;
	local[8]= w;
	goto viewportIF3465;
viewportIF3464:
	local[8]= NIL;
viewportIF3465:
	goto viewportWHL3461;
viewportWHX3462:
	local[8]= NIL;
viewportBLK3463:
	w = NIL;
viewportWHL3474:
	if (local[2]==NIL) goto viewportWHX3475;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)RECLAIM(ctx,1,local+6); /*system:reclaim*/
	local[2] = local[4];
	goto viewportWHL3474;
viewportWHX3475:
	local[6]= NIL;
viewportBLK3476:
	w = local[6];
	local[0]= w;
viewportBLK3457:
	ctx->vsp=local; return(local[0]);}

/*:draw-body*/
static pointer viewportM3477viewer_draw_body(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto viewportENT3480;}
	local[0]= T;
viewportENT3480:
viewportENT3479:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= fqv[51];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[52];
	local[3]= argv[2];
	local[4]= fqv[53];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= local[0];
	local[5]= argv[2];
	local[6]= fqv[18];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
viewportBLK3478:
	ctx->vsp=local; return(local[0]);}

/*:draw-axis*/
static pointer viewportM3481viewer_draw_axis(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto viewportENT3484;}
	local[0]= NIL;
viewportENT3484:
viewportENT3483:
	if (n>4) maerror();
	if (local[0]!=NIL) goto viewportIF3485;
	local[0] = makeflt(1.0000000000000000000000e+00);
	local[1]= local[0];
	goto viewportIF3486;
viewportIF3485:
	local[1]= NIL;
viewportIF3486:
	local[1]= argv[2];
	local[2]= fqv[54];
	local[3]= fqv[55];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= local[0];
	local[3]= makeflt(2.9999999999999982236432e-01);
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= fqv[54];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[21];
	local[7]= local[1];
	local[8]= argv[2];
	local[9]= fqv[54];
	local[10]= local[0];
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)MKFLTVEC(ctx,3,local+10); /*float-vector*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[21];
	local[7]= local[1];
	local[8]= argv[2];
	local[9]= fqv[54];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[0];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)MKFLTVEC(ctx,3,local+10); /*float-vector*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[21];
	local[7]= local[1];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[21];
	local[7]= local[4];
	local[8]= argv[2];
	local[9]= fqv[54];
	local[10]= local[3];
	local[11]= local[2];
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,1,local+13); /*-*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)VPLUS(ctx,2,local+10); /*v+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[21];
	local[7]= local[4];
	local[8]= argv[2];
	local[9]= fqv[54];
	local[10]= local[3];
	local[11]= makeint((eusinteger_t)0L);
	local[12]= local[2];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,1,local+13); /*-*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)VPLUS(ctx,2,local+10); /*v+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[0]= w;
viewportBLK3482:
	ctx->vsp=local; return(local[0]);}

/*:draw-one*/
static pointer viewportM3487viewer_draw_one(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	w = argv[2];
	if (!isnum(w)) goto viewportCON3490;
	local[0]= NIL;
	goto viewportCON3489;
viewportCON3490:
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto viewportCON3491;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[0]); /*float-vector-p*/
	if (w==NIL) goto viewportCON3493;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= local[0];
	w = fqv[56];
	if (memq(local[1],w)==NIL) goto viewportIF3494;
	local[1]= argv[0];
	local[2]= fqv[21];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto viewportIF3495;
viewportIF3494:
	local[1]= local[0];
	if (fqv[57]!=local[1]) goto viewportIF3496;
	local[1]= argv[0];
	local[2]= fqv[31];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto viewportIF3497;
viewportIF3496:
	if (T==NIL) goto viewportIF3498;
	local[1]= fqv[58];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
	goto viewportIF3499;
viewportIF3498:
	local[1]= NIL;
viewportIF3499:
viewportIF3497:
viewportIF3495:
	w = local[1];
	local[0]= w;
	goto viewportCON3492;
viewportCON3493:
	local[0]= NIL;
	local[1]= argv[2];
viewportWHL3501:
	if (local[1]==NIL) goto viewportWHX3502;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= argv[0];
	local[3]= fqv[59];
	local[4]= local[0];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	goto viewportWHL3501;
viewportWHX3502:
	local[2]= NIL;
viewportBLK3503:
	w = NIL;
	local[0]= w;
	goto viewportCON3492;
viewportCON3500:
	local[0]= NIL;
viewportCON3492:
	goto viewportCON3489;
viewportCON3491:
	local[0]= argv[2];
	local[1]= fqv[60];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[61]); /*find-method*/
	if (w==NIL) goto viewportCON3504;
	local[0]= argv[2];
	local[1]= fqv[60];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto viewportCON3489;
viewportCON3504:
	local[0]= argv[2];
	local[1]= fqv[62];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[61]); /*find-method*/
	if (w==NIL) goto viewportCON3505;
	local[0]= argv[2];
	local[1]= fqv[51];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[61]); /*find-method*/
	if (w==NIL) goto viewportIF3506;
	local[0]= argv[2];
	local[1]= fqv[51];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto viewportIF3507;
viewportIF3506:
	local[0]= NIL;
viewportIF3507:
	local[0]= argv[0];
	local[1]= fqv[59];
	local[2]= argv[2];
	local[3]= fqv[62];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto viewportCON3489;
viewportCON3505:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[63]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto viewportCON3508;
	local[0]= argv[0];
	local[1]= fqv[50];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto viewportCON3489;
viewportCON3508:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[64]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto viewportCON3509;
	local[0]= argv[0];
	local[1]= fqv[65];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto viewportCON3489;
viewportCON3509:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[66]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto viewportCON3510;
	local[0]= argv[2];
	local[1]= fqv[51];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[2];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= argv[2];
	local[3]= fqv[67];
	local[4]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
viewportWHL3511:
	if (local[2]==NIL) goto viewportWHX3512;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= argv[0];
	local[4]= fqv[50];
	local[5]= local[1];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	goto viewportWHL3511;
viewportWHX3512:
	local[3]= NIL;
viewportBLK3513:
	w = NIL;
	local[0]= w;
	goto viewportCON3489;
viewportCON3510:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[68]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto viewportCON3514;
	local[0]= argv[2];
	local[1]= fqv[51];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[2];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= argv[2];
	local[3]= fqv[69];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
viewportWHL3515:
	if (local[2]==NIL) goto viewportWHX3516;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= argv[0];
	local[4]= fqv[50];
	local[5]= local[1];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	goto viewportWHL3515;
viewportWHX3516:
	local[3]= NIL;
viewportBLK3517:
	w = NIL;
	local[0]= w;
	goto viewportCON3489;
viewportCON3514:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[70]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto viewportCON3518;
	local[0]= argv[0];
	local[1]= fqv[52];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto viewportCON3489;
viewportCON3518:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[71]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto viewportCON3519;
	local[0]= NIL;
	local[1]= argv[2];
	local[2]= fqv[69];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
viewportWHL3520:
	if (local[1]==NIL) goto viewportWHX3521;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= argv[0];
	local[3]= fqv[50];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	goto viewportWHL3520;
viewportWHX3521:
	local[2]= NIL;
viewportBLK3522:
	w = NIL;
	local[0]= w;
	goto viewportCON3489;
viewportCON3519:
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[0]); /*float-vector-p*/
	if (w==NIL) goto viewportCON3523;
	local[0]= argv[0];
	local[1]= fqv[72];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[3];
	goto viewportCON3489;
viewportCON3523:
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[3])(ctx,1,local+0,&ftab[3],fqv[73]); /*coordinates-p*/
	if (w==NIL) goto viewportCON3524;
	local[0]= argv[0];
	local[1]= fqv[74];
	local[2]= argv[2];
	local[3]= fqv[51];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto viewportCON3489;
viewportCON3524:
	local[0]= fqv[75];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w==NIL) goto viewportCON3525;
	local[0]= argv[2];
	local[1]= loadglobal(fqv[75]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto viewportCON3525;
	local[0]= argv[0];
	local[1]= fqv[76];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto viewportCON3489;
viewportCON3525:
	local[0]= fqv[77];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w==NIL) goto viewportCON3526;
	local[0]= argv[2];
	local[1]= loadglobal(fqv[77]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto viewportCON3526;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[78];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto viewportCON3489;
viewportCON3526:
	local[0]= fqv[79];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w==NIL) goto viewportCON3527;
	local[0]= argv[2];
	local[1]= loadglobal(fqv[79]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto viewportCON3527;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[18];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto viewportCON3489;
viewportCON3527:
	local[0]= NIL;
viewportCON3489:
	w = local[0];
	local[0]= w;
viewportBLK3488:
	ctx->vsp=local; return(local[0]);}

/*:draw*/
static pointer viewportM3528viewer_draw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto viewportENT3531;}
	local[0]= NIL;
viewportENT3531:
viewportENT3530:
	if (n>4) maerror();
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w==NIL) goto viewportCON3533;
	local[1]= NIL;
	local[2]= argv[2];
viewportWHL3534:
	if (local[2]==NIL) goto viewportWHX3535;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= argv[0];
	local[4]= fqv[59];
	local[5]= local[1];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	goto viewportWHL3534;
viewportWHX3535:
	local[3]= NIL;
viewportBLK3536:
	w = NIL;
	local[1]= w;
	goto viewportCON3532;
viewportCON3533:
	if (argv[2]==NIL) goto viewportCON3537;
	local[1]= argv[0];
	local[2]= fqv[59];
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto viewportCON3532;
viewportCON3537:
	local[1]= NIL;
viewportCON3532:
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[15];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = T;
	local[0]= w;
viewportBLK3529:
	ctx->vsp=local; return(local[0]);}

/*:erase*/
static pointer viewportM3538viewer_erase(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[80];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[60];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[81];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
viewportBLK3539:
	ctx->vsp=local; return(local[0]);}

/*:clear*/
static pointer viewportM3540viewer_clear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[82];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[15];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
viewportBLK3541:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer viewportM3542viewer_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[83], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto viewportKEY3544;
	local[0] = NIL;
viewportKEY3544:
	if (n & (1<<1)) goto viewportKEY3545;
	local[1] = NIL;
viewportKEY3545:
	if (n & (1<<2)) goto viewportKEY3546;
	local[2] = NIL;
viewportKEY3546:
	if (n & (1<<3)) goto viewportKEY3547;
	local[3] = NIL;
viewportKEY3547:
	if (n & (1<<4)) goto viewportKEY3548;
	local[4] = NIL;
viewportKEY3548:
	local[5]= argv[0];
	local[6]= local[4];
	local[7]= fqv[84];
	ctx->vsp=local+8;
	w=(pointer)PUTPROP(ctx,3,local+5); /*putprop*/
	argv[0]->c.obj.iv[1] = local[0];
	argv[0]->c.obj.iv[2] = local[1];
	argv[0]->c.obj.iv[3] = local[2];
	local[5]= local[3];
	storeglobal(fqv[85],local[5]);
	local[5]= argv[0];
	w = loadglobal(fqv[86]);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	storeglobal(fqv[86],local[5]);
	w = argv[0];
	local[0]= w;
viewportBLK3543:
	ctx->vsp=local; return(local[0]);}

/*:adjust-viewport*/
static pointer viewportM3549viewer_adjust_viewport(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto viewportENT3555;}
	local[0]= NIL;
viewportENT3555:
	if (n>=4) { local[1]=(argv[3]); goto viewportENT3554;}
	local[1]= NIL;
viewportENT3554:
	if (n>=5) { local[2]=(argv[4]); goto viewportENT3553;}
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
viewportENT3553:
	if (n>=6) { local[3]=(argv[5]); goto viewportENT3552;}
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
viewportENT3552:
viewportENT3551:
	if (n>6) maerror();
	if (local[0]!=NIL) goto viewportIF3556;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[0] = w;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[6];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[1] = w;
	local[4]= local[1];
	goto viewportIF3557;
viewportIF3556:
	local[4]= NIL;
viewportIF3557:
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= fqv[87];
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= fqv[88];
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[0]= w;
viewportBLK3550:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer viewportM3558viewer_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto viewportENT3561;}
	local[0]= argv[2];
viewportENT3561:
viewportENT3560:
	if (n>4) maerror();
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[89];
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[15];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[90];
	local[3]= argv[2];
	local[4]= local[0];
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= fqv[91];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)EUSFLOAT(ctx,1,local+3); /*float*/
	local[3]= w;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
viewportBLK3559:
	ctx->vsp=local; return(local[0]);}

/*draw*/
static pointer viewportF3202draw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
viewportRST3563:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= loadglobal(fqv[92]);
	ctx->vsp=local+6;
	w=(pointer)DERIVEDP(ctx,2,local+4); /*derivedp*/
	if (w==NIL) goto viewportIF3564;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	goto viewportIF3565;
viewportIF3564:
	local[4]= loadglobal(fqv[93]);
viewportIF3565:
	local[2] = local[4];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!isint(w)) goto viewportIF3566;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	local[3] = w;
	local[4]= local[2];
	local[5]= fqv[94];
	local[6]= fqv[95];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto viewportIF3567;
viewportIF3566:
	local[4]= NIL;
viewportIF3567:
	local[4]= NIL;
	local[5]= local[0];
viewportWHL3568:
	if (local[5]==NIL) goto viewportWHX3569;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[2];
	local[7]= fqv[60];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	goto viewportWHL3568;
viewportWHX3569:
	local[6]= NIL;
viewportBLK3570:
	w = NIL;
	w = local[3];
	if (!isint(w)) goto viewportIF3571;
	local[4]= local[2];
	local[5]= fqv[94];
	local[6]= fqv[95];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto viewportIF3572;
viewportIF3571:
	local[4]= NIL;
viewportIF3572:
	w = local[4];
	local[0]= w;
viewportBLK3562:
	ctx->vsp=local; return(local[0]);}

/*draw-tree*/
static pointer viewportF3203draw_tree(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
viewportRST3574:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= NIL;
	local[2]= NIL;
viewportWHL3575:
	if (local[0]==NIL) goto viewportWHX3576;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	local[4]= loadglobal(fqv[68]);
	ctx->vsp=local+5;
	w=(pointer)DERIVEDP(ctx,2,local+3); /*derivedp*/
	if (w==NIL) goto viewportIF3578;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)viewportF3202draw(ctx,1,local+3); /*draw*/
	local[3]= w;
	goto viewportIF3579;
viewportIF3578:
	local[3]= NIL;
viewportIF3579:
	local[3]= local[1];
	local[4]= fqv[96];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[2] = w;
	local[3]= NIL;
	local[4]= local[2];
viewportWHL3580:
	if (local[4]==NIL) goto viewportWHX3581;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3];
	w = local[0];
	ctx->vsp=local+6;
	local[0] = cons(ctx,local[5],w);
	goto viewportWHL3580;
viewportWHX3581:
	local[5]= NIL;
viewportBLK3582:
	w = NIL;
	goto viewportWHL3575;
viewportWHX3576:
	local[3]= NIL;
viewportBLK3577:
	w = local[3];
	local[0]= w;
viewportBLK3573:
	ctx->vsp=local; return(local[0]);}

/*erase*/
static pointer viewportF3204erase(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
viewportRST3584:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= NIL;
	local[2]= loadglobal(fqv[93]);
	local[3]= NIL;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= loadglobal(fqv[92]);
	ctx->vsp=local+6;
	w=(pointer)DERIVEDP(ctx,2,local+4); /*derivedp*/
	if (w==NIL) goto viewportIF3585;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	goto viewportIF3586;
viewportIF3585:
	local[4]= NIL;
viewportIF3586:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!isint(w)) goto viewportIF3587;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	local[3] = w;
	local[4]= local[2];
	local[5]= fqv[94];
	local[6]= fqv[95];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto viewportIF3588;
viewportIF3587:
	local[4]= NIL;
viewportIF3588:
	local[4]= local[2];
	local[5]= fqv[97];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	w = local[3];
	if (!isint(w)) goto viewportIF3589;
	local[4]= local[2];
	local[5]= fqv[94];
	local[6]= fqv[95];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto viewportIF3590;
viewportIF3589:
	local[4]= NIL;
viewportIF3590:
	w = local[4];
	local[0]= w;
viewportBLK3583:
	ctx->vsp=local; return(local[0]);}

/*draw-axis*/
static pointer viewportF3205draw_axis(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
viewportRST3592:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= NIL;
	local[2]= loadglobal(fqv[93]);
	local[3]= makeflt(1.0000000000000000000000e+01);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= loadglobal(fqv[92]);
	ctx->vsp=local+6;
	w=(pointer)DERIVEDP(ctx,2,local+4); /*derivedp*/
	if (w==NIL) goto viewportIF3593;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	goto viewportIF3594;
viewportIF3593:
	local[4]= NIL;
viewportIF3594:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!isnum(w)) goto viewportIF3595;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	local[3] = w;
	local[4]= local[3];
	goto viewportIF3596;
viewportIF3595:
	local[4]= NIL;
viewportIF3596:
	local[4]= NIL;
	local[5]= local[0];
viewportWHL3597:
	if (local[5]==NIL) goto viewportWHX3598;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[2];
	local[7]= fqv[74];
	local[8]= local[4];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	goto viewportWHL3597;
viewportWHX3598:
	local[6]= NIL;
viewportBLK3599:
	w = NIL;
	local[4]= local[2];
	local[5]= fqv[94];
	local[6]= fqv[15];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[0]= w;
viewportBLK3591:
	ctx->vsp=local; return(local[0]);}

/*draw-arrow*/
static pointer viewportF3206draw_arrow(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[93]);
	local[1]= fqv[98];
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= loadglobal(fqv[99]);
	local[1]= fqv[15];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
viewportBLK3600:
	ctx->vsp=local; return(local[0]);}

/*hid*/
static pointer viewportF3207hid(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
viewportRST3602:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= NIL;
	local[2]= loadglobal(fqv[93]);
	local[3]= NIL;
	local[4]= NIL;
	local[5]= T;
	local[6]= makeflt(0.0000000000000000000000e+00);
	local[7]= makeflt(0.0000000000000000000000e+00);
	local[8]= makeflt(0.0000000000000000000000e+00);
	local[9]= makeflt(0.0000000000000000000000e+00);
	w = local[9];
	ctx->vsp=local+10;
	bindspecial(ctx,fqv[100],w);
	w = local[8];
	ctx->vsp=local+13;
	bindspecial(ctx,fqv[101],w);
	w = local[7];
	ctx->vsp=local+16;
	bindspecial(ctx,fqv[102],w);
	w = local[6];
	ctx->vsp=local+19;
	bindspecial(ctx,fqv[103],w);
	w = local[5];
	ctx->vsp=local+22;
	bindspecial(ctx,fqv[104],w);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[25]= (w)->c.cons.car;
	local[26]= loadglobal(fqv[92]);
	ctx->vsp=local+27;
	w=(pointer)DERIVEDP(ctx,2,local+25); /*derivedp*/
	if (w==NIL) goto viewportIF3603;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[25]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[25];
	local[2] = w;
	local[25]= local[2];
	goto viewportIF3604;
viewportIF3603:
	local[25]= NIL;
viewportIF3604:
	local[25]= NIL;
	local[26]= local[0];
	ctx->vsp=local+27;
	w=(*ftab[4])(ctx,1,local+26,&ftab[4],fqv[105]); /*flatten*/
	local[26]= w;
viewportWHL3605:
	if (local[26]==NIL) goto viewportWHX3606;
	w=local[26];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[27]= (w)->c.cons.car;
	w=local[26];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26] = (w)->c.cons.cdr;
	w = local[27];
	local[25] = w;
	local[27]= local[25];
	local[28]= fqv[62];
	ctx->vsp=local+29;
	w=(*ftab[2])(ctx,2,local+27,&ftab[2],fqv[61]); /*find-method*/
	if (w==NIL) goto viewportIF3608;
	local[27]= local[25];
	local[28]= fqv[62];
	ctx->vsp=local+29;
	w=(pointer)SEND(ctx,2,local+27); /*send*/
	local[27]= w;
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(pointer)APPEND(ctx,2,local+27); /*append*/
	local[3] = w;
	local[27]= local[3];
	goto viewportIF3609;
viewportIF3608:
	local[27]= local[25];
	w = local[3];
	ctx->vsp=local+28;
	local[3] = cons(ctx,local[27],w);
	local[27]= local[3];
viewportIF3609:
	goto viewportWHL3605;
viewportWHX3606:
	local[27]= NIL;
viewportBLK3607:
	w = NIL;
	local[25]= local[3];
	local[26]= local[2];
	local[27]= fqv[106];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,2,local+26); /*send*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(*ftab[5])(ctx,2,local+25,&ftab[5],fqv[107]); /*hid2*/
	local[25]= local[2];
	local[26]= fqv[60];
	local[27]= loadglobal(fqv[108]);
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,3,local+25); /*send*/
	local[25]= w;
	ctx->vsp=local+26;
	unbindx(ctx,5);
	w = local[25];
	local[0]= w;
viewportBLK3601:
	ctx->vsp=local; return(local[0]);}

/*hidd*/
static pointer viewportF3208hidd(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
viewportRST3611:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= NIL;
	local[2]= loadglobal(fqv[93]);
	local[3]= NIL;
	local[4]= NIL;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= loadglobal(fqv[92]);
	ctx->vsp=local+7;
	w=(pointer)DERIVEDP(ctx,2,local+5); /*derivedp*/
	if (w==NIL) goto viewportIF3612;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[5];
	local[2] = w;
	local[5]= local[2];
	goto viewportIF3613;
viewportIF3612:
	local[5]= NIL;
viewportIF3613:
	local[5]= NIL;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,1,local+6,&ftab[4],fqv[105]); /*flatten*/
	local[6]= w;
viewportWHL3614:
	if (local[6]==NIL) goto viewportWHX3615;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[5];
	local[8]= fqv[62];
	ctx->vsp=local+9;
	w=(*ftab[2])(ctx,2,local+7,&ftab[2],fqv[61]); /*find-method*/
	if (w==NIL) goto viewportIF3617;
	local[7]= local[5];
	local[8]= fqv[62];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	local[3] = w;
	local[7]= local[3];
	goto viewportIF3618;
viewportIF3617:
	local[7]= local[5];
	w = local[3];
	ctx->vsp=local+8;
	local[3] = cons(ctx,local[7],w);
	local[7]= local[3];
viewportIF3618:
	goto viewportWHL3614;
viewportWHX3615:
	local[7]= NIL;
viewportBLK3616:
	w = NIL;
	local[5]= makeflt(0.0000000000000000000000e+00);
	local[6]= makeflt(0.0000000000000000000000e+00);
	local[7]= makeflt(0.0000000000000000000000e+00);
	local[8]= makeflt(0.0000000000000000000000e+00);
	w = local[8];
	ctx->vsp=local+9;
	bindspecial(ctx,fqv[100],w);
	w = local[7];
	ctx->vsp=local+12;
	bindspecial(ctx,fqv[101],w);
	w = local[6];
	ctx->vsp=local+15;
	bindspecial(ctx,fqv[102],w);
	w = local[5];
	ctx->vsp=local+18;
	bindspecial(ctx,fqv[103],w);
	local[21]= local[3];
	local[22]= local[2];
	local[23]= fqv[106];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,2,local+22); /*send*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(*ftab[5])(ctx,2,local+21,&ftab[5],fqv[107]); /*hid2*/
	local[21]= w;
	ctx->vsp=local+22;
	unbindx(ctx,4);
	w = local[21];
	local[5]= NIL;
	local[6]= loadglobal(fqv[108]);
viewportWHL3619:
	if (local[6]==NIL) goto viewportWHX3620;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[2];
	local[8]= fqv[65];
	local[9]= local[5];
	local[10]= T;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	goto viewportWHL3619;
viewportWHX3620:
	local[7]= NIL;
viewportBLK3621:
	w = NIL;
	if (loadglobal(fqv[109])==NIL) goto viewportIF3622;
	local[5]= local[2];
	local[6]= fqv[94];
	local[7]= fqv[45];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= NIL;
	local[6]= loadglobal(fqv[110]);
viewportWHL3624:
	if (local[6]==NIL) goto viewportWHX3625;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	if (loadglobal(fqv[104])==NIL) goto viewportAND3629;
	local[7]= local[5];
	local[8]= fqv[111];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	if (w==NIL) goto viewportAND3629;
	goto viewportIF3627;
viewportAND3629:
	local[7]= local[2];
	local[8]= fqv[50];
	local[9]= local[5];
	local[10]= local[5];
	local[11]= fqv[18];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= w;
	goto viewportIF3628;
viewportIF3627:
	local[7]= NIL;
viewportIF3628:
	goto viewportWHL3624;
viewportWHX3625:
	local[7]= NIL;
viewportBLK3626:
	w = NIL;
	local[5]= local[2];
	local[6]= fqv[94];
	local[7]= fqv[45];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	goto viewportIF3623;
viewportIF3622:
	local[5]= NIL;
viewportIF3623:
	local[5]= local[2];
	local[6]= fqv[94];
	local[7]= fqv[15];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[0]= w;
viewportBLK3610:
	ctx->vsp=local; return(local[0]);}

/*cls*/
static pointer viewportF3209cls(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto viewportENT3632;}
	local[0]= loadglobal(fqv[93]);
viewportENT3632:
viewportENT3631:
	if (n>1) maerror();
	local[1]= local[0];
	local[2]= fqv[94];
	local[3]= fqv[82];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= local[0];
	local[2]= fqv[94];
	local[3]= fqv[15];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
viewportBLK3630:
	ctx->vsp=local; return(local[0]);}

/*draw-hid*/
static pointer viewportF3210draw_hid(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto viewportENT3635;}
	local[0]= loadglobal(fqv[93]);
viewportENT3635:
viewportENT3634:
	if (n>2) maerror();
	local[1]= NIL;
	local[2]= argv[0];
viewportWHL3636:
	if (local[2]==NIL) goto viewportWHX3637;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[0];
	local[4]= fqv[31];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,5,local+3); /*send*/
	goto viewportWHL3636;
viewportWHX3637:
	local[3]= NIL;
viewportBLK3638:
	w = NIL;
	ctx->vsp=local+1;
	w=(*ftab[6])(ctx,0,local+1,&ftab[6],fqv[112]); /*xflush*/
	local[0]= w;
viewportBLK3633:
	ctx->vsp=local; return(local[0]);}

/*draw-step*/
static pointer viewportF3211draw_step(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
viewportRST3640:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= NIL;
	local[2]= loadglobal(fqv[93]);
	w = local[2];
	ctx->vsp=local+2;
	bindspecial(ctx,fqv[93],w);
	local[5]= makeint((eusinteger_t)3L);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= loadglobal(fqv[92]);
	ctx->vsp=local+8;
	w=(pointer)DERIVEDP(ctx,2,local+6); /*derivedp*/
	if (w==NIL) goto viewportIF3641;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[6];
	local[6]= w;
	storeglobal(fqv[93],w);
	goto viewportIF3642;
viewportIF3641:
	local[6]= NIL;
viewportIF3642:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!isint(w)) goto viewportIF3643;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[6];
	local[5] = w;
	local[6]= local[5];
	goto viewportIF3644;
viewportIF3643:
	local[6]= NIL;
viewportIF3644:
	ctx->vsp=local+6;
	w = makeclosure(codevec,quotevec,viewportUWP3645,env,argv,local);
	local[6]=(pointer)(ctx->protfp); local[7]=w;
	ctx->protfp=(struct protectframe *)(local+6);
	local[8]= NIL;
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,1,local+9,&ftab[4],fqv[105]); /*flatten*/
	local[9]= w;
viewportWHL3646:
	if (local[9]==NIL) goto viewportWHX3647;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= loadglobal(fqv[93]);
	local[11]= fqv[94];
	local[12]= fqv[95];
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,4,local+10); /*send*/
	local[10]= loadglobal(fqv[93]);
	local[11]= fqv[94];
	local[12]= fqv[113];
	local[13]= makeint((eusinteger_t)6L);
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,4,local+10); /*send*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)PRINT(ctx,1,local+10); /*print*/
	local[10]= loadglobal(fqv[93]);
	local[11]= fqv[60];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	ctx->vsp=local+10;
	w=(pointer)READCH(ctx,0,local+10); /*read-char*/
	local[10]= w;
	local[11]= local[10];
	local[12]= makeint((eusinteger_t)113L);
	ctx->vsp=local+13;
	w=(pointer)EQ(ctx,2,local+11); /*eql*/
	if (w==NIL) goto viewportIF3649;
	w = local[8];
	ctx->vsp=local+11;
	unwind(ctx,local+0);
	local[0]=w;
	goto viewportBLK3639;
	goto viewportIF3650;
viewportIF3649:
	local[11]= NIL;
viewportIF3650:
	w = local[11];
	local[10]= loadglobal(fqv[93]);
	local[11]= fqv[60];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= loadglobal(fqv[93]);
	local[11]= fqv[94];
	local[12]= fqv[95];
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,4,local+10); /*send*/
	local[10]= loadglobal(fqv[93]);
	local[11]= fqv[94];
	local[12]= fqv[113];
	local[13]= makeint((eusinteger_t)15L);
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,4,local+10); /*send*/
	local[10]= loadglobal(fqv[93]);
	local[11]= fqv[60];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)viewportF3202draw(ctx,3,local+10); /*draw*/
	goto viewportWHL3646;
viewportWHX3647:
	local[10]= NIL;
viewportBLK3648:
	w = NIL;
	ctx->vsp=local+8;
	viewportUWP3645(ctx,0,local+8,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[6]= w;
	ctx->vsp=local+7;
	unbindx(ctx,1);
	w = local[6];
	local[0]= w;
viewportBLK3639:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer viewportUWP3645(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= loadglobal(fqv[93]);
	local[1]= fqv[94];
	local[2]= fqv[95];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= loadglobal(fqv[93]);
	local[1]= fqv[94];
	local[2]= fqv[113];
	local[3]= makeint((eusinteger_t)15L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*find-viewer*/
static pointer viewportF3212find_viewer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,viewportCLO3652,env,argv,local);
	local[1]= loadglobal(fqv[86]);
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,2,local+0,&ftab[7],fqv[114]); /*find-if*/
	local[0]= w;
viewportBLK3651:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer viewportCLO3652(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[84];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[8])(ctx,2,local+0,&ftab[8],fqv[115]); /*string-equal*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*view*/
static pointer viewportF3213view(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
viewportRST3654:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[116], &argv[0], n-0, local+1, 1);
	if (n & (1<<0)) goto viewportKEY3655;
	local[1] = NIL;
viewportKEY3655:
	if (n & (1<<1)) goto viewportKEY3656;
	local[2] = NIL;
viewportKEY3656:
	if (n & (1<<2)) goto viewportKEY3657;
	local[3] = NIL;
viewportKEY3657:
	if (n & (1<<3)) goto viewportKEY3658;
	local[4] = makeint((eusinteger_t)3L);
viewportKEY3658:
	if (n & (1<<4)) goto viewportKEY3659;
	local[5] = makeint((eusinteger_t)500L);
viewportKEY3659:
	if (n & (1<<5)) goto viewportKEY3660;
	local[6] = local[5];
viewportKEY3660:
	if (n & (1<<6)) goto viewportKEY3661;
	local[7] = local[5];
viewportKEY3661:
	if (n & (1<<7)) goto viewportKEY3662;
	local[8] = makeint((eusinteger_t)100L);
viewportKEY3662:
	if (n & (1<<8)) goto viewportKEY3663;
	local[9] = makeint((eusinteger_t)100L);
viewportKEY3663:
	if (n & (1<<9)) goto viewportKEY3664;
	local[10] = fqv[117];
viewportKEY3664:
	if (n & (1<<10)) goto viewportKEY3665;
	local[11] = local[10];
viewportKEY3665:
	if (n & (1<<11)) goto viewportKEY3666;
	local[12] = NIL;
viewportKEY3666:
	if (n & (1<<12)) goto viewportKEY3667;
	local[13] = makeint((eusinteger_t)3L);
viewportKEY3667:
	if (n & (1<<13)) goto viewportKEY3668;
	local[14] = NIL;
viewportKEY3668:
	if (n & (1<<14)) goto viewportKEY3669;
	local[28]= makeint((eusinteger_t)300L);
	local[29]= makeint((eusinteger_t)200L);
	local[30]= makeint((eusinteger_t)100L);
	ctx->vsp=local+31;
	w=(pointer)MKFLTVEC(ctx,3,local+28); /*float-vector*/
	local[15] = w;
viewportKEY3669:
	if (n & (1<<15)) goto viewportKEY3670;
	local[28]= makeint((eusinteger_t)0L);
	local[29]= makeint((eusinteger_t)0L);
	local[30]= makeint((eusinteger_t)0L);
	ctx->vsp=local+31;
	w=(pointer)MKFLTVEC(ctx,3,local+28); /*float-vector*/
	local[16] = w;
viewportKEY3670:
	if (n & (1<<16)) goto viewportKEY3671;
	local[17] = makeflt(5.0000000000000000000000e+00);
viewportKEY3671:
	if (n & (1<<17)) goto viewportKEY3672;
	local[18] = makeflt(1.0000000000000000000000e+02);
viewportKEY3672:
	if (n & (1<<18)) goto viewportKEY3673;
	local[19] = makeflt(1.0000000000000000000000e+04);
viewportKEY3673:
	if (n & (1<<19)) goto viewportKEY3674;
	local[20] = makeflt(1.0000000000000000000000e+00);
viewportKEY3674:
	if (n & (1<<20)) goto viewportKEY3675;
	local[21] = local[20];
viewportKEY3675:
	if (n & (1<<21)) goto viewportKEY3676;
	local[22] = local[20];
viewportKEY3676:
	if (n & (1<<22)) goto viewportKEY3677;
	local[28]= local[6];
	local[29]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+30;
	w=(pointer)QUOTIENT(ctx,2,local+28); /*/*/
	local[23] = w;
viewportKEY3677:
	if (n & (1<<23)) goto viewportKEY3678;
	local[28]= local[7];
	local[29]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+30;
	w=(pointer)QUOTIENT(ctx,2,local+28); /*/*/
	local[24] = w;
viewportKEY3678:
	if (n & (1<<24)) goto viewportKEY3679;
	local[25] = makeint((eusinteger_t)2L);
viewportKEY3679:
	if (n & (1<<25)) goto viewportKEY3680;
	local[26] = makeint((eusinteger_t)0L);
viewportKEY3680:
	if (n & (1<<26)) goto viewportKEY3681;
	local[27] = NIL;
viewportKEY3681:
	local[28]= NIL;
	local[29]= NIL;
	local[30]= NIL;
	local[31]= NIL;
	if (local[2]==NIL) goto viewportIF3682;
	local[28] = local[2];
	local[32]= local[28];
	goto viewportIF3683;
viewportIF3682:
	local[32]= (pointer)get_sym_func(fqv[118]);
	local[33]= fqv[119];
	local[34]= local[8];
	local[35]= fqv[120];
	local[36]= local[9];
	local[37]= fqv[5];
	local[38]= local[6];
	local[39]= fqv[6];
	local[40]= local[7];
	local[41]= fqv[121];
	local[42]= local[10];
	local[43]= fqv[122];
	local[44]= local[12];
	local[45]= fqv[123];
	local[46]= local[13];
	local[47]= fqv[124];
	local[48]= local[14];
	local[49]= fqv[125];
	local[50]= local[25];
	local[51]= fqv[126];
	local[52]= local[26];
	local[53]= fqv[84];
	local[54]= local[11];
	local[55]= local[0];
	ctx->vsp=local+56;
	w=(pointer)APPLY(ctx,24,local+32); /*apply*/
	local[28] = w;
	local[32]= local[28];
viewportIF3683:
	if (local[1]==NIL) goto viewportIF3684;
	local[29] = local[1];
	local[32]= local[29];
	goto viewportIF3685;
viewportIF3684:
	local[32]= loadglobal(fqv[127]);
	ctx->vsp=local+33;
	w=(pointer)INSTANTIATE(ctx,1,local+32); /*instantiate*/
	local[32]= w;
	local[33]= local[32];
	local[34]= fqv[12];
	local[35]= fqv[13];
	local[36]= local[4];
	local[37]= fqv[7];
	local[38]= local[23];
	local[39]= fqv[8];
	local[40]= local[24];
	local[41]= fqv[5];
	local[42]= local[6];
	local[43]= fqv[6];
	local[44]= fqv[128];
	local[45]= loadglobal(fqv[129]);
	ctx->vsp=local+46;
	w=(*ftab[9])(ctx,2,local+44,&ftab[9],fqv[130]); /*member*/
	if (w!=NIL) goto viewportOR3688;
	local[44]= fqv[131];
	local[45]= loadglobal(fqv[129]);
	ctx->vsp=local+46;
	w=(*ftab[9])(ctx,2,local+44,&ftab[9],fqv[130]); /*member*/
	if (w!=NIL) goto viewportOR3688;
	goto viewportIF3686;
viewportOR3688:
	local[44]= local[7];
	ctx->vsp=local+45;
	w=(pointer)MINUS(ctx,1,local+44); /*-*/
	local[44]= w;
	goto viewportIF3687;
viewportIF3686:
	local[44]= local[7];
viewportIF3687:
	ctx->vsp=local+45;
	w=(pointer)SEND(ctx,12,local+33); /*send*/
	w = local[32];
	local[29] = w;
	local[32]= local[29];
viewportIF3685:
	if (local[3]==NIL) goto viewportIF3689;
	local[32]= local[3];
	goto viewportIF3690;
viewportIF3689:
	local[32]= local[4];
	local[33]= makeint((eusinteger_t)2L);
	ctx->vsp=local+34;
	w=(pointer)NUMEQUAL(ctx,2,local+32); /*=*/
	if (w==NIL) goto viewportIF3691;
	local[32]= loadglobal(fqv[132]);
	ctx->vsp=local+33;
	w=(pointer)INSTANTIATE(ctx,1,local+32); /*instantiate*/
	local[32]= w;
	local[33]= (pointer)get_sym_func(fqv[14]);
	local[34]= local[32];
	local[35]= fqv[12];
	local[36]= fqv[122];
	local[37]= NIL;
	local[38]= fqv[133];
	local[39]= local[15];
	local[40]= makeint((eusinteger_t)0L);
	ctx->vsp=local+41;
	w=(pointer)AREF(ctx,2,local+39); /*aref*/
	local[39]= w;
	local[40]= local[15];
	local[41]= makeint((eusinteger_t)1L);
	ctx->vsp=local+42;
	w=(pointer)AREF(ctx,2,local+40); /*aref*/
	local[40]= w;
	ctx->vsp=local+41;
	w=(pointer)MKFLTVEC(ctx,2,local+39); /*float-vector*/
	local[39]= w;
	local[40]= local[0];
	ctx->vsp=local+41;
	w=(pointer)APPLY(ctx,8,local+33); /*apply*/
	w = local[32];
	local[32]= w;
	goto viewportIF3692;
viewportIF3691:
	local[32]= loadglobal(fqv[134]);
	ctx->vsp=local+33;
	w=(pointer)INSTANTIATE(ctx,1,local+32); /*instantiate*/
	local[32]= w;
	local[33]= (pointer)get_sym_func(fqv[14]);
	local[34]= local[32];
	local[35]= fqv[12];
	local[36]= fqv[122];
	local[37]= NIL;
	local[38]= fqv[133];
	local[39]= local[15];
	local[40]= fqv[135];
	local[41]= local[16];
	local[42]= fqv[136];
	local[43]= local[17];
	local[44]= fqv[137];
	local[45]= local[18];
	local[46]= fqv[138];
	local[47]= local[19];
	local[48]= fqv[139];
	local[49]= local[21];
	local[50]= fqv[140];
	local[51]= local[22];
	local[52]= local[0];
	ctx->vsp=local+53;
	w=(pointer)APPLY(ctx,20,local+33); /*apply*/
	w = local[32];
	local[32]= w;
viewportIF3692:
viewportIF3690:
	local[30] = local[32];
	local[32]= local[11];
	ctx->vsp=local+33;
	w=(pointer)viewportF3212find_viewer(ctx,1,local+32); /*find-viewer*/
	local[31] = w;
	if (local[31]!=NIL) goto viewportIF3693;
	local[32]= loadglobal(fqv[92]);
	ctx->vsp=local+33;
	w=(pointer)INSTANTIATE(ctx,1,local+32); /*instantiate*/
	local[31] = w;
	local[32]= local[31];
	goto viewportIF3694;
viewportIF3693:
	local[32]= NIL;
viewportIF3694:
	local[32]= fqv[141];
	ctx->vsp=local+33;
	w=(pointer)BOUNDP(ctx,1,local+32); /*boundp*/
	if (w==NIL) goto viewportIF3695;
	w = loadglobal(fqv[141]);
	if (!isnum(w)) goto viewportIF3695;
	if (local[27]==NIL) goto viewportIF3695;
	local[32]= local[27];
	local[33]= loadglobal(fqv[142]);
	ctx->vsp=local+34;
	w=(pointer)DERIVEDP(ctx,2,local+32); /*derivedp*/
	if (w!=NIL) goto viewportIF3695;
	local[32]= loadglobal(fqv[143]);
	ctx->vsp=local+33;
	w=(pointer)INSTANTIATE(ctx,1,local+32); /*instantiate*/
	local[32]= w;
	local[33]= local[32];
	local[34]= fqv[144];
	local[35]= fqv[5];
	local[36]= local[6];
	local[37]= fqv[6];
	local[38]= local[7];
	ctx->vsp=local+39;
	w=(pointer)SEND(ctx,6,local+33); /*send*/
	w = local[32];
	local[27] = w;
	local[32]= local[27];
	goto viewportIF3696;
viewportIF3695:
	local[32]= NIL;
viewportIF3696:
	local[32]= local[31];
	local[33]= fqv[12];
	local[34]= fqv[106];
	local[35]= local[30];
	local[36]= fqv[94];
	local[37]= local[28];
	local[38]= fqv[145];
	local[39]= local[29];
	local[40]= fqv[84];
	local[41]= local[11];
	local[42]= fqv[146];
	local[43]= local[27];
	ctx->vsp=local+44;
	w=(pointer)SEND(ctx,12,local+32); /*send*/
	w = local[31];
	local[0]= w;
viewportBLK3653:
	ctx->vsp=local; return(local[0]);}

/*with-gc*/
static pointer viewportF3697(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
viewportRST3699:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	w = argv[0];
	if (!iscons(w)) goto viewportCON3701;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.car;
	local[4]= fqv[147];
	local[5]= fqv[148];
	local[6]= fqv[144];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[2] = cons(ctx,local[4],w);
	local[4]= fqv[14];
	local[5]= local[1];
	local[6]= fqv[149];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	local[3] = w;
	local[4]= local[3];
	goto viewportCON3700;
viewportCON3701:
	local[1] = argv[0];
	local[2] = argv[0];
	local[3] = NIL;
	local[4]= local[3];
	goto viewportCON3700;
viewportCON3702:
	local[4]= NIL;
viewportCON3700:
	local[4]= fqv[150];
	local[5]= fqv[151];
	local[6]= fqv[14];
	local[7]= fqv[93];
	local[8]= fqv[94];
	local[9]= fqv[152];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[153];
	local[7]= fqv[154];
	local[8]= fqv[14];
	local[9]= fqv[93];
	local[10]= fqv[94];
	local[11]= fqv[152];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	w = local[0];
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[14];
	local[9]= fqv[93];
	local[10]= fqv[94];
	local[11]= fqv[152];
	local[12]= fqv[151];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	w = local[3];
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	local[0]= w;
viewportBLK3698:
	ctx->vsp=local; return(local[0]);}

/*with-viewsurface*/
static pointer viewportF3703(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
viewportRST3705:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[150];
	local[2]= fqv[155];
	local[3]= fqv[156];
	local[4]= fqv[93];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	local[3]= fqv[153];
	local[4]= fqv[154];
	local[5]= fqv[157];
	local[6]= fqv[156];
	local[7]= fqv[93];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	w = local[0];
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[157];
	local[6]= fqv[156];
	local[7]= fqv[93];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[155];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
viewportBLK3704:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___viewport(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[158];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto viewportIF3706;
	local[0]= fqv[159];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[160],w);
	goto viewportIF3707;
viewportIF3706:
	local[0]= fqv[161];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
viewportIF3707:
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,viewportFLET3708,env,argv,local);
	local[1]= fqv[162];
	local[2]= fqv[163];
	w = local[0];
	ctx->vsp=local+3;
	w=viewportFLET3708(ctx,2,local+1,w);
	local[1]= fqv[164];
	local[2]= fqv[165];
	w = local[0];
	ctx->vsp=local+3;
	w=viewportFLET3708(ctx,2,local+1,w);
	local[1]= fqv[166];
	local[2]= fqv[167];
	w = local[0];
	ctx->vsp=local+3;
	w=viewportFLET3708(ctx,2,local+1,w);
	local[1]= fqv[168];
	local[2]= fqv[169];
	w = local[0];
	ctx->vsp=local+3;
	w=viewportFLET3708(ctx,2,local+1,w);
	local[1]= fqv[170];
	local[2]= fqv[171];
	w = local[0];
	ctx->vsp=local+3;
	w=viewportFLET3708(ctx,2,local+1,w);
	local[1]= fqv[172];
	local[2]= fqv[173];
	w = local[0];
	ctx->vsp=local+3;
	w=viewportFLET3708(ctx,2,local+1,w);
	local[0]= fqv[174];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto viewportIF3709;
	local[0]= fqv[175];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[160],w);
	goto viewportIF3710;
viewportIF3709:
	local[0]= fqv[176];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
viewportIF3710:
	local[0]= fqv[93];
	local[1]= fqv[177];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto viewportIF3711;
	local[0]= fqv[93];
	local[1]= fqv[177];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[93];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto viewportIF3713;
	local[0]= fqv[93];
	local[1]= fqv[178];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto viewportIF3714;
viewportIF3713:
	local[0]= NIL;
viewportIF3714:
	local[0]= fqv[93];
	goto viewportIF3712;
viewportIF3711:
	local[0]= NIL;
viewportIF3712:
	local[0]= fqv[86];
	local[1]= fqv[177];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto viewportIF3715;
	local[0]= fqv[86];
	local[1]= fqv[177];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[86];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto viewportIF3717;
	local[0]= fqv[86];
	local[1]= fqv[178];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto viewportIF3718;
viewportIF3717:
	local[0]= NIL;
viewportIF3718:
	local[0]= fqv[86];
	goto viewportIF3716;
viewportIF3715:
	local[0]= NIL;
viewportIF3716:
	local[0]= fqv[179];
	local[1]= fqv[177];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto viewportIF3719;
	local[0]= fqv[179];
	local[1]= fqv[177];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[179];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto viewportIF3721;
	local[0]= fqv[179];
	local[1]= fqv[178];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto viewportIF3722;
viewportIF3721:
	local[0]= NIL;
viewportIF3722:
	local[0]= fqv[179];
	goto viewportIF3720;
viewportIF3719:
	local[0]= NIL;
viewportIF3720:
	local[0]= fqv[99];
	local[1]= fqv[177];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto viewportIF3723;
	local[0]= fqv[99];
	local[1]= fqv[177];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[99];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto viewportIF3725;
	local[0]= fqv[99];
	local[1]= fqv[178];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto viewportIF3726;
viewportIF3725:
	local[0]= NIL;
viewportIF3726:
	local[0]= fqv[99];
	goto viewportIF3724;
viewportIF3723:
	local[0]= NIL;
viewportIF3724:
	local[0]= fqv[180];
	local[1]= fqv[177];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto viewportIF3727;
	local[0]= fqv[180];
	local[1]= fqv[177];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[180];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto viewportIF3729;
	local[0]= fqv[180];
	local[1]= fqv[178];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto viewportIF3730;
viewportIF3729:
	local[0]= NIL;
viewportIF3730:
	local[0]= fqv[180];
	goto viewportIF3728;
viewportIF3727:
	local[0]= NIL;
viewportIF3728:
	local[0]= fqv[181];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[2];
	local[1]= fqv[178];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[3];
	local[1]= fqv[178];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[127];
	local[1]= fqv[178];
	local[2]= fqv[127];
	local[3]= fqv[182];
	local[4]= loadglobal(fqv[183]);
	local[5]= fqv[184];
	local[6]= fqv[185];
	local[7]= fqv[186];
	local[8]= NIL;
	local[9]= fqv[187];
	local[10]= NIL;
	local[11]= fqv[88];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[188];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[10])(ctx,13,local+2,&ftab[10],fqv[189]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3214viewport_xcenter,fqv[7],fqv[127],fqv[190]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3220viewport_ycenter,fqv[8],fqv[127],fqv[191]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3226viewport_center,fqv[87],fqv[127],fqv[192]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3235viewport_width,fqv[5],fqv[127],fqv[193]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3241viewport_height,fqv[6],fqv[127],fqv[194]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3247viewport_size,fqv[88],fqv[127],fqv[195]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3256viewport_screen_point_to_ndc,fqv[196],fqv[127],fqv[197]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3258viewport_ndc_width_to_screen,fqv[25],fqv[127],fqv[198]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3260viewport_ndc_height_to_screen,fqv[26],fqv[127],fqv[199]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3262viewport_ndc_point_to_screen,fqv[16],fqv[127],fqv[200]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3266viewport_ndc_line_to_screen,fqv[20],fqv[127],fqv[201]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3278viewport_resize,fqv[89],fqv[127],fqv[202]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3293viewport_init,fqv[12],fqv[127],fqv[203]);
	local[0]= fqv[92];
	local[1]= fqv[178];
	local[2]= fqv[92];
	local[3]= fqv[182];
	local[4]= loadglobal(fqv[204]);
	local[5]= fqv[184];
	local[6]= fqv[205];
	local[7]= fqv[186];
	local[8]= NIL;
	local[9]= fqv[187];
	local[10]= NIL;
	local[11]= fqv[88];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[188];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[10])(ctx,13,local+2,&ftab[10],fqv[189]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3301viewer_viewing,fqv[106],fqv[92],fqv[206]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3306viewer_viewsurface,fqv[94],fqv[92],fqv[207]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3311viewer_viewport,fqv[145],fqv[92],fqv[208]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3316viewer_flush,fqv[15],fqv[92],fqv[209]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3318viewer_point_to_screen,fqv[210],fqv[92],fqv[211]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3320viewer_draw_point_ndc,fqv[212],fqv[92],fqv[213]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3326viewer_draw_line_ndc,fqv[31],fqv[92],fqv[214]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3335viewer_draw_string_ndc,fqv[215],fqv[92],fqv[216]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3341viewer_draw_image_string_ndc,fqv[217],fqv[92],fqv[218]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3347viewer_draw_rectangle_ndc,fqv[219],fqv[92],fqv[220]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3353viewer_draw_fill_rectangle_ndc,fqv[221],fqv[92],fqv[222]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3359viewer_draw_arc_ndc,fqv[35],fqv[92],fqv[223]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3367viewer_draw_fill_arc_ndc,fqv[36],fqv[92],fqv[224]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3373viewer_draw_polyline_ndc,fqv[32],fqv[92],fqv[225]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3380viewer_draw_box_ndc,fqv[33],fqv[92],fqv[226]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3384viewer_draw_star_ndc,fqv[41],fqv[92],fqv[227]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3389viewer_draw_line,fqv[21],fqv[92],fqv[228]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3394viewer_draw_box,fqv[229],fqv[92],fqv[230]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3399viewer_draw_polyline,fqv[231],fqv[92],fqv[232]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3404viewer_draw_arc,fqv[29],fqv[92],fqv[233]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3412viewer_draw_fill_arc,fqv[30],fqv[92],fqv[234]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3420viewer_draw_arrow,fqv[98],fqv[92],fqv[235]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3426viewer_pane,fqv[236],fqv[92],fqv[237]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3428viewer_draw_star,fqv[72],fqv[92],fqv[238]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3435viewer_draw_2dlnseg,fqv[76],fqv[92],fqv[239]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3437viewer_draw_edge_image,fqv[65],fqv[92],fqv[240]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3450viewer_draw_edge,fqv[50],fqv[92],fqv[241]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3456viewer_draw_faces,fqv[52],fqv[92],fqv[242]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3477viewer_draw_body,fqv[243],fqv[92],fqv[244]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3481viewer_draw_axis,fqv[74],fqv[92],fqv[245]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3487viewer_draw_one,fqv[59],fqv[92],fqv[246]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3528viewer_draw,fqv[60],fqv[92],fqv[247]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3538viewer_erase,fqv[97],fqv[92],fqv[248]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3540viewer_clear,fqv[82],fqv[92],fqv[249]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3542viewer_init,fqv[12],fqv[92],fqv[250]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3549viewer_adjust_viewport,fqv[90],fqv[92],fqv[251]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewportM3558viewer_resize,fqv[89],fqv[92],fqv[252]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[253],module,viewportF3202draw,fqv[254]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[255],module,viewportF3203draw_tree,fqv[256]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[257],module,viewportF3204erase,fqv[258]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[259],module,viewportF3205draw_axis,fqv[260]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[261],module,viewportF3206draw_arrow,fqv[262]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[263],module,viewportF3207hid,fqv[264]);
	local[0]= fqv[109];
	local[1]= fqv[177];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto viewportIF3731;
	local[0]= fqv[109];
	local[1]= fqv[177];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[109];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto viewportIF3733;
	local[0]= fqv[109];
	local[1]= fqv[178];
	local[2]= T;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto viewportIF3734;
viewportIF3733:
	local[0]= NIL;
viewportIF3734:
	local[0]= fqv[109];
	goto viewportIF3732;
viewportIF3731:
	local[0]= NIL;
viewportIF3732:
	ctx->vsp=local+0;
	compfun(ctx,fqv[265],module,viewportF3208hidd,fqv[266]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[267],module,viewportF3209cls,fqv[268]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[269],module,viewportF3210draw_hid,fqv[270]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[271],module,viewportF3211draw_step,fqv[272]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[273],module,viewportF3212find_viewer,fqv[274]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[275],module,viewportF3213view,fqv[276]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[277],module,viewportF3697,fqv[278]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[279],module,viewportF3703,fqv[280]);
	local[0]= fqv[145];
	local[1]= fqv[281];
	ctx->vsp=local+2;
	w=(*ftab[11])(ctx,2,local+0,&ftab[11],fqv[282]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer viewportFLET3708(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= fqv[283];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<12; i++) ftab[i]=fcallx;
}

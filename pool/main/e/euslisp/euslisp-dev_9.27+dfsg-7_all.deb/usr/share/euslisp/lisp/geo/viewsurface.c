/* ./viewsurface.c :  entry=viewsurface */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "viewsurface.h"
#pragma init (register_viewsurface)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___viewsurface();
extern pointer build_quote_vector();
static int register_viewsurface()
  { add_module_initializer("___viewsurface", ___viewsurface);}

static pointer viewsurfF3080hls2rgb();
static pointer viewsurfF3081rgb2hls();
static pointer viewsurfF3082tektro_showline();
static pointer viewsurfF3083tektro_clear();
static pointer viewsurfF3084default_viewsurface();

/*hls2rgb*/
static pointer viewsurfF3080hls2rgb(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto viewsurfENT3087;}
	local[0]= makeint((eusinteger_t)255L);
viewsurfENT3087:
viewsurfENT3086:
	if (n>4) maerror();
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,viewsurfFLET3088,env,argv,local);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[1];
	local[5]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	if (w==NIL) goto viewsurfIF3089;
	local[4]= argv[1];
	local[5]= makeint((eusinteger_t)1L);
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[3] = w;
	local[4]= local[3];
	goto viewsurfIF3090;
viewsurfIF3089:
	local[4]= argv[1];
	local[5]= argv[2];
	local[6]= argv[1];
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,3,local+4); /*+*/
	local[3] = w;
	local[4]= local[3];
viewsurfIF3090:
	local[4]= makeint((eusinteger_t)2L);
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,1,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[2] = w;
	local[4]= argv[2];
	local[5]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+6;
	w=(pointer)NUMEQUAL(ctx,2,local+4); /*=*/
	if (w==NIL) goto viewsurfCON3092;
	if (argv[0]!=NIL) goto viewsurfIF3093;
	local[4]= argv[1];
	local[5]= argv[1];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,3,local+4); /*list*/
	local[4]= w;
	goto viewsurfIF3094;
viewsurfIF3093:
	local[4]= NIL;
viewsurfIF3094:
	goto viewsurfCON3091;
viewsurfCON3092:
	local[4]= local[0];
	local[5]= local[2];
	local[6]= local[3];
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)120L);
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	w = local[1];
	ctx->vsp=local+8;
	w=viewsurfFLET3088(ctx,3,local+5,w);
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ROUND(ctx,1,local+4); /*round*/
	local[4]= w;
	local[5]= local[0];
	local[6]= local[2];
	local[7]= local[3];
	local[8]= argv[0];
	w = local[1];
	ctx->vsp=local+9;
	w=viewsurfFLET3088(ctx,3,local+6,w);
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ROUND(ctx,1,local+5); /*round*/
	local[5]= w;
	local[6]= local[0];
	local[7]= local[2];
	local[8]= local[3];
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)120L);
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	w = local[1];
	ctx->vsp=local+10;
	w=viewsurfFLET3088(ctx,3,local+7,w);
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,3,local+4); /*list*/
	local[4]= w;
	goto viewsurfCON3091;
viewsurfCON3095:
	local[4]= NIL;
viewsurfCON3091:
	w = local[4];
	local[0]= w;
viewsurfBLK3085:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer viewsurfFLET3088(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)ROUND(ctx,1,local+0); /*round*/
	argv[2] = w;
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)360L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto viewsurfIF3096;
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)360L);
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	argv[2] = w;
	local[0]= argv[2];
	goto viewsurfIF3097;
viewsurfIF3096:
	local[0]= NIL;
viewsurfIF3097:
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto viewsurfIF3098;
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)360L);
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	argv[2] = w;
	local[0]= argv[2];
	goto viewsurfIF3099;
viewsurfIF3098:
	local[0]= NIL;
viewsurfIF3099:
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)60L);
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	local[1]= local[0];
	w = fqv[0];
	if (memq(local[1],w)==NIL) goto viewsurfIF3100;
	local[1]= argv[0];
	local[2]= argv[1];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,1,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= makeflt(6.0000000000000000000000e+01);
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[1]= w;
	goto viewsurfIF3101;
viewsurfIF3100:
	local[1]= local[0];
	w = fqv[1];
	if (memq(local[1],w)==NIL) goto viewsurfIF3102;
	local[1]= argv[1];
	goto viewsurfIF3103;
viewsurfIF3102:
	local[1]= local[0];
	w = fqv[2];
	if (memq(local[1],w)==NIL) goto viewsurfIF3104;
	local[1]= argv[0];
	local[2]= argv[1];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,1,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)240L);
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,1,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= makeflt(6.0000000000000000000000e+01);
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[1]= w;
	goto viewsurfIF3105;
viewsurfIF3104:
	local[1]= local[0];
	w = fqv[3];
	if (memq(local[1],w)==NIL) goto viewsurfIF3106;
	local[1]= argv[0];
	goto viewsurfIF3107;
viewsurfIF3106:
	local[1]= NIL;
viewsurfIF3107:
viewsurfIF3105:
viewsurfIF3103:
viewsurfIF3101:
	w = local[1];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*rgb2hls*/
static pointer viewsurfF3081rgb2hls(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto viewsurfENT3110;}
	local[0]= makeflt(2.5500000000000000000000e+02);
viewsurfENT3110:
viewsurfENT3109:
	if (n>4) maerror();
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)EUSFLOAT(ctx,1,local+1); /*float*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	argv[0] = w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)EUSFLOAT(ctx,1,local+1); /*float*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	argv[1] = w;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)EUSFLOAT(ctx,1,local+1); /*float*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	argv[2] = w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= argv[0];
	local[11]= argv[1];
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)MAX(ctx,3,local+10); /*max*/
	local[4] = w;
	local[10]= argv[0];
	local[11]= argv[1];
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)MIN(ctx,3,local+10); /*min*/
	local[5] = w;
	local[10]= local[5];
	{ double x,y;
		y=fltval(local[4]); x=fltval(local[10]);
		local[10]=(makeflt(x + y));}
	local[11]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[2] = w;
	local[10]= local[2];
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[10]);
	if (left >= right) goto viewsurfIF3111;}
	local[10]= makeflt(0.0000000000000000000000e+00);
	local[11]= makeflt(0.0000000000000000000000e+00);
	local[12]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,3,local+10); /*list*/
	ctx->vsp=local+10;
	local[0]=w;
	goto viewsurfBLK3108;
	goto viewsurfIF3112;
viewsurfIF3111:
	local[10]= NIL;
viewsurfIF3112:
	local[10]= local[4];
	{ double x,y;
		y=fltval(local[5]); x=fltval(local[10]);
		local[10]=(makeflt(x - y));}
	local[9] = local[10];
	local[3] = local[9];
	local[10]= local[3];
	{ double left,right;
		right=fltval(makeflt(0.0000000000000000000000e+00)); left=fltval(local[10]);
	if (left > right) goto viewsurfIF3113;}
	local[10]= makeflt(0.0000000000000000000000e+00);
	local[11]= local[2];
	local[12]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,3,local+10); /*list*/
	ctx->vsp=local+10;
	local[0]=w;
	goto viewsurfBLK3108;
	goto viewsurfIF3114;
viewsurfIF3113:
	local[10]= NIL;
viewsurfIF3114:
	local[10]= local[3];
	local[11]= local[2];
	{ double left,right;
		right=fltval(makeflt(5.0000000000000000000000e-01)); left=fltval(local[11]);
	if (left >= right) goto viewsurfIF3115;}
	local[11]= local[4];
	{ double x,y;
		y=fltval(local[5]); x=fltval(local[11]);
		local[11]=(makeflt(x + y));}
	goto viewsurfIF3116;
viewsurfIF3115:
	local[11]= makeflt(2.0000000000000000000000e+00);
	local[12]= local[4];
	{ double x,y;
		y=fltval(local[5]); x=fltval(local[12]);
		local[12]=(makeflt(x + y));}
	{ double x,y;
		y=fltval(makeflt(-(fltval(local[12])))); x=fltval(local[11]);
		local[11]=(makeflt(x + y));}
viewsurfIF3116:
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[3] = w;
	local[10]= local[4];
	{ double x,y;
		y=fltval(makeflt(-(fltval(argv[0])))); x=fltval(local[10]);
		local[10]=(makeflt(x + y));}
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[6] = w;
	local[10]= local[4];
	{ double x,y;
		y=fltval(makeflt(-(fltval(argv[1])))); x=fltval(local[10]);
		local[10]=(makeflt(x + y));}
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[7] = w;
	local[10]= local[4];
	{ double x,y;
		y=fltval(makeflt(-(fltval(argv[2])))); x=fltval(local[10]);
		local[10]=(makeflt(x + y));}
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[8] = w;
	local[10]= argv[0];
	if (local[4]!=local[10]) goto viewsurfCON3118;
	local[10]= argv[1];
	if (local[5]!=local[10]) goto viewsurfIF3119;
	local[10]= makeflt(5.0000000000000000000000e+00);
	{ double x,y;
		y=fltval(local[8]); x=fltval(local[10]);
		local[10]=(makeflt(x + y));}
	goto viewsurfIF3120;
viewsurfIF3119:
	local[10]= makeflt(1.0000000000000000000000e+00);
	{ double x,y;
		y=fltval(local[7]); x=fltval(local[10]);
		local[10]=(makeflt(x - y));}
viewsurfIF3120:
	local[1] = local[10];
	local[10]= local[1];
	goto viewsurfCON3117;
viewsurfCON3118:
	local[10]= argv[1];
	if (local[4]!=local[10]) goto viewsurfCON3121;
	local[10]= argv[2];
	if (local[5]!=local[10]) goto viewsurfIF3122;
	local[10]= makeflt(1.0000000000000000000000e+00);
	{ double x,y;
		y=fltval(local[6]); x=fltval(local[10]);
		local[10]=(makeflt(x + y));}
	goto viewsurfIF3123;
viewsurfIF3122:
	local[10]= makeflt(3.0000000000000000000000e+00);
	{ double x,y;
		y=fltval(local[8]); x=fltval(local[10]);
		local[10]=(makeflt(x - y));}
viewsurfIF3123:
	local[1] = local[10];
	local[10]= local[1];
	goto viewsurfCON3117;
viewsurfCON3121:
	local[10]= argv[0];
	if (local[5]!=local[10]) goto viewsurfIF3125;
	local[10]= makeflt(3.0000000000000000000000e+00);
	{ double x,y;
		y=fltval(local[7]); x=fltval(local[10]);
		local[10]=(makeflt(x + y));}
	goto viewsurfIF3126;
viewsurfIF3125:
	local[10]= makeflt(5.0000000000000000000000e+00);
	{ double x,y;
		y=fltval(local[6]); x=fltval(local[10]);
		local[10]=(makeflt(x - y));}
viewsurfIF3126:
	local[1] = local[10];
	local[10]= local[1];
	goto viewsurfCON3117;
viewsurfCON3124:
	local[10]= NIL;
viewsurfCON3117:
	local[10]= local[1];
	local[11]= makeflt(6.0000000000000000000000e+00);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[1] = w;
	local[10]= makeflt(3.6000000000000000000000e+02);
	{ double x,y;
		y=fltval(local[1]); x=fltval(local[10]);
		local[10]=(makeflt(x * y));}
	local[11]= local[2];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,3,local+10); /*list*/
	local[0]= w;
viewsurfBLK3108:
	ctx->vsp=local; return(local[0]);}

/*:drawline-primitive*/
static pointer viewsurfM3127viewsurface_drawline_primitive(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	if (n>=7) { local[0]=(argv[6]); goto viewsurfENT3130;}
	local[0]= NIL;
viewsurfENT3130:
viewsurfENT3129:
	if (n>7) maerror();
	local[1]= T;
	local[2]= fqv[4];
	local[3]= argv[2];
	local[4]= argv[5];
	local[5]= argv[4];
	local[6]= argv[5];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,6,local+1); /*format*/
	local[0]= w;
viewsurfBLK3128:
	ctx->vsp=local; return(local[0]);}

/*:draw-line*/
static pointer viewsurfM3131viewsurface_draw_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto viewsurfENT3134;}
	local[0]= NIL;
viewsurfENT3134:
viewsurfENT3133:
	if (n>5) maerror();
	local[1]= argv[0];
	local[2]= fqv[5];
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	local[5]= argv[3];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= argv[3];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,7,local+1); /*send*/
	local[0]= w;
viewsurfBLK3132:
	ctx->vsp=local; return(local[0]);}

/*:line-style*/
static pointer viewsurfM3135viewsurface_line_style(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= local[0];
	if (fqv[6]!=local[1]) goto viewsurfIF3137;
	local[1]= fqv[7];
	goto viewsurfIF3138;
viewsurfIF3137:
	local[1]= local[0];
	if (fqv[8]!=local[1]) goto viewsurfIF3139;
	local[1]= fqv[9];
	goto viewsurfIF3140;
viewsurfIF3139:
	local[1]= NIL;
viewsurfIF3140:
viewsurfIF3138:
	w = local[1];
	local[0]= w;
viewsurfBLK3136:
	ctx->vsp=local; return(local[0]);}

/*:line-width*/
static pointer viewsurfM3141viewsurface_line_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= T;
	local[1]= fqv[10];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
viewsurfBLK3142:
	ctx->vsp=local; return(local[0]);}

/*:nomethod*/
static pointer viewsurfM3143viewsurface_nomethod(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
viewsurfRST3145:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[11];
	local[2]= local[0];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,3,local+1,&ftab[0],fqv[12]); /*warn*/
	local[0]= w;
viewsurfBLK3144:
	ctx->vsp=local; return(local[0]);}

/*:set-erase-mode*/
static pointer viewsurfM3146viewsurface_set_erase_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = NIL;
	local[0]= w;
viewsurfBLK3147:
	ctx->vsp=local; return(local[0]);}

/*:set-show-mode*/
static pointer viewsurfM3148viewsurface_set_show_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = NIL;
	local[0]= w;
viewsurfBLK3149:
	ctx->vsp=local; return(local[0]);}

/*:flush*/
static pointer viewsurfM3150viewsurface_flush(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = T;
	local[0]= w;
viewsurfBLK3151:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer viewsurfM3152viewsurface_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
viewsurfRST3154:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	w = argv[0];
	local[0]= w;
viewsurfBLK3153:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer viewsurfM3155tektro_viewsurface_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
viewsurfRST3157:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[13], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto viewsurfKEY3158;
	local[1] = makeint((eusinteger_t)0L);
viewsurfKEY3158:
	if (n & (1<<1)) goto viewsurfKEY3159;
	local[2] = makeint((eusinteger_t)768L);
viewsurfKEY3159:
	if (n & (1<<2)) goto viewsurfKEY3160;
	local[3] = makeint((eusinteger_t)512L);
viewsurfKEY3160:
	argv[0]->c.obj.iv[3] = local[1];
	argv[0]->c.obj.iv[2] = local[3];
	argv[0]->c.obj.iv[1] = local[3];
	w = argv[0];
	local[0]= w;
viewsurfBLK3156:
	ctx->vsp=local; return(local[0]);}

/*:clear*/
static pointer viewsurfM3161tektro_viewsurface_clear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	w=(pointer)viewsurfF3083tektro_clear(ctx,0,local+0); /*tektro-clear*/
	local[0]= w;
viewsurfBLK3162:
	ctx->vsp=local; return(local[0]);}

/*:width*/
static pointer viewsurfM3163tektro_viewsurface_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto viewsurfENT3166;}
	local[0]= NIL;
viewsurfENT3166:
viewsurfENT3165:
	if (n>3) maerror();
	w = local[0];
	if (!isnum(w)) goto viewsurfIF3167;
	argv[0]->c.obj.iv[1] = local[0];
	local[1]= argv[0]->c.obj.iv[1];
	goto viewsurfIF3168;
viewsurfIF3167:
	local[1]= NIL;
viewsurfIF3168:
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
viewsurfBLK3164:
	ctx->vsp=local; return(local[0]);}

/*:height*/
static pointer viewsurfM3169tektro_viewsurface_height(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto viewsurfENT3172;}
	local[0]= NIL;
viewsurfENT3172:
viewsurfENT3171:
	if (n>3) maerror();
	w = local[0];
	if (!isnum(w)) goto viewsurfIF3173;
	argv[0]->c.obj.iv[2] = local[0];
	local[1]= argv[0]->c.obj.iv[2];
	goto viewsurfIF3174;
viewsurfIF3173:
	local[1]= NIL;
viewsurfIF3174:
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
viewsurfBLK3170:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer viewsurfM3175tektro_viewsurface_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[14];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
viewsurfBLK3176:
	ctx->vsp=local; return(local[0]);}

/*:drawline-primitive*/
static pointer viewsurfM3177tektro_viewsurface_drawline_primitive(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	if (n>=7) { local[0]=(argv[6]); goto viewsurfENT3180;}
	local[0]= NIL;
viewsurfENT3180:
viewsurfENT3179:
	if (n>7) maerror();
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)ROUND(ctx,1,local+1); /*round*/
	local[1]= w;
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)ROUND(ctx,1,local+2); /*round*/
	local[2]= w;
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)ROUND(ctx,1,local+3); /*round*/
	local[3]= w;
	local[4]= argv[5];
	ctx->vsp=local+5;
	w=(pointer)ROUND(ctx,1,local+4); /*round*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)viewsurfF3082tektro_showline(ctx,4,local+1); /*tektro-showline*/
	local[0]= w;
viewsurfBLK3178:
	ctx->vsp=local; return(local[0]);}

/*tektro-showline*/
static pointer viewsurfF3082tektro_showline(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	if (loadglobal(fqv[16])==NIL) goto viewsurfIF3182;
	local[0]= T;
	local[1]= fqv[17];
	local[2]= argv[0];
	local[3]= argv[1];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,6,local+0); /*format*/
	local[0]= w;
	goto viewsurfIF3183;
viewsurfIF3182:
	local[0]= NIL;
viewsurfIF3183:
	local[0]= loadglobal(fqv[18]);
	local[1]= makeint((eusinteger_t)1L);
	local[2]= makeint((eusinteger_t)32L);
	local[3]= argv[1];
	local[4]= makeint((eusinteger_t)32L);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[18]);
	local[1]= makeint((eusinteger_t)2L);
	local[2]= makeint((eusinteger_t)96L);
	local[3]= argv[1];
	local[4]= makeint((eusinteger_t)32L);
	ctx->vsp=local+5;
	w=(pointer)MOD(ctx,2,local+3); /*mod*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[18]);
	local[1]= makeint((eusinteger_t)3L);
	local[2]= makeint((eusinteger_t)32L);
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)32L);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[18]);
	local[1]= makeint((eusinteger_t)4L);
	local[2]= makeint((eusinteger_t)64L);
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)32L);
	ctx->vsp=local+5;
	w=(pointer)MOD(ctx,2,local+3); /*mod*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[18]);
	local[1]= makeint((eusinteger_t)5L);
	local[2]= makeint((eusinteger_t)32L);
	local[3]= argv[3];
	local[4]= makeint((eusinteger_t)32L);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[18]);
	local[1]= makeint((eusinteger_t)6L);
	local[2]= makeint((eusinteger_t)96L);
	local[3]= argv[3];
	local[4]= makeint((eusinteger_t)32L);
	ctx->vsp=local+5;
	w=(pointer)MOD(ctx,2,local+3); /*mod*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[18]);
	local[1]= makeint((eusinteger_t)7L);
	local[2]= makeint((eusinteger_t)32L);
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)32L);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[18]);
	local[1]= makeint((eusinteger_t)8L);
	local[2]= makeint((eusinteger_t)64L);
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)32L);
	ctx->vsp=local+5;
	w=(pointer)MOD(ctx,2,local+3); /*mod*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[18]);
	local[1]= loadglobal(fqv[19]);
	ctx->vsp=local+2;
	w=(pointer)PRINC(ctx,2,local+0); /*princ*/
	w = T;
	local[0]= w;
viewsurfBLK3181:
	ctx->vsp=local; return(local[0]);}

/*tektro-clear*/
static pointer viewsurfF3083tektro_clear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto viewsurfENT3186;}
	local[0]= loadglobal(fqv[19]);
viewsurfENT3186:
viewsurfENT3185:
	if (n>1) maerror();
	local[1]= makeint((eusinteger_t)27L);
	local[2]= makeint((eusinteger_t)12L);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)WRTBYTE(ctx,2,local+1); /*write-byte*/
	local[0]= w;
viewsurfBLK3184:
	ctx->vsp=local; return(local[0]);}

/*tektro*/
static pointer viewsurfF3187(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
viewsurfRST3189:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[20];
	local[2]= fqv[19];
	local[3]= argv[0];
	local[4]= fqv[21];
	local[5]= fqv[22];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= local[0];
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)APPEND(ctx,2,local+3); /*append*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
viewsurfBLK3188:
	ctx->vsp=local; return(local[0]);}

/*default-viewsurface*/
static pointer viewsurfF3084default_viewsurface(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
viewsurfRST3191:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= (pointer)get_sym_func(fqv[23]);
	local[2]= loadglobal(fqv[24]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= fqv[25];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[0]= w;
viewsurfBLK3190:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___viewsurface(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[26];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto viewsurfIF3192;
	local[0]= fqv[27];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[28],w);
	goto viewsurfIF3193;
viewsurfIF3192:
	local[0]= fqv[29];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
viewsurfIF3193:
	local[0]= fqv[30];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[31],module,viewsurfF3080hls2rgb,fqv[32]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[33],module,viewsurfF3081rgb2hls,fqv[34]);
	local[0]= fqv[35];
	local[1]= fqv[36];
	local[2]= fqv[35];
	local[3]= fqv[37];
	local[4]= loadglobal(fqv[38]);
	local[5]= fqv[39];
	local[6]= fqv[40];
	local[7]= fqv[41];
	local[8]= NIL;
	local[9]= fqv[42];
	local[10]= NIL;
	local[11]= fqv[43];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[44];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[45]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewsurfM3127viewsurface_drawline_primitive,fqv[5],fqv[35],fqv[46]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewsurfM3131viewsurface_draw_line,fqv[47],fqv[35],fqv[48]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewsurfM3135viewsurface_line_style,fqv[49],fqv[35],fqv[50]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewsurfM3141viewsurface_line_width,fqv[51],fqv[35],fqv[52]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewsurfM3143viewsurface_nomethod,fqv[53],fqv[35],fqv[54]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewsurfM3146viewsurface_set_erase_mode,fqv[55],fqv[35],fqv[56]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewsurfM3148viewsurface_set_show_mode,fqv[57],fqv[35],fqv[58]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewsurfM3150viewsurface_flush,fqv[59],fqv[35],fqv[60]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewsurfM3152viewsurface_init,fqv[25],fqv[35],fqv[61]);
	local[0]= fqv[24];
	local[1]= fqv[36];
	local[2]= fqv[24];
	local[3]= fqv[37];
	local[4]= loadglobal(fqv[35]);
	local[5]= fqv[39];
	local[6]= fqv[62];
	local[7]= fqv[41];
	local[8]= NIL;
	local[9]= fqv[42];
	local[10]= NIL;
	local[11]= fqv[43];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[44];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[45]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewsurfM3155tektro_viewsurface_init,fqv[25],fqv[24],fqv[63]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewsurfM3161tektro_viewsurface_clear,fqv[64],fqv[24],fqv[65]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewsurfM3163tektro_viewsurface_width,fqv[14],fqv[24],fqv[66]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewsurfM3169tektro_viewsurface_height,fqv[15],fqv[24],fqv[67]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewsurfM3175tektro_viewsurface_resize,fqv[68],fqv[24],fqv[69]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,viewsurfM3177tektro_viewsurface_drawline_primitive,fqv[5],fqv[24],fqv[70]);
	local[0]= fqv[18];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto viewsurfIF3194;
	local[0]= fqv[18];
	local[1]= fqv[71];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[18];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto viewsurfIF3196;
	local[0]= fqv[18];
	local[1]= fqv[36];
	local[2]= fqv[72];
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto viewsurfIF3197;
viewsurfIF3196:
	local[0]= NIL;
viewsurfIF3197:
	local[0]= fqv[18];
	goto viewsurfIF3195;
viewsurfIF3194:
	local[0]= NIL;
viewsurfIF3195:
	local[0]= loadglobal(fqv[18]);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)29L);
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[18]);
	local[1]= makeint((eusinteger_t)9L);
	local[2]= makeint((eusinteger_t)31L);
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= fqv[19];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto viewsurfIF3198;
	local[0]= fqv[19];
	local[1]= fqv[71];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[19];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto viewsurfIF3200;
	local[0]= fqv[19];
	local[1]= fqv[36];
	local[2]= T;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto viewsurfIF3201;
viewsurfIF3200:
	local[0]= NIL;
viewsurfIF3201:
	local[0]= fqv[19];
	goto viewsurfIF3199;
viewsurfIF3198:
	local[0]= NIL;
viewsurfIF3199:
	ctx->vsp=local+0;
	compfun(ctx,fqv[73],module,viewsurfF3082tektro_showline,fqv[74]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[75],module,viewsurfF3083tektro_clear,fqv[76]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[77],module,viewsurfF3187,fqv[78]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[79],module,viewsurfF3084default_viewsurface,fqv[80]);
	local[0]= fqv[81];
	local[1]= fqv[82];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[83]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<3; i++) ftab[i]=fcallx;
}

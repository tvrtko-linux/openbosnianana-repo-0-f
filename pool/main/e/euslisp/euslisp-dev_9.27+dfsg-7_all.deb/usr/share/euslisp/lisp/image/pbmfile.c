/* ./pbmfile.c :  entry=pbmfile */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "pbmfile.h"
#pragma init (register_pbmfile)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___pbmfile();
extern pointer build_quote_vector();
static int register_pbmfile()
  { add_module_initializer("___pbmfile", ___pbmfile);}

static pointer pbmfileF1read_raw_image();
static pointer pbmfileF2write_raw_image();
static pointer pbmfileF3read_pbm_token();
static pointer pbmfileF4read_ascii_pbm();
static pointer pbmfileF5read_binary_pbm();
static pointer pbmfileF6write_pgm();
static pointer pbmfileF7read_ascii_pgm();
static pointer pbmfileF8read_binary_pgm();
static pointer pbmfileF9read_binary_ppm();
static pointer pbmfileF10read_ascii_ppm();
static pointer pbmfileF11write_ppm();
static pointer pbmfileF12read_pnm();
static pointer pbmfileF13read_pnm_file();
static pointer pbmfileF14write_pnm();
static pointer pbmfileF15write_pnm_file();

/*read-raw-image*/
static pointer pbmfileF1read_raw_image(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto pbmfileENT19;}
	local[0]= makeint((eusinteger_t)256L);
pbmfileENT19:
	if (n>=3) { local[1]=(argv[2]); goto pbmfileENT18;}
	local[1]= local[0];
pbmfileENT18:
pbmfileENT17:
	if (n>3) maerror();
	local[2]= local[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= fqv[0];
	local[4]= fqv[1];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,3,local+2,&ftab[0],fqv[2]); /*make-array*/
	local[2]= w;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,1,local+3,&ftab[1],fqv[3]); /*open*/
	local[3]= w;
	ctx->vsp=local+4;
	w = makeclosure(codevec,quotevec,pbmfileUWP20,env,argv,local);
	local[4]=(pointer)(ctx->protfp); local[5]=w;
	ctx->protfp=(struct protectframe *)(local+4);
	local[6]= local[3];
	local[7]= fqv[4];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)UNIXREAD(ctx,2,local+6); /*unix:uread*/
	ctx->vsp=local+6;
	pbmfileUWP20(ctx,0,local+6,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	w = local[2];
	local[0]= w;
pbmfileBLK16:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer pbmfileUWP20(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[3];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*write-raw-image*/
static pointer pbmfileF2write_raw_image(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[1])(ctx,1,local+0,&ftab[1],fqv[3]); /*open*/
	local[0]= w;
	ctx->vsp=local+1;
	w = makeclosure(codevec,quotevec,pbmfileUWP22,env,argv,local);
	local[1]=(pointer)(ctx->protfp); local[2]=w;
	ctx->protfp=(struct protectframe *)(local+1);
	local[3]= local[0];
	local[4]= fqv[5];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)UNIXWRITE(ctx,2,local+3); /*unix:write*/
	ctx->vsp=local+3;
	pbmfileUWP22(ctx,0,local+3,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	w = argv[1];
	local[0]= w;
pbmfileBLK21:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer pbmfileUWP22(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[0];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*read-pbm-token*/
static pointer pbmfileF3read_pbm_token(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
pbmfileTAG25:
pbmfileWHL26:
	local[1]= argv[0];
	local[2]= NIL;
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)READCH(ctx,3,local+1); /*read-char*/
	local[0] = w;
	local[1]= local[0];
	local[2]= fqv[6];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[7]); /*member*/
	if (w==NIL) goto pbmfileWHX27;
	goto pbmfileWHL26;
pbmfileWHX27:
	local[1]= NIL;
pbmfileBLK28:
	local[1]= local[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)UNREADCH(ctx,2,local+1); /*unread-char*/
	local[1]= local[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)EQ(ctx,2,local+1); /*eql*/
	if (w==NIL) goto pbmfileCON30;
	w = argv[1];
	ctx->vsp=local+1;
	local[0]=w;
	goto pbmfileBLK24;
	goto pbmfileCON29;
pbmfileCON30:
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)35L);
	ctx->vsp=local+3;
	w=(pointer)EQ(ctx,2,local+1); /*eql*/
	if (w==NIL) goto pbmfileCON31;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)READLINE(ctx,1,local+1); /*read-line*/
	ctx->vsp=local+1;
	goto pbmfileTAG25;
	goto pbmfileCON29;
pbmfileCON31:
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)READ(ctx,1,local+1); /*read*/
	ctx->vsp=local+1;
	local[0]=w;
	goto pbmfileBLK24;
	goto pbmfileCON29;
pbmfileCON32:
	local[1]= NIL;
pbmfileCON29:
	w = NIL;
	local[0]= w;
pbmfileBLK24:
	w = local[0];
	local[0]= w;
pbmfileBLK23:
	ctx->vsp=local; return(local[0]);}

/*read-ascii-pbm*/
static pointer pbmfileF4read_ascii_pbm(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= fqv[8];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
pbmfileBLK33:
	ctx->vsp=local; return(local[0]);}

/*read-binary-pbm*/
static pointer pbmfileF5read_binary_pbm(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= fqv[9];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
pbmfileBLK34:
	ctx->vsp=local; return(local[0]);}

/*write-pgm*/
static pointer pbmfileF6write_pgm(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto pbmfileENT39;}
	local[0]= makeint((eusinteger_t)255L);
pbmfileENT39:
	if (n>=4) { local[1]=(argv[3]); goto pbmfileENT38;}
	local[1]= argv[1];
	local[2]= fqv[10];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
pbmfileENT38:
	if (n>=5) { local[2]=(argv[4]); goto pbmfileENT37;}
	local[2]= argv[1];
	local[3]= fqv[11];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
pbmfileENT37:
pbmfileENT36:
	if (n>5) maerror();
	local[3]= argv[0];
	local[4]= fqv[12];
	local[5]= local[1];
	local[6]= local[2];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,5,local+3); /*format*/
	local[3]= argv[0];
	local[4]= fqv[5];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[1]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(pointer)UNIXWRITE(ctx,2,local+3); /*unix:write*/
	local[0]= w;
pbmfileBLK35:
	ctx->vsp=local; return(local[0]);}

/*read-ascii-pgm*/
static pointer pbmfileF7read_ascii_pgm(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	w = NIL;
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	local[1]= NIL;
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)pbmfileF3read_pbm_token(ctx,2,local+2); /*read-pbm-token*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)255L);
	ctx->vsp=local+6;
	w=(*ftab[3])(ctx,2,local+4,&ftab[3],fqv[13]); /*/=*/
	if (w==NIL) goto pbmfileIF41;
	local[4]= fqv[14];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SIGERROR(ctx,2,local+4); /*error*/
	local[4]= w;
	goto pbmfileIF42;
pbmfileIF41:
	local[4]= NIL;
pbmfileIF42:
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[3];
pbmfileWHL43:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto pbmfileWHX44;
	local[6]= argv[0];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)pbmfileF3read_pbm_token(ctx,2,local+6); /*read-pbm-token*/
	local[1] = w;
	local[6]= local[1];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)EQ(ctx,2,local+6); /*eql*/
	if (w==NIL) goto pbmfileIF46;
	local[6]= fqv[15];
	ctx->vsp=local+7;
	w=(pointer)SIGERROR(ctx,1,local+6); /*error*/
	local[6]= w;
	goto pbmfileIF47;
pbmfileIF46:
	local[6]= NIL;
pbmfileIF47:
	local[6]= argv[1];
	local[7]= local[4];
	w = local[1];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[7]); v=local[6];
	  v->c.str.chars[i]=intval(w);}
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto pbmfileWHL43;
pbmfileWHX44:
	local[6]= NIL;
pbmfileBLK45:
	w = NIL;
	local[4]= loadglobal(fqv[16]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= local[4];
	local[6]= fqv[17];
	local[7]= argv[2];
	local[8]= argv[3];
	local[9]= argv[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	w = local[4];
	argv[1] = w;
	local[4]= argv[1];
	local[5]= fqv[18];
	local[6]= argv[0];
	local[7]= fqv[19];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	w = argv[1];
	local[0]= w;
pbmfileBLK40:
	ctx->vsp=local; return(local[0]);}

/*read-binary-pgm*/
static pointer pbmfileF8read_binary_pgm(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	w = NIL;
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= argv[0];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)pbmfileF3read_pbm_token(ctx,2,local+5); /*read-pbm-token*/
	local[5]= w;
	local[6]= local[5];
	local[7]= makeint((eusinteger_t)255L);
	ctx->vsp=local+8;
	w=(*ftab[3])(ctx,2,local+6,&ftab[3],fqv[13]); /*/=*/
	if (w==NIL) goto pbmfileIF49;
	local[6]= fqv[20];
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)SIGERROR(ctx,2,local+6); /*error*/
	local[6]= w;
	goto pbmfileIF50;
pbmfileIF49:
	local[6]= NIL;
pbmfileIF50:
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,1,local+6,&ftab[4],fqv[21]); /*make-string*/
	argv[1] = w;
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)READCH(ctx,1,local+6); /*read-char*/
	local[6]= argv[1];
	local[7]= argv[0];
	local[8]= fqv[22];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= fqv[23];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[0] = w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[24]); /*replace*/
	local[6]= argv[0];
	local[7]= fqv[22];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[25];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[1] = w;
pbmfileWHL51:
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)LESSP(ctx,2,local+6); /*<*/
	if (w==NIL) goto pbmfileWHX52;
	local[6]= argv[0];
	local[7]= fqv[4];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[1];
	local[8]= local[2];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)UNIXREAD(ctx,4,local+6); /*unix:uread*/
	local[3] = w;
	local[6]= local[3];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)LSEQP(ctx,2,local+6); /*<=*/
	if (w==NIL) goto pbmfileIF54;
	local[6]= fqv[26];
	ctx->vsp=local+7;
	w=(pointer)SIGERROR(ctx,1,local+6); /*error*/
	local[6]= w;
	goto pbmfileIF55;
pbmfileIF54:
	local[6]= NIL;
pbmfileIF55:
	local[6]= local[1];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[1] = w;
	goto pbmfileWHL51;
pbmfileWHX52:
	local[6]= NIL;
pbmfileBLK53:
	local[6]= loadglobal(fqv[16]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[17];
	local[9]= argv[2];
	local[10]= argv[3];
	local[11]= argv[1];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	w = local[6];
	argv[1] = w;
	local[6]= argv[1];
	local[7]= fqv[18];
	local[8]= argv[0];
	local[9]= fqv[19];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	w = argv[1];
	local[0]= w;
pbmfileBLK48:
	ctx->vsp=local; return(local[0]);}

/*read-binary-ppm*/
static pointer pbmfileF9read_binary_ppm(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= NIL;
	w = NIL;
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= argv[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)pbmfileF3read_pbm_token(ctx,2,local+2); /*read-pbm-token*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= NIL;
	local[8]= local[2];
	local[9]= makeint((eusinteger_t)255L);
	ctx->vsp=local+10;
	w=(*ftab[3])(ctx,2,local+8,&ftab[3],fqv[13]); /*/=*/
	if (w==NIL) goto pbmfileIF57;
	local[8]= fqv[27];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)SIGERROR(ctx,2,local+8); /*error*/
	local[8]= w;
	goto pbmfileIF58;
pbmfileIF57:
	local[8]= NIL;
pbmfileIF58:
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)READCH(ctx,1,local+8); /*read-char*/
	local[8]= argv[1];
	local[9]= argv[0];
	local[10]= fqv[22];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= fqv[23];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[4] = w;
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(*ftab[5])(ctx,2,local+8,&ftab[5],fqv[24]); /*replace*/
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[5] = w;
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(pointer)MOD(ctx,2,local+8); /*mod*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)GREATERP(ctx,2,local+8); /*>*/
	if (w==NIL) goto pbmfileIF59;
	local[8]= makeint((eusinteger_t)3L);
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)3L);
	ctx->vsp=local+11;
	w=(pointer)MOD(ctx,2,local+9); /*mod*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[7] = w;
	local[8]= argv[0];
	local[9]= fqv[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= argv[1];
	local[10]= local[7];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)UNIXREAD(ctx,4,local+8); /*unix:uread*/
	local[8]= local[5];
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[5] = w;
	local[8]= local[5];
	goto pbmfileIF60;
pbmfileIF59:
	local[8]= NIL;
pbmfileIF60:
pbmfileWHL61:
	local[8]= argv[0];
	local[9]= fqv[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= argv[1];
	local[10]= local[6];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,2,local+10); /*-*/
	local[10]= w;
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)UNIXREAD(ctx,4,local+8); /*unix:uread*/
	local[7] = w;
	local[8]= local[7];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)GREATERP(ctx,2,local+8); /*>*/
	if (w==NIL) goto pbmfileWHX62;
	local[8]= local[5];
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[5] = w;
	goto pbmfileWHL61;
pbmfileWHX62:
	local[8]= NIL;
pbmfileBLK63:
	local[8]= loadglobal(fqv[28]);
	ctx->vsp=local+9;
	w=(pointer)INSTANTIATE(ctx,1,local+8); /*instantiate*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[17];
	local[11]= argv[2];
	local[12]= argv[3];
	local[13]= argv[1];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,5,local+9); /*send*/
	w = local[8];
	local[3] = w;
	local[8]= local[3];
	local[9]= fqv[18];
	local[10]= argv[0];
	local[11]= fqv[19];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	w = local[3];
	local[0]= w;
pbmfileBLK56:
	ctx->vsp=local; return(local[0]);}

/*read-ascii-ppm*/
static pointer pbmfileF10read_ascii_ppm(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= NIL;
	w = NIL;
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= NIL;
	local[3]= argv[0];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)pbmfileF3read_pbm_token(ctx,2,local+3); /*read-pbm-token*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= NIL;
	local[6]= local[3];
	local[7]= makeint((eusinteger_t)255L);
	ctx->vsp=local+8;
	w=(*ftab[3])(ctx,2,local+6,&ftab[3],fqv[13]); /*/=*/
	if (w==NIL) goto pbmfileIF65;
	local[6]= fqv[29];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SIGERROR(ctx,2,local+6); /*error*/
	local[6]= w;
	goto pbmfileIF66;
pbmfileIF65:
	local[6]= NIL;
pbmfileIF66:
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[4];
pbmfileWHL67:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto pbmfileWHX68;
	local[8]= local[6];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[8]);
		local[8]=(makeint(i * j));}
	local[5] = local[8];
	local[8]= argv[0];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)pbmfileF3read_pbm_token(ctx,2,local+8); /*read-pbm-token*/
	local[2] = w;
	local[8]= local[2];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)EQ(ctx,2,local+8); /*eql*/
	if (w==NIL) goto pbmfileIF70;
	local[8]= fqv[30];
	ctx->vsp=local+9;
	w=(pointer)SIGERROR(ctx,1,local+8); /*error*/
	local[8]= w;
	goto pbmfileIF71;
pbmfileIF70:
	local[8]= NIL;
pbmfileIF71:
	local[8]= argv[1];
	local[9]= local[5];
	w = local[2];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[9]); v=local[8];
	  v->c.str.chars[i]=intval(w);}
	local[8]= argv[0];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)pbmfileF3read_pbm_token(ctx,2,local+8); /*read-pbm-token*/
	local[2] = w;
	local[8]= local[2];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)EQ(ctx,2,local+8); /*eql*/
	if (w==NIL) goto pbmfileIF72;
	local[8]= fqv[31];
	ctx->vsp=local+9;
	w=(pointer)SIGERROR(ctx,1,local+8); /*error*/
	local[8]= w;
	goto pbmfileIF73;
pbmfileIF72:
	local[8]= NIL;
pbmfileIF73:
	local[8]= argv[1];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[9]= w;
	w = local[2];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[9]); v=local[8];
	  v->c.str.chars[i]=intval(w);}
	local[8]= argv[0];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)pbmfileF3read_pbm_token(ctx,2,local+8); /*read-pbm-token*/
	local[2] = w;
	local[8]= local[2];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)EQ(ctx,2,local+8); /*eql*/
	if (w==NIL) goto pbmfileIF74;
	local[8]= fqv[32];
	ctx->vsp=local+9;
	w=(pointer)SIGERROR(ctx,1,local+8); /*error*/
	local[8]= w;
	goto pbmfileIF75;
pbmfileIF74:
	local[8]= NIL;
pbmfileIF75:
	local[8]= argv[1];
	local[9]= local[5];
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	w = local[2];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[9]); v=local[8];
	  v->c.str.chars[i]=intval(w);}
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto pbmfileWHL67;
pbmfileWHX68:
	local[8]= NIL;
pbmfileBLK69:
	w = NIL;
	local[6]= loadglobal(fqv[28]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[17];
	local[9]= argv[2];
	local[10]= argv[3];
	local[11]= argv[1];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	w = local[6];
	local[0] = w;
	local[6]= local[0];
	local[7]= fqv[18];
	local[8]= argv[0];
	local[9]= fqv[19];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	w = local[0];
	local[0]= w;
pbmfileBLK64:
	ctx->vsp=local; return(local[0]);}

/*write-ppm*/
static pointer pbmfileF11write_ppm(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= fqv[33];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[1] = w;
	local[0]= argv[0];
	local[1]= fqv[34];
	local[2]= argv[1];
	local[3]= fqv[10];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[1];
	local[4]= fqv[11];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)255L);
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,5,local+0); /*format*/
	local[0]= argv[0];
	local[1]= fqv[5];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= fqv[35];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)UNIXWRITE(ctx,2,local+0); /*unix:write*/
	local[0]= w;
pbmfileBLK76:
	ctx->vsp=local; return(local[0]);}

/*read-pnm*/
static pointer pbmfileF12read_pnm(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto pbmfileENT79;}
	local[0]= NIL;
pbmfileENT79:
pbmfileENT78:
	if (n>2) maerror();
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)READCH(ctx,1,local+1); /*read-char*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	w = NIL;
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= NIL;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)CHUPCASE(ctx,1,local+6); /*char-upcase*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)80L);
	ctx->vsp=local+8;
	w=(pointer)EQ(ctx,2,local+6); /*eql*/
	if (w!=NIL) goto pbmfileIF80;
	local[6]= fqv[36];
	ctx->vsp=local+7;
	w=(pointer)SIGERROR(ctx,1,local+6); /*error*/
	local[6]= w;
	goto pbmfileIF81;
pbmfileIF80:
	local[6]= NIL;
pbmfileIF81:
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)READCH(ctx,1,local+6); /*read-char*/
	local[1] = w;
	local[6]= argv[0];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)pbmfileF3read_pbm_token(ctx,2,local+6); /*read-pbm-token*/
	local[2] = w;
	local[6]= argv[0];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)pbmfileF3read_pbm_token(ctx,2,local+6); /*read-pbm-token*/
	local[3] = w;
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[5] = w;
	local[6]= local[5];
	local[7]= makeint((eusinteger_t)4096L);
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)4096L)); i=intval(local[7]);
		local[7]=(makeint(i * j));}
	ctx->vsp=local+8;
	w=(pointer)GREATERP(ctx,2,local+6); /*>*/
	if (w!=NIL) goto pbmfileOR84;
	local[6]= local[5];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)LESSP(ctx,2,local+6); /*<*/
	if (w!=NIL) goto pbmfileOR84;
	goto pbmfileIF82;
pbmfileOR84:
	local[6]= fqv[37];
	ctx->vsp=local+7;
	w=(pointer)SIGERROR(ctx,1,local+6); /*error*/
	local[6]= w;
	goto pbmfileIF83;
pbmfileIF82:
	local[6]= NIL;
pbmfileIF83:
	if (local[0]!=NIL) goto pbmfileIF85;
	local[6]= local[1];
	local[7]= local[6];
	w = fqv[38];
	if (memq(local[7],w)==NIL) goto pbmfileIF87;
	local[7]= local[5];
	local[8]= makeint((eusinteger_t)7L);
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)8L);
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,1,local+7,&ftab[4],fqv[21]); /*make-string*/
	local[0] = w;
	local[7]= local[0];
	goto pbmfileIF88;
pbmfileIF87:
	local[7]= local[6];
	w = fqv[39];
	if (memq(local[7],w)==NIL) goto pbmfileIF89;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,1,local+7,&ftab[4],fqv[21]); /*make-string*/
	local[0] = w;
	local[7]= local[0];
	goto pbmfileIF90;
pbmfileIF89:
	local[7]= local[6];
	w = fqv[40];
	if (memq(local[7],w)==NIL) goto pbmfileIF91;
	local[7]= local[5];
	local[8]= makeint((eusinteger_t)3L);
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,1,local+7,&ftab[4],fqv[21]); /*make-string*/
	local[0] = w;
	local[7]= local[0];
	goto pbmfileIF92;
pbmfileIF91:
	local[7]= NIL;
pbmfileIF92:
pbmfileIF90:
pbmfileIF88:
	w = local[7];
	local[6]= w;
	goto pbmfileIF86;
pbmfileIF85:
	local[6]= NIL;
pbmfileIF86:
	local[6]= local[1];
	local[7]= local[6];
	if (fqv[41]!=local[7]) goto pbmfileIF93;
	local[7]= argv[0];
	local[8]= local[0];
	local[9]= local[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)pbmfileF4read_ascii_pbm(ctx,4,local+7); /*read-ascii-pbm*/
	local[7]= w;
	goto pbmfileIF94;
pbmfileIF93:
	local[7]= local[6];
	if (fqv[42]!=local[7]) goto pbmfileIF95;
	local[7]= argv[0];
	local[8]= local[0];
	local[9]= local[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)pbmfileF7read_ascii_pgm(ctx,4,local+7); /*read-ascii-pgm*/
	local[7]= w;
	goto pbmfileIF96;
pbmfileIF95:
	local[7]= local[6];
	if (fqv[43]!=local[7]) goto pbmfileIF97;
	local[7]= argv[0];
	local[8]= local[0];
	local[9]= local[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)pbmfileF10read_ascii_ppm(ctx,4,local+7); /*read-ascii-ppm*/
	local[7]= w;
	goto pbmfileIF98;
pbmfileIF97:
	local[7]= local[6];
	if (fqv[44]!=local[7]) goto pbmfileIF99;
	local[7]= argv[0];
	local[8]= local[0];
	local[9]= local[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)pbmfileF5read_binary_pbm(ctx,4,local+7); /*read-binary-pbm*/
	local[7]= w;
	goto pbmfileIF100;
pbmfileIF99:
	local[7]= local[6];
	if (fqv[45]!=local[7]) goto pbmfileIF101;
	local[7]= argv[0];
	local[8]= local[0];
	local[9]= local[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)pbmfileF8read_binary_pgm(ctx,4,local+7); /*read-binary-pgm*/
	local[7]= w;
	goto pbmfileIF102;
pbmfileIF101:
	local[7]= local[6];
	if (fqv[46]!=local[7]) goto pbmfileIF103;
	local[7]= argv[0];
	local[8]= local[0];
	local[9]= local[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)pbmfileF9read_binary_ppm(ctx,4,local+7); /*read-binary-ppm*/
	local[7]= w;
	goto pbmfileIF104;
pbmfileIF103:
	if (T==NIL) goto pbmfileIF105;
	local[7]= fqv[47];
	ctx->vsp=local+8;
	w=(pointer)SIGERROR(ctx,1,local+7); /*error*/
	local[7]= w;
	goto pbmfileIF106;
pbmfileIF105:
	local[7]= NIL;
pbmfileIF106:
pbmfileIF104:
pbmfileIF102:
pbmfileIF100:
pbmfileIF98:
pbmfileIF96:
pbmfileIF94:
	w = local[7];
	local[0]= w;
pbmfileBLK77:
	ctx->vsp=local; return(local[0]);}

/*read-pnm-file*/
static pointer pbmfileF13read_pnm_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto pbmfileENT109;}
	local[0]= NIL;
pbmfileENT109:
pbmfileENT108:
	if (n>2) maerror();
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,1,local+1,&ftab[1],fqv[3]); /*open*/
	local[1]= w;
	ctx->vsp=local+2;
	w = makeclosure(codevec,quotevec,pbmfileUWP110,env,argv,local);
	local[2]=(pointer)(ctx->protfp); local[3]=w;
	ctx->protfp=(struct protectframe *)(local+2);
	local[4]= local[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)pbmfileF12read_pnm(ctx,2,local+4); /*read-pnm*/
	ctx->vsp=local+4;
	pbmfileUWP110(ctx,0,local+4,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
pbmfileBLK107:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer pbmfileUWP110(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[1];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*write-pnm*/
static pointer pbmfileF14write_pnm(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= loadglobal(fqv[48]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto pbmfileCON113;
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)pbmfileF11write_ppm(ctx,2,local+0); /*write-ppm*/
	local[0]= w;
	goto pbmfileCON112;
pbmfileCON113:
	local[0]= argv[1];
	local[1]= loadglobal(fqv[48]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto pbmfileCON114;
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)pbmfileF11write_ppm(ctx,2,local+0); /*write-ppm*/
	local[0]= w;
	goto pbmfileCON112;
pbmfileCON114:
	local[0]= argv[1];
	local[1]= loadglobal(fqv[49]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto pbmfileCON115;
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)pbmfileF11write_ppm(ctx,2,local+0); /*write-ppm*/
	local[0]= w;
	goto pbmfileCON112;
pbmfileCON115:
	local[0]= argv[1];
	local[1]= loadglobal(fqv[16]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto pbmfileCON116;
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)pbmfileF6write_pgm(ctx,2,local+0); /*write-pgm*/
	local[0]= w;
	goto pbmfileCON112;
pbmfileCON116:
	local[0]= NIL;
pbmfileCON112:
	w = local[0];
	local[0]= w;
pbmfileBLK111:
	ctx->vsp=local; return(local[0]);}

/*write-pnm-file*/
static pointer pbmfileF15write_pnm_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[50];
	local[2]= fqv[51];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,3,local+0,&ftab[1],fqv[3]); /*open*/
	local[0]= w;
	ctx->vsp=local+1;
	w = makeclosure(codevec,quotevec,pbmfileUWP118,env,argv,local);
	local[1]=(pointer)(ctx->protfp); local[2]=w;
	ctx->protfp=(struct protectframe *)(local+1);
	local[3]= local[0];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)pbmfileF14write_pnm(ctx,2,local+3); /*write-pnm*/
	ctx->vsp=local+3;
	pbmfileUWP118(ctx,0,local+3,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
pbmfileBLK117:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer pbmfileUWP118(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[0];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___pbmfile(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[52];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w!=NIL) goto pbmfileIF119;
	local[0]= fqv[53];
	local[1]= fqv[54];
	local[2]= fqv[55];
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,3,local+0,&ftab[6],fqv[56]); /*make-package*/
	local[0]= w;
	goto pbmfileIF120;
pbmfileIF119:
	local[0]= NIL;
pbmfileIF120:
	local[0]= fqv[57];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto pbmfileIF121;
	local[0]= fqv[58];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[59],w);
	goto pbmfileIF122;
pbmfileIF121:
	local[0]= fqv[60];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
pbmfileIF122:
	local[0]= fqv[61];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[62],module,pbmfileF1read_raw_image,fqv[63]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[64],module,pbmfileF2write_raw_image,fqv[65]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[66],module,pbmfileF3read_pbm_token,fqv[67]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[68],module,pbmfileF4read_ascii_pbm,fqv[69]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[70],module,pbmfileF5read_binary_pbm,fqv[71]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[72],module,pbmfileF6write_pgm,fqv[73]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[74],module,pbmfileF7read_ascii_pgm,fqv[75]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[76],module,pbmfileF8read_binary_pgm,fqv[77]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[78],module,pbmfileF9read_binary_ppm,fqv[79]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[80],module,pbmfileF10read_ascii_ppm,fqv[81]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[82],module,pbmfileF11write_ppm,fqv[83]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[84],module,pbmfileF12read_pnm,fqv[85]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[86],module,pbmfileF13read_pnm_file,fqv[87]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[88],module,pbmfileF14write_pnm,fqv[89]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[90],module,pbmfileF15write_pnm_file,fqv[91]);
	local[0]= fqv[92];
	local[1]= fqv[93];
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,2,local+0,&ftab[7],fqv[94]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<8; i++) ftab[i]=fcallx;
}

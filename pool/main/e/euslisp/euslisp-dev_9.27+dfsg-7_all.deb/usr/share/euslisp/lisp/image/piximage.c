/* ./piximage.c :  entry=piximage */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "piximage.h"
#pragma init (register_piximage)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___piximage();
extern pointer build_quote_vector();
static int register_piximage()
  { add_module_initializer("___piximage", ___piximage);}

static pointer piximageF123make_equilevel_lut();
static pointer piximageF124look_up2();
static pointer piximageF125look_up_();
static pointer piximageF126concatenate_lut();
static pointer piximageF127color_32to24();
static pointer piximageF128color_24to32();
static pointer piximageF129color_24to8();
static pointer piximageF130color_24to16();
static pointer piximageF131color_32to8();
static pointer piximageF132color_24to6();
static pointer piximageF133color_32to8x3();
static pointer piximageF134color_24to8x3();
static pointer piximageF135swap_rgb();
static pointer piximageF136color_to_deep();
static pointer piximageF137copy_color_map();
static pointer piximageF138make_ximage();
static pointer piximageF139make_colors();

/*make-equilevel-lut*/
static pointer piximageF123make_equilevel_lut(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto piximageENT142;}
	local[0]= makeint((eusinteger_t)256L);
piximageENT142:
piximageENT141:
	if (n>2) maerror();
	local[1]= loadglobal(fqv[0]);
	local[2]= makeint((eusinteger_t)256L);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,2,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[0];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[0];
piximageWHL143:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto piximageWHX144;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[2];
piximageWHL146:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto piximageWHX147;
	local[8]= local[1];
	local[9]= local[3];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)ASET(ctx,3,local+8); /*aset*/
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[3] = w;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto piximageWHL146;
piximageWHX147:
	local[8]= NIL;
piximageBLK148:
	w = NIL;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto piximageWHL143;
piximageWHX144:
	local[6]= NIL;
piximageBLK145:
	w = NIL;
	w = local[1];
	local[0]= w;
piximageBLK140:
	ctx->vsp=local; return(local[0]);}

/*look-up2*/
static pointer piximageF124look_up2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	if (argv[1]!=NIL) goto piximageIF150;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)GETCLASS(ctx,1,local+0); /*class*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[1]); /*make-sequence*/
	argv[1] = w;
	local[0]= argv[1];
	goto piximageIF151;
piximageIF150:
	local[0]= NIL;
piximageIF151:
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
piximageWHL152:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto piximageWHX153;
	local[2]= argv[1];
	local[3]= local[0];
	local[4]= argv[3];
	local[5]= argv[2];
	local[6]= argv[0];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto piximageWHL152;
piximageWHX153:
	local[2]= NIL;
piximageBLK154:
	w = NIL;
	w = argv[1];
	local[0]= w;
piximageBLK149:
	ctx->vsp=local; return(local[0]);}

/*look-up**/
static pointer piximageF125look_up_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	if (argv[1]!=NIL) goto piximageIF156;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)GETCLASS(ctx,1,local+2); /*class*/
	local[2]= w;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,2,local+2,&ftab[0],fqv[1]); /*make-sequence*/
	argv[1] = w;
	local[2]= argv[1];
	goto piximageIF157;
piximageIF156:
	local[2]= NIL;
piximageIF157:
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
piximageWHL158:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto piximageWHX159;
	local[4]= argv[0];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[1] = w;
	local[4]= NIL;
	local[5]= argv[2];
piximageWHL161:
	if (local[5]==NIL) goto piximageWHX162;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[4];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[1] = w;
	goto piximageWHL161;
piximageWHX162:
	local[6]= NIL;
piximageBLK163:
	w = NIL;
	local[4]= argv[1];
	local[5]= local[2];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,3,local+4); /*aset*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto piximageWHL158;
piximageWHX159:
	local[4]= NIL;
piximageBLK160:
	w = NIL;
	w = argv[1];
	local[0]= w;
piximageBLK155:
	ctx->vsp=local; return(local[0]);}

/*concatenate-lut*/
static pointer piximageF126concatenate_lut(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT166;}
	local[0]= makeint((eusinteger_t)256L);
piximageENT166:
piximageENT165:
	if (n>3) maerror();
	local[1]= loadglobal(fqv[0]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[1]); /*make-sequence*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)256L);
piximageWHL167:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto piximageWHX168;
	local[4]= local[1];
	local[5]= local[2];
	local[6]= argv[1];
	local[7]= argv[0];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,2,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,3,local+4); /*aset*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto piximageWHL167;
piximageWHX168:
	local[4]= NIL;
piximageBLK169:
	w = NIL;
	w = local[1];
	local[0]= w;
piximageBLK164:
	ctx->vsp=local; return(local[0]);}

/*:entity*/
static pointer piximageM170image_2d_entity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
piximageBLK171:
	ctx->vsp=local; return(local[0]);}

/*:width*/
static pointer piximageM172image_2d_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[6];
	local[0]= w;
piximageBLK173:
	ctx->vsp=local; return(local[0]);}

/*:height*/
static pointer piximageM174image_2d_height(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
piximageBLK175:
	ctx->vsp=local; return(local[0]);}

/*:size*/
static pointer piximageM176image_2d_size(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
piximageBLK177:
	ctx->vsp=local; return(local[0]);}

/*:pixel*/
static pointer piximageM178image_2d_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= argv[3];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,3,local+0); /*aref*/
	local[0]= w;
piximageBLK179:
	ctx->vsp=local; return(local[0]);}

/*:set-pixel*/
static pointer piximageM180image_2d_set_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= argv[3];
	local[2]= argv[2];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)ASET(ctx,4,local+0); /*aset*/
	local[0]= w;
piximageBLK181:
	ctx->vsp=local; return(local[0]);}

/*:duplicate*/
static pointer piximageM182image_2d_duplicate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
piximageRST184:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)GETCLASS(ctx,1,local+1); /*class*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= (pointer)get_sym_func(fqv[2]);
	local[3]= local[1];
	local[4]= fqv[3];
	local[5]= argv[0];
	local[6]= fqv[4];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[5];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,6,local+2); /*apply*/
	w = local[1];
	local[0]= w;
piximageBLK183:
	ctx->vsp=local; return(local[0]);}

/*:copy-from*/
static pointer piximageM185image_2d_copy_from(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[6]); /*replace*/
	w = argv[0];
	local[0]= w;
piximageBLK186:
	ctx->vsp=local; return(local[0]);}

/*:copy*/
static pointer piximageM187image_2d_copy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)COPYOBJ(ctx,1,local+0); /*copy-object*/
	local[0]= w;
piximageBLK188:
	ctx->vsp=local; return(local[0]);}

/*:hex*/
static pointer piximageM189image_2d_hex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT196;}
	local[0]= makeint((eusinteger_t)0L);
piximageENT196:
	if (n>=4) { local[1]=(argv[3]); goto piximageENT195;}
	local[1]= makeint((eusinteger_t)0L);
piximageENT195:
	if (n>=5) { local[2]=(argv[4]); goto piximageENT194;}
	local[2]= makeint((eusinteger_t)8L);
piximageENT194:
	if (n>=6) { local[3]=(argv[5]); goto piximageENT193;}
	local[3]= makeint((eusinteger_t)8L);
piximageENT193:
	if (n>=7) { local[4]=(argv[6]); goto piximageENT192;}
	local[4]= T;
piximageENT192:
piximageENT191:
	if (n>7) maerror();
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[3];
piximageWHL197:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto piximageWHX198;
	local[7]= local[4];
	local[8]= fqv[7];
	local[9]= local[1];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[2];
piximageWHL200:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto piximageWHX201;
	local[9]= local[4];
	local[10]= fqv[8];
	local[11]= argv[0];
	local[12]= fqv[9];
	local[13]= local[0];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= local[1];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,2,local+14); /*+*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,4,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,3,local+9); /*format*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto piximageWHL200;
piximageWHX201:
	local[9]= NIL;
piximageBLK202:
	w = NIL;
	local[7]= local[4];
	local[8]= fqv[10];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,2,local+7); /*format*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto piximageWHL197;
piximageWHX198:
	local[7]= NIL;
piximageBLK199:
	w = NIL;
	local[0]= w;
piximageBLK190:
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer piximageM203image_2d_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
piximageRST205:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	local[1]= (pointer)get_sym_func(fqv[11]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[12]));
	local[4]= fqv[13];
	local[5]= argv[2];
	local[6]= NIL;
	local[7]= fqv[14];
	local[8]= argv[0];
	local[9]= fqv[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= argv[0];
	local[10]= fqv[5];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,4,local+6); /*format*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,7,local+1); /*apply*/
	local[0]= w;
piximageBLK204:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer piximageM206image_2d_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto piximageENT210;}
	local[0]= NIL;
piximageENT210:
	if (n>=6) { local[1]=(argv[5]); goto piximageENT209;}
	local[1]= makeint((eusinteger_t)8L);
piximageENT209:
piximageENT208:
	if (n>6) maerror();
	if (local[0]!=NIL) goto piximageIF211;
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= fqv[15];
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)NUMEQUAL(ctx,2,local+4); /*=*/
	if (w==NIL) goto piximageCON214;
	local[4]= fqv[16];
	goto piximageCON213;
piximageCON214:
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)8L);
	ctx->vsp=local+6;
	w=(pointer)LSEQP(ctx,2,local+4); /*<=*/
	if (w==NIL) goto piximageCON215;
	local[4]= fqv[17];
	goto piximageCON213;
piximageCON215:
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)32L);
	ctx->vsp=local+6;
	w=(pointer)LSEQP(ctx,2,local+4); /*<=*/
	if (w==NIL) goto piximageCON216;
	local[4]= fqv[18];
	goto piximageCON213;
piximageCON216:
	local[4]= fqv[19];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,1,local+4); /*error*/
	local[4]= w;
	goto piximageCON213;
piximageCON217:
	local[4]= NIL;
piximageCON213:
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,3,local+2,&ftab[2],fqv[20]); /*make-array*/
	local[0] = w;
	local[2]= local[0];
	goto piximageIF212;
piximageIF211:
	local[2]= NIL;
piximageIF212:
	argv[0]->c.obj.iv[2] = makeint((eusinteger_t)2L);
	argv[0]->c.obj.iv[4] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[12] = local[1];
	argv[0]->c.obj.iv[6] = argv[2];
	argv[0]->c.obj.iv[5] = argv[3];
	argv[0]->c.obj.iv[1] = local[0];
	w = argv[0];
	local[0]= w;
piximageBLK207:
	ctx->vsp=local; return(local[0]);}

/*:fill*/
static pointer piximageM218image_2d_fill(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[21]); /*fill*/
	w = argv[2];
	local[0]= w;
piximageBLK219:
	ctx->vsp=local; return(local[0]);}

/*:clear*/
static pointer piximageM220image_2d_clear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[22];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
piximageBLK221:
	ctx->vsp=local; return(local[0]);}

/*:transpose*/
static pointer piximageM222image_2d_transpose(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT225;}
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)GETCLASS(ctx,1,local+0); /*class*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[3];
	local[3]= argv[0];
	local[4]= fqv[5];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[4];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
piximageENT225:
piximageENT224:
	if (n>3) maerror();
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[6];
piximageWHL226:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto piximageWHX227;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[5];
piximageWHL229:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto piximageWHX230;
	local[5]= local[0];
	local[6]= fqv[23];
	local[7]= local[1];
	local[8]= local[3];
	local[9]= argv[0];
	local[10]= fqv[24];
	local[11]= local[3];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto piximageWHL229;
piximageWHX230:
	local[5]= NIL;
piximageBLK231:
	w = NIL;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto piximageWHL226;
piximageWHX227:
	local[3]= NIL;
piximageBLK228:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK223:
	ctx->vsp=local; return(local[0]);}

/*:map-picture*/
static pointer piximageM232image_2d_map_picture(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto piximageENT235;}
	local[0]= argv[0];
	local[1]= fqv[25];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
piximageENT235:
piximageENT234:
	if (n>4) maerror();
	local[1]= local[0]->c.obj.iv[1];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
piximageWHL236:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto piximageWHX237;
	local[4]= local[1];
	local[5]= local[2];
	local[6]= argv[2];
	local[7]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[2]);
	  w=makeint(local[7]->c.str.chars[i]);}
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[5]); v=local[4];
	  v->c.str.chars[i]=intval(w);}
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto piximageWHL236;
piximageWHX237:
	local[4]= NIL;
piximageBLK238:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK233:
	ctx->vsp=local; return(local[0]);}

/*:map*/
static pointer piximageM239image_2d_map(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto piximageENT242;}
	local[0]= argv[0];
	local[1]= fqv[25];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
piximageENT242:
piximageENT241:
	if (n>4) maerror();
	local[1]= local[0]->c.obj.iv[1];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
piximageWHL243:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto piximageWHX244;
	local[4]= local[1];
	local[5]= local[2];
	local[6]= argv[2];
	local[7]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[2]);
	  w=makeint(local[7]->c.str.chars[i]);}
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)FUNCALL(ctx,2,local+6); /*funcall*/
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[5]); v=local[4];
	  v->c.str.chars[i]=intval(w);}
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto piximageWHL243;
piximageWHX244:
	local[4]= NIL;
piximageBLK245:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK240:
	ctx->vsp=local; return(local[0]);}

/*:pixel*/
static pointer piximageM246single_channel_image_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[3];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,3,local+0); /*aref*/
	local[0]= w;
piximageBLK247:
	ctx->vsp=local; return(local[0]);}

/*:set-pixel*/
static pointer piximageM248single_channel_image_set_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[3];
	local[2]= argv[2];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)ASET(ctx,4,local+0); /*aset*/
	local[0]= w;
piximageBLK249:
	ctx->vsp=local; return(local[0]);}

/*:pixel-hex-string*/
static pointer piximageM250single_channel_image_pixel_hex_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= fqv[26];
	local[2]= argv[0];
	local[3]= fqv[24];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
piximageBLK251:
	ctx->vsp=local; return(local[0]);}

/*:halve*/
static pointer piximageM252single_channel_image_halve(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT255;}
	local[0]= NIL;
piximageENT255:
piximageENT254:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	if (local[0]!=NIL) goto piximageIF256;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)GETCLASS(ctx,1,local+3); /*class*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[3];
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = local[3];
	local[0] = w;
	local[3]= local[0];
	goto piximageIF257;
piximageIF256:
	local[3]= NIL;
piximageIF257:
	local[3]= argv[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,2,local+3,&ftab[4],fqv[27]); /*halve-image*/
	w = local[0];
	local[0]= w;
piximageBLK253:
	ctx->vsp=local; return(local[0]);}

/*:double*/
static pointer piximageM258single_channel_image_double(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT261;}
	local[0]= NIL;
piximageENT261:
piximageENT260:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	if (local[0]!=NIL) goto piximageIF262;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)GETCLASS(ctx,1,local+3); /*class*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[3];
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = local[3];
	local[0] = w;
	local[3]= local[0];
	goto piximageIF263;
piximageIF262:
	local[3]= NIL;
piximageIF263:
	local[3]= argv[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[5])(ctx,2,local+3,&ftab[5],fqv[28]); /*double-image*/
	w = local[0];
	local[0]= w;
piximageBLK259:
	ctx->vsp=local; return(local[0]);}

/*:patch-in*/
static pointer piximageM264single_channel_image_patch_in(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= fqv[4];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[5];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[4];
	local[3]= fqv[4];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[4]->c.obj.iv[1];
	local[4]= NIL;
	local[5]= NIL;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= argv[4];
	local[8]= fqv[5];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
piximageWHL266:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto piximageWHX267;
	local[8]= argv[3];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[4] = w;
	local[8]= argv[0]->c.obj.iv[1];
	local[9]= local[3];
	local[10]= fqv[29];
	local[11]= local[4];
	local[12]= fqv[30];
	local[13]= local[4];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= fqv[31];
	local[15]= local[6];
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[1])(ctx,8,local+8,&ftab[1],fqv[6]); /*replace*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto piximageWHL266;
piximageWHX267:
	local[8]= NIL;
piximageBLK268:
	w = NIL;
	local[0]= w;
piximageBLK265:
	ctx->vsp=local; return(local[0]);}

/*:xpicture*/
static pointer piximageM269single_channel_image_xpicture(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT272;}
	local[0]= NIL;
piximageENT272:
piximageENT271:
	if (n>3) maerror();
	if (loadglobal(fqv[32])!=NIL) goto piximageIF273;
	local[1]= loadglobal(fqv[33]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[3];
	local[4]= argv[0]->c.obj.iv[6];
	local[5]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[1]= w;
	storeglobal(fqv[32],w);
	goto piximageIF274;
piximageIF273:
	local[1]= NIL;
piximageIF274:
	if (local[0]!=NIL) goto piximageIF275;
	local[1]= argv[0];
	local[2]= fqv[34];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0] = w;
	local[1]= local[0];
	goto piximageIF276;
piximageIF275:
	local[1]= NIL;
piximageIF276:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= loadglobal(fqv[32])->c.obj.iv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,3,local+1,&ftab[6],fqv[35]); /*look-up*/
	w = loadglobal(fqv[32]);
	local[0]= w;
piximageBLK270:
	ctx->vsp=local; return(local[0]);}

/*:display-lut*/
static pointer piximageM277single_channel_image_display_lut(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT280;}
	local[0]= NIL;
piximageENT280:
piximageENT279:
	if (n>3) maerror();
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)VECTORP(ctx,1,local+1); /*vectorp*/
	if (w==NIL) goto piximageIF281;
	local[1]= argv[0];
	local[2]= fqv[36];
	local[3]= local[0];
	storeglobal(fqv[37],local[3]);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto piximageIF282;
piximageIF281:
	local[1]= NIL;
piximageIF282:
	if (loadglobal(fqv[37])==NIL) goto piximageIF283;
	local[1]= loadglobal(fqv[37]);
	goto piximageIF284;
piximageIF283:
	local[1]= loadglobal(fqv[38]);
piximageIF284:
	w = local[1];
	local[0]= w;
piximageBLK278:
	ctx->vsp=local; return(local[0]);}

/*:display*/
static pointer piximageM285single_channel_image_display(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT291;}
	local[0]= loadglobal(fqv[39]);
piximageENT291:
	if (n>=4) { local[1]=(argv[3]); goto piximageENT290;}
	local[1]= NIL;
piximageENT290:
	if (n>=5) { local[2]=(argv[4]); goto piximageENT289;}
	local[2]= makeint((eusinteger_t)0L);
piximageENT289:
	if (n>=6) { local[3]=(argv[5]); goto piximageENT288;}
	local[3]= makeint((eusinteger_t)0L);
piximageENT288:
piximageENT287:
	if (n>6) maerror();
	local[4]= local[0];
	local[5]= fqv[40];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[4];
	local[6]= local[5];
	if (fqv[41]!=local[6]) goto piximageIF292;
	local[6]= local[0];
	local[7]= fqv[42];
	if (loadglobal(fqv[32])==NIL) goto piximageIF294;
	local[8]= argv[0];
	local[9]= fqv[36];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w->c.obj.iv[1];
	goto piximageIF295;
piximageIF294:
	local[8]= argv[0]->c.obj.iv[1];
piximageIF295:
	local[9]= fqv[43];
	local[10]= local[2];
	local[11]= fqv[44];
	local[12]= local[3];
	local[13]= fqv[4];
	local[14]= argv[0]->c.obj.iv[6];
	local[15]= fqv[5];
	local[16]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,11,local+6); /*send*/
	local[6]= w;
	goto piximageIF293;
piximageIF292:
	local[6]= local[5];
	if (fqv[45]!=local[6]) goto piximageIF296;
	local[6]= local[0];
	local[7]= fqv[42];
	local[8]= argv[0];
	local[9]= fqv[46];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto piximageIF297;
piximageIF296:
	local[6]= local[5];
	if (fqv[47]!=local[6]) goto piximageIF298;
	local[6]= local[0];
	local[7]= fqv[42];
	local[8]= argv[0];
	local[9]= fqv[48];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto piximageIF299;
piximageIF298:
	local[6]= local[5];
	if (fqv[49]!=local[6]) goto piximageIF300;
	local[6]= local[0];
	local[7]= fqv[42];
	local[8]= argv[0];
	local[9]= fqv[50];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto piximageIF301;
piximageIF300:
	if (T==NIL) goto piximageIF302;
	local[6]= fqv[51];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(*ftab[7])(ctx,2,local+6,&ftab[7],fqv[52]); /*warn*/
	local[6]= w;
	goto piximageIF303;
piximageIF302:
	local[6]= NIL;
piximageIF303:
piximageIF301:
piximageIF299:
piximageIF297:
piximageIF293:
	w = local[6];
	w = argv[0];
	local[0]= w;
piximageBLK286:
	ctx->vsp=local; return(local[0]);}

/*:subimage*/
static pointer piximageM304single_channel_image_subimage(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[4];
	local[1]= argv[5];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[53]); /*make-string*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[5];
piximageWHL306:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto piximageWHX307;
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= fqv[29];
	local[6]= local[1];
	local[7]= argv[4];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= fqv[30];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[8]= w;
	local[9]= argv[4];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= fqv[31];
	local[10]= argv[3];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	local[11]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	local[11]= argv[2];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[1])(ctx,8,local+3,&ftab[1],fqv[6]); /*replace*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto piximageWHL306;
piximageWHX307:
	local[3]= NIL;
piximageBLK308:
	w = NIL;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)GETCLASS(ctx,1,local+1); /*class*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[3];
	local[4]= argv[4];
	local[5]= argv[5];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	w = local[1];
	local[0]= w;
piximageBLK305:
	ctx->vsp=local; return(local[0]);}

/*:patch-in*/
static pointer piximageM309single_channel_image_patch_in(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= fqv[4];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[5];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[4];
	local[3]= fqv[4];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[4]->c.obj.iv[1];
	local[4]= NIL;
	local[5]= NIL;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= argv[4];
	local[8]= fqv[5];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
piximageWHL311:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto piximageWHX312;
	local[8]= argv[3];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[4] = w;
	local[8]= argv[0]->c.obj.iv[1];
	local[9]= local[3];
	local[10]= fqv[29];
	local[11]= local[4];
	local[12]= fqv[30];
	local[13]= local[4];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= fqv[31];
	local[15]= local[6];
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[1])(ctx,8,local+8,&ftab[1],fqv[6]); /*replace*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto piximageWHL311;
piximageWHX312:
	local[8]= NIL;
piximageBLK313:
	w = NIL;
	local[0]= w;
piximageBLK310:
	ctx->vsp=local; return(local[0]);}

/*:brightest-pixel*/
static pointer piximageM314single_channel_image_brightest_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
piximageWHL316:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto piximageWHX317;
	local[3]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[1]);
	  w=makeint(local[3]->c.str.chars[i]);}
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)GREATERP(ctx,2,local+3); /*>*/
	if (w==NIL) goto piximageIF319;
	local[3]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[1]);
	  w=makeint(local[3]->c.str.chars[i]);}
	local[0] = w;
	local[3]= local[0];
	goto piximageIF320;
piximageIF319:
	local[3]= NIL;
piximageIF320:
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto piximageWHL316;
piximageWHX317:
	local[3]= NIL;
piximageBLK318:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK315:
	ctx->vsp=local; return(local[0]);}

/*:darkest-pixel*/
static pointer piximageM321single_channel_image_darkest_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)256L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
piximageWHL323:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto piximageWHX324;
	local[3]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[1]);
	  w=makeint(local[3]->c.str.chars[i]);}
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	if (w==NIL) goto piximageIF326;
	local[3]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[1]);
	  w=makeint(local[3]->c.str.chars[i]);}
	local[0] = w;
	local[3]= local[0];
	goto piximageIF327;
piximageIF326:
	local[3]= NIL;
piximageIF327:
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto piximageWHL323;
piximageWHX324:
	local[3]= NIL;
piximageBLK325:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK322:
	ctx->vsp=local; return(local[0]);}

/*:average-pixel*/
static pointer piximageM328single_channel_image_average_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= (pointer)get_sym_func(fqv[54]);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[9])(ctx,2,local+0,&ftab[9],fqv[55]); /*reduce*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)EUSFLOAT(ctx,1,local+0); /*float*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
piximageBLK329:
	ctx->vsp=local; return(local[0]);}

/*:amplify*/
static pointer piximageM330single_channel_image_amplify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto piximageENT333;}
	local[0]= argv[0];
	local[1]= fqv[25];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
piximageENT333:
piximageENT332:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= local[0]->c.obj.iv[1];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
piximageWHL334:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto piximageWHX335;
	local[5]= local[2];
	local[6]= local[3];
	local[7]= makeint((eusinteger_t)255L);
	local[8]= argv[2];
	local[9]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[3]);
	  w=makeint(local[9]->c.str.chars[i]);}
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)ROUND(ctx,1,local+8); /*round*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MIN(ctx,2,local+7); /*min*/
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[6]); v=local[5];
	  v->c.str.chars[i]=intval(w);}
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto piximageWHL334;
piximageWHX335:
	local[5]= NIL;
piximageBLK336:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK331:
	ctx->vsp=local; return(local[0]);}

/*:compress-gray-scale*/
static pointer piximageM337single_channel_image_compress_gray_scale(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto piximageENT340;}
	local[0]= NIL;
piximageENT340:
piximageENT339:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= NIL;
	if (local[0]!=NIL) goto piximageIF341;
	local[3]= argv[0];
	local[4]= fqv[25];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[0] = w;
	local[3]= local[0];
	local[4]= fqv[56];
	local[5]= NIL;
	local[6]= fqv[57];
	local[7]= argv[0];
	local[8]= fqv[56];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto piximageIF342;
piximageIF341:
	local[3]= NIL;
piximageIF342:
	local[2] = local[0]->c.obj.iv[1];
	local[3]= makeint((eusinteger_t)256L);
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	argv[2] = w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
piximageWHL343:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto piximageWHX344;
	local[5]= local[2];
	local[6]= local[3];
	local[7]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[3]);
	  w=makeint(local[7]->c.str.chars[i]);}
	local[7]= w;
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[6]); v=local[5];
	  v->c.str.chars[i]=intval(w);}
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto piximageWHL343;
piximageWHX344:
	local[5]= NIL;
piximageBLK345:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK338:
	ctx->vsp=local; return(local[0]);}

/*:lut*/
static pointer piximageM346single_channel_image_lut(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto piximageENT349;}
	local[0]= argv[0];
	local[1]= fqv[25];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
piximageENT349:
piximageENT348:
	if (n>4) maerror();
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= local[0]->c.obj.iv[1];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,3,local+1,&ftab[6],fqv[35]); /*look-up*/
	w = local[0];
	local[0]= w;
piximageBLK347:
	ctx->vsp=local; return(local[0]);}

/*:lut2*/
static pointer piximageM350single_channel_image_lut2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto piximageENT353;}
	local[0]= argv[0];
	local[1]= fqv[25];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
piximageENT353:
piximageENT352:
	if (n>5) maerror();
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= local[0]->c.obj.iv[1];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)piximageF124look_up2(ctx,4,local+1); /*look-up2*/
	w = local[0];
	local[0]= w;
piximageBLK351:
	ctx->vsp=local; return(local[0]);}

/*:to24*/
static pointer piximageM354single_channel_image_to24(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[58];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)3L);
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[53]); /*make-string*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
	local[3]= fqv[58];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
piximageWHL356:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto piximageWHX357;
	local[3]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[1]);
	  w=makeint(local[3]->c.str.chars[i]);}
	local[3]= w;
	local[4]= local[1];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[4]);
		local[4]=(makeint(i * j));}
	local[5]= local[0];
	local[6]= local[4];
	w = local[3];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[6]); v=local[5];
	  v->c.str.chars[i]=intval(w);}
	local[5]= local[0];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[6]= w;
	w = local[3];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[6]); v=local[5];
	  v->c.str.chars[i]=intval(w);}
	local[5]= local[0];
	local[6]= local[4];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	w = local[3];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[6]); v=local[5];
	  v->c.str.chars[i]=intval(w);}
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto piximageWHL356;
piximageWHX357:
	local[3]= NIL;
piximageBLK358:
	w = NIL;
	local[1]= loadglobal(fqv[59]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[3];
	local[4]= argv[0];
	local[5]= fqv[4];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[5];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	w = local[1];
	local[0]= w;
piximageBLK355:
	ctx->vsp=local; return(local[0]);}

/*:to32*/
static pointer piximageM359single_channel_image_to32(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[48];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[50];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
piximageBLK360:
	ctx->vsp=local; return(local[0]);}

/*:to16*/
static pointer piximageM361single_channel_image_to16(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[48];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[46];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
piximageBLK362:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer piximageM363bitmap_image_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto piximageENT366;}
	local[0]= NIL;
piximageENT366:
piximageENT365:
	if (n>5) maerror();
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[12]));
	local[3]= fqv[3];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)SENDMESSAGE(ctx,7,local+1); /*send-message*/
	local[0]= w;
piximageBLK364:
	ctx->vsp=local; return(local[0]);}

/*:pixel-hex-string*/
static pointer piximageM367bitmap_image_pixel_hex_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= fqv[60];
	local[2]= argv[0];
	local[3]= fqv[24];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
piximageBLK368:
	ctx->vsp=local; return(local[0]);}

/*color-32to24*/
static pointer piximageF127color_32to24(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto piximageENT371;}
	local[0]= argv[1];
	local[1]= argv[2];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[1]);
		local[1]=(makeint(i * j));}
	{ eusinteger_t i,j;
		j=intval(local[1]); i=intval(local[0]);
		local[0]=(makeint(i * j));}
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[53]); /*make-string*/
	local[0]= w;
piximageENT371:
piximageENT370:
	if (n>4) maerror();
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[1];
	{ eusinteger_t i,j;
		j=intval(argv[2]); i=intval(local[4]);
		local[4]=(makeint(i * j));}
piximageWHL372:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto piximageWHX373;
	local[5]= local[0];
	local[6]= local[2];
	local[7]= argv[0];
	local[8]= local[1];
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	{ register eusinteger_t i=intval((pointer)((eusinteger_t)local[8] + (eusinteger_t)w));
	  w=makeint(local[7]->c.str.chars[i]);}
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[6]); v=local[5];
	  v->c.str.chars[i]=intval(w);}
	local[5]= local[0];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= local[1];
	w = makeint((eusinteger_t)2L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	{ register eusinteger_t i=intval((pointer)((eusinteger_t)local[8] + (eusinteger_t)w));
	  w=makeint(local[7]->c.str.chars[i]);}
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[6]); v=local[5];
	  v->c.str.chars[i]=intval(w);}
	local[5]= local[0];
	local[6]= local[2];
	w = makeint((eusinteger_t)2L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[6]= (pointer)((eusinteger_t)local[6] + (eusinteger_t)w);
	local[7]= argv[0];
	local[8]= local[1];
	w = makeint((eusinteger_t)3L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	{ register eusinteger_t i=intval((pointer)((eusinteger_t)local[8] + (eusinteger_t)w));
	  w=makeint(local[7]->c.str.chars[i]);}
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[6]); v=local[5];
	  v->c.str.chars[i]=intval(w);}
	local[5]= local[1];
	w = makeint((eusinteger_t)4L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[1] = (pointer)((eusinteger_t)local[5] + (eusinteger_t)w);
	local[5]= local[2];
	w = makeint((eusinteger_t)3L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[2] = (pointer)((eusinteger_t)local[5] + (eusinteger_t)w);
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto piximageWHL372;
piximageWHX373:
	local[5]= NIL;
piximageBLK374:
	w = NIL;
	local[0]= w;
piximageBLK369:
	ctx->vsp=local; return(local[0]);}

/*color-24to32*/
static pointer piximageF128color_24to32(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto piximageENT377;}
	local[0]= argv[1];
	local[1]= argv[2];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)4L)); i=intval(local[1]);
		local[1]=(makeint(i * j));}
	{ eusinteger_t i,j;
		j=intval(local[1]); i=intval(local[0]);
		local[0]=(makeint(i * j));}
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[53]); /*make-string*/
	local[0]= w;
piximageENT377:
piximageENT376:
	if (n>4) maerror();
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[1];
	{ eusinteger_t i,j;
		j=intval(argv[2]); i=intval(local[4]);
		local[4]=(makeint(i * j));}
piximageWHL378:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto piximageWHX379;
	local[5]= local[0];
	local[6]= local[2];
	w = makeint((eusinteger_t)2L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[6]= (pointer)((eusinteger_t)local[6] + (eusinteger_t)w);
	local[7]= argv[0];
	local[8]= local[1];
	w = makeint((eusinteger_t)2L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	{ register eusinteger_t i=intval((pointer)((eusinteger_t)local[8] + (eusinteger_t)w));
	  w=makeint(local[7]->c.str.chars[i]);}
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[6]); v=local[5];
	  v->c.str.chars[i]=intval(w);}
	local[5]= local[0];
	local[6]= local[2];
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[6]= (pointer)((eusinteger_t)local[6] + (eusinteger_t)w);
	local[7]= argv[0];
	local[8]= local[1];
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	{ register eusinteger_t i=intval((pointer)((eusinteger_t)local[8] + (eusinteger_t)w));
	  w=makeint(local[7]->c.str.chars[i]);}
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[6]); v=local[5];
	  v->c.str.chars[i]=intval(w);}
	local[5]= local[0];
	local[6]= local[2];
	w = makeint((eusinteger_t)0L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[6]= (pointer)((eusinteger_t)local[6] + (eusinteger_t)w);
	local[7]= argv[0];
	local[8]= local[1];
	w = makeint((eusinteger_t)0L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	{ register eusinteger_t i=intval((pointer)((eusinteger_t)local[8] + (eusinteger_t)w));
	  w=makeint(local[7]->c.str.chars[i]);}
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[6]); v=local[5];
	  v->c.str.chars[i]=intval(w);}
	local[5]= local[1];
	w = makeint((eusinteger_t)3L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[1] = (pointer)((eusinteger_t)local[5] + (eusinteger_t)w);
	local[5]= local[2];
	w = makeint((eusinteger_t)4L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[2] = (pointer)((eusinteger_t)local[5] + (eusinteger_t)w);
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto piximageWHL378;
piximageWHX379:
	local[5]= NIL;
piximageBLK380:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK375:
	ctx->vsp=local; return(local[0]);}

/*color-24to8*/
static pointer piximageF129color_24to8(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto piximageENT384;}
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[10])(ctx,1,local+0,&ftab[10],fqv[61]); /**w*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[53]); /*make-string*/
	local[0]= w;
piximageENT384:
	if (n>=5) { local[1]=(argv[4]); goto piximageENT383;}
	local[1]= fqv[62];
piximageENT383:
piximageENT382:
	if (n>5) maerror();
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= NIL;
	local[15]= NIL;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.car;
piximageWHL385:
	local[16]= local[6];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)LOGTEST(ctx,2,local+16); /*logtest*/
	if (w!=NIL) goto piximageWHX386;
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(pointer)SUB1(ctx,1,local+16); /*1-*/
	local[3] = w;
	local[16]= local[6];
	local[17]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+18;
	w=(pointer)ASH(ctx,2,local+16); /*ash*/
	local[6] = w;
	goto piximageWHL385;
piximageWHX386:
	local[16]= NIL;
piximageBLK387:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.car;
piximageWHL388:
	local[16]= local[9];
	local[17]= makeint((eusinteger_t)128L);
	ctx->vsp=local+18;
	w=(pointer)LOGTEST(ctx,2,local+16); /*logtest*/
	if (w!=NIL) goto piximageWHX389;
	local[16]= local[9];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)ASH(ctx,2,local+16); /*ash*/
	local[9] = w;
	goto piximageWHL388;
piximageWHX389:
	local[16]= NIL;
piximageBLK390:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.car;
piximageWHL391:
	local[16]= local[7];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)LOGTEST(ctx,2,local+16); /*logtest*/
	if (w!=NIL) goto piximageWHX392;
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)SUB1(ctx,1,local+16); /*1-*/
	local[4] = w;
	local[16]= local[7];
	local[17]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+18;
	w=(pointer)ASH(ctx,2,local+16); /*ash*/
	local[7] = w;
	goto piximageWHL391;
piximageWHX392:
	local[16]= NIL;
piximageBLK393:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.car;
piximageWHL394:
	local[16]= local[10];
	local[17]= makeint((eusinteger_t)128L);
	ctx->vsp=local+18;
	w=(pointer)LOGTEST(ctx,2,local+16); /*logtest*/
	if (w!=NIL) goto piximageWHX395;
	local[16]= local[10];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)ASH(ctx,2,local+16); /*ash*/
	local[10] = w;
	goto piximageWHL394;
piximageWHX395:
	local[16]= NIL;
piximageBLK396:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.car;
piximageWHL397:
	local[16]= local[8];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)LOGTEST(ctx,2,local+16); /*logtest*/
	if (w!=NIL) goto piximageWHX398;
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)SUB1(ctx,1,local+16); /*1-*/
	local[5] = w;
	local[16]= local[8];
	local[17]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+18;
	w=(pointer)ASH(ctx,2,local+16); /*ash*/
	local[8] = w;
	goto piximageWHL397;
piximageWHX398:
	local[16]= NIL;
piximageBLK399:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.car;
piximageWHL400:
	local[16]= local[11];
	local[17]= makeint((eusinteger_t)128L);
	ctx->vsp=local+18;
	w=(pointer)LOGTEST(ctx,2,local+16); /*logtest*/
	if (w!=NIL) goto piximageWHX401;
	local[16]= local[11];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)ASH(ctx,2,local+16); /*ash*/
	local[11] = w;
	goto piximageWHL400;
piximageWHX401:
	local[16]= NIL;
piximageBLK402:
	local[15] = makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)LENGTH(ctx,1,local+17); /*length*/
	local[17]= w;
piximageWHL403:
	local[18]= local[16];
	w = local[17];
	if ((eusinteger_t)local[18] >= (eusinteger_t)w) goto piximageWHX404;
	local[18]= local[9];
	local[19]= argv[0];
	{ register eusinteger_t i=intval(local[15]);
	  w=makeint(local[19]->c.str.chars[i]);}
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)LOGAND(ctx,2,local+18); /*logand*/
	local[12] = w;
	local[18]= local[10];
	local[19]= argv[0];
	local[20]= local[15];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[15] = w;
	{ register eusinteger_t i=intval(local[15]);
	  w=makeint(local[19]->c.str.chars[i]);}
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)LOGAND(ctx,2,local+18); /*logand*/
	local[13] = w;
	local[18]= local[11];
	local[19]= argv[0];
	local[20]= local[15];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[15] = w;
	{ register eusinteger_t i=intval(local[15]);
	  w=makeint(local[19]->c.str.chars[i]);}
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)LOGAND(ctx,2,local+18); /*logand*/
	local[14] = w;
	local[18]= local[15];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[15] = w;
	local[18]= local[0];
	local[19]= local[16];
	local[20]= local[12];
	local[21]= local[3];
	ctx->vsp=local+22;
	w=(pointer)ASH(ctx,2,local+20); /*ash*/
	local[20]= w;
	local[21]= local[13];
	local[22]= local[4];
	ctx->vsp=local+23;
	w=(pointer)ASH(ctx,2,local+21); /*ash*/
	local[21]= w;
	local[22]= local[14];
	local[23]= local[5];
	ctx->vsp=local+24;
	w=(pointer)ASH(ctx,2,local+22); /*ash*/
	w = (pointer)((eusinteger_t)local[21] | (eusinteger_t)w);
	w = (pointer)((eusinteger_t)local[20] | (eusinteger_t)w);
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[19]); v=local[18];
	  v->c.str.chars[i]=intval(w);}
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[16] = w;
	goto piximageWHL403;
piximageWHX404:
	local[18]= NIL;
piximageBLK405:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK381:
	ctx->vsp=local; return(local[0]);}

/*color-24to16*/
static pointer piximageF130color_24to16(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto piximageENT409;}
	local[0]= NIL;
piximageENT409:
	if (n>=5) { local[1]=(argv[4]); goto piximageENT408;}
	local[1]= fqv[63];
piximageENT408:
piximageENT407:
	if (n>5) maerror();
	if (local[0]!=NIL) goto piximageIF410;
	local[2]= makeint((eusinteger_t)2L);
	local[3]= argv[1];
	{ eusinteger_t i,j;
		j=intval(argv[2]); i=intval(local[3]);
		local[3]=(makeint(i * j));}
	{ eusinteger_t i,j;
		j=intval(local[3]); i=intval(local[2]);
		local[2]=(makeint(i * j));}
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,1,local+2,&ftab[8],fqv[53]); /*make-string*/
	local[0] = w;
	local[2]= local[0];
	goto piximageIF411;
piximageIF410:
	local[2]= NIL;
piximageIF411:
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= NIL;
	local[15]= NIL;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
piximageWHL412:
	local[16]= local[2];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)LOGTEST(ctx,2,local+16); /*logtest*/
	if (w!=NIL) goto piximageWHX413;
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[5] = w;
	local[16]= local[2];
	local[17]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+18;
	w=(pointer)ASH(ctx,2,local+16); /*ash*/
	local[2] = w;
	goto piximageWHL412;
piximageWHX413:
	local[16]= NIL;
piximageBLK414:
piximageWHL415:
	local[16]= local[2];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)LOGTEST(ctx,2,local+16); /*logtest*/
	if (w==NIL) goto piximageWHX416;
	local[16]= local[8];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[8] = w;
	local[16]= local[2];
	local[17]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+18;
	w=(pointer)ASH(ctx,2,local+16); /*ash*/
	local[2] = w;
	goto piximageWHL415;
piximageWHX416:
	local[16]= NIL;
piximageBLK417:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
piximageWHL418:
	local[16]= local[3];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)LOGTEST(ctx,2,local+16); /*logtest*/
	if (w!=NIL) goto piximageWHX419;
	local[16]= local[6];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[6] = w;
	local[16]= local[3];
	local[17]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+18;
	w=(pointer)ASH(ctx,2,local+16); /*ash*/
	local[3] = w;
	goto piximageWHL418;
piximageWHX419:
	local[16]= NIL;
piximageBLK420:
piximageWHL421:
	local[16]= local[3];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)LOGTEST(ctx,2,local+16); /*logtest*/
	if (w==NIL) goto piximageWHX422;
	local[16]= local[9];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[9] = w;
	local[16]= local[3];
	local[17]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+18;
	w=(pointer)ASH(ctx,2,local+16); /*ash*/
	local[3] = w;
	goto piximageWHL421;
piximageWHX422:
	local[16]= NIL;
piximageBLK423:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.car;
piximageWHL424:
	local[16]= local[4];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)LOGTEST(ctx,2,local+16); /*logtest*/
	if (w!=NIL) goto piximageWHX425;
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[7] = w;
	local[16]= local[4];
	local[17]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+18;
	w=(pointer)ASH(ctx,2,local+16); /*ash*/
	local[4] = w;
	goto piximageWHL424;
piximageWHX425:
	local[16]= NIL;
piximageBLK426:
piximageWHL427:
	local[16]= local[4];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)LOGTEST(ctx,2,local+16); /*logtest*/
	if (w==NIL) goto piximageWHX428;
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[10] = w;
	local[16]= local[4];
	local[17]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+18;
	w=(pointer)ASH(ctx,2,local+16); /*ash*/
	local[4] = w;
	goto piximageWHL427;
piximageWHX428:
	local[16]= NIL;
piximageBLK429:
	local[15] = makeint((eusinteger_t)0L);
	local[16]= local[8];
	w = makeint((eusinteger_t)8L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[8] = (pointer)((eusinteger_t)local[16] - (eusinteger_t)w);
	local[16]= local[9];
	w = makeint((eusinteger_t)8L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[9] = (pointer)((eusinteger_t)local[16] - (eusinteger_t)w);
	local[16]= local[10];
	w = makeint((eusinteger_t)8L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[10] = (pointer)((eusinteger_t)local[16] - (eusinteger_t)w);
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)LENGTH(ctx,1,local+17); /*length*/
	local[17]= w;
	local[18]= makeint((eusinteger_t)2L);
	ctx->vsp=local+19;
	w=(pointer)QUOTIENT(ctx,2,local+17); /*/*/
	local[17]= w;
piximageWHL430:
	local[18]= local[16];
	w = local[17];
	if ((eusinteger_t)local[18] >= (eusinteger_t)w) goto piximageWHX431;
	local[18]= argv[0];
	{ register eusinteger_t i=intval(local[15]);
	  w=makeint(local[18]->c.str.chars[i]);}
	local[18]= w;
	local[19]= local[8];
	ctx->vsp=local+20;
	w=(pointer)ASH(ctx,2,local+18); /*ash*/
	local[12] = w;
	local[18]= argv[0];
	local[19]= local[15];
	ctx->vsp=local+20;
	w=(pointer)ADD1(ctx,1,local+19); /*1+*/
	local[15] = w;
	{ register eusinteger_t i=intval(local[15]);
	  w=makeint(local[18]->c.str.chars[i]);}
	local[18]= w;
	local[19]= local[9];
	ctx->vsp=local+20;
	w=(pointer)ASH(ctx,2,local+18); /*ash*/
	local[13] = w;
	local[18]= argv[0];
	local[19]= local[15];
	ctx->vsp=local+20;
	w=(pointer)ADD1(ctx,1,local+19); /*1+*/
	local[15] = w;
	{ register eusinteger_t i=intval(local[15]);
	  w=makeint(local[18]->c.str.chars[i]);}
	local[18]= w;
	local[19]= local[10];
	ctx->vsp=local+20;
	w=(pointer)ASH(ctx,2,local+18); /*ash*/
	local[14] = w;
	local[18]= local[15];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[15] = w;
	local[18]= local[12];
	local[19]= local[5];
	ctx->vsp=local+20;
	w=(pointer)ASH(ctx,2,local+18); /*ash*/
	local[18]= w;
	local[19]= local[13];
	local[20]= local[6];
	ctx->vsp=local+21;
	w=(pointer)ASH(ctx,2,local+19); /*ash*/
	local[19]= w;
	local[20]= local[14];
	local[21]= local[7];
	ctx->vsp=local+22;
	w=(pointer)ASH(ctx,2,local+20); /*ash*/
	w = (pointer)((eusinteger_t)local[19] | (eusinteger_t)w);
	local[11] = (pointer)((eusinteger_t)local[18] | (eusinteger_t)w);
	local[18]= local[11];
	local[19]= local[0];
	local[20]= local[16];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)2L)); i=intval(local[20]);
		local[20]=(makeint(i * j));}
	local[21]= fqv[64];
	ctx->vsp=local+22;
	w=(pointer)POKE(ctx,4,local+18); /*system:poke*/
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[16] = w;
	goto piximageWHL430;
piximageWHX431:
	local[18]= NIL;
piximageBLK432:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK406:
	ctx->vsp=local; return(local[0]);}

/*color-32to8*/
static pointer piximageF131color_32to8(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto piximageENT436;}
	local[0]= argv[1];
	{ eusinteger_t i,j;
		j=intval(argv[2]); i=intval(local[0]);
		local[0]=(makeint(i * j));}
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[53]); /*make-string*/
	local[0]= w;
piximageENT436:
	if (n>=5) { local[1]=(argv[4]); goto piximageENT435;}
	local[1]= fqv[65];
piximageENT435:
piximageENT434:
	if (n>5) maerror();
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= NIL;
	local[15]= NIL;
	local[16]= NIL;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.car;
piximageWHL437:
	local[17]= local[9];
	local[18]= makeint((eusinteger_t)128L);
	ctx->vsp=local+19;
	w=(pointer)LOGTEST(ctx,2,local+17); /*logtest*/
	if (w!=NIL) goto piximageWHX438;
	local[17]= local[9];
	local[18]= makeint((eusinteger_t)1L);
	ctx->vsp=local+19;
	w=(pointer)ASH(ctx,2,local+17); /*ash*/
	local[9] = w;
	goto piximageWHL437;
piximageWHX438:
	local[17]= NIL;
piximageBLK439:
piximageWHL440:
	local[17]= local[10];
	local[18]= makeint((eusinteger_t)128L);
	ctx->vsp=local+19;
	w=(pointer)LOGTEST(ctx,2,local+17); /*logtest*/
	if (w!=NIL) goto piximageWHX441;
	local[17]= local[10];
	local[18]= makeint((eusinteger_t)1L);
	ctx->vsp=local+19;
	w=(pointer)ASH(ctx,2,local+17); /*ash*/
	local[10] = w;
	goto piximageWHL440;
piximageWHX441:
	local[17]= NIL;
piximageBLK442:
piximageWHL443:
	local[17]= local[11];
	local[18]= makeint((eusinteger_t)128L);
	ctx->vsp=local+19;
	w=(pointer)LOGTEST(ctx,2,local+17); /*logtest*/
	if (w!=NIL) goto piximageWHX444;
	local[17]= local[11];
	local[18]= makeint((eusinteger_t)1L);
	ctx->vsp=local+19;
	w=(pointer)ASH(ctx,2,local+17); /*ash*/
	local[11] = w;
	goto piximageWHL443;
piximageWHX444:
	local[17]= NIL;
piximageBLK445:
piximageWHL446:
	local[17]= local[9];
	local[18]= local[3];
	ctx->vsp=local+19;
	w=(pointer)ASH(ctx,2,local+17); /*ash*/
	local[17]= w;
	local[18]= local[6];
	ctx->vsp=local+19;
	w=(pointer)EQ(ctx,2,local+17); /*eql*/
	if (w!=NIL) goto piximageWHX447;
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)SUB1(ctx,1,local+17); /*1-*/
	local[3] = w;
	goto piximageWHL446;
piximageWHX447:
	local[17]= NIL;
piximageBLK448:
piximageWHL449:
	local[17]= local[10];
	local[18]= local[4];
	ctx->vsp=local+19;
	w=(pointer)ASH(ctx,2,local+17); /*ash*/
	local[17]= w;
	local[18]= local[7];
	ctx->vsp=local+19;
	w=(pointer)EQ(ctx,2,local+17); /*eql*/
	if (w!=NIL) goto piximageWHX450;
	local[17]= local[4];
	ctx->vsp=local+18;
	w=(pointer)SUB1(ctx,1,local+17); /*1-*/
	local[4] = w;
	goto piximageWHL449;
piximageWHX450:
	local[17]= NIL;
piximageBLK451:
piximageWHL452:
	local[17]= local[11];
	local[18]= local[5];
	ctx->vsp=local+19;
	w=(pointer)ASH(ctx,2,local+17); /*ash*/
	local[17]= w;
	local[18]= local[8];
	ctx->vsp=local+19;
	w=(pointer)EQ(ctx,2,local+17); /*eql*/
	if (w!=NIL) goto piximageWHX453;
	local[17]= local[5];
	ctx->vsp=local+18;
	w=(pointer)SUB1(ctx,1,local+17); /*1-*/
	local[5] = w;
	goto piximageWHL452;
piximageWHX453:
	local[17]= NIL;
piximageBLK454:
	local[17]= T;
	local[18]= fqv[66];
	local[19]= local[3];
	local[20]= local[9];
	local[21]= local[4];
	local[22]= local[10];
	local[23]= local[5];
	local[24]= local[11];
	ctx->vsp=local+25;
	w=(pointer)XFORMAT(ctx,8,local+17); /*format*/
	local[15] = makeint((eusinteger_t)0L);
	local[17]= makeint((eusinteger_t)0L);
	local[18]= local[0];
	ctx->vsp=local+19;
	w=(pointer)LENGTH(ctx,1,local+18); /*length*/
	local[18]= w;
piximageWHL455:
	local[19]= local[17];
	w = local[18];
	if ((eusinteger_t)local[19] >= (eusinteger_t)w) goto piximageWHX456;
	local[19]= local[15];
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[15] = (pointer)((eusinteger_t)local[19] + (eusinteger_t)w);
	local[19]= local[11];
	local[20]= argv[0];
	{ register eusinteger_t i=intval(local[15]);
	  w=makeint(local[20]->c.str.chars[i]);}
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)LOGAND(ctx,2,local+19); /*logand*/
	local[14] = w;
	local[19]= local[10];
	local[20]= argv[0];
	local[21]= local[15];
	ctx->vsp=local+22;
	w=(pointer)ADD1(ctx,1,local+21); /*1+*/
	local[15] = w;
	{ register eusinteger_t i=intval(local[15]);
	  w=makeint(local[20]->c.str.chars[i]);}
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)LOGAND(ctx,2,local+19); /*logand*/
	local[13] = w;
	local[19]= local[9];
	local[20]= argv[0];
	local[21]= local[15];
	ctx->vsp=local+22;
	w=(pointer)ADD1(ctx,1,local+21); /*1+*/
	local[15] = w;
	{ register eusinteger_t i=intval(local[15]);
	  w=makeint(local[20]->c.str.chars[i]);}
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)LOGAND(ctx,2,local+19); /*logand*/
	local[12] = w;
	local[19]= local[15];
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[15] = (pointer)((eusinteger_t)local[19] + (eusinteger_t)w);
	local[19]= local[0];
	local[20]= local[17];
	local[21]= local[12];
	local[22]= local[3];
	ctx->vsp=local+23;
	w=(pointer)ASH(ctx,2,local+21); /*ash*/
	local[21]= w;
	local[22]= local[13];
	local[23]= local[4];
	ctx->vsp=local+24;
	w=(pointer)ASH(ctx,2,local+22); /*ash*/
	local[22]= w;
	local[23]= local[14];
	local[24]= local[5];
	ctx->vsp=local+25;
	w=(pointer)ASH(ctx,2,local+23); /*ash*/
	w = (pointer)((eusinteger_t)local[22] | (eusinteger_t)w);
	w = (pointer)((eusinteger_t)local[21] | (eusinteger_t)w);
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[20]); v=local[19];
	  v->c.str.chars[i]=intval(w);}
	local[19]= local[17];
	ctx->vsp=local+20;
	w=(pointer)ADD1(ctx,1,local+19); /*1+*/
	local[17] = w;
	goto piximageWHL455;
piximageWHX456:
	local[19]= NIL;
piximageBLK457:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK433:
	ctx->vsp=local; return(local[0]);}

/*color-24to6*/
static pointer piximageF132color_24to6(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto piximageENT460;}
	local[0]= argv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[53]); /*make-string*/
	local[0]= w;
piximageENT460:
piximageENT459:
	if (n>4) maerror();
	local[1]= makeint((eusinteger_t)0L);
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= argv[1];
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
piximageWHL461:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto piximageWHX462;
	local[8]= argv[0];
	local[9]= local[1];
	w = makeint((eusinteger_t)0L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[9]= (pointer)((eusinteger_t)local[9] + (eusinteger_t)w);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,2,local+8); /*aref*/
	local[3] = w;
	local[8]= argv[0];
	local[9]= local[1];
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[9]= (pointer)((eusinteger_t)local[9] + (eusinteger_t)w);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,2,local+8); /*aref*/
	local[4] = w;
	local[8]= argv[0];
	local[9]= local[1];
	w = makeint((eusinteger_t)2L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[9]= (pointer)((eusinteger_t)local[9] + (eusinteger_t)w);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,2,local+8); /*aref*/
	local[5] = w;
	local[8]= local[1];
	w = makeint((eusinteger_t)3L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[1] = (pointer)((eusinteger_t)local[8] + (eusinteger_t)w);
	local[8]= local[3];
	local[9]= makeint((eusinteger_t)-2L);
	ctx->vsp=local+10;
	w=(pointer)ASH(ctx,2,local+8); /*ash*/
	local[8]= w;
	w = makeint((eusinteger_t)48L);
	local[8]= (pointer)((eusinteger_t)local[8] & (eusinteger_t)w);
	local[9]= local[4];
	local[10]= makeint((eusinteger_t)-4L);
	ctx->vsp=local+11;
	w=(pointer)ASH(ctx,2,local+9); /*ash*/
	local[9]= w;
	w = makeint((eusinteger_t)12L);
	local[9]= (pointer)((eusinteger_t)local[9] & (eusinteger_t)w);
	local[10]= local[5];
	local[11]= makeint((eusinteger_t)-6L);
	ctx->vsp=local+12;
	w=(pointer)ASH(ctx,2,local+10); /*ash*/
	local[10]= w;
	w = makeint((eusinteger_t)3L);
	w = (pointer)((eusinteger_t)local[10] & (eusinteger_t)w);
	w = (pointer)((eusinteger_t)local[9] | (eusinteger_t)w);
	local[2] = (pointer)((eusinteger_t)local[8] | (eusinteger_t)w);
	local[8]= local[0];
	local[9]= local[6];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)ASET(ctx,3,local+8); /*aset*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto piximageWHL461;
piximageWHX462:
	local[8]= NIL;
piximageBLK463:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK458:
	ctx->vsp=local; return(local[0]);}

/*color-32to8x3*/
static pointer piximageF133color_32to8x3(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto piximageENT468;}
	local[0]= argv[1];
	{ eusinteger_t i,j;
		j=intval(argv[2]); i=intval(local[0]);
		local[0]=(makeint(i * j));}
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[53]); /*make-string*/
	local[0]= w;
piximageENT468:
	if (n>=5) { local[1]=(argv[4]); goto piximageENT467;}
	local[1]= argv[1];
	{ eusinteger_t i,j;
		j=intval(argv[2]); i=intval(local[1]);
		local[1]=(makeint(i * j));}
	ctx->vsp=local+2;
	w=(*ftab[8])(ctx,1,local+1,&ftab[8],fqv[53]); /*make-string*/
	local[1]= w;
piximageENT467:
	if (n>=6) { local[2]=(argv[5]); goto piximageENT466;}
	local[2]= argv[1];
	{ eusinteger_t i,j;
		j=intval(argv[2]); i=intval(local[2]);
		local[2]=(makeint(i * j));}
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,1,local+2,&ftab[8],fqv[53]); /*make-string*/
	local[2]= w;
piximageENT466:
piximageENT465:
	if (n>6) maerror();
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[1];
	{ eusinteger_t i,j;
		j=intval(argv[2]); i=intval(local[8]);
		local[8]=(makeint(i * j));}
piximageWHL469:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto piximageWHX470;
	local[9]= argv[0];
	{ register eusinteger_t i=intval(local[6]);
	  w=makeint(local[9]->c.str.chars[i]);}
	local[3] = w;
	local[9]= argv[0];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	{ register eusinteger_t i=intval(w);
	  w=makeint(local[9]->c.str.chars[i]);}
	local[4] = w;
	local[9]= argv[0];
	local[10]= local[6];
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	{ register eusinteger_t i=intval(w);
	  w=makeint(local[9]->c.str.chars[i]);}
	local[5] = w;
	local[9]= local[2];
	local[10]= local[7];
	w = local[5];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[10]); v=local[9];
	  v->c.str.chars[i]=intval(w);}
	local[9]= local[1];
	local[10]= local[7];
	w = local[4];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[10]); v=local[9];
	  v->c.str.chars[i]=intval(w);}
	local[9]= local[0];
	local[10]= local[7];
	w = local[3];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[10]); v=local[9];
	  v->c.str.chars[i]=intval(w);}
	local[9]= local[6];
	local[10]= makeint((eusinteger_t)4L);
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[6] = w;
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto piximageWHL469;
piximageWHX470:
	local[9]= NIL;
piximageBLK471:
	w = NIL;
	local[0]= w;
piximageBLK464:
	ctx->vsp=local; return(local[0]);}

/*color-24to8x3*/
static pointer piximageF134color_24to8x3(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto piximageENT476;}
	local[0]= argv[1];
	{ eusinteger_t i,j;
		j=intval(argv[2]); i=intval(local[0]);
		local[0]=(makeint(i * j));}
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[53]); /*make-string*/
	local[0]= w;
piximageENT476:
	if (n>=5) { local[1]=(argv[4]); goto piximageENT475;}
	local[1]= argv[1];
	{ eusinteger_t i,j;
		j=intval(argv[2]); i=intval(local[1]);
		local[1]=(makeint(i * j));}
	ctx->vsp=local+2;
	w=(*ftab[8])(ctx,1,local+1,&ftab[8],fqv[53]); /*make-string*/
	local[1]= w;
piximageENT475:
	if (n>=6) { local[2]=(argv[5]); goto piximageENT474;}
	local[2]= argv[1];
	{ eusinteger_t i,j;
		j=intval(argv[2]); i=intval(local[2]);
		local[2]=(makeint(i * j));}
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,1,local+2,&ftab[8],fqv[53]); /*make-string*/
	local[2]= w;
piximageENT474:
piximageENT473:
	if (n>6) maerror();
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[1];
	{ eusinteger_t i,j;
		j=intval(argv[2]); i=intval(local[8]);
		local[8]=(makeint(i * j));}
piximageWHL477:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto piximageWHX478;
	local[9]= argv[0];
	{ register eusinteger_t i=intval(local[6]);
	  w=makeint(local[9]->c.str.chars[i]);}
	local[3] = w;
	local[9]= argv[0];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	{ register eusinteger_t i=intval(w);
	  w=makeint(local[9]->c.str.chars[i]);}
	local[4] = w;
	local[9]= argv[0];
	local[10]= local[6];
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	{ register eusinteger_t i=intval(w);
	  w=makeint(local[9]->c.str.chars[i]);}
	local[5] = w;
	local[9]= local[2];
	local[10]= local[7];
	w = local[5];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[10]); v=local[9];
	  v->c.str.chars[i]=intval(w);}
	local[9]= local[1];
	local[10]= local[7];
	w = local[4];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[10]); v=local[9];
	  v->c.str.chars[i]=intval(w);}
	local[9]= local[0];
	local[10]= local[7];
	w = local[3];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[10]); v=local[9];
	  v->c.str.chars[i]=intval(w);}
	local[9]= local[6];
	local[10]= makeint((eusinteger_t)3L);
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[6] = w;
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto piximageWHL477;
piximageWHX478:
	local[9]= NIL;
piximageBLK479:
	w = NIL;
	local[0]= w;
piximageBLK472:
	ctx->vsp=local; return(local[0]);}

/*swap-rgb*/
static pointer piximageF135swap_rgb(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto piximageENT482;}
	local[0]= makeint((eusinteger_t)3L);
piximageENT482:
piximageENT481:
	if (n>2) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[1] = argv[0]->c.obj.iv[1];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[2] = w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[2];
piximageWHL483:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto piximageWHX484;
	local[9]= local[7];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[3] = w;
	local[9]= local[1];
	{ register eusinteger_t i=intval(local[3]);
	  w=makeint(local[9]->c.str.chars[i]);}
	local[4] = w;
	local[9]= local[1];
	local[10]= local[3];
	w = makeint((eusinteger_t)2L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	{ register eusinteger_t i=intval((pointer)((eusinteger_t)local[10] + (eusinteger_t)w));
	  w=makeint(local[9]->c.str.chars[i]);}
	local[6] = w;
	local[9]= local[1];
	local[10]= local[3];
	w = makeint((eusinteger_t)2L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[10]= (pointer)((eusinteger_t)local[10] + (eusinteger_t)w);
	w = local[4];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[10]); v=local[9];
	  v->c.str.chars[i]=intval(w);}
	local[9]= local[1];
	local[10]= local[3];
	w = local[6];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[10]); v=local[9];
	  v->c.str.chars[i]=intval(w);}
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto piximageWHL483;
piximageWHX484:
	local[9]= NIL;
piximageBLK485:
	w = NIL;
	w = argv[0];
	local[0]= w;
piximageBLK480:
	ctx->vsp=local; return(local[0]);}

/*:components*/
static pointer piximageM486multi_channel_image_components(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[13];
	local[0]= w;
piximageBLK487:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer piximageM488color_image_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto piximageENT493;}
	local[0]= NIL;
piximageENT493:
	if (n>=6) { local[1]=(argv[5]); goto piximageENT492;}
	local[1]= makeint((eusinteger_t)24L);
piximageENT492:
	if (n>=7) { local[2]=(argv[6]); goto piximageENT491;}
	local[2]= makeint((eusinteger_t)3L);
piximageENT491:
piximageENT490:
	if (n>7) maerror();
	argv[0]->c.obj.iv[12] = local[1];
	argv[0]->c.obj.iv[13] = local[2];
	local[3]= argv[0]->c.obj.iv[12];
	local[4]= makeint((eusinteger_t)8L);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	argv[0]->c.obj.iv[14] = w;
	if (local[0]!=NIL) goto piximageIF494;
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,3,local+3); /***/
	local[3]= w;
	local[4]= fqv[15];
	local[5]= fqv[17];
	ctx->vsp=local+6;
	w=(*ftab[2])(ctx,3,local+3,&ftab[2],fqv[20]); /*make-array*/
	local[0] = w;
	local[3]= local[0];
	goto piximageIF495;
piximageIF494:
	local[3]= NIL;
piximageIF495:
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[12]));
	local[5]= fqv[3];
	local[6]= argv[2];
	local[7]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= argv[3];
	local[8]= local[0];
	local[9]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+10;
	w=(pointer)SENDMESSAGE(ctx,7,local+3); /*send-message*/
	w = argv[0];
	local[0]= w;
piximageBLK489:
	ctx->vsp=local; return(local[0]);}

/*:depth*/
static pointer piximageM496color_image_depth(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[12];
	local[0]= w;
piximageBLK497:
	ctx->vsp=local; return(local[0]);}

/*:byte-depth*/
static pointer piximageM498color_image_byte_depth(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[14];
	local[0]= w;
piximageBLK499:
	ctx->vsp=local; return(local[0]);}

/*:width*/
static pointer piximageM500color_image_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[6];
	local[1]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
piximageBLK501:
	ctx->vsp=local; return(local[0]);}

/*:pixel*/
static pointer piximageM502color_image_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0]->c.obj.iv[13];
piximageWHL504:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto piximageWHX505;
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)8L);
	ctx->vsp=local+6;
	w=(pointer)ASH(ctx,2,local+4); /*ash*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= argv[3];
	local[7]= local[0];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,3,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LOGIOR(ctx,2,local+4); /*logior*/
	local[1] = w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto piximageWHL504;
piximageWHX505:
	local[4]= NIL;
piximageBLK506:
	w = NIL;
	w = local[1];
	local[0]= w;
piximageBLK503:
	ctx->vsp=local; return(local[0]);}

/*:pixel-hex-string*/
static pointer piximageM507color_image_pixel_hex_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= fqv[67];
	local[2]= argv[0];
	local[3]= fqv[24];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
piximageBLK508:
	ctx->vsp=local; return(local[0]);}

/*:pixel-list*/
static pointer piximageM509color_image_pixel_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[14];
piximageWHL511:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto piximageWHX512;
	local[3]= argv[0];
	local[4]= argv[3];
	local[5]= local[1];
	local[6]= argv[2];
	local[7]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,3,local+3); /*aref*/
	local[3]= w;
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto piximageWHL511;
piximageWHX512:
	local[3]= NIL;
piximageBLK513:
	w = NIL;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)NREVERSE(ctx,1,local+1); /*nreverse*/
	local[0]= w;
piximageBLK510:
	ctx->vsp=local; return(local[0]);}

/*:patch-in*/
static pointer piximageM514color_image_patch_in(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= fqv[4];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[5];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[4];
	local[3]= fqv[4];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[4]->c.obj.iv[1];
	local[4]= NIL;
	local[5]= NIL;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= argv[4];
	local[8]= fqv[5];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
piximageWHL516:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto piximageWHX517;
	local[8]= argv[0]->c.obj.iv[12];
	local[9]= argv[3];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	local[10]= argv[2];
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[4] = w;
	local[8]= argv[0]->c.obj.iv[1];
	local[9]= local[3];
	local[10]= fqv[29];
	local[11]= local[4];
	local[12]= fqv[30];
	local[13]= local[4];
	local[14]= argv[0]->c.obj.iv[12];
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= fqv[31];
	local[15]= argv[0]->c.obj.iv[12];
	local[16]= local[6];
	local[17]= local[2];
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,3,local+15); /***/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[1])(ctx,8,local+8,&ftab[1],fqv[6]); /*replace*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto piximageWHL516;
piximageWHX517:
	local[8]= NIL;
piximageBLK518:
	w = NIL;
	local[0]= w;
piximageBLK515:
	ctx->vsp=local; return(local[0]);}

/*:subimage*/
static pointer piximageM519color_image_subimage(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[4];
	local[1]= argv[5];
	local[2]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,3,local+0); /***/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[53]); /*make-string*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[5];
piximageWHL521:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto piximageWHX522;
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= fqv[29];
	local[6]= local[1];
	local[7]= argv[4];
	local[8]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,3,local+6); /***/
	local[6]= w;
	local[7]= fqv[30];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[8]= w;
	local[9]= argv[4];
	local[10]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,3,local+8); /***/
	local[8]= w;
	local[9]= fqv[31];
	local[10]= argv[3];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	local[11]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	local[11]= argv[0]->c.obj.iv[14];
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[1])(ctx,8,local+3,&ftab[1],fqv[6]); /*replace*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto piximageWHL521;
piximageWHX522:
	local[3]= NIL;
piximageBLK523:
	w = NIL;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)GETCLASS(ctx,1,local+1); /*class*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[3];
	local[4]= argv[4];
	local[5]= argv[5];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	w = local[1];
	local[0]= w;
piximageBLK520:
	ctx->vsp=local; return(local[0]);}

/*:halve*/
static pointer piximageM524color_image_halve(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT527;}
	local[0]= NIL;
piximageENT527:
piximageENT526:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	if (local[0]!=NIL) goto piximageIF528;
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[3];
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = local[3];
	local[0] = w;
	local[3]= local[0];
	goto piximageIF529;
piximageIF528:
	local[3]= NIL;
piximageIF529:
	local[3]= argv[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,2,local+3,&ftab[4],fqv[27]); /*halve-image*/
	w = local[0];
	local[0]= w;
piximageBLK525:
	ctx->vsp=local; return(local[0]);}

/*:double*/
static pointer piximageM530color_image_double(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT533;}
	local[0]= NIL;
piximageENT533:
piximageENT532:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	if (local[0]!=NIL) goto piximageIF534;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)GETCLASS(ctx,1,local+3); /*class*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[3];
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = local[3];
	local[0] = w;
	local[3]= local[0];
	goto piximageIF535;
piximageIF534:
	local[3]= NIL;
piximageIF535:
	local[3]= argv[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[5])(ctx,2,local+3,&ftab[5],fqv[28]); /*double-image*/
	w = local[0];
	local[0]= w;
piximageBLK531:
	ctx->vsp=local; return(local[0]);}

/*:display*/
static pointer piximageM536color_image_display(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT541;}
	local[0]= loadglobal(fqv[39]);
piximageENT541:
	if (n>=4) { local[1]=(argv[3]); goto piximageENT540;}
	local[1]= makeint((eusinteger_t)0L);
piximageENT540:
	if (n>=5) { local[2]=(argv[4]); goto piximageENT539;}
	local[2]= makeint((eusinteger_t)0L);
piximageENT539:
piximageENT538:
	if (n>5) maerror();
	local[3]= local[0];
	local[4]= fqv[40];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= local[3];
	local[5]= local[4];
	if (fqv[68]!=local[5]) goto piximageIF542;
	local[5]= local[0];
	local[6]= fqv[42];
	if (loadglobal(fqv[32])==NIL) goto piximageIF544;
	local[7]= argv[0];
	local[8]= fqv[36];
	local[9]= loadglobal(fqv[69]);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w->c.obj.iv[1];
	goto piximageIF545;
piximageIF544:
	local[7]= argv[0]->c.obj.iv[1];
piximageIF545:
	local[8]= fqv[43];
	local[9]= local[1];
	local[10]= fqv[44];
	local[11]= local[2];
	local[12]= fqv[4];
	local[13]= argv[0]->c.obj.iv[6];
	local[14]= fqv[5];
	local[15]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,11,local+5); /*send*/
	local[5]= w;
	goto piximageIF543;
piximageIF542:
	local[5]= local[4];
	if (fqv[70]!=local[5]) goto piximageIF546;
	local[5]= local[0];
	local[6]= fqv[42];
	local[7]= argv[0];
	local[8]= fqv[46];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto piximageIF547;
piximageIF546:
	local[5]= local[4];
	if (fqv[71]!=local[5]) goto piximageIF548;
	local[5]= local[0];
	local[6]= fqv[42];
	local[7]= argv[0];
	local[8]= fqv[48];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto piximageIF549;
piximageIF548:
	local[5]= local[4];
	if (fqv[72]!=local[5]) goto piximageIF550;
	local[5]= local[0];
	local[6]= fqv[42];
	local[7]= argv[0];
	local[8]= fqv[50];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto piximageIF551;
piximageIF550:
	if (T==NIL) goto piximageIF552;
	local[5]= fqv[73];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[7])(ctx,2,local+5,&ftab[7],fqv[52]); /*warn*/
	local[5]= w;
	goto piximageIF553;
piximageIF552:
	local[5]= NIL;
piximageIF553:
piximageIF551:
piximageIF549:
piximageIF547:
piximageIF543:
	w = local[5];
	w = argv[0];
	local[0]= w;
piximageBLK537:
	ctx->vsp=local; return(local[0]);}

/*:component*/
static pointer piximageM554color_image_component(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto piximageENT557;}
	local[0]= NIL;
piximageENT557:
piximageENT556:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= argv[2];
	local[3]= argv[0];
	local[4]= fqv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	if (local[0]!=NIL) goto piximageIF558;
	local[5]= loadglobal(fqv[74]);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,1,local+5); /*instantiate*/
	local[5]= w;
	local[6]= local[5];
	local[7]= fqv[3];
	local[8]= local[3];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	w = local[5];
	local[0] = w;
	local[5]= local[0];
	goto piximageIF559;
piximageIF558:
	local[5]= NIL;
piximageIF559:
	local[5]= local[0];
	local[6]= fqv[75];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[1] = w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[3];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
piximageWHL560:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto piximageWHX561;
	local[7]= local[1];
	local[8]= local[5];
	local[9]= argv[0]->c.obj.iv[1];
	local[10]= local[5];
	local[11]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	{ register eusinteger_t i=intval(w);
	  w=makeint(local[9]->c.str.chars[i]);}
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[8]); v=local[7];
	  v->c.str.chars[i]=intval(w);}
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto piximageWHL560;
piximageWHX561:
	local[7]= NIL;
piximageBLK562:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK555:
	ctx->vsp=local; return(local[0]);}

/*:red*/
static pointer piximageM563color_image_red(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[76];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
piximageBLK564:
	ctx->vsp=local; return(local[0]);}

/*:green*/
static pointer piximageM565color_image_green(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[76];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
piximageBLK566:
	ctx->vsp=local; return(local[0]);}

/*:blue*/
static pointer piximageM567color_image_blue(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[76];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
piximageBLK568:
	ctx->vsp=local; return(local[0]);}

/*:pseudo2true*/
static pointer piximageM569color_image_pseudo2true(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[4];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= fqv[5];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= NIL;
	local[2]= argv[2];
	local[3]= fqv[75];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[0];
piximageWHL571:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto piximageWHX572;
	local[7]= local[2];
	{ register eusinteger_t i=intval(local[5]);
	  w=makeint(local[7]->c.str.chars[i]);}
	local[1] = w;
	local[7]= local[5];
	local[8]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[4] = w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[0]->c.obj.iv[12];
piximageWHL574:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto piximageWHX575;
	local[9]= local[3];
	local[10]= local[4];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	w = local[1];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[10]); v=local[9];
	  v->c.str.chars[i]=intval(w);}
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto piximageWHL574;
piximageWHX575:
	local[9]= NIL;
piximageBLK576:
	w = NIL;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto piximageWHL571;
piximageWHX572:
	local[7]= NIL;
piximageBLK573:
	w = NIL;
	w = argv[0];
	local[0]= w;
piximageBLK570:
	ctx->vsp=local; return(local[0]);}

/*:monochromize*/
static pointer piximageM577color_image_monochromize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT580;}
	local[0]= NIL;
piximageENT580:
piximageENT579:
	if (n>3) maerror();
	if (local[0]!=NIL) goto piximageIF581;
	local[1]= loadglobal(fqv[74]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[3];
	local[4]= argv[0];
	local[5]= fqv[4];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[5];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[0] = w;
	local[1]= local[0];
	goto piximageIF582;
piximageIF581:
	local[1]= NIL;
piximageIF582:
	local[1]= local[0];
	local[2]= fqv[75];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0];
	local[4]= fqv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
piximageWHL583:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto piximageWHX584;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[2];
	local[6]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= argv[0]->c.obj.iv[14];
piximageWHL586:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto piximageWHX587;
	local[8]= local[4];
	local[9]= argv[0]->c.obj.iv[1];
	local[10]= local[5];
	w = local[6];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	{ register eusinteger_t i=intval((pointer)((eusinteger_t)local[10] + (eusinteger_t)w));
	  w=makeint(local[9]->c.str.chars[i]);}
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[4] = w;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto piximageWHL586;
piximageWHX587:
	local[8]= NIL;
piximageBLK588:
	w = NIL;
	local[6]= local[1];
	local[7]= local[2];
	local[8]= local[4];
	local[9]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[7]); v=local[6];
	  v->c.str.chars[i]=intval(w);}
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto piximageWHL583;
piximageWHX584:
	local[4]= NIL;
piximageBLK585:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK578:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer piximageM589color_image16_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto piximageENT592;}
	local[0]= NIL;
piximageENT592:
piximageENT591:
	if (n>5) maerror();
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[12]));
	local[3]= fqv[3];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)16L);
	local[8]= makeint((eusinteger_t)3L);
	ctx->vsp=local+9;
	w=(pointer)SENDMESSAGE(ctx,8,local+1); /*send-message*/
	local[0]= w;
piximageBLK590:
	ctx->vsp=local; return(local[0]);}

/*:pixel*/
static pointer piximageM593color_image16_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= argv[3];
	local[3]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[1]= w;
	local[2]= fqv[64];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
piximageBLK594:
	ctx->vsp=local; return(local[0]);}

/*:set-pixel*/
static pointer piximageM595color_image16_set_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[4];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,piximageCLO597,env,argv,local);
	ctx->vsp=local+3;
	w=(*ftab[11])(ctx,0,local+3,&ftab[11],fqv[64]); /*:short*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,2,local+2); /*apply*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)POKE(ctx,3,local+0); /*system:poke*/
	local[0]= w;
piximageBLK596:
	ctx->vsp=local; return(local[0]);}

/*:pixel-hex-string*/
static pointer piximageM598color_image16_pixel_hex_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= fqv[77];
	local[2]= argv[0];
	local[3]= fqv[24];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
piximageBLK599:
	ctx->vsp=local; return(local[0]);}

/*:pixel-list*/
static pointer piximageM600color_image16_pixel_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[24];
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)11L);
	local[3]= makeint((eusinteger_t)5L);
	ctx->vsp=local+4;
	w=(pointer)LDB(ctx,3,local+1); /*ldb*/
	local[1]= w;
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)5L);
	local[4]= makeint((eusinteger_t)6L);
	ctx->vsp=local+5;
	w=(pointer)LDB(ctx,3,local+2); /*ldb*/
	local[2]= w;
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)5L);
	ctx->vsp=local+6;
	w=(pointer)LDB(ctx,3,local+3); /*ldb*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[0]= w;
piximageBLK601:
	ctx->vsp=local; return(local[0]);}

/*:to16*/
static pointer piximageM602color_image16_to16(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0];
	local[0]= w;
piximageBLK603:
	ctx->vsp=local; return(local[0]);}

/*:component*/
static pointer piximageM604color_image16_component(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= fqv[78];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
piximageBLK605:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer piximageCLO597(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[0];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[79],w);
	local[3]= env->c.clo.env1[3];
	local[4]= env->c.clo.env1[0]->c.obj.iv[6];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:pixel-list*/
static pointer piximageM606color_image24_pixel_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0]->c.obj.iv[14];
	local[1]= argv[2];
	local[2]= argv[3];
	local[3]= argv[0];
	local[4]= fqv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[0]);
	  w=makeint(local[1]->c.str.chars[i]);}
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	{ register eusinteger_t i=intval(w);
	  w=makeint(local[2]->c.str.chars[i]);}
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= local[0];
	w = makeint((eusinteger_t)2L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	{ register eusinteger_t i=intval((pointer)((eusinteger_t)local[4] + (eusinteger_t)w));
	  w=makeint(local[3]->c.str.chars[i]);}
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[0]= w;
piximageBLK607:
	ctx->vsp=local; return(local[0]);}

/*:to24*/
static pointer piximageM608color_image24_to24(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0];
	local[0]= w;
piximageBLK609:
	ctx->vsp=local; return(local[0]);}

/*:to16*/
static pointer piximageM610color_image24_to16(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[80]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[3];
	local[3]= argv[0];
	local[4]= fqv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[1];
	local[6]= argv[0];
	local[7]= fqv[4];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[5];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)piximageF130color_24to16(ctx,3,local+5); /*color-24to16*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	w = local[0];
	local[0]= w;
piximageBLK611:
	ctx->vsp=local; return(local[0]);}

/*:from32*/
static pointer piximageM612color_image24_from32(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)piximageF127color_32to24(ctx,4,local+0); /*color-32to24*/
	w = argv[0];
	local[0]= w;
piximageBLK613:
	ctx->vsp=local; return(local[0]);}

/*:to32*/
static pointer piximageM614color_image24_to32(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT617;}
	local[0]= NIL;
piximageENT617:
piximageENT616:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= local[1];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)piximageF128color_24to32(ctx,3,local+4); /*color-24to32*/
	local[3] = w;
	local[4]= loadglobal(fqv[81]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= local[4];
	local[6]= fqv[3];
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	w = local[4];
	local[0]= w;
piximageBLK615:
	ctx->vsp=local; return(local[0]);}

/*:hls*/
static pointer piximageM618color_image24_hls(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT621;}
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)GETCLASS(ctx,1,local+0); /*class*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[3];
	local[3]= argv[0];
	local[4]= fqv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
piximageENT621:
piximageENT620:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= local[0];
	local[4]= fqv[75];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[1];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
piximageWHL622:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto piximageWHX623;
	local[12]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[9]);
	  w=makeint(local[12]->c.str.chars[i]);}
	local[7] = w;
	local[12]= argv[0]->c.obj.iv[1];
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)ADD1(ctx,1,local+13); /*1+*/
	{ register eusinteger_t i=intval(w);
	  w=makeint(local[12]->c.str.chars[i]);}
	local[6] = w;
	local[12]= argv[0]->c.obj.iv[1];
	local[13]= local[9];
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	{ register eusinteger_t i=intval(w);
	  w=makeint(local[12]->c.str.chars[i]);}
	local[5] = w;
	local[12]= local[5];
	local[13]= local[6];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(*ftab[12])(ctx,3,local+12,&ftab[12],fqv[82]); /*rgb-to-hls*/
	local[8] = w;
	local[12]= local[3];
	local[13]= local[9];
	local[14]= local[8];
	local[15]= makeint((eusinteger_t)16L);
	local[16]= makeint((eusinteger_t)8L);
	ctx->vsp=local+17;
	w=(pointer)LDB(ctx,3,local+14); /*ldb*/
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[13]); v=local[12];
	  v->c.str.chars[i]=intval(w);}
	local[12]= local[3];
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)ADD1(ctx,1,local+13); /*1+*/
	local[13]= w;
	local[14]= local[8];
	local[15]= makeint((eusinteger_t)8L);
	local[16]= makeint((eusinteger_t)8L);
	ctx->vsp=local+17;
	w=(pointer)LDB(ctx,3,local+14); /*ldb*/
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[13]); v=local[12];
	  v->c.str.chars[i]=intval(w);}
	local[12]= local[3];
	local[13]= local[9];
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= local[8];
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)8L);
	ctx->vsp=local+17;
	w=(pointer)LDB(ctx,3,local+14); /*ldb*/
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[13]); v=local[12];
	  v->c.str.chars[i]=intval(w);}
	local[12]= local[9];
	local[13]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[9] = w;
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto piximageWHL622;
piximageWHX623:
	local[12]= NIL;
piximageBLK624:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK619:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer piximageM625color_image32_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto piximageENT628;}
	local[0]= NIL;
piximageENT628:
piximageENT627:
	if (n>5) maerror();
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[12]));
	local[3]= fqv[3];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)32L);
	local[8]= makeint((eusinteger_t)4L);
	ctx->vsp=local+9;
	w=(pointer)SENDMESSAGE(ctx,8,local+1); /*send-message*/
	w = argv[0];
	local[0]= w;
piximageBLK626:
	ctx->vsp=local; return(local[0]);}

/*:from24*/
static pointer piximageM629color_image32_from24(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)piximageF128color_24to32(ctx,4,local+0); /*color-24to32*/
	w = argv[0];
	local[0]= w;
piximageBLK630:
	ctx->vsp=local; return(local[0]);}

/*:to24*/
static pointer piximageM631color_image32_to24(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT634;}
	local[0]= NIL;
piximageENT634:
piximageENT633:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= local[1];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)piximageF127color_32to24(ctx,3,local+4); /*color-32to24*/
	local[3] = w;
	local[4]= loadglobal(fqv[59]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= local[4];
	local[6]= fqv[3];
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	w = local[4];
	local[0]= w;
piximageBLK632:
	ctx->vsp=local; return(local[0]);}

/*:to16*/
static pointer piximageM635color_image32_to16(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[48];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[46];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
piximageBLK636:
	ctx->vsp=local; return(local[0]);}

/*:to8*/
static pointer piximageM637color_image32_to8(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT640;}
	local[0]= NIL;
piximageENT640:
piximageENT639:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= local[1];
	local[5]= local[2];
	local[6]= local[0];
	local[7]= loadglobal(fqv[83]);
	ctx->vsp=local+8;
	w=(*ftab[13])(ctx,1,local+7,&ftab[13],fqv[84]); /*x::visual-masks*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)piximageF131color_32to8(ctx,5,local+3); /*color-32to8*/
	local[0] = w;
	local[3]= loadglobal(fqv[74]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[3];
	local[6]= local[1];
	local[7]= local[2];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	w = local[3];
	local[0]= w;
piximageBLK638:
	ctx->vsp=local; return(local[0]);}

/*:hls*/
static pointer piximageM641color_image32_hls(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT644;}
	local[0]= loadglobal(fqv[81]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[3];
	local[3]= argv[0];
	local[4]= fqv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
piximageENT644:
piximageENT643:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= local[0];
	local[4]= fqv[75];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[1];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
piximageWHL645:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto piximageWHX646;
	local[11]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[8]);
	  w=makeint(local[11]->c.str.chars[i]);}
	local[6] = w;
	local[11]= argv[0]->c.obj.iv[1];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	{ register eusinteger_t i=intval(w);
	  w=makeint(local[11]->c.str.chars[i]);}
	local[5] = w;
	local[11]= argv[0]->c.obj.iv[1];
	local[12]= local[8];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	{ register eusinteger_t i=intval(w);
	  w=makeint(local[11]->c.str.chars[i]);}
	local[4] = w;
	local[11]= local[4];
	local[12]= local[5];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(*ftab[12])(ctx,3,local+11,&ftab[12],fqv[82]); /*rgb-to-hls*/
	local[7] = w;
	local[11]= local[3];
	local[12]= local[8];
	local[13]= local[7];
	local[14]= makeint((eusinteger_t)16L);
	local[15]= makeint((eusinteger_t)8L);
	ctx->vsp=local+16;
	w=(pointer)LDB(ctx,3,local+13); /*ldb*/
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[12]); v=local[11];
	  v->c.str.chars[i]=intval(w);}
	local[11]= local[3];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[12]= w;
	local[13]= local[7];
	local[14]= makeint((eusinteger_t)8L);
	local[15]= makeint((eusinteger_t)8L);
	ctx->vsp=local+16;
	w=(pointer)LDB(ctx,3,local+13); /*ldb*/
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[12]); v=local[11];
	  v->c.str.chars[i]=intval(w);}
	local[11]= local[3];
	local[12]= local[8];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[12]= w;
	local[13]= local[7];
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)8L);
	ctx->vsp=local+16;
	w=(pointer)LDB(ctx,3,local+13); /*ldb*/
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[12]); v=local[11];
	  v->c.str.chars[i]=intval(w);}
	local[11]= local[8];
	local[12]= makeint((eusinteger_t)4L);
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[8] = w;
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto piximageWHL645;
piximageWHX646:
	local[11]= NIL;
piximageBLK647:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK642:
	ctx->vsp=local; return(local[0]);}

/*:component*/
static pointer piximageM648color_image32_component(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto piximageENT651;}
	local[0]= loadglobal(fqv[74]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[3];
	local[3]= argv[0];
	local[4]= fqv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
piximageENT651:
piximageENT650:
	if (n>4) maerror();
	local[1]= local[0];
	local[2]= fqv[75];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0];
	local[5]= fqv[58];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
piximageWHL652:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto piximageWHX653;
	local[5]= local[1];
	local[6]= local[3];
	local[7]= argv[0]->c.obj.iv[1];
	local[8]= local[3];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)4L)); i=intval(local[8]);
		local[8]=(makeint(i * j));}
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	{ register eusinteger_t i=intval(w);
	  w=makeint(local[7]->c.str.chars[i]);}
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[6]); v=local[5];
	  v->c.str.chars[i]=intval(w);}
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto piximageWHL652;
piximageWHX653:
	local[5]= NIL;
piximageBLK654:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK649:
	ctx->vsp=local; return(local[0]);}

/*:red*/
static pointer piximageM655color_image32_red(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[76];
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
piximageBLK656:
	ctx->vsp=local; return(local[0]);}

/*:green*/
static pointer piximageM657color_image32_green(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[76];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
piximageBLK658:
	ctx->vsp=local; return(local[0]);}

/*:blue*/
static pointer piximageM659color_image32_blue(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[76];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
piximageBLK660:
	ctx->vsp=local; return(local[0]);}

/*:monochromize*/
static pointer piximageM661color_image32_monochromize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto piximageENT664;}
	local[0]= loadglobal(fqv[74]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[3];
	local[3]= argv[0];
	local[4]= fqv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
piximageENT664:
piximageENT663:
	if (n>3) maerror();
	local[1]= local[0];
	local[2]= fqv[75];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)1L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0];
	local[5]= fqv[58];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
piximageWHL665:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto piximageWHX666;
	local[5]= local[1];
	local[6]= local[3];
	local[7]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[2]);
	  w=makeint(local[7]->c.str.chars[i]);}
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[1];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	{ register eusinteger_t i=intval(w);
	  w=makeint(local[8]->c.str.chars[i]);}
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[1];
	local[10]= local[2];
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	{ register eusinteger_t i=intval(w);
	  w=makeint(local[9]->c.str.chars[i]);}
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,3,local+7); /*+*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)3L);
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[6]); v=local[5];
	  v->c.str.chars[i]=intval(w);}
	local[5]= local[2];
	local[6]= makeint((eusinteger_t)4L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[2] = w;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto piximageWHL665;
piximageWHX666:
	local[5]= NIL;
piximageBLK667:
	w = NIL;
	w = local[0];
	local[0]= w;
piximageBLK662:
	ctx->vsp=local; return(local[0]);}

/*color-to-deep*/
static pointer piximageF136color_to_deep(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[59]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[3];
	local[3]= argv[0];
	local[4]= fqv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	w = local[0];
	local[0]= w;
piximageBLK668:
	ctx->vsp=local; return(local[0]);}

/*copy-color-map*/
static pointer piximageF137copy_color_map(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[2];
piximageWHL670:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto piximageWHX671;
	local[2]= argv[0];
	local[3]= fqv[85];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[1];
	local[4]= fqv[86];
	local[5]= NIL;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,6,local+3); /*send*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto piximageWHL670;
piximageWHX671:
	local[2]= NIL;
piximageBLK672:
	w = NIL;
	local[0]= w;
piximageBLK669:
	ctx->vsp=local; return(local[0]);}

/*make-ximage*/
static pointer piximageF138make_ximage(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto piximageENT675;}
	local[0]= loadglobal(fqv[38]);
piximageENT675:
piximageENT674:
	if (n>2) maerror();
	local[1]= NIL;
	local[2]= argv[0];
	local[3]= fqv[87];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[1] = w;
	local[2]= local[1];
	local[3]= fqv[88];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	w = local[1];
	local[0]= w;
piximageBLK673:
	ctx->vsp=local; return(local[0]);}

/*make-colors*/
static pointer piximageF139make_colors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	if (argv[0]==NIL) goto piximageIF677;
	local[0]= loadglobal(fqv[89]);
	storeglobal(fqv[90],local[0]);
	goto piximageIF678;
piximageIF677:
	local[0]= loadglobal(fqv[91]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[92];
	local[3]= fqv[93];
	local[4]= makeint((eusinteger_t)256L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
	storeglobal(fqv[90],w);
	local[0]= loadglobal(fqv[89]);
	local[1]= loadglobal(fqv[90]);
	local[2]= makeint((eusinteger_t)32L);
	ctx->vsp=local+3;
	w=(pointer)piximageF137copy_color_map(ctx,3,local+0); /*copy-color-map*/
	local[0]= w;
piximageIF678:
	local[0]= loadglobal(fqv[90]);
	local[1]= fqv[94];
	local[2]= fqv[95];
	local[3]= makeint((eusinteger_t)16L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	storeglobal(fqv[96],w);
	local[0]= loadglobal(fqv[90]);
	local[1]= fqv[94];
	local[2]= fqv[97];
	local[3]= makeint((eusinteger_t)32L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	storeglobal(fqv[98],w);
	local[0]= loadglobal(fqv[90]);
	local[1]= fqv[99];
	local[2]= fqv[100];
	local[3]= makeint((eusinteger_t)32L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)360L);
	local[6]= makeflt(5.0000000000000000000000e-01);
	local[7]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,8,local+0); /*send*/
	local[0]= w;
	storeglobal(fqv[101],w);
	local[0]= loadglobal(fqv[90]);
	local[1]= fqv[99];
	local[2]= fqv[102];
	local[3]= makeint((eusinteger_t)16L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)360L);
	local[6]= makeflt(5.0000000000000000000000e-01);
	local[7]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,8,local+0); /*send*/
	local[0]= w;
	storeglobal(fqv[103],w);
	local[0]= loadglobal(fqv[90]);
	local[1]= fqv[104];
	local[2]= fqv[105];
	local[3]= makeint((eusinteger_t)16L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeflt(9.9999999999999977795540e-02);
	local[6]= makeflt(5.0000000000000000000000e-01);
	local[7]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,8,local+0); /*send*/
	local[0]= w;
	storeglobal(fqv[106],w);
	local[0]= loadglobal(fqv[90]);
	local[1]= fqv[104];
	local[2]= fqv[107];
	local[3]= makeint((eusinteger_t)16L);
	local[4]= makeint((eusinteger_t)120L);
	local[5]= makeflt(9.9999999999999977795540e-02);
	local[6]= makeflt(5.0000000000000000000000e-01);
	local[7]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,8,local+0); /*send*/
	local[0]= w;
	storeglobal(fqv[108],w);
	local[0]= loadglobal(fqv[90]);
	local[1]= fqv[104];
	local[2]= fqv[109];
	local[3]= makeint((eusinteger_t)16L);
	local[4]= makeint((eusinteger_t)240L);
	local[5]= makeflt(9.9999999999999977795540e-02);
	local[6]= makeflt(5.0000000000000000000000e-01);
	local[7]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,8,local+0); /*send*/
	local[0]= w;
	storeglobal(fqv[110],w);
	local[0]= loadglobal(fqv[90]);
	local[1]= fqv[111];
	local[2]= fqv[112];
	local[3]= fqv[113];
	local[4]= makeint((eusinteger_t)65535L);
	local[5]= makeint((eusinteger_t)40000L);
	local[6]= makeint((eusinteger_t)40000L);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,3,local+4); /*list*/
	local[4]= w;
	local[5]= fqv[114];
	local[6]= fqv[115];
	local[7]= fqv[116];
	local[8]= fqv[117];
	local[9]= fqv[118];
	local[10]= fqv[119];
	local[11]= fqv[120];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,9,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	storeglobal(fqv[121],w);
	local[0]= makeint((eusinteger_t)8L);
	ctx->vsp=local+1;
	w=(pointer)piximageF123make_equilevel_lut(ctx,1,local+0); /*make-equilevel-lut*/
	local[0]= w;
	storeglobal(fqv[122],w);
	local[0]= makeint((eusinteger_t)16L);
	ctx->vsp=local+1;
	w=(pointer)piximageF123make_equilevel_lut(ctx,1,local+0); /*make-equilevel-lut*/
	local[0]= w;
	storeglobal(fqv[123],w);
	local[0]= makeint((eusinteger_t)32L);
	ctx->vsp=local+1;
	w=(pointer)piximageF123make_equilevel_lut(ctx,1,local+0); /*make-equilevel-lut*/
	local[0]= w;
	storeglobal(fqv[124],w);
	local[0]= loadglobal(fqv[123]);
	local[1]= loadglobal(fqv[96]);
	ctx->vsp=local+2;
	w=(pointer)piximageF126concatenate_lut(ctx,2,local+0); /*concatenate-lut*/
	local[0]= w;
	storeglobal(fqv[125],w);
	local[0]= loadglobal(fqv[124]);
	local[1]= loadglobal(fqv[98]);
	ctx->vsp=local+2;
	w=(pointer)piximageF126concatenate_lut(ctx,2,local+0); /*concatenate-lut*/
	local[0]= w;
	storeglobal(fqv[38],w);
	local[0]= loadglobal(fqv[123]);
	local[1]= loadglobal(fqv[103]);
	ctx->vsp=local+2;
	w=(pointer)piximageF126concatenate_lut(ctx,2,local+0); /*concatenate-lut*/
	local[0]= w;
	storeglobal(fqv[126],w);
	local[0]= loadglobal(fqv[124]);
	local[1]= loadglobal(fqv[101]);
	ctx->vsp=local+2;
	w=(pointer)piximageF126concatenate_lut(ctx,2,local+0); /*concatenate-lut*/
	local[0]= w;
	storeglobal(fqv[127],w);
	local[0]= loadglobal(fqv[123]);
	ctx->vsp=local+1;
	w=(pointer)REVERSE(ctx,1,local+0); /*reverse*/
	local[0]= w;
	local[1]= loadglobal(fqv[101]);
	local[2]= makeint((eusinteger_t)8L);
	local[3]= makeint((eusinteger_t)24L);
	ctx->vsp=local+4;
	w=(pointer)SUBSEQ(ctx,3,local+1); /*subseq*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)piximageF126concatenate_lut(ctx,2,local+0); /*concatenate-lut*/
	local[0]= w;
	storeglobal(fqv[128],w);
	local[0]= loadglobal(fqv[123]);
	local[1]= loadglobal(fqv[106]);
	ctx->vsp=local+2;
	w=(pointer)piximageF126concatenate_lut(ctx,2,local+0); /*concatenate-lut*/
	local[0]= w;
	storeglobal(fqv[129],w);
	local[0]= loadglobal(fqv[123]);
	local[1]= loadglobal(fqv[108]);
	ctx->vsp=local+2;
	w=(pointer)piximageF126concatenate_lut(ctx,2,local+0); /*concatenate-lut*/
	local[0]= w;
	storeglobal(fqv[130],w);
	local[0]= loadglobal(fqv[123]);
	local[1]= loadglobal(fqv[110]);
	ctx->vsp=local+2;
	w=(pointer)piximageF126concatenate_lut(ctx,2,local+0); /*concatenate-lut*/
	local[0]= w;
	storeglobal(fqv[131],w);
	w = local[0];
	local[0]= w;
piximageBLK676:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___piximage(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[132];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto piximageIF679;
	local[0]= fqv[133];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[134],w);
	goto piximageIF680;
piximageIF679:
	local[0]= fqv[135];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
piximageIF680:
	local[0]= fqv[136];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[137];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[138];
	ctx->vsp=local+1;
	w=(*ftab[14])(ctx,1,local+0,&ftab[14],fqv[139]); /*use-package*/
	local[0]= fqv[125];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF681;
	local[0]= fqv[125];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[125];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF683;
	local[0]= fqv[125];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF684;
piximageIF683:
	local[0]= NIL;
piximageIF684:
	local[0]= fqv[125];
	goto piximageIF682;
piximageIF681:
	local[0]= NIL;
piximageIF682:
	local[0]= fqv[38];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF685;
	local[0]= fqv[38];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[38];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF687;
	local[0]= fqv[38];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF688;
piximageIF687:
	local[0]= NIL;
piximageIF688:
	local[0]= fqv[38];
	goto piximageIF686;
piximageIF685:
	local[0]= NIL;
piximageIF686:
	local[0]= fqv[128];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF689;
	local[0]= fqv[128];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[128];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF691;
	local[0]= fqv[128];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF692;
piximageIF691:
	local[0]= NIL;
piximageIF692:
	local[0]= fqv[128];
	goto piximageIF690;
piximageIF689:
	local[0]= NIL;
piximageIF690:
	local[0]= fqv[129];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF693;
	local[0]= fqv[129];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[129];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF695;
	local[0]= fqv[129];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF696;
piximageIF695:
	local[0]= NIL;
piximageIF696:
	local[0]= fqv[129];
	goto piximageIF694;
piximageIF693:
	local[0]= NIL;
piximageIF694:
	local[0]= fqv[130];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF697;
	local[0]= fqv[130];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[130];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF699;
	local[0]= fqv[130];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF700;
piximageIF699:
	local[0]= NIL;
piximageIF700:
	local[0]= fqv[130];
	goto piximageIF698;
piximageIF697:
	local[0]= NIL;
piximageIF698:
	local[0]= fqv[131];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF701;
	local[0]= fqv[131];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[131];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF703;
	local[0]= fqv[131];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF704;
piximageIF703:
	local[0]= NIL;
piximageIF704:
	local[0]= fqv[131];
	goto piximageIF702;
piximageIF701:
	local[0]= NIL;
piximageIF702:
	local[0]= fqv[126];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF705;
	local[0]= fqv[126];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[126];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF707;
	local[0]= fqv[126];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF708;
piximageIF707:
	local[0]= NIL;
piximageIF708:
	local[0]= fqv[126];
	goto piximageIF706;
piximageIF705:
	local[0]= NIL;
piximageIF706:
	local[0]= fqv[127];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF709;
	local[0]= fqv[127];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[127];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF711;
	local[0]= fqv[127];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF712;
piximageIF711:
	local[0]= NIL;
piximageIF712:
	local[0]= fqv[127];
	goto piximageIF710;
piximageIF709:
	local[0]= NIL;
piximageIF710:
	local[0]= fqv[142];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF713;
	local[0]= fqv[142];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[142];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF715;
	local[0]= fqv[142];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF716;
piximageIF715:
	local[0]= NIL;
piximageIF716:
	local[0]= fqv[142];
	goto piximageIF714;
piximageIF713:
	local[0]= NIL;
piximageIF714:
	local[0]= fqv[96];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF717;
	local[0]= fqv[96];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[96];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF719;
	local[0]= fqv[96];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF720;
piximageIF719:
	local[0]= NIL;
piximageIF720:
	local[0]= fqv[96];
	goto piximageIF718;
piximageIF717:
	local[0]= NIL;
piximageIF718:
	local[0]= fqv[98];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF721;
	local[0]= fqv[98];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[98];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF723;
	local[0]= fqv[98];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF724;
piximageIF723:
	local[0]= NIL;
piximageIF724:
	local[0]= fqv[98];
	goto piximageIF722;
piximageIF721:
	local[0]= NIL;
piximageIF722:
	local[0]= fqv[103];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF725;
	local[0]= fqv[103];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[103];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF727;
	local[0]= fqv[103];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF728;
piximageIF727:
	local[0]= NIL;
piximageIF728:
	local[0]= fqv[103];
	goto piximageIF726;
piximageIF725:
	local[0]= NIL;
piximageIF726:
	local[0]= fqv[101];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF729;
	local[0]= fqv[101];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[101];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF731;
	local[0]= fqv[101];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF732;
piximageIF731:
	local[0]= NIL;
piximageIF732:
	local[0]= fqv[101];
	goto piximageIF730;
piximageIF729:
	local[0]= NIL;
piximageIF730:
	local[0]= fqv[106];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF733;
	local[0]= fqv[106];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[106];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF735;
	local[0]= fqv[106];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF736;
piximageIF735:
	local[0]= NIL;
piximageIF736:
	local[0]= fqv[106];
	goto piximageIF734;
piximageIF733:
	local[0]= NIL;
piximageIF734:
	local[0]= fqv[108];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF737;
	local[0]= fqv[108];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[108];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF739;
	local[0]= fqv[108];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF740;
piximageIF739:
	local[0]= NIL;
piximageIF740:
	local[0]= fqv[108];
	goto piximageIF738;
piximageIF737:
	local[0]= NIL;
piximageIF738:
	local[0]= fqv[110];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF741;
	local[0]= fqv[110];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[110];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF743;
	local[0]= fqv[110];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF744;
piximageIF743:
	local[0]= NIL;
piximageIF744:
	local[0]= fqv[110];
	goto piximageIF742;
piximageIF741:
	local[0]= NIL;
piximageIF742:
	local[0]= fqv[121];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF745;
	local[0]= fqv[121];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[121];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF747;
	local[0]= fqv[121];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF748;
piximageIF747:
	local[0]= NIL;
piximageIF748:
	local[0]= fqv[121];
	goto piximageIF746;
piximageIF745:
	local[0]= NIL;
piximageIF746:
	local[0]= fqv[122];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF749;
	local[0]= fqv[122];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[122];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF751;
	local[0]= fqv[122];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF752;
piximageIF751:
	local[0]= NIL;
piximageIF752:
	local[0]= fqv[122];
	goto piximageIF750;
piximageIF749:
	local[0]= NIL;
piximageIF750:
	local[0]= fqv[123];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF753;
	local[0]= fqv[123];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[123];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF755;
	local[0]= fqv[123];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF756;
piximageIF755:
	local[0]= NIL;
piximageIF756:
	local[0]= fqv[123];
	goto piximageIF754;
piximageIF753:
	local[0]= NIL;
piximageIF754:
	local[0]= fqv[124];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF757;
	local[0]= fqv[124];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[124];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF759;
	local[0]= fqv[124];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF760;
piximageIF759:
	local[0]= NIL;
piximageIF760:
	local[0]= fqv[124];
	goto piximageIF758;
piximageIF757:
	local[0]= NIL;
piximageIF758:
	local[0]= fqv[90];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto piximageIF761;
	local[0]= fqv[90];
	local[1]= fqv[140];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[90];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto piximageIF763;
	local[0]= fqv[90];
	local[1]= fqv[141];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto piximageIF764;
piximageIF763:
	local[0]= NIL;
piximageIF764:
	local[0]= fqv[90];
	goto piximageIF762;
piximageIF761:
	local[0]= NIL;
piximageIF762:
	ctx->vsp=local+0;
	compfun(ctx,fqv[143],module,piximageF123make_equilevel_lut,fqv[144]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[145],module,piximageF124look_up2,fqv[146]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[147],module,piximageF125look_up_,fqv[148]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[149],module,piximageF126concatenate_lut,fqv[150]);
	local[0]= fqv[151];
	local[1]= fqv[141];
	local[2]= fqv[151];
	local[3]= fqv[152];
	local[4]= loadglobal(fqv[153]);
	local[5]= fqv[154];
	local[6]= fqv[155];
	local[7]= fqv[156];
	local[8]= NIL;
	local[9]= fqv[15];
	local[10]= NIL;
	local[11]= fqv[58];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[157];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[15])(ctx,13,local+2,&ftab[15],fqv[158]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[159];
	local[1]= fqv[141];
	local[2]= fqv[159];
	local[3]= fqv[152];
	local[4]= loadglobal(fqv[151]);
	local[5]= fqv[154];
	local[6]= fqv[160];
	local[7]= fqv[156];
	local[8]= NIL;
	local[9]= fqv[15];
	local[10]= NIL;
	local[11]= fqv[58];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[157];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[15])(ctx,13,local+2,&ftab[15],fqv[158]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[161];
	local[1]= fqv[141];
	local[2]= fqv[161];
	local[3]= fqv[152];
	local[4]= loadglobal(fqv[159]);
	local[5]= fqv[154];
	local[6]= fqv[160];
	local[7]= fqv[156];
	local[8]= NIL;
	local[9]= fqv[15];
	local[10]= NIL;
	local[11]= fqv[58];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[157];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[15])(ctx,13,local+2,&ftab[15],fqv[158]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[74];
	local[1]= fqv[141];
	local[2]= fqv[74];
	local[3]= fqv[152];
	local[4]= loadglobal(fqv[159]);
	local[5]= fqv[154];
	local[6]= fqv[160];
	local[7]= fqv[156];
	local[8]= NIL;
	local[9]= fqv[15];
	local[10]= NIL;
	local[11]= fqv[58];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[157];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[15])(ctx,13,local+2,&ftab[15],fqv[158]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[33];
	local[1]= fqv[141];
	local[2]= fqv[33];
	local[3]= fqv[152];
	local[4]= loadglobal(fqv[159]);
	local[5]= fqv[154];
	local[6]= fqv[160];
	local[7]= fqv[156];
	local[8]= NIL;
	local[9]= fqv[15];
	local[10]= NIL;
	local[11]= fqv[58];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[157];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[15])(ctx,13,local+2,&ftab[15],fqv[158]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[162];
	local[1]= fqv[141];
	local[2]= fqv[162];
	local[3]= fqv[152];
	local[4]= loadglobal(fqv[151]);
	local[5]= fqv[154];
	local[6]= fqv[163];
	local[7]= fqv[156];
	local[8]= NIL;
	local[9]= fqv[15];
	local[10]= NIL;
	local[11]= fqv[58];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[157];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[15])(ctx,13,local+2,&ftab[15],fqv[158]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[164];
	local[1]= fqv[141];
	local[2]= fqv[164];
	local[3]= fqv[152];
	local[4]= loadglobal(fqv[162]);
	local[5]= fqv[154];
	local[6]= fqv[160];
	local[7]= fqv[156];
	local[8]= NIL;
	local[9]= fqv[15];
	local[10]= NIL;
	local[11]= fqv[58];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[157];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[15])(ctx,13,local+2,&ftab[15],fqv[158]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[165];
	local[1]= fqv[141];
	local[2]= fqv[165];
	local[3]= fqv[152];
	local[4]= loadglobal(fqv[162]);
	local[5]= fqv[154];
	local[6]= fqv[166];
	local[7]= fqv[156];
	local[8]= NIL;
	local[9]= fqv[15];
	local[10]= NIL;
	local[11]= fqv[58];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[157];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[15])(ctx,13,local+2,&ftab[15],fqv[158]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[80];
	local[1]= fqv[141];
	local[2]= fqv[80];
	local[3]= fqv[152];
	local[4]= loadglobal(fqv[165]);
	local[5]= fqv[154];
	local[6]= fqv[160];
	local[7]= fqv[156];
	local[8]= NIL;
	local[9]= fqv[15];
	local[10]= NIL;
	local[11]= fqv[58];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[157];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[15])(ctx,13,local+2,&ftab[15],fqv[158]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[59];
	local[1]= fqv[141];
	local[2]= fqv[59];
	local[3]= fqv[152];
	local[4]= loadglobal(fqv[165]);
	local[5]= fqv[154];
	local[6]= fqv[160];
	local[7]= fqv[156];
	local[8]= NIL;
	local[9]= fqv[15];
	local[10]= NIL;
	local[11]= fqv[58];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[157];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[15])(ctx,13,local+2,&ftab[15],fqv[158]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[81];
	local[1]= fqv[141];
	local[2]= fqv[81];
	local[3]= fqv[152];
	local[4]= loadglobal(fqv[165]);
	local[5]= fqv[154];
	local[6]= fqv[160];
	local[7]= fqv[156];
	local[8]= NIL;
	local[9]= fqv[15];
	local[10]= NIL;
	local[11]= fqv[58];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[157];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[15])(ctx,13,local+2,&ftab[15],fqv[158]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM170image_2d_entity,fqv[75],fqv[151],fqv[167]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM172image_2d_width,fqv[4],fqv[151],fqv[168]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM174image_2d_height,fqv[5],fqv[151],fqv[169]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM176image_2d_size,fqv[58],fqv[151],fqv[170]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM178image_2d_pixel,fqv[24],fqv[151],fqv[171]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM180image_2d_set_pixel,fqv[23],fqv[151],fqv[172]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM182image_2d_duplicate,fqv[25],fqv[151],fqv[173]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM185image_2d_copy_from,fqv[174],fqv[151],fqv[175]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM187image_2d_copy,fqv[176],fqv[151],fqv[177]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM189image_2d_hex,fqv[178],fqv[151],fqv[179]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM203image_2d_prin1,fqv[13],fqv[151],fqv[180]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM206image_2d_init,fqv[3],fqv[151],fqv[181]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM218image_2d_fill,fqv[22],fqv[151],fqv[182]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM220image_2d_clear,fqv[183],fqv[151],fqv[184]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM222image_2d_transpose,fqv[185],fqv[151],fqv[186]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM232image_2d_map_picture,fqv[187],fqv[151],fqv[188]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM239image_2d_map,fqv[189],fqv[151],fqv[190]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM246single_channel_image_pixel,fqv[24],fqv[159],fqv[191]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM248single_channel_image_set_pixel,fqv[23],fqv[159],fqv[192]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM250single_channel_image_pixel_hex_string,fqv[9],fqv[159],fqv[193]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM252single_channel_image_halve,fqv[194],fqv[159],fqv[195]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM258single_channel_image_double,fqv[196],fqv[159],fqv[197]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM264single_channel_image_patch_in,fqv[198],fqv[159],fqv[199]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM269single_channel_image_xpicture,fqv[36],fqv[159],fqv[200]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM277single_channel_image_display_lut,fqv[34],fqv[159],fqv[201]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM285single_channel_image_display,fqv[88],fqv[159],fqv[202]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM304single_channel_image_subimage,fqv[203],fqv[159],fqv[204]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM309single_channel_image_patch_in,fqv[198],fqv[159],fqv[205]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM314single_channel_image_brightest_pixel,fqv[206],fqv[159],fqv[207]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM321single_channel_image_darkest_pixel,fqv[208],fqv[159],fqv[209]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM328single_channel_image_average_pixel,fqv[210],fqv[159],fqv[211]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM330single_channel_image_amplify,fqv[212],fqv[159],fqv[213]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM337single_channel_image_compress_gray_scale,fqv[214],fqv[159],fqv[215]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM346single_channel_image_lut,fqv[87],fqv[159],fqv[216]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM350single_channel_image_lut2,fqv[217],fqv[159],fqv[218]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM354single_channel_image_to24,fqv[48],fqv[159],fqv[219]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM359single_channel_image_to32,fqv[50],fqv[159],fqv[220]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM361single_channel_image_to16,fqv[46],fqv[159],fqv[221]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM363bitmap_image_init,fqv[3],fqv[161],fqv[222]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM367bitmap_image_pixel_hex_string,fqv[9],fqv[161],fqv[223]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[224],module,piximageF127color_32to24,fqv[225]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[226],module,piximageF128color_24to32,fqv[227]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[228],module,piximageF129color_24to8,fqv[229]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[230],module,piximageF130color_24to16,fqv[231]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[232],module,piximageF131color_32to8,fqv[233]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[234],module,piximageF132color_24to6,fqv[235]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[236],module,piximageF133color_32to8x3,fqv[237]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[238],module,piximageF134color_24to8x3,fqv[239]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[240],module,piximageF135swap_rgb,fqv[241]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM486multi_channel_image_components,fqv[242],fqv[162],fqv[243]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM488color_image_init,fqv[3],fqv[165],fqv[244]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM496color_image_depth,fqv[40],fqv[165],fqv[245]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM498color_image_byte_depth,fqv[246],fqv[165],fqv[247]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM500color_image_width,fqv[4],fqv[165],fqv[248]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM502color_image_pixel,fqv[24],fqv[165],fqv[249]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM507color_image_pixel_hex_string,fqv[9],fqv[165],fqv[250]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM509color_image_pixel_list,fqv[251],fqv[165],fqv[252]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM514color_image_patch_in,fqv[198],fqv[165],fqv[253]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM519color_image_subimage,fqv[203],fqv[165],fqv[254]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM524color_image_halve,fqv[194],fqv[165],fqv[255]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM530color_image_double,fqv[196],fqv[165],fqv[256]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM536color_image_display,fqv[88],fqv[165],fqv[257]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM554color_image_component,fqv[76],fqv[165],fqv[258]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM563color_image_red,fqv[259],fqv[165],fqv[260]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM565color_image_green,fqv[261],fqv[165],fqv[262]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM567color_image_blue,fqv[263],fqv[165],fqv[264]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM569color_image_pseudo2true,fqv[265],fqv[165],fqv[266]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM577color_image_monochromize,fqv[267],fqv[165],fqv[268]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM589color_image16_init,fqv[3],fqv[80],fqv[269]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM593color_image16_pixel,fqv[24],fqv[80],fqv[270]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM595color_image16_set_pixel,fqv[23],fqv[80],fqv[271]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM598color_image16_pixel_hex_string,fqv[9],fqv[80],fqv[272]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM600color_image16_pixel_list,fqv[251],fqv[80],fqv[273]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM602color_image16_to16,fqv[46],fqv[80],fqv[274]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM604color_image16_component,fqv[76],fqv[80],fqv[275]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM606color_image24_pixel_list,fqv[251],fqv[59],fqv[276]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM608color_image24_to24,fqv[48],fqv[59],fqv[277]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM610color_image24_to16,fqv[46],fqv[59],fqv[278]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM612color_image24_from32,fqv[279],fqv[59],fqv[280]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM614color_image24_to32,fqv[50],fqv[59],fqv[281]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM618color_image24_hls,fqv[282],fqv[59],fqv[283]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM625color_image32_init,fqv[3],fqv[81],fqv[284]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM629color_image32_from24,fqv[285],fqv[81],fqv[286]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM631color_image32_to24,fqv[48],fqv[81],fqv[287]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM635color_image32_to16,fqv[46],fqv[81],fqv[288]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM637color_image32_to8,fqv[289],fqv[81],fqv[290]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM641color_image32_hls,fqv[282],fqv[81],fqv[291]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM648color_image32_component,fqv[76],fqv[81],fqv[292]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM655color_image32_red,fqv[259],fqv[81],fqv[293]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM657color_image32_green,fqv[261],fqv[81],fqv[294]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM659color_image32_blue,fqv[263],fqv[81],fqv[295]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,piximageM661color_image32_monochromize,fqv[267],fqv[81],fqv[296]);
	local[0]= fqv[297];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[297],module,piximageF136color_to_deep,fqv[298]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[299],module,piximageF137copy_color_map,fqv[300]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[301],module,piximageF138make_ximage,fqv[302]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[303],module,piximageF139make_colors,fqv[304]);
	local[0]= fqv[305];
	local[1]= fqv[306];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[307]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<17; i++) ftab[i]=fcallx;
}

static pointer (*ftab[4])();

#define QUOTE_STRINGS_SIZE 17
static char *quote_strings[QUOTE_STRINGS_SIZE]={
    "user::dvector2float-bytestring",
    "glunurbscurve-org",
    "glunurbssurface-org",
    ":gluforeign",
    "provide",
    "\"GL\"",
    "\"GL\"",
    "*package*",
    "\"no such package\"",
    "(gluerrorstring gluortho2d gluperspective glupickmatrix glulookat gluproject gluunproject gluscaleimage glubuild1dmipmaps glubuild2dmipmaps glunewquadric gludeletequadric gluquadricnormals gluquadrictexture gluquadricorientation gluquadricdrawstyle glucylinder gludisk glupartialdisk glusphere gluquadriccallback glunewtess glutesscallback gludeletetess glubeginpolygon gluendpolygon glunextcontour glutessvertex glunewnurbsrenderer gludeletenurbsrenderer glubeginsurface glubegincurve gluendcurve gluendsurface glubegintrim gluendtrim glupwlcurve glunurbscurve glunurbssurface gluloadsamplingmatrices glunurbsproperty glugetnurbsproperty glunurbscallback)",
    "glunurbsproperty-org",
    "glunurbsproperty",
    "glunurbspropertyd",
    "glunurbscurve",
    "glunurbssurface",
    "\"(nobj nknots knot stride ctlarray order type)\"",
    "\"(nurb sknotcount sknots tknotcount tknots sstride tstride control sorder torder type)\"",
  };

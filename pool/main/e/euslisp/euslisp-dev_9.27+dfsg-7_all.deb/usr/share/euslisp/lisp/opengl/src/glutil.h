static pointer (*ftab[1])();

#define QUOTE_STRINGS_SIZE 7
static char *quote_strings[QUOTE_STRINGS_SIZE]={
    ":glutil",
    "provide",
    "\"GL\"",
    "\"GL\"",
    "*package*",
    "\"no such package\"",
    "(glclearcolorfv glortho6f glorthofv glrotatefv gltranslatefv auxsolidteapotfv glclipplanef auxsolidspherefv auxwirespherefv auxsolidcylinderfv auxsolidconefv auxsolidboxfv gluperspectivefv glulookatfv glutesscallbackl auxsolidtorusfv auxsolidcubefv auxsolidoctahedronfv glaccumfv glclearaccumfv gludiskfv glupartialdiskfv auxwireicosahedronfv glscalefv glunurbsproperty glbitmapfv glmap2fv auxsetonecolorfv glaccumfv glfrustumfv gluortho2dfv glpointsizefv glclearindexfv glpolygonoffsetextfv)",
  };

static pointer (*ftab[2])();

#define QUOTE_STRINGS_SIZE 11
static char *quote_strings[QUOTE_STRINGS_SIZE]={
    "glxchoosevisual-for-wrap",
    "user::lvector2integer-bytestring",
    ":glxforeign",
    "provide",
    "\"GL\"",
    "\"GL\"",
    "*package*",
    "\"no such package\"",
    "(glxchoosevisual glxcopycontext glxcreatecontext glxcreateglxpixmap glxdestroycontext glxdestroyglxpixmap glxgetconfig glxgetcurrentcontext glxgetcurrentdrawable glxisdirect glxmakecurrent glxqueryextension glxqueryversion glxswapbuffers glxusexfont glxwaitgl glxwaitx)",
    "glxchoosevisual",
    "\"(display screen attr)\"",
  };

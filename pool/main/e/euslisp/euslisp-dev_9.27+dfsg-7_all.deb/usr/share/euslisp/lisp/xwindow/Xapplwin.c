/* ./Xapplwin.c :  entry=Xapplwin */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "Xapplwin.h"
#pragma init (register_Xapplwin)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___Xapplwin();
extern pointer build_quote_vector();
static int register_Xapplwin()
  { add_module_initializer("___Xapplwin", ___Xapplwin);}

static pointer XapplwinF3174ls_l();

/*:create-buttons*/
static pointer XapplwinM3175filedialog_create_buttons(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[0];
	local[2]= loadglobal(fqv[1]);
	local[3]= fqv[2];
	local[4]= argv[0];
	local[5]= fqv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	argv[0]->c.obj.iv[31] = w;
	local[0]= argv[0];
	local[1]= fqv[0];
	local[2]= loadglobal(fqv[1]);
	local[3]= fqv[4];
	local[4]= argv[0];
	local[5]= fqv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	argv[0]->c.obj.iv[32] = w;
	local[0]= argv[0];
	local[1]= fqv[0];
	local[2]= loadglobal(fqv[1]);
	local[3]= fqv[6];
	local[4]= argv[0];
	local[5]= fqv[7];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	argv[0]->c.obj.iv[26] = w;
	local[0]= argv[0];
	local[1]= fqv[0];
	local[2]= loadglobal(fqv[1]);
	local[3]= fqv[8];
	local[4]= argv[0];
	local[5]= fqv[9];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	argv[0]->c.obj.iv[34] = w;
	local[0]= argv[0];
	local[1]= fqv[0];
	local[2]= loadglobal(fqv[1]);
	local[3]= fqv[10];
	local[4]= argv[0];
	local[5]= fqv[11];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	argv[0]->c.obj.iv[33] = w;
	local[0]= argv[0];
	local[1]= fqv[0];
	local[2]= loadglobal(fqv[12]);
	local[3]= fqv[13];
	local[4]= argv[0];
	local[5]= fqv[7];
	local[6]= fqv[14];
	local[7]= makeint((eusinteger_t)23L);
	local[8]= fqv[15];
	local[9]= loadglobal(fqv[16]);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,10,local+0); /*send*/
	argv[0]->c.obj.iv[28] = w;
	local[0]= argv[0];
	local[1]= fqv[0];
	local[2]= loadglobal(fqv[12]);
	local[3]= fqv[17];
	local[4]= argv[0];
	local[5]= fqv[7];
	local[6]= fqv[14];
	local[7]= makeint((eusinteger_t)46L);
	local[8]= fqv[15];
	local[9]= loadglobal(fqv[16]);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,10,local+0); /*send*/
	argv[0]->c.obj.iv[27] = w;
	w = argv[0]->c.obj.iv[27];
	local[0]= w;
XapplwinBLK3176:
	ctx->vsp=local; return(local[0]);}

/*:create-fileview*/
static pointer XapplwinM3177filedialog_create_fileview(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[18]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[19];
	local[3]= fqv[20];
	local[4]= argv[0];
	local[5]= fqv[21];
	local[6]= argv[0]->c.obj.iv[5];
	local[7]= makeint((eusinteger_t)15L);
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	local[7]= fqv[22];
	local[8]= argv[0]->c.obj.iv[6];
	local[9]= argv[0]->c.obj.iv[18];
	local[10]= makeint((eusinteger_t)40L);
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,3,local+8); /*-*/
	local[8]= w;
	local[9]= fqv[15];
	local[10]= argv[0];
	local[11]= fqv[15];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= fqv[23];
	local[12]= T;
	local[13]= fqv[24];
	local[14]= T;
	local[15]= fqv[25];
	local[16]= NIL;
	local[17]= fqv[26];
	local[18]= argv[0];
	local[19]= fqv[27];
	local[20]= fqv[28];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,20,local+1); /*send*/
	w = local[0];
	argv[0]->c.obj.iv[29] = w;
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[29]); /*truename*/
	argv[0]->c.obj.iv[25] = w;
	local[0]= argv[0]->c.obj.iv[29];
	local[1]= fqv[30];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XapplwinF3174ls_l(ctx,1,local+2); /*ls-l*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	argv[0]->c.obj.iv[30] = argv[0]->c.obj.iv[18];
	local[0]= argv[0];
	local[1]= fqv[31];
	local[2]= argv[0]->c.obj.iv[29];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[27];
	local[1]= fqv[32];
	local[2]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,1,local+2,&ftab[1],fqv[33]); /*namestring*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XapplwinBLK3178:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XapplwinM3179filedialog_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XapplwinRST3181:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[34], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto XapplwinKEY3182;
	local[1] = loadglobal(fqv[16]);
XapplwinKEY3182:
	if (n & (1<<1)) goto XapplwinKEY3183;
	local[5]= loadglobal(fqv[35]);
	ctx->vsp=local+6;
	w=(*ftab[2])(ctx,0,local+6,&ftab[2],fqv[36]); /*pwd*/
	local[6]= w;
	local[7]= fqv[37];
	ctx->vsp=local+8;
	w=(pointer)CONCATENATE(ctx,3,local+5); /*concatenate*/
	local[2] = w;
XapplwinKEY3183:
	if (n & (1<<2)) goto XapplwinKEY3184;
	local[3] = NIL;
XapplwinKEY3184:
	if (n & (1<<3)) goto XapplwinKEY3185;
	local[4] = local[3];
XapplwinKEY3185:
	local[5]= (pointer)get_sym_func(fqv[38]);
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[39]));
	local[8]= fqv[19];
	local[9]= fqv[21];
	local[10]= makeint((eusinteger_t)380L);
	local[11]= fqv[22];
	local[12]= makeint((eusinteger_t)330L);
	local[13]= fqv[15];
	local[14]= local[1];
	local[15]= fqv[40];
	local[16]= fqv[41];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)APPLY(ctx,13,local+5); /*apply*/
	local[5]= argv[0];
	local[6]= fqv[42];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[43];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	argv[0]->c.obj.iv[35] = local[3];
	argv[0]->c.obj.iv[36] = local[4];
	w = argv[0];
	local[0]= w;
XapplwinBLK3180:
	ctx->vsp=local; return(local[0]);}

/*:cwd*/
static pointer XapplwinM3186filedialog_cwd(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[27];
	local[1]= fqv[32];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
XapplwinBLK3187:
	ctx->vsp=local; return(local[0]);}

/*:file-selected*/
static pointer XapplwinM3188filedialog_file_selected(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[29];
	local[1]= fqv[44];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)32L);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[3])(ctx,2,local+3,&ftab[3],fqv[45]); /*position*/
	local[1] = w;
	if (local[1]==NIL) goto XapplwinIF3190;
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SUBSEQ(ctx,3,local+3); /*subseq*/
	local[2] = w;
	local[3]= argv[0]->c.obj.iv[28];
	local[4]= fqv[32];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= local[2];
	goto XapplwinIF3191;
XapplwinIF3190:
	local[3]= NIL;
XapplwinIF3191:
	w = local[3];
	local[0]= w;
XapplwinBLK3189:
	ctx->vsp=local; return(local[0]);}

/*:selected-fname*/
static pointer XapplwinM3192filedialog_selected_fname(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[28];
	local[1]= fqv[32];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	w = makeint((eusinteger_t)0L);
	if ((eusinteger_t)local[1] <= (eusinteger_t)w) goto XapplwinIF3194;
	local[1]= argv[0]->c.obj.iv[28];
	local[2]= fqv[32];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[46];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[4])(ctx,2,local+1,&ftab[4],fqv[47]); /*merge-pathnames*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,1,local+1,&ftab[0],fqv[29]); /*truename*/
	local[1]= w;
	goto XapplwinIF3195;
XapplwinIF3194:
	local[1]= argv[0];
	local[2]= fqv[46];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,1,local+1,&ftab[0],fqv[29]); /*truename*/
	local[1]= w;
XapplwinIF3195:
	w = local[1];
	local[0]= w;
XapplwinBLK3193:
	ctx->vsp=local; return(local[0]);}

/*:view*/
static pointer XapplwinM3196filedialog_view(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0];
	local[4]= fqv[49];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[5])(ctx,1,local+3,&ftab[5],fqv[50]); /*probe-file*/
	if (w==NIL) goto XapplwinIF3198;
	local[3]= loadglobal(fqv[51]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[19];
	local[6]= fqv[52];
	local[7]= argv[0];
	local[8]= fqv[49];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= fqv[21];
	local[9]= makeint((eusinteger_t)500L);
	local[10]= fqv[22];
	local[11]= makeint((eusinteger_t)500L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,8,local+4); /*send*/
	w = local[3];
	local[3]= w;
	goto XapplwinIF3199;
XapplwinIF3198:
	local[3]= NIL;
XapplwinIF3199:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3197:
	ctx->vsp=local; return(local[0]);}

/*:ok*/
static pointer XapplwinM3200filedialog_ok(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0];
	local[4]= fqv[53];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	if (argv[0]->c.obj.iv[35]==NIL) goto XapplwinIF3202;
	local[3]= (pointer)get_sym_func(fqv[54]);
	w=argv[0]->c.obj.iv[35];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[35];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= argv[0];
	local[7]= fqv[49];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	w=argv[0]->c.obj.iv[35];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,5,local+3); /*apply*/
	local[3]= w;
	goto XapplwinIF3203;
XapplwinIF3202:
	local[3]= NIL;
XapplwinIF3203:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3201:
	ctx->vsp=local; return(local[0]);}

/*:cancel*/
static pointer XapplwinM3204filedialog_cancel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0];
	local[4]= fqv[53];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	if (argv[0]->c.obj.iv[36]==NIL) goto XapplwinIF3206;
	w=argv[0]->c.obj.iv[36];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[36];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= NIL;
	w=argv[0]->c.obj.iv[36];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.cdr;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto XapplwinIF3207;
XapplwinIF3206:
	local[3]= NIL;
XapplwinIF3207:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3205:
	ctx->vsp=local; return(local[0]);}

/*:open*/
static pointer XapplwinM3208filedialog_open(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0];
	local[4]= fqv[49];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,1,local+4,&ftab[1],fqv[33]); /*namestring*/
	local[3] = w;
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,1,local+4,&ftab[6],fqv[55]); /*directory-p*/
	if (w==NIL) goto XapplwinIF3210;
	local[4]= loadglobal(fqv[35]);
	local[5]= local[3];
	local[6]= fqv[56];
	ctx->vsp=local+7;
	w=(pointer)CONCATENATE(ctx,3,local+4); /*concatenate*/
	argv[0]->c.obj.iv[25] = w;
	local[4]= argv[0]->c.obj.iv[28];
	local[5]= fqv[32];
	local[6]= fqv[57];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[29];
	local[5]= fqv[58];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[29];
	local[5]= fqv[30];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)XapplwinF3174ls_l(ctx,1,local+6); /*ls-l*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[27];
	local[5]= fqv[32];
	local[6]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,1,local+6,&ftab[1],fqv[33]); /*namestring*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XapplwinIF3211;
XapplwinIF3210:
	local[4]= NIL;
XapplwinIF3211:
	w = local[4];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3209:
	ctx->vsp=local; return(local[0]);}

/*:go-up*/
static pointer XapplwinM3212filedialog_go_up(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0];
	local[4]= fqv[46];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,1,local+3,&ftab[0],fqv[29]); /*truename*/
	local[3]= w;
	local[4]= fqv[59];
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(*ftab[7])(ctx,1,local+5,&ftab[7],fqv[60]); /*pathname-directory*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)BUTLAST(ctx,1,local+5); /*butlast*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[8])(ctx,2,local+4,&ftab[8],fqv[61]); /*make-pathname*/
	local[4]= w;
	local[5]= local[4];
	ctx->vsp=local+6;
	w=(*ftab[1])(ctx,1,local+5,&ftab[1],fqv[33]); /*namestring*/
	local[4] = w;
	argv[0]->c.obj.iv[25] = local[4];
	local[5]= argv[0]->c.obj.iv[27];
	local[6]= fqv[32];
	local[7]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+8;
	w=(*ftab[1])(ctx,1,local+7,&ftab[1],fqv[33]); /*namestring*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= argv[0]->c.obj.iv[29];
	local[6]= fqv[58];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= argv[0]->c.obj.iv[29];
	local[6]= fqv[30];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)XapplwinF3174ls_l(ctx,1,local+7); /*ls-l*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= argv[0]->c.obj.iv[28];
	local[6]= fqv[32];
	local[7]= fqv[62];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3213:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer XapplwinM3214filedialog_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	argv[0]->c.obj.iv[5] = argv[2];
	argv[0]->c.obj.iv[6] = argv[3];
	local[0]= argv[0]->c.obj.iv[29];
	local[1]= fqv[63];
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)15L);
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	local[3]= argv[3];
	local[4]= argv[0]->c.obj.iv[30];
	local[5]= makeint((eusinteger_t)40L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,3,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
XapplwinBLK3215:
	ctx->vsp=local; return(local[0]);}

/*:configurenotify*/
static pointer XapplwinM3216filedialog_configurenotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0];
	local[4]= fqv[21];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[22];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[3];
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,2,local+5,&ftab[9],fqv[64]); /*/=*/
	if (w!=NIL) goto XapplwinOR3220;
	local[5]= local[4];
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,2,local+5,&ftab[9],fqv[64]); /*/=*/
	if (w!=NIL) goto XapplwinOR3220;
	goto XapplwinIF3218;
XapplwinOR3220:
	local[5]= argv[0];
	local[6]= fqv[63];
	local[7]= local[3];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	goto XapplwinIF3219;
XapplwinIF3218:
	local[5]= NIL;
XapplwinIF3219:
	w = local[5];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3217:
	ctx->vsp=local; return(local[0]);}

/*:create-buttons*/
static pointer XapplwinM3221filepanel_create_buttons(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[39]));
	local[2]= fqv[42];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	local[0]= argv[0];
	local[1]= fqv[0];
	local[2]= loadglobal(fqv[1]);
	local[3]= fqv[65];
	local[4]= argv[0];
	local[5]= fqv[66];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	argv[0]->c.obj.iv[40] = w;
	local[0]= argv[0];
	local[1]= fqv[0];
	local[2]= loadglobal(fqv[1]);
	local[3]= fqv[67];
	local[4]= argv[0];
	local[5]= fqv[68];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	argv[0]->c.obj.iv[38] = w;
	local[0]= argv[0];
	local[1]= fqv[0];
	local[2]= loadglobal(fqv[1]);
	local[3]= fqv[69];
	local[4]= argv[0];
	local[5]= fqv[70];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	argv[0]->c.obj.iv[37] = w;
	local[0]= argv[0];
	local[1]= fqv[0];
	local[2]= loadglobal(fqv[1]);
	local[3]= fqv[71];
	local[4]= argv[0];
	local[5]= fqv[72];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	argv[0]->c.obj.iv[41] = w;
	local[0]= argv[0];
	local[1]= fqv[0];
	local[2]= loadglobal(fqv[12]);
	local[3]= fqv[73];
	local[4]= argv[0];
	local[5]= fqv[74];
	local[6]= fqv[14];
	local[7]= makeint((eusinteger_t)47L);
	local[8]= fqv[15];
	local[9]= loadglobal(fqv[16]);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,10,local+0); /*send*/
	argv[0]->c.obj.iv[42] = w;
	w = argv[0]->c.obj.iv[42];
	local[0]= w;
XapplwinBLK3222:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XapplwinM3223filepanel_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XapplwinRST3225:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[38]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[39]));
	local[4]= fqv[19];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	local[1]= loadglobal(fqv[75]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[19];
	local[4]= fqv[25];
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	argv[0]->c.obj.iv[43] = w;
	w = argv[0];
	local[0]= w;
XapplwinBLK3224:
	ctx->vsp=local; return(local[0]);}

/*:load*/
static pointer XapplwinM3226filepanel_load(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0];
	local[4]= fqv[49];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[10])(ctx,1,local+3,&ftab[10],fqv[76]); /*load*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3227:
	ctx->vsp=local; return(local[0]);}

/*:eval*/
static pointer XapplwinM3228filepanel_eval(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0]->c.obj.iv[42];
	local[4]= fqv[32];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[11])(ctx,1,local+3,&ftab[11],fqv[77]); /*read-from-string*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)EVAL(ctx,1,local+3); /*eval*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PRINT(ctx,1,local+3); /*print*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3229:
	ctx->vsp=local; return(local[0]);}

/*:print*/
static pointer XapplwinM3230filepanel_print(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0];
	local[4]= fqv[49];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	if (local[3]==NIL) goto XapplwinIF3232;
	local[4]= NIL;
	local[5]= fqv[78];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,1,local+6,&ftab[1],fqv[33]); /*namestring*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SYSTEM(ctx,1,local+4); /*unix:system*/
	local[4]= w;
	goto XapplwinIF3233;
XapplwinIF3232:
	local[4]= NIL;
XapplwinIF3233:
	w = local[4];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3231:
	ctx->vsp=local; return(local[0]);}

/*:compile*/
static pointer XapplwinM3234filepanel_compile(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0];
	local[4]= fqv[49];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	if (local[3]==NIL) goto XapplwinIF3236;
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,1,local+4,&ftab[1],fqv[33]); /*namestring*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[12])(ctx,1,local+4,&ftab[12],fqv[79]); /*compiler:compile-file*/
	local[4]= w;
	goto XapplwinIF3237;
XapplwinIF3236:
	local[4]= NIL;
XapplwinIF3237:
	w = local[4];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3235:
	ctx->vsp=local; return(local[0]);}

/*:remove*/
static pointer XapplwinM3238filepanel_remove(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0];
	local[4]= fqv[49];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,1,local+3,&ftab[1],fqv[33]); /*namestring*/
	argv[0]->c.obj.iv[44] = w;
	local[3]= argv[0]->c.obj.iv[43];
	local[4]= fqv[80];
	local[5]= argv[0];
	local[6]= fqv[81];
	local[7]= fqv[82];
	local[8]= loadglobal(fqv[35]);
	local[9]= argv[0]->c.obj.iv[44];
	local[10]= fqv[83];
	ctx->vsp=local+11;
	w=(pointer)CONCATENATE(ctx,3,local+8); /*concatenate*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,6,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3239:
	ctx->vsp=local; return(local[0]);}

/*:remove-confirm*/
static pointer XapplwinM3240filepanel_remove_confirm(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	if (fqv[84]!=local[0]) goto XapplwinIF3242;
	local[0]= argv[0]->c.obj.iv[44];
	ctx->vsp=local+1;
	w=(pointer)PRINT(ctx,1,local+0); /*print*/
	local[0]= argv[0]->c.obj.iv[44];
	ctx->vsp=local+1;
	w=(pointer)UNLINK(ctx,1,local+0); /*unix:unlink*/
	local[0]= argv[0]->c.obj.iv[29];
	local[1]= fqv[58];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[29];
	local[1]= fqv[30];
	local[2]= argv[0];
	local[3]= fqv[46];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XapplwinF3174ls_l(ctx,1,local+2); /*ls-l*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto XapplwinIF3243;
XapplwinIF3242:
	local[0]= NIL;
XapplwinIF3243:
	argv[0]->c.obj.iv[44] = NIL;
	w = argv[0]->c.obj.iv[44];
	local[0]= w;
XapplwinBLK3241:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XapplwinM3244textviewpanel_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XapplwinRST3246:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[85], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto XapplwinKEY3247;
	local[1] = NIL;
XapplwinKEY3247:
	if (n & (1<<1)) goto XapplwinKEY3248;
	local[2] = NIL;
XapplwinKEY3248:
	if (n & (1<<2)) goto XapplwinKEY3249;
	local[3] = NIL;
XapplwinKEY3249:
	if (n & (1<<3)) goto XapplwinKEY3250;
	local[4] = NIL;
XapplwinKEY3250:
	if (n & (1<<4)) goto XapplwinKEY3251;
	local[5] = makeint((eusinteger_t)400L);
XapplwinKEY3251:
	local[6]= (pointer)get_sym_func(fqv[38]);
	local[7]= argv[0];
	local[8]= *(ovafptr(argv[1],fqv[39]));
	local[9]= fqv[19];
	local[10]= fqv[21];
	local[11]= local[5];
	local[12]= fqv[15];
	local[13]= local[1];
	local[14]= fqv[40];
	local[15]= fqv[86];
	local[16]= local[0];
	ctx->vsp=local+17;
	w=(pointer)APPLY(ctx,11,local+6); /*apply*/
	local[6]= argv[0];
	local[7]= fqv[0];
	local[8]= loadglobal(fqv[1]);
	local[9]= fqv[87];
	local[10]= argv[0];
	local[11]= fqv[88];
	local[12]= fqv[15];
	local[13]= loadglobal(fqv[16]);
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,8,local+6); /*send*/
	argv[0]->c.obj.iv[25] = w;
	local[6]= argv[0];
	local[7]= fqv[0];
	local[8]= loadglobal(fqv[1]);
	local[9]= fqv[89];
	local[10]= argv[0];
	local[11]= fqv[70];
	local[12]= fqv[15];
	local[13]= loadglobal(fqv[16]);
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,8,local+6); /*send*/
	argv[0]->c.obj.iv[27] = w;
	local[6]= argv[0];
	local[7]= fqv[0];
	local[8]= loadglobal(fqv[1]);
	local[9]= fqv[90];
	local[10]= argv[0];
	local[11]= fqv[91];
	local[12]= fqv[15];
	local[13]= loadglobal(fqv[16]);
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,8,local+6); /*send*/
	argv[0]->c.obj.iv[26] = w;
	local[6]= argv[0];
	local[7]= fqv[0];
	local[8]= loadglobal(fqv[12]);
	local[9]= fqv[92];
	local[10]= argv[0];
	local[11]= fqv[91];
	local[12]= fqv[15];
	local[13]= loadglobal(fqv[16]);
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,8,local+6); /*send*/
	argv[0]->c.obj.iv[30] = w;
	local[6]= argv[0];
	local[7]= fqv[31];
	local[8]= loadglobal(fqv[18]);
	ctx->vsp=local+9;
	w=(pointer)INSTANTIATE(ctx,1,local+8); /*instantiate*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[19];
	local[11]= fqv[21];
	local[12]= argv[0];
	local[13]= fqv[21];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)10L);
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,2,local+12); /*-*/
	local[5] = w;
	local[12]= local[5];
	local[13]= fqv[22];
	local[14]= argv[0];
	local[15]= fqv[22];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	argv[0]->c.obj.iv[6] = w;
	local[14]= argv[0]->c.obj.iv[6];
	local[15]= makeint((eusinteger_t)60L);
	ctx->vsp=local+16;
	w=(pointer)MINUS(ctx,2,local+14); /*-*/
	local[14]= w;
	local[15]= fqv[23];
	local[16]= T;
	local[17]= fqv[24];
	local[18]= T;
	local[19]= fqv[25];
	local[20]= NIL;
	local[21]= fqv[15];
	local[22]= local[1];
	local[23]= fqv[20];
	local[24]= argv[0];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,16,local+9); /*send*/
	w = local[8];
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	argv[0]->c.obj.iv[31] = w;
	if (local[2]==NIL) goto XapplwinCON3253;
	argv[0]->c.obj.iv[28] = local[2];
	local[6]= argv[0]->c.obj.iv[31];
	local[7]= fqv[93];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto XapplwinCON3252;
XapplwinCON3253:
	if (local[4]==NIL) goto XapplwinCON3254;
	local[6]= NIL;
	goto XapplwinCON3252;
XapplwinCON3254:
	if (local[3]==NIL) goto XapplwinCON3255;
	local[6]= argv[0]->c.obj.iv[31];
	local[7]= fqv[30];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto XapplwinCON3252;
XapplwinCON3255:
	local[6]= NIL;
XapplwinCON3252:
	w = argv[0];
	local[0]= w;
XapplwinBLK3245:
	ctx->vsp=local; return(local[0]);}

/*:quit*/
static pointer XapplwinM3256textviewpanel_quit(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0];
	local[4]= fqv[53];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= argv[0];
	local[4]= fqv[94];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3257:
	ctx->vsp=local; return(local[0]);}

/*:finish*/
static pointer XapplwinM3258textviewpanel_finish(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= fqv[95];
	w = argv[0];
	ctx->vsp=local+4;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3259:
	ctx->vsp=local; return(local[0]);}

/*:print*/
static pointer XapplwinM3260textviewpanel_print(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0]->c.obj.iv[28];
	local[4]= NIL;
	if (argv[0]->c.obj.iv[28]!=NIL) goto XapplwinIF3262;
	local[5]= argv[0]->c.obj.iv[31];
	local[6]= fqv[96];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[4] = w;
	local[5]= NIL;
	local[6]= fqv[97];
	local[7]= argv[0];
	local[8]= fqv[98];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)GETPID(ctx,0,local+8); /*unix:getpid*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[3] = w;
	local[5]= local[3];
	local[6]= fqv[99];
	local[7]= fqv[100];
	ctx->vsp=local+8;
	w=(*ftab[13])(ctx,3,local+5,&ftab[13],fqv[101]); /*open*/
	local[5]= w;
	ctx->vsp=local+6;
	w = makeclosure(codevec,quotevec,XapplwinUWP3264,env,argv,local);
	local[6]=(pointer)(ctx->protfp); local[7]=w;
	ctx->protfp=(struct protectframe *)(local+6);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
XapplwinWHL3265:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto XapplwinWHX3266;
	local[10]= local[5];
	local[11]= fqv[102];
	local[12]= local[4];
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,3,local+10); /*format*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto XapplwinWHL3265;
XapplwinWHX3266:
	local[10]= NIL;
XapplwinBLK3267:
	w = NIL;
	ctx->vsp=local+8;
	XapplwinUWP3264(ctx,0,local+8,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[5]= w;
	goto XapplwinIF3263;
XapplwinIF3262:
	local[5]= NIL;
XapplwinIF3263:
	local[5]= NIL;
	local[6]= fqv[103];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(*ftab[1])(ctx,1,local+7,&ftab[1],fqv[33]); /*namestring*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,3,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SYSTEM(ctx,1,local+5); /*unix:system*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3261:
	ctx->vsp=local; return(local[0]);}

/*:find*/
static pointer XapplwinM3268textviewpanel_find(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0]->c.obj.iv[30];
	local[4]= fqv[32];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= NIL;
	local[5]= argv[0]->c.obj.iv[31];
	local[6]= fqv[104];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
XapplwinTAG3271:
	local[7]= local[6];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)GREQP(ctx,2,local+7); /*>=*/
	if (w!=NIL) goto XapplwinOR3274;
	if (local[4]!=NIL) goto XapplwinOR3274;
	goto XapplwinIF3272;
XapplwinOR3274:
	w = NIL;
	ctx->vsp=local+7;
	local[6]=w;
	goto XapplwinBLK3270;
	goto XapplwinIF3273;
XapplwinIF3272:
	local[7]= NIL;
XapplwinIF3273:
	local[7]= local[3];
	local[8]= argv[0]->c.obj.iv[31];
	local[9]= fqv[105];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[14])(ctx,2,local+7,&ftab[14],fqv[106]); /*substringp*/
	if (w==NIL) goto XapplwinIF3275;
	local[4] = local[6];
	local[7]= local[4];
	goto XapplwinIF3276;
XapplwinIF3275:
	local[7]= NIL;
XapplwinIF3276:
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[7]= w;
	local[6] = local[7];
	w = NIL;
	ctx->vsp=local+7;
	goto XapplwinTAG3271;
	w = NIL;
	local[6]= w;
XapplwinBLK3270:
	if (local[4]==NIL) goto XapplwinIF3277;
	local[6]= argv[0]->c.obj.iv[31];
	local[7]= fqv[107];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= argv[0]->c.obj.iv[31];
	local[7]= fqv[108];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto XapplwinIF3278;
XapplwinIF3277:
	local[6]= NIL;
XapplwinIF3278:
	w = local[6];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3269:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer XapplwinM3279textviewpanel_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	argv[0]->c.obj.iv[5] = argv[2];
	argv[0]->c.obj.iv[6] = argv[3];
	local[0]= argv[0]->c.obj.iv[31];
	local[1]= fqv[63];
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)10L);
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	local[3]= argv[3];
	local[4]= makeint((eusinteger_t)38L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
XapplwinBLK3280:
	ctx->vsp=local; return(local[0]);}

/*:configurenotify*/
static pointer XapplwinM3281textviewpanel_configurenotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0];
	local[4]= fqv[21];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[22];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[3];
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,2,local+5,&ftab[9],fqv[64]); /*/=*/
	if (w!=NIL) goto XapplwinOR3285;
	local[5]= local[4];
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,2,local+5,&ftab[9],fqv[64]); /*/=*/
	if (w!=NIL) goto XapplwinOR3285;
	goto XapplwinIF3283;
XapplwinOR3285:
	local[5]= argv[0];
	local[6]= fqv[63];
	local[7]= local[3];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	goto XapplwinIF3284;
XapplwinIF3283:
	local[5]= NIL;
XapplwinIF3284:
	w = local[5];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3282:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer XapplwinUWP3264(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[5];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*ls-l*/
static pointer XapplwinF3174ls_l(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto XapplwinENT3288;}
	local[0]= fqv[109];
XapplwinENT3288:
XapplwinENT3287:
	if (n>1) maerror();
	local[1]= fqv[110];
	local[2]= fqv[111];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,1,local+3,&ftab[1],fqv[33]); /*namestring*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[15])(ctx,3,local+1,&ftab[15],fqv[112]); /*piped-fork*/
	local[1]= w;
	local[2]= NIL;
	w = NIL;
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= local[1];
	local[9]= NIL;
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)READLINE(ctx,3,local+8); /*read-line*/
XapplwinWHL3289:
	local[8]= local[1];
	local[9]= NIL;
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)READLINE(ctx,3,local+8); /*read-line*/
	local[5] = w;
	local[8]= local[5];
	if (local[2]==local[8]) goto XapplwinWHX3290;
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)NREVERSE(ctx,1,local+8); /*nreverse*/
	local[8]= makeint((eusinteger_t)32L);
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[3])(ctx,2,local+8,&ftab[3],fqv[45]); /*position*/
	local[6] = w;
	if (local[6]==NIL) goto XapplwinIF3292;
	local[8]= local[5];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)SUBSEQ(ctx,3,local+8); /*subseq*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)NREVERSE(ctx,1,local+8); /*nreverse*/
	local[8]= w;
	goto XapplwinIF3293;
XapplwinIF3292:
	local[8]= fqv[113];
XapplwinIF3293:
	local[3] = local[8];
	if (local[6]==NIL) goto XapplwinIF3294;
	local[8]= local[5];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,2,local+8); /*subseq*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)NREVERSE(ctx,1,local+8); /*nreverse*/
	local[8]= w;
	goto XapplwinIF3295;
XapplwinIF3294:
	local[8]= fqv[114];
XapplwinIF3295:
	local[5] = local[8];
	local[8]= NIL;
	local[9]= fqv[115];
	local[10]= local[3];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,4,local+8); /*format*/
	local[8]= w;
	w = local[4];
	ctx->vsp=local+9;
	local[4] = cons(ctx,local[8],w);
	goto XapplwinWHL3289;
XapplwinWHX3290:
	local[8]= NIL;
XapplwinBLK3291:
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)CLOSE(ctx,1,local+8); /*close*/
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)NREVERSE(ctx,1,local+8); /*nreverse*/
	local[0]= w;
XapplwinBLK3286:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XapplwinM3296confirmpanel_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XapplwinRST3298:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[38]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[39]));
	local[4]= fqv[19];
	local[5]= fqv[21];
	local[6]= makeint((eusinteger_t)400L);
	local[7]= fqv[22];
	local[8]= makeint((eusinteger_t)260L);
	local[9]= fqv[15];
	local[10]= loadglobal(fqv[116]);
	local[11]= fqv[117];
	local[12]= fqv[118];
	local[13]= fqv[25];
	local[14]= NIL;
	local[15]= fqv[40];
	local[16]= NIL;
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)APPLY(ctx,17,local+1); /*apply*/
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= loadglobal(fqv[1]);
	local[4]= fqv[119];
	local[5]= argv[0];
	local[6]= fqv[84];
	local[7]= fqv[15];
	local[8]= loadglobal(fqv[116]);
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,8,local+1); /*send*/
	argv[0]->c.obj.iv[25] = w;
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= loadglobal(fqv[1]);
	local[4]= fqv[120];
	local[5]= argv[0];
	local[6]= fqv[121];
	local[7]= fqv[15];
	local[8]= loadglobal(fqv[116]);
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,8,local+1); /*send*/
	argv[0]->c.obj.iv[26] = w;
	local[1]= argv[0]->c.obj.iv[25];
	local[2]= fqv[122];
	local[3]= makeint((eusinteger_t)70L);
	local[4]= makeint((eusinteger_t)200L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[26];
	local[2]= fqv[122];
	local[3]= makeint((eusinteger_t)270L);
	local[4]= makeint((eusinteger_t)200L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = argv[0];
	local[0]= w;
XapplwinBLK3297:
	ctx->vsp=local; return(local[0]);}

/*:draw-message*/
static pointer XapplwinM3299confirmpanel_draw_message(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)20L);
	local[1]= makeint((eusinteger_t)50L);
	local[2]= argv[0];
	local[3]= fqv[58];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= NIL;
	local[3]= argv[0]->c.obj.iv[28];
XapplwinWHL3301:
	if (local[3]==NIL) goto XapplwinWHX3302;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= argv[0];
	local[5]= fqv[123];
	local[6]= local[0];
	local[7]= local[1];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)30L);
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[1] = w;
	goto XapplwinWHL3301;
XapplwinWHX3302:
	local[4]= NIL;
XapplwinBLK3303:
	w = NIL;
	local[0]= w;
XapplwinBLK3300:
	ctx->vsp=local; return(local[0]);}

/*:ask*/
static pointer XapplwinM3304confirmpanel_ask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
XapplwinRST3306:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-4);
	argv[0]->c.obj.iv[27] = NIL;
	argv[0]->c.obj.iv[28] = local[0];
	local[1]= argv[0];
	local[2]= fqv[124];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[25];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	argv[0]->c.obj.iv[29] = argv[2];
	argv[0]->c.obj.iv[30] = argv[3];
	w = argv[0];
	local[0]= w;
XapplwinBLK3305:
	ctx->vsp=local; return(local[0]);}

/*:yes*/
static pointer XapplwinM3307confirmpanel_yes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	argv[0]->c.obj.iv[27] = fqv[84];
	local[3]= argv[0];
	local[4]= fqv[125];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= argv[0]->c.obj.iv[29];
	local[4]= argv[0]->c.obj.iv[30];
	local[5]= fqv[84];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3308:
	ctx->vsp=local; return(local[0]);}

/*:no*/
static pointer XapplwinM3309confirmpanel_no(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	argv[0]->c.obj.iv[27] = fqv[121];
	local[3]= argv[0];
	local[4]= fqv[125];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= argv[0]->c.obj.iv[29];
	local[4]= argv[0]->c.obj.iv[30];
	local[5]= fqv[121];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3310:
	ctx->vsp=local; return(local[0]);}

/*:configurenotify*/
static pointer XapplwinM3311confirmpanel_configurenotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= loadglobal(fqv[48]);
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,1,local+3,&ftab[16],fqv[126]); /*event-width*/
	local[3]= w;
	local[4]= loadglobal(fqv[48]);
	ctx->vsp=local+5;
	w=(*ftab[17])(ctx,1,local+4,&ftab[17],fqv[127]); /*event-height*/
	local[4]= w;
	local[5]= local[3];
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,2,local+5,&ftab[9],fqv[64]); /*/=*/
	if (w!=NIL) goto XapplwinOR3315;
	local[5]= local[4];
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,2,local+5,&ftab[9],fqv[64]); /*/=*/
	if (w!=NIL) goto XapplwinOR3315;
	goto XapplwinIF3313;
XapplwinOR3315:
	local[5]= argv[0];
	local[6]= fqv[124];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	goto XapplwinIF3314;
XapplwinIF3313:
	local[5]= NIL;
XapplwinIF3314:
	w = local[5];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3312:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XapplwinM3316colorpickerpanel_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XapplwinRST3318:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[38]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[39]));
	local[4]= fqv[19];
	local[5]= fqv[21];
	local[6]= makeint((eusinteger_t)300L);
	local[7]= fqv[22];
	local[8]= makeint((eusinteger_t)300L);
	local[9]= fqv[15];
	local[10]= loadglobal(fqv[128]);
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)APPLY(ctx,11,local+1); /*apply*/
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= loadglobal(fqv[1]);
	local[4]= fqv[129];
	local[5]= argv[0];
	local[6]= fqv[3];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	argv[0]->c.obj.iv[25] = w;
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= loadglobal(fqv[1]);
	local[4]= fqv[130];
	local[5]= argv[0];
	local[6]= fqv[5];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	argv[0]->c.obj.iv[26] = w;
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= loadglobal(fqv[1]);
	local[4]= fqv[131];
	local[5]= argv[0];
	local[6]= fqv[132];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	argv[0]->c.obj.iv[27] = w;
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= loadglobal(fqv[1]);
	local[4]= fqv[133];
	local[5]= argv[0];
	local[6]= fqv[134];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	argv[0]->c.obj.iv[28] = w;
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= loadglobal(fqv[1]);
	local[4]= fqv[135];
	local[5]= argv[0];
	local[6]= fqv[136];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	argv[0]->c.obj.iv[29] = w;
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= loadglobal(fqv[1]);
	local[4]= fqv[137];
	local[5]= argv[0];
	local[6]= fqv[138];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	argv[0]->c.obj.iv[30] = w;
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= loadglobal(fqv[1]);
	local[4]= fqv[139];
	local[5]= argv[0];
	local[6]= fqv[140];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	argv[0]->c.obj.iv[34] = w;
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= loadglobal(fqv[1]);
	local[4]= fqv[141];
	local[5]= argv[0];
	local[6]= fqv[142];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	argv[0]->c.obj.iv[35] = w;
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= loadglobal(fqv[143]);
	local[4]= fqv[144];
	local[5]= argv[0];
	local[6]= fqv[145];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	argv[0]->c.obj.iv[31] = w;
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= loadglobal(fqv[143]);
	local[4]= fqv[146];
	local[5]= argv[0];
	local[6]= fqv[147];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	argv[0]->c.obj.iv[32] = w;
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= loadglobal(fqv[143]);
	local[4]= fqv[148];
	local[5]= argv[0];
	local[6]= fqv[149];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	argv[0]->c.obj.iv[33] = w;
	local[1]= makeflt(2.9999999999999982236432e-01);
	local[2]= makeflt(3.9999999999999991118216e-01);
	local[3]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	argv[0]->c.obj.iv[36] = w;
	local[1]= makeflt(5.0000000000000000000000e-01);
	local[2]= makeflt(3.9999999999999991118216e-01);
	local[3]= makeflt(2.9999999999999982236432e-01);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	argv[0]->c.obj.iv[37] = w;
	local[1]= makeflt(1.9999999999999995559108e-01);
	local[2]= makeflt(1.9999999999999995559108e-01);
	local[3]= makeflt(1.9999999999999995559108e-01);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	argv[0]->c.obj.iv[38] = w;
	local[1]= makeflt(9.9999999999999977795540e-02);
	local[2]= makeflt(9.9999999999999977795540e-02);
	local[3]= makeflt(9.9999999999999977795540e-02);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	argv[0]->c.obj.iv[39] = w;
	argv[0]->c.obj.iv[40] = makeflt(1.0000000000000000000000e+01);
	argv[0]->c.obj.iv[41] = makeflt(0.0000000000000000000000e+00);
	argv[0]->c.obj.iv[42] = NIL;
	argv[0]->c.obj.iv[43] = NIL;
	w = argv[0];
	local[0]= w;
XapplwinBLK3317:
	ctx->vsp=local; return(local[0]);}

/*:init-value*/
static pointer XapplwinM3319colorpickerpanel_init_value(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[132];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[36] = w;
	local[0]= argv[2];
	local[1]= fqv[134];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[37] = w;
	local[0]= argv[2];
	local[1]= fqv[136];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[38] = w;
	local[0]= argv[2];
	local[1]= fqv[138];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[39] = w;
	local[0]= argv[2];
	local[1]= fqv[140];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[40] = w;
	local[0]= argv[2];
	local[1]= fqv[142];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[41] = w;
	w = NIL;
	local[0]= w;
XapplwinBLK3320:
	ctx->vsp=local; return(local[0]);}

/*:value1*/
static pointer XapplwinM3321colorpickerpanel_value1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)PRINT(ctx,1,local+0); /*print*/
	local[0]= w;
XapplwinBLK3322:
	ctx->vsp=local; return(local[0]);}

/*:value2*/
static pointer XapplwinM3323colorpickerpanel_value2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)PRINT(ctx,1,local+0); /*print*/
	local[0]= w;
XapplwinBLK3324:
	ctx->vsp=local; return(local[0]);}

/*:value3*/
static pointer XapplwinM3325colorpickerpanel_value3(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)PRINT(ctx,1,local+0); /*print*/
	local[0]= w;
XapplwinBLK3326:
	ctx->vsp=local; return(local[0]);}

/*:ambient*/
static pointer XapplwinM3327colorpickerpanel_ambient(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0]->c.obj.iv[31];
	local[4]= fqv[32];
	local[5]= argv[0]->c.obj.iv[36];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[0]->c.obj.iv[32];
	local[4]= fqv[32];
	local[5]= argv[0]->c.obj.iv[36];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[0]->c.obj.iv[33];
	local[4]= fqv[32];
	local[5]= argv[0]->c.obj.iv[36];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3328:
	ctx->vsp=local; return(local[0]);}

/*:diffuse*/
static pointer XapplwinM3329colorpickerpanel_diffuse(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0]->c.obj.iv[31];
	local[4]= fqv[32];
	local[5]= argv[0]->c.obj.iv[37];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[0]->c.obj.iv[32];
	local[4]= fqv[32];
	local[5]= argv[0]->c.obj.iv[37];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[0]->c.obj.iv[33];
	local[4]= fqv[32];
	local[5]= argv[0]->c.obj.iv[37];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3330:
	ctx->vsp=local; return(local[0]);}

/*:specular*/
static pointer XapplwinM3331colorpickerpanel_specular(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0]->c.obj.iv[31];
	local[4]= fqv[32];
	local[5]= argv[0]->c.obj.iv[38];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[0]->c.obj.iv[32];
	local[4]= fqv[32];
	local[5]= argv[0]->c.obj.iv[38];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[0]->c.obj.iv[33];
	local[4]= fqv[32];
	local[5]= argv[0]->c.obj.iv[38];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3332:
	ctx->vsp=local; return(local[0]);}

/*:emission*/
static pointer XapplwinM3333colorpickerpanel_emission(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0]->c.obj.iv[31];
	local[4]= fqv[32];
	local[5]= argv[0]->c.obj.iv[39];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[0]->c.obj.iv[32];
	local[4]= fqv[32];
	local[5]= argv[0]->c.obj.iv[39];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[0]->c.obj.iv[33];
	local[4]= fqv[32];
	local[5]= argv[0]->c.obj.iv[39];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3334:
	ctx->vsp=local; return(local[0]);}

/*:shininess*/
static pointer XapplwinM3335colorpickerpanel_shininess(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0]->c.obj.iv[31];
	local[4]= fqv[32];
	local[5]= argv[0]->c.obj.iv[40];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3336:
	ctx->vsp=local; return(local[0]);}

/*:transparency*/
static pointer XapplwinM3337colorpickerpanel_transparency(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[48],w);
	local[3]= argv[0]->c.obj.iv[31];
	local[4]= fqv[32];
	local[5]= argv[0]->c.obj.iv[41];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XapplwinBLK3338:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XapplwinM3339objectbrowser_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XapplwinRST3341:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[150], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto XapplwinKEY3342;
	local[1] = makeint((eusinteger_t)350L);
XapplwinKEY3342:
	if (n & (1<<1)) goto XapplwinKEY3343;
	local[2] = makeint((eusinteger_t)500L);
XapplwinKEY3343:
	local[3]= (pointer)get_sym_func(fqv[38]);
	local[4]= argv[0];
	local[5]= *(ovafptr(argv[1],fqv[39]));
	local[6]= fqv[19];
	local[7]= fqv[21];
	local[8]= local[1];
	local[9]= fqv[22];
	local[10]= local[2];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)APPLY(ctx,9,local+3); /*apply*/
	local[3]= argv[0];
	local[4]= fqv[0];
	local[5]= loadglobal(fqv[12]);
	local[6]= fqv[151];
	local[7]= argv[0];
	local[8]= fqv[152];
	local[9]= fqv[15];
	local[10]= loadglobal(fqv[16]);
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,8,local+3); /*send*/
	argv[0]->c.obj.iv[25] = w;
	local[3]= argv[0];
	local[4]= fqv[0];
	local[5]= loadglobal(fqv[12]);
	local[6]= fqv[153];
	local[7]= argv[0];
	local[8]= fqv[154];
	local[9]= fqv[15];
	local[10]= loadglobal(fqv[16]);
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,8,local+3); /*send*/
	argv[0]->c.obj.iv[26] = w;
	local[3]= argv[0];
	local[4]= fqv[0];
	local[5]= loadglobal(fqv[1]);
	local[6]= fqv[155];
	local[7]= argv[0];
	local[8]= fqv[156];
	local[9]= fqv[15];
	local[10]= loadglobal(fqv[116]);
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,8,local+3); /*send*/
	argv[0]->c.obj.iv[28] = w;
	local[3]= argv[0];
	local[4]= fqv[0];
	local[5]= loadglobal(fqv[1]);
	local[6]= fqv[157];
	local[7]= argv[0];
	local[8]= fqv[158];
	local[9]= fqv[15];
	local[10]= loadglobal(fqv[116]);
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,8,local+3); /*send*/
	argv[0]->c.obj.iv[27] = w;
	local[3]= loadglobal(fqv[51]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[19];
	local[6]= fqv[20];
	local[7]= argv[0];
	local[8]= fqv[21];
	local[9]= argv[0];
	local[10]= fqv[21];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= fqv[22];
	local[11]= argv[0];
	local[12]= fqv[22];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)120L);
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	local[12]= fqv[159];
	local[13]= makeint((eusinteger_t)120L);
	local[14]= fqv[15];
	local[15]= loadglobal(fqv[16]);
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,12,local+4); /*send*/
	w = local[3];
	argv[0]->c.obj.iv[29] = w;
	local[3]= loadglobal(fqv[160]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[19];
	local[6]= fqv[21];
	local[7]= local[1];
	local[8]= fqv[22];
	local[9]= makeint((eusinteger_t)60L);
	local[10]= fqv[159];
	local[11]= makeint((eusinteger_t)60L);
	local[12]= fqv[15];
	local[13]= loadglobal(fqv[16]);
	local[14]= fqv[20];
	local[15]= argv[0];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,12,local+4); /*send*/
	w = local[3];
	argv[0]->c.obj.iv[30] = w;
	local[3]= argv[0]->c.obj.iv[30];
	ctx->vsp=local+4;
	w=(*ftab[18])(ctx,1,local+3,&ftab[18],fqv[161]); /*make-textwindow-stream*/
	argv[0]->c.obj.iv[31] = w;
	w = argv[0];
	local[0]= w;
XapplwinBLK3340:
	ctx->vsp=local; return(local[0]);}

/*:update-method-names*/
static pointer XapplwinM3344objectbrowser_update_method_names(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XapplwinENT3347;}
	local[0]= argv[0]->c.obj.iv[33];
XapplwinENT3347:
XapplwinENT3346:
	if (n>3) maerror();
	local[1]= (pointer)get_sym_func(fqv[35]);
	local[2]= (pointer)get_sym_func(fqv[162]);
	local[3]= local[0];
	local[4]= fqv[163];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	argv[0]->c.obj.iv[36] = w;
	local[1]= argv[0]->c.obj.iv[36];
	storeglobal(fqv[164],local[1]);
	local[1]= *(ovafptr(argv[0]->c.obj.iv[29],fqv[165]));
	local[2]= fqv[30];
	local[3]= argv[0]->c.obj.iv[36];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
XapplwinBLK3345:
	ctx->vsp=local; return(local[0]);}

/*:set-object*/
static pointer XapplwinM3348objectbrowser_set_object(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[25];
	local[1]= fqv[32];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[11])(ctx,1,local+0,&ftab[11],fqv[77]); /*read-from-string*/
	argv[0]->c.obj.iv[32] = w;
	local[0]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w==NIL) goto XapplwinCON3351;
	local[0]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+1;
	w=(pointer)SYMVALUE(ctx,1,local+0); /*symbol-value*/
	argv[0]->c.obj.iv[32] = w;
	local[0]= argv[0];
	local[1]= fqv[154];
	local[2]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+3;
	w=(pointer)GETCLASS(ctx,1,local+2); /*class*/
	argv[0]->c.obj.iv[33] = w;
	local[2]= argv[0]->c.obj.iv[33];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[31];
	local[1]= fqv[166];
	local[2]= argv[0]->c.obj.iv[32];
	local[3]= argv[0]->c.obj.iv[33];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
	goto XapplwinCON3350;
XapplwinCON3351:
	local[0]= argv[0]->c.obj.iv[31];
	local[1]= fqv[167];
	local[2]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	goto XapplwinCON3350;
XapplwinCON3352:
	local[0]= NIL;
XapplwinCON3350:
	w = local[0];
	local[0]= w;
XapplwinBLK3349:
	ctx->vsp=local; return(local[0]);}

/*:set-class*/
static pointer XapplwinM3353objectbrowser_set_class(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)CLASSP(ctx,1,local+0); /*classp*/
	if (w!=NIL) goto XapplwinCON3356;
	local[0]= argv[0]->c.obj.iv[26];
	local[1]= fqv[32];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[11])(ctx,1,local+0,&ftab[11],fqv[77]); /*read-from-string*/
	argv[0]->c.obj.iv[33] = w;
	local[0]= argv[0]->c.obj.iv[33];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w==NIL) goto XapplwinIF3357;
	local[0]= argv[0]->c.obj.iv[33];
	ctx->vsp=local+1;
	w=(pointer)SYMVALUE(ctx,1,local+0); /*symbol-value*/
	argv[0]->c.obj.iv[33] = w;
	local[0]= argv[0]->c.obj.iv[33];
	goto XapplwinIF3358;
XapplwinIF3357:
	local[0]= argv[0]->c.obj.iv[31];
	local[1]= fqv[168];
	local[2]= argv[0]->c.obj.iv[33];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
XapplwinIF3358:
	goto XapplwinCON3355;
XapplwinCON3356:
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)CLASSP(ctx,1,local+0); /*classp*/
	if (w==NIL) goto XapplwinCON3359;
	argv[0]->c.obj.iv[33] = argv[2];
	local[0]= argv[0]->c.obj.iv[26];
	local[1]= fqv[32];
	local[2]= NIL;
	local[3]= fqv[169];
	local[4]= argv[0]->c.obj.iv[33];
	local[5]= fqv[98];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto XapplwinCON3355;
XapplwinCON3359:
	local[0]= NIL;
XapplwinCON3355:
	local[0]= argv[0]->c.obj.iv[26];
	local[1]= fqv[32];
	local[2]= argv[0]->c.obj.iv[33];
	local[3]= fqv[98];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,1,local+2,&ftab[19],fqv[35]); /*string*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[33];
	local[1]= argv[0]->c.obj.iv[33];
	local[2]= fqv[170];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[34] = cons(ctx,local[0],w);
	local[0]= argv[0];
	local[1]= fqv[171];
	local[2]= argv[0]->c.obj.iv[33];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XapplwinBLK3354:
	ctx->vsp=local; return(local[0]);}

/*:set-superclass*/
static pointer XapplwinM3360objectbrowser_set_superclass(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[33];
	local[1]= argv[0]->c.obj.iv[34];
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,2,local+0,&ftab[20],fqv[172]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	if (local[0]==NIL) goto XapplwinIF3362;
	argv[0]->c.obj.iv[33] = local[0];
	local[1]= argv[0]->c.obj.iv[26];
	local[2]= fqv[32];
	local[3]= argv[0]->c.obj.iv[33];
	local[4]= fqv[98];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[19])(ctx,1,local+3,&ftab[19],fqv[35]); /*string*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[171];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto XapplwinIF3363;
XapplwinIF3362:
	local[1]= NIL;
XapplwinIF3363:
	w = local[1];
	local[0]= w;
XapplwinBLK3361:
	ctx->vsp=local; return(local[0]);}

/*:set-subclass*/
static pointer XapplwinM3364objectbrowser_set_subclass(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[34];
XapplwinWHL3366:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto XapplwinWHX3367;
	local[1]= argv[0]->c.obj.iv[33];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)EQ(ctx,2,local+1); /*eql*/
	if (w!=NIL) goto XapplwinWHX3367;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	goto XapplwinWHL3366;
XapplwinWHX3367:
	local[1]= NIL;
XapplwinBLK3368:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto XapplwinIF3369;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[33] = (w)->c.cons.car;
	local[1]= argv[0]->c.obj.iv[26];
	local[2]= fqv[32];
	local[3]= argv[0]->c.obj.iv[33];
	local[4]= fqv[98];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[19])(ctx,1,local+3,&ftab[19],fqv[35]); /*string*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[171];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto XapplwinIF3370;
XapplwinIF3369:
	local[1]= NIL;
XapplwinIF3370:
	w = local[1];
	w = argv[0]->c.obj.iv[33];
	local[0]= w;
XapplwinBLK3365:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___Xapplwin(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[173];
	local[1]= fqv[174];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[175]); /*require*/
	local[0]= fqv[176];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[177];
	local[1]= fqv[178];
	local[2]= fqv[177];
	local[3]= fqv[179];
	local[4]= loadglobal(fqv[180]);
	local[5]= fqv[181];
	local[6]= fqv[182];
	local[7]= fqv[183];
	local[8]= NIL;
	local[9]= fqv[184];
	local[10]= NIL;
	local[11]= fqv[185];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[186];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[22])(ctx,13,local+2,&ftab[22],fqv[187]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3175filedialog_create_buttons,fqv[42],fqv[177],fqv[188]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3177filedialog_create_fileview,fqv[43],fqv[177],fqv[189]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3179filedialog_create,fqv[19],fqv[177],fqv[190]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3186filedialog_cwd,fqv[46],fqv[177],fqv[191]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3188filedialog_file_selected,fqv[28],fqv[177],fqv[192]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3192filedialog_selected_fname,fqv[49],fqv[177],fqv[193]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3196filedialog_view,fqv[11],fqv[177],fqv[194]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3200filedialog_ok,fqv[3],fqv[177],fqv[195]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3204filedialog_cancel,fqv[5],fqv[177],fqv[196]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3208filedialog_open,fqv[7],fqv[177],fqv[197]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3212filedialog_go_up,fqv[9],fqv[177],fqv[198]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3214filedialog_resize,fqv[63],fqv[177],fqv[199]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3216filedialog_configurenotify,fqv[200],fqv[177],fqv[201]);
	local[0]= fqv[202];
	local[1]= fqv[178];
	local[2]= fqv[202];
	local[3]= fqv[179];
	local[4]= loadglobal(fqv[177]);
	local[5]= fqv[181];
	local[6]= fqv[203];
	local[7]= fqv[183];
	local[8]= NIL;
	local[9]= fqv[184];
	local[10]= NIL;
	local[11]= fqv[185];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[186];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[22])(ctx,13,local+2,&ftab[22],fqv[187]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3221filepanel_create_buttons,fqv[42],fqv[202],fqv[204]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3223filepanel_create,fqv[19],fqv[202],fqv[205]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3226filepanel_load,fqv[66],fqv[202],fqv[206]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3228filepanel_eval,fqv[74],fqv[202],fqv[207]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3230filepanel_print,fqv[70],fqv[202],fqv[208]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3234filepanel_compile,fqv[72],fqv[202],fqv[209]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3238filepanel_remove,fqv[68],fqv[202],fqv[210]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3240filepanel_remove_confirm,fqv[81],fqv[202],fqv[211]);
	local[0]= fqv[51];
	local[1]= fqv[178];
	local[2]= fqv[51];
	local[3]= fqv[179];
	local[4]= loadglobal(fqv[180]);
	local[5]= fqv[181];
	local[6]= fqv[212];
	local[7]= fqv[183];
	local[8]= NIL;
	local[9]= fqv[184];
	local[10]= NIL;
	local[11]= fqv[185];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[186];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[22])(ctx,13,local+2,&ftab[22],fqv[187]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3244textviewpanel_create,fqv[19],fqv[51],fqv[213]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3256textviewpanel_quit,fqv[88],fqv[51],fqv[214]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3258textviewpanel_finish,fqv[215],fqv[51],fqv[216]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3260textviewpanel_print,fqv[70],fqv[51],fqv[217]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3268textviewpanel_find,fqv[91],fqv[51],fqv[218]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3279textviewpanel_resize,fqv[63],fqv[51],fqv[219]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3281textviewpanel_configurenotify,fqv[200],fqv[51],fqv[220]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[221],module,XapplwinF3174ls_l,fqv[222]);
	local[0]= fqv[75];
	local[1]= fqv[178];
	local[2]= fqv[75];
	local[3]= fqv[179];
	local[4]= loadglobal(fqv[180]);
	local[5]= fqv[181];
	local[6]= fqv[223];
	local[7]= fqv[183];
	local[8]= NIL;
	local[9]= fqv[184];
	local[10]= NIL;
	local[11]= fqv[185];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[186];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[22])(ctx,13,local+2,&ftab[22],fqv[187]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3296confirmpanel_create,fqv[19],fqv[75],fqv[224]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3299confirmpanel_draw_message,fqv[124],fqv[75],fqv[225]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3304confirmpanel_ask,fqv[80],fqv[75],fqv[226]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3307confirmpanel_yes,fqv[84],fqv[75],fqv[227]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3309confirmpanel_no,fqv[121],fqv[75],fqv[228]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3311confirmpanel_configurenotify,fqv[200],fqv[75],fqv[229]);
	local[0]= fqv[230];
	local[1]= fqv[178];
	local[2]= fqv[230];
	local[3]= fqv[179];
	local[4]= loadglobal(fqv[180]);
	local[5]= fqv[181];
	local[6]= fqv[231];
	local[7]= fqv[183];
	local[8]= NIL;
	local[9]= fqv[184];
	local[10]= NIL;
	local[11]= fqv[185];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[186];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[22])(ctx,13,local+2,&ftab[22],fqv[187]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3316colorpickerpanel_create,fqv[19],fqv[230],fqv[232]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3319colorpickerpanel_init_value,fqv[233],fqv[230],fqv[234]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3321colorpickerpanel_value1,fqv[145],fqv[230],fqv[235]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3323colorpickerpanel_value2,fqv[147],fqv[230],fqv[236]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3325colorpickerpanel_value3,fqv[149],fqv[230],fqv[237]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3327colorpickerpanel_ambient,fqv[132],fqv[230],fqv[238]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3329colorpickerpanel_diffuse,fqv[134],fqv[230],fqv[239]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3331colorpickerpanel_specular,fqv[136],fqv[230],fqv[240]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3333colorpickerpanel_emission,fqv[138],fqv[230],fqv[241]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3335colorpickerpanel_shininess,fqv[140],fqv[230],fqv[242]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3337colorpickerpanel_transparency,fqv[142],fqv[230],fqv[243]);
	local[0]= fqv[244];
	local[1]= fqv[178];
	local[2]= fqv[244];
	local[3]= fqv[179];
	local[4]= loadglobal(fqv[180]);
	local[5]= fqv[181];
	local[6]= fqv[245];
	local[7]= fqv[183];
	local[8]= NIL;
	local[9]= fqv[184];
	local[10]= NIL;
	local[11]= fqv[185];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[186];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[22])(ctx,13,local+2,&ftab[22],fqv[187]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3339objectbrowser_create,fqv[19],fqv[244],fqv[246]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3344objectbrowser_update_method_names,fqv[171],fqv[244],fqv[247]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3348objectbrowser_set_object,fqv[152],fqv[244],fqv[248]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3353objectbrowser_set_class,fqv[154],fqv[244],fqv[249]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3360objectbrowser_set_superclass,fqv[158],fqv[244],fqv[250]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XapplwinM3364objectbrowser_set_subclass,fqv[156],fqv[244],fqv[251]);
	local[0]= fqv[252];
	local[1]= fqv[253];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[254]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<24; i++) ftab[i]=fcallx;
}

/* ./Xcolor.c :  entry=Xcolor */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "Xcolor.h"
#pragma init (register_Xcolor)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___Xcolor();
extern pointer build_quote_vector();
static int register_Xcolor()
  { add_module_initializer("___Xcolor", ___Xcolor);}

static pointer XcolorF1266list_visuals();
static pointer XcolorF1267visual_type();
static pointer XcolorF1268find_visual();
static pointer XcolorF1269visual_id();
static pointer XcolorF1270visual_class();
static pointer XcolorF1271visual_red_mask();
static pointer XcolorF1272visual_green_mask();
static pointer XcolorF1273visual_blue_mask();
static pointer XcolorF1274visual_masks();
static pointer XcolorF1275visual_bits_per_rgb();
static pointer XcolorF1276visual_depth();
static pointer XcolorF1277best_visual();
static pointer XcolorF1278xcolor_pixel();
static pointer XcolorF1279set_xcolor_pixel();
static pointer XcolorF1280xcolor_red();
static pointer XcolorF1281set_xcolor_red();
static pointer XcolorF1282xcolor_green();
static pointer XcolorF1283set_xcolor_green();
static pointer XcolorF1284xcolor_blue();
static pointer XcolorF1285set_xcolor_blue();
static pointer XcolorF1286xcolor_flags();
static pointer XcolorF1287set_xcolor_flags();
static pointer XcolorF1288xcolor_pad();
static pointer XcolorF1289set_xcolor_pad();
static pointer XcolorF1290get_lighter_pixel();
static pointer XcolorF1291get_redish_pixel();

/*list-visuals*/
static pointer XcolorF1266list_visuals(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto XcolorENT1294;}
	local[0]= makeint((eusinteger_t)0L);
XcolorENT1294:
XcolorENT1293:
	if (n>1) maerror();
	local[1]= NIL;
	local[2]= makeint((eusinteger_t)64L);
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,1,local+2,&ftab[0],fqv[0]); /*make-string*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= fqv[1];
XcolorWHL1295:
	if (local[7]==NIL) goto XcolorWHX1296;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)3L);
XcolorWHL1298:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto XcolorWHX1299;
	local[10]= local[8];
	w = makeint((eusinteger_t)3L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[1] = (pointer)((eusinteger_t)local[10] + (eusinteger_t)w);
	local[10]= loadglobal(fqv[2]);
	local[11]= local[0];
	local[12]= local[6];
	local[13]= local[1];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,5,local+10,&ftab[1],fqv[3]); /*matchvisualinfo*/
	local[3] = w;
	local[10]= T;
	local[11]= fqv[4];
	local[12]= local[6];
	local[13]= local[1];
	local[14]= local[13];
	if (fqv[5]!=local[14]) goto XcolorIF1301;
	local[14]= fqv[6];
	goto XcolorIF1302;
XcolorIF1301:
	local[14]= local[13];
	if (fqv[7]!=local[14]) goto XcolorIF1303;
	local[14]= fqv[8];
	goto XcolorIF1304;
XcolorIF1303:
	local[14]= local[13];
	if (fqv[9]!=local[14]) goto XcolorIF1305;
	local[14]= fqv[10];
	goto XcolorIF1306;
XcolorIF1305:
	local[14]= NIL;
XcolorIF1306:
XcolorIF1304:
XcolorIF1302:
	w = local[14];
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,4,local+10); /*format*/
	local[10]= local[3];
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)EQ(ctx,2,local+10); /*eql*/
	if (w==NIL) goto XcolorCON1308;
	local[10]= T;
	local[11]= fqv[11];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,2,local+10); /*format*/
	local[10]= w;
	goto XcolorCON1307;
XcolorCON1308:
	local[10]= local[2];
	local[11]= makeint((eusinteger_t)0L);
	local[12]= fqv[12];
	ctx->vsp=local+13;
	w=(pointer)PEEK(ctx,3,local+10); /*system:peek*/
	local[4] = w;
	local[10]= local[2];
	local[11]= makeint((eusinteger_t)4L);
	local[12]= fqv[12];
	ctx->vsp=local+13;
	w=(pointer)PEEK(ctx,3,local+10); /*system:peek*/
	local[5] = w;
	local[10]= T;
	local[11]= fqv[13];
	local[12]= local[4];
	local[13]= local[5];
	local[14]= local[4];
	local[15]= loadglobal(fqv[14]);
	ctx->vsp=local+16;
	w=(pointer)EQ(ctx,2,local+14); /*eql*/
	if (w==NIL) goto XcolorIF1310;
	local[14]= fqv[15];
	goto XcolorIF1311;
XcolorIF1310:
	local[14]= fqv[16];
XcolorIF1311:
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,5,local+10); /*format*/
	local[10]= w;
	goto XcolorCON1307;
XcolorCON1309:
	local[10]= NIL;
XcolorCON1307:
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto XcolorWHL1298;
XcolorWHX1299:
	local[10]= NIL;
XcolorBLK1300:
	w = NIL;
	goto XcolorWHL1295;
XcolorWHX1296:
	local[8]= NIL;
XcolorBLK1297:
	w = NIL;
	local[0]= w;
XcolorBLK1292:
	ctx->vsp=local; return(local[0]);}

/*visual-type*/
static pointer XcolorF1267visual_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!isint(w)) goto XcolorCON1314;
	local[0]= argv[0];
	goto XcolorCON1313;
XcolorCON1314:
	w = argv[0];
	if (!issymbol(w)) goto XcolorCON1315;
	local[0]= argv[0];
	local[1]= fqv[17];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[18]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	goto XcolorCON1313;
XcolorCON1315:
	local[0]= NIL;
XcolorCON1313:
	w = local[0];
	local[0]= w;
XcolorBLK1312:
	ctx->vsp=local; return(local[0]);}

/*find-visual*/
static pointer XcolorF1268find_visual(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XcolorENT1318;}
	local[0]= makeint((eusinteger_t)0L);
XcolorENT1318:
XcolorENT1317:
	if (n>3) maerror();
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)XcolorF1267visual_type(ctx,1,local+1); /*visual-type*/
	argv[0] = w;
	w = argv[0];
	if (isint(w)) goto XcolorIF1319;
	local[1]= fqv[19];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,2,local+1); /*error*/
	local[1]= w;
	goto XcolorIF1320;
XcolorIF1319:
	local[1]= NIL;
XcolorIF1320:
	local[1]= makeint((eusinteger_t)16L);
	local[2]= fqv[20];
	local[3]= fqv[21];
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,3,local+1,&ftab[3],fqv[22]); /*make-array*/
	local[1]= w;
	local[2]= loadglobal(fqv[2]);
	local[3]= local[0];
	local[4]= argv[1];
	local[5]= argv[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,5,local+2,&ftab[1],fqv[3]); /*matchvisualinfo*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)NUMEQUAL(ctx,2,local+2); /*=*/
	if (w==NIL) goto XcolorIF1321;
	local[2]= NIL;
	goto XcolorIF1322;
XcolorIF1321:
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,2,local+2); /*aref*/
	local[2]= w;
XcolorIF1322:
	w = local[2];
	local[0]= w;
XcolorBLK1316:
	ctx->vsp=local; return(local[0]);}

/*visual-id*/
static pointer XcolorF1269visual_id(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)4L);
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(pointer)PEEK(ctx,2,local+0); /*system:peek*/
	local[0]= w;
XcolorBLK1323:
	ctx->vsp=local; return(local[0]);}

/*visual-class*/
static pointer XcolorF1270visual_class(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)8L);
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(pointer)PEEK(ctx,2,local+0); /*system:peek*/
	local[0]= w;
XcolorBLK1324:
	ctx->vsp=local; return(local[0]);}

/*visual-red-mask*/
static pointer XcolorF1271visual_red_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)12L);
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(pointer)PEEK(ctx,2,local+0); /*system:peek*/
	local[0]= w;
XcolorBLK1325:
	ctx->vsp=local; return(local[0]);}

/*visual-green-mask*/
static pointer XcolorF1272visual_green_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)16L);
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(pointer)PEEK(ctx,2,local+0); /*system:peek*/
	local[0]= w;
XcolorBLK1326:
	ctx->vsp=local; return(local[0]);}

/*visual-blue-mask*/
static pointer XcolorF1273visual_blue_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)20L);
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(pointer)PEEK(ctx,2,local+0); /*system:peek*/
	local[0]= w;
XcolorBLK1327:
	ctx->vsp=local; return(local[0]);}

/*visual-masks*/
static pointer XcolorF1274visual_masks(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)12L);
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(pointer)PEEK(ctx,2,local+0); /*system:peek*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)16L);
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[1]= w;
	local[2]= fqv[12];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,2,local+1); /*system:peek*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= makeint((eusinteger_t)20L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)PEEK(ctx,2,local+2); /*system:peek*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
XcolorBLK1328:
	ctx->vsp=local; return(local[0]);}

/*visual-bits-per-rgb*/
static pointer XcolorF1275visual_bits_per_rgb(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)24L);
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(pointer)PEEK(ctx,2,local+0); /*system:peek*/
	local[0]= w;
XcolorBLK1329:
	ctx->vsp=local; return(local[0]);}

/*visual-depth*/
static pointer XcolorF1276visual_depth(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[23]);
	local[2]= fqv[24];
	local[3]= (pointer)get_sym_func(fqv[25]);
	ctx->vsp=local+4;
	w=(*ftab[2])(ctx,4,local+0,&ftab[2],fqv[18]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	if (local[0]==NIL) goto XcolorIF1331;
	local[1]= local[0];
	goto XcolorIF1332;
XcolorIF1331:
	local[1]= fqv[26];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,2,local+1); /*error*/
	local[1]= w;
XcolorIF1332:
	w = local[1];
	local[0]= w;
XcolorBLK1330:
	ctx->vsp=local; return(local[0]);}

/*best-visual*/
static pointer XcolorF1277best_visual(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto XcolorENT1337;}
	local[0]= fqv[27];
XcolorENT1337:
	if (n>=2) { local[1]=(argv[1]); goto XcolorENT1336;}
	local[1]= fqv[28];
XcolorENT1336:
	if (n>=3) { local[2]=(argv[2]); goto XcolorENT1335;}
	local[2]= makeint((eusinteger_t)0L);
XcolorENT1335:
XcolorENT1334:
	if (n>3) maerror();
	local[3]= NIL;
	local[4]= makeint((eusinteger_t)64L);
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,1,local+4,&ftab[0],fqv[0]); /*make-string*/
	local[4]= w;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= (pointer)get_sym_func(fqv[29]);
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)MAPCAR(ctx,2,local+8); /*mapcar*/
	local[0] = w;
	local[8]= NIL;
	local[9]= local[1];
XcolorWHL1338:
	if (local[9]==NIL) goto XcolorWHX1339;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= NIL;
	local[11]= local[0];
XcolorWHL1341:
	if (local[11]==NIL) goto XcolorWHX1342;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= loadglobal(fqv[2]);
	local[13]= local[2];
	local[14]= local[8];
	local[15]= local[10];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(*ftab[1])(ctx,5,local+12,&ftab[1],fqv[3]); /*matchvisualinfo*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(*ftab[4])(ctx,2,local+12,&ftab[4],fqv[30]); /*/=*/
	local[5] = w;
	if (local[5]==NIL) goto XcolorIF1344;
	local[12]= local[4];
	local[13]= makeint((eusinteger_t)0L);
	local[14]= fqv[12];
	ctx->vsp=local+15;
	w=(pointer)PEEK(ctx,3,local+12); /*system:peek*/
	local[6] = w;
	local[12]= local[6];
	local[13]= local[8];
	local[14]= local[10];
	local[15]= local[14];
	if (fqv[31]!=local[15]) goto XcolorIF1346;
	local[15]= fqv[32];
	goto XcolorIF1347;
XcolorIF1346:
	local[15]= local[14];
	if (fqv[33]!=local[15]) goto XcolorIF1348;
	local[15]= fqv[34];
	goto XcolorIF1349;
XcolorIF1348:
	local[15]= local[14];
	if (fqv[35]!=local[15]) goto XcolorIF1350;
	local[15]= fqv[36];
	goto XcolorIF1351;
XcolorIF1350:
	local[15]= NIL;
XcolorIF1351:
XcolorIF1349:
XcolorIF1347:
	w = local[15];
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,3,local+12); /*list*/
	ctx->vsp=local+12;
	local[0]=w;
	goto XcolorBLK1333;
	goto XcolorIF1345;
XcolorIF1344:
	local[12]= NIL;
XcolorIF1345:
	goto XcolorWHL1341;
XcolorWHX1342:
	local[12]= NIL;
XcolorBLK1343:
	w = NIL;
	goto XcolorWHL1338;
XcolorWHX1339:
	local[10]= NIL;
XcolorBLK1340:
	w = NIL;
	local[0]= w;
XcolorBLK1333:
	ctx->vsp=local; return(local[0]);}

/*xcolor-pixel*/
static pointer XcolorF1278xcolor_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= fqv[12];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XcolorBLK1352:
	ctx->vsp=local; return(local[0]);}

/*set-xcolor-pixel*/
static pointer XcolorF1279set_xcolor_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XcolorBLK1353:
	ctx->vsp=local; return(local[0]);}

/*xcolor-red*/
static pointer XcolorF1280xcolor_red(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)8L);
	local[2]= fqv[37];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XcolorBLK1354:
	ctx->vsp=local; return(local[0]);}

/*set-xcolor-red*/
static pointer XcolorF1281set_xcolor_red(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)8L);
	local[3]= fqv[37];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XcolorBLK1355:
	ctx->vsp=local; return(local[0]);}

/*xcolor-green*/
static pointer XcolorF1282xcolor_green(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)10L);
	local[2]= fqv[37];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XcolorBLK1356:
	ctx->vsp=local; return(local[0]);}

/*set-xcolor-green*/
static pointer XcolorF1283set_xcolor_green(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)10L);
	local[3]= fqv[37];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XcolorBLK1357:
	ctx->vsp=local; return(local[0]);}

/*xcolor-blue*/
static pointer XcolorF1284xcolor_blue(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)12L);
	local[2]= fqv[37];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XcolorBLK1358:
	ctx->vsp=local; return(local[0]);}

/*set-xcolor-blue*/
static pointer XcolorF1285set_xcolor_blue(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)12L);
	local[3]= fqv[37];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XcolorBLK1359:
	ctx->vsp=local; return(local[0]);}

/*xcolor-flags*/
static pointer XcolorF1286xcolor_flags(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)14L);
	local[2]= fqv[38];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XcolorBLK1360:
	ctx->vsp=local; return(local[0]);}

/*set-xcolor-flags*/
static pointer XcolorF1287set_xcolor_flags(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)14L);
	local[3]= fqv[38];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XcolorBLK1361:
	ctx->vsp=local; return(local[0]);}

/*xcolor-pad*/
static pointer XcolorF1288xcolor_pad(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)15L);
	local[2]= fqv[38];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XcolorBLK1362:
	ctx->vsp=local; return(local[0]);}

/*set-xcolor-pad*/
static pointer XcolorF1289set_xcolor_pad(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)15L);
	local[3]= fqv[38];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XcolorBLK1363:
	ctx->vsp=local; return(local[0]);}

/*:pixel*/
static pointer XcolorM1364xcolor_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XcolorF1278xcolor_pixel(ctx,1,local+0); /*xcolor-pixel*/
	local[0]= w;
XcolorBLK1365:
	ctx->vsp=local; return(local[0]);}

/*:red*/
static pointer XcolorM1366xcolor_red(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)XcolorF1280xcolor_red(ctx,1,local+2); /*xcolor-red*/
	local[1] = w;
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto XcolorIF1368;
	local[2]= makeint((eusinteger_t)65536L);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	goto XcolorIF1369;
XcolorIF1368:
	local[2]= local[1];
XcolorIF1369:
	w = local[2];
	local[0]= w;
XcolorBLK1367:
	ctx->vsp=local; return(local[0]);}

/*:green*/
static pointer XcolorM1370xcolor_green(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)XcolorF1282xcolor_green(ctx,1,local+2); /*xcolor-green*/
	local[1] = w;
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto XcolorIF1372;
	local[2]= makeint((eusinteger_t)65536L);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	goto XcolorIF1373;
XcolorIF1372:
	local[2]= local[1];
XcolorIF1373:
	w = local[2];
	local[0]= w;
XcolorBLK1371:
	ctx->vsp=local; return(local[0]);}

/*:blue*/
static pointer XcolorM1374xcolor_blue(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)XcolorF1284xcolor_blue(ctx,1,local+2); /*xcolor-blue*/
	local[1] = w;
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto XcolorIF1376;
	local[2]= makeint((eusinteger_t)65536L);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	goto XcolorIF1377;
XcolorIF1376:
	local[2]= local[1];
XcolorIF1377:
	w = local[2];
	local[0]= w;
XcolorBLK1375:
	ctx->vsp=local; return(local[0]);}

/*:rgb*/
static pointer XcolorM1378xcolor_rgb(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[39];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[40];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[41];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
XcolorBLK1379:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer XcolorM1380xcolor_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	if (n>=7) { local[0]=(argv[6]); goto XcolorENT1383;}
	local[0]= makeint((eusinteger_t)7L);
XcolorENT1383:
XcolorENT1382:
	if (n>7) maerror();
	local[1]= argv[0];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XcolorF1279set_xcolor_pixel(ctx,2,local+1); /*set-xcolor-pixel*/
	local[1]= argv[0];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)XcolorF1281set_xcolor_red(ctx,2,local+1); /*set-xcolor-red*/
	local[1]= argv[0];
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)XcolorF1283set_xcolor_green(ctx,2,local+1); /*set-xcolor-green*/
	local[1]= argv[0];
	local[2]= argv[5];
	ctx->vsp=local+3;
	w=(pointer)XcolorF1285set_xcolor_blue(ctx,2,local+1); /*set-xcolor-blue*/
	local[1]= argv[0];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)XcolorF1287set_xcolor_flags(ctx,2,local+1); /*set-xcolor-flags*/
	w = argv[0];
	local[0]= w;
XcolorBLK1381:
	ctx->vsp=local; return(local[0]);}

/*:id*/
static pointer XcolorM1384colormap_id(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
XcolorBLK1385:
	ctx->vsp=local; return(local[0]);}

/*:query*/
static pointer XcolorM1386colormap_query(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= loadglobal(fqv[42]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[43];
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,6,local+3); /*send*/
	w = local[2];
	local[1] = w;
	local[2]= loadglobal(fqv[2]);
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[5])(ctx,3,local+2,&ftab[5],fqv[44]); /*querycolor*/
	local[2]= local[1];
	local[3]= fqv[45];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[0]= w;
XcolorBLK1387:
	ctx->vsp=local; return(local[0]);}

/*:set-window*/
static pointer XcolorM1388colormap_set_window(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[2]);
	local[1]= argv[2];
	local[2]= fqv[46];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,3,local+0,&ftab[6],fqv[47]); /*setwindowcolormap*/
	local[0]= w;
XcolorBLK1389:
	ctx->vsp=local; return(local[0]);}

/*:destroy*/
static pointer XcolorM1390colormap_destroy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[2]);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,2,local+0,&ftab[7],fqv[48]); /*freecolormap*/
	local[0]= w;
XcolorBLK1391:
	ctx->vsp=local; return(local[0]);}

/*:alloc*/
static pointer XcolorM1392colormap_alloc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XcolorENT1396;}
	local[0]= NIL;
XcolorENT1396:
	if (n>=5) { local[1]=(argv[4]); goto XcolorENT1395;}
	local[1]= NIL;
XcolorENT1395:
XcolorENT1394:
	if (n>5) maerror();
	local[2]= argv[0];
	local[3]= fqv[49];
	local[4]= NIL;
	local[5]= argv[2];
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[0]= w;
XcolorBLK1393:
	ctx->vsp=local; return(local[0]);}

/*:store*/
static pointer XcolorM1397colormap_store(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto XcolorENT1401;}
	local[0]= NIL;
XcolorENT1401:
	if (n>=6) { local[1]=(argv[5]); goto XcolorENT1400;}
	local[1]= NIL;
XcolorENT1400:
XcolorENT1399:
	if (n>6) maerror();
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[3];
	local[7]= loadglobal(fqv[42]);
	ctx->vsp=local+8;
	w=(pointer)DERIVEDP(ctx,2,local+6); /*derivedp*/
	if (w==NIL) goto XcolorCON1403;
	local[4] = argv[3];
	local[6]= local[4];
	goto XcolorCON1402;
XcolorCON1403:
	w = argv[3];
	if (issymbol(w)) goto XcolorOR1405;
	w = argv[3];
	if (isstring(w)) goto XcolorOR1405;
	goto XcolorCON1404;
XcolorOR1405:
	local[6]= loadglobal(fqv[42]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[43];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)7L);
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,7,local+7); /*send*/
	w = local[6];
	local[4] = w;
	local[6]= loadglobal(fqv[42]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[43];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)7L);
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,7,local+7); /*send*/
	w = local[6];
	local[3] = w;
	local[6]= loadglobal(fqv[2]);
	local[7]= argv[0]->c.obj.iv[1];
	local[8]= argv[3];
	ctx->vsp=local+9;
	w=(*ftab[8])(ctx,1,local+8,&ftab[8],fqv[50]); /*string*/
	local[8]= w;
	local[9]= local[4];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(*ftab[9])(ctx,5,local+6,&ftab[9],fqv[51]); /*lookupcolor*/
	local[5] = w;
	local[6]= local[5];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)NUMEQUAL(ctx,2,local+6); /*=*/
	if (w==NIL) goto XcolorIF1406;
	w = NIL;
	ctx->vsp=local+6;
	local[0]=w;
	goto XcolorBLK1398;
	goto XcolorIF1407;
XcolorIF1406:
	local[6]= NIL;
XcolorIF1407:
	goto XcolorCON1402;
XcolorCON1404:
	w = argv[3];
	if (!isint(w)) goto XcolorCON1408;
	w = local[0];
	if (!isint(w)) goto XcolorCON1408;
	w = local[1];
	if (!isint(w)) goto XcolorCON1408;
	local[6]= loadglobal(fqv[42]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[43];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= argv[3];
	local[11]= local[0];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,6,local+7); /*send*/
	w = local[6];
	local[4] = w;
	local[6]= local[4];
	goto XcolorCON1402;
XcolorCON1408:
	local[6]= fqv[52];
	ctx->vsp=local+7;
	w=(pointer)SIGERROR(ctx,1,local+6); /*error*/
	local[6]= w;
	goto XcolorCON1402;
XcolorCON1409:
	local[6]= NIL;
XcolorCON1402:
	if (argv[2]!=NIL) goto XcolorCON1411;
	local[6]= loadglobal(fqv[2]);
	local[7]= argv[0]->c.obj.iv[1];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(*ftab[10])(ctx,3,local+6,&ftab[10],fqv[53]); /*alloccolor*/
	local[6]= local[4];
	local[7]= fqv[54];
	local[8]= fqv[55];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto XcolorCON1410;
XcolorCON1411:
	w = argv[2];
	if (!isint(w)) goto XcolorCON1412;
	local[6]= local[4];
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)XcolorF1279set_xcolor_pixel(ctx,2,local+6); /*set-xcolor-pixel*/
	local[6]= makeint((eusinteger_t)0L);
	local[7]= loadglobal(fqv[2]);
	local[8]= argv[0]->c.obj.iv[1];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(*ftab[11])(ctx,3,local+7,&ftab[11],fqv[56]); /*storecolor*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)NUMEQUAL(ctx,2,local+6); /*=*/
	if (w==NIL) goto XcolorIF1413;
	local[6]= NIL;
	goto XcolorIF1414;
XcolorIF1413:
	local[6]= argv[2];
XcolorIF1414:
	goto XcolorCON1410;
XcolorCON1412:
	local[6]= fqv[57];
	ctx->vsp=local+7;
	w=(pointer)SIGERROR(ctx,1,local+6); /*error*/
	local[6]= w;
	goto XcolorCON1410;
XcolorCON1415:
	local[6]= NIL;
XcolorCON1410:
	w = local[6];
	local[0]= w;
XcolorBLK1398:
	ctx->vsp=local; return(local[0]);}

/*:store-hls*/
static pointer XcolorM1416colormap_store_hls(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[3];
	local[1]= argv[4];
	local[2]= argv[5];
	local[3]= makeint((eusinteger_t)65536L);
	ctx->vsp=local+4;
	w=(*ftab[12])(ctx,4,local+0,&ftab[12],fqv[58]); /*geometry:hls2rgb*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[49];
	local[3]= argv[2];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[0]= w;
XcolorBLK1417:
	ctx->vsp=local; return(local[0]);}

/*:lut-list*/
static pointer XcolorM1418colormap_lut_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
XcolorBLK1419:
	ctx->vsp=local; return(local[0]);}

/*:lut-names*/
static pointer XcolorM1420colormap_lut_names(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= (pointer)get_sym_func(fqv[59]);
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
XcolorBLK1421:
	ctx->vsp=local; return(local[0]);}

/*:lut*/
static pointer XcolorM1422colormap_lut(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[18]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
XcolorBLK1423:
	ctx->vsp=local; return(local[0]);}

/*:pixel*/
static pointer XcolorM1424colormap_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[18]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)AREF(ctx,2,local+0); /*aref*/
	local[0]= w;
XcolorBLK1425:
	ctx->vsp=local; return(local[0]);}

/*:size*/
static pointer XcolorM1426colormap_size(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[60];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
XcolorBLK1427:
	ctx->vsp=local; return(local[0]);}

/*:planes*/
static pointer XcolorM1428colormap_planes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
XcolorBLK1429:
	ctx->vsp=local; return(local[0]);}

/*:plane-bits*/
static pointer XcolorM1430colormap_plane_bits(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
XcolorWHL1432:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto XcolorWHX1433;
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LOGIOR(ctx,2,local+3); /*logior*/
	local[0] = w;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto XcolorWHL1432;
XcolorWHX1433:
	local[3]= NIL;
XcolorBLK1434:
	w = NIL;
	w = local[0];
	local[0]= w;
XcolorBLK1431:
	ctx->vsp=local; return(local[0]);}

/*:plane-shifts*/
static pointer XcolorM1435colormap_plane_shifts(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)0L);
XcolorWHL1437:
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,2,local+2); /*aref*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LOGBITP(ctx,2,local+1); /*logbitp*/
	if (w!=NIL) goto XcolorWHX1438;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)ADD1(ctx,1,local+1); /*1+*/
	local[0] = w;
	goto XcolorWHL1437;
XcolorWHX1438:
	local[1]= NIL;
XcolorBLK1439:
	w = local[0];
	local[0]= w;
XcolorBLK1436:
	ctx->vsp=local; return(local[0]);}

/*:free*/
static pointer XcolorM1440colormap_free(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XcolorENT1443;}
	local[0]= NIL;
XcolorENT1443:
XcolorENT1442:
	if (n>3) maerror();
	w = local[0];
	if (!isint(w)) goto XcolorCON1445;
	local[1]= loadglobal(fqv[2]);
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)MKINTVECTOR(ctx,1,local+3); /*integer-vector*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKINTVECTOR(ctx,1,local+5); /*integer-vector*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[13])(ctx,5,local+1,&ftab[13],fqv[61]); /*freecolors*/
	local[1]= w;
	goto XcolorCON1444;
XcolorCON1445:
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[18]); /*assoc*/
	if (w==NIL) goto XcolorCON1446;
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[18]); /*assoc*/
	local[0] = w;
	local[1]= loadglobal(fqv[2]);
	local[2]= argv[0]->c.obj.iv[1];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKINTVECTOR(ctx,1,local+5); /*integer-vector*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[13])(ctx,5,local+1,&ftab[13],fqv[61]); /*freecolors*/
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+3;
	w=(*ftab[14])(ctx,2,local+1,&ftab[14],fqv[62]); /*delete*/
	argv[0]->c.obj.iv[4] = w;
	local[1]= argv[0]->c.obj.iv[4];
	goto XcolorCON1444;
XcolorCON1446:
	w = local[0];
	if (iscons(w)) goto XcolorOR1448;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)VECTORP(ctx,1,local+1); /*vectorp*/
	if (w!=NIL) goto XcolorOR1448;
	goto XcolorCON1447;
XcolorOR1448:
	local[1]= makeint((eusinteger_t)0L);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
XcolorWHL1449:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto XcolorWHX1450;
	local[3]= loadglobal(fqv[2]);
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= local[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MKINTVECTOR(ctx,1,local+5); /*integer-vector*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)MKINTVECTOR(ctx,1,local+6); /*integer-vector*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[13])(ctx,4,local+3,&ftab[13],fqv[61]); /*freecolors*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto XcolorWHL1449;
XcolorWHX1450:
	local[3]= NIL;
XcolorBLK1451:
	w = NIL;
	local[1]= w;
	goto XcolorCON1444;
XcolorCON1447:
	local[1]= local[0];
	if (T!=local[1]) goto XcolorCON1452;
	local[1]= loadglobal(fqv[2]);
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= local[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[63];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[13])(ctx,5,local+1,&ftab[13],fqv[61]); /*freecolors*/
	local[1]= w;
	goto XcolorCON1444;
XcolorCON1452:
	local[1]= NIL;
XcolorCON1444:
	w = local[1];
	local[0]= w;
XcolorBLK1441:
	ctx->vsp=local; return(local[0]);}

/*:allocate-private-colors*/
static pointer XcolorM1453colormap_allocate_private_colors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XcolorENT1456;}
	local[0]= makeint((eusinteger_t)0L);
XcolorENT1456:
XcolorENT1455:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= fqv[20];
	local[3]= fqv[21];
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,3,local+1,&ftab[3],fqv[22]); /*make-array*/
	argv[0]->c.obj.iv[3] = w;
	local[1]= local[0];
	local[2]= fqv[20];
	local[3]= fqv[21];
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,3,local+1,&ftab[3],fqv[22]); /*make-array*/
	argv[0]->c.obj.iv[2] = w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= loadglobal(fqv[2]);
	local[6]= argv[0]->c.obj.iv[1];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= local[0];
	local[10]= argv[0]->c.obj.iv[3];
	local[11]= argv[2];
	ctx->vsp=local+12;
	w=(*ftab[15])(ctx,7,local+5,&ftab[15],fqv[64]); /*alloccolorcells*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)NUMEQUAL(ctx,2,local+4); /*=*/
	if (w==NIL) goto XcolorIF1457;
	local[4]= fqv[65];
	local[5]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+6;
	w=(*ftab[16])(ctx,2,local+4,&ftab[16],fqv[66]); /*warn*/
	local[4]= NIL;
	goto XcolorIF1458;
XcolorIF1457:
	local[4]= NIL;
	local[5]= loadglobal(fqv[67]);
	local[6]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+7;
	w=(pointer)CONCATENATE(ctx,2,local+5); /*concatenate*/
	local[5]= w;
XcolorWHL1459:
	if (local[5]==NIL) goto XcolorWHX1460;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)2L);
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(*ftab[17])(ctx,2,local+7,&ftab[17],fqv[68]); /*expt*/
	local[7]= w;
XcolorWHL1462:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto XcolorWHX1463;
	local[2] = local[6];
	local[3] = makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[0];
XcolorWHL1465:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto XcolorWHX1466;
	local[10]= local[2];
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)LOGAND(ctx,2,local+10); /*logand*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)NUMEQUAL(ctx,2,local+10); /*=*/
	if (w==NIL) goto XcolorIF1468;
	local[10]= local[3];
	local[11]= argv[0]->c.obj.iv[2];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,2,local+11); /*aref*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[3] = w;
	local[10]= local[3];
	goto XcolorIF1469;
XcolorIF1468:
	local[10]= NIL;
XcolorIF1469:
	local[10]= local[2];
	local[11]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+12;
	w=(pointer)ASH(ctx,2,local+10); /*ash*/
	local[2] = w;
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto XcolorWHL1465;
XcolorWHX1466:
	local[10]= NIL;
XcolorBLK1467:
	w = NIL;
	local[8]= local[4];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)LOGIOR(ctx,2,local+8); /*logior*/
	local[8]= w;
	w = local[1];
	ctx->vsp=local+9;
	local[1] = cons(ctx,local[8],w);
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto XcolorWHL1462;
XcolorWHX1463:
	local[8]= NIL;
XcolorBLK1464:
	w = NIL;
	goto XcolorWHL1459;
XcolorWHX1460:
	local[6]= NIL;
XcolorBLK1461:
	local[6]= local[1];
	local[7]= loadglobal(fqv[69]);
	ctx->vsp=local+8;
	w=(pointer)COERCE(ctx,2,local+6); /*coerce*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)NREVERSE(ctx,1,local+6); /*nreverse*/
	local[4]= w;
XcolorIF1458:
	w = local[4];
	local[0]= w;
XcolorBLK1454:
	ctx->vsp=local; return(local[0]);}

/*:allocate-colors*/
static pointer XcolorM1470colormap_allocate_colors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XcolorENT1474;}
	local[0]= NIL;
XcolorENT1474:
	if (n>=5) { local[1]=(argv[4]); goto XcolorENT1473;}
	local[1]= makeint((eusinteger_t)0L);
XcolorENT1473:
XcolorENT1472:
	if (n>5) maerror();
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	local[5]= NIL;
	if (local[0]==NIL) goto XcolorCON1476;
	local[6]= argv[0];
	local[7]= fqv[70];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	if (local[2]!=NIL) goto XcolorIF1477;
	w = NIL;
	ctx->vsp=local+6;
	local[0]=w;
	goto XcolorBLK1471;
	goto XcolorIF1478;
XcolorIF1477:
	local[6]= NIL;
XcolorIF1478:
	goto XcolorCON1475;
XcolorCON1476:
	local[6]= local[4];
	local[7]= fqv[20];
	local[8]= fqv[21];
	ctx->vsp=local+9;
	w=(*ftab[3])(ctx,3,local+6,&ftab[3],fqv[22]); /*make-array*/
	local[2] = w;
	local[6]= local[2];
	goto XcolorCON1475;
XcolorCON1479:
	local[6]= NIL;
XcolorCON1475:
	local[6]= NIL;
	local[7]= argv[2];
XcolorWHL1480:
	if (local[7]==NIL) goto XcolorWHX1481;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	if (local[0]==NIL) goto XcolorCON1484;
	w = local[6];
	if (!iscons(w)) goto XcolorIF1485;
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= local[2];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,2,local+10); /*aref*/
	local[10]= w;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,6,local+8); /*send*/
	local[8]= w;
	goto XcolorIF1486;
XcolorIF1485:
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= local[2];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,2,local+10); /*aref*/
	local[10]= w;
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= w;
XcolorIF1486:
	goto XcolorCON1483;
XcolorCON1484:
	w = local[6];
	if (!iscons(w)) goto XcolorIF1488;
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= NIL;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,6,local+8); /*send*/
	local[8]= w;
	goto XcolorIF1489;
XcolorIF1488:
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= NIL;
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= w;
XcolorIF1489:
	local[5] = local[8];
	if (local[5]!=NIL) goto XcolorIF1490;
	local[8]= argv[0];
	local[9]= fqv[71];
	local[10]= local[2];
	local[11]= makeint((eusinteger_t)0L);
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)SUBSEQ(ctx,3,local+10); /*subseq*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= fqv[72];
	ctx->vsp=local+9;
	w=(pointer)SIGERROR(ctx,1,local+8); /*error*/
	local[8]= w;
	goto XcolorIF1491;
XcolorIF1490:
	local[8]= NIL;
XcolorIF1491:
	local[8]= local[2];
	local[9]= local[3];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)ASET(ctx,3,local+8); /*aset*/
	local[8]= w;
	goto XcolorCON1483;
XcolorCON1487:
	local[8]= NIL;
XcolorCON1483:
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[3] = w;
	goto XcolorWHL1480;
XcolorWHX1481:
	local[8]= NIL;
XcolorBLK1482:
	w = NIL;
	w = local[2];
	local[0]= w;
XcolorBLK1471:
	ctx->vsp=local; return(local[0]);}

/*:define-lut*/
static pointer XcolorM1492colormap_define_lut(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto XcolorENT1495;}
	local[0]= NIL;
XcolorENT1495:
XcolorENT1494:
	if (n>5) maerror();
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[18]); /*assoc*/
	local[1]= w;
	local[2]= NIL;
	if (local[1]!=NIL) goto XcolorCON1497;
	local[3]= argv[0];
	local[4]= fqv[73];
	local[5]= argv[3];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[2] = w;
	if (local[2]!=NIL) goto XcolorIF1498;
	local[3]= fqv[74];
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,1,local+3); /*error*/
	local[3]= w;
	goto XcolorIF1499;
XcolorIF1498:
	local[3]= NIL;
XcolorIF1499:
	local[3]= argv[2];
	w = local[2];
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	w = argv[0]->c.obj.iv[4];
	ctx->vsp=local+4;
	argv[0]->c.obj.iv[4] = cons(ctx,local[3],w);
	local[3]= local[2];
	goto XcolorCON1496;
XcolorCON1497:
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	if (w!=local[3]) goto XcolorCON1500;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	goto XcolorCON1496;
XcolorCON1500:
	local[3]= fqv[75];
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,1,local+3); /*error*/
	local[3]= w;
	goto XcolorCON1496;
XcolorCON1501:
	local[3]= NIL;
XcolorCON1496:
	w = local[3];
	local[0]= w;
XcolorBLK1493:
	ctx->vsp=local; return(local[0]);}

/*:define-gray-scale-lut*/
static pointer XcolorM1502colormap_define_gray_scale_lut(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto XcolorENT1505;}
	local[0]= NIL;
XcolorENT1505:
XcolorENT1504:
	if (n>5) maerror();
	local[1]= NIL;
	local[2]= makeint((eusinteger_t)65536L);
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)SUB1(ctx,1,local+3); /*1-*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[3];
XcolorWHL1506:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto XcolorWHX1507;
	local[6]= local[3];
	local[7]= local[3];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,3,local+6); /*list*/
	local[6]= w;
	w = local[1];
	ctx->vsp=local+7;
	local[1] = cons(ctx,local[6],w);
	local[6]= local[3];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[3] = w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto XcolorWHL1506;
XcolorWHX1507:
	local[6]= NIL;
XcolorBLK1508:
	w = NIL;
	local[4]= argv[0];
	local[5]= fqv[76];
	local[6]= argv[2];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)NREVERSE(ctx,1,local+7); /*nreverse*/
	local[7]= w;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[0]= w;
XcolorBLK1503:
	ctx->vsp=local; return(local[0]);}

/*:define-rgb-lut*/
static pointer XcolorM1509colormap_define_rgb_lut(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto XcolorENT1514;}
	local[0]= argv[3];
XcolorENT1514:
	if (n>=6) { local[1]=(argv[5]); goto XcolorENT1513;}
	local[1]= local[0];
XcolorENT1513:
	if (n>=7) { local[2]=(argv[6]); goto XcolorENT1512;}
	local[2]= NIL;
XcolorENT1512:
XcolorENT1511:
	if (n>7) maerror();
	local[3]= argv[3];
	local[4]= local[0];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,3,local+3); /*+*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)2L);
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(*ftab[17])(ctx,2,local+4,&ftab[17],fqv[68]); /*expt*/
	local[4]= w;
	local[5]= NIL;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)2L);
	local[8]= argv[3];
	ctx->vsp=local+9;
	w=(*ftab[17])(ctx,2,local+7,&ftab[17],fqv[68]); /*expt*/
	argv[3] = w;
	local[7]= makeint((eusinteger_t)2L);
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(*ftab[17])(ctx,2,local+7,&ftab[17],fqv[68]); /*expt*/
	local[0] = w;
	local[7]= makeint((eusinteger_t)2L);
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(*ftab[17])(ctx,2,local+7,&ftab[17],fqv[68]); /*expt*/
	local[1] = w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[3];
XcolorWHL1515:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto XcolorWHX1516;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[0];
XcolorWHL1518:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto XcolorWHX1519;
	local[11]= makeint((eusinteger_t)0L);
	local[12]= local[1];
XcolorWHL1521:
	local[13]= local[11];
	w = local[12];
	if ((eusinteger_t)local[13] >= (eusinteger_t)w) goto XcolorWHX1522;
	local[13]= makeint((eusinteger_t)65535L);
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[14]= w;
	local[15]= argv[3];
	ctx->vsp=local+16;
	w=(pointer)EUSFLOAT(ctx,1,local+15); /*float*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)ROUND(ctx,1,local+13); /*round*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)65535L);
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[15]= w;
	local[16]= local[0];
	ctx->vsp=local+17;
	w=(pointer)EUSFLOAT(ctx,1,local+16); /*float*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)QUOTIENT(ctx,2,local+15); /*/*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)ROUND(ctx,1,local+14); /*round*/
	local[14]= w;
	local[15]= makeint((eusinteger_t)65535L);
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[16]= w;
	local[17]= local[1];
	ctx->vsp=local+18;
	w=(pointer)EUSFLOAT(ctx,1,local+17); /*float*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)QUOTIENT(ctx,2,local+16); /*/*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)ROUND(ctx,1,local+15); /*round*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,3,local+13); /*list*/
	local[13]= w;
	w = local[5];
	ctx->vsp=local+14;
	local[5] = cons(ctx,local[13],w);
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)ADD1(ctx,1,local+13); /*1+*/
	local[6] = w;
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)ADD1(ctx,1,local+13); /*1+*/
	local[11] = w;
	goto XcolorWHL1521;
XcolorWHX1522:
	local[13]= NIL;
XcolorBLK1523:
	w = NIL;
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto XcolorWHL1518;
XcolorWHX1519:
	local[11]= NIL;
XcolorBLK1520:
	w = NIL;
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto XcolorWHL1515;
XcolorWHX1516:
	local[9]= NIL;
XcolorBLK1517:
	w = NIL;
	local[7]= argv[0];
	local[8]= fqv[76];
	local[9]= argv[2];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)NREVERSE(ctx,1,local+10); /*nreverse*/
	local[10]= w;
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	local[0]= w;
XcolorBLK1510:
	ctx->vsp=local; return(local[0]);}

/*:define-hls-lut*/
static pointer XcolorM1524colormap_define_hls_lut(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<8) maerror();
	if (n>=9) { local[0]=(argv[8]); goto XcolorENT1527;}
	local[0]= NIL;
XcolorENT1527:
XcolorENT1526:
	if (n>9) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[5];
	local[4]= argv[6];
	local[5]= argv[5];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)EUSFLOAT(ctx,1,local+5); /*float*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[3];
XcolorWHL1528:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto XcolorWHX1529;
	local[7]= argv[4];
	local[8]= local[3];
	local[9]= argv[7];
	local[10]= makeint((eusinteger_t)65535L);
	ctx->vsp=local+11;
	w=(*ftab[12])(ctx,4,local+7,&ftab[12],fqv[58]); /*geometry:hls2rgb*/
	local[1] = w;
	local[7]= local[1];
	w = local[2];
	ctx->vsp=local+8;
	local[2] = cons(ctx,local[7],w);
	local[7]= local[3];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[3] = w;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto XcolorWHL1528;
XcolorWHX1529:
	local[7]= NIL;
XcolorBLK1530:
	w = NIL;
	local[5]= argv[0];
	local[6]= fqv[76];
	local[7]= argv[2];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)NREVERSE(ctx,1,local+8); /*nreverse*/
	local[8]= w;
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	local[0]= w;
XcolorBLK1525:
	ctx->vsp=local; return(local[0]);}

/*:define-rainbow-lut*/
static pointer XcolorM1531colormap_define_rainbow_lut(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XcolorENT1539;}
	local[0]= makeint((eusinteger_t)32L);
XcolorENT1539:
	if (n>=5) { local[1]=(argv[4]); goto XcolorENT1538;}
	local[1]= makeint((eusinteger_t)0L);
XcolorENT1538:
	if (n>=6) { local[2]=(argv[5]); goto XcolorENT1537;}
	local[2]= makeint((eusinteger_t)360L);
XcolorENT1537:
	if (n>=7) { local[3]=(argv[6]); goto XcolorENT1536;}
	local[3]= makeflt(5.0000000000000000000000e-01);
XcolorENT1536:
	if (n>=8) { local[4]=(argv[7]); goto XcolorENT1535;}
	local[4]= makeflt(1.0000000000000000000000e+00);
XcolorENT1535:
	if (n>=9) { local[5]=(argv[8]); goto XcolorENT1534;}
	local[5]= NIL;
XcolorENT1534:
XcolorENT1533:
	if (n>9) maerror();
	local[6]= NIL;
	local[7]= NIL;
	local[8]= local[1];
	local[9]= local[2];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)EUSFLOAT(ctx,1,local+10); /*float*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[0];
XcolorWHL1540:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto XcolorWHX1541;
	local[12]= local[8];
	local[13]= local[3];
	local[14]= local[4];
	local[15]= makeint((eusinteger_t)65535L);
	ctx->vsp=local+16;
	w=(*ftab[12])(ctx,4,local+12,&ftab[12],fqv[58]); /*geometry:hls2rgb*/
	local[6] = w;
	local[12]= local[6];
	w = local[7];
	ctx->vsp=local+13;
	local[7] = cons(ctx,local[12],w);
	local[12]= local[8];
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[8] = w;
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto XcolorWHL1540;
XcolorWHX1541:
	local[12]= NIL;
XcolorBLK1542:
	w = NIL;
	local[10]= argv[0];
	local[11]= fqv[76];
	local[12]= argv[2];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)NREVERSE(ctx,1,local+13); /*nreverse*/
	local[13]= w;
	local[14]= local[5];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,5,local+10); /*send*/
	local[0]= w;
XcolorBLK1532:
	ctx->vsp=local; return(local[0]);}

/*:install*/
static pointer XcolorM1543colormap_install(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[2]);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[77]); /*installcolormap*/
	local[0]= w;
XcolorBLK1544:
	ctx->vsp=local; return(local[0]);}

/*:uninstall*/
static pointer XcolorM1545colormap_uninstall(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[2]);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[19])(ctx,2,local+0,&ftab[19],fqv[78]); /*uninstallcolormap*/
	local[0]= w;
XcolorBLK1546:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer XcolorM1547colormap_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XcolorENT1550;}
	local[0]= NIL;
XcolorENT1550:
XcolorENT1549:
	if (n>3) maerror();
	argv[0]->c.obj.iv[1] = local[0];
	argv[0]->c.obj.iv[4] = NIL;
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= loadglobal(fqv[79]);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[20])(ctx,3,local+1,&ftab[20],fqv[80]); /*sethash*/
	w = argv[0];
	local[0]= w;
XcolorBLK1548:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XcolorM1551colormap_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[81], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto XcolorKEY1553;
	local[0] = makeint((eusinteger_t)0L);
XcolorKEY1553:
	if (n & (1<<1)) goto XcolorKEY1554;
	local[1] = makeint((eusinteger_t)1L);
XcolorKEY1554:
	if (n & (1<<2)) goto XcolorKEY1555;
	local[2] = loadglobal(fqv[14]);
XcolorKEY1555:
	if (n & (1<<3)) goto XcolorKEY1556;
	local[3] = NIL;
XcolorKEY1556:
	local[4]= argv[0];
	local[5]= fqv[43];
	local[6]= loadglobal(fqv[2]);
	local[7]= loadglobal(fqv[82]);
	local[8]= fqv[46];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= local[2];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(*ftab[21])(ctx,4,local+6,&ftab[21],fqv[83]); /*createcolormap*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	w = argv[0];
	local[0]= w;
XcolorBLK1552:
	ctx->vsp=local; return(local[0]);}

/*:get-pixel*/
static pointer XcolorM1557colormap_get_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	if (!isnum(w)) goto XcolorIF1559;
	local[0]= argv[2];
	goto XcolorIF1560;
XcolorIF1559:
	local[0]= argv[0];
	local[1]= fqv[84];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XcolorIF1560:
	w = local[0];
	local[0]= w;
XcolorBLK1558:
	ctx->vsp=local; return(local[0]);}

/*:copy-colors*/
static pointer XcolorM1561colormap_copy_colors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto XcolorENT1564;}
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	local[0]= w;
XcolorENT1564:
XcolorENT1563:
	if (n>5) maerror();
	local[1]= NIL;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[0];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
XcolorWHL1565:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto XcolorWHX1566;
	local[4]= (pointer)get_sym_func(fqv[85]);
	local[5]= argv[0];
	local[6]= fqv[84];
	local[7]= argv[2];
	local[8]= fqv[86];
	local[9]= argv[3];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,4,local+4); /*apply*/
	local[4]= w;
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto XcolorWHL1565;
XcolorWHX1566:
	local[4]= NIL;
XcolorBLK1567:
	w = NIL;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)NREVERSE(ctx,1,local+2); /*nreverse*/
	local[0]= w;
XcolorBLK1562:
	ctx->vsp=local; return(local[0]);}

/*get-lighter-pixel*/
static pointer XcolorF1290get_lighter_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto XcolorENT1571;}
	local[0]= makeflt(1.3999999999999994670929e+00);
XcolorENT1571:
	if (n>=3) { local[1]=(argv[2]); goto XcolorENT1570;}
	local[1]= loadglobal(fqv[87]);
XcolorENT1570:
XcolorENT1569:
	if (n>3) maerror();
	local[2]= NIL;
	local[3]= NIL;
	local[4]= local[1];
	local[5]= fqv[86];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[3] = w;
	local[4]= local[1];
	local[5]= fqv[84];
	local[6]= local[0];
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	local[7]= loadglobal(fqv[88]);
	ctx->vsp=local+8;
	w=(pointer)MIN(ctx,2,local+6); /*min*/
	local[6]= w;
	local[7]= local[0];
	local[8]= local[3];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ROUND(ctx,1,local+7); /*round*/
	local[7]= w;
	local[8]= loadglobal(fqv[88]);
	ctx->vsp=local+9;
	w=(pointer)MIN(ctx,2,local+7); /*min*/
	local[7]= w;
	local[8]= local[0];
	local[9]= local[3];
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)ROUND(ctx,1,local+8); /*round*/
	local[8]= w;
	local[9]= loadglobal(fqv[88]);
	ctx->vsp=local+10;
	w=(pointer)MIN(ctx,2,local+8); /*min*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[0]= w;
XcolorBLK1568:
	ctx->vsp=local; return(local[0]);}

/*get-redish-pixel*/
static pointer XcolorF1291get_redish_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto XcolorENT1575;}
	local[0]= makeflt(1.0999999999999996447286e+00);
XcolorENT1575:
	if (n>=3) { local[1]=(argv[2]); goto XcolorENT1574;}
	local[1]= loadglobal(fqv[87]);
XcolorENT1574:
XcolorENT1573:
	if (n>3) maerror();
	local[2]= NIL;
	local[3]= NIL;
	local[4]= local[1];
	local[5]= fqv[86];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[3] = w;
	local[4]= local[1];
	local[5]= fqv[84];
	local[6]= local[0];
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	local[7]= loadglobal(fqv[88]);
	ctx->vsp=local+8;
	w=(pointer)MIN(ctx,2,local+6); /*min*/
	local[6]= w;
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ROUND(ctx,1,local+7); /*round*/
	local[7]= w;
	local[8]= loadglobal(fqv[88]);
	ctx->vsp=local+9;
	w=(pointer)MIN(ctx,2,local+7); /*min*/
	local[7]= w;
	local[8]= local[3];
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)ROUND(ctx,1,local+8); /*round*/
	local[8]= w;
	local[9]= loadglobal(fqv[88]);
	ctx->vsp=local+10;
	w=(pointer)MIN(ctx,2,local+8); /*min*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[0]= w;
XcolorBLK1572:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___Xcolor(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[89];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[90],module,XcolorF1266list_visuals,fqv[91]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[29],module,XcolorF1267visual_type,fqv[92]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[93],module,XcolorF1268find_visual,fqv[94]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[95],module,XcolorF1269visual_id,fqv[96]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[97],module,XcolorF1270visual_class,fqv[98]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[99],module,XcolorF1271visual_red_mask,fqv[100]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[101],module,XcolorF1272visual_green_mask,fqv[102]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[103],module,XcolorF1273visual_blue_mask,fqv[104]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[105],module,XcolorF1274visual_masks,fqv[106]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[107],module,XcolorF1275visual_bits_per_rgb,fqv[108]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[109],module,XcolorF1276visual_depth,fqv[110]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[111],module,XcolorF1277best_visual,fqv[112]);
	local[0]= fqv[42];
	local[1]= fqv[113];
	local[2]= fqv[42];
	local[3]= fqv[114];
	local[4]= loadglobal(fqv[115]);
	local[5]= fqv[116];
	local[6]= fqv[117];
	local[7]= fqv[118];
	local[8]= loadglobal(fqv[119]);
	local[9]= fqv[20];
	local[10]= fqv[38];
	local[11]= fqv[120];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[121];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[22])(ctx,13,local+2,&ftab[22],fqv[122]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= loadglobal(fqv[42]);
	local[1]= fqv[123];
	local[2]= fqv[124];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[125],module,XcolorF1278xcolor_pixel,fqv[126]);
	local[0]= fqv[125];
	local[1]= fqv[127];
	local[2]= fqv[128];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[125];
	local[1]= fqv[129];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[130]); /*remprop*/
	local[0]= fqv[125];
	local[1]= fqv[131];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[130]); /*remprop*/
	local[0]= fqv[125];
	local[1]= NIL;
	local[2]= fqv[132];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[127],module,XcolorF1279set_xcolor_pixel,fqv[133]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[134],module,XcolorF1280xcolor_red,fqv[135]);
	local[0]= fqv[134];
	local[1]= fqv[136];
	local[2]= fqv[128];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[134];
	local[1]= fqv[129];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[130]); /*remprop*/
	local[0]= fqv[134];
	local[1]= fqv[131];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[130]); /*remprop*/
	local[0]= fqv[134];
	local[1]= NIL;
	local[2]= fqv[132];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[136],module,XcolorF1281set_xcolor_red,fqv[137]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[138],module,XcolorF1282xcolor_green,fqv[139]);
	local[0]= fqv[138];
	local[1]= fqv[140];
	local[2]= fqv[128];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[138];
	local[1]= fqv[129];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[130]); /*remprop*/
	local[0]= fqv[138];
	local[1]= fqv[131];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[130]); /*remprop*/
	local[0]= fqv[138];
	local[1]= NIL;
	local[2]= fqv[132];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[140],module,XcolorF1283set_xcolor_green,fqv[141]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[142],module,XcolorF1284xcolor_blue,fqv[143]);
	local[0]= fqv[142];
	local[1]= fqv[144];
	local[2]= fqv[128];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[142];
	local[1]= fqv[129];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[130]); /*remprop*/
	local[0]= fqv[142];
	local[1]= fqv[131];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[130]); /*remprop*/
	local[0]= fqv[142];
	local[1]= NIL;
	local[2]= fqv[132];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[144],module,XcolorF1285set_xcolor_blue,fqv[145]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[146],module,XcolorF1286xcolor_flags,fqv[147]);
	local[0]= fqv[146];
	local[1]= fqv[148];
	local[2]= fqv[128];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[146];
	local[1]= fqv[129];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[130]); /*remprop*/
	local[0]= fqv[146];
	local[1]= fqv[131];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[130]); /*remprop*/
	local[0]= fqv[146];
	local[1]= NIL;
	local[2]= fqv[132];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[148],module,XcolorF1287set_xcolor_flags,fqv[149]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[150],module,XcolorF1288xcolor_pad,fqv[151]);
	local[0]= fqv[150];
	local[1]= fqv[152];
	local[2]= fqv[128];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[150];
	local[1]= fqv[129];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[130]); /*remprop*/
	local[0]= fqv[150];
	local[1]= fqv[131];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[130]); /*remprop*/
	local[0]= fqv[150];
	local[1]= NIL;
	local[2]= fqv[132];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[152],module,XcolorF1289set_xcolor_pad,fqv[153]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1364xcolor_pixel,fqv[154],fqv[42],fqv[155]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1366xcolor_red,fqv[39],fqv[42],fqv[156]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1370xcolor_green,fqv[40],fqv[42],fqv[157]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1374xcolor_blue,fqv[41],fqv[42],fqv[158]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1378xcolor_rgb,fqv[45],fqv[42],fqv[159]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1380xcolor_init,fqv[43],fqv[42],fqv[160]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1384colormap_id,fqv[161],fqv[162],fqv[163]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1386colormap_query,fqv[86],fqv[162],fqv[164]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1388colormap_set_window,fqv[165],fqv[162],fqv[166]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1390colormap_destroy,fqv[167],fqv[162],fqv[168]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1392colormap_alloc,fqv[84],fqv[162],fqv[169]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1397colormap_store,fqv[49],fqv[162],fqv[170]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1416colormap_store_hls,fqv[171],fqv[162],fqv[172]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1418colormap_lut_list,fqv[173],fqv[162],fqv[174]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1420colormap_lut_names,fqv[175],fqv[162],fqv[176]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1422colormap_lut,fqv[60],fqv[162],fqv[177]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1424colormap_pixel,fqv[154],fqv[162],fqv[178]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1426colormap_size,fqv[120],fqv[162],fqv[179]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1428colormap_planes,fqv[180],fqv[162],fqv[181]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1430colormap_plane_bits,fqv[63],fqv[162],fqv[182]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1435colormap_plane_shifts,fqv[183],fqv[162],fqv[184]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1440colormap_free,fqv[71],fqv[162],fqv[185]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1453colormap_allocate_private_colors,fqv[70],fqv[162],fqv[186]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1470colormap_allocate_colors,fqv[73],fqv[162],fqv[187]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1492colormap_define_lut,fqv[76],fqv[162],fqv[188]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1502colormap_define_gray_scale_lut,fqv[189],fqv[162],fqv[190]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1509colormap_define_rgb_lut,fqv[191],fqv[162],fqv[192]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1524colormap_define_hls_lut,fqv[193],fqv[162],fqv[194]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1531colormap_define_rainbow_lut,fqv[195],fqv[162],fqv[196]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1543colormap_install,fqv[197],fqv[162],fqv[198]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1545colormap_uninstall,fqv[199],fqv[162],fqv[200]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1547colormap_init,fqv[43],fqv[162],fqv[201]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1551colormap_create,fqv[202],fqv[162],fqv[203]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1557colormap_get_pixel,fqv[204],fqv[162],fqv[205]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcolorM1561colormap_copy_colors,fqv[206],fqv[162],fqv[207]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[208],module,XcolorF1290get_lighter_pixel,fqv[209]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[210],module,XcolorF1291get_redish_pixel,fqv[211]);
	local[0]= fqv[212];
	ctx->vsp=local+1;
	w=(*ftab[24])(ctx,1,local+0,&ftab[24],fqv[213]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<25; i++) ftab[i]=fcallx;
}

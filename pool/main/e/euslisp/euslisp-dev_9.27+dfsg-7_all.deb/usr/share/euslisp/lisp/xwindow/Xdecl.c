/* ./Xdecl.c :  entry=Xdecl */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "Xdecl.h"
#pragma init (register_Xdecl)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___Xdecl();
extern pointer build_quote_vector();
static int register_Xdecl()
  { add_module_initializer("___Xdecl", ___Xdecl);}

static pointer XdeclF1c_long_long65();
static pointer XdeclF2set_c_long_long65();
static pointer XdeclF3c_long();
static pointer XdeclF4set_c_long();
static pointer XdeclF5c_int_integer66();
static pointer XdeclF6set_c_int_integer66();
static pointer XdeclF7c_int();
static pointer XdeclF8set_c_int();

/*c-long-long69*/
static pointer XdeclF9(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[1];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)8L)); i=intval(local[2]);
		local[2]=(makeint(i * j));}
	w = local[2];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[1]= (pointer)((eusinteger_t)local[1] + (eusinteger_t)w);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XdeclBLK10:
	ctx->vsp=local; return(local[0]);}

/*set-c-long-long69*/
static pointer XdeclF11(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[1];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)8L)); i=intval(local[3]);
		local[3]=(makeint(i * j));}
	w = local[3];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[2]= (pointer)((eusinteger_t)local[2] + (eusinteger_t)w);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XdeclBLK12:
	ctx->vsp=local; return(local[0]);}

/*c-long*/
static pointer XdeclF3c_long(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto XdeclENT15;}
	local[0]= makeint((eusinteger_t)0L);
XdeclENT15:
XdeclENT14:
	if (n>2) maerror();
	local[1]= argv[0];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)XdeclF9(ctx,2,local+1); /*c-long-long69*/
	local[0]= w;
XdeclBLK13:
	ctx->vsp=local; return(local[0]);}

/*set-c-long*/
static pointer XdeclF4set_c_long(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XdeclENT18;}
	local[0]= NIL;
XdeclENT18:
XdeclENT17:
	if (n>3) maerror();
	if (local[0]==NIL) goto XdeclIF19;
	local[1]= argv[0];
	local[2]= argv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XdeclF11(ctx,3,local+1); /*set-c-long-long69*/
	local[1]= w;
	goto XdeclIF20;
XdeclIF19:
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)XdeclF11(ctx,3,local+1); /*set-c-long-long69*/
	local[1]= w;
XdeclIF20:
	w = local[1];
	local[0]= w;
XdeclBLK16:
	ctx->vsp=local; return(local[0]);}

/*c-int-integer70*/
static pointer XdeclF21(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[1];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)4L)); i=intval(local[2]);
		local[2]=(makeint(i * j));}
	w = local[2];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[1]= (pointer)((eusinteger_t)local[1] + (eusinteger_t)w);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XdeclBLK22:
	ctx->vsp=local; return(local[0]);}

/*set-c-int-integer70*/
static pointer XdeclF23(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[1];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)4L)); i=intval(local[3]);
		local[3]=(makeint(i * j));}
	w = local[3];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[2]= (pointer)((eusinteger_t)local[2] + (eusinteger_t)w);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XdeclBLK24:
	ctx->vsp=local; return(local[0]);}

/*c-int*/
static pointer XdeclF7c_int(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto XdeclENT27;}
	local[0]= makeint((eusinteger_t)0L);
XdeclENT27:
XdeclENT26:
	if (n>2) maerror();
	local[1]= argv[0];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)XdeclF21(ctx,2,local+1); /*c-int-integer70*/
	local[0]= w;
XdeclBLK25:
	ctx->vsp=local; return(local[0]);}

/*set-c-int*/
static pointer XdeclF8set_c_int(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XdeclENT30;}
	local[0]= NIL;
XdeclENT30:
XdeclENT29:
	if (n>3) maerror();
	if (local[0]==NIL) goto XdeclIF31;
	local[1]= argv[0];
	local[2]= argv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XdeclF23(ctx,3,local+1); /*set-c-int-integer70*/
	local[1]= w;
	goto XdeclIF32;
XdeclIF31:
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)XdeclF23(ctx,3,local+1); /*set-c-int-integer70*/
	local[1]= w;
XdeclIF32:
	w = local[1];
	local[0]= w;
XdeclBLK28:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___Xdecl(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[2];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto XdeclIF33;
	local[0]= fqv[3];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[4],w);
	goto XdeclIF34;
XdeclIF33:
	local[0]= fqv[5];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
XdeclIF34:
	local[0]= fqv[6];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[7];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[8];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[9];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[10];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[11];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[12];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[13];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[14];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[15];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF35;
	local[0]= fqv[15];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[15];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF37;
	local[0]= fqv[15];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF38;
XdeclIF37:
	local[0]= NIL;
XdeclIF38:
	local[0]= fqv[15];
	goto XdeclIF36;
XdeclIF35:
	local[0]= NIL;
XdeclIF36:
	local[0]= fqv[18];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF39;
	local[0]= fqv[18];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[18];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF41;
	local[0]= fqv[18];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF42;
XdeclIF41:
	local[0]= NIL;
XdeclIF42:
	local[0]= fqv[18];
	goto XdeclIF40;
XdeclIF39:
	local[0]= NIL;
XdeclIF40:
	local[0]= fqv[19];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF43;
	local[0]= fqv[19];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[19];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF45;
	local[0]= fqv[19];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF46;
XdeclIF45:
	local[0]= NIL;
XdeclIF46:
	local[0]= fqv[19];
	goto XdeclIF44;
XdeclIF43:
	local[0]= NIL;
XdeclIF44:
	local[0]= fqv[20];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF47;
	local[0]= fqv[20];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[20];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF49;
	local[0]= fqv[20];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF50;
XdeclIF49:
	local[0]= NIL;
XdeclIF50:
	local[0]= fqv[20];
	goto XdeclIF48;
XdeclIF47:
	local[0]= NIL;
XdeclIF48:
	local[0]= fqv[21];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF51;
	local[0]= fqv[21];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[21];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF53;
	local[0]= fqv[21];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF54;
XdeclIF53:
	local[0]= NIL;
XdeclIF54:
	local[0]= fqv[21];
	goto XdeclIF52;
XdeclIF51:
	local[0]= NIL;
XdeclIF52:
	local[0]= fqv[22];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF55;
	local[0]= fqv[22];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[22];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF57;
	local[0]= fqv[22];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF58;
XdeclIF57:
	local[0]= NIL;
XdeclIF58:
	local[0]= fqv[22];
	goto XdeclIF56;
XdeclIF55:
	local[0]= NIL;
XdeclIF56:
	local[0]= fqv[23];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF59;
	local[0]= fqv[23];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[23];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF61;
	local[0]= fqv[23];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF62;
XdeclIF61:
	local[0]= NIL;
XdeclIF62:
	local[0]= fqv[23];
	goto XdeclIF60;
XdeclIF59:
	local[0]= NIL;
XdeclIF60:
	local[0]= fqv[24];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF63;
	local[0]= fqv[24];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[24];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF65;
	local[0]= fqv[24];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF66;
XdeclIF65:
	local[0]= NIL;
XdeclIF66:
	local[0]= fqv[24];
	goto XdeclIF64;
XdeclIF63:
	local[0]= NIL;
XdeclIF64:
	local[0]= fqv[25];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF67;
	local[0]= fqv[25];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[25];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF69;
	local[0]= fqv[25];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF70;
XdeclIF69:
	local[0]= NIL;
XdeclIF70:
	local[0]= fqv[25];
	goto XdeclIF68;
XdeclIF67:
	local[0]= NIL;
XdeclIF68:
	local[0]= fqv[26];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF71;
	local[0]= fqv[26];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[26];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF73;
	local[0]= fqv[26];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF74;
XdeclIF73:
	local[0]= NIL;
XdeclIF74:
	local[0]= fqv[26];
	goto XdeclIF72;
XdeclIF71:
	local[0]= NIL;
XdeclIF72:
	local[0]= fqv[27];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF75;
	local[0]= fqv[27];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[27];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF77;
	local[0]= fqv[27];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF78;
XdeclIF77:
	local[0]= NIL;
XdeclIF78:
	local[0]= fqv[27];
	goto XdeclIF76;
XdeclIF75:
	local[0]= NIL;
XdeclIF76:
	local[0]= fqv[28];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF79;
	local[0]= fqv[28];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[28];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF81;
	local[0]= fqv[28];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF82;
XdeclIF81:
	local[0]= NIL;
XdeclIF82:
	local[0]= fqv[28];
	goto XdeclIF80;
XdeclIF79:
	local[0]= NIL;
XdeclIF80:
	local[0]= fqv[29];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF83;
	local[0]= fqv[29];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[29];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF85;
	local[0]= fqv[29];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF86;
XdeclIF85:
	local[0]= NIL;
XdeclIF86:
	local[0]= fqv[29];
	goto XdeclIF84;
XdeclIF83:
	local[0]= NIL;
XdeclIF84:
	local[0]= fqv[30];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF87;
	local[0]= fqv[30];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[30];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF89;
	local[0]= fqv[30];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF90;
XdeclIF89:
	local[0]= NIL;
XdeclIF90:
	local[0]= fqv[30];
	goto XdeclIF88;
XdeclIF87:
	local[0]= NIL;
XdeclIF88:
	local[0]= fqv[31];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF91;
	local[0]= fqv[31];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[31];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF93;
	local[0]= fqv[31];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF94;
XdeclIF93:
	local[0]= NIL;
XdeclIF94:
	local[0]= fqv[31];
	goto XdeclIF92;
XdeclIF91:
	local[0]= NIL;
XdeclIF92:
	local[0]= fqv[32];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF95;
	local[0]= fqv[32];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[32];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF97;
	local[0]= fqv[32];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF98;
XdeclIF97:
	local[0]= NIL;
XdeclIF98:
	local[0]= fqv[32];
	goto XdeclIF96;
XdeclIF95:
	local[0]= NIL;
XdeclIF96:
	local[0]= fqv[33];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF99;
	local[0]= fqv[33];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[33];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF101;
	local[0]= fqv[33];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF102;
XdeclIF101:
	local[0]= NIL;
XdeclIF102:
	local[0]= fqv[33];
	goto XdeclIF100;
XdeclIF99:
	local[0]= NIL;
XdeclIF100:
	local[0]= fqv[34];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF103;
	local[0]= fqv[34];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[34];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF105;
	local[0]= fqv[34];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF106;
XdeclIF105:
	local[0]= NIL;
XdeclIF106:
	local[0]= fqv[34];
	goto XdeclIF104;
XdeclIF103:
	local[0]= NIL;
XdeclIF104:
	local[0]= fqv[35];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF107;
	local[0]= fqv[35];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[35];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF109;
	local[0]= fqv[35];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF110;
XdeclIF109:
	local[0]= NIL;
XdeclIF110:
	local[0]= fqv[35];
	goto XdeclIF108;
XdeclIF107:
	local[0]= NIL;
XdeclIF108:
	local[0]= fqv[36];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF111;
	local[0]= fqv[36];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[36];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF113;
	local[0]= fqv[36];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF114;
XdeclIF113:
	local[0]= NIL;
XdeclIF114:
	local[0]= fqv[36];
	goto XdeclIF112;
XdeclIF111:
	local[0]= NIL;
XdeclIF112:
	local[0]= fqv[37];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF115;
	local[0]= fqv[37];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[37];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF117;
	local[0]= fqv[37];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF118;
XdeclIF117:
	local[0]= NIL;
XdeclIF118:
	local[0]= fqv[37];
	goto XdeclIF116;
XdeclIF115:
	local[0]= NIL;
XdeclIF116:
	local[0]= fqv[38];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF119;
	local[0]= fqv[38];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[38];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF121;
	local[0]= fqv[38];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF122;
XdeclIF121:
	local[0]= NIL;
XdeclIF122:
	local[0]= fqv[38];
	goto XdeclIF120;
XdeclIF119:
	local[0]= NIL;
XdeclIF120:
	local[0]= fqv[39];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF123;
	local[0]= fqv[39];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[39];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF125;
	local[0]= fqv[39];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF126;
XdeclIF125:
	local[0]= NIL;
XdeclIF126:
	local[0]= fqv[39];
	goto XdeclIF124;
XdeclIF123:
	local[0]= NIL;
XdeclIF124:
	local[0]= fqv[40];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF127;
	local[0]= fqv[40];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[40];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF129;
	local[0]= fqv[40];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF130;
XdeclIF129:
	local[0]= NIL;
XdeclIF130:
	local[0]= fqv[40];
	goto XdeclIF128;
XdeclIF127:
	local[0]= NIL;
XdeclIF128:
	local[0]= fqv[41];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF131;
	local[0]= fqv[41];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[41];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF133;
	local[0]= fqv[41];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF134;
XdeclIF133:
	local[0]= NIL;
XdeclIF134:
	local[0]= fqv[41];
	goto XdeclIF132;
XdeclIF131:
	local[0]= NIL;
XdeclIF132:
	local[0]= fqv[42];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF135;
	local[0]= fqv[42];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[42];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF137;
	local[0]= fqv[42];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF138;
XdeclIF137:
	local[0]= NIL;
XdeclIF138:
	local[0]= fqv[42];
	goto XdeclIF136;
XdeclIF135:
	local[0]= NIL;
XdeclIF136:
	local[0]= fqv[43];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF139;
	local[0]= fqv[43];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[43];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF141;
	local[0]= fqv[43];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF142;
XdeclIF141:
	local[0]= NIL;
XdeclIF142:
	local[0]= fqv[43];
	goto XdeclIF140;
XdeclIF139:
	local[0]= NIL;
XdeclIF140:
	local[0]= fqv[44];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF143;
	local[0]= fqv[44];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[44];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF145;
	local[0]= fqv[44];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF146;
XdeclIF145:
	local[0]= NIL;
XdeclIF146:
	local[0]= fqv[44];
	goto XdeclIF144;
XdeclIF143:
	local[0]= NIL;
XdeclIF144:
	local[0]= fqv[45];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[46];
	local[1]= fqv[17];
	local[2]= fqv[47];
	local[3]= makeint((eusinteger_t)20L);
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,2,local+2,&ftab[0],fqv[48]); /*make-hash-table*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[49];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[50];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF147;
	local[0]= fqv[50];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[50];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF149;
	local[0]= fqv[50];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF150;
XdeclIF149:
	local[0]= NIL;
XdeclIF150:
	local[0]= fqv[50];
	goto XdeclIF148;
XdeclIF147:
	local[0]= NIL;
XdeclIF148:
	local[0]= fqv[51];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF151;
	local[0]= fqv[51];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[51];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF153;
	local[0]= fqv[51];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF154;
XdeclIF153:
	local[0]= NIL;
XdeclIF154:
	local[0]= fqv[51];
	goto XdeclIF152;
XdeclIF151:
	local[0]= NIL;
XdeclIF152:
	local[0]= fqv[52];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF155;
	local[0]= fqv[52];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[52];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF157;
	local[0]= fqv[52];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF158;
XdeclIF157:
	local[0]= NIL;
XdeclIF158:
	local[0]= fqv[52];
	goto XdeclIF156;
XdeclIF155:
	local[0]= NIL;
XdeclIF156:
	local[0]= fqv[53];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF159;
	local[0]= fqv[53];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[53];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF161;
	local[0]= fqv[53];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF162;
XdeclIF161:
	local[0]= NIL;
XdeclIF162:
	local[0]= fqv[53];
	goto XdeclIF160;
XdeclIF159:
	local[0]= NIL;
XdeclIF160:
	local[0]= fqv[54];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF163;
	local[0]= fqv[54];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[54];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF165;
	local[0]= fqv[54];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF166;
XdeclIF165:
	local[0]= NIL;
XdeclIF166:
	local[0]= fqv[54];
	goto XdeclIF164;
XdeclIF163:
	local[0]= NIL;
XdeclIF164:
	local[0]= fqv[55];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF167;
	local[0]= fqv[55];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[55];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF169;
	local[0]= fqv[55];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF170;
XdeclIF169:
	local[0]= NIL;
XdeclIF170:
	local[0]= fqv[55];
	goto XdeclIF168;
XdeclIF167:
	local[0]= NIL;
XdeclIF168:
	local[0]= fqv[56];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF171;
	local[0]= fqv[56];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[56];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF173;
	local[0]= fqv[56];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF174;
XdeclIF173:
	local[0]= NIL;
XdeclIF174:
	local[0]= fqv[56];
	goto XdeclIF172;
XdeclIF171:
	local[0]= NIL;
XdeclIF172:
	local[0]= fqv[57];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF175;
	local[0]= fqv[57];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[57];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF177;
	local[0]= fqv[57];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF178;
XdeclIF177:
	local[0]= NIL;
XdeclIF178:
	local[0]= fqv[57];
	goto XdeclIF176;
XdeclIF175:
	local[0]= NIL;
XdeclIF176:
	local[0]= fqv[58];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF179;
	local[0]= fqv[58];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[58];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF181;
	local[0]= fqv[58];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF182;
XdeclIF181:
	local[0]= NIL;
XdeclIF182:
	local[0]= fqv[58];
	goto XdeclIF180;
XdeclIF179:
	local[0]= NIL;
XdeclIF180:
	local[0]= fqv[59];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF183;
	local[0]= fqv[59];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[59];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF185;
	local[0]= fqv[59];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF186;
XdeclIF185:
	local[0]= NIL;
XdeclIF186:
	local[0]= fqv[59];
	goto XdeclIF184;
XdeclIF183:
	local[0]= NIL;
XdeclIF184:
	local[0]= fqv[60];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF187;
	local[0]= fqv[60];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[60];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF189;
	local[0]= fqv[60];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF190;
XdeclIF189:
	local[0]= NIL;
XdeclIF190:
	local[0]= fqv[60];
	goto XdeclIF188;
XdeclIF187:
	local[0]= NIL;
XdeclIF188:
	local[0]= fqv[61];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF191;
	local[0]= fqv[61];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[61];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF193;
	local[0]= fqv[61];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF194;
XdeclIF193:
	local[0]= NIL;
XdeclIF194:
	local[0]= fqv[61];
	goto XdeclIF192;
XdeclIF191:
	local[0]= NIL;
XdeclIF192:
	local[0]= fqv[62];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF195;
	local[0]= fqv[62];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[62];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF197;
	local[0]= fqv[62];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF198;
XdeclIF197:
	local[0]= NIL;
XdeclIF198:
	local[0]= fqv[62];
	goto XdeclIF196;
XdeclIF195:
	local[0]= NIL;
XdeclIF196:
	local[0]= fqv[63];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF199;
	local[0]= fqv[63];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[63];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF201;
	local[0]= fqv[63];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF202;
XdeclIF201:
	local[0]= NIL;
XdeclIF202:
	local[0]= fqv[63];
	goto XdeclIF200;
XdeclIF199:
	local[0]= NIL;
XdeclIF200:
	local[0]= fqv[64];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF203;
	local[0]= fqv[64];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[64];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF205;
	local[0]= fqv[64];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF206;
XdeclIF205:
	local[0]= NIL;
XdeclIF206:
	local[0]= fqv[64];
	goto XdeclIF204;
XdeclIF203:
	local[0]= NIL;
XdeclIF204:
	local[0]= fqv[65];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF207;
	local[0]= fqv[65];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[65];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF209;
	local[0]= fqv[65];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF210;
XdeclIF209:
	local[0]= NIL;
XdeclIF210:
	local[0]= fqv[65];
	goto XdeclIF208;
XdeclIF207:
	local[0]= NIL;
XdeclIF208:
	local[0]= fqv[66];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF211;
	local[0]= fqv[66];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[66];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF213;
	local[0]= fqv[66];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF214;
XdeclIF213:
	local[0]= NIL;
XdeclIF214:
	local[0]= fqv[66];
	goto XdeclIF212;
XdeclIF211:
	local[0]= NIL;
XdeclIF212:
	local[0]= fqv[67];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF215;
	local[0]= fqv[67];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[67];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF217;
	local[0]= fqv[67];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF218;
XdeclIF217:
	local[0]= NIL;
XdeclIF218:
	local[0]= fqv[67];
	goto XdeclIF216;
XdeclIF215:
	local[0]= NIL;
XdeclIF216:
	local[0]= fqv[68];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF219;
	local[0]= fqv[68];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[68];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF221;
	local[0]= fqv[68];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF222;
XdeclIF221:
	local[0]= NIL;
XdeclIF222:
	local[0]= fqv[68];
	goto XdeclIF220;
XdeclIF219:
	local[0]= NIL;
XdeclIF220:
	local[0]= fqv[69];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF223;
	local[0]= fqv[69];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[69];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF225;
	local[0]= fqv[69];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF226;
XdeclIF225:
	local[0]= NIL;
XdeclIF226:
	local[0]= fqv[69];
	goto XdeclIF224;
XdeclIF223:
	local[0]= NIL;
XdeclIF224:
	local[0]= fqv[70];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF227;
	local[0]= fqv[70];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[70];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF229;
	local[0]= fqv[70];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF230;
XdeclIF229:
	local[0]= NIL;
XdeclIF230:
	local[0]= fqv[70];
	goto XdeclIF228;
XdeclIF227:
	local[0]= NIL;
XdeclIF228:
	local[0]= fqv[71];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF231;
	local[0]= fqv[71];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[71];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF233;
	local[0]= fqv[71];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF234;
XdeclIF233:
	local[0]= NIL;
XdeclIF234:
	local[0]= fqv[71];
	goto XdeclIF232;
XdeclIF231:
	local[0]= NIL;
XdeclIF232:
	local[0]= fqv[72];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF235;
	local[0]= fqv[72];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[72];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF237;
	local[0]= fqv[72];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF238;
XdeclIF237:
	local[0]= NIL;
XdeclIF238:
	local[0]= fqv[72];
	goto XdeclIF236;
XdeclIF235:
	local[0]= NIL;
XdeclIF236:
	local[0]= fqv[73];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF239;
	local[0]= fqv[73];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[73];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF241;
	local[0]= fqv[73];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF242;
XdeclIF241:
	local[0]= NIL;
XdeclIF242:
	local[0]= fqv[73];
	goto XdeclIF240;
XdeclIF239:
	local[0]= NIL;
XdeclIF240:
	local[0]= fqv[74];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF243;
	local[0]= fqv[74];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[74];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF245;
	local[0]= fqv[74];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF246;
XdeclIF245:
	local[0]= NIL;
XdeclIF246:
	local[0]= fqv[74];
	goto XdeclIF244;
XdeclIF243:
	local[0]= NIL;
XdeclIF244:
	local[0]= fqv[33];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XdeclIF247;
	local[0]= fqv[33];
	local[1]= fqv[16];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[33];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XdeclIF249;
	local[0]= fqv[33];
	local[1]= fqv[17];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XdeclIF250;
XdeclIF249:
	local[0]= NIL;
XdeclIF250:
	local[0]= fqv[33];
	goto XdeclIF248;
XdeclIF247:
	local[0]= NIL;
XdeclIF248:
	local[0]= fqv[75];
	local[1]= fqv[17];
	local[2]= fqv[75];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[77]);
	local[5]= fqv[78];
	local[6]= fqv[79];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[84];
	local[1]= fqv[17];
	local[2]= fqv[84];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[85]);
	local[5]= fqv[78];
	local[6]= fqv[86];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[87];
	local[1]= fqv[17];
	local[2]= fqv[87];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[75]);
	local[5]= fqv[78];
	local[6]= fqv[88];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[89];
	local[1]= fqv[17];
	local[2]= fqv[89];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[75]);
	local[5]= fqv[78];
	local[6]= fqv[90];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[91];
	local[1]= fqv[17];
	local[2]= fqv[91];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[89]);
	local[5]= fqv[78];
	local[6]= fqv[92];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[93];
	local[1]= fqv[17];
	local[2]= fqv[93];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[89]);
	local[5]= fqv[78];
	local[6]= fqv[94];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[95];
	local[1]= fqv[17];
	local[2]= fqv[95];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[93]);
	local[5]= fqv[78];
	local[6]= fqv[96];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[97];
	local[1]= fqv[17];
	local[2]= fqv[97];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[93]);
	local[5]= fqv[78];
	local[6]= fqv[98];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[99];
	local[1]= fqv[17];
	local[2]= fqv[99];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[93]);
	local[5]= fqv[78];
	local[6]= fqv[100];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[101];
	local[1]= fqv[17];
	local[2]= fqv[101];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[99]);
	local[5]= fqv[78];
	local[6]= fqv[102];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[103];
	local[1]= fqv[17];
	local[2]= fqv[103];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[99]);
	local[5]= fqv[78];
	local[6]= fqv[104];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[105];
	local[1]= fqv[17];
	local[2]= fqv[105];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[99]);
	local[5]= fqv[78];
	local[6]= fqv[106];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[107];
	local[1]= fqv[17];
	local[2]= fqv[107];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[101]);
	local[5]= fqv[78];
	local[6]= fqv[108];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[109];
	local[1]= fqv[17];
	local[2]= fqv[109];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[99]);
	local[5]= fqv[78];
	local[6]= fqv[110];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[111];
	local[1]= fqv[17];
	local[2]= fqv[111];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[99]);
	local[5]= fqv[78];
	local[6]= fqv[112];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[113];
	local[1]= fqv[17];
	local[2]= fqv[113];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[95]);
	local[5]= fqv[78];
	local[6]= fqv[114];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[115];
	local[1]= fqv[17];
	local[2]= fqv[115];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[93]);
	local[5]= fqv[78];
	local[6]= fqv[116];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[117];
	local[1]= fqv[17];
	local[2]= fqv[117];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[115]);
	local[5]= fqv[78];
	local[6]= fqv[92];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[118];
	local[1]= fqv[17];
	local[2]= fqv[118];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[93]);
	local[5]= fqv[78];
	local[6]= fqv[119];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[120];
	local[1]= fqv[17];
	local[2]= fqv[120];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[118]);
	local[5]= fqv[78];
	local[6]= fqv[121];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[122];
	local[1]= fqv[17];
	local[2]= fqv[122];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[120]);
	local[5]= fqv[78];
	local[6]= fqv[123];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[124];
	local[1]= fqv[17];
	local[2]= fqv[124];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[122]);
	local[5]= fqv[78];
	local[6]= fqv[125];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[126];
	local[1]= fqv[17];
	local[2]= fqv[126];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[127]);
	local[5]= fqv[78];
	local[6]= fqv[128];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[129];
	local[1]= fqv[17];
	local[2]= fqv[129];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[95]);
	local[5]= fqv[78];
	local[6]= fqv[92];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[130];
	local[1]= fqv[17];
	local[2]= fqv[130];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[101]);
	local[5]= fqv[78];
	local[6]= fqv[131];
	local[7]= fqv[80];
	local[8]= NIL;
	local[9]= fqv[81];
	local[10]= NIL;
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[132];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[134];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)1L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[135];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)2L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[136];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)4L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[137];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)8L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[138];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)16L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[139];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)32L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[140];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)64L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[141];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)128L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[142];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)256L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[143];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)512L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[144];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)1024L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[145];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)2048L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[146];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)4096L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[147];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)8192L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[148];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)16384L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[149];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)32768L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[150];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)65536L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[151];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)131072L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[152];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)262144L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[153];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)524288L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[154];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)1048576L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[155];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)2097152L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[156];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)4194304L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[157];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)8388608L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[158];
	local[1]= fqv[133];
	local[2]= makeint((eusinteger_t)16777216L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[159];
	local[1]= fqv[17];
	local[2]= fqv[159];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[160]);
	local[5]= fqv[78];
	local[6]= fqv[92];
	local[7]= fqv[80];
	local[8]= loadglobal(fqv[161]);
	local[9]= fqv[81];
	local[10]= fqv[162];
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= loadglobal(fqv[159]);
	local[1]= fqv[163];
	local[2]= fqv[164];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[165],module,XdeclF9,fqv[166]);
	local[0]= fqv[165];
	local[1]= fqv[167];
	local[2]= fqv[168];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[165];
	local[1]= fqv[169];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[170]); /*remprop*/
	local[0]= fqv[165];
	local[1]= fqv[171];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[170]); /*remprop*/
	local[0]= fqv[165];
	local[1]= NIL;
	local[2]= fqv[172];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[167],module,XdeclF11,fqv[173]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[159],module,XdeclF3c_long,fqv[174]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[175],module,XdeclF4set_c_long,fqv[176]);
	local[0]= fqv[159];
	local[1]= fqv[175];
	local[2]= fqv[168];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[159];
	local[1]= fqv[169];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[170]); /*remprop*/
	local[0]= fqv[159];
	local[1]= fqv[171];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[170]); /*remprop*/
	local[0]= fqv[159];
	local[1]= NIL;
	local[2]= fqv[172];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[177];
	local[1]= fqv[17];
	local[2]= fqv[177];
	local[3]= fqv[76];
	local[4]= loadglobal(fqv[160]);
	local[5]= fqv[78];
	local[6]= fqv[92];
	local[7]= fqv[80];
	local[8]= loadglobal(fqv[161]);
	local[9]= fqv[81];
	local[10]= fqv[162];
	local[11]= fqv[47];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[82];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,13,local+2,&ftab[1],fqv[83]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= loadglobal(fqv[177]);
	local[1]= fqv[163];
	local[2]= fqv[178];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[179],module,XdeclF21,fqv[180]);
	local[0]= fqv[179];
	local[1]= fqv[181];
	local[2]= fqv[168];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[179];
	local[1]= fqv[169];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[170]); /*remprop*/
	local[0]= fqv[179];
	local[1]= fqv[171];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[170]); /*remprop*/
	local[0]= fqv[179];
	local[1]= NIL;
	local[2]= fqv[172];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[181],module,XdeclF23,fqv[182]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[177],module,XdeclF7c_int,fqv[183]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[184],module,XdeclF8set_c_int,fqv[185]);
	local[0]= fqv[177];
	local[1]= fqv[184];
	local[2]= fqv[168];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[177];
	local[1]= fqv[169];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[170]); /*remprop*/
	local[0]= fqv[177];
	local[1]= fqv[171];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[170]); /*remprop*/
	local[0]= fqv[177];
	local[1]= NIL;
	local[2]= fqv[172];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[186];
	local[1]= fqv[187];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[188]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<4; i++) ftab[i]=fcallx;
}

/* ./Xeus.c :  entry=Xeus */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "Xeus.h"
#pragma init (register_Xeus)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___Xeus();
extern pointer build_quote_vector();
static int register_Xeus()
  { add_module_initializer("___Xeus", ___Xeus);}

static pointer XeusF251setwindowattributes_pixmap();
static pointer XeusF252set_setwindowattributes_pixmap();
static pointer XeusF253setwindowattributes_background_pixel();
static pointer XeusF254set_setwindowattributes_background_pixel();
static pointer XeusF255setwindowattributes_border_pixmap();
static pointer XeusF256set_setwindowattributes_border_pixmap();
static pointer XeusF257setwindowattributes_border_pixel();
static pointer XeusF258set_setwindowattributes_border_pixel();
static pointer XeusF259setwindowattributes_bit_gravity();
static pointer XeusF260set_setwindowattributes_bit_gravity();
static pointer XeusF261setwindowattributes_win_gravity();
static pointer XeusF262set_setwindowattributes_win_gravity();
static pointer XeusF263setwindowattributes_backing_store();
static pointer XeusF264set_setwindowattributes_backing_store();
static pointer XeusF265setwindowattributes_backing_planes();
static pointer XeusF266set_setwindowattributes_backing_planes();
static pointer XeusF267setwindowattributes_backing_pixel();
static pointer XeusF268set_setwindowattributes_backing_pixel();
static pointer XeusF269setwindowattributes_save_under();
static pointer XeusF270set_setwindowattributes_save_under();
static pointer XeusF271setwindowattributes_event_mask();
static pointer XeusF272set_setwindowattributes_event_mask();
static pointer XeusF273setwindowattributes_do_not_propagate_mask();
static pointer XeusF274set_setwindowattributes_do_not_propagate_mask();
static pointer XeusF275setwindowattributes_override_redirect();
static pointer XeusF276set_setwindowattributes_override_redirect();
static pointer XeusF277setwindowattributes_colormap();
static pointer XeusF278set_setwindowattributes_colormap();
static pointer XeusF279setwindowattributes_cursor();
static pointer XeusF280set_setwindowattributes_cursor();
static pointer XeusF281windowattributes_x();
static pointer XeusF282set_windowattributes_x();
static pointer XeusF283windowattributes_y();
static pointer XeusF284set_windowattributes_y();
static pointer XeusF285windowattributes_width();
static pointer XeusF286set_windowattributes_width();
static pointer XeusF287windowattributes_height();
static pointer XeusF288set_windowattributes_height();
static pointer XeusF289windowattributes_border_width();
static pointer XeusF290set_windowattributes_border_width();
static pointer XeusF291windowattributes_depth();
static pointer XeusF292set_windowattributes_depth();
static pointer XeusF293windowattributes_visual();
static pointer XeusF294set_windowattributes_visual();
static pointer XeusF295windowattributes_root();
static pointer XeusF296set_windowattributes_root();
static pointer XeusF297windowattributes_class();
static pointer XeusF298set_windowattributes_class();
static pointer XeusF299windowattributes_bit_gravity();
static pointer XeusF300set_windowattributes_bit_gravity();
static pointer XeusF301windowattributes_win_gravity();
static pointer XeusF302set_windowattributes_win_gravity();
static pointer XeusF303windowattributes_backing_store();
static pointer XeusF304set_windowattributes_backing_store();
static pointer XeusF305windowattributes_backing_planes();
static pointer XeusF306set_windowattributes_backing_planes();
static pointer XeusF307windowattributes_backing_pixel();
static pointer XeusF308set_windowattributes_backing_pixel();
static pointer XeusF309windowattributes_save_under();
static pointer XeusF310set_windowattributes_save_under();
static pointer XeusF311windowattributes_colormap();
static pointer XeusF312set_windowattributes_colormap();
static pointer XeusF313windowattributes_map_installed();
static pointer XeusF314set_windowattributes_map_installed();
static pointer XeusF315windowattributes_map_state();
static pointer XeusF316set_windowattributes_map_state();
static pointer XeusF317windowattributes_all_event_masks();
static pointer XeusF318set_windowattributes_all_event_masks();
static pointer XeusF319windowattributes_your_event_mask();
static pointer XeusF320set_windowattributes_your_event_mask();
static pointer XeusF321windowattributes_do_not_propagate_mask();
static pointer XeusF322set_windowattributes_do_not_propagate_mask();
static pointer XeusF323windowattributes_override_redirect();
static pointer XeusF324set_windowattributes_override_redirect();
static pointer XeusF325windowattributes_screen();
static pointer XeusF326set_windowattributes_screen();
static pointer XeusF327make_pixmaps();
static pointer XeusF328make_gray_pixmap();
static pointer XeusF329make_gray_gc();
static pointer XeusF330make_cleared_pixmap();
static pointer XeusF331eventmask_to_value();
static pointer XeusF332gravity_to_value();
static pointer XeusF333geometry__default_viewsurface();
static pointer XeusF334make_xwindow();
static pointer XeusF335find_xwindow();

/*setwindowattributes-pixmap*/
static pointer XeusF251setwindowattributes_pixmap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK336:
	ctx->vsp=local; return(local[0]);}

/*set-setwindowattributes-pixmap*/
static pointer XeusF252set_setwindowattributes_pixmap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK337:
	ctx->vsp=local; return(local[0]);}

/*setwindowattributes-background_pixel*/
static pointer XeusF253setwindowattributes_background_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)8L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK338:
	ctx->vsp=local; return(local[0]);}

/*set-setwindowattributes-background_pixel*/
static pointer XeusF254set_setwindowattributes_background_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)8L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK339:
	ctx->vsp=local; return(local[0]);}

/*setwindowattributes-border_pixmap*/
static pointer XeusF255setwindowattributes_border_pixmap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)16L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK340:
	ctx->vsp=local; return(local[0]);}

/*set-setwindowattributes-border_pixmap*/
static pointer XeusF256set_setwindowattributes_border_pixmap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)16L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK341:
	ctx->vsp=local; return(local[0]);}

/*setwindowattributes-border_pixel*/
static pointer XeusF257setwindowattributes_border_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)24L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK342:
	ctx->vsp=local; return(local[0]);}

/*set-setwindowattributes-border_pixel*/
static pointer XeusF258set_setwindowattributes_border_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)24L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK343:
	ctx->vsp=local; return(local[0]);}

/*setwindowattributes-bit_gravity*/
static pointer XeusF259setwindowattributes_bit_gravity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)32L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK344:
	ctx->vsp=local; return(local[0]);}

/*set-setwindowattributes-bit_gravity*/
static pointer XeusF260set_setwindowattributes_bit_gravity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)32L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK345:
	ctx->vsp=local; return(local[0]);}

/*setwindowattributes-win_gravity*/
static pointer XeusF261setwindowattributes_win_gravity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)36L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK346:
	ctx->vsp=local; return(local[0]);}

/*set-setwindowattributes-win_gravity*/
static pointer XeusF262set_setwindowattributes_win_gravity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)36L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK347:
	ctx->vsp=local; return(local[0]);}

/*setwindowattributes-backing_store*/
static pointer XeusF263setwindowattributes_backing_store(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)40L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK348:
	ctx->vsp=local; return(local[0]);}

/*set-setwindowattributes-backing_store*/
static pointer XeusF264set_setwindowattributes_backing_store(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)40L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK349:
	ctx->vsp=local; return(local[0]);}

/*setwindowattributes-backing_planes*/
static pointer XeusF265setwindowattributes_backing_planes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)48L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK350:
	ctx->vsp=local; return(local[0]);}

/*set-setwindowattributes-backing_planes*/
static pointer XeusF266set_setwindowattributes_backing_planes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)48L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK351:
	ctx->vsp=local; return(local[0]);}

/*setwindowattributes-backing_pixel*/
static pointer XeusF267setwindowattributes_backing_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)56L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK352:
	ctx->vsp=local; return(local[0]);}

/*set-setwindowattributes-backing_pixel*/
static pointer XeusF268set_setwindowattributes_backing_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)56L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK353:
	ctx->vsp=local; return(local[0]);}

/*setwindowattributes-save_under*/
static pointer XeusF269setwindowattributes_save_under(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)64L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK354:
	ctx->vsp=local; return(local[0]);}

/*set-setwindowattributes-save_under*/
static pointer XeusF270set_setwindowattributes_save_under(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)64L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK355:
	ctx->vsp=local; return(local[0]);}

/*setwindowattributes-event_mask*/
static pointer XeusF271setwindowattributes_event_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)72L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK356:
	ctx->vsp=local; return(local[0]);}

/*set-setwindowattributes-event_mask*/
static pointer XeusF272set_setwindowattributes_event_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)72L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK357:
	ctx->vsp=local; return(local[0]);}

/*setwindowattributes-do_not_propagate_mask*/
static pointer XeusF273setwindowattributes_do_not_propagate_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)80L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK358:
	ctx->vsp=local; return(local[0]);}

/*set-setwindowattributes-do_not_propagate_mask*/
static pointer XeusF274set_setwindowattributes_do_not_propagate_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)80L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK359:
	ctx->vsp=local; return(local[0]);}

/*setwindowattributes-override_redirect*/
static pointer XeusF275setwindowattributes_override_redirect(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)88L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK360:
	ctx->vsp=local; return(local[0]);}

/*set-setwindowattributes-override_redirect*/
static pointer XeusF276set_setwindowattributes_override_redirect(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)88L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK361:
	ctx->vsp=local; return(local[0]);}

/*setwindowattributes-colormap*/
static pointer XeusF277setwindowattributes_colormap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)96L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK362:
	ctx->vsp=local; return(local[0]);}

/*set-setwindowattributes-colormap*/
static pointer XeusF278set_setwindowattributes_colormap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)96L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK363:
	ctx->vsp=local; return(local[0]);}

/*setwindowattributes-cursor*/
static pointer XeusF279setwindowattributes_cursor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)104L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK364:
	ctx->vsp=local; return(local[0]);}

/*set-setwindowattributes-cursor*/
static pointer XeusF280set_setwindowattributes_cursor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)104L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK365:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-x*/
static pointer XeusF281windowattributes_x(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK366:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-x*/
static pointer XeusF282set_windowattributes_x(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK367:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-y*/
static pointer XeusF283windowattributes_y(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)4L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK368:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-y*/
static pointer XeusF284set_windowattributes_y(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)4L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK369:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-width*/
static pointer XeusF285windowattributes_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)8L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK370:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-width*/
static pointer XeusF286set_windowattributes_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)8L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK371:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-height*/
static pointer XeusF287windowattributes_height(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)12L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK372:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-height*/
static pointer XeusF288set_windowattributes_height(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)12L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK373:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-border_width*/
static pointer XeusF289windowattributes_border_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)16L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK374:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-border_width*/
static pointer XeusF290set_windowattributes_border_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)16L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK375:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-depth*/
static pointer XeusF291windowattributes_depth(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)20L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK376:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-depth*/
static pointer XeusF292set_windowattributes_depth(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)20L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK377:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-visual*/
static pointer XeusF293windowattributes_visual(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)24L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK378:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-visual*/
static pointer XeusF294set_windowattributes_visual(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)24L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK379:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-root*/
static pointer XeusF295windowattributes_root(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)32L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK380:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-root*/
static pointer XeusF296set_windowattributes_root(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)32L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK381:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-class*/
static pointer XeusF297windowattributes_class(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)40L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK382:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-class*/
static pointer XeusF298set_windowattributes_class(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)40L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK383:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-bit_gravity*/
static pointer XeusF299windowattributes_bit_gravity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)44L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK384:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-bit_gravity*/
static pointer XeusF300set_windowattributes_bit_gravity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)44L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK385:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-win_gravity*/
static pointer XeusF301windowattributes_win_gravity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)48L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK386:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-win_gravity*/
static pointer XeusF302set_windowattributes_win_gravity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)48L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK387:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-backing_store*/
static pointer XeusF303windowattributes_backing_store(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)52L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK388:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-backing_store*/
static pointer XeusF304set_windowattributes_backing_store(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)52L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK389:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-backing_planes*/
static pointer XeusF305windowattributes_backing_planes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)56L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK390:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-backing_planes*/
static pointer XeusF306set_windowattributes_backing_planes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)56L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK391:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-backing_pixel*/
static pointer XeusF307windowattributes_backing_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)64L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK392:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-backing_pixel*/
static pointer XeusF308set_windowattributes_backing_pixel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)64L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK393:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-save_under*/
static pointer XeusF309windowattributes_save_under(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)72L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK394:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-save_under*/
static pointer XeusF310set_windowattributes_save_under(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)72L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK395:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-colormap*/
static pointer XeusF311windowattributes_colormap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)80L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK396:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-colormap*/
static pointer XeusF312set_windowattributes_colormap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)80L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK397:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-map_installed*/
static pointer XeusF313windowattributes_map_installed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)88L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK398:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-map_installed*/
static pointer XeusF314set_windowattributes_map_installed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)88L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK399:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-map_state*/
static pointer XeusF315windowattributes_map_state(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)92L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK400:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-map_state*/
static pointer XeusF316set_windowattributes_map_state(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)92L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK401:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-all_event_masks*/
static pointer XeusF317windowattributes_all_event_masks(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)96L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK402:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-all_event_masks*/
static pointer XeusF318set_windowattributes_all_event_masks(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)96L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK403:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-your_event_mask*/
static pointer XeusF319windowattributes_your_event_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)104L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK404:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-your_event_mask*/
static pointer XeusF320set_windowattributes_your_event_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)104L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK405:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-do_not_propagate_mask*/
static pointer XeusF321windowattributes_do_not_propagate_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)112L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK406:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-do_not_propagate_mask*/
static pointer XeusF322set_windowattributes_do_not_propagate_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)112L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK407:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-override_redirect*/
static pointer XeusF323windowattributes_override_redirect(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)120L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK408:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-override_redirect*/
static pointer XeusF324set_windowattributes_override_redirect(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)120L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK409:
	ctx->vsp=local; return(local[0]);}

/*windowattributes-screen*/
static pointer XeusF325windowattributes_screen(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)128L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeusBLK410:
	ctx->vsp=local; return(local[0]);}

/*set-windowattributes-screen*/
static pointer XeusF326set_windowattributes_screen(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)128L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeusBLK411:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer XeusM412xdrawable_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XeusENT417;}
	local[0]= NIL;
XeusENT417:
	if (n>=5) { local[1]=(argv[4]); goto XeusENT416;}
	local[1]= NIL;
XeusENT416:
	if (n>=6) { local[2]=(argv[5]); goto XeusENT415;}
	local[2]= NIL;
XeusENT415:
XeusENT414:
	if (n>6) maerror();
	if (local[2]==NIL) goto XeusCON419;
	local[3]= local[2];
	goto XeusCON418;
XeusCON419:
	if (argv[2]==NIL) goto XeusCON420;
	local[3]= loadglobal(fqv[2]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[3];
	local[6]= fqv[4];
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = local[3];
	local[3]= w;
	goto XeusCON418;
XeusCON420:
	local[3]= loadglobal(fqv[2]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	w = local[3];
	local[3]= w;
	goto XeusCON418;
XeusCON421:
	local[3]= NIL;
XeusCON418:
	argv[0]->c.obj.iv[3] = local[3];
	argv[0]->c.obj.iv[2] = argv[2];
	if (local[0]==NIL) goto XeusIF422;
	argv[0]->c.obj.iv[5] = local[0];
	local[3]= argv[0]->c.obj.iv[5];
	goto XeusIF423;
XeusIF422:
	local[3]= NIL;
XeusIF423:
	if (local[1]==NIL) goto XeusIF424;
	argv[0]->c.obj.iv[6] = local[1];
	local[3]= argv[0]->c.obj.iv[6];
	goto XeusIF425;
XeusIF424:
	local[3]= NIL;
XeusIF425:
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= loadglobal(fqv[5]);
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[0])(ctx,3,local+3,&ftab[0],fqv[6]); /*sethash*/
	w = argv[0];
	local[0]= w;
XeusBLK413:
	ctx->vsp=local; return(local[0]);}

/*:drawable*/
static pointer XeusM426xdrawable_drawable(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
XeusBLK427:
	ctx->vsp=local; return(local[0]);}

/*:flush*/
static pointer XeusM428xdrawable_flush(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[7]);
	ctx->vsp=local+1;
	w=(*ftab[1])(ctx,1,local+0,&ftab[1],fqv[8]); /*flush*/
	local[0]= w;
XeusBLK429:
	ctx->vsp=local; return(local[0]);}

/*:geometry*/
static pointer XeusM430xdrawable_geometry(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[9]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= loadglobal(fqv[10]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= loadglobal(fqv[10]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= loadglobal(fqv[10]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= loadglobal(fqv[10]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= loadglobal(fqv[10]);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,1,local+5); /*instantiate*/
	local[5]= w;
	local[6]= loadglobal(fqv[10]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= loadglobal(fqv[7]);
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= local[0];
	local[10]= local[1];
	local[11]= local[2];
	local[12]= local[3];
	local[13]= local[4];
	local[14]= local[5];
	local[15]= local[6];
	ctx->vsp=local+16;
	w=(*ftab[2])(ctx,9,local+7,&ftab[2],fqv[11]); /*getgeometry*/
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(*ftab[3])(ctx,1,local+7,&ftab[3],fqv[9]); /*c-long*/
	local[7]= w;
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,1,local+8,&ftab[4],fqv[10]); /*c-int*/
	local[8]= w;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,1,local+9,&ftab[4],fqv[10]); /*c-int*/
	local[9]= w;
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(*ftab[4])(ctx,1,local+10,&ftab[4],fqv[10]); /*c-int*/
	local[10]= w;
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(*ftab[4])(ctx,1,local+11,&ftab[4],fqv[10]); /*c-int*/
	local[11]= w;
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(*ftab[4])(ctx,1,local+12,&ftab[4],fqv[10]); /*c-int*/
	local[12]= w;
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(*ftab[4])(ctx,1,local+13,&ftab[4],fqv[10]); /*c-int*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,7,local+7); /*list*/
	local[0]= w;
XeusBLK431:
	ctx->vsp=local; return(local[0]);}

/*:height*/
static pointer XeusM432xdrawable_height(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)4L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
XeusBLK433:
	ctx->vsp=local; return(local[0]);}

/*:width*/
static pointer XeusM434xdrawable_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)3L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
XeusBLK435:
	ctx->vsp=local; return(local[0]);}

/*:pos*/
static pointer XeusM436xdrawable_pos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= loadglobal(fqv[13]);
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,3,local+0,&ftab[5],fqv[14]); /*getwindowattributes*/
	local[0]= loadglobal(fqv[13]);
	local[1]= fqv[15];
	local[2]= fqv[16];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= loadglobal(fqv[13]);
	local[2]= fqv[15];
	local[3]= fqv[17];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKINTVECTOR(ctx,2,local+0); /*integer-vector*/
	local[0]= w;
XeusBLK437:
	ctx->vsp=local; return(local[0]);}

/*:x*/
static pointer XeusM438xdrawable_x(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= loadglobal(fqv[13]);
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,3,local+0,&ftab[5],fqv[14]); /*getwindowattributes*/
	local[0]= loadglobal(fqv[13]);
	local[1]= fqv[15];
	local[2]= fqv[16];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XeusBLK439:
	ctx->vsp=local; return(local[0]);}

/*:y*/
static pointer XeusM440xdrawable_y(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= loadglobal(fqv[13]);
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,3,local+0,&ftab[5],fqv[14]); /*getwindowattributes*/
	local[0]= loadglobal(fqv[13]);
	local[1]= fqv[15];
	local[2]= fqv[17];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XeusBLK441:
	ctx->vsp=local; return(local[0]);}

/*:gc*/
static pointer XeusM442xdrawable_gc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XeusRST444:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]!=NIL) goto XeusCON446;
	local[1]= argv[0]->c.obj.iv[3];
	goto XeusCON445;
XeusCON446:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= loadglobal(fqv[2]);
	ctx->vsp=local+3;
	w=(pointer)DERIVEDP(ctx,2,local+1); /*derivedp*/
	if (w==NIL) goto XeusCON447;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[3] = (w)->c.cons.car;
	local[1]= argv[0]->c.obj.iv[3];
	goto XeusCON445;
XeusCON447:
	local[1]= (pointer)get_sym_func(fqv[18]);
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,3,local+1); /*apply*/
	local[1]= w;
	goto XeusCON445;
XeusCON448:
	local[1]= NIL;
XeusCON445:
	w = local[1];
	local[0]= w;
XeusBLK443:
	ctx->vsp=local; return(local[0]);}

/*:gcid*/
static pointer XeusM449xdrawable_gcid(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[19];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
XeusBLK450:
	ctx->vsp=local; return(local[0]);}

/*:line-width*/
static pointer XeusM451xdrawable_line_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XeusENT454;}
	local[0]= NIL;
XeusENT454:
XeusENT453:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[20];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
XeusBLK452:
	ctx->vsp=local; return(local[0]);}

/*:line-style*/
static pointer XeusM455xdrawable_line_style(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XeusENT458;}
	local[0]= NIL;
XeusENT458:
XeusENT457:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[21];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
XeusBLK456:
	ctx->vsp=local; return(local[0]);}

/*:color*/
static pointer XeusM459xdrawable_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XeusENT462;}
	local[0]= NIL;
XeusENT462:
XeusENT461:
	if (n>3) maerror();
	w = local[0];
	if (isnum(w)) goto XeusOR465;
	w = local[0];
	if (isstring(w)) goto XeusOR465;
	w = local[0];
	if (issymbol(w)) goto XeusOR465;
	goto XeusCON464;
XeusOR465:
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[22];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[3];
	goto XeusCON463;
XeusCON464:
	local[1]= local[0];
	local[2]= loadglobal(fqv[2]);
	ctx->vsp=local+3;
	w=(pointer)DERIVEDP(ctx,2,local+1); /*derivedp*/
	if (w==NIL) goto XeusCON466;
	argv[0]->c.obj.iv[3] = local[0];
	local[1]= argv[0]->c.obj.iv[3];
	goto XeusCON463;
XeusCON466:
	local[1]= argv[0]->c.obj.iv[3];
	goto XeusCON463;
XeusCON467:
	local[1]= NIL;
XeusCON463:
	w = local[1];
	local[0]= w;
XeusBLK460:
	ctx->vsp=local; return(local[0]);}

/*:copy-from*/
static pointer XeusM468xdrawable_copy_from(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[23], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto XeusKEY470;
	local[0] = NIL;
XeusKEY470:
	if (n & (1<<1)) goto XeusKEY471;
	local[1] = NIL;
XeusKEY471:
	if (n & (1<<2)) goto XeusKEY472;
	local[2] = makeint((eusinteger_t)0L);
XeusKEY472:
	if (n & (1<<3)) goto XeusKEY473;
	local[3] = makeint((eusinteger_t)0L);
XeusKEY473:
	if (n & (1<<4)) goto XeusKEY474;
	local[4] = makeint((eusinteger_t)0L);
XeusKEY474:
	if (n & (1<<5)) goto XeusKEY475;
	local[5] = makeint((eusinteger_t)0L);
XeusKEY475:
	if (local[0]!=NIL) goto XeusIF476;
	if (local[1]!=NIL) goto XeusIF476;
	local[6]= argv[0];
	local[7]= fqv[12];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[6];
	local[8]= makeint((eusinteger_t)3L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[0] = w;
	local[7]= local[6];
	local[8]= makeint((eusinteger_t)4L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[1] = w;
	w = local[1];
	local[6]= w;
	goto XeusIF477;
XeusIF476:
	local[6]= NIL;
XeusIF477:
	local[6]= loadglobal(fqv[7]);
	local[7]= argv[2];
	local[8]= fqv[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[0]->c.obj.iv[3]->c.obj.iv[2];
	local[10]= local[2];
	local[11]= local[3];
	local[12]= local[0];
	local[13]= local[1];
	local[14]= local[4];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(*ftab[6])(ctx,10,local+6,&ftab[6],fqv[24]); /*copyarea*/
	local[0]= w;
XeusBLK469:
	ctx->vsp=local; return(local[0]);}

/*:shift*/
static pointer XeusM478xdrawable_shift(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XeusENT481;}
	local[0]= makeint((eusinteger_t)0L);
XeusENT481:
XeusENT480:
	if (n>4) maerror();
	w = argv[2];
	if (!isflt(w)) goto XeusIF482;
	local[1]= argv[0];
	local[2]= fqv[25];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	argv[2] = w;
	local[1]= argv[2];
	goto XeusIF483;
XeusIF482:
	local[1]= NIL;
XeusIF483:
	w = local[0];
	if (!isflt(w)) goto XeusIF484;
	local[1]= argv[0];
	local[2]= fqv[26];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[0] = w;
	local[1]= local[0];
	goto XeusIF485;
XeusIF484:
	local[1]= NIL;
XeusIF485:
	local[1]= loadglobal(fqv[7]);
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= argv[0]->c.obj.iv[3]->c.obj.iv[2];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= argv[0];
	local[8]= fqv[25];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[26];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= argv[2];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(*ftab[6])(ctx,10,local+1,&ftab[6],fqv[24]); /*copyarea*/
	local[0]= w;
XeusBLK479:
	ctx->vsp=local; return(local[0]);}

/*:point*/
static pointer XeusM486xdrawable_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto XeusENT489;}
	local[0]= argv[0]->c.obj.iv[3];
XeusENT489:
XeusENT488:
	if (n>5) maerror();
	local[1]= loadglobal(fqv[7]);
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0]->c.obj.iv[2];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(*ftab[7])(ctx,5,local+1,&ftab[7],fqv[27]); /*drawpoint*/
	local[0]= w;
XeusBLK487:
	ctx->vsp=local; return(local[0]);}

/*:line*/
static pointer XeusM490xdrawable_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	if (n>=7) { local[0]=(argv[6]); goto XeusENT493;}
	local[0]= argv[0]->c.obj.iv[3];
XeusENT493:
XeusENT492:
	if (n>7) maerror();
	local[1]= loadglobal(fqv[7]);
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0]->c.obj.iv[2];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= argv[4];
	local[7]= argv[5];
	ctx->vsp=local+8;
	w=(*ftab[8])(ctx,7,local+1,&ftab[8],fqv[28]); /*drawline*/
	local[0]= w;
XeusBLK491:
	ctx->vsp=local; return(local[0]);}

/*:rectangle*/
static pointer XeusM494xdrawable_rectangle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	if (n>=7) { local[0]=(argv[6]); goto XeusENT497;}
	local[0]= argv[0]->c.obj.iv[3];
XeusENT497:
XeusENT496:
	if (n>7) maerror();
	local[1]= loadglobal(fqv[7]);
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0]->c.obj.iv[2];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= argv[4];
	local[7]= argv[5];
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,7,local+1,&ftab[9],fqv[29]); /*drawrectangle*/
	local[0]= w;
XeusBLK495:
	ctx->vsp=local; return(local[0]);}

/*:arc*/
static pointer XeusM498xdrawable_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	if (n>=6) { local[0]=(argv[5]); goto XeusENT504;}
	local[0]= argv[4];
XeusENT504:
	if (n>=7) { local[1]=(argv[6]); goto XeusENT503;}
	local[1]= makeflt(0.0000000000000000000000e+00);
XeusENT503:
	if (n>=8) { local[2]=(argv[7]); goto XeusENT502;}
	local[2]= makeflt(6.2831853071795862319959e+00);
XeusENT502:
	if (n>=9) { local[3]=(argv[8]); goto XeusENT501;}
	local[3]= argv[0]->c.obj.iv[3];
XeusENT501:
XeusENT500:
	if (n>9) maerror();
	local[4]= loadglobal(fqv[7]);
	local[5]= argv[0]->c.obj.iv[2];
	local[6]= local[3]->c.obj.iv[2];
	local[7]= argv[2];
	local[8]= argv[3];
	local[9]= argv[4];
	local[10]= local[0];
	local[11]= makeint((eusinteger_t)64L);
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(*ftab[10])(ctx,1,local+12,&ftab[10],fqv[30]); /*rad2deg*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ROUND(ctx,1,local+11); /*round*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)64L);
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(*ftab[10])(ctx,1,local+13,&ftab[10],fqv[30]); /*rad2deg*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ROUND(ctx,1,local+12); /*round*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[11])(ctx,9,local+4,&ftab[11],fqv[31]); /*drawarc*/
	local[0]= w;
XeusBLK499:
	ctx->vsp=local; return(local[0]);}

/*:fill-rectangle*/
static pointer XeusM505xdrawable_fill_rectangle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	if (n>=7) { local[0]=(argv[6]); goto XeusENT508;}
	local[0]= argv[0]->c.obj.iv[3];
XeusENT508:
XeusENT507:
	if (n>7) maerror();
	local[1]= loadglobal(fqv[7]);
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0]->c.obj.iv[2];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)ROUND(ctx,1,local+4); /*round*/
	local[4]= w;
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)ROUND(ctx,1,local+5); /*round*/
	local[5]= w;
	local[6]= argv[4];
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	local[7]= argv[5];
	ctx->vsp=local+8;
	w=(pointer)ROUND(ctx,1,local+7); /*round*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[12])(ctx,7,local+1,&ftab[12],fqv[32]); /*fillrectangle*/
	local[0]= w;
XeusBLK506:
	ctx->vsp=local; return(local[0]);}

/*:fill-arc*/
static pointer XeusM509xdrawable_fill_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	if (n>=6) { local[0]=(argv[5]); goto XeusENT515;}
	local[0]= argv[4];
XeusENT515:
	if (n>=7) { local[1]=(argv[6]); goto XeusENT514;}
	local[1]= makeflt(0.0000000000000000000000e+00);
XeusENT514:
	if (n>=8) { local[2]=(argv[7]); goto XeusENT513;}
	local[2]= makeflt(6.2831853071795862319959e+00);
XeusENT513:
	if (n>=9) { local[3]=(argv[8]); goto XeusENT512;}
	local[3]= argv[0]->c.obj.iv[3];
XeusENT512:
XeusENT511:
	if (n>9) maerror();
	local[4]= loadglobal(fqv[7]);
	local[5]= argv[0]->c.obj.iv[2];
	local[6]= local[3]->c.obj.iv[2];
	local[7]= argv[2];
	local[8]= argv[3];
	local[9]= argv[4];
	local[10]= local[0];
	local[11]= makeint((eusinteger_t)64L);
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(*ftab[10])(ctx,1,local+12,&ftab[10],fqv[30]); /*rad2deg*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ROUND(ctx,1,local+11); /*round*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)64L);
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(*ftab[10])(ctx,1,local+13,&ftab[10],fqv[30]); /*rad2deg*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ROUND(ctx,1,local+12); /*round*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[13])(ctx,9,local+4,&ftab[13],fqv[33]); /*fillarc*/
	local[0]= w;
XeusBLK510:
	ctx->vsp=local; return(local[0]);}

/*:string*/
static pointer XeusM516xdrawable_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	if (n>=6) { local[0]=(argv[5]); goto XeusENT521;}
	local[0]= makeint((eusinteger_t)0L);
XeusENT521:
	if (n>=7) { local[1]=(argv[6]); goto XeusENT520;}
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
XeusENT520:
	if (n>=8) { local[2]=(argv[7]); goto XeusENT519;}
	local[2]= argv[0]->c.obj.iv[3];
XeusENT519:
XeusENT518:
	if (n>8) maerror();
	local[3]= loadglobal(fqv[7]);
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= local[2]->c.obj.iv[2];
	local[6]= argv[2];
	local[7]= argv[3];
	local[8]= argv[4];
	ctx->vsp=local+9;
	w=(pointer)ADDRESS(ctx,1,local+8); /*system:address*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)8L);
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)2L)); i=intval(local[9]);
		local[9]=(makeint(i * j));}
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,3,local+8); /*+*/
	local[8]= w;
	local[9]= local[1];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[14])(ctx,7,local+3,&ftab[14],fqv[34]); /*drawstring*/
	local[0]= w;
XeusBLK517:
	ctx->vsp=local; return(local[0]);}

/*:image-string*/
static pointer XeusM522xdrawable_image_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	if (n>=6) { local[0]=(argv[5]); goto XeusENT527;}
	local[0]= makeint((eusinteger_t)0L);
XeusENT527:
	if (n>=7) { local[1]=(argv[6]); goto XeusENT526;}
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
XeusENT526:
	if (n>=8) { local[2]=(argv[7]); goto XeusENT525;}
	local[2]= argv[0]->c.obj.iv[3];
XeusENT525:
XeusENT524:
	if (n>8) maerror();
	local[3]= loadglobal(fqv[7]);
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= local[2]->c.obj.iv[2];
	local[6]= argv[2];
	local[7]= argv[3];
	local[8]= argv[4];
	ctx->vsp=local+9;
	w=(pointer)ADDRESS(ctx,1,local+8); /*system:address*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)8L);
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)2L)); i=intval(local[9]);
		local[9]=(makeint(i * j));}
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,3,local+8); /*+*/
	local[8]= w;
	local[9]= local[1];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[15])(ctx,7,local+3,&ftab[15],fqv[35]); /*drawimagestring*/
	local[0]= w;
XeusBLK523:
	ctx->vsp=local; return(local[0]);}

/*:getimage*/
static pointer XeusM528xdrawable_getimage(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[36], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto XeusKEY530;
	local[0] = NIL;
XeusKEY530:
	if (n & (1<<1)) goto XeusKEY531;
	local[1] = makeint((eusinteger_t)0L);
XeusKEY531:
	if (n & (1<<2)) goto XeusKEY532;
	local[2] = makeint((eusinteger_t)0L);
XeusKEY532:
	if (n & (1<<3)) goto XeusKEY533;
	local[7]= argv[0];
	local[8]= fqv[25];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[3] = w;
XeusKEY533:
	if (n & (1<<4)) goto XeusKEY534;
	local[7]= argv[0];
	local[8]= fqv[26];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[4] = w;
XeusKEY534:
	if (n & (1<<5)) goto XeusKEY535;
	local[5] = makeint((eusinteger_t)1152921504606846975L);
XeusKEY535:
	if (n & (1<<6)) goto XeusKEY536;
	local[6] = makeint((eusinteger_t)2L);
XeusKEY536:
	if (local[0]==NIL) goto XeusIF537;
	local[7]= local[0];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,2,local+7); /*aref*/
	local[1] = w;
	local[7]= local[0];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,2,local+7); /*aref*/
	local[2] = w;
	local[7]= local[2];
	goto XeusIF538;
XeusIF537:
	local[7]= NIL;
XeusIF538:
	local[7]= loadglobal(fqv[7]);
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= local[1];
	local[10]= local[2];
	local[11]= local[3];
	local[12]= local[4];
	local[13]= local[5];
	local[14]= local[6];
	ctx->vsp=local+15;
	w=(*ftab[16])(ctx,8,local+7,&ftab[16],fqv[37]); /*getimage*/
	local[7]= w;
	local[8]= local[7];
	local[9]= makeint((eusinteger_t)48L);
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	local[9]= fqv[1];
	ctx->vsp=local+10;
	w=(pointer)PEEK(ctx,2,local+8); /*system:peek*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)8L);
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	local[9]= local[7];
	local[10]= makeint((eusinteger_t)44L);
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= fqv[1];
	ctx->vsp=local+11;
	w=(pointer)PEEK(ctx,2,local+9); /*system:peek*/
	local[9]= w;
	local[10]= local[7];
	local[11]= makeint((eusinteger_t)8L);
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	local[11]= fqv[1];
	ctx->vsp=local+12;
	w=(pointer)PEEK(ctx,2,local+10); /*system:peek*/
	local[10]= w;
	local[11]= local[7];
	local[12]= makeint((eusinteger_t)16L);
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	local[12]= fqv[0];
	ctx->vsp=local+13;
	w=(pointer)PEEK(ctx,2,local+11); /*system:peek*/
	local[11]= w;
	local[12]= local[3];
	local[13]= local[4];
	local[14]= local[8];
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,3,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[17])(ctx,1,local+12,&ftab[17],fqv[38]); /*make-string*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	local[14]= local[4];
XeusWHL539:
	local[15]= local[13];
	w = local[14];
	if ((eusinteger_t)local[15] >= (eusinteger_t)w) goto XeusWHX540;
	local[15]= local[12];
	local[16]= local[11];
	local[17]= local[13];
	local[18]= local[9];
	local[19]= local[8];
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,3,local+17); /***/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)PLUS(ctx,2,local+16); /*+*/
	local[16]= w;
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(*ftab[18])(ctx,2,local+16,&ftab[18],fqv[39]); /*make-foreign-string*/
	local[16]= w;
	local[17]= fqv[40];
	local[18]= local[13];
	local[19]= local[3];
	local[20]= local[8];
	ctx->vsp=local+21;
	w=(pointer)TIMES(ctx,3,local+18); /***/
	local[18]= w;
	local[19]= fqv[41];
	local[20]= local[13];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[20]= w;
	local[21]= local[3];
	local[22]= local[8];
	ctx->vsp=local+23;
	w=(pointer)TIMES(ctx,3,local+20); /***/
	local[20]= w;
	ctx->vsp=local+21;
	w=(*ftab[19])(ctx,6,local+15,&ftab[19],fqv[42]); /*replace*/
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[13] = w;
	goto XeusWHL539;
XeusWHX540:
	local[15]= NIL;
XeusBLK541:
	w = NIL;
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(*ftab[20])(ctx,1,local+13,&ftab[20],fqv[43]); /*destroyimage*/
	w = local[12];
	local[0]= w;
XeusBLK529:
	ctx->vsp=local; return(local[0]);}

/*:putimage*/
static pointer XeusM542xdrawable_putimage(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[44], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto XeusKEY544;
	local[0] = NIL;
XeusKEY544:
	if (n & (1<<1)) goto XeusKEY545;
	local[1] = makeint((eusinteger_t)0L);
XeusKEY545:
	if (n & (1<<2)) goto XeusKEY546;
	local[2] = makeint((eusinteger_t)0L);
XeusKEY546:
	if (n & (1<<3)) goto XeusKEY547;
	local[3] = NIL;
XeusKEY547:
	if (n & (1<<4)) goto XeusKEY548;
	local[4] = makeint((eusinteger_t)0L);
XeusKEY548:
	if (n & (1<<5)) goto XeusKEY549;
	local[5] = makeint((eusinteger_t)0L);
XeusKEY549:
	if (n & (1<<6)) goto XeusKEY550;
	local[6] = NIL;
XeusKEY550:
	if (n & (1<<7)) goto XeusKEY551;
	local[7] = NIL;
XeusKEY551:
	if (n & (1<<8)) goto XeusKEY552;
	local[8] = argv[0]->c.obj.iv[3];
XeusKEY552:
	if (n & (1<<9)) goto XeusKEY553;
	local[13]= argv[0];
	local[14]= fqv[45];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[9] = w;
XeusKEY553:
	if (n & (1<<10)) goto XeusKEY554;
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(*ftab[21])(ctx,1,local+13,&ftab[21],fqv[46]); /*visual-depth*/
	local[10] = w;
XeusKEY554:
	if (n & (1<<11)) goto XeusKEY555;
	local[11] = local[10];
XeusKEY555:
	if (n & (1<<12)) goto XeusKEY556;
	local[12] = loadglobal(fqv[47]);
XeusKEY556:
	if (local[0]==NIL) goto XeusIF557;
	local[13]= local[0];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,2,local+13); /*aref*/
	local[1] = w;
	local[13]= local[0];
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,2,local+13); /*aref*/
	local[2] = w;
	local[13]= local[2];
	goto XeusIF558;
XeusIF557:
	local[13]= NIL;
XeusIF558:
	if (local[3]==NIL) goto XeusIF559;
	local[13]= local[3];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,2,local+13); /*aref*/
	local[4] = w;
	local[13]= local[3];
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,2,local+13); /*aref*/
	local[5] = w;
	local[13]= local[5];
	goto XeusIF560;
XeusIF559:
	local[13]= NIL;
XeusIF560:
	local[13]= argv[2];
	local[14]= loadglobal(fqv[48]);
	ctx->vsp=local+15;
	w=(pointer)DERIVEDP(ctx,2,local+13); /*derivedp*/
	if (w==NIL) goto XeusCON562;
	if (local[6]!=NIL) goto XeusIF563;
	local[13]= argv[2];
	local[14]= fqv[25];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[6] = w;
	local[13]= local[6];
	goto XeusIF564;
XeusIF563:
	local[13]= NIL;
XeusIF564:
	if (local[7]!=NIL) goto XeusIF565;
	local[13]= argv[2];
	local[14]= fqv[26];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[7] = w;
	local[13]= local[7];
	goto XeusIF566;
XeusIF565:
	local[13]= NIL;
XeusIF566:
	argv[2] = argv[2]->c.obj.iv[1];
	local[13]= argv[2];
	goto XeusCON561;
XeusCON562:
	if (local[6]!=NIL) goto XeusIF568;
	local[13]= argv[0];
	local[14]= fqv[25];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,2,local+13); /*-*/
	local[6] = w;
	local[13]= local[6];
	goto XeusIF569;
XeusIF568:
	local[13]= NIL;
XeusIF569:
	if (local[7]!=NIL) goto XeusIF570;
	local[13]= argv[0];
	local[14]= fqv[26];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= local[5];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,2,local+13); /*-*/
	local[7] = w;
	local[13]= local[7];
	goto XeusIF571;
XeusIF570:
	local[13]= NIL;
XeusIF571:
	goto XeusCON561;
XeusCON567:
	local[13]= NIL;
XeusCON561:
	local[13]= local[12];
	local[14]= argv[2];
	local[15]= local[6];
	local[16]= local[7];
	local[17]= local[9];
	local[18]= local[10];
	local[19]= local[11];
	ctx->vsp=local+20;
	w=(*ftab[22])(ctx,7,local+13,&ftab[22],fqv[49]); /*set-ximage*/
	local[13]= loadglobal(fqv[7]);
	local[14]= argv[0]->c.obj.iv[2];
	local[15]= local[8]->c.obj.iv[2];
	local[16]= local[12];
	local[17]= local[1];
	local[18]= local[2];
	local[19]= local[4];
	local[20]= local[5];
	local[21]= local[6];
	local[22]= local[7];
	ctx->vsp=local+23;
	w=(*ftab[23])(ctx,10,local+13,&ftab[23],fqv[50]); /*putimage*/
	local[0]= w;
XeusBLK543:
	ctx->vsp=local; return(local[0]);}

/*:putimage8to24*/
static pointer XeusM572xdrawable_putimage8to24(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[51], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto XeusKEY574;
	local[0] = NIL;
XeusKEY574:
	if (n & (1<<1)) goto XeusKEY575;
	local[1] = makeint((eusinteger_t)0L);
XeusKEY575:
	if (n & (1<<2)) goto XeusKEY576;
	local[2] = makeint((eusinteger_t)0L);
XeusKEY576:
	if (n & (1<<3)) goto XeusKEY577;
	local[3] = NIL;
XeusKEY577:
	if (n & (1<<4)) goto XeusKEY578;
	local[4] = makeint((eusinteger_t)0L);
XeusKEY578:
	if (n & (1<<5)) goto XeusKEY579;
	local[5] = makeint((eusinteger_t)0L);
XeusKEY579:
	if (n & (1<<6)) goto XeusKEY580;
	local[12]= argv[0];
	local[13]= fqv[25];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,2,local+12); /*-*/
	local[6] = w;
XeusKEY580:
	if (n & (1<<7)) goto XeusKEY581;
	local[12]= argv[0];
	local[13]= fqv[26];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,2,local+12); /*-*/
	local[7] = w;
XeusKEY581:
	if (n & (1<<8)) goto XeusKEY582;
	local[8] = argv[0]->c.obj.iv[3];
XeusKEY582:
	if (n & (1<<9)) goto XeusKEY583;
	local[9] = NIL;
XeusKEY583:
	if (n & (1<<10)) goto XeusKEY584;
	local[10] = NIL;
XeusKEY584:
	if (n & (1<<11)) goto XeusKEY585;
	local[11] = NIL;
XeusKEY585:
	local[12]= NIL;
	local[13]= NIL;
	local[14]= NIL;
	if (local[0]==NIL) goto XeusIF586;
	local[15]= local[0];
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)AREF(ctx,2,local+15); /*aref*/
	local[1] = w;
	local[15]= local[0];
	local[16]= makeint((eusinteger_t)1L);
	ctx->vsp=local+17;
	w=(pointer)AREF(ctx,2,local+15); /*aref*/
	local[2] = w;
	local[15]= local[2];
	goto XeusIF587;
XeusIF586:
	local[15]= NIL;
XeusIF587:
	if (local[3]==NIL) goto XeusIF588;
	local[15]= local[3];
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)AREF(ctx,2,local+15); /*aref*/
	local[4] = w;
	local[15]= local[3];
	local[16]= makeint((eusinteger_t)1L);
	ctx->vsp=local+17;
	w=(pointer)AREF(ctx,2,local+15); /*aref*/
	local[5] = w;
	local[15]= local[5];
	goto XeusIF589;
XeusIF588:
	local[15]= NIL;
XeusIF589:
	local[15]= local[6];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	local[16]= fqv[52];
	local[17]= fqv[1];
	ctx->vsp=local+18;
	w=(*ftab[24])(ctx,3,local+15,&ftab[24],fqv[53]); /*make-array*/
	local[13] = w;
	local[15]= makeint((eusinteger_t)0L);
	local[16]= local[6];
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
XeusWHL590:
	local[17]= local[15];
	w = local[16];
	if ((eusinteger_t)local[17] >= (eusinteger_t)w) goto XeusWHX591;
	local[17]= argv[2];
	local[18]= local[15];
	ctx->vsp=local+19;
	w=(pointer)AREF(ctx,2,local+17); /*aref*/
	local[14] = w;
	local[17]= local[13];
	local[18]= local[15];
	local[19]= local[14];
	local[20]= local[14];
	local[21]= makeint((eusinteger_t)8L);
	ctx->vsp=local+22;
	w=(pointer)ASH(ctx,2,local+20); /*ash*/
	local[20]= w;
	local[21]= local[14];
	local[22]= makeint((eusinteger_t)16L);
	ctx->vsp=local+23;
	w=(pointer)ASH(ctx,2,local+21); /*ash*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)LOGIOR(ctx,3,local+19); /*logior*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)ASET(ctx,3,local+17); /*aset*/
	local[17]= local[15];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[15] = w;
	goto XeusWHL590;
XeusWHX591:
	local[17]= NIL;
XeusBLK592:
	w = NIL;
	local[15]= loadglobal(fqv[7]);
	local[16]= argv[0]->c.obj.iv[2];
	local[17]= local[8]->c.obj.iv[2];
	local[18]= local[13];
	local[19]= local[1];
	local[20]= local[2];
	local[21]= local[4];
	local[22]= local[5];
	local[23]= local[6];
	local[24]= local[7];
	ctx->vsp=local+25;
	w=(*ftab[23])(ctx,10,local+15,&ftab[23],fqv[50]); /*putimage*/
	local[0]= w;
XeusBLK573:
	ctx->vsp=local; return(local[0]);}

/*:draw-point*/
static pointer XeusM593xdrawable_draw_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XeusENT596;}
	local[0]= argv[0]->c.obj.iv[3];
XeusENT596:
XeusENT595:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[54];
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ROUND(ctx,1,local+3); /*round*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ROUND(ctx,1,local+4); /*round*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
XeusBLK594:
	ctx->vsp=local; return(local[0]);}

/*:draw-line*/
static pointer XeusM597xdrawable_draw_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto XeusENT600;}
	local[0]= argv[0]->c.obj.iv[3];
XeusENT600:
XeusENT599:
	if (n>5) maerror();
	local[1]= argv[0];
	local[2]= fqv[55];
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ROUND(ctx,1,local+3); /*round*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ROUND(ctx,1,local+4); /*round*/
	local[4]= w;
	local[5]= argv[3];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ROUND(ctx,1,local+5); /*round*/
	local[5]= w;
	local[6]= argv[3];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,7,local+1); /*send*/
	local[0]= w;
XeusBLK598:
	ctx->vsp=local; return(local[0]);}

/*:draw-string*/
static pointer XeusM601xdrawable_draw_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto XeusENT606;}
	local[0]= makeint((eusinteger_t)0L);
XeusENT606:
	if (n>=6) { local[1]=(argv[5]); goto XeusENT605;}
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
XeusENT605:
	if (n>=7) { local[2]=(argv[6]); goto XeusENT604;}
	local[2]= argv[0]->c.obj.iv[3];
XeusENT604:
XeusENT603:
	if (n>7) maerror();
	local[3]= argv[0];
	local[4]= fqv[56];
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ROUND(ctx,1,local+5); /*round*/
	local[5]= w;
	local[6]= argv[2];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	local[7]= argv[3];
	local[8]= local[0];
	local[9]= local[1];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,8,local+3); /*send*/
	local[0]= w;
XeusBLK602:
	ctx->vsp=local; return(local[0]);}

/*:draw-image-string*/
static pointer XeusM607xdrawable_draw_image_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto XeusENT612;}
	local[0]= makeint((eusinteger_t)0L);
XeusENT612:
	if (n>=6) { local[1]=(argv[5]); goto XeusENT611;}
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
XeusENT611:
	if (n>=7) { local[2]=(argv[6]); goto XeusENT610;}
	local[2]= argv[0]->c.obj.iv[3];
XeusENT610:
XeusENT609:
	if (n>7) maerror();
	local[3]= argv[0];
	local[4]= fqv[57];
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ROUND(ctx,1,local+5); /*round*/
	local[5]= w;
	local[6]= argv[2];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	local[7]= argv[3];
	local[8]= local[0];
	local[9]= local[1];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,8,local+3); /*send*/
	local[0]= w;
XeusBLK608:
	ctx->vsp=local; return(local[0]);}

/*:draw-rectangle*/
static pointer XeusM613xdrawable_draw_rectangle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	if (n>=6) { local[0]=(argv[5]); goto XeusENT616;}
	local[0]= argv[0]->c.obj.iv[3];
XeusENT616:
XeusENT615:
	if (n>6) maerror();
	local[1]= argv[0];
	local[2]= fqv[58];
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ROUND(ctx,1,local+3); /*round*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ROUND(ctx,1,local+4); /*round*/
	local[4]= w;
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)ROUND(ctx,1,local+5); /*round*/
	local[5]= w;
	local[6]= argv[4];
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,7,local+1); /*send*/
	local[0]= w;
XeusBLK614:
	ctx->vsp=local; return(local[0]);}

/*:draw-fill-rectangle*/
static pointer XeusM617xdrawable_draw_fill_rectangle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	if (n>=6) { local[0]=(argv[5]); goto XeusENT620;}
	local[0]= argv[0]->c.obj.iv[3];
XeusENT620:
XeusENT619:
	if (n>6) maerror();
	local[1]= local[0];
	local[2]= loadglobal(fqv[2]);
	ctx->vsp=local+3;
	w=(pointer)DERIVEDP(ctx,2,local+1); /*derivedp*/
	if (w!=NIL) goto XeusIF621;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[22];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0] = argv[0]->c.obj.iv[3];
	local[1]= local[0];
	goto XeusIF622;
XeusIF621:
	local[1]= NIL;
XeusIF622:
	local[1]= argv[0];
	local[2]= fqv[59];
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ROUND(ctx,1,local+3); /*round*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ROUND(ctx,1,local+4); /*round*/
	local[4]= w;
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)ROUND(ctx,1,local+5); /*round*/
	local[5]= w;
	local[6]= argv[4];
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,7,local+1); /*send*/
	local[0]= w;
XeusBLK618:
	ctx->vsp=local; return(local[0]);}

/*:draw-arc*/
static pointer XeusM623xdrawable_draw_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto XeusENT629;}
	local[0]= argv[3];
XeusENT629:
	if (n>=6) { local[1]=(argv[5]); goto XeusENT628;}
	local[1]= makeflt(0.0000000000000000000000e+00);
XeusENT628:
	if (n>=7) { local[2]=(argv[6]); goto XeusENT627;}
	local[2]= makeflt(6.2831853071795862319959e+00);
XeusENT627:
	if (n>=8) { local[3]=(argv[7]); goto XeusENT626;}
	local[3]= argv[0]->c.obj.iv[3];
XeusENT626:
XeusENT625:
	if (n>8) maerror();
	local[4]= argv[0];
	local[5]= fqv[60];
	local[6]= argv[2];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	local[7]= argv[2];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ROUND(ctx,1,local+7); /*round*/
	local[7]= w;
	local[8]= argv[3];
	ctx->vsp=local+9;
	w=(pointer)ROUND(ctx,1,local+8); /*round*/
	local[8]= w;
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)ROUND(ctx,1,local+9); /*round*/
	local[9]= w;
	local[10]= local[1];
	local[11]= local[2];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,9,local+4); /*send*/
	local[0]= w;
XeusBLK624:
	ctx->vsp=local; return(local[0]);}

/*:draw-fill-arc*/
static pointer XeusM630xdrawable_draw_fill_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto XeusENT636;}
	local[0]= argv[3];
XeusENT636:
	if (n>=6) { local[1]=(argv[5]); goto XeusENT635;}
	local[1]= makeflt(0.0000000000000000000000e+00);
XeusENT635:
	if (n>=7) { local[2]=(argv[6]); goto XeusENT634;}
	local[2]= makeflt(6.2831853071795862319959e+00);
XeusENT634:
	if (n>=8) { local[3]=(argv[7]); goto XeusENT633;}
	local[3]= argv[0]->c.obj.iv[3];
XeusENT633:
XeusENT632:
	if (n>8) maerror();
	local[4]= argv[0];
	local[5]= fqv[61];
	local[6]= argv[2];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	local[7]= argv[2];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ROUND(ctx,1,local+7); /*round*/
	local[7]= w;
	local[8]= argv[3];
	ctx->vsp=local+9;
	w=(pointer)ROUND(ctx,1,local+8); /*round*/
	local[8]= w;
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)ROUND(ctx,1,local+9); /*round*/
	local[9]= w;
	local[10]= local[1];
	local[11]= local[2];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,9,local+4); /*send*/
	local[0]= w;
XeusBLK631:
	ctx->vsp=local; return(local[0]);}

/*:drawline-primitive*/
static pointer XeusM637xdrawable_drawline_primitive(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[0];
	local[1]= fqv[55];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)ROUND(ctx,1,local+2); /*round*/
	local[2]= w;
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)ROUND(ctx,1,local+3); /*round*/
	local[3]= w;
	local[4]= argv[4];
	ctx->vsp=local+5;
	w=(pointer)ROUND(ctx,1,local+4); /*round*/
	local[4]= w;
	local[5]= argv[5];
	ctx->vsp=local+6;
	w=(pointer)ROUND(ctx,1,local+5); /*round*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	local[0]= w;
XeusBLK638:
	ctx->vsp=local; return(local[0]);}

/*:set-show-mode*/
static pointer XeusM639xdrawable_set_show_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[62];
	local[2]= fqv[63];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XeusBLK640:
	ctx->vsp=local; return(local[0]);}

/*:set-erase-mode*/
static pointer XeusM641xdrawable_set_erase_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[62];
	local[2]= fqv[64];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XeusBLK642:
	ctx->vsp=local; return(local[0]);}

/*:set-xor-mode*/
static pointer XeusM643xdrawable_set_xor_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[62];
	local[2]= fqv[65];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XeusBLK644:
	ctx->vsp=local; return(local[0]);}

/*:clear-area*/
static pointer XeusM645xdrawable_clear_area(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[66], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto XeusKEY647;
	local[0] = makeint((eusinteger_t)0L);
XeusKEY647:
	if (n & (1<<1)) goto XeusKEY648;
	local[1] = makeint((eusinteger_t)0L);
XeusKEY648:
	if (n & (1<<2)) goto XeusKEY649;
	local[5]= argv[0];
	local[6]= fqv[25];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[2] = w;
XeusKEY649:
	if (n & (1<<3)) goto XeusKEY650;
	local[5]= argv[0];
	local[6]= fqv[26];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[3] = w;
XeusKEY650:
	if (n & (1<<4)) goto XeusKEY651;
	local[4] = argv[0]->c.obj.iv[3];
XeusKEY651:
	local[5]= local[4];
	local[6]= fqv[62];
	local[7]= fqv[64];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= loadglobal(fqv[7]);
	local[6]= argv[0]->c.obj.iv[2];
	local[7]= local[4]->c.obj.iv[2];
	local[8]= local[0];
	local[9]= local[1];
	local[10]= local[2];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(*ftab[12])(ctx,7,local+5,&ftab[12],fqv[32]); /*fillrectangle*/
	local[5]= local[4];
	local[6]= fqv[62];
	local[7]= fqv[63];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[0]= w;
XeusBLK646:
	ctx->vsp=local; return(local[0]);}

/*:clear*/
static pointer XeusM652xdrawable_clear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[67];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
XeusBLK653:
	ctx->vsp=local; return(local[0]);}

/*:graph*/
static pointer XeusM654xdrawable_graph(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[68], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto XeusKEY656;
	local[0] = NIL;
XeusKEY656:
	if (n & (1<<1)) goto XeusKEY657;
	local[1] = NIL;
XeusKEY657:
	if (n & (1<<2)) goto XeusKEY658;
	local[2] = NIL;
XeusKEY658:
	if (n & (1<<3)) goto XeusKEY659;
	local[3] = argv[0]->c.obj.iv[3];
XeusKEY659:
	if (n & (1<<4)) goto XeusKEY660;
	local[4] = NIL;
XeusKEY660:
	if (n & (1<<5)) goto XeusKEY661;
	local[5] = NIL;
XeusKEY661:
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	if (local[4]==NIL) goto XeusIF662;
	local[14]= argv[0];
	local[15]= fqv[64];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	goto XeusIF663;
XeusIF662:
	local[14]= NIL;
XeusIF663:
	if (local[1]!=NIL) goto XeusIF664;
	w = argv[2];
	if (iscons(w)) goto XeusIF666;
	local[14]= argv[2];
	local[15]= loadglobal(fqv[69]);
	ctx->vsp=local+16;
	w=(pointer)COERCE(ctx,2,local+14); /*coerce*/
	argv[2] = w;
	local[14]= argv[2];
	goto XeusIF667;
XeusIF666:
	local[14]= NIL;
XeusIF667:
	local[14]= (pointer)get_sym_func(fqv[70]);
	local[15]= argv[2];
	ctx->vsp=local+16;
	w=(pointer)APPLY(ctx,2,local+14); /*apply*/
	local[1] = w;
	local[14]= local[1];
	goto XeusIF665;
XeusIF664:
	local[14]= NIL;
XeusIF665:
	if (local[2]!=NIL) goto XeusIF668;
	w = argv[2];
	if (iscons(w)) goto XeusIF670;
	local[14]= argv[2];
	local[15]= loadglobal(fqv[69]);
	ctx->vsp=local+16;
	w=(pointer)COERCE(ctx,2,local+14); /*coerce*/
	argv[2] = w;
	local[14]= argv[2];
	goto XeusIF671;
XeusIF670:
	local[14]= NIL;
XeusIF671:
	local[14]= (pointer)get_sym_func(fqv[71]);
	local[15]= argv[2];
	ctx->vsp=local+16;
	w=(pointer)APPLY(ctx,2,local+14); /*apply*/
	local[2] = w;
	local[14]= local[2];
	goto XeusIF669;
XeusIF668:
	local[14]= NIL;
XeusIF669:
	local[14]= local[1];
	ctx->vsp=local+15;
	w=(pointer)EUSFLOAT(ctx,1,local+14); /*float*/
	local[1] = w;
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)EUSFLOAT(ctx,1,local+14); /*float*/
	local[2] = w;
	if (local[0]==NIL) goto XeusIF672;
	local[14]= argv[0];
	local[15]= fqv[22];
	local[16]= local[0];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= w;
	goto XeusIF673;
XeusIF672:
	local[14]= NIL;
XeusIF673:
	local[14]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+15;
	w=(pointer)EUSFLOAT(ctx,1,local+14); /*float*/
	local[14]= w;
	local[15]= local[1];
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)MINUS(ctx,2,local+15); /*-*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[13] = w;
	if (local[5]!=NIL) goto XeusIF674;
	local[14]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+15;
	w=(pointer)EUSFLOAT(ctx,1,local+14); /*float*/
	local[14]= w;
	local[15]= local[6];
	ctx->vsp=local+16;
	w=(pointer)SUB1(ctx,1,local+15); /*1-*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[5] = w;
	local[14]= local[5];
	goto XeusIF675;
XeusIF674:
	local[14]= NIL;
XeusIF675:
	ctx->vsp=local+14;
	local[14]= makeclosure(codevec,quotevec,XeusFLET676,env,argv,local);
	local[15]= argv[2];
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	w = local[14];
	ctx->vsp=local+16;
	w=XeusFLET676(ctx,1,local+15,w);
	local[11] = w;
	local[15]= makeint((eusinteger_t)0L);
	local[16]= local[6];
	ctx->vsp=local+17;
	w=(pointer)SUB1(ctx,1,local+16); /*1-*/
	local[16]= w;
XeusWHL677:
	local[17]= local[15];
	w = local[16];
	if ((eusinteger_t)local[17] >= (eusinteger_t)w) goto XeusWHX678;
	local[17]= local[15];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[17]= w;
	local[18]= local[5];
	ctx->vsp=local+19;
	w=(pointer)TIMES(ctx,2,local+17); /***/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ROUND(ctx,1,local+17); /*round*/
	local[10] = w;
	local[17]= argv[2];
	local[18]= local[15];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	w = local[14];
	ctx->vsp=local+18;
	w=XeusFLET676(ctx,1,local+17,w);
	local[12] = w;
	local[17]= argv[0];
	local[18]= fqv[55];
	local[19]= local[9];
	local[20]= local[11];
	local[21]= local[10];
	local[22]= local[12];
	local[23]= local[3];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,7,local+17); /*send*/
	local[9] = local[10];
	local[11] = local[12];
	local[17]= local[15];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[15] = w;
	goto XeusWHL677;
XeusWHX678:
	local[17]= NIL;
XeusBLK679:
	w = NIL;
	local[0]= w;
XeusBLK655:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer XeusFLET676(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0]->c.obj.iv[6];
	local[1]= env->c.clo.env2[13];
	local[2]= argv[0];
	local[3]= env->c.clo.env2[2];
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)ROUND(ctx,1,local+0); /*round*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:3d-fill-rectangle*/
static pointer XeusM680xdrawable_3d_fill_rectangle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<11) maerror();
	if (n>=12) { local[0]=(argv[11]); goto XeusENT683;}
	local[0]= fqv[72];
XeusENT683:
XeusENT682:
	if (n>12) maerror();
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[22];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= local[0];
	local[5]= local[4];
	if (fqv[73]!=local[5]) goto XeusIF684;
	local[2] = argv[7];
	local[3] = argv[8];
	local[5]= local[3];
	goto XeusIF685;
XeusIF684:
	local[5]= local[4];
	if (fqv[74]!=local[5]) goto XeusIF686;
	local[2] = argv[8];
	local[3] = argv[7];
	local[5]= local[3];
	goto XeusIF687;
XeusIF686:
	if (T==NIL) goto XeusIF688;
	local[2] = argv[9];
	local[3] = argv[9];
	local[5]= local[3];
	goto XeusIF689;
XeusIF688:
	local[5]= NIL;
XeusIF689:
XeusIF687:
XeusIF685:
	w = local[5];
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[22];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[59];
	local[6]= argv[2];
	local[7]= argv[3];
	local[8]= argv[4];
	local[9]= argv[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,6,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[22];
	local[6]= argv[9];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[59];
	local[6]= argv[2];
	local[7]= argv[6];
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[7]= argv[3];
	local[8]= argv[6];
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	local[8]= argv[4];
	local[9]= argv[6];
	local[10]= argv[6];
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,3,local+8); /*-*/
	local[8]= w;
	local[9]= argv[5];
	local[10]= argv[6];
	local[11]= argv[6];
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,3,local+9); /*-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,6,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[22];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[75];
	local[6]= argv[10];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[22];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[0]= w;
XeusBLK681:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XeusM690xpixmap_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[76], &argv[2], n-2, local+0, 1);
	if (n & (1<<0)) goto XeusKEY692;
	local[0] = makeint((eusinteger_t)256L);
XeusKEY692:
	if (n & (1<<1)) goto XeusKEY693;
	local[1] = local[0];
XeusKEY693:
	if (n & (1<<2)) goto XeusKEY694;
	local[2] = local[1];
XeusKEY694:
	if (n & (1<<3)) goto XeusKEY695;
	local[5]= loadglobal(fqv[7]);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(*ftab[25])(ctx,2,local+5,&ftab[25],fqv[77]); /*defaultdepth*/
	local[3] = w;
XeusKEY695:
	if (n & (1<<4)) goto XeusKEY696;
	local[4] = loadglobal(fqv[78]);
XeusKEY696:
	local[5]= loadglobal(fqv[7]);
	local[6]= loadglobal(fqv[7]);
	ctx->vsp=local+7;
	w=(*ftab[26])(ctx,1,local+6,&ftab[26],fqv[79]); /*defaultrootwindow*/
	local[6]= w;
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[27])(ctx,5,local+5,&ftab[27],fqv[80]); /*createpixmap*/
	argv[0]->c.obj.iv[2] = w;
	local[5]= argv[0];
	local[6]= fqv[81];
	local[7]= argv[0]->c.obj.iv[2];
	local[8]= local[1];
	local[9]= local[2];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,6,local+5); /*send*/
	w = argv[0];
	local[0]= w;
XeusBLK691:
	ctx->vsp=local; return(local[0]);}

/*:create-from-bitmap-file*/
static pointer XeusM697xpixmap_create_from_bitmap_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[82]));
	local[2]= fqv[81];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)SENDMESSAGE(ctx,4,local+0); /*send-message*/
	local[0]= loadglobal(fqv[10]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= loadglobal(fqv[10]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= loadglobal(fqv[9]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= loadglobal(fqv[10]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= loadglobal(fqv[10]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= loadglobal(fqv[7]);
	local[6]= loadglobal(fqv[7]);
	ctx->vsp=local+7;
	w=(*ftab[26])(ctx,1,local+6,&ftab[26],fqv[79]); /*defaultrootwindow*/
	local[6]= w;
	local[7]= argv[2];
	local[8]= local[0];
	local[9]= local[1];
	local[10]= local[2];
	local[11]= local[3];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(*ftab[28])(ctx,8,local+5,&ftab[28],fqv[83]); /*readbitmapfile*/
	local[5]= loadglobal(fqv[7]);
	ctx->vsp=local+6;
	w=(*ftab[1])(ctx,1,local+5,&ftab[1],fqv[8]); /*flush*/
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[3])(ctx,1,local+5,&ftab[3],fqv[9]); /*c-long*/
	argv[0]->c.obj.iv[2] = w;
	w = argv[0];
	local[0]= w;
XeusBLK698:
	ctx->vsp=local; return(local[0]);}

/*:write-to-bitmap-file*/
static pointer XeusM699xpixmap_write_to_bitmap_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= argv[0];
	local[4]= fqv[25];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[26];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(*ftab[29])(ctx,7,local+0,&ftab[29],fqv[84]); /*writebitmapfile*/
	local[0]= loadglobal(fqv[7]);
	ctx->vsp=local+1;
	w=(*ftab[1])(ctx,1,local+0,&ftab[1],fqv[8]); /*flush*/
	local[0]= w;
XeusBLK700:
	ctx->vsp=local; return(local[0]);}

/*:destroy*/
static pointer XeusM701xpixmap_destroy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(*ftab[30])(ctx,2,local+0,&ftab[30],fqv[85]); /*freepixmap*/
	argv[0]->c.obj.iv[2] = NIL;
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
XeusBLK702:
	ctx->vsp=local; return(local[0]);}

/*make-pixmaps*/
static pointer XeusF327make_pixmaps(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[86], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto XeusKEY704;
	local[0] = makeint((eusinteger_t)500L);
XeusKEY704:
	if (n & (1<<1)) goto XeusKEY705;
	local[1] = local[0];
XeusKEY705:
	if (n & (1<<2)) goto XeusKEY706;
	local[2] = local[1];
XeusKEY706:
	if (n & (1<<3)) goto XeusKEY707;
	local[3] = loadglobal(fqv[87]);
XeusKEY707:
	local[4]= NIL;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0];
XeusWHL708:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto XeusWHX709;
	local[7]= loadglobal(fqv[88]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[3];
	local[10]= fqv[25];
	local[11]= local[1];
	local[12]= fqv[26];
	local[13]= local[2];
	local[14]= fqv[19];
	local[15]= local[3];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,8,local+8); /*send*/
	w = local[7];
	local[7]= w;
	w = local[4];
	ctx->vsp=local+8;
	local[4] = cons(ctx,local[7],w);
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= fqv[19];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto XeusWHL708;
XeusWHX709:
	local[7]= NIL;
XeusBLK710:
	w = NIL;
	w = local[4];
	local[0]= w;
XeusBLK703:
	ctx->vsp=local; return(local[0]);}

/*make-gray-pixmap*/
static pointer XeusF328make_gray_pixmap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[89], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto XeusKEY712;
	local[0] = loadglobal(fqv[90]);
XeusKEY712:
	if (n & (1<<1)) goto XeusKEY713;
	local[1] = loadglobal(fqv[91]);
XeusKEY713:
	if (n & (1<<2)) goto XeusKEY714;
	local[3]= loadglobal(fqv[7]);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(*ftab[25])(ctx,2,local+3,&ftab[25],fqv[77]); /*defaultdepth*/
	local[2] = w;
XeusKEY714:
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)32L);
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)FLOOR(ctx,1,local+3); /*floor*/
	local[3]= w;
	local[4]= loadglobal(fqv[92]);
	local[5]= makeint((eusinteger_t)32L);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,2,local+4); /*instantiate*/
	local[4]= w;
	local[5]= NIL;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[3];
XeusWHL715:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto XeusWHX716;
	local[8]= local[4];
	local[9]= fqv[93];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)ASET(ctx,3,local+8); /*aset*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto XeusWHL715;
XeusWHX716:
	local[8]= NIL;
XeusBLK717:
	w = NIL;
	local[6]= loadglobal(fqv[88]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[3];
	local[9]= fqv[25];
	local[10]= makeint((eusinteger_t)8L);
	local[11]= fqv[26];
	local[12]= makeint((eusinteger_t)4L);
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,6,local+7); /*send*/
	w = local[6];
	local[5] = w;
	local[6]= loadglobal(fqv[7]);
	local[7]= loadglobal(fqv[94]);
	local[8]= fqv[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= local[4];
	local[9]= makeint((eusinteger_t)8L);
	local[10]= makeint((eusinteger_t)4L);
	local[11]= local[0];
	local[12]= local[1];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(*ftab[31])(ctx,8,local+6,&ftab[31],fqv[95]); /*createpixmapfrombitmapdata*/
	local[4] = w;
	local[6]= local[4];
	local[7]= local[6];
	w = local[5];
	w->c.obj.iv[2] = local[7];
	w = local[5];
	local[0]= w;
XeusBLK711:
	ctx->vsp=local; return(local[0]);}

/*make-gray-gc*/
static pointer XeusF329make_gray_gc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[96], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto XeusKEY719;
	local[0] = loadglobal(fqv[90]);
XeusKEY719:
	if (n & (1<<1)) goto XeusKEY720;
	local[1] = loadglobal(fqv[91]);
XeusKEY720:
	if (n & (1<<2)) goto XeusKEY721;
	local[3]= loadglobal(fqv[7]);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(*ftab[25])(ctx,2,local+3,&ftab[25],fqv[77]); /*defaultdepth*/
	local[2] = w;
XeusKEY721:
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)32L);
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)FLOOR(ctx,1,local+3); /*floor*/
	local[3]= w;
	local[4]= loadglobal(fqv[92]);
	local[5]= makeint((eusinteger_t)32L);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,2,local+4); /*instantiate*/
	local[4]= w;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= loadglobal(fqv[2]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	w = local[7];
	local[6] = w;
	local[7]= local[6];
	local[8]= fqv[97];
	local[9]= fqv[98];
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[22];
	local[9]= local[0];
	local[10]= fqv[99];
	local[11]= local[1];
	local[12]= fqv[100];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)XeusF328make_gray_pixmap(ctx,7,local+7); /*make-gray-pixmap*/
	local[5] = w;
	local[7]= local[6];
	local[8]= fqv[101];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	w = local[6];
	local[0]= w;
XeusBLK718:
	ctx->vsp=local; return(local[0]);}

/*make-cleared-pixmap*/
static pointer XeusF330make_cleared_pixmap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto XeusENT725;}
	local[0]= argv[0];
XeusENT725:
	if (n>=3) { local[1]=(argv[2]); goto XeusENT724;}
	local[1]= loadglobal(fqv[91]);
XeusENT724:
XeusENT723:
	if (n>3) maerror();
	local[2]= loadglobal(fqv[88]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[3];
	local[5]= fqv[25];
	local[6]= argv[0];
	local[7]= fqv[26];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,6,local+3); /*send*/
	w = local[2];
	local[2]= w;
	local[3]= NIL;
	local[4]= local[2];
	local[5]= fqv[19];
	local[6]= fqv[22];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[3] = w;
	local[4]= local[2];
	local[5]= fqv[19];
	local[6]= fqv[22];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= local[2];
	local[5]= fqv[59];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[0];
	local[9]= local[0];
	local[10]= local[2];
	local[11]= fqv[19];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,7,local+4); /*send*/
	local[4]= local[2];
	local[5]= fqv[19];
	local[6]= fqv[22];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = local[2];
	local[0]= w;
XeusBLK722:
	ctx->vsp=local; return(local[0]);}

/*eventmask-to-value*/
static pointer XeusF331eventmask_to_value(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!isnum(w)) goto XeusCON728;
	local[0]= argv[0];
	goto XeusCON727;
XeusCON728:
	local[0]= makeint((eusinteger_t)0L);
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
XeusWHL730:
	if (local[3]==NIL) goto XeusWHX731;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	local[5]= fqv[102];
	ctx->vsp=local+6;
	w=(*ftab[32])(ctx,2,local+4,&ftab[32],fqv[103]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.car;
	if (local[1]==NIL) goto XeusIF733;
	local[4]= local[0];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)LOGIOR(ctx,2,local+4); /*logior*/
	local[0] = w;
	local[4]= local[0];
	goto XeusIF734;
XeusIF733:
	local[4]= fqv[104];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[33])(ctx,2,local+4,&ftab[33],fqv[105]); /*warn*/
	local[4]= w;
XeusIF734:
	goto XeusWHL730;
XeusWHX731:
	local[4]= NIL;
XeusBLK732:
	w = NIL;
	w = local[0];
	local[0]= w;
	goto XeusCON727;
XeusCON729:
	local[0]= NIL;
XeusCON727:
	w = local[0];
	local[0]= w;
XeusBLK726:
	ctx->vsp=local; return(local[0]);}

/*gravity-to-value*/
static pointer XeusF332gravity_to_value(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!issymbol(w)) goto XeusIF736;
	local[0]= argv[0];
	local[1]= fqv[106];
	ctx->vsp=local+2;
	w=(*ftab[32])(ctx,2,local+0,&ftab[32],fqv[103]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	local[0]= argv[0];
	goto XeusIF737;
XeusIF736:
	local[0]= NIL;
XeusIF737:
	w = argv[0];
	if (isint(w)) goto XeusIF738;
	local[0]= fqv[107];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,2,local+0); /*error*/
	local[0]= w;
	goto XeusIF739;
XeusIF738:
	local[0]= NIL;
XeusIF739:
	w = argv[0];
	local[0]= w;
XeusBLK735:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XeusM740xwindow_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[108], &argv[2], n-2, local+0, 1);
	if (n & (1<<0)) goto XeusKEY742;
	local[0] = loadglobal(fqv[94]);
XeusKEY742:
	if (n & (1<<1)) goto XeusKEY743;
	local[1] = makeint((eusinteger_t)0L);
XeusKEY743:
	if (n & (1<<2)) goto XeusKEY744;
	local[2] = makeint((eusinteger_t)0L);
XeusKEY744:
	if (n & (1<<3)) goto XeusKEY745;
	local[3] = makeint((eusinteger_t)256L);
XeusKEY745:
	if (n & (1<<4)) goto XeusKEY746;
	local[4] = local[3];
XeusKEY746:
	if (n & (1<<5)) goto XeusKEY747;
	local[5] = local[4];
XeusKEY747:
	if (n & (1<<6)) goto XeusKEY748;
	local[6] = makeint((eusinteger_t)2L);
XeusKEY748:
	if (n & (1<<7)) goto XeusKEY749;
	local[7] = loadglobal(fqv[90]);
XeusKEY749:
	if (n & (1<<8)) goto XeusKEY750;
	local[8] = NIL;
XeusKEY750:
	if (n & (1<<9)) goto XeusKEY751;
	local[9] = fqv[109];
XeusKEY751:
	if (n & (1<<10)) goto XeusKEY752;
	local[10] = NIL;
XeusKEY752:
	if (n & (1<<11)) goto XeusKEY753;
	local[11] = NIL;
XeusKEY753:
	if (n & (1<<12)) goto XeusKEY754;
	local[12] = NIL;
XeusKEY754:
	if (n & (1<<13)) goto XeusKEY755;
	local[24]= fqv[110];
	ctx->vsp=local+25;
	w=(pointer)GENSYM(ctx,1,local+24); /*gensym*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(*ftab[34])(ctx,1,local+24,&ftab[34],fqv[111]); /*string*/
	local[13] = w;
XeusKEY755:
	if (n & (1<<14)) goto XeusKEY756;
	local[14] = makeint((eusinteger_t)139279L);
XeusKEY756:
	if (n & (1<<15)) goto XeusKEY757;
	local[15] = NIL;
XeusKEY757:
	if (n & (1<<16)) goto XeusKEY758;
	local[16] = NIL;
XeusKEY758:
	if (n & (1<<17)) goto XeusKEY759;
	local[17] = NIL;
XeusKEY759:
	if (n & (1<<18)) goto XeusKEY760;
	local[18] = T;
XeusKEY760:
	if (n & (1<<19)) goto XeusKEY761;
	local[19] = loadglobal(fqv[112]);
XeusKEY761:
	if (n & (1<<20)) goto XeusKEY762;
	local[24]= local[19];
	ctx->vsp=local+25;
	w=(*ftab[21])(ctx,1,local+24,&ftab[21],fqv[46]); /*visual-depth*/
	local[20] = w;
XeusKEY762:
	if (n & (1<<21)) goto XeusKEY763;
	local[21] = NIL;
XeusKEY763:
	if (n & (1<<22)) goto XeusKEY764;
	local[22] = NIL;
XeusKEY764:
	if (n & (1<<23)) goto XeusKEY765;
	local[23] = fqv[113];
XeusKEY765:
	if (local[0]!=NIL) goto XeusIF766;
	local[0] = loadglobal(fqv[94]);
	local[24]= local[0];
	goto XeusIF767;
XeusIF766:
	local[24]= NIL;
XeusIF767:
	argv[0]->c.obj.iv[7] = local[0];
	argv[0]->c.obj.iv[9] = local[19];
	w = local[8];
	if (!isnum(w)) goto XeusCON769;
	local[24]= local[8];
	goto XeusCON768;
XeusCON769:
	local[24]= local[8];
	if (T!=local[24]) goto XeusCON770;
	local[24]= makeint((eusinteger_t)1L);
	goto XeusCON768;
XeusCON770:
	if (loadglobal(fqv[114])==NIL) goto XeusCON771;
	local[24]= makeint((eusinteger_t)1L);
	goto XeusCON768;
XeusCON771:
	local[24]= makeint((eusinteger_t)0L);
	goto XeusCON768;
XeusCON772:
	local[24]= NIL;
XeusCON768:
	local[8] = local[24];
	w = local[9];
	if (!isnum(w)) goto XeusCON774;
	local[24]= local[9];
	goto XeusCON773;
XeusCON774:
	if (loadglobal(fqv[114])!=NIL) goto XeusCON775;
	local[24]= makeint((eusinteger_t)0L);
	goto XeusCON773;
XeusCON775:
	local[24]= local[9];
	local[25]= fqv[115];
	ctx->vsp=local+26;
	w=(*ftab[32])(ctx,2,local+24,&ftab[32],fqv[103]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[24]= (w)->c.cons.car;
	goto XeusCON773;
XeusCON776:
	local[24]= NIL;
XeusCON773:
	local[9] = local[24];
	local[24]= local[14];
	ctx->vsp=local+25;
	w=(pointer)XeusF331eventmask_to_value(ctx,1,local+24); /*eventmask-to-value*/
	local[14] = w;
	local[24]= local[8];
	local[25]= makeint((eusinteger_t)0L);
	ctx->vsp=local+26;
	w=(pointer)NUMEQUAL(ctx,2,local+24); /*=*/
	if (w==NIL) goto XeusIF777;
	local[24]= local[14];
	local[25]= fqv[116];
	ctx->vsp=local+26;
	w=(pointer)XeusF331eventmask_to_value(ctx,1,local+25); /*eventmask-to-value*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)LOGIOR(ctx,2,local+24); /*logior*/
	local[14] = w;
	local[24]= local[14];
	goto XeusIF778;
XeusIF777:
	local[24]= NIL;
XeusIF778:
	local[24]= loadglobal(fqv[117]);
	local[25]= local[8];
	ctx->vsp=local+26;
	w=(pointer)XeusF270set_setwindowattributes_save_under(ctx,2,local+24); /*set-setwindowattributes-save_under*/
	local[24]= loadglobal(fqv[117]);
	local[25]= local[9];
	ctx->vsp=local+26;
	w=(pointer)XeusF264set_setwindowattributes_backing_store(ctx,2,local+24); /*set-setwindowattributes-backing_store*/
	local[24]= loadglobal(fqv[117]);
	local[25]= local[7];
	ctx->vsp=local+26;
	w=(pointer)XeusF258set_setwindowattributes_border_pixel(ctx,2,local+24); /*set-setwindowattributes-border_pixel*/
	local[24]= loadglobal(fqv[117]);
	local[25]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+26;
	w=(pointer)XeusF266set_setwindowattributes_backing_planes(ctx,2,local+24); /*set-setwindowattributes-backing_planes*/
	local[24]= loadglobal(fqv[117]);
	local[25]= makeint((eusinteger_t)0L);
	ctx->vsp=local+26;
	w=(pointer)XeusF268set_setwindowattributes_backing_pixel(ctx,2,local+24); /*set-setwindowattributes-backing_pixel*/
	local[24]= loadglobal(fqv[117]);
	local[25]= local[14];
	ctx->vsp=local+26;
	w=(pointer)XeusF272set_setwindowattributes_event_mask(ctx,2,local+24); /*set-setwindowattributes-event_mask*/
	local[24]= loadglobal(fqv[117]);
	local[25]= local[23];
	ctx->vsp=local+26;
	w=(pointer)XeusF332gravity_to_value(ctx,1,local+25); /*gravity-to-value*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)XeusF262set_setwindowattributes_win_gravity(ctx,2,local+24); /*set-setwindowattributes-win_gravity*/
	if (local[21]!=NIL) goto XeusIF779;
	local[24]= local[19];
	local[25]= loadglobal(fqv[112]);
	ctx->vsp=local+26;
	w=(pointer)NUMEQUAL(ctx,2,local+24); /*=*/
	if (w==NIL) goto XeusCON782;
	local[24]= argv[0]->c.obj.iv[7];
	local[25]= fqv[118];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,2,local+24); /*send*/
	local[21] = w;
	local[24]= local[21];
	goto XeusCON781;
XeusCON782:
	local[24]= loadglobal(fqv[119]);
	ctx->vsp=local+25;
	w=(pointer)INSTANTIATE(ctx,1,local+24); /*instantiate*/
	local[24]= w;
	local[25]= local[24];
	local[26]= fqv[3];
	local[27]= fqv[45];
	local[28]= local[19];
	ctx->vsp=local+29;
	w=(pointer)SEND(ctx,4,local+25); /*send*/
	w = local[24];
	local[21] = w;
	local[24]= local[21];
	local[25]= fqv[120];
	local[26]= loadglobal(fqv[121]);
	local[27]= makeint((eusinteger_t)0L);
	local[28]= makeint((eusinteger_t)32L);
	ctx->vsp=local+29;
	w=(pointer)SEND(ctx,5,local+24); /*send*/
	local[24]= w;
	goto XeusCON781;
XeusCON783:
	local[24]= NIL;
XeusCON781:
	goto XeusIF780;
XeusIF779:
	local[24]= NIL;
XeusIF780:
	local[24]= loadglobal(fqv[117]);
	local[25]= local[21];
	local[26]= fqv[122];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,2,local+25); /*send*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)XeusF278set_setwindowattributes_colormap(ctx,2,local+24); /*set-setwindowattributes-colormap*/
	local[24]= loadglobal(fqv[117]);
	if (local[22]==NIL) goto XeusIF784;
	local[25]= makeint((eusinteger_t)1L);
	goto XeusIF785;
XeusIF784:
	local[25]= makeint((eusinteger_t)0L);
XeusIF785:
	ctx->vsp=local+26;
	w=(pointer)XeusF276set_setwindowattributes_override_redirect(ctx,2,local+24); /*set-setwindowattributes-override_redirect*/
	local[24]= loadglobal(fqv[7]);
	local[25]= argv[0]->c.obj.iv[7];
	local[26]= fqv[4];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,2,local+25); /*send*/
	local[25]= w;
	local[26]= local[1];
	local[27]= local[2];
	local[28]= local[4];
	local[29]= local[5];
	local[30]= local[6];
	local[31]= local[20];
	local[32]= makeint((eusinteger_t)0L);
	local[33]= local[19];
	local[34]= makeint((eusinteger_t)12264L);
	local[35]= loadglobal(fqv[117]);
	ctx->vsp=local+36;
	w=(*ftab[35])(ctx,12,local+24,&ftab[35],fqv[123]); /*createwindow*/
	argv[0]->c.obj.iv[2] = w;
	local[24]= loadglobal(fqv[7]);
	local[25]= argv[0]->c.obj.iv[2];
	local[26]= local[13];
	ctx->vsp=local+27;
	w=(*ftab[36])(ctx,3,local+24,&ftab[36],fqv[124]); /*storename*/
	local[24]= argv[0];
	local[25]= fqv[81];
	local[26]= argv[0]->c.obj.iv[2];
	local[27]= local[4];
	local[28]= local[5];
	local[29]= local[15];
	ctx->vsp=local+30;
	w=(pointer)SEND(ctx,6,local+24); /*send*/
	local[24]= local[12];
	if (local[12]!=NIL) goto XeusIF786;
	if (argv[0]->c.obj.iv[7]==NIL) goto XeusIF788;
	local[25]= argv[0]->c.obj.iv[7];
	local[26]= loadglobal(fqv[94]);
	ctx->vsp=local+27;
	w=(pointer)EQ(ctx,2,local+25); /*eql*/
	if (w!=NIL) goto XeusIF788;
	local[25]= argv[0]->c.obj.iv[7];
	local[26]= fqv[19];
	local[27]= fqv[99];
	local[28]= NIL;
	local[29]= local[21];
	ctx->vsp=local+30;
	w=(pointer)SEND(ctx,5,local+25); /*send*/
	local[25]= w;
	goto XeusIF789;
XeusIF788:
	local[25]= loadglobal(fqv[91]);
XeusIF789:
	local[12] = local[25];
	local[25]= local[12];
	goto XeusIF787;
XeusIF786:
	local[25]= NIL;
XeusIF787:
	local[25]= local[21];
	local[26]= fqv[125];
	local[27]= local[12];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,3,local+25); /*send*/
	local[12] = w;
	w = local[12];
	if (isnum(w)) goto XeusIF790;
	local[25]= fqv[126];
	local[26]= local[24];
	ctx->vsp=local+27;
	w=(*ftab[33])(ctx,2,local+25,&ftab[33],fqv[105]); /*warn*/
	local[12] = loadglobal(fqv[91]);
	local[25]= local[12];
	goto XeusIF791;
XeusIF790:
	local[25]= NIL;
XeusIF791:
	w = local[25];
	local[24]= argv[0]->c.obj.iv[3];
	local[25]= fqv[22];
	local[26]= local[11];
	if (local[26]!=NIL) goto XeusCON792;
XeusCON793:
	if (argv[0]->c.obj.iv[7]==NIL) goto XeusCON794;
	local[26]= argv[0]->c.obj.iv[7];
	local[27]= fqv[22];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,2,local+26); /*send*/
	local[26]= w;
	goto XeusCON792;
XeusCON794:
	local[26]= loadglobal(fqv[90]);
	goto XeusCON792;
XeusCON795:
	local[26]= NIL;
XeusCON792:
	local[27]= local[21];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,4,local+24); /*send*/
	argv[0]->c.obj.iv[4] = local[12];
	local[24]= loadglobal(fqv[7]);
	local[25]= argv[0]->c.obj.iv[2];
	local[26]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+27;
	w=(*ftab[37])(ctx,3,local+24,&ftab[37],fqv[127]); /*setwindowbackground*/
	if (local[10]==NIL) goto XeusIF796;
	local[24]= loadglobal(fqv[88]);
	ctx->vsp=local+25;
	w=(pointer)INSTANTIATE(ctx,1,local+24); /*instantiate*/
	local[24]= w;
	local[25]= local[24];
	local[26]= fqv[3];
	local[27]= fqv[25];
	local[28]= local[4];
	local[29]= fqv[26];
	local[30]= local[5];
	ctx->vsp=local+31;
	w=(pointer)SEND(ctx,6,local+25); /*send*/
	w = local[24];
	argv[0]->c.obj.iv[10] = w;
	local[24]= argv[0]->c.obj.iv[10];
	goto XeusIF797;
XeusIF796:
	local[24]= NIL;
XeusIF797:
	local[24]= loadglobal(fqv[7]);
	local[25]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+26;
	w=(*ftab[38])(ctx,2,local+24,&ftab[38],fqv[128]); /*clearwindow*/
	if (local[18]==NIL) goto XeusIF798;
	local[24]= loadglobal(fqv[7]);
	local[25]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+26;
	w=(*ftab[39])(ctx,2,local+24,&ftab[39],fqv[129]); /*mapwindow*/
	local[24]= w;
	goto XeusIF799;
XeusIF798:
	local[24]= NIL;
XeusIF799:
	if (argv[0]->c.obj.iv[7]==NIL) goto XeusIF800;
	local[24]= argv[0]->c.obj.iv[7];
	local[25]= fqv[130];
	local[26]= argv[0];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,3,local+24); /*send*/
	local[24]= w;
	goto XeusIF801;
XeusIF800:
	local[24]= NIL;
XeusIF801:
	local[24]= argv[0];
	w = loadglobal(fqv[131]);
	ctx->vsp=local+25;
	local[24]= cons(ctx,local[24],w);
	storeglobal(fqv[131],local[24]);
	if (local[16]==NIL) goto XeusCON803;
	local[24]= argv[0]->c.obj.iv[3];
	local[25]= fqv[132];
	local[26]= local[16];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,3,local+24); /*send*/
	local[24]= w;
	goto XeusCON802;
XeusCON803:
	if (argv[0]->c.obj.iv[7]==NIL) goto XeusCON804;
	local[24]= argv[0]->c.obj.iv[3];
	local[25]= fqv[132];
	local[26]= argv[0]->c.obj.iv[7];
	local[27]= fqv[19];
	local[28]= fqv[132];
	ctx->vsp=local+29;
	w=(pointer)SEND(ctx,3,local+26); /*send*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,3,local+24); /*send*/
	local[24]= w;
	goto XeusCON802;
XeusCON804:
	local[24]= NIL;
XeusCON802:
	if (local[17]==NIL) goto XeusIF805;
	local[24]= argv[0];
	local[25]= fqv[133];
	local[26]= local[17];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,3,local+24); /*send*/
	local[24]= w;
	goto XeusIF806;
XeusIF805:
	local[24]= argv[0];
	local[25]= fqv[133];
	local[26]= local[13];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,3,local+24); /*send*/
	local[24]= w;
XeusIF806:
	local[24]= argv[0]->c.obj.iv[3];
	local[25]= fqv[99];
	local[26]= argv[0]->c.obj.iv[4];
	local[27]= local[21];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,4,local+24); /*send*/
	local[24]= loadglobal(fqv[7]);
	ctx->vsp=local+25;
	w=(*ftab[1])(ctx,1,local+24,&ftab[1],fqv[8]); /*flush*/
	w = argv[0];
	local[0]= w;
XeusBLK741:
	ctx->vsp=local; return(local[0]);}

/*:subwindows*/
static pointer XeusM807xwindow_subwindows(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XeusENT810;}
	local[0]= NIL;
XeusENT810:
XeusENT809:
	if (n>3) maerror();
	if (local[0]==NIL) goto XeusIF811;
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+3;
	w=(pointer)NTH(ctx,2,local+1); /*nth*/
	local[1]= w;
	goto XeusIF812;
XeusIF811:
	local[1]= argv[0]->c.obj.iv[8];
XeusIF812:
	w = local[1];
	local[0]= w;
XeusBLK808:
	ctx->vsp=local; return(local[0]);}

/*:map*/
static pointer XeusM813xwindow_map(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= fqv[134];
	ctx->vsp=local+2;
	w=(*ftab[40])(ctx,2,local+0,&ftab[40],fqv[135]); /*send-all*/
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(*ftab[39])(ctx,2,local+0,&ftab[39],fqv[129]); /*mapwindow*/
	local[0]= w;
XeusBLK814:
	ctx->vsp=local; return(local[0]);}

/*:unmap*/
static pointer XeusM815xwindow_unmap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= fqv[136];
	ctx->vsp=local+2;
	w=(*ftab[40])(ctx,2,local+0,&ftab[40],fqv[135]); /*send-all*/
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(*ftab[41])(ctx,2,local+0,&ftab[41],fqv[137]); /*unmapwindow*/
	local[0]= w;
XeusBLK816:
	ctx->vsp=local; return(local[0]);}

/*:remap*/
static pointer XeusM817xwindow_remap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[136];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= loadglobal(fqv[7]);
	ctx->vsp=local+1;
	w=(*ftab[1])(ctx,1,local+0,&ftab[1],fqv[8]); /*flush*/
	local[0]= argv[0];
	local[1]= fqv[134];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= loadglobal(fqv[7]);
	ctx->vsp=local+1;
	w=(*ftab[1])(ctx,1,local+0,&ftab[1],fqv[8]); /*flush*/
	local[0]= w;
XeusBLK818:
	ctx->vsp=local; return(local[0]);}

/*:parent*/
static pointer XeusM819xwindow_parent(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[7];
	local[0]= w;
XeusBLK820:
	ctx->vsp=local; return(local[0]);}

/*:associate*/
static pointer XeusM821xwindow_associate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= fqv[138];
	local[3]= NIL;
	local[4]= fqv[139];
	local[5]= NIL;
	local[6]= fqv[140];
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(*ftab[42])(ctx,8,local+0,&ftab[42],fqv[141]); /*member*/
	if (w!=NIL) goto XeusIF823;
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[8];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[8] = cons(ctx,local[0],w);
	local[0]= argv[0]->c.obj.iv[8];
	goto XeusIF824;
XeusIF823:
	local[0]= NIL;
XeusIF824:
	w = NIL;
	local[0]= w;
XeusBLK822:
	ctx->vsp=local; return(local[0]);}

/*:dissociate*/
static pointer XeusM825xwindow_dissociate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(*ftab[43])(ctx,2,local+0,&ftab[43],fqv[142]); /*delete*/
	argv[0]->c.obj.iv[8] = w;
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
XeusBLK826:
	ctx->vsp=local; return(local[0]);}

/*:reparent*/
static pointer XeusM827xwindow_reparent(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XeusENT831;}
	local[0]= makeint((eusinteger_t)0L);
XeusENT831:
	if (n>=5) { local[1]=(argv[4]); goto XeusENT830;}
	local[1]= makeint((eusinteger_t)0L);
XeusENT830:
XeusENT829:
	if (n>5) maerror();
	w = argv[2];
	if (isint(w)) goto XeusIF832;
	local[2]= argv[2];
	local[3]= fqv[4];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	argv[2] = w;
	local[2]= argv[2];
	goto XeusIF833;
XeusIF832:
	local[2]= NIL;
XeusIF833:
	local[2]= loadglobal(fqv[7]);
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= argv[2];
	local[5]= local[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[44])(ctx,5,local+2,&ftab[44],fqv[143]); /*reparentwindow*/
	argv[0]->c.obj.iv[7] = argv[2];
	w = argv[0]->c.obj.iv[7];
	local[0]= w;
XeusBLK828:
	ctx->vsp=local; return(local[0]);}

/*:destroy*/
static pointer XeusM834xwindow_destroy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= fqv[144];
	ctx->vsp=local+2;
	w=(*ftab[40])(ctx,2,local+0,&ftab[40],fqv[135]); /*send-all*/
	if (argv[0]->c.obj.iv[2]==NIL) goto XeusIF836;
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	argv[0]->c.obj.iv[2] = NIL;
	w = local[1];
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[45])(ctx,2,local+0,&ftab[45],fqv[145]); /*destroywindow*/
	local[0]= w;
	goto XeusIF837;
XeusIF836:
	local[0]= NIL;
XeusIF837:
	if (argv[0]->c.obj.iv[7]==NIL) goto XeusIF838;
	local[0]= argv[0]->c.obj.iv[7];
	local[1]= fqv[146];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	argv[0]->c.obj.iv[7] = NIL;
	local[0]= argv[0]->c.obj.iv[7];
	goto XeusIF839;
XeusIF838:
	local[0]= NIL;
XeusIF839:
	local[0]= argv[0];
	local[1]= loadglobal(fqv[131]);
	ctx->vsp=local+2;
	w=(*ftab[43])(ctx,2,local+0,&ftab[43],fqv[142]); /*delete*/
	local[0]= w;
	storeglobal(fqv[131],w);
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= loadglobal(fqv[5]);
	ctx->vsp=local+2;
	w=(*ftab[46])(ctx,2,local+0,&ftab[46],fqv[147]); /*remhash*/
	local[0]= w;
XeusBLK835:
	ctx->vsp=local; return(local[0]);}

/*:attributes*/
static pointer XeusM840xwindow_attributes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= loadglobal(fqv[148]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[1] = w;
	local[2]= loadglobal(fqv[7]);
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[5])(ctx,3,local+2,&ftab[5],fqv[14]); /*getwindowattributes*/
	w = local[1];
	local[0]= w;
XeusBLK841:
	ctx->vsp=local; return(local[0]);}

/*:event-mask*/
static pointer XeusM842xwindow_event_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[149];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[15];
	local[2]= fqv[150];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XeusBLK843:
	ctx->vsp=local; return(local[0]);}

/*:selectinput*/
static pointer XeusM844xwindow_selectinput(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XeusF331eventmask_to_value(ctx,1,local+2); /*eventmask-to-value*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[47])(ctx,3,local+0,&ftab[47],fqv[151]); /*selectinput*/
	local[0]= w;
XeusBLK845:
	ctx->vsp=local; return(local[0]);}

/*:visual*/
static pointer XeusM846xwindow_visual(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[9]==NIL) goto XeusIF848;
	local[0]= argv[0]->c.obj.iv[9];
	goto XeusIF849;
XeusIF848:
	local[0]= argv[0];
	local[1]= fqv[149];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[15];
	local[2]= fqv[152];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XeusIF849:
	w = local[0];
	local[0]= w;
XeusBLK847:
	ctx->vsp=local; return(local[0]);}

/*:location*/
static pointer XeusM850xwindow_location(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[149];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[15];
	local[4]= fqv[16];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= local[1];
	local[4]= fqv[15];
	local[5]= fqv[17];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MKINTVECTOR(ctx,2,local+2); /*integer-vector*/
	local[0]= w;
XeusBLK851:
	ctx->vsp=local; return(local[0]);}

/*:size*/
static pointer XeusM852xwindow_size(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[149];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[15];
	local[4]= fqv[153];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= local[1];
	local[4]= fqv[15];
	local[5]= fqv[154];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MKINTVECTOR(ctx,2,local+2); /*integer-vector*/
	local[0]= w;
XeusBLK853:
	ctx->vsp=local; return(local[0]);}

/*:depth*/
static pointer XeusM854xwindow_depth(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[149];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[15];
	local[2]= fqv[155];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XeusBLK855:
	ctx->vsp=local; return(local[0]);}

/*:screen*/
static pointer XeusM856xwindow_screen(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[149];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[15];
	local[2]= fqv[156];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XeusBLK857:
	ctx->vsp=local; return(local[0]);}

/*:colormap*/
static pointer XeusM858xwindow_colormap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[149];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[15];
	local[2]= fqv[119];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= loadglobal(fqv[5]);
	ctx->vsp=local+2;
	w=(*ftab[48])(ctx,2,local+0,&ftab[48],fqv[157]); /*gethash*/
	local[0]= w;
	local[1]= local[0];
	local[2]= loadglobal(fqv[119]);
	ctx->vsp=local+3;
	w=(pointer)DERIVEDP(ctx,2,local+1); /*derivedp*/
	if (w!=NIL) goto XeusIF860;
	local[1]= makeint((eusinteger_t)2L);
	local[2]= fqv[158];
	local[3]= argv[0];
	local[4]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+5;
	w=(*ftab[49])(ctx,4,local+1,&ftab[49],fqv[159]); /*warning-message*/
	local[0] = loadglobal(fqv[121]);
	local[1]= local[0];
	goto XeusIF861;
XeusIF860:
	local[1]= NIL;
XeusIF861:
	w = local[0];
	local[0]= w;
XeusBLK859:
	ctx->vsp=local; return(local[0]);}

/*:root*/
static pointer XeusM862xwindow_root(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[149];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[15];
	local[2]= fqv[160];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XeusBLK863:
	ctx->vsp=local; return(local[0]);}

/*:title*/
static pointer XeusM864xwindow_title(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[36])(ctx,3,local+0,&ftab[36],fqv[124]); /*storename*/
	local[0]= loadglobal(fqv[7]);
	ctx->vsp=local+1;
	w=(*ftab[1])(ctx,1,local+0,&ftab[1],fqv[8]); /*flush*/
	local[0]= w;
XeusBLK865:
	ctx->vsp=local; return(local[0]);}

/*:background*/
static pointer XeusM866xwindow_background(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XeusENT869;}
	local[0]= NIL;
XeusENT869:
XeusENT868:
	if (n>3) maerror();
	if (local[0]==NIL) goto XeusIF870;
	local[1]= loadglobal(fqv[7]);
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[37])(ctx,3,local+1,&ftab[37],fqv[127]); /*setwindowbackground*/
	argv[0]->c.obj.iv[4] = local[0];
	local[1]= argv[0];
	local[2]= fqv[64];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto XeusIF871;
XeusIF870:
	local[1]= NIL;
XeusIF871:
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
XeusBLK867:
	ctx->vsp=local; return(local[0]);}

/*:background-pixmap*/
static pointer XeusM872xwindow_background_pixmap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[2];
	local[3]= fqv[4];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[50])(ctx,3,local+0,&ftab[50],fqv[161]); /*setwindowbackgroundpixmap*/
	local[0]= argv[0];
	local[1]= fqv[64];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
XeusBLK873:
	ctx->vsp=local; return(local[0]);}

/*:border*/
static pointer XeusM874xwindow_border(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[51])(ctx,3,local+0,&ftab[51],fqv[162]); /*setwindowborder*/
	local[0]= w;
XeusBLK875:
	ctx->vsp=local; return(local[0]);}

/*:save*/
static pointer XeusM876xwindow_save(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[10];
	local[1]= fqv[163];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= loadglobal(fqv[7]);
	ctx->vsp=local+1;
	w=(*ftab[1])(ctx,1,local+0,&ftab[1],fqv[8]); /*flush*/
	local[0]= w;
XeusBLK877:
	ctx->vsp=local; return(local[0]);}

/*:refresh*/
static pointer XeusM878xwindow_refresh(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[82]));
	local[2]= fqv[163];
	local[3]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+4;
	w=(pointer)SENDMESSAGE(ctx,4,local+0); /*send-message*/
	local[0]= loadglobal(fqv[7]);
	ctx->vsp=local+1;
	w=(*ftab[1])(ctx,1,local+0,&ftab[1],fqv[8]); /*flush*/
	local[0]= w;
XeusBLK879:
	ctx->vsp=local; return(local[0]);}

/*:move*/
static pointer XeusM880xwindow_move(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(*ftab[52])(ctx,4,local+0,&ftab[52],fqv[164]); /*movewindow*/
	local[0]= w;
XeusBLK881:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer XeusM882xwindow_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(*ftab[53])(ctx,4,local+0,&ftab[53],fqv[165]); /*resizewindow*/
	argv[0]->c.obj.iv[5] = argv[2];
	argv[0]->c.obj.iv[6] = argv[3];
	w = argv[0]->c.obj.iv[6];
	local[0]= w;
XeusBLK883:
	ctx->vsp=local; return(local[0]);}

/*:raise*/
static pointer XeusM884xwindow_raise(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(*ftab[54])(ctx,2,local+0,&ftab[54],fqv[166]); /*raisewindow*/
	local[0]= w;
XeusBLK885:
	ctx->vsp=local; return(local[0]);}

/*:lower*/
static pointer XeusM886xwindow_lower(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(*ftab[55])(ctx,2,local+0,&ftab[55],fqv[167]); /*lowerwindow*/
	local[0]= w;
XeusBLK887:
	ctx->vsp=local; return(local[0]);}

/*:write-to-bitmap-file*/
static pointer XeusM888xwindow_write_to_bitmap_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[10];
	local[1]= fqv[168];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XeusBLK889:
	ctx->vsp=local; return(local[0]);}

/*:clear*/
static pointer XeusM890xwindow_clear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(*ftab[38])(ctx,2,local+0,&ftab[38],fqv[128]); /*clearwindow*/
	local[0]= w;
XeusBLK891:
	ctx->vsp=local; return(local[0]);}

/*:clear-area*/
static pointer XeusM892xwindow_clear_area(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[169], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto XeusKEY894;
	local[0] = makeint((eusinteger_t)0L);
XeusKEY894:
	if (n & (1<<1)) goto XeusKEY895;
	local[1] = makeint((eusinteger_t)0L);
XeusKEY895:
	if (n & (1<<2)) goto XeusKEY896;
	local[2] = makeint((eusinteger_t)0L);
XeusKEY896:
	if (n & (1<<3)) goto XeusKEY897;
	local[3] = makeint((eusinteger_t)0L);
XeusKEY897:
	local[4]= loadglobal(fqv[7]);
	local[5]= argv[0]->c.obj.iv[2];
	local[6]= local[0];
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[3];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(*ftab[56])(ctx,7,local+4,&ftab[56],fqv[170]); /*cleararea*/
	local[0]= w;
XeusBLK893:
	ctx->vsp=local; return(local[0]);}

/*:set-colormap*/
static pointer XeusM898xwindow_set_colormap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= *(ovafptr(argv[2],fqv[171]));
	ctx->vsp=local+3;
	w=(*ftab[57])(ctx,3,local+0,&ftab[57],fqv[172]); /*setwindowcolormap*/
	local[0]= w;
XeusBLK899:
	ctx->vsp=local; return(local[0]);}

/*:copy*/
static pointer XeusM900xwindow_copy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XeusRST902:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= (pointer)get_sym_func(fqv[18]);
	local[3]= local[1];
	local[4]= fqv[3];
	local[5]= fqv[25];
	local[6]= argv[0];
	local[7]= fqv[25];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[26];
	local[8]= argv[0];
	local[9]= fqv[26];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)APPLY(ctx,8,local+2); /*apply*/
	w = local[1];
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[163];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	w = local[1];
	local[0]= w;
XeusBLK901:
	ctx->vsp=local; return(local[0]);}

/*geometry::default-viewsurface*/
static pointer XeusF333geometry__default_viewsurface(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
XeusRST904:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= (pointer)get_sym_func(fqv[18]);
	local[2]= loadglobal(fqv[173]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= fqv[3];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[0]= w;
XeusBLK903:
	ctx->vsp=local; return(local[0]);}

/*:draw-lines*/
static pointer XeusM905xdrawable_draw_lines(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XeusENT909;}
	local[0]= makeint((eusinteger_t)0L);
XeusENT909:
	if (n>=5) { local[1]=(argv[4]); goto XeusENT908;}
	local[1]= argv[0]->c.obj.iv[3];
XeusENT908:
XeusENT907:
	if (n>5) maerror();
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	local[3]= loadglobal(fqv[111]);
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)4L);
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,2,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[174];
	local[6]= argv[2];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= fqv[175];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= loadglobal(fqv[7]);
	local[5]= argv[0]->c.obj.iv[2];
	local[6]= local[1]->c.obj.iv[2];
	local[7]= local[3];
	local[8]= local[2];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(*ftab[58])(ctx,6,local+4,&ftab[58],fqv[176]); /*drawlines*/
	local[0]= w;
XeusBLK906:
	ctx->vsp=local; return(local[0]);}

/*:draw-polygon*/
static pointer XeusM910xdrawable_draw_polygon(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XeusENT913;}
	local[0]= argv[0]->c.obj.iv[3];
XeusENT913:
XeusENT912:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[177];
	local[3]= argv[2];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)APPEND(ctx,2,local+3); /*append*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
XeusBLK911:
	ctx->vsp=local; return(local[0]);}

/*:fill-polygon*/
static pointer XeusM914xdrawable_fill_polygon(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XeusENT919;}
	local[0]= makeint((eusinteger_t)0L);
XeusENT919:
	if (n>=5) { local[1]=(argv[4]); goto XeusENT918;}
	local[1]= makeint((eusinteger_t)0L);
XeusENT918:
	if (n>=6) { local[2]=(argv[5]); goto XeusENT917;}
	local[2]= argv[0]->c.obj.iv[3];
XeusENT917:
XeusENT916:
	if (n>6) maerror();
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)VECTORP(ctx,1,local+5); /*vectorp*/
	if (w==NIL) goto XeusCON921;
	local[4] = argv[2];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)4L);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[3] = w;
	local[5]= local[3];
	goto XeusCON920;
XeusCON921:
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[3] = w;
	local[5]= loadglobal(fqv[111]);
	local[6]= makeint((eusinteger_t)4L);
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,2,local+5); /*instantiate*/
	local[4] = w;
	local[5]= local[4];
	local[6]= fqv[174];
	local[7]= argv[2];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= fqv[175];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	local[5]= w;
	goto XeusCON920;
XeusCON922:
	local[5]= NIL;
XeusCON920:
	local[5]= loadglobal(fqv[7]);
	local[6]= argv[0]->c.obj.iv[2];
	local[7]= local[2]->c.obj.iv[2];
	local[8]= local[4];
	local[9]= local[3];
	local[10]= local[0];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(*ftab[59])(ctx,7,local+5,&ftab[59],fqv[178]); /*fillpolygon*/
	local[0]= w;
XeusBLK915:
	ctx->vsp=local; return(local[0]);}

/*:override_redirect*/
static pointer XeusM923xwindow_override_redirect(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XeusENT926;}
	local[0]= makeint((eusinteger_t)1L);
XeusENT926:
XeusENT925:
	if (n>3) maerror();
	local[1]= loadglobal(fqv[117]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)XeusF276set_setwindowattributes_override_redirect(ctx,2,local+1); /*set-setwindowattributes-override_redirect*/
	local[1]= loadglobal(fqv[7]);
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= makeint((eusinteger_t)1L);
	local[4]= makeint((eusinteger_t)9L);
	ctx->vsp=local+5;
	w=(pointer)ASH(ctx,2,local+3); /*ash*/
	local[3]= w;
	local[4]= loadglobal(fqv[117]);
	ctx->vsp=local+5;
	w=(*ftab[60])(ctx,4,local+1,&ftab[60],fqv[179]); /*changewindowattributes*/
	local[0]= w;
XeusBLK924:
	ctx->vsp=local; return(local[0]);}

/*:save_under*/
static pointer XeusM927xwindow_save_under(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XeusENT930;}
	local[0]= makeint((eusinteger_t)1L);
XeusENT930:
XeusENT929:
	if (n>3) maerror();
	local[1]= loadglobal(fqv[117]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)XeusF270set_setwindowattributes_save_under(ctx,2,local+1); /*set-setwindowattributes-save_under*/
	local[1]= loadglobal(fqv[7]);
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= makeint((eusinteger_t)1L);
	local[4]= makeint((eusinteger_t)10L);
	ctx->vsp=local+5;
	w=(pointer)ASH(ctx,2,local+3); /*ash*/
	local[3]= w;
	local[4]= loadglobal(fqv[117]);
	ctx->vsp=local+5;
	w=(*ftab[60])(ctx,4,local+1,&ftab[60],fqv[179]); /*changewindowattributes*/
	local[0]= w;
XeusBLK928:
	ctx->vsp=local; return(local[0]);}

/*:settransientforhint*/
static pointer XeusM931xwindow_settransientforhint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[0]->c.obj.iv[7];
	local[3]= fqv[4];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[61])(ctx,3,local+0,&ftab[61],fqv[180]); /*settransientforhint*/
	local[0]= w;
XeusBLK932:
	ctx->vsp=local; return(local[0]);}

/*:querypointer*/
static pointer XeusM933xwindow_querypointer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[9]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= loadglobal(fqv[9]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= loadglobal(fqv[10]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= loadglobal(fqv[10]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= loadglobal(fqv[10]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= loadglobal(fqv[10]);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,1,local+5); /*instantiate*/
	local[5]= w;
	local[6]= loadglobal(fqv[10]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= loadglobal(fqv[7]);
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= local[0];
	local[10]= local[1];
	local[11]= local[2];
	local[12]= local[3];
	local[13]= local[4];
	local[14]= local[5];
	local[15]= local[6];
	ctx->vsp=local+16;
	w=(*ftab[62])(ctx,9,local+7,&ftab[62],fqv[181]); /*querypointer*/
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(*ftab[3])(ctx,1,local+7,&ftab[3],fqv[9]); /*c-long*/
	local[7]= w;
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(*ftab[3])(ctx,1,local+8,&ftab[3],fqv[9]); /*c-long*/
	local[8]= w;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,1,local+9,&ftab[4],fqv[10]); /*c-int*/
	local[9]= w;
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(*ftab[4])(ctx,1,local+10,&ftab[4],fqv[10]); /*c-int*/
	local[10]= w;
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(*ftab[4])(ctx,1,local+11,&ftab[4],fqv[10]); /*c-int*/
	local[11]= w;
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(*ftab[4])(ctx,1,local+12,&ftab[4],fqv[10]); /*c-int*/
	local[12]= w;
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(*ftab[4])(ctx,1,local+13,&ftab[4],fqv[10]); /*c-int*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,7,local+7); /*list*/
	local[0]= w;
XeusBLK934:
	ctx->vsp=local; return(local[0]);}

/*:global-pos*/
static pointer XeusM935xwindow_global_pos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[182];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)4L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)5L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MKINTVECTOR(ctx,2,local+1); /*integer-vector*/
	local[0]= w;
XeusBLK936:
	ctx->vsp=local; return(local[0]);}

/*make-xwindow*/
static pointer XeusF334make_xwindow(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
XeusRST938:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= (pointer)get_sym_func(fqv[18]);
	local[2]= loadglobal(fqv[173]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= fqv[3];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[0]= w;
XeusBLK937:
	ctx->vsp=local; return(local[0]);}

/*find-xwindow*/
static pointer XeusF335find_xwindow(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,XeusCLO940,env,argv,local);
	local[1]= loadglobal(fqv[131]);
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
XeusBLK939:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer XeusCLO940(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[133];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[34])(ctx,1,local+1,&ftab[34],fqv[111]); /*string*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[63])(ctx,2,local+0,&ftab[63],fqv[183]); /*substringp*/
	if (w==NIL) goto XeusIF941;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto XeusIF942;
XeusIF941:
	local[0]= NIL;
XeusIF942:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___Xeus(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[184];
	local[1]= fqv[185];
	ctx->vsp=local+2;
	w=(*ftab[64])(ctx,2,local+0,&ftab[64],fqv[186]); /*require*/
	local[0]= fqv[187];
	local[1]= fqv[188];
	ctx->vsp=local+2;
	w=(*ftab[64])(ctx,2,local+0,&ftab[64],fqv[186]); /*require*/
	local[0]= fqv[189];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto XeusIF943;
	local[0]= fqv[190];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[191],w);
	goto XeusIF944;
XeusIF943:
	local[0]= fqv[192];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
XeusIF944:
	local[0]= fqv[114];
	local[1]= fqv[193];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XeusIF945;
	local[0]= fqv[114];
	local[1]= fqv[193];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[114];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XeusIF947;
	local[0]= fqv[114];
	local[1]= fqv[194];
	local[2]= T;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XeusIF948;
XeusIF947:
	local[0]= NIL;
XeusIF948:
	local[0]= fqv[114];
	goto XeusIF946;
XeusIF945:
	local[0]= NIL;
XeusIF946:
	local[0]= fqv[195];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[196];
	local[1]= fqv[194];
	local[2]= fqv[196];
	local[3]= fqv[197];
	local[4]= loadglobal(fqv[198]);
	local[5]= fqv[199];
	local[6]= fqv[200];
	local[7]= fqv[201];
	local[8]= loadglobal(fqv[202]);
	local[9]= fqv[52];
	local[10]= fqv[203];
	local[11]= fqv[204];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[205];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[65])(ctx,13,local+2,&ftab[65],fqv[206]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= loadglobal(fqv[196]);
	local[1]= fqv[207];
	local[2]= fqv[208];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[209],module,XeusF251setwindowattributes_pixmap,fqv[210]);
	local[0]= fqv[209];
	local[1]= fqv[211];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[209];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[209];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[209];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[211],module,XeusF252set_setwindowattributes_pixmap,fqv[217]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[218],module,XeusF253setwindowattributes_background_pixel,fqv[219]);
	local[0]= fqv[218];
	local[1]= fqv[220];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[218];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[218];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[218];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[220],module,XeusF254set_setwindowattributes_background_pixel,fqv[221]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[222],module,XeusF255setwindowattributes_border_pixmap,fqv[223]);
	local[0]= fqv[222];
	local[1]= fqv[224];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[222];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[222];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[222];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[224],module,XeusF256set_setwindowattributes_border_pixmap,fqv[225]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[226],module,XeusF257setwindowattributes_border_pixel,fqv[227]);
	local[0]= fqv[226];
	local[1]= fqv[228];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[226];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[226];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[226];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[228],module,XeusF258set_setwindowattributes_border_pixel,fqv[229]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[230],module,XeusF259setwindowattributes_bit_gravity,fqv[231]);
	local[0]= fqv[230];
	local[1]= fqv[232];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[230];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[230];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[230];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[232],module,XeusF260set_setwindowattributes_bit_gravity,fqv[233]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[234],module,XeusF261setwindowattributes_win_gravity,fqv[235]);
	local[0]= fqv[234];
	local[1]= fqv[236];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[234];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[234];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[234];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[236],module,XeusF262set_setwindowattributes_win_gravity,fqv[237]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[238],module,XeusF263setwindowattributes_backing_store,fqv[239]);
	local[0]= fqv[238];
	local[1]= fqv[240];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[238];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[238];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[238];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[240],module,XeusF264set_setwindowattributes_backing_store,fqv[241]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[242],module,XeusF265setwindowattributes_backing_planes,fqv[243]);
	local[0]= fqv[242];
	local[1]= fqv[244];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[242];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[242];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[242];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[244],module,XeusF266set_setwindowattributes_backing_planes,fqv[245]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[246],module,XeusF267setwindowattributes_backing_pixel,fqv[247]);
	local[0]= fqv[246];
	local[1]= fqv[248];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[246];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[246];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[246];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[248],module,XeusF268set_setwindowattributes_backing_pixel,fqv[249]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[250],module,XeusF269setwindowattributes_save_under,fqv[251]);
	local[0]= fqv[250];
	local[1]= fqv[252];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[250];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[250];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[250];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[252],module,XeusF270set_setwindowattributes_save_under,fqv[253]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[254],module,XeusF271setwindowattributes_event_mask,fqv[255]);
	local[0]= fqv[254];
	local[1]= fqv[256];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[254];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[254];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[254];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[256],module,XeusF272set_setwindowattributes_event_mask,fqv[257]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[258],module,XeusF273setwindowattributes_do_not_propagate_mask,fqv[259]);
	local[0]= fqv[258];
	local[1]= fqv[260];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[258];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[258];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[258];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[260],module,XeusF274set_setwindowattributes_do_not_propagate_mask,fqv[261]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[262],module,XeusF275setwindowattributes_override_redirect,fqv[263]);
	local[0]= fqv[262];
	local[1]= fqv[264];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[262];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[262];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[262];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[264],module,XeusF276set_setwindowattributes_override_redirect,fqv[265]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[266],module,XeusF277setwindowattributes_colormap,fqv[267]);
	local[0]= fqv[266];
	local[1]= fqv[268];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[266];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[266];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[266];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[268],module,XeusF278set_setwindowattributes_colormap,fqv[269]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[270],module,XeusF279setwindowattributes_cursor,fqv[271]);
	local[0]= fqv[270];
	local[1]= fqv[272];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[270];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[270];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[270];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[272],module,XeusF280set_setwindowattributes_cursor,fqv[273]);
	local[0]= fqv[148];
	local[1]= fqv[194];
	local[2]= fqv[148];
	local[3]= fqv[197];
	local[4]= loadglobal(fqv[198]);
	local[5]= fqv[199];
	local[6]= fqv[200];
	local[7]= fqv[201];
	local[8]= loadglobal(fqv[202]);
	local[9]= fqv[52];
	local[10]= fqv[203];
	local[11]= fqv[204];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[205];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[65])(ctx,13,local+2,&ftab[65],fqv[206]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= loadglobal(fqv[148]);
	local[1]= fqv[207];
	local[2]= fqv[274];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[275],module,XeusF281windowattributes_x,fqv[276]);
	local[0]= fqv[275];
	local[1]= fqv[277];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[275];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[275];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[275];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[277],module,XeusF282set_windowattributes_x,fqv[278]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[279],module,XeusF283windowattributes_y,fqv[280]);
	local[0]= fqv[279];
	local[1]= fqv[281];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[279];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[279];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[279];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[281],module,XeusF284set_windowattributes_y,fqv[282]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[283],module,XeusF285windowattributes_width,fqv[284]);
	local[0]= fqv[283];
	local[1]= fqv[285];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[283];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[283];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[283];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[285],module,XeusF286set_windowattributes_width,fqv[286]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[287],module,XeusF287windowattributes_height,fqv[288]);
	local[0]= fqv[287];
	local[1]= fqv[289];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[287];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[287];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[287];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[289],module,XeusF288set_windowattributes_height,fqv[290]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[291],module,XeusF289windowattributes_border_width,fqv[292]);
	local[0]= fqv[291];
	local[1]= fqv[293];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[291];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[291];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[291];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[293],module,XeusF290set_windowattributes_border_width,fqv[294]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[295],module,XeusF291windowattributes_depth,fqv[296]);
	local[0]= fqv[295];
	local[1]= fqv[297];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[295];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[295];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[295];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[297],module,XeusF292set_windowattributes_depth,fqv[298]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[299],module,XeusF293windowattributes_visual,fqv[300]);
	local[0]= fqv[299];
	local[1]= fqv[301];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[299];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[299];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[299];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[301],module,XeusF294set_windowattributes_visual,fqv[302]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[303],module,XeusF295windowattributes_root,fqv[304]);
	local[0]= fqv[303];
	local[1]= fqv[305];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[303];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[303];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[303];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[305],module,XeusF296set_windowattributes_root,fqv[306]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[307],module,XeusF297windowattributes_class,fqv[308]);
	local[0]= fqv[307];
	local[1]= fqv[309];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[307];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[307];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[307];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[309],module,XeusF298set_windowattributes_class,fqv[310]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[311],module,XeusF299windowattributes_bit_gravity,fqv[312]);
	local[0]= fqv[311];
	local[1]= fqv[313];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[311];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[311];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[311];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[313],module,XeusF300set_windowattributes_bit_gravity,fqv[314]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[315],module,XeusF301windowattributes_win_gravity,fqv[316]);
	local[0]= fqv[315];
	local[1]= fqv[317];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[315];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[315];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[315];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[317],module,XeusF302set_windowattributes_win_gravity,fqv[318]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[319],module,XeusF303windowattributes_backing_store,fqv[320]);
	local[0]= fqv[319];
	local[1]= fqv[321];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[319];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[319];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[319];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[321],module,XeusF304set_windowattributes_backing_store,fqv[322]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[323],module,XeusF305windowattributes_backing_planes,fqv[324]);
	local[0]= fqv[323];
	local[1]= fqv[325];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[323];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[323];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[323];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[325],module,XeusF306set_windowattributes_backing_planes,fqv[326]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[327],module,XeusF307windowattributes_backing_pixel,fqv[328]);
	local[0]= fqv[327];
	local[1]= fqv[329];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[327];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[327];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[327];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[329],module,XeusF308set_windowattributes_backing_pixel,fqv[330]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[331],module,XeusF309windowattributes_save_under,fqv[332]);
	local[0]= fqv[331];
	local[1]= fqv[333];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[331];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[331];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[331];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[333],module,XeusF310set_windowattributes_save_under,fqv[334]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[335],module,XeusF311windowattributes_colormap,fqv[336]);
	local[0]= fqv[335];
	local[1]= fqv[337];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[335];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[335];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[335];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[337],module,XeusF312set_windowattributes_colormap,fqv[338]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[339],module,XeusF313windowattributes_map_installed,fqv[340]);
	local[0]= fqv[339];
	local[1]= fqv[341];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[339];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[339];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[339];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[341],module,XeusF314set_windowattributes_map_installed,fqv[342]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[343],module,XeusF315windowattributes_map_state,fqv[344]);
	local[0]= fqv[343];
	local[1]= fqv[345];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[343];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[343];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[343];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[345],module,XeusF316set_windowattributes_map_state,fqv[346]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[347],module,XeusF317windowattributes_all_event_masks,fqv[348]);
	local[0]= fqv[347];
	local[1]= fqv[349];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[347];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[347];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[347];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[349],module,XeusF318set_windowattributes_all_event_masks,fqv[350]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[351],module,XeusF319windowattributes_your_event_mask,fqv[352]);
	local[0]= fqv[351];
	local[1]= fqv[353];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[351];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[351];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[351];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[353],module,XeusF320set_windowattributes_your_event_mask,fqv[354]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[355],module,XeusF321windowattributes_do_not_propagate_mask,fqv[356]);
	local[0]= fqv[355];
	local[1]= fqv[357];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[355];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[355];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[355];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[357],module,XeusF322set_windowattributes_do_not_propagate_mask,fqv[358]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[359],module,XeusF323windowattributes_override_redirect,fqv[360]);
	local[0]= fqv[359];
	local[1]= fqv[361];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[359];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[359];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[359];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[361],module,XeusF324set_windowattributes_override_redirect,fqv[362]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[363],module,XeusF325windowattributes_screen,fqv[364]);
	local[0]= fqv[363];
	local[1]= fqv[365];
	local[2]= fqv[212];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[363];
	local[1]= fqv[213];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[363];
	local[1]= fqv[215];
	ctx->vsp=local+2;
	w=(*ftab[66])(ctx,2,local+0,&ftab[66],fqv[214]); /*remprop*/
	local[0]= fqv[363];
	local[1]= NIL;
	local[2]= fqv[216];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[365],module,XeusF326set_windowattributes_screen,fqv[366]);
	local[0]= fqv[117];
	local[1]= fqv[193];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XeusIF949;
	local[0]= fqv[117];
	local[1]= fqv[193];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[117];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XeusIF951;
	local[0]= fqv[117];
	local[1]= fqv[194];
	local[2]= loadglobal(fqv[196]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XeusIF952;
XeusIF951:
	local[0]= NIL;
XeusIF952:
	local[0]= fqv[117];
	goto XeusIF950;
XeusIF949:
	local[0]= NIL;
XeusIF950:
	local[0]= fqv[13];
	local[1]= fqv[193];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XeusIF953;
	local[0]= fqv[13];
	local[1]= fqv[193];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[13];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XeusIF955;
	local[0]= fqv[13];
	local[1]= fqv[194];
	local[2]= loadglobal(fqv[148]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XeusIF956;
XeusIF955:
	local[0]= NIL;
XeusIF956:
	local[0]= fqv[13];
	goto XeusIF954;
XeusIF953:
	local[0]= NIL;
XeusIF954:
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM412xdrawable_init,fqv[81],fqv[367],fqv[368]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM426xdrawable_drawable,fqv[4],fqv[367],fqv[369]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM428xdrawable_flush,fqv[370],fqv[367],fqv[371]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM430xdrawable_geometry,fqv[12],fqv[367],fqv[372]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM432xdrawable_height,fqv[26],fqv[367],fqv[373]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM434xdrawable_width,fqv[25],fqv[367],fqv[374]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM436xdrawable_pos,fqv[375],fqv[367],fqv[376]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM438xdrawable_x,fqv[377],fqv[367],fqv[378]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM440xdrawable_y,fqv[379],fqv[367],fqv[380]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM442xdrawable_gc,fqv[19],fqv[367],fqv[381]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM449xdrawable_gcid,fqv[382],fqv[367],fqv[383]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM451xdrawable_line_width,fqv[20],fqv[367],fqv[384]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM455xdrawable_line_style,fqv[21],fqv[367],fqv[385]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM459xdrawable_color,fqv[386],fqv[367],fqv[387]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM468xdrawable_copy_from,fqv[163],fqv[367],fqv[388]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM478xdrawable_shift,fqv[389],fqv[367],fqv[390]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM486xdrawable_point,fqv[54],fqv[367],fqv[391]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM490xdrawable_line,fqv[55],fqv[367],fqv[392]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM494xdrawable_rectangle,fqv[58],fqv[367],fqv[393]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM498xdrawable_arc,fqv[60],fqv[367],fqv[394]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM505xdrawable_fill_rectangle,fqv[59],fqv[367],fqv[395]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM509xdrawable_fill_arc,fqv[61],fqv[367],fqv[396]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM516xdrawable_string,fqv[56],fqv[367],fqv[397]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM522xdrawable_image_string,fqv[57],fqv[367],fqv[398]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM528xdrawable_getimage,fqv[399],fqv[367],fqv[400]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM542xdrawable_putimage,fqv[401],fqv[367],fqv[402]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM572xdrawable_putimage8to24,fqv[403],fqv[367],fqv[404]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM593xdrawable_draw_point,fqv[405],fqv[367],fqv[406]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM597xdrawable_draw_line,fqv[407],fqv[367],fqv[408]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM601xdrawable_draw_string,fqv[409],fqv[367],fqv[410]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM607xdrawable_draw_image_string,fqv[411],fqv[367],fqv[412]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM613xdrawable_draw_rectangle,fqv[413],fqv[367],fqv[414]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM617xdrawable_draw_fill_rectangle,fqv[415],fqv[367],fqv[416]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM623xdrawable_draw_arc,fqv[417],fqv[367],fqv[418]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM630xdrawable_draw_fill_arc,fqv[419],fqv[367],fqv[420]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM637xdrawable_drawline_primitive,fqv[421],fqv[367],fqv[422]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM639xdrawable_set_show_mode,fqv[423],fqv[367],fqv[424]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM641xdrawable_set_erase_mode,fqv[425],fqv[367],fqv[426]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM643xdrawable_set_xor_mode,fqv[427],fqv[367],fqv[428]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM645xdrawable_clear_area,fqv[67],fqv[367],fqv[429]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM652xdrawable_clear,fqv[64],fqv[367],fqv[430]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM654xdrawable_graph,fqv[431],fqv[367],fqv[432]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM680xdrawable_3d_fill_rectangle,fqv[433],fqv[367],fqv[434]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM690xpixmap_create,fqv[3],fqv[88],fqv[435]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM697xpixmap_create_from_bitmap_file,fqv[436],fqv[88],fqv[437]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM699xpixmap_write_to_bitmap_file,fqv[168],fqv[88],fqv[438]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM701xpixmap_destroy,fqv[144],fqv[88],fqv[439]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[440],module,XeusF327make_pixmaps,fqv[441]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[442],module,XeusF328make_gray_pixmap,fqv[443]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[444],module,XeusF329make_gray_gc,fqv[445]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[446],module,XeusF330make_cleared_pixmap,fqv[447]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[448],module,XeusF331eventmask_to_value,fqv[449]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[450],module,XeusF332gravity_to_value,fqv[451]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM740xwindow_create,fqv[3],fqv[173],fqv[452]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM807xwindow_subwindows,fqv[453],fqv[173],fqv[454]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM813xwindow_map,fqv[134],fqv[173],fqv[455]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM815xwindow_unmap,fqv[136],fqv[173],fqv[456]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM817xwindow_remap,fqv[457],fqv[173],fqv[458]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM819xwindow_parent,fqv[459],fqv[173],fqv[460]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM821xwindow_associate,fqv[130],fqv[173],fqv[461]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM825xwindow_dissociate,fqv[146],fqv[173],fqv[462]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM827xwindow_reparent,fqv[463],fqv[173],fqv[464]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM834xwindow_destroy,fqv[144],fqv[173],fqv[465]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM840xwindow_attributes,fqv[149],fqv[173],fqv[466]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM842xwindow_event_mask,fqv[467],fqv[173],fqv[468]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM844xwindow_selectinput,fqv[469],fqv[173],fqv[470]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM846xwindow_visual,fqv[45],fqv[173],fqv[471]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM850xwindow_location,fqv[472],fqv[173],fqv[473]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM852xwindow_size,fqv[204],fqv[173],fqv[474]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM854xwindow_depth,fqv[100],fqv[173],fqv[475]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM856xwindow_screen,fqv[476],fqv[173],fqv[477]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM858xwindow_colormap,fqv[118],fqv[173],fqv[478]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM862xwindow_root,fqv[479],fqv[173],fqv[480]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM864xwindow_title,fqv[481],fqv[173],fqv[482]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM866xwindow_background,fqv[99],fqv[173],fqv[483]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM872xwindow_background_pixmap,fqv[484],fqv[173],fqv[485]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM874xwindow_border,fqv[486],fqv[173],fqv[487]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM876xwindow_save,fqv[488],fqv[173],fqv[489]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM878xwindow_refresh,fqv[490],fqv[173],fqv[491]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM880xwindow_move,fqv[492],fqv[173],fqv[493]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM882xwindow_resize,fqv[494],fqv[173],fqv[495]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM884xwindow_raise,fqv[496],fqv[173],fqv[497]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM886xwindow_lower,fqv[498],fqv[173],fqv[499]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM888xwindow_write_to_bitmap_file,fqv[168],fqv[173],fqv[500]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM890xwindow_clear,fqv[64],fqv[173],fqv[501]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM892xwindow_clear_area,fqv[67],fqv[173],fqv[502]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM898xwindow_set_colormap,fqv[503],fqv[173],fqv[504]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM900xwindow_copy,fqv[63],fqv[173],fqv[505]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[506],module,XeusF333geometry__default_viewsurface,fqv[507]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM905xdrawable_draw_lines,fqv[177],fqv[367],fqv[508]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM910xdrawable_draw_polygon,fqv[509],fqv[367],fqv[510]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM914xdrawable_fill_polygon,fqv[75],fqv[367],fqv[511]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM923xwindow_override_redirect,fqv[512],fqv[173],fqv[513]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM927xwindow_save_under,fqv[514],fqv[173],fqv[515]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM931xwindow_settransientforhint,fqv[516],fqv[173],fqv[517]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM933xwindow_querypointer,fqv[182],fqv[173],fqv[518]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeusM935xwindow_global_pos,fqv[519],fqv[173],fqv[520]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[521],module,XeusF334make_xwindow,fqv[522]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[523],module,XeusF335find_xwindow,fqv[524]);
	local[0]= fqv[525];
	local[1]= fqv[526];
	ctx->vsp=local+2;
	w=(*ftab[67])(ctx,2,local+0,&ftab[67],fqv[527]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<68; i++) ftab[i]=fcallx;
}

/* ./Xevent.c :  entry=Xevent */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "Xevent.h"
#pragma init (register_Xevent)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___Xevent();
extern pointer build_quote_vector();
static int register_Xevent()
  { add_module_initializer("___Xevent", ___Xevent);}

static pointer XeventF1576xevent_type();
static pointer XeventF1577set_xevent_type();
static pointer XeventF1578xevent_serial();
static pointer XeventF1579set_xevent_serial();
static pointer XeventF1580xevent_send_event();
static pointer XeventF1581set_xevent_send_event();
static pointer XeventF1582xevent_display();
static pointer XeventF1583set_xevent_display();
static pointer XeventF1584xevent_window();
static pointer XeventF1585set_xevent_window();
static pointer XeventF1586xevent_root();
static pointer XeventF1587set_xevent_root();
static pointer XeventF1588xevent_subwindow();
static pointer XeventF1589set_xevent_subwindow();
static pointer XeventF1590xevent_time();
static pointer XeventF1591set_xevent_time();
static pointer XeventF1592xevent_x();
static pointer XeventF1593set_xevent_x();
static pointer XeventF1594xevent_y();
static pointer XeventF1595set_xevent_y();
static pointer XeventF1596xevent_x_root();
static pointer XeventF1597set_xevent_x_root();
static pointer XeventF1598xevent_y_root();
static pointer XeventF1599set_xevent_y_root();
static pointer XeventF1600xevent_state();
static pointer XeventF1601set_xevent_state();
static pointer XeventF1602xevent_detail();
static pointer XeventF1603set_xevent_detail();
static pointer XeventF1604xevent_same_screen();
static pointer XeventF1605set_xevent_same_screen();
static pointer XeventF1606xevent_focus();
static pointer XeventF1607set_xevent_focus();
static pointer XeventF1608xevent_alt_state();
static pointer XeventF1609set_xevent_alt_state();
static pointer XeventF1610xevent_pad();
static pointer XeventF1611set_xevent_pad();
static pointer XeventF1612next_event();
static pointer XeventF1613event_type();
static pointer XeventF1614event_x();
static pointer XeventF1615event_y();
static pointer XeventF1616event_x_root();
static pointer XeventF1617event_y_root();
static pointer XeventF1618event_pos();
static pointer XeventF1619event_key();
static pointer XeventF1620event_root_pos();
static pointer XeventF1621event_width();
static pointer XeventF1622event_height();
static pointer XeventF1623event_time();
static pointer XeventF1624event_window();
static pointer XeventF1625event_button();
static pointer XeventF1626event_state();
static pointer XeventF1627event_shift();
static pointer XeventF1628event_control();
static pointer XeventF1629event_meta();
static pointer XeventF1630event_left();
static pointer XeventF1631event_middle();
static pointer XeventF1632event_right();
static pointer XeventF1633event_pressed();
static pointer XeventF1634print_event();
static pointer XeventF1635display_events();
static pointer XeventF1636process_event();
static pointer XeventF1637window_main_one();
static pointer XeventF1638wmlerror();
static pointer XeventF1639window_main_thread2();
static pointer XeventF1640window_main_thread();
static pointer XeventF1641display_fd();
static pointer XeventF1642repwin();

/*xevent-type*/
static pointer XeventF1576xevent_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1643:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-type*/
static pointer XeventF1577set_xevent_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1644:
	ctx->vsp=local; return(local[0]);}

/*xevent-serial*/
static pointer XeventF1578xevent_serial(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)8L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1645:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-serial*/
static pointer XeventF1579set_xevent_serial(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)8L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1646:
	ctx->vsp=local; return(local[0]);}

/*xevent-send-event*/
static pointer XeventF1580xevent_send_event(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)16L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1647:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-send-event*/
static pointer XeventF1581set_xevent_send_event(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)16L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1648:
	ctx->vsp=local; return(local[0]);}

/*xevent-display*/
static pointer XeventF1582xevent_display(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)24L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1649:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-display*/
static pointer XeventF1583set_xevent_display(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)24L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1650:
	ctx->vsp=local; return(local[0]);}

/*xevent-window*/
static pointer XeventF1584xevent_window(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)32L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1651:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-window*/
static pointer XeventF1585set_xevent_window(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)32L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1652:
	ctx->vsp=local; return(local[0]);}

/*xevent-root*/
static pointer XeventF1586xevent_root(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)40L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1653:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-root*/
static pointer XeventF1587set_xevent_root(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)40L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1654:
	ctx->vsp=local; return(local[0]);}

/*xevent-subwindow*/
static pointer XeventF1588xevent_subwindow(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)48L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1655:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-subwindow*/
static pointer XeventF1589set_xevent_subwindow(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)48L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1656:
	ctx->vsp=local; return(local[0]);}

/*xevent-time*/
static pointer XeventF1590xevent_time(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)56L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1657:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-time*/
static pointer XeventF1591set_xevent_time(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)56L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1658:
	ctx->vsp=local; return(local[0]);}

/*xevent-x*/
static pointer XeventF1592xevent_x(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)64L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1659:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-x*/
static pointer XeventF1593set_xevent_x(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)64L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1660:
	ctx->vsp=local; return(local[0]);}

/*xevent-y*/
static pointer XeventF1594xevent_y(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)68L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1661:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-y*/
static pointer XeventF1595set_xevent_y(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)68L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1662:
	ctx->vsp=local; return(local[0]);}

/*xevent-x-root*/
static pointer XeventF1596xevent_x_root(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)72L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1663:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-x-root*/
static pointer XeventF1597set_xevent_x_root(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)72L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1664:
	ctx->vsp=local; return(local[0]);}

/*xevent-y-root*/
static pointer XeventF1598xevent_y_root(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)76L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1665:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-y-root*/
static pointer XeventF1599set_xevent_y_root(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)76L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1666:
	ctx->vsp=local; return(local[0]);}

/*xevent-state*/
static pointer XeventF1600xevent_state(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)80L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1667:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-state*/
static pointer XeventF1601set_xevent_state(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)80L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1668:
	ctx->vsp=local; return(local[0]);}

/*xevent-detail*/
static pointer XeventF1602xevent_detail(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)84L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1669:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-detail*/
static pointer XeventF1603set_xevent_detail(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)84L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1670:
	ctx->vsp=local; return(local[0]);}

/*xevent-same-screen*/
static pointer XeventF1604xevent_same_screen(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)88L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1671:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-same-screen*/
static pointer XeventF1605set_xevent_same_screen(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)88L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1672:
	ctx->vsp=local; return(local[0]);}

/*xevent-focus*/
static pointer XeventF1606xevent_focus(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)92L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1673:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-focus*/
static pointer XeventF1607set_xevent_focus(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)92L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1674:
	ctx->vsp=local; return(local[0]);}

/*xevent-alt-state*/
static pointer XeventF1608xevent_alt_state(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)96L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1675:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-alt-state*/
static pointer XeventF1609set_xevent_alt_state(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)96L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XeventBLK1676:
	ctx->vsp=local; return(local[0]);}

/*xevent-pad*/
static pointer XeventF1610xevent_pad(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto XeventENT1679;}
	local[0]= NIL;
XeventENT1679:
XeventENT1678:
	if (n>2) maerror();
	if (local[0]==NIL) goto XeventIF1680;
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)100L);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[2];
	ctx->vsp=local+4;
	w=(pointer)PEEK(ctx,3,local+1); /*system:peek*/
	local[1]= w;
	goto XeventIF1681;
XeventIF1680:
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)100L);
	local[3]= makeint((eusinteger_t)100L);
	w = makeint((eusinteger_t)92L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[3]= (pointer)((eusinteger_t)local[3] + (eusinteger_t)w);
	ctx->vsp=local+4;
	w=(pointer)SUBSEQ(ctx,3,local+1); /*subseq*/
	local[1]= w;
XeventIF1681:
	w = local[1];
	local[0]= w;
XeventBLK1677:
	ctx->vsp=local; return(local[0]);}

/*set-xevent-pad*/
static pointer XeventF1611set_xevent_pad(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XeventRST1683:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]==NIL) goto XeventIF1684;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= makeint((eusinteger_t)100L);
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[2];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,3,local+1); /*system:poke*/
	local[1]= w;
	goto XeventIF1685;
XeventIF1684:
	local[1]= argv[0];
	local[2]= argv[1];
	local[3]= fqv[3];
	local[4]= makeint((eusinteger_t)100L);
	local[5]= fqv[4];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[0])(ctx,6,local+1,&ftab[0],fqv[5]); /*replace*/
	local[1]= w;
XeventIF1685:
	w = local[1];
	local[0]= w;
XeventBLK1682:
	ctx->vsp=local; return(local[0]);}

/*next-event*/
static pointer XeventF1612next_event(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= loadglobal(fqv[6]);
	ctx->vsp=local+1;
	w=(*ftab[1])(ctx,1,local+0,&ftab[1],fqv[7]); /*pending*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto XeventCON1688;
	local[0]= loadglobal(fqv[6]);
	local[1]= loadglobal(fqv[8]);
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[9]); /*nextevent*/
	local[0]= loadglobal(fqv[8]);
	goto XeventCON1687;
XeventCON1688:
	local[0]= NIL;
XeventCON1687:
	w = local[0];
	local[0]= w;
XeventBLK1686:
	ctx->vsp=local; return(local[0]);}

/*event-type*/
static pointer XeventF1613event_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[10];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)XeventF1576xevent_type(ctx,1,local+1); /*xevent-type*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
XeventBLK1689:
	ctx->vsp=local; return(local[0]);}

/*event-x*/
static pointer XeventF1614event_x(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1592xevent_x(ctx,1,local+0); /*xevent-x*/
	local[0]= w;
XeventBLK1690:
	ctx->vsp=local; return(local[0]);}

/*event-y*/
static pointer XeventF1615event_y(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1594xevent_y(ctx,1,local+0); /*xevent-y*/
	local[0]= w;
XeventBLK1691:
	ctx->vsp=local; return(local[0]);}

/*event-x-root*/
static pointer XeventF1616event_x_root(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1596xevent_x_root(ctx,1,local+0); /*xevent-x-root*/
	local[0]= w;
XeventBLK1692:
	ctx->vsp=local; return(local[0]);}

/*event-y-root*/
static pointer XeventF1617event_y_root(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1598xevent_y_root(ctx,1,local+0); /*xevent-y-root*/
	local[0]= w;
XeventBLK1693:
	ctx->vsp=local; return(local[0]);}

/*event-pos*/
static pointer XeventF1618event_pos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1592xevent_x(ctx,1,local+0); /*xevent-x*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)XeventF1594xevent_y(ctx,1,local+1); /*xevent-y*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKINTVECTOR(ctx,2,local+0); /*integer-vector*/
	local[0]= w;
XeventBLK1694:
	ctx->vsp=local; return(local[0]);}

/*event-key*/
static pointer XeventF1619event_key(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1602xevent_detail(ctx,1,local+0); /*xevent-detail*/
	local[0]= w;
XeventBLK1695:
	ctx->vsp=local; return(local[0]);}

/*event-root-pos*/
static pointer XeventF1620event_root_pos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1596xevent_x_root(ctx,1,local+0); /*xevent-x-root*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)XeventF1598xevent_y_root(ctx,1,local+1); /*xevent-y-root*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKINTVECTOR(ctx,2,local+0); /*integer-vector*/
	local[0]= w;
XeventBLK1696:
	ctx->vsp=local; return(local[0]);}

/*event-width*/
static pointer XeventF1621event_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)ADDRESS(ctx,1,local+0); /*system:address*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)16L);
	local[2]= makeint((eusinteger_t)4L);
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)14L)); i=intval(local[2]);
		local[2]=(makeint(i * j));}
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,3,local+0); /*+*/
	local[0]= w;
	local[1]= fqv[0];
	ctx->vsp=local+2;
	w=(pointer)PEEK(ctx,2,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1697:
	ctx->vsp=local; return(local[0]);}

/*event-height*/
static pointer XeventF1622event_height(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)ADDRESS(ctx,1,local+0); /*system:address*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)16L);
	local[2]= makeint((eusinteger_t)4L);
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)15L)); i=intval(local[2]);
		local[2]=(makeint(i * j));}
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,3,local+0); /*+*/
	local[0]= w;
	local[1]= fqv[0];
	ctx->vsp=local+2;
	w=(pointer)PEEK(ctx,2,local+0); /*system:peek*/
	local[0]= w;
XeventBLK1698:
	ctx->vsp=local; return(local[0]);}

/*event-time*/
static pointer XeventF1623event_time(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1590xevent_time(ctx,1,local+0); /*xevent-time*/
	local[0]= w;
XeventBLK1699:
	ctx->vsp=local; return(local[0]);}

/*event-window*/
static pointer XeventF1624event_window(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1584xevent_window(ctx,1,local+0); /*xevent-window*/
	local[0]= w;
	local[1]= loadglobal(fqv[11]);
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[12]); /*gethash*/
	local[0]= w;
XeventBLK1700:
	ctx->vsp=local; return(local[0]);}

/*event-button*/
static pointer XeventF1625event_button(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1602xevent_detail(ctx,1,local+0); /*xevent-detail*/
	local[0]= w;
XeventBLK1701:
	ctx->vsp=local; return(local[0]);}

/*event-state*/
static pointer XeventF1626event_state(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1600xevent_state(ctx,1,local+0); /*xevent-state*/
	local[0]= w;
	local[1]= NIL;
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(pointer)LOGTEST(ctx,2,local+2); /*logtest*/
	if (w==NIL) goto XeventIF1703;
	local[2]= fqv[13];
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
	local[2]= local[1];
	goto XeventIF1704;
XeventIF1703:
	local[2]= NIL;
XeventIF1704:
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)4L);
	ctx->vsp=local+4;
	w=(pointer)LOGTEST(ctx,2,local+2); /*logtest*/
	if (w==NIL) goto XeventIF1705;
	local[2]= fqv[14];
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
	local[2]= local[1];
	goto XeventIF1706;
XeventIF1705:
	local[2]= NIL;
XeventIF1706:
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)8L);
	ctx->vsp=local+4;
	w=(pointer)LOGTEST(ctx,2,local+2); /*logtest*/
	if (w==NIL) goto XeventIF1707;
	local[2]= fqv[15];
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
	local[2]= local[1];
	goto XeventIF1708;
XeventIF1707:
	local[2]= NIL;
XeventIF1708:
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)256L);
	ctx->vsp=local+4;
	w=(pointer)LOGTEST(ctx,2,local+2); /*logtest*/
	if (w==NIL) goto XeventIF1709;
	local[2]= fqv[16];
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
	local[2]= local[1];
	goto XeventIF1710;
XeventIF1709:
	local[2]= NIL;
XeventIF1710:
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)512L);
	ctx->vsp=local+4;
	w=(pointer)LOGTEST(ctx,2,local+2); /*logtest*/
	if (w==NIL) goto XeventIF1711;
	local[2]= fqv[17];
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
	local[2]= local[1];
	goto XeventIF1712;
XeventIF1711:
	local[2]= NIL;
XeventIF1712:
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)1024L);
	ctx->vsp=local+4;
	w=(pointer)LOGTEST(ctx,2,local+2); /*logtest*/
	if (w==NIL) goto XeventIF1713;
	local[2]= fqv[18];
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
	local[2]= local[1];
	goto XeventIF1714;
XeventIF1713:
	local[2]= NIL;
XeventIF1714:
	w = local[1];
	local[0]= w;
XeventBLK1702:
	ctx->vsp=local; return(local[0]);}

/*event-shift*/
static pointer XeventF1627event_shift(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1600xevent_state(ctx,1,local+0); /*xevent-state*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)3L);
	ctx->vsp=local+2;
	w=(pointer)LOGTEST(ctx,2,local+0); /*logtest*/
	local[0]= w;
XeventBLK1715:
	ctx->vsp=local; return(local[0]);}

/*event-control*/
static pointer XeventF1628event_control(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1600xevent_state(ctx,1,local+0); /*xevent-state*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)4L);
	ctx->vsp=local+2;
	w=(pointer)LOGTEST(ctx,2,local+0); /*logtest*/
	local[0]= w;
XeventBLK1716:
	ctx->vsp=local; return(local[0]);}

/*event-meta*/
static pointer XeventF1629event_meta(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1600xevent_state(ctx,1,local+0); /*xevent-state*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)8L);
	ctx->vsp=local+2;
	w=(pointer)LOGTEST(ctx,2,local+0); /*logtest*/
	local[0]= w;
XeventBLK1717:
	ctx->vsp=local; return(local[0]);}

/*event-left*/
static pointer XeventF1630event_left(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1600xevent_state(ctx,1,local+0); /*xevent-state*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)256L);
	ctx->vsp=local+2;
	w=(pointer)LOGTEST(ctx,2,local+0); /*logtest*/
	local[0]= w;
XeventBLK1718:
	ctx->vsp=local; return(local[0]);}

/*event-middle*/
static pointer XeventF1631event_middle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1600xevent_state(ctx,1,local+0); /*xevent-state*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)512L);
	ctx->vsp=local+2;
	w=(pointer)LOGTEST(ctx,2,local+0); /*logtest*/
	local[0]= w;
XeventBLK1719:
	ctx->vsp=local; return(local[0]);}

/*event-right*/
static pointer XeventF1632event_right(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)XeventF1600xevent_state(ctx,1,local+0); /*xevent-state*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1024L);
	ctx->vsp=local+2;
	w=(pointer)LOGTEST(ctx,2,local+0); /*logtest*/
	local[0]= w;
XeventBLK1720:
	ctx->vsp=local; return(local[0]);}

/*event-pressed*/
static pointer XeventF1633event_pressed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto XeventENT1723;}
	local[0]= NIL;
XeventENT1723:
XeventENT1722:
	if (n>2) maerror();
	if (local[0]==NIL) goto XeventIF1724;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)XeventF1608xevent_alt_state(ctx,1,local+1); /*xevent-alt-state*/
	local[1]= w;
	goto XeventIF1725;
XeventIF1724:
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)XeventF1600xevent_state(ctx,1,local+1); /*xevent-state*/
	local[1]= w;
XeventIF1725:
	local[2]= makeint((eusinteger_t)1792L);
	ctx->vsp=local+3;
	w=(pointer)LOGTEST(ctx,2,local+1); /*logtest*/
	local[0]= w;
XeventBLK1721:
	ctx->vsp=local; return(local[0]);}

/*print-event*/
static pointer XeventF1634print_event(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	local[3]= T;
	local[4]= fqv[19];
	local[5]= loadglobal(fqv[8]);
	ctx->vsp=local+6;
	w=(pointer)XeventF1578xevent_serial(ctx,1,local+5); /*xevent-serial*/
	local[5]= w;
	local[6]= loadglobal(fqv[8]);
	ctx->vsp=local+7;
	w=(pointer)XeventF1613event_type(ctx,1,local+6); /*event-type*/
	local[6]= w;
	local[7]= loadglobal(fqv[8]);
	ctx->vsp=local+8;
	w=(pointer)XeventF1624event_window(ctx,1,local+7); /*event-window*/
	local[7]= w;
	local[8]= fqv[20];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= loadglobal(fqv[8]);
	ctx->vsp=local+9;
	w=(pointer)XeventF1618event_pos(ctx,1,local+8); /*event-pos*/
	local[8]= w;
	local[9]= loadglobal(fqv[8]);
	ctx->vsp=local+10;
	w=(pointer)XeventF1626event_state(ctx,1,local+9); /*event-state*/
	local[9]= w;
	local[10]= loadglobal(fqv[8]);
	ctx->vsp=local+11;
	w=(pointer)XeventF1600xevent_state(ctx,1,local+10); /*xevent-state*/
	local[10]= w;
	local[11]= loadglobal(fqv[8]);
	ctx->vsp=local+12;
	w=(pointer)XeventF1619event_key(ctx,1,local+11); /*event-key*/
	local[11]= w;
	local[12]= loadglobal(fqv[8]);
	ctx->vsp=local+13;
	w=(pointer)XeventF1590xevent_time(ctx,1,local+12); /*xevent-time*/
	local[12]= w;
	local[13]= makeflt(1.0000000000000000000000e+03);
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,10,local+3); /*format*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1726:
	ctx->vsp=local; return(local[0]);}

/*display-events*/
static pointer XeventF1635display_events(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= loadglobal(fqv[6]);
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[21]); /*sync*/
XeventWHL1728:
	if (T==NIL) goto XeventWHX1729;
	local[0]= loadglobal(fqv[6]);
	local[1]= loadglobal(fqv[8]);
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[9]); /*nextevent*/
	local[0]= loadglobal(fqv[8]);
	ctx->vsp=local+1;
	w=(pointer)XeventF1634print_event(ctx,1,local+0); /*print-event*/
	local[0]= loadglobal(fqv[8]);
	ctx->vsp=local+1;
	w=(pointer)XeventF1613event_type(ctx,1,local+0); /*event-type*/
	local[0]= w;
	local[1]= fqv[22];
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XeventIF1731;
	local[0]= loadglobal(fqv[8]);
	ctx->vsp=local+1;
	w=(pointer)XeventF1619event_key(ctx,1,local+0); /*event-key*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)103L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XeventIF1731;
	w = NIL;
	ctx->vsp=local+0;
	local[0]=w;
	goto XeventBLK1727;
	goto XeventIF1732;
XeventIF1731:
	local[0]= NIL;
XeventIF1732:
	goto XeventWHL1728;
XeventWHX1729:
	local[0]= NIL;
XeventBLK1730:
	w = local[0];
	local[0]= w;
XeventBLK1727:
	ctx->vsp=local; return(local[0]);}

/*:event-notify-print*/
static pointer XeventM1733xwindow_event_notify_print(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	w = argv[3];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	local[3]= T;
	local[4]= fqv[23];
	local[5]= argv[2];
	local[6]= loadglobal(fqv[8]);
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,4,local+3); /*format*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1734:
	ctx->vsp=local; return(local[0]);}

/*:event-notify-dispatch*/
static pointer XeventM1735xwindow_event_notify_dispatch(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	w = argv[3];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	local[3]= argv[0];
	local[4]= argv[2];
	local[5]= loadglobal(fqv[8]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1736:
	ctx->vsp=local; return(local[0]);}

/*:event-notify*/
static pointer XeventM1737xwindow_event_notify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	w = argv[3];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	if (argv[0]->c.obj.iv[11]==NIL) goto XeventCON1740;
	local[3]= argv[0]->c.obj.iv[11];
	local[4]= fqv[24];
	local[5]= argv[2];
	local[6]= loadglobal(fqv[8]);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto XeventCON1739;
XeventCON1740:
	local[3]= argv[2];
	local[4]= fqv[25];
	ctx->vsp=local+5;
	w=(*ftab[5])(ctx,2,local+3,&ftab[5],fqv[26]); /*member*/
	if (w==NIL) goto XeventCON1741;
	local[3]= argv[0];
	local[4]= fqv[27];
	local[5]= argv[2];
	local[6]= loadglobal(fqv[8]);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto XeventCON1739;
XeventCON1741:
	local[3]= argv[2];
	local[4]= fqv[28];
	ctx->vsp=local+5;
	w=(*ftab[5])(ctx,2,local+3,&ftab[5],fqv[26]); /*member*/
	if (w==NIL) goto XeventCON1742;
	local[3]= argv[2];
	if (fqv[29]!=local[3]) goto XeventIF1743;
	local[3]= loadglobal(fqv[30]);
	local[4]= loadglobal(fqv[31]);
	ctx->vsp=local+5;
	w=(pointer)DERIVEDP(ctx,2,local+3); /*derivedp*/
	if (w==NIL) goto XeventIF1743;
	local[3]= loadglobal(fqv[30]);
	local[4]= fqv[29];
	local[5]= loadglobal(fqv[8]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto XeventIF1744;
XeventIF1743:
	local[3]= NIL;
XeventIF1744:
	local[3]= argv[0];
	local[4]= fqv[27];
	local[5]= argv[2];
	local[6]= loadglobal(fqv[8]);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto XeventCON1739;
XeventCON1742:
	local[3]= NIL;
XeventCON1739:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1738:
	ctx->vsp=local; return(local[0]);}

/*:keyrelease*/
static pointer XeventM1745xwindow_keyrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	if (loadglobal(fqv[32])==NIL) goto XeventIF1747;
	local[3]= fqv[33];
	local[4]= fqv[22];
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,2,local+3,&ftab[6],fqv[34]); /*warn*/
	local[3]= w;
	goto XeventIF1748;
XeventIF1747:
	local[3]= NIL;
XeventIF1748:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1746:
	ctx->vsp=local; return(local[0]);}

/*:keypress*/
static pointer XeventM1749xwindow_keypress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	local[3]= loadglobal(fqv[8]);
	local[4]= loadglobal(fqv[35]);
	local[5]= makeint((eusinteger_t)1L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(*ftab[7])(ctx,5,local+3,&ftab[7],fqv[36]); /*lookupstring*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)NUMEQUAL(ctx,2,local+3); /*=*/
	if (w==NIL) goto XeventIF1751;
	local[3]= argv[0];
	local[4]= fqv[37];
	local[5]= loadglobal(fqv[35]);
	{ register eusinteger_t i=intval(makeint((eusinteger_t)0L));
	  w=makeint(local[5]->c.str.chars[i]);}
	local[5]= w;
	local[6]= loadglobal(fqv[8]);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto XeventIF1752;
XeventIF1751:
	local[3]= NIL;
XeventIF1752:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1750:
	ctx->vsp=local; return(local[0]);}

/*:keyenter*/
static pointer XeventM1753xwindow_keyenter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XeventENT1756;}
	local[0]= NIL;
XeventENT1756:
	w = local[0];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
XeventENT1755:
	if (n>4) maerror();
	if (loadglobal(fqv[32])==NIL) goto XeventIF1757;
	local[3]= fqv[38];
	local[4]= fqv[37];
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,2,local+3,&ftab[6],fqv[34]); /*warn*/
	local[3]= w;
	goto XeventIF1758;
XeventIF1757:
	local[3]= NIL;
XeventIF1758:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1754:
	ctx->vsp=local; return(local[0]);}

/*:buttonpress*/
static pointer XeventM1759xwindow_buttonpress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	if (loadglobal(fqv[32])==NIL) goto XeventIF1761;
	local[3]= fqv[39];
	local[4]= fqv[40];
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,2,local+3,&ftab[6],fqv[34]); /*warn*/
	local[3]= loadglobal(fqv[8]);
	ctx->vsp=local+4;
	w=(pointer)XeventF1626event_state(ctx,1,local+3); /*event-state*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PRINT(ctx,1,local+3); /*print*/
	local[3]= w;
	goto XeventIF1762;
XeventIF1761:
	local[3]= NIL;
XeventIF1762:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1760:
	ctx->vsp=local; return(local[0]);}

/*:buttonrelease*/
static pointer XeventM1763xwindow_buttonrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	if (loadglobal(fqv[32])==NIL) goto XeventIF1765;
	local[3]= fqv[41];
	local[4]= fqv[29];
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,2,local+3,&ftab[6],fqv[34]); /*warn*/
	local[3]= w;
	goto XeventIF1766;
XeventIF1765:
	local[3]= NIL;
XeventIF1766:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1764:
	ctx->vsp=local; return(local[0]);}

/*:motionnotify*/
static pointer XeventM1767xwindow_motionnotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	if (loadglobal(fqv[32])==NIL) goto XeventIF1769;
	local[3]= fqv[42];
	local[4]= fqv[43];
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,2,local+3,&ftab[6],fqv[34]); /*warn*/
	local[3]= w;
	goto XeventIF1770;
XeventIF1769:
	local[3]= NIL;
XeventIF1770:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1768:
	ctx->vsp=local; return(local[0]);}

/*:enternotify*/
static pointer XeventM1771xwindow_enternotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	if (loadglobal(fqv[32])==NIL) goto XeventIF1773;
	local[3]= fqv[44];
	local[4]= fqv[45];
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,2,local+3,&ftab[6],fqv[34]); /*warn*/
	local[3]= w;
	goto XeventIF1774;
XeventIF1773:
	local[3]= NIL;
XeventIF1774:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1772:
	ctx->vsp=local; return(local[0]);}

/*:leavenotify*/
static pointer XeventM1775xwindow_leavenotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	if (loadglobal(fqv[32])==NIL) goto XeventIF1777;
	local[3]= fqv[46];
	local[4]= fqv[47];
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,2,local+3,&ftab[6],fqv[34]); /*warn*/
	local[3]= w;
	goto XeventIF1778;
XeventIF1777:
	local[3]= NIL;
XeventIF1778:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1776:
	ctx->vsp=local; return(local[0]);}

/*:configurenotify*/
static pointer XeventM1779xwindow_configurenotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	if (loadglobal(fqv[32])==NIL) goto XeventIF1781;
	local[3]= fqv[48];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,2,local+3,&ftab[6],fqv[34]); /*warn*/
	local[3]= w;
	goto XeventIF1782;
XeventIF1781:
	local[3]= NIL;
XeventIF1782:
	local[3]= argv[0];
	local[4]= fqv[49];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[50];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	if (T==NIL) goto XeventIF1783;
	local[5]= local[3];
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[8])(ctx,2,local+5,&ftab[8],fqv[51]); /*/=*/
	local[5]= w;
	if (w!=NIL) goto XeventOR1785;
	local[5]= local[4];
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(*ftab[8])(ctx,2,local+5,&ftab[8],fqv[51]); /*/=*/
	local[5]= w;
XeventOR1785:
	argv[0]->c.obj.iv[5] = local[3];
	argv[0]->c.obj.iv[6] = local[4];
	local[5]= argv[0];
	local[6]= fqv[52];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	goto XeventIF1784;
XeventIF1783:
	local[5]= NIL;
XeventIF1784:
	w = local[5];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1780:
	ctx->vsp=local; return(local[0]);}

/*:configurerequest*/
static pointer XeventM1786xwindow_configurerequest(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	local[3]= fqv[53];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,2,local+3,&ftab[6],fqv[34]); /*warn*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1787:
	ctx->vsp=local; return(local[0]);}

/*:expose*/
static pointer XeventM1788xwindow_expose(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	local[3]= argv[0];
	local[4]= fqv[52];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1789:
	ctx->vsp=local; return(local[0]);}

/*:visibilitynotify*/
static pointer XeventM1790xwindow_visibilitynotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	local[3]= NIL;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1791:
	ctx->vsp=local; return(local[0]);}

/*:redraw*/
static pointer XeventM1792xwindow_redraw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[54];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,2,local+0,&ftab[6],fqv[34]); /*warn*/
	local[0]= w;
XeventBLK1793:
	ctx->vsp=local; return(local[0]);}

/*process-event*/
static pointer XeventF1636process_event(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[8],w);
	local[3]= loadglobal(fqv[8]);
	ctx->vsp=local+4;
	w=(pointer)XeventF1624event_window(ctx,1,local+3); /*event-window*/
	local[3]= w;
	local[4]= loadglobal(fqv[8]);
	ctx->vsp=local+5;
	w=(pointer)XeventF1613event_type(ctx,1,local+4); /*event-type*/
	local[4]= w;
	if (loadglobal(fqv[32])==NIL) goto XeventIF1795;
	local[5]= loadglobal(fqv[8]);
	ctx->vsp=local+6;
	w=(pointer)XeventF1634print_event(ctx,1,local+5); /*print-event*/
	local[5]= w;
	goto XeventIF1796;
XeventIF1795:
	local[5]= NIL;
XeventIF1796:
	local[5]= local[3];
	local[6]= loadglobal(fqv[31]);
	ctx->vsp=local+7;
	w=(pointer)DERIVEDP(ctx,2,local+5); /*derivedp*/
	if (w==NIL) goto XeventIF1797;
	local[5]= local[3];
	local[6]= fqv[24];
	local[7]= local[4];
	local[8]= loadglobal(fqv[8]);
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	goto XeventIF1798;
XeventIF1797:
	local[5]= NIL;
XeventIF1798:
	w = local[5];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XeventBLK1794:
	ctx->vsp=local; return(local[0]);}

/*window-main-one*/
static pointer XeventF1637window_main_one(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto XeventENT1801;}
	local[0]= NIL;
XeventENT1801:
XeventENT1800:
	if (n>1) maerror();
	{jmp_buf jb;
	w = fqv[55];
	ctx->vsp=local+1;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto XeventCAT1802;}
XeventWHL1803:
	local[7]= loadglobal(fqv[6]);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,2,local+7,&ftab[9],fqv[56]); /*eventsqueued*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)GREATERP(ctx,2,local+7); /*>*/
	if (w==NIL) goto XeventWHX1804;
	local[7]= loadglobal(fqv[6]);
	local[8]= loadglobal(fqv[8]);
	ctx->vsp=local+9;
	w=(*ftab[2])(ctx,2,local+7,&ftab[2],fqv[9]); /*nextevent*/
	if (loadglobal(fqv[57])==NIL) goto XeventIF1806;
	local[7]= loadglobal(fqv[8]);
	ctx->vsp=local+8;
	w=(pointer)XeventF1634print_event(ctx,1,local+7); /*print-event*/
	local[7]= w;
	goto XeventIF1807;
XeventIF1806:
	local[7]= NIL;
XeventIF1807:
	if (loadglobal(fqv[58])==NIL) goto XeventIF1808;
	local[7]= loadglobal(fqv[8]);
	ctx->vsp=local+8;
	w=(pointer)XeventF1613event_type(ctx,1,local+7); /*event-type*/
	local[7]= w;
	local[8]= fqv[43];
	ctx->vsp=local+9;
	w=(pointer)EQ(ctx,2,local+7); /*eql*/
	if (w==NIL) goto XeventIF1808;
XeventWHL1810:
	local[7]= loadglobal(fqv[6]);
	ctx->vsp=local+8;
	w=(*ftab[1])(ctx,1,local+7,&ftab[1],fqv[7]); /*pending*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)GREATERP(ctx,2,local+7); /*>*/
	if (w==NIL) goto XeventWHX1811;
	local[7]= loadglobal(fqv[6]);
	local[8]= loadglobal(fqv[59]);
	ctx->vsp=local+9;
	w=(*ftab[10])(ctx,2,local+7,&ftab[10],fqv[60]); /*peekevent*/
	local[7]= loadglobal(fqv[59]);
	ctx->vsp=local+8;
	w=(pointer)XeventF1613event_type(ctx,1,local+7); /*event-type*/
	local[7]= w;
	local[8]= fqv[43];
	ctx->vsp=local+9;
	w=(pointer)EQ(ctx,2,local+7); /*eql*/
	if (w==NIL) goto XeventWHX1811;
	local[7]= loadglobal(fqv[6]);
	local[8]= loadglobal(fqv[8]);
	ctx->vsp=local+9;
	w=(*ftab[2])(ctx,2,local+7,&ftab[2],fqv[9]); /*nextevent*/
	local[7]= loadglobal(fqv[61]);
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[7]= w;
	storeglobal(fqv[61],w);
	goto XeventWHL1810;
XeventWHX1811:
	local[7]= NIL;
XeventBLK1812:
	goto XeventIF1809;
XeventIF1808:
	local[7]= NIL;
XeventIF1809:
	local[7]= loadglobal(fqv[8]);
	ctx->vsp=local+8;
	w=(pointer)XeventF1636process_event(ctx,1,local+7); /*process-event*/
	goto XeventWHL1803;
XeventWHX1804:
	local[7]= NIL;
XeventBLK1805:
	ctx->vsp=local+7;
	w=(*ftab[11])(ctx,0,local+7,&ftab[11],fqv[62]); /*xflush*/
XeventCAT1802:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[0]= w;
XeventBLK1799:
	ctx->vsp=local; return(local[0]);}

/*window-main-loop*/
static pointer XeventF1813(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
XeventRST1815:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	if (local[0]!=NIL) goto XeventIF1816;
	local[1]= fqv[63];
	local[2]= fqv[21];
	local[3]= fqv[6];
	local[4]= fqv[64];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[65];
	local[4]= fqv[55];
	local[5]= fqv[66];
	local[6]= fqv[67];
	local[7]= fqv[68];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[21];
	local[7]= fqv[6];
	local[8]= fqv[69];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[62];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	goto XeventIF1817;
XeventIF1816:
	local[1]= fqv[63];
	local[2]= fqv[21];
	local[3]= fqv[6];
	local[4]= fqv[70];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[65];
	local[4]= fqv[55];
	local[5]= fqv[66];
	local[6]= fqv[67];
	local[7]= fqv[71];
	local[8]= fqv[72];
	local[9]= fqv[7];
	local[10]= fqv[6];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[73];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[9];
	local[10]= fqv[6];
	local[11]= fqv[8];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[74];
	local[11]= fqv[8];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[67];
	w = local[0];
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[21];
	local[5]= fqv[6];
	local[6]= fqv[75];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[62];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
XeventIF1817:
	w = local[1];
	local[0]= w;
XeventBLK1814:
	ctx->vsp=local; return(local[0]);}

/*wml*/
static pointer XeventF1818(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
XeventRST1820:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= fqv[76];
	w = local[0];
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
XeventBLK1819:
	ctx->vsp=local; return(local[0]);}

/*wmlerror*/
static pointer XeventF1638wmlerror(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XeventENT1823;}
	local[0]= NIL;
XeventENT1823:
XeventENT1822:
	if (n>4) maerror();
	local[1]= loadglobal(fqv[77]);
	local[2]= fqv[78];
	local[3]= loadglobal(fqv[79]);
	ctx->vsp=local+4;
	w=(pointer)THR_SELF(ctx,0,local+4); /*unix:thr-self*/
	local[4]= w;
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,5,local+1); /*format*/
	if (local[0]==NIL) goto XeventIF1824;
	local[1]= loadglobal(fqv[77]);
	local[2]= fqv[80];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= w;
	goto XeventIF1825;
XeventIF1824:
	local[1]= NIL;
XeventIF1825:
	if (argv[2]==NIL) goto XeventIF1826;
	local[1]= loadglobal(fqv[77]);
	local[2]= fqv[81];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= w;
	goto XeventIF1827;
XeventIF1826:
	local[1]= NIL;
XeventIF1827:
	local[1]= loadglobal(fqv[77]);
	ctx->vsp=local+2;
	w=(pointer)TERPRI(ctx,1,local+1); /*terpri*/
	local[1]= fqv[82];
	w = NIL;
	ctx->vsp=local+2;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	w = local[1];
	local[0]= w;
XeventBLK1821:
	ctx->vsp=local; return(local[0]);}

/*window-main-thread2*/
static pointer XeventF1639window_main_thread2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= (pointer)get_sym_func(fqv[83]);
	ctx->vsp=local+2;
	w=(*ftab[12])(ctx,1,local+1,&ftab[12],fqv[84]); /*lisp::install-error-handler*/
	local[1]= loadglobal(fqv[6]);
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(*ftab[4])(ctx,2,local+1,&ftab[4],fqv[21]); /*sync*/
	{jmp_buf jb;
	w = fqv[55];
	ctx->vsp=local+1;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto XeventCAT1829;}
XeventWHL1830:
	if (T==NIL) goto XeventWHX1831;
	{jmp_buf jb;
	w = fqv[82];
	ctx->vsp=local+7;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto XeventCAT1833;}
	local[13]= loadglobal(fqv[6]);
	local[14]= loadglobal(fqv[8]);
	ctx->vsp=local+15;
	w=(*ftab[2])(ctx,2,local+13,&ftab[2],fqv[9]); /*nextevent*/
	if (loadglobal(fqv[32])==NIL) goto XeventIF1834;
	local[13]= loadglobal(fqv[8]);
	ctx->vsp=local+14;
	w=(pointer)XeventF1634print_event(ctx,1,local+13); /*print-event*/
	local[13]= w;
	goto XeventIF1835;
XeventIF1834:
	local[13]= NIL;
XeventIF1835:
	local[13]= local[0];
	ctx->vsp=local+14;
	w=(pointer)ADD1(ctx,1,local+13); /*1+*/
	local[0] = w;
	local[13]= loadglobal(fqv[8]);
	ctx->vsp=local+14;
	w=(pointer)XeventF1636process_event(ctx,1,local+13); /*process-event*/
XeventCAT1833:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	goto XeventWHL1830;
XeventWHX1831:
	local[7]= NIL;
XeventBLK1832:
	w = local[7];
XeventCAT1829:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[1]= fqv[85];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,2,local+1,&ftab[6],fqv[34]); /*warn*/
	local[1]= loadglobal(fqv[6]);
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(*ftab[4])(ctx,2,local+1,&ftab[4],fqv[21]); /*sync*/
	ctx->vsp=local+1;
	w=(*ftab[11])(ctx,0,local+1,&ftab[11],fqv[62]); /*xflush*/
	local[0]= w;
XeventBLK1828:
	ctx->vsp=local; return(local[0]);}

/*window-main-thread*/
static pointer XeventF1640window_main_thread(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= (pointer)get_sym_func(fqv[86]);
	ctx->vsp=local+1;
	w=(pointer)AFUNCALL_NO_WAIT(ctx,1,local+0); /*system:thread-no-wait*/
	local[0]= w;
XeventBLK1836:
	ctx->vsp=local; return(local[0]);}

/*display-fd*/
static pointer XeventF1641display_fd(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto XeventENT1839;}
	local[0]= loadglobal(fqv[6]);
XeventENT1839:
XeventENT1838:
	if (n>1) maerror();
	if (local[0]==NIL) goto XeventIF1840;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)16L);
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[1]= w;
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,2,local+1); /*system:peek*/
	local[1]= w;
	goto XeventIF1841;
XeventIF1840:
	local[1]= NIL;
XeventIF1841:
	w = local[1];
	local[0]= w;
XeventBLK1837:
	ctx->vsp=local; return(local[0]);}

/*repwin*/
static pointer XeventF1642repwin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	ctx->vsp=local+0;
	w=(pointer)XeventF1641display_fd(ctx,0,local+0); /*display-fd*/
	local[0]= w;
	local[1]= NIL;
	local[2]= T;
XeventWHL1843:
	if (T==NIL) goto XeventWHX1844;
	if (local[2]==NIL) goto XeventIF1846;
	local[3]= loadglobal(fqv[87]);
	local[4]= fqv[88];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,2,local+3); /*format*/
	local[3]= loadglobal(fqv[87]);
	ctx->vsp=local+4;
	w=(pointer)FINOUT(ctx,1,local+3); /*finish-output*/
	local[3]= w;
	goto XeventIF1847;
XeventIF1846:
	local[3]= NIL;
XeventIF1847:
	local[2] = NIL;
	local[3]= loadglobal(fqv[89]);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[3]= w;
	local[4]= makeflt(1.0000000000000000000000e+01);
	ctx->vsp=local+5;
	w=(*ftab[13])(ctx,2,local+3,&ftab[13],fqv[90]); /*select-stream*/
	local[1] = w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= loadglobal(fqv[89]);
	ctx->vsp=local+5;
	w=(pointer)EQ(ctx,2,local+3); /*eql*/
	if (w==NIL) goto XeventCON1849;
	local[3]= loadglobal(fqv[89]);
	ctx->vsp=local+4;
	w=(pointer)READ(ctx,1,local+3); /*read*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)EVAL(ctx,1,local+3); /*eval*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PRINT(ctx,1,local+3); /*print*/
	local[2] = T;
	local[3]= local[2];
	goto XeventCON1848;
XeventCON1849:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)EQ(ctx,2,local+3); /*eql*/
	if (w==NIL) goto XeventCON1850;
	ctx->vsp=local+3;
	w=(pointer)XeventF1637window_main_one(ctx,0,local+3); /*window-main-one*/
	local[3]= w;
	goto XeventCON1848;
XeventCON1850:
	local[3]= loadglobal(fqv[91]);
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[3]= w;
	storeglobal(fqv[91],w);
	goto XeventCON1848;
XeventCON1851:
	local[3]= NIL;
XeventCON1848:
	goto XeventWHL1843;
XeventWHX1844:
	local[3]= NIL;
XeventBLK1845:
	w = local[3];
	local[0]= w;
XeventBLK1842:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___Xevent(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[92];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto XeventIF1852;
	local[0]= fqv[93];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[94],w);
	goto XeventIF1853;
XeventIF1852:
	local[0]= fqv[95];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
XeventIF1853:
	local[0]= fqv[96];
	local[1]= fqv[97];
	ctx->vsp=local+2;
	w=(*ftab[14])(ctx,2,local+0,&ftab[14],fqv[98]); /*require*/
	local[0]= fqv[99];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[57];
	local[1]= fqv[100];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[101];
	local[1]= fqv[100];
	local[2]= fqv[101];
	local[3]= fqv[102];
	local[4]= loadglobal(fqv[103]);
	local[5]= fqv[104];
	local[6]= fqv[105];
	local[7]= fqv[106];
	local[8]= loadglobal(fqv[107]);
	local[9]= fqv[108];
	local[10]= fqv[2];
	local[11]= fqv[109];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[110];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[15])(ctx,13,local+2,&ftab[15],fqv[111]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= loadglobal(fqv[101]);
	local[1]= fqv[112];
	local[2]= fqv[113];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[114],module,XeventF1576xevent_type,fqv[115]);
	local[0]= fqv[114];
	local[1]= fqv[116];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[114];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[114];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[114];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[116],module,XeventF1577set_xevent_type,fqv[122]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[123],module,XeventF1578xevent_serial,fqv[124]);
	local[0]= fqv[123];
	local[1]= fqv[125];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[123];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[123];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[123];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[125],module,XeventF1579set_xevent_serial,fqv[126]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[127],module,XeventF1580xevent_send_event,fqv[128]);
	local[0]= fqv[127];
	local[1]= fqv[129];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[127];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[127];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[127];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[129],module,XeventF1581set_xevent_send_event,fqv[130]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[131],module,XeventF1582xevent_display,fqv[132]);
	local[0]= fqv[131];
	local[1]= fqv[133];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[131];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[131];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[131];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[133],module,XeventF1583set_xevent_display,fqv[134]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[135],module,XeventF1584xevent_window,fqv[136]);
	local[0]= fqv[135];
	local[1]= fqv[137];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[135];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[135];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[135];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[137],module,XeventF1585set_xevent_window,fqv[138]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[139],module,XeventF1586xevent_root,fqv[140]);
	local[0]= fqv[139];
	local[1]= fqv[141];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[139];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[139];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[139];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[141],module,XeventF1587set_xevent_root,fqv[142]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[143],module,XeventF1588xevent_subwindow,fqv[144]);
	local[0]= fqv[143];
	local[1]= fqv[145];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[143];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[143];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[143];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[145],module,XeventF1589set_xevent_subwindow,fqv[146]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[147],module,XeventF1590xevent_time,fqv[148]);
	local[0]= fqv[147];
	local[1]= fqv[149];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[147];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[147];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[147];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[149],module,XeventF1591set_xevent_time,fqv[150]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[151],module,XeventF1592xevent_x,fqv[152]);
	local[0]= fqv[151];
	local[1]= fqv[153];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[151];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[151];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[151];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[153],module,XeventF1593set_xevent_x,fqv[154]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[155],module,XeventF1594xevent_y,fqv[156]);
	local[0]= fqv[155];
	local[1]= fqv[157];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[155];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[155];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[155];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[157],module,XeventF1595set_xevent_y,fqv[158]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[159],module,XeventF1596xevent_x_root,fqv[160]);
	local[0]= fqv[159];
	local[1]= fqv[161];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[159];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[159];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[159];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[161],module,XeventF1597set_xevent_x_root,fqv[162]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[163],module,XeventF1598xevent_y_root,fqv[164]);
	local[0]= fqv[163];
	local[1]= fqv[165];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[163];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[163];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[163];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[165],module,XeventF1599set_xevent_y_root,fqv[166]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[167],module,XeventF1600xevent_state,fqv[168]);
	local[0]= fqv[167];
	local[1]= fqv[169];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[167];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[167];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[167];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[169],module,XeventF1601set_xevent_state,fqv[170]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[171],module,XeventF1602xevent_detail,fqv[172]);
	local[0]= fqv[171];
	local[1]= fqv[173];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[171];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[171];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[171];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[173],module,XeventF1603set_xevent_detail,fqv[174]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[175],module,XeventF1604xevent_same_screen,fqv[176]);
	local[0]= fqv[175];
	local[1]= fqv[177];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[175];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[175];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[175];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[177],module,XeventF1605set_xevent_same_screen,fqv[178]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[179],module,XeventF1606xevent_focus,fqv[180]);
	local[0]= fqv[179];
	local[1]= fqv[181];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[179];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[179];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[179];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[181],module,XeventF1607set_xevent_focus,fqv[182]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[183],module,XeventF1608xevent_alt_state,fqv[184]);
	local[0]= fqv[183];
	local[1]= fqv[185];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[183];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[183];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[183];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[185],module,XeventF1609set_xevent_alt_state,fqv[186]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[187],module,XeventF1610xevent_pad,fqv[188]);
	local[0]= fqv[187];
	local[1]= fqv[189];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[187];
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[187];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[119]); /*remprop*/
	local[0]= fqv[187];
	local[1]= NIL;
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[189],module,XeventF1611set_xevent_pad,fqv[190]);
	local[0]= fqv[8];
	local[1]= fqv[100];
	local[2]= loadglobal(fqv[101]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[59];
	local[1]= fqv[100];
	local[2]= loadglobal(fqv[101]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[191],module,XeventF1612next_event,fqv[192]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[193],module,XeventF1613event_type,fqv[194]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[195],module,XeventF1614event_x,fqv[196]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[197],module,XeventF1615event_y,fqv[198]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[199],module,XeventF1616event_x_root,fqv[200]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[201],module,XeventF1617event_y_root,fqv[202]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[203],module,XeventF1618event_pos,fqv[204]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[205],module,XeventF1619event_key,fqv[206]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[207],module,XeventF1620event_root_pos,fqv[208]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[209],module,XeventF1621event_width,fqv[210]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[211],module,XeventF1622event_height,fqv[212]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[213],module,XeventF1623event_time,fqv[214]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[215],module,XeventF1624event_window,fqv[216]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[217],module,XeventF1625event_button,fqv[218]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[219],module,XeventF1626event_state,fqv[220]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[221],module,XeventF1627event_shift,fqv[222]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[223],module,XeventF1628event_control,fqv[224]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[225],module,XeventF1629event_meta,fqv[226]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[227],module,XeventF1630event_left,fqv[228]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[229],module,XeventF1631event_middle,fqv[230]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[231],module,XeventF1632event_right,fqv[232]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[233],module,XeventF1633event_pressed,fqv[234]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[235],module,XeventF1634print_event,fqv[236]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[237],module,XeventF1635display_events,fqv[238]);
	local[0]= fqv[35];
	local[1]= fqv[100];
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,1,local+2,&ftab[17],fqv[239]); /*make-string*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1733xwindow_event_notify_print,fqv[240],fqv[31],fqv[241]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1735xwindow_event_notify_dispatch,fqv[27],fqv[31],fqv[242]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1737xwindow_event_notify,fqv[24],fqv[31],fqv[243]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1745xwindow_keyrelease,fqv[22],fqv[31],fqv[244]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1749xwindow_keypress,fqv[245],fqv[31],fqv[246]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1753xwindow_keyenter,fqv[37],fqv[31],fqv[247]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1759xwindow_buttonpress,fqv[40],fqv[31],fqv[248]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1763xwindow_buttonrelease,fqv[29],fqv[31],fqv[249]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1767xwindow_motionnotify,fqv[43],fqv[31],fqv[250]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1771xwindow_enternotify,fqv[45],fqv[31],fqv[251]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1775xwindow_leavenotify,fqv[47],fqv[31],fqv[252]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1779xwindow_configurenotify,fqv[253],fqv[31],fqv[254]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1786xwindow_configurerequest,fqv[255],fqv[31],fqv[256]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1788xwindow_expose,fqv[257],fqv[31],fqv[258]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1790xwindow_visibilitynotify,fqv[259],fqv[31],fqv[260]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XeventM1792xwindow_redraw,fqv[52],fqv[31],fqv[261]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[74],module,XeventF1636process_event,fqv[262]);
	local[0]= fqv[61];
	local[1]= fqv[100];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[58];
	local[1]= fqv[100];
	local[2]= T;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[68],module,XeventF1637window_main_one,fqv[263]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[76],module,XeventF1813,fqv[264]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[265],module,XeventF1818,fqv[266]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[83],module,XeventF1638wmlerror,fqv[267]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[86],module,XeventF1639window_main_thread2,fqv[268]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[269],module,XeventF1640window_main_thread,fqv[270]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[271],module,XeventF1641display_fd,fqv[272]);
	local[0]= fqv[91];
	local[1]= fqv[273];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XeventIF1854;
	local[0]= fqv[91];
	local[1]= fqv[273];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[91];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XeventIF1856;
	local[0]= fqv[91];
	local[1]= fqv[100];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XeventIF1857;
XeventIF1856:
	local[0]= NIL;
XeventIF1857:
	local[0]= fqv[91];
	goto XeventIF1855;
XeventIF1854:
	local[0]= NIL;
XeventIF1855:
	ctx->vsp=local+0;
	compfun(ctx,fqv[274],module,XeventF1642repwin,fqv[275]);
	local[0]= fqv[276];
	local[1]= fqv[277];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[278]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<19; i++) ftab[i]=fcallx;
}

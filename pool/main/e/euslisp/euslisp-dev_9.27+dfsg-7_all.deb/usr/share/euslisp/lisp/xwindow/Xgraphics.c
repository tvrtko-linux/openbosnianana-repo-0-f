/* ./Xgraphics.c :  entry=Xgraphics */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "Xgraphics.h"
#pragma init (register_Xgraphics)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___Xgraphics();
extern pointer build_quote_vector();
static int register_Xgraphics()
  { add_module_initializer("___Xgraphics", ___Xgraphics);}

static pointer XgraphicF957gcvalues_function();
static pointer XgraphicF958set_gcvalues_function();
static pointer XgraphicF959gcvalues_plane_mask();
static pointer XgraphicF960set_gcvalues_plane_mask();
static pointer XgraphicF961gcvalues_foreground();
static pointer XgraphicF962set_gcvalues_foreground();
static pointer XgraphicF963gcvalues_background();
static pointer XgraphicF964set_gcvalues_background();
static pointer XgraphicF965gcvalues_line_width();
static pointer XgraphicF966set_gcvalues_line_width();
static pointer XgraphicF967gcvalues_line_style();
static pointer XgraphicF968set_gcvalues_line_style();
static pointer XgraphicF969gcvalues_cap_style();
static pointer XgraphicF970set_gcvalues_cap_style();
static pointer XgraphicF971gcvalues_join_style();
static pointer XgraphicF972set_gcvalues_join_style();
static pointer XgraphicF973gcvalues_fill_style();
static pointer XgraphicF974set_gcvalues_fill_style();
static pointer XgraphicF975gcvalues_fill_rule();
static pointer XgraphicF976set_gcvalues_fill_rule();
static pointer XgraphicF977gcvalues_arc_mode();
static pointer XgraphicF978set_gcvalues_arc_mode();
static pointer XgraphicF979gcvalues_tile();
static pointer XgraphicF980set_gcvalues_tile();
static pointer XgraphicF981gcvalues_stipple();
static pointer XgraphicF982set_gcvalues_stipple();
static pointer XgraphicF983gcvalues_ts_x_origin();
static pointer XgraphicF984set_gcvalues_ts_x_origin();
static pointer XgraphicF985gcvalues_ts_y_origin();
static pointer XgraphicF986set_gcvalues_ts_y_origin();
static pointer XgraphicF987gcvalues_font();
static pointer XgraphicF988set_gcvalues_font();
static pointer XgraphicF989gcvalues_subwindow_mode();
static pointer XgraphicF990set_gcvalues_subwindow_mode();
static pointer XgraphicF991gcvalues_graphics_exposures();
static pointer XgraphicF992set_gcvalues_graphics_exposures();
static pointer XgraphicF993gcvalues_clip_x_origin();
static pointer XgraphicF994set_gcvalues_clip_x_origin();
static pointer XgraphicF995gcvalues_clip_y_origin();
static pointer XgraphicF996set_gcvalues_clip_y_origin();
static pointer XgraphicF997gcvalues_clip_mask();
static pointer XgraphicF998set_gcvalues_clip_mask();
static pointer XgraphicF999gcvalues_dash_offset();
static pointer XgraphicF1000set_gcvalues_dash_offset();
static pointer XgraphicF1001gcvalues_dashes();
static pointer XgraphicF1002set_gcvalues_dashes();
static pointer XgraphicF1003font_id();
static pointer XgraphicF1004textdots();
static pointer XgraphicF1005create_ximage();
static pointer XgraphicF1006set_ximage();
static pointer XgraphicF1007gc_attribute_to_mask();
static pointer XgraphicF1008make_gc_from_pixmap();
static pointer XgraphicF1009make_color_gc();

/*gcvalues-function*/
static pointer XgraphicF957gcvalues_function(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1010:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-function*/
static pointer XgraphicF958set_gcvalues_function(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1011:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-plane-mask*/
static pointer XgraphicF959gcvalues_plane_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)8L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1012:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-plane-mask*/
static pointer XgraphicF960set_gcvalues_plane_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)8L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1013:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-foreground*/
static pointer XgraphicF961gcvalues_foreground(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)16L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1014:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-foreground*/
static pointer XgraphicF962set_gcvalues_foreground(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)16L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1015:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-background*/
static pointer XgraphicF963gcvalues_background(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)24L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1016:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-background*/
static pointer XgraphicF964set_gcvalues_background(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)24L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1017:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-line-width*/
static pointer XgraphicF965gcvalues_line_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)32L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1018:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-line-width*/
static pointer XgraphicF966set_gcvalues_line_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)32L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1019:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-line-style*/
static pointer XgraphicF967gcvalues_line_style(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)36L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1020:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-line-style*/
static pointer XgraphicF968set_gcvalues_line_style(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)36L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1021:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-cap-style*/
static pointer XgraphicF969gcvalues_cap_style(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)40L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1022:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-cap-style*/
static pointer XgraphicF970set_gcvalues_cap_style(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)40L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1023:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-join-style*/
static pointer XgraphicF971gcvalues_join_style(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)44L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1024:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-join-style*/
static pointer XgraphicF972set_gcvalues_join_style(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)44L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1025:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-fill-style*/
static pointer XgraphicF973gcvalues_fill_style(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)48L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1026:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-fill-style*/
static pointer XgraphicF974set_gcvalues_fill_style(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)48L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1027:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-fill-rule*/
static pointer XgraphicF975gcvalues_fill_rule(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)52L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1028:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-fill-rule*/
static pointer XgraphicF976set_gcvalues_fill_rule(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)52L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1029:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-arc-mode*/
static pointer XgraphicF977gcvalues_arc_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)56L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1030:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-arc-mode*/
static pointer XgraphicF978set_gcvalues_arc_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)56L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1031:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-tile*/
static pointer XgraphicF979gcvalues_tile(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)64L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1032:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-tile*/
static pointer XgraphicF980set_gcvalues_tile(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)64L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1033:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-stipple*/
static pointer XgraphicF981gcvalues_stipple(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)72L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1034:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-stipple*/
static pointer XgraphicF982set_gcvalues_stipple(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)72L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1035:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-ts-x-origin*/
static pointer XgraphicF983gcvalues_ts_x_origin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)80L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1036:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-ts-x-origin*/
static pointer XgraphicF984set_gcvalues_ts_x_origin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)80L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1037:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-ts-y-origin*/
static pointer XgraphicF985gcvalues_ts_y_origin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)84L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1038:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-ts-y-origin*/
static pointer XgraphicF986set_gcvalues_ts_y_origin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)84L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1039:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-font*/
static pointer XgraphicF987gcvalues_font(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)88L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1040:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-font*/
static pointer XgraphicF988set_gcvalues_font(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)88L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1041:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-subwindow-mode*/
static pointer XgraphicF989gcvalues_subwindow_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)96L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1042:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-subwindow-mode*/
static pointer XgraphicF990set_gcvalues_subwindow_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)96L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1043:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-graphics-exposures*/
static pointer XgraphicF991gcvalues_graphics_exposures(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)100L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1044:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-graphics-exposures*/
static pointer XgraphicF992set_gcvalues_graphics_exposures(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)100L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1045:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-clip-x-origin*/
static pointer XgraphicF993gcvalues_clip_x_origin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)104L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1046:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-clip-x-origin*/
static pointer XgraphicF994set_gcvalues_clip_x_origin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)104L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1047:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-clip-y-origin*/
static pointer XgraphicF995gcvalues_clip_y_origin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)108L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1048:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-clip-y-origin*/
static pointer XgraphicF996set_gcvalues_clip_y_origin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)108L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1049:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-clip-mask*/
static pointer XgraphicF997gcvalues_clip_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)112L);
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1050:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-clip-mask*/
static pointer XgraphicF998set_gcvalues_clip_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)112L);
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1051:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-dash-offset*/
static pointer XgraphicF999gcvalues_dash_offset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)120L);
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1052:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-dash-offset*/
static pointer XgraphicF1000set_gcvalues_dash_offset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)120L);
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1053:
	ctx->vsp=local; return(local[0]);}

/*gcvalues-dashes*/
static pointer XgraphicF1001gcvalues_dashes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)124L);
	local[2]= fqv[2];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
XgraphicBLK1054:
	ctx->vsp=local; return(local[0]);}

/*set-gcvalues-dashes*/
static pointer XgraphicF1002set_gcvalues_dashes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)124L);
	local[3]= fqv[2];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
XgraphicBLK1055:
	ctx->vsp=local; return(local[0]);}

/*font-id*/
static pointer XgraphicF1003font_id(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	w = argv[0];
	if (!isint(w)) goto XgraphicCON1058;
	local[2]= argv[0];
	goto XgraphicCON1057;
XgraphicCON1058:
	w = argv[0];
	if (!isstring(w)) goto XgraphicCON1059;
	local[2]= loadglobal(fqv[3]);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,2,local+2,&ftab[0],fqv[4]); /*loadqueryfont*/
	local[1] = w;
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)NUMEQUAL(ctx,2,local+2); /*=*/
	if (w==NIL) goto XgraphicIF1060;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= fqv[5];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[6]); /*warn*/
	w = local[2];
	local[2]= w;
	goto XgraphicIF1061;
XgraphicIF1060:
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)8L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)PEEK(ctx,2,local+2); /*system:peek*/
	local[2]= w;
XgraphicIF1061:
	goto XgraphicCON1057;
XgraphicCON1059:
	local[2]= NIL;
XgraphicCON1057:
	w = local[2];
	local[0]= w;
XgraphicBLK1056:
	ctx->vsp=local; return(local[0]);}

/*textdots*/
static pointer XgraphicF1004textdots(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto XgraphicENT1064;}
	local[0]= loadglobal(fqv[7]);
XgraphicENT1064:
XgraphicENT1063:
	if (n>2) maerror();
	local[1]= loadglobal(fqv[8]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= loadglobal(fqv[9]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= loadglobal(fqv[9]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)16L);
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,1,local+4,&ftab[2],fqv[10]); /*make-string*/
	local[4]= w;
	local[5]= loadglobal(fqv[3]);
	local[6]= local[0];
	local[7]= argv[0];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
	local[9]= local[1];
	local[10]= local[2];
	local[11]= local[3];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(*ftab[3])(ctx,8,local+5,&ftab[3],fqv[11]); /*querytextextents*/
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,1,local+5,&ftab[4],fqv[9]); /*c-int*/
	local[5]= w;
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,1,local+6,&ftab[4],fqv[9]); /*c-int*/
	local[6]= w;
	local[7]= local[4];
	local[8]= makeint((eusinteger_t)5L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,2,local+7); /*aref*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)256L);
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= local[4];
	local[9]= makeint((eusinteger_t)4L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,2,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MKINTVECTOR(ctx,3,local+5); /*integer-vector*/
	local[0]= w;
XgraphicBLK1062:
	ctx->vsp=local; return(local[0]);}

/*create-ximage*/
static pointer XgraphicF1005create_ximage(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[12], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto XgraphicKEY1066;
	local[0] = makeint((eusinteger_t)0L);
XgraphicKEY1066:
	if (n & (1<<1)) goto XgraphicKEY1067;
	local[1] = makeint((eusinteger_t)0L);
XgraphicKEY1067:
	if (n & (1<<2)) goto XgraphicKEY1068;
	local[2] = loadglobal(fqv[13]);
XgraphicKEY1068:
	if (n & (1<<3)) goto XgraphicKEY1069;
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,1,local+6,&ftab[5],fqv[14]); /*visual-depth*/
	local[3] = w;
XgraphicKEY1069:
	if (n & (1<<4)) goto XgraphicKEY1070;
	local[4] = makeint((eusinteger_t)2L);
XgraphicKEY1070:
	if (n & (1<<5)) goto XgraphicKEY1071;
	local[5] = makeint((eusinteger_t)0L);
XgraphicKEY1071:
	local[6]= NIL;
	local[7]= NIL;
	local[8]= local[3];
	local[9]= local[8];
	if (fqv[15]!=local[9]) goto XgraphicIF1072;
	local[9]= makeint((eusinteger_t)8L);
	goto XgraphicIF1073;
XgraphicIF1072:
	local[9]= local[8];
	if (fqv[16]!=local[9]) goto XgraphicIF1074;
	local[9]= makeint((eusinteger_t)16L);
	goto XgraphicIF1075;
XgraphicIF1074:
	local[9]= local[8];
	if (fqv[17]!=local[9]) goto XgraphicIF1076;
	local[9]= makeint((eusinteger_t)16L);
	goto XgraphicIF1077;
XgraphicIF1076:
	if (T==NIL) goto XgraphicIF1078;
	local[9]= makeint((eusinteger_t)32L);
	goto XgraphicIF1079;
XgraphicIF1078:
	local[9]= NIL;
XgraphicIF1079:
XgraphicIF1077:
XgraphicIF1075:
XgraphicIF1073:
	w = local[9];
	local[6] = w;
	local[8]= loadglobal(fqv[3]);
	local[9]= local[2];
	local[10]= local[3];
	local[11]= local[4];
	local[12]= local[5];
	local[13]= argv[0];
	local[14]= local[0];
	local[15]= local[1];
	local[16]= local[6];
	local[17]= local[0];
	local[18]= local[6];
	local[19]= makeint((eusinteger_t)8L);
	ctx->vsp=local+20;
	w=(pointer)QUOTIENT(ctx,2,local+18); /*/*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)TIMES(ctx,2,local+17); /***/
	local[17]= w;
	ctx->vsp=local+18;
	w=(*ftab[6])(ctx,10,local+8,&ftab[6],fqv[18]); /*createimage*/
	local[7] = w;
	local[8]= local[7];
	local[9]= makeint((eusinteger_t)88L);
	ctx->vsp=local+10;
	w=(*ftab[7])(ctx,2,local+8,&ftab[7],fqv[19]); /*make-foreign-string*/
	local[0]= w;
XgraphicBLK1065:
	ctx->vsp=local; return(local[0]);}

/*set-ximage*/
static pointer XgraphicF1006set_ximage(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto XgraphicENT1084;}
	local[0]= loadglobal(fqv[13]);
XgraphicENT1084:
	if (n>=6) { local[1]=(argv[5]); goto XgraphicENT1083;}
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,1,local+1,&ftab[5],fqv[14]); /*visual-depth*/
	local[1]= w;
XgraphicENT1083:
	if (n>=7) { local[2]=(argv[6]); goto XgraphicENT1082;}
	local[2]= local[1];
XgraphicENT1082:
XgraphicENT1081:
	if (n>7) maerror();
	local[3]= argv[2];
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= fqv[0];
	ctx->vsp=local+7;
	w=(pointer)POKE(ctx,4,local+3); /*system:poke*/
	local[3]= argv[3];
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)4L);
	local[6]= fqv[0];
	ctx->vsp=local+7;
	w=(pointer)POKE(ctx,4,local+3); /*system:poke*/
	local[3]= makeint((eusinteger_t)2L);
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)12L);
	local[6]= fqv[0];
	ctx->vsp=local+7;
	w=(pointer)POKE(ctx,4,local+3); /*system:poke*/
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)ADDRESS(ctx,1,local+3); /*system:address*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)16L);
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)16L);
	local[6]= fqv[1];
	ctx->vsp=local+7;
	w=(pointer)POKE(ctx,4,local+3); /*system:poke*/
	local[3]= loadglobal(fqv[20]);
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)24L);
	local[6]= fqv[0];
	ctx->vsp=local+7;
	w=(pointer)POKE(ctx,4,local+3); /*system:poke*/
	local[3]= local[2];
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)28L);
	local[6]= fqv[0];
	ctx->vsp=local+7;
	w=(pointer)POKE(ctx,4,local+3); /*system:poke*/
	local[3]= loadglobal(fqv[20]);
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)32L);
	local[6]= fqv[0];
	ctx->vsp=local+7;
	w=(pointer)POKE(ctx,4,local+3); /*system:poke*/
	local[3]= local[2];
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)36L);
	local[6]= fqv[0];
	ctx->vsp=local+7;
	w=(pointer)POKE(ctx,4,local+3); /*system:poke*/
	local[3]= local[1];
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)40L);
	local[6]= fqv[0];
	ctx->vsp=local+7;
	w=(pointer)POKE(ctx,4,local+3); /*system:poke*/
	local[3]= argv[2];
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)8L);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)44L);
	local[6]= fqv[0];
	ctx->vsp=local+7;
	w=(pointer)POKE(ctx,4,local+3); /*system:poke*/
	local[3]= local[1];
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)48L);
	local[6]= fqv[0];
	ctx->vsp=local+7;
	w=(pointer)POKE(ctx,4,local+3); /*system:poke*/
	local[3]= loadglobal(fqv[21]);
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)56L);
	local[6]= fqv[1];
	ctx->vsp=local+7;
	w=(pointer)POKE(ctx,4,local+3); /*system:poke*/
	local[3]= loadglobal(fqv[22]);
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)64L);
	local[6]= fqv[1];
	ctx->vsp=local+7;
	w=(pointer)POKE(ctx,4,local+3); /*system:poke*/
	local[3]= loadglobal(fqv[23]);
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)72L);
	local[6]= fqv[1];
	ctx->vsp=local+7;
	w=(pointer)POKE(ctx,4,local+3); /*system:poke*/
	w = argv[0];
	local[0]= w;
XgraphicBLK1080:
	ctx->vsp=local; return(local[0]);}

/*gc-attribute-to-mask*/
static pointer XgraphicF1007gc_attribute_to_mask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[24];
	ctx->vsp=local+2;
	w=(*ftab[8])(ctx,2,local+0,&ftab[8],fqv[25]); /*assoc*/
	local[0]= w;
	if (local[0]==NIL) goto XgraphicIF1086;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	goto XgraphicIF1087;
XgraphicIF1086:
	local[1]= makeint((eusinteger_t)0L);
XgraphicIF1087:
	w = local[1];
	local[0]= w;
XgraphicBLK1085:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer XgraphicM1088gcontext_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[2] = argv[2];
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= loadglobal(fqv[26]);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[9])(ctx,3,local+0,&ftab[9],fqv[27]); /*sethash*/
	w = argv[0];
	local[0]= w;
XgraphicBLK1089:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XgraphicM1090gcontext_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XgraphicRST1092:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[28], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto XgraphicKEY1093;
	local[5]= loadglobal(fqv[3]);
	ctx->vsp=local+6;
	w=(*ftab[10])(ctx,1,local+5,&ftab[10],fqv[29]); /*defaultrootwindow*/
	local[1] = w;
XgraphicKEY1093:
	if (n & (1<<1)) goto XgraphicKEY1094;
	local[2] = loadglobal(fqv[30]);
XgraphicKEY1094:
	if (n & (1<<2)) goto XgraphicKEY1095;
	local[3] = loadglobal(fqv[31]);
XgraphicKEY1095:
	if (n & (1<<3)) goto XgraphicKEY1096;
	local[4] = NIL;
XgraphicKEY1096:
	local[5]= argv[0];
	local[6]= fqv[32];
	local[7]= loadglobal(fqv[3]);
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= loadglobal(fqv[33]);
	ctx->vsp=local+11;
	w=(*ftab[11])(ctx,4,local+7,&ftab[11],fqv[34]); /*creategc*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	if (local[4]==NIL) goto XgraphicIF1097;
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[35]));
	local[7]= fqv[36];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SENDMESSAGE(ctx,4,local+5); /*send-message*/
	local[5]= w;
	goto XgraphicIF1098;
XgraphicIF1097:
	local[5]= NIL;
XgraphicIF1098:
	local[5]= (pointer)get_sym_func(fqv[37]);
	local[6]= argv[0];
	local[7]= fqv[38];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,4,local+5); /*apply*/
	w = argv[0];
	local[0]= w;
XgraphicBLK1091:
	ctx->vsp=local; return(local[0]);}

/*:free*/
static pointer XgraphicM1099gcontext_free(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[3]);
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(*ftab[12])(ctx,2,local+0,&ftab[12],fqv[39]); /*freegc*/
	local[0]= w;
XgraphicBLK1100:
	ctx->vsp=local; return(local[0]);}

/*:gc*/
static pointer XgraphicM1101gcontext_gc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
XgraphicBLK1102:
	ctx->vsp=local; return(local[0]);}

/*:copy*/
static pointer XgraphicM1103gcontext_copy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[40]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[41];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = local[0];
	local[0]= w;
	local[1]= loadglobal(fqv[3]);
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[42];
	local[4]= local[0];
	local[5]= fqv[43];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[13])(ctx,4,local+1,&ftab[13],fqv[44]); /*copygc*/
	w = local[0];
	local[0]= w;
XgraphicBLK1104:
	ctx->vsp=local; return(local[0]);}

/*:function-to-value*/
static pointer XgraphicM1105gcontext_function_to_value(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	if (!issymbol(w)) goto XgraphicIF1107;
	local[0]= argv[2];
	local[1]= fqv[45];
	ctx->vsp=local+2;
	w=(*ftab[8])(ctx,2,local+0,&ftab[8],fqv[25]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	local[0]= argv[2];
	goto XgraphicIF1108;
XgraphicIF1107:
	local[0]= NIL;
XgraphicIF1108:
	w = argv[2];
	if (isint(w)) goto XgraphicIF1109;
	local[0]= fqv[46];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
	goto XgraphicIF1110;
XgraphicIF1109:
	local[0]= NIL;
XgraphicIF1110:
	w = argv[2];
	local[0]= w;
XgraphicBLK1106:
	ctx->vsp=local; return(local[0]);}

/*:function*/
static pointer XgraphicM1111gcontext_function(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[3]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[0];
	local[3]= fqv[47];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[14])(ctx,3,local+0,&ftab[14],fqv[48]); /*setfunction*/
	local[0]= w;
XgraphicBLK1112:
	ctx->vsp=local; return(local[0]);}

/*:foreground*/
static pointer XgraphicM1113gcontext_foreground(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XgraphicENT1117;}
	local[0]= NIL;
XgraphicENT1117:
	if (n>=4) { local[1]=(argv[3]); goto XgraphicENT1116;}
	local[1]= loadglobal(fqv[49]);
XgraphicENT1116:
XgraphicENT1115:
	if (n>4) maerror();
	w = local[0];
	if (!isstring(w)) goto XgraphicIF1118;
	local[2]= local[1];
	local[3]= fqv[50];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[0] = w;
	local[2]= local[0];
	goto XgraphicIF1119;
XgraphicIF1118:
	local[2]= NIL;
XgraphicIF1119:
	if (local[0]==NIL) goto XgraphicIF1120;
	local[2]= loadglobal(fqv[3]);
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[15])(ctx,3,local+2,&ftab[15],fqv[51]); /*setforeground*/
	local[2]= w;
	goto XgraphicIF1121;
XgraphicIF1120:
	local[2]= argv[0];
	local[3]= fqv[52];
	local[4]= fqv[53];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
XgraphicIF1121:
	w = local[2];
	local[0]= w;
XgraphicBLK1114:
	ctx->vsp=local; return(local[0]);}

/*:background*/
static pointer XgraphicM1122gcontext_background(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XgraphicENT1126;}
	local[0]= NIL;
XgraphicENT1126:
	if (n>=4) { local[1]=(argv[3]); goto XgraphicENT1125;}
	local[1]= loadglobal(fqv[49]);
XgraphicENT1125:
XgraphicENT1124:
	if (n>4) maerror();
	w = local[0];
	if (!isstring(w)) goto XgraphicIF1127;
	local[2]= local[1];
	local[3]= fqv[50];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[0] = w;
	local[2]= local[0];
	goto XgraphicIF1128;
XgraphicIF1127:
	local[2]= NIL;
XgraphicIF1128:
	if (local[0]==NIL) goto XgraphicIF1129;
	local[2]= loadglobal(fqv[3]);
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[16])(ctx,3,local+2,&ftab[16],fqv[54]); /*setbackground*/
	local[2]= w;
	goto XgraphicIF1130;
XgraphicIF1129:
	local[2]= argv[0];
	local[3]= fqv[52];
	local[4]= fqv[55];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
XgraphicIF1130:
	w = local[2];
	local[0]= w;
XgraphicBLK1123:
	ctx->vsp=local; return(local[0]);}

/*:foreback*/
static pointer XgraphicM1131gcontext_foreback(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XgraphicENT1135;}
	local[0]= NIL;
XgraphicENT1135:
	if (n>=4) { local[1]=(argv[3]); goto XgraphicENT1134;}
	local[1]= NIL;
XgraphicENT1134:
XgraphicENT1133:
	if (n>4) maerror();
	local[2]= argv[0];
	local[3]= fqv[56];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[57];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[0]= w;
XgraphicBLK1132:
	ctx->vsp=local; return(local[0]);}

/*:reverse*/
static pointer XgraphicM1136gcontext_reverse(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
	local[4]= fqv[58];
	local[5]= fqv[53];
	local[6]= fqv[55];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[0] = w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XgraphicF961gcvalues_foreground(ctx,1,local+3); /*gcvalues-foreground*/
	local[1] = w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XgraphicF963gcvalues_background(ctx,1,local+3); /*gcvalues-background*/
	local[2] = w;
	local[3]= argv[0];
	local[4]= fqv[38];
	local[5]= fqv[56];
	local[6]= local[2];
	local[7]= fqv[57];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,6,local+3); /*send*/
	local[3]= local[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[0]= w;
XgraphicBLK1137:
	ctx->vsp=local; return(local[0]);}

/*:planemask*/
static pointer XgraphicM1138gcontext_planemask(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XgraphicENT1141;}
	local[0]= NIL;
XgraphicENT1141:
XgraphicENT1140:
	if (n>3) maerror();
	if (local[0]==NIL) goto XgraphicIF1142;
	local[1]= loadglobal(fqv[3]);
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[17])(ctx,3,local+1,&ftab[17],fqv[59]); /*setplanemask*/
	local[1]= w;
	goto XgraphicIF1143;
XgraphicIF1142:
	local[1]= argv[0];
	local[2]= fqv[52];
	local[3]= fqv[60];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
XgraphicIF1143:
	w = local[1];
	local[0]= w;
XgraphicBLK1139:
	ctx->vsp=local; return(local[0]);}

/*:line-width*/
static pointer XgraphicM1144gcontext_line_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XgraphicENT1147;}
	local[0]= NIL;
XgraphicENT1147:
XgraphicENT1146:
	if (n>3) maerror();
	if (local[0]==NIL) goto XgraphicIF1148;
	local[1]= argv[0];
	local[2]= fqv[38];
	local[3]= fqv[61];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto XgraphicIF1149;
XgraphicIF1148:
	local[1]= argv[0];
	local[2]= fqv[52];
	local[3]= fqv[62];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
XgraphicIF1149:
	w = local[1];
	local[0]= w;
XgraphicBLK1145:
	ctx->vsp=local; return(local[0]);}

/*:line-style*/
static pointer XgraphicM1150gcontext_line_style(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XgraphicENT1153;}
	local[0]= NIL;
XgraphicENT1153:
XgraphicENT1152:
	if (n>3) maerror();
	if (local[0]==NIL) goto XgraphicIF1154;
	local[1]= argv[0];
	local[2]= fqv[38];
	local[3]= fqv[63];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto XgraphicIF1155;
XgraphicIF1154:
	local[1]= argv[0];
	local[2]= fqv[52];
	local[3]= fqv[64];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
XgraphicIF1155:
	w = local[1];
	local[0]= w;
XgraphicBLK1151:
	ctx->vsp=local; return(local[0]);}

/*:cap-style*/
static pointer XgraphicM1156gcontext_cap_style(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XgraphicENT1159;}
	local[0]= NIL;
XgraphicENT1159:
XgraphicENT1158:
	if (n>3) maerror();
	if (local[0]==NIL) goto XgraphicIF1160;
	local[1]= argv[0];
	local[2]= fqv[38];
	local[3]= fqv[65];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto XgraphicIF1161;
XgraphicIF1160:
	local[1]= argv[0];
	local[2]= fqv[52];
	local[3]= fqv[66];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
XgraphicIF1161:
	w = local[1];
	local[0]= w;
XgraphicBLK1157:
	ctx->vsp=local; return(local[0]);}

/*:join-style*/
static pointer XgraphicM1162gcontext_join_style(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XgraphicENT1165;}
	local[0]= NIL;
XgraphicENT1165:
XgraphicENT1164:
	if (n>3) maerror();
	if (local[0]==NIL) goto XgraphicIF1166;
	local[1]= argv[0];
	local[2]= fqv[38];
	local[3]= fqv[67];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto XgraphicIF1167;
XgraphicIF1166:
	local[1]= argv[0];
	local[2]= fqv[52];
	local[3]= fqv[68];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
XgraphicIF1167:
	w = local[1];
	local[0]= w;
XgraphicBLK1163:
	ctx->vsp=local; return(local[0]);}

/*:dash*/
static pointer XgraphicM1168gcontext_dash(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XgraphicRST1170:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= local[0];
	local[2]= loadglobal(fqv[69]);
	ctx->vsp=local+3;
	w=(pointer)COERCE(ctx,2,local+1); /*coerce*/
	local[0] = w;
	local[1]= loadglobal(fqv[3]);
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[18])(ctx,5,local+1,&ftab[18],fqv[70]); /*setdashes*/
	local[0]= w;
XgraphicBLK1169:
	ctx->vsp=local; return(local[0]);}

/*:fill-style*/
static pointer XgraphicM1171gcontext_fill_style(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XgraphicENT1174;}
	local[0]= NIL;
XgraphicENT1174:
XgraphicENT1173:
	if (n>3) maerror();
	if (local[0]==NIL) goto XgraphicIF1175;
	local[1]= argv[0];
	local[2]= fqv[38];
	local[3]= fqv[71];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto XgraphicIF1176;
XgraphicIF1175:
	local[1]= argv[0];
	local[2]= fqv[52];
	local[3]= fqv[72];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
XgraphicIF1176:
	w = local[1];
	local[0]= w;
XgraphicBLK1172:
	ctx->vsp=local; return(local[0]);}

/*:fill-rule*/
static pointer XgraphicM1177gcontext_fill_rule(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XgraphicENT1180;}
	local[0]= NIL;
XgraphicENT1180:
XgraphicENT1179:
	if (n>3) maerror();
	if (local[0]==NIL) goto XgraphicIF1181;
	local[1]= argv[0];
	local[2]= fqv[38];
	local[3]= fqv[73];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto XgraphicIF1182;
XgraphicIF1181:
	local[1]= argv[0];
	local[2]= fqv[52];
	local[3]= fqv[74];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
XgraphicIF1182:
	w = local[1];
	local[0]= w;
XgraphicBLK1178:
	ctx->vsp=local; return(local[0]);}

/*:change-attributes*/
static pointer XgraphicM1183gcontext_change_attributes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XgraphicRST1185:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[75], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto XgraphicKEY1186;
	local[1] = NIL;
XgraphicKEY1186:
	if (n & (1<<1)) goto XgraphicKEY1187;
	local[2] = NIL;
XgraphicKEY1187:
	if (n & (1<<2)) goto XgraphicKEY1188;
	local[3] = NIL;
XgraphicKEY1188:
	if (n & (1<<3)) goto XgraphicKEY1189;
	local[4] = NIL;
XgraphicKEY1189:
	if (n & (1<<4)) goto XgraphicKEY1190;
	local[5] = NIL;
XgraphicKEY1190:
	if (n & (1<<5)) goto XgraphicKEY1191;
	local[6] = NIL;
XgraphicKEY1191:
	if (n & (1<<6)) goto XgraphicKEY1192;
	local[7] = NIL;
XgraphicKEY1192:
	if (n & (1<<7)) goto XgraphicKEY1193;
	local[8] = NIL;
XgraphicKEY1193:
	if (n & (1<<8)) goto XgraphicKEY1194;
	local[9] = NIL;
XgraphicKEY1194:
	if (n & (1<<9)) goto XgraphicKEY1195;
	local[10] = NIL;
XgraphicKEY1195:
	if (n & (1<<10)) goto XgraphicKEY1196;
	local[11] = NIL;
XgraphicKEY1196:
	if (n & (1<<11)) goto XgraphicKEY1197;
	local[12] = loadglobal(fqv[49]);
XgraphicKEY1197:
	if (n & (1<<12)) goto XgraphicKEY1198;
	local[13] = NIL;
XgraphicKEY1198:
	if (n & (1<<13)) goto XgraphicKEY1199;
	local[14] = NIL;
XgraphicKEY1199:
	if (n & (1<<14)) goto XgraphicKEY1200;
	local[15] = makeint((eusinteger_t)0L);
XgraphicKEY1200:
	if (n & (1<<15)) goto XgraphicKEY1201;
	local[16] = NIL;
XgraphicKEY1201:
	if (n & (1<<16)) goto XgraphicKEY1202;
	local[17] = NIL;
XgraphicKEY1202:
	local[18]= NIL;
	local[19]= makeint((eusinteger_t)0L);
	local[20]= NIL;
	local[21]= NIL;
	local[22]= NIL;
XgraphicWHL1203:
	if (local[0]==NIL) goto XgraphicWHX1204;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[23];
	local[21] = w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[23];
	local[22] = w;
	local[23]= local[21];
	local[24]= local[23];
	if (fqv[76]!=local[24]) goto XgraphicIF1206;
	local[24]= local[22];
	ctx->vsp=local+25;
	w=(pointer)XgraphicF1003font_id(ctx,1,local+24); /*font-id*/
	local[22] = w;
	local[24]= local[22];
	goto XgraphicIF1207;
XgraphicIF1206:
	local[24]= local[23];
	if (fqv[77]!=local[24]) goto XgraphicIF1208;
	local[24]= argv[0];
	local[25]= fqv[47];
	local[26]= local[22];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,3,local+24); /*send*/
	local[22] = w;
	local[24]= local[22];
	goto XgraphicIF1209;
XgraphicIF1208:
	local[24]= local[23];
	if (fqv[56]!=local[24]) goto XgraphicIF1210;
	local[24]= local[12];
	local[25]= fqv[50];
	local[26]= local[22];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,3,local+24); /*send*/
	local[22] = w;
	local[24]= local[22];
	goto XgraphicIF1211;
XgraphicIF1210:
	local[24]= local[23];
	if (fqv[57]!=local[24]) goto XgraphicIF1212;
	local[24]= local[12];
	local[25]= fqv[50];
	local[26]= local[22];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,3,local+24); /*send*/
	local[22] = w;
	local[24]= local[22];
	goto XgraphicIF1213;
XgraphicIF1212:
	local[24]= NIL;
XgraphicIF1213:
XgraphicIF1211:
XgraphicIF1209:
XgraphicIF1207:
	w = local[24];
	local[23]= local[21];
	ctx->vsp=local+24;
	w=(pointer)XgraphicF1007gc_attribute_to_mask(ctx,1,local+23); /*gc-attribute-to-mask*/
	local[20] = w;
	local[23]= local[20];
	local[24]= makeint((eusinteger_t)0L);
	ctx->vsp=local+25;
	w=(*ftab[19])(ctx,2,local+23,&ftab[19],fqv[78]); /*/=*/
	if (w==NIL) goto XgraphicIF1214;
	local[23]= local[19];
	local[24]= local[20];
	ctx->vsp=local+25;
	w=(pointer)LOGIOR(ctx,2,local+23); /*logior*/
	local[19] = w;
	local[23]= loadglobal(fqv[33]);
	local[24]= fqv[79];
	local[25]= local[22];
	local[26]= local[21];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,4,local+23); /*send*/
	local[23]= w;
	goto XgraphicIF1215;
XgraphicIF1214:
	local[23]= NIL;
XgraphicIF1215:
	goto XgraphicWHL1203;
XgraphicWHX1204:
	local[23]= NIL;
XgraphicBLK1205:
	local[23]= loadglobal(fqv[3]);
	local[24]= argv[0]->c.obj.iv[2];
	local[25]= local[19];
	local[26]= loadglobal(fqv[33]);
	ctx->vsp=local+27;
	w=(*ftab[20])(ctx,4,local+23,&ftab[20],fqv[80]); /*changegc*/
	w = local[19];
	local[0]= w;
XgraphicBLK1184:
	ctx->vsp=local; return(local[0]);}

/*:get-attributes*/
static pointer XgraphicM1216gcontext_get_attributes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XgraphicRST1218:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= NIL;
	local[3]= local[0];
XgraphicWHL1219:
	if (local[3]==NIL) goto XgraphicWHX1220;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	w = local[2];
	if (!isint(w)) goto XgraphicCON1223;
	local[4]= local[2];
	goto XgraphicCON1222;
XgraphicCON1223:
	w = local[2];
	if (!issymbol(w)) goto XgraphicCON1224;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)XgraphicF1007gc_attribute_to_mask(ctx,1,local+4); /*gc-attribute-to-mask*/
	local[4]= w;
	goto XgraphicCON1222;
XgraphicCON1224:
	local[4]= NIL;
XgraphicCON1222:
	ctx->vsp=local+5;
	w=(pointer)LOGIOR(ctx,1,local+4); /*logior*/
	local[1] = w;
	goto XgraphicWHL1219;
XgraphicWHX1220:
	local[4]= NIL;
XgraphicBLK1221:
	w = NIL;
	local[2]= loadglobal(fqv[3]);
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= local[1];
	local[5]= loadglobal(fqv[33]);
	ctx->vsp=local+6;
	w=(*ftab[21])(ctx,4,local+2,&ftab[21],fqv[81]); /*getgcvalues*/
	w = loadglobal(fqv[33]);
	local[0]= w;
XgraphicBLK1217:
	ctx->vsp=local; return(local[0]);}

/*:get-attribute*/
static pointer XgraphicM1225gcontext_get_attribute(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[58];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[82];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XgraphicBLK1226:
	ctx->vsp=local; return(local[0]);}

/*:font*/
static pointer XgraphicM1227gcontext_font(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XgraphicENT1230;}
	local[0]= NIL;
XgraphicENT1230:
XgraphicENT1229:
	if (n>3) maerror();
	local[1]= NIL;
	w = local[0];
	if (!isstring(w)) goto XgraphicCON1232;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)XgraphicF1003font_id(ctx,1,local+2); /*font-id*/
	local[1] = w;
	local[2]= local[1];
	goto XgraphicCON1231;
XgraphicCON1232:
	w = local[0];
	if (!isint(w)) goto XgraphicCON1233;
	local[1] = local[0];
	local[2]= local[1];
	goto XgraphicCON1231;
XgraphicCON1233:
	if (local[0]!=NIL) goto XgraphicCON1234;
	local[2]= argv[0];
	local[3]= fqv[52];
	local[4]= fqv[83];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	ctx->vsp=local+2;
	local[0]=w;
	goto XgraphicBLK1228;
	goto XgraphicCON1231;
XgraphicCON1234:
	local[2]= local[0];
	local[3]= fqv[76];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[1] = w;
	local[2]= local[1];
	goto XgraphicCON1231;
XgraphicCON1235:
	local[2]= NIL;
XgraphicCON1231:
	local[2]= loadglobal(fqv[3]);
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[22])(ctx,3,local+2,&ftab[22],fqv[84]); /*setfont*/
	w = local[1];
	local[0]= w;
XgraphicBLK1228:
	ctx->vsp=local; return(local[0]);}

/*:tile*/
static pointer XgraphicM1236gcontext_tile(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[3]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[2];
	local[3]= fqv[85];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[23])(ctx,3,local+0,&ftab[23],fqv[86]); /*settile*/
	local[0]= w;
XgraphicBLK1237:
	ctx->vsp=local; return(local[0]);}

/*:stipple*/
static pointer XgraphicM1238gcontext_stipple(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[3]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[2];
	local[3]= fqv[85];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[24])(ctx,3,local+0,&ftab[24],fqv[87]); /*setstipple*/
	local[0]= w;
XgraphicBLK1239:
	ctx->vsp=local; return(local[0]);}

/*make-gc-from-pixmap*/
static pointer XgraphicF1008make_gc_from_pixmap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[40]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[41];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = local[0];
	local[0]= w;
	storeglobal(fqv[88],w);
	local[0]= loadglobal(fqv[88]);
	local[1]= fqv[38];
	local[2]= fqv[71];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= loadglobal(fqv[88]);
	local[1]= fqv[89];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	w = loadglobal(fqv[88]);
	local[0]= w;
XgraphicBLK1240:
	ctx->vsp=local; return(local[0]);}

/*make-color-gc*/
static pointer XgraphicF1009make_color_gc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto XgraphicENT1244;}
	local[0]= NIL;
XgraphicENT1244:
	if (n>=3) { local[1]=(argv[2]); goto XgraphicENT1243;}
	local[1]= loadglobal(fqv[49]);
XgraphicENT1243:
XgraphicENT1242:
	if (n>3) maerror();
	local[2]= NIL;
	local[3]= NIL;
	w = argv[0];
	if (!iscons(w)) goto XgraphicCON1246;
	local[4]= (pointer)get_sym_func(fqv[37]);
	local[5]= local[1];
	local[6]= fqv[90];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,4,local+4); /*apply*/
	local[4]= w;
	goto XgraphicCON1245;
XgraphicCON1246:
	if (argv[0]==NIL) goto XgraphicCON1247;
	local[4]= local[1];
	local[5]= fqv[90];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XgraphicCON1245;
XgraphicCON1247:
	local[4]= loadglobal(fqv[31]);
	goto XgraphicCON1245;
XgraphicCON1248:
	local[4]= NIL;
XgraphicCON1245:
	local[2] = local[4];
	w = local[0];
	if (!iscons(w)) goto XgraphicCON1250;
	local[4]= (pointer)get_sym_func(fqv[37]);
	local[5]= local[1];
	local[6]= fqv[90];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,4,local+4); /*apply*/
	local[4]= w;
	goto XgraphicCON1249;
XgraphicCON1250:
	if (local[0]==NIL) goto XgraphicCON1251;
	local[4]= local[1];
	local[5]= fqv[90];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XgraphicCON1249;
XgraphicCON1251:
	local[4]= loadglobal(fqv[30]);
	goto XgraphicCON1249;
XgraphicCON1252:
	local[4]= NIL;
XgraphicCON1249:
	local[3] = local[4];
	w = local[2];
	if (!isnum(w)) goto XgraphicIF1253;
	w = local[3];
	if (!isnum(w)) goto XgraphicIF1253;
	local[4]= loadglobal(fqv[40]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= local[4];
	local[6]= fqv[41];
	local[7]= fqv[56];
	local[8]= local[2];
	local[9]= fqv[57];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,6,local+5); /*send*/
	w = local[4];
	local[4]= w;
	goto XgraphicIF1254;
XgraphicIF1253:
	local[4]= fqv[91];
	local[5]= argv[0];
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(*ftab[1])(ctx,4,local+4,&ftab[1],fqv[6]); /*warn*/
	local[4]= NIL;
XgraphicIF1254:
	w = local[4];
	local[0]= w;
XgraphicBLK1241:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___Xgraphics(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[92];
	local[1]= fqv[93];
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,2,local+0,&ftab[25],fqv[94]); /*require*/
	local[0]= fqv[95];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto XgraphicIF1255;
	local[0]= fqv[96];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[97],w);
	goto XgraphicIF1256;
XgraphicIF1255:
	local[0]= fqv[98];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
XgraphicIF1256:
	local[0]= fqv[99];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[100];
	local[1]= fqv[101];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[102];
	local[1]= fqv[101];
	local[2]= makeint((eusinteger_t)1L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[20];
	local[1]= fqv[103];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= makeint((eusinteger_t)1L);
	local[1]= fqv[104];
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,3,local+0,&ftab[26],fqv[105]); /*make-array*/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)19088743L);
	ctx->vsp=local+4;
	w=(pointer)ASET(ctx,3,local+1); /*aset*/
	local[1]= local[0];
	local[2]= loadglobal(fqv[69]);
	ctx->vsp=local+3;
	w=(*ftab[27])(ctx,2,local+1,&ftab[27],fqv[106]); /*become*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)103L);
	ctx->vsp=local+3;
	w=(pointer)EQ(ctx,2,local+1); /*eql*/
	if (w==NIL) goto XgraphicIF1257;
	local[1]= makeint((eusinteger_t)0L);
	goto XgraphicIF1258;
XgraphicIF1257:
	local[1]= makeint((eusinteger_t)1L);
XgraphicIF1258:
	storeglobal(fqv[20],local[1]);
	w = local[1];
	local[0]= fqv[107];
	local[1]= fqv[103];
	local[2]= fqv[107];
	local[3]= fqv[108];
	local[4]= loadglobal(fqv[109]);
	local[5]= fqv[110];
	local[6]= fqv[111];
	local[7]= fqv[112];
	local[8]= loadglobal(fqv[113]);
	local[9]= fqv[104];
	local[10]= fqv[114];
	local[11]= fqv[115];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[116];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[28])(ctx,13,local+2,&ftab[28],fqv[117]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= loadglobal(fqv[107]);
	local[1]= fqv[118];
	local[2]= fqv[119];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[120],module,XgraphicF957gcvalues_function,fqv[121]);
	local[0]= fqv[120];
	local[1]= fqv[122];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[120];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[120];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[120];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[122],module,XgraphicF958set_gcvalues_function,fqv[128]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[129],module,XgraphicF959gcvalues_plane_mask,fqv[130]);
	local[0]= fqv[129];
	local[1]= fqv[131];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[129];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[129];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[129];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[131],module,XgraphicF960set_gcvalues_plane_mask,fqv[132]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[133],module,XgraphicF961gcvalues_foreground,fqv[134]);
	local[0]= fqv[133];
	local[1]= fqv[135];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[133];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[133];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[133];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[135],module,XgraphicF962set_gcvalues_foreground,fqv[136]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[137],module,XgraphicF963gcvalues_background,fqv[138]);
	local[0]= fqv[137];
	local[1]= fqv[139];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[137];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[137];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[137];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[139],module,XgraphicF964set_gcvalues_background,fqv[140]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[141],module,XgraphicF965gcvalues_line_width,fqv[142]);
	local[0]= fqv[141];
	local[1]= fqv[143];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[141];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[141];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[141];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[143],module,XgraphicF966set_gcvalues_line_width,fqv[144]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[145],module,XgraphicF967gcvalues_line_style,fqv[146]);
	local[0]= fqv[145];
	local[1]= fqv[147];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[145];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[145];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[145];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[147],module,XgraphicF968set_gcvalues_line_style,fqv[148]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[149],module,XgraphicF969gcvalues_cap_style,fqv[150]);
	local[0]= fqv[149];
	local[1]= fqv[151];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[149];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[149];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[149];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[151],module,XgraphicF970set_gcvalues_cap_style,fqv[152]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[153],module,XgraphicF971gcvalues_join_style,fqv[154]);
	local[0]= fqv[153];
	local[1]= fqv[155];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[153];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[153];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[153];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[155],module,XgraphicF972set_gcvalues_join_style,fqv[156]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[157],module,XgraphicF973gcvalues_fill_style,fqv[158]);
	local[0]= fqv[157];
	local[1]= fqv[159];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[157];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[157];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[157];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[159],module,XgraphicF974set_gcvalues_fill_style,fqv[160]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[161],module,XgraphicF975gcvalues_fill_rule,fqv[162]);
	local[0]= fqv[161];
	local[1]= fqv[163];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[161];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[161];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[161];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[163],module,XgraphicF976set_gcvalues_fill_rule,fqv[164]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[165],module,XgraphicF977gcvalues_arc_mode,fqv[166]);
	local[0]= fqv[165];
	local[1]= fqv[167];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[165];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[165];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[165];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[167],module,XgraphicF978set_gcvalues_arc_mode,fqv[168]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[169],module,XgraphicF979gcvalues_tile,fqv[170]);
	local[0]= fqv[169];
	local[1]= fqv[171];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[169];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[169];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[169];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[171],module,XgraphicF980set_gcvalues_tile,fqv[172]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[173],module,XgraphicF981gcvalues_stipple,fqv[174]);
	local[0]= fqv[173];
	local[1]= fqv[175];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[173];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[173];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[173];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[175],module,XgraphicF982set_gcvalues_stipple,fqv[176]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[177],module,XgraphicF983gcvalues_ts_x_origin,fqv[178]);
	local[0]= fqv[177];
	local[1]= fqv[179];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[177];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[177];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[177];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[179],module,XgraphicF984set_gcvalues_ts_x_origin,fqv[180]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[181],module,XgraphicF985gcvalues_ts_y_origin,fqv[182]);
	local[0]= fqv[181];
	local[1]= fqv[183];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[181];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[181];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[181];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[183],module,XgraphicF986set_gcvalues_ts_y_origin,fqv[184]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[185],module,XgraphicF987gcvalues_font,fqv[186]);
	local[0]= fqv[185];
	local[1]= fqv[187];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[185];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[185];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[185];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[187],module,XgraphicF988set_gcvalues_font,fqv[188]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[189],module,XgraphicF989gcvalues_subwindow_mode,fqv[190]);
	local[0]= fqv[189];
	local[1]= fqv[191];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[189];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[189];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[189];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[191],module,XgraphicF990set_gcvalues_subwindow_mode,fqv[192]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[193],module,XgraphicF991gcvalues_graphics_exposures,fqv[194]);
	local[0]= fqv[193];
	local[1]= fqv[195];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[193];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[193];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[193];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[195],module,XgraphicF992set_gcvalues_graphics_exposures,fqv[196]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[197],module,XgraphicF993gcvalues_clip_x_origin,fqv[198]);
	local[0]= fqv[197];
	local[1]= fqv[199];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[197];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[197];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[197];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[199],module,XgraphicF994set_gcvalues_clip_x_origin,fqv[200]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[201],module,XgraphicF995gcvalues_clip_y_origin,fqv[202]);
	local[0]= fqv[201];
	local[1]= fqv[203];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[201];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[201];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[201];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[203],module,XgraphicF996set_gcvalues_clip_y_origin,fqv[204]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[205],module,XgraphicF997gcvalues_clip_mask,fqv[206]);
	local[0]= fqv[205];
	local[1]= fqv[207];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[205];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[205];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[205];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[207],module,XgraphicF998set_gcvalues_clip_mask,fqv[208]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[209],module,XgraphicF999gcvalues_dash_offset,fqv[210]);
	local[0]= fqv[209];
	local[1]= fqv[211];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[209];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[209];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[209];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[211],module,XgraphicF1000set_gcvalues_dash_offset,fqv[212]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[213],module,XgraphicF1001gcvalues_dashes,fqv[214]);
	local[0]= fqv[213];
	local[1]= fqv[215];
	local[2]= fqv[123];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[213];
	local[1]= fqv[124];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[213];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,2,local+0,&ftab[29],fqv[125]); /*remprop*/
	local[0]= fqv[213];
	local[1]= NIL;
	local[2]= fqv[127];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[215],module,XgraphicF1002set_gcvalues_dashes,fqv[216]);
	local[0]= loadglobal(fqv[107]);
	local[1]= fqv[118];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= local[0];
XgraphicWHL1259:
	if (local[3]==NIL) goto XgraphicWHX1260;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car->c.obj.iv[4];
	local[5]= loadglobal(fqv[217]);
	ctx->vsp=local+6;
	w=(pointer)INTERN(ctx,2,local+4); /*intern*/
	local[4]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	goto XgraphicWHL1259;
XgraphicWHX1260:
	local[4]= NIL;
XgraphicBLK1261:
	w = NIL;
	local[2]= local[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	local[2]= w;
	local[3]= w;
	*(ovafptr(loadglobal(fqv[107]),fqv[218])) = local[3];
	w = local[2];
	local[0]= fqv[33];
	local[1]= fqv[219];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XgraphicIF1262;
	local[0]= fqv[33];
	local[1]= fqv[219];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[33];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XgraphicIF1264;
	local[0]= fqv[33];
	local[1]= fqv[103];
	local[2]= loadglobal(fqv[107]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XgraphicIF1265;
XgraphicIF1264:
	local[0]= NIL;
XgraphicIF1265:
	local[0]= fqv[33];
	goto XgraphicIF1263;
XgraphicIF1262:
	local[0]= NIL;
XgraphicIF1263:
	ctx->vsp=local+0;
	compfun(ctx,fqv[220],module,XgraphicF1003font_id,fqv[221]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[222],module,XgraphicF1004textdots,fqv[223]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[224],module,XgraphicF1005create_ximage,fqv[225]);
	local[0]= fqv[21];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)255L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[22];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)65280L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[23];
	local[1]= fqv[103];
	local[2]= makeint((eusinteger_t)16711680L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[226],module,XgraphicF1006set_ximage,fqv[227]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[228],module,XgraphicF1007gc_attribute_to_mask,fqv[229]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1088gcontext_init,fqv[32],fqv[40],fqv[230]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1090gcontext_create,fqv[41],fqv[40],fqv[231]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1099gcontext_free,fqv[232],fqv[40],fqv[233]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1101gcontext_gc,fqv[43],fqv[40],fqv[234]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1103gcontext_copy,fqv[235],fqv[40],fqv[236]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1105gcontext_function_to_value,fqv[47],fqv[40],fqv[237]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1111gcontext_function,fqv[77],fqv[40],fqv[238]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1113gcontext_foreground,fqv[56],fqv[40],fqv[239]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1122gcontext_background,fqv[57],fqv[40],fqv[240]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1131gcontext_foreback,fqv[241],fqv[40],fqv[242]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1136gcontext_reverse,fqv[243],fqv[40],fqv[244]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1138gcontext_planemask,fqv[245],fqv[40],fqv[246]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1144gcontext_line_width,fqv[61],fqv[40],fqv[247]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1150gcontext_line_style,fqv[63],fqv[40],fqv[248]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1156gcontext_cap_style,fqv[65],fqv[40],fqv[249]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1162gcontext_join_style,fqv[67],fqv[40],fqv[250]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1168gcontext_dash,fqv[251],fqv[40],fqv[252]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1171gcontext_fill_style,fqv[71],fqv[40],fqv[253]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1177gcontext_fill_rule,fqv[73],fqv[40],fqv[254]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1183gcontext_change_attributes,fqv[38],fqv[40],fqv[255]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1216gcontext_get_attributes,fqv[58],fqv[40],fqv[256]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1225gcontext_get_attribute,fqv[52],fqv[40],fqv[257]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1227gcontext_font,fqv[76],fqv[40],fqv[258]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1236gcontext_tile,fqv[89],fqv[40],fqv[259]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XgraphicM1238gcontext_stipple,fqv[260],fqv[40],fqv[261]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[262],module,XgraphicF1008make_gc_from_pixmap,fqv[263]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[264],module,XgraphicF1009make_color_gc,fqv[265]);
	local[0]= fqv[266];
	local[1]= fqv[267];
	ctx->vsp=local+2;
	w=(*ftab[30])(ctx,2,local+0,&ftab[30],fqv[268]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<31; i++) ftab[i]=fcallx;
}

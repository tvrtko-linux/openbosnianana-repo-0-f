/* ./Xitem.c :  entry=Xitem */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "Xitem.h"
#pragma init (register_Xitem)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___Xitem();
extern pointer build_quote_vector();
static int register_Xitem()
  { add_module_initializer("___Xitem", ___Xitem);}

static pointer XitemF1949clump();
static pointer XitemF1950replace_key_arg();
static pointer XitemF1951make_topleft_edge_polygon();

/*clump*/
static pointer XitemF1949clump(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)MIN(ctx,2,local+1); /*min*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MAX(ctx,2,local+0); /*max*/
	local[0]= w;
XitemBLK1952:
	ctx->vsp=local; return(local[0]);}

/*replace-key-arg*/
static pointer XitemF1950replace_key_arg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
XitemWHL1954:
	if (argv[2]==NIL) goto XitemWHX1955;
	local[1]= argv[0];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)EQ(ctx,2,local+1); /*eql*/
	if (w==NIL) goto XitemIF1957;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	local[1]= argv[2];
	goto XitemIF1958;
XitemIF1957:
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[1];
	local[1]= w;
	w = local[0];
	ctx->vsp=local+2;
	local[0] = cons(ctx,local[1],w);
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[1];
	local[1]= w;
	w = local[0];
	ctx->vsp=local+2;
	local[0] = cons(ctx,local[1],w);
	local[1]= local[0];
XitemIF1958:
	goto XitemWHL1954;
XitemWHX1955:
	local[1]= NIL;
XitemBLK1956:
	local[1]= argv[0];
	local[2]= argv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST_STAR(ctx,3,local+1); /*list**/
	local[0]= w;
XitemBLK1953:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XitemM1959panel_item_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
XitemRST1961:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-5);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[0], &argv[5], n-5, local+1, 1);
	if (n & (1<<0)) goto XitemKEY1962;
	local[1] = makeint((eusinteger_t)100L);
XitemKEY1962:
	if (n & (1<<1)) goto XitemKEY1963;
	local[2] = local[1];
XitemKEY1963:
	if (n & (1<<2)) goto XitemKEY1964;
	local[3] = local[2];
XitemKEY1964:
	if (n & (1<<3)) goto XitemKEY1965;
	local[4] = loadglobal(fqv[1]);
XitemKEY1965:
	argv[0]->c.obj.iv[5] = local[2];
	argv[0]->c.obj.iv[6] = local[3];
	argv[0]->c.obj.iv[15] = local[4];
	argv[0]->c.obj.iv[16] = argv[2];
	argv[0]->c.obj.iv[14] = argv[4];
	if (argv[3]==NIL) goto XitemIF1966;
	local[5]= argv[3];
	goto XitemIF1967;
XitemIF1966:
	local[5]= argv[0]->c.obj.iv[7];
XitemIF1967:
	argv[0]->c.obj.iv[13] = local[5];
	local[5]= (pointer)get_sym_func(fqv[2]);
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[3]));
	local[8]= fqv[4];
	local[9]= fqv[5];
	local[10]= argv[2];
	local[11]= fqv[6];
	local[12]= local[2];
	local[13]= fqv[7];
	local[14]= local[3];
	local[15]= fqv[8];
	local[16]= local[4];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)APPLY(ctx,13,local+5); /*apply*/
	local[5]= argv[0];
	local[6]= fqv[5];
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= argv[2];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(*ftab[0])(ctx,2,local+5,&ftab[0],fqv[9]); /*textdots*/
	argv[0]->c.obj.iv[17] = w;
	w = argv[0]->c.obj.iv[17];
	local[0]= w;
XitemBLK1960:
	ctx->vsp=local; return(local[0]);}

/*:draw-label*/
static pointer XitemM1968panel_item_draw_label(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[10];
	local[2]= fqv[11];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[12];
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= argv[0]->c.obj.iv[17];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	w = argv[0]->c.obj.iv[16];
	local[0]= w;
XitemBLK1969:
	ctx->vsp=local; return(local[0]);}

/*:notify*/
static pointer XitemM1970panel_item_notify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XitemRST1972:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (argv[0]->c.obj.iv[13]==NIL) goto XitemIF1973;
	if (argv[0]->c.obj.iv[14]==NIL) goto XitemIF1973;
	local[1]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w==NIL) goto XitemIF1975;
	local[1]= (pointer)get_sym_func(fqv[13]);
	local[2]= argv[0]->c.obj.iv[13];
	w=argv[0]->c.obj.iv[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	local[5]= argv[0];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,6,local+1); /*apply*/
	local[1]= w;
	goto XitemIF1976;
XitemIF1975:
	local[1]= (pointer)get_sym_func(fqv[13]);
	local[2]= argv[0]->c.obj.iv[13];
	local[3]= argv[0]->c.obj.iv[14];
	local[4]= argv[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	local[1]= w;
XitemIF1976:
	goto XitemIF1974;
XitemIF1973:
	local[1]= NIL;
XitemIF1974:
	w = local[1];
	local[0]= w;
XitemBLK1971:
	ctx->vsp=local; return(local[0]);}

/*:keypress*/
static pointer XitemM1977panel_item_keypress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = NIL;
	local[0]= w;
XitemBLK1978:
	ctx->vsp=local; return(local[0]);}

/*:keyrelease*/
static pointer XitemM1979panel_item_keyrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = NIL;
	local[0]= w;
XitemBLK1980:
	ctx->vsp=local; return(local[0]);}

/*:buttonpress*/
static pointer XitemM1981panel_item_buttonpress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = NIL;
	local[0]= w;
XitemBLK1982:
	ctx->vsp=local; return(local[0]);}

/*:motionnotify*/
static pointer XitemM1983panel_item_motionnotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = NIL;
	local[0]= w;
XitemBLK1984:
	ctx->vsp=local; return(local[0]);}

/*:enternotify*/
static pointer XitemM1985panel_item_enternotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= NIL;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK1986:
	ctx->vsp=local; return(local[0]);}

/*:leavenotify*/
static pointer XitemM1987panel_item_leavenotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = NIL;
	local[0]= w;
XitemBLK1988:
	ctx->vsp=local; return(local[0]);}

/*make-topleft-edge-polygon*/
static pointer XitemF1951make_topleft_edge_polygon(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= loadglobal(fqv[15]);
	local[1]= makeint((eusinteger_t)2L);
	local[2]= makeint((eusinteger_t)2L);
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)6L)); i=intval(local[2]);
		local[2]=(makeint(i * j));}
	{ eusinteger_t i,j;
		j=intval(local[2]); i=intval(local[1]);
		local[1]=(makeint(i * j));}
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,2,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[16];
	local[3]= argv[0];
	local[4]= argv[1];
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= argv[4];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= argv[4];
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[9]= w;
	local[10]= argv[4];
	local[11]= argv[4];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,3,local+9); /*+*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	local[12]= argv[3];
	local[13]= argv[4];
	local[14]= argv[4];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,3,local+12); /*-*/
	local[12]= w;
	local[13]= argv[4];
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,1,local+13); /*-*/
	local[13]= w;
	local[14]= argv[4];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,12,local+3); /*list*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= fqv[17];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	w = local[0];
	local[0]= w;
XitemBLK1989:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XitemM1990button_item_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
XitemRST1992:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-5);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[18], &argv[5], n-5, local+1, 1);
	if (n & (1<<0)) goto XitemKEY1993;
	local[1] = NIL;
XitemKEY1993:
	if (n & (1<<1)) goto XitemKEY1994;
	local[2] = NIL;
XitemKEY1994:
	if (n & (1<<2)) goto XitemKEY1995;
	local[3] = loadglobal(fqv[19]);
XitemKEY1995:
	if (n & (1<<3)) goto XitemKEY1996;
	local[4] = fqv[20];
XitemKEY1996:
	if (n & (1<<4)) goto XitemKEY1997;
	local[5] = loadglobal(fqv[21]);
XitemKEY1997:
	if (n & (1<<5)) goto XitemKEY1998;
	local[6] = loadglobal(fqv[22]);
XitemKEY1998:
	if (n & (1<<6)) goto XitemKEY1999;
	local[7] = makeint((eusinteger_t)0L);
XitemKEY1999:
	if (n & (1<<7)) goto XitemKEY2000;
	local[11]= local[3];
	local[12]= loadglobal(fqv[23]);
	ctx->vsp=local+13;
	w=(pointer)DERIVEDP(ctx,2,local+11); /*derivedp*/
	if (w==NIL) goto XitemIF2001;
	local[11]= fqv[24];
	goto XitemIF2002;
XitemIF2001:
	local[11]= fqv[25];
XitemIF2002:
	local[8] = local[11];
XitemKEY2000:
	if (n & (1<<8)) goto XitemKEY2003;
	local[9] = NIL;
XitemKEY2003:
	if (n & (1<<9)) goto XitemKEY2004;
	local[10] = NIL;
XitemKEY2004:
	local[11]= NIL;
	local[12]= NIL;
	local[13]= argv[2];
	local[14]= local[5];
	ctx->vsp=local+15;
	w=(*ftab[0])(ctx,2,local+13,&ftab[0],fqv[9]); /*textdots*/
	argv[0]->c.obj.iv[17] = w;
	if (local[1]==NIL) goto XitemIF2005;
	local[13]= local[1];
	goto XitemIF2006;
XitemIF2005:
	local[13]= argv[0]->c.obj.iv[17];
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,2,local+13); /*aref*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)10L);
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
XitemIF2006:
	local[11] = local[13];
	if (local[2]==NIL) goto XitemIF2007;
	local[13]= local[2];
	goto XitemIF2008;
XitemIF2007:
	local[13]= argv[0]->c.obj.iv[17];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,2,local+13); /*aref*/
	local[13]= w;
	local[14]= argv[0]->c.obj.iv[17];
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(pointer)AREF(ctx,2,local+14); /*aref*/
	local[14]= w;
	local[15]= makeint((eusinteger_t)6L);
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,3,local+13); /*+*/
	local[13]= w;
XitemIF2008:
	local[12] = local[13];
	local[13]= (pointer)get_sym_func(fqv[2]);
	local[14]= argv[0];
	local[15]= *(ovafptr(argv[1],fqv[3]));
	local[16]= fqv[4];
	local[17]= argv[2];
	local[18]= argv[3];
	local[19]= argv[4];
	local[20]= fqv[6];
	local[21]= local[11];
	local[22]= fqv[7];
	local[23]= local[12];
	local[24]= fqv[26];
	local[25]= local[7];
	local[26]= fqv[27];
	local[27]= local[3];
	local[28]= fqv[28];
	local[29]= local[6];
	local[30]= fqv[29];
	local[31]= local[4];
	local[32]= local[0];
	ctx->vsp=local+33;
	w=(pointer)APPLY(ctx,20,local+13); /*apply*/
	local[13]= argv[0]->c.obj.iv[4];
	local[14]= makeflt(1.3999999999999994670929e+00);
	local[15]= argv[0];
	local[16]= fqv[30];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[1])(ctx,3,local+13,&ftab[1],fqv[31]); /*get-lighter-pixel*/
	argv[0]->c.obj.iv[23] = w;
	local[13]= argv[0]->c.obj.iv[4];
	local[14]= makeflt(5.9999999999999964472863e-01);
	local[15]= argv[0];
	local[16]= fqv[30];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[1])(ctx,3,local+13,&ftab[1],fqv[31]); /*get-lighter-pixel*/
	argv[0]->c.obj.iv[22] = w;
	local[13]= makeint((eusinteger_t)0L);
	local[14]= makeint((eusinteger_t)0L);
	local[15]= argv[0]->c.obj.iv[5];
	local[16]= argv[0]->c.obj.iv[6];
	local[17]= makeint((eusinteger_t)2L);
	ctx->vsp=local+18;
	w=(pointer)XitemF1951make_topleft_edge_polygon(ctx,5,local+13); /*make-topleft-edge-polygon*/
	argv[0]->c.obj.iv[24] = w;
	argv[0]->c.obj.iv[21] = local[8];
	argv[0]->c.obj.iv[20] = local[9];
	local[13]= argv[0]->c.obj.iv[3];
	local[14]= fqv[8];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= argv[2];
	local[14]= local[13];
	w = argv[0];
	w->c.obj.iv[16] = local[14];
	local[13]= argv[0];
	local[14]= fqv[32];
	local[15]= local[8];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[11]= local[10];
	local[12]= local[11];
	w = argv[0];
	w->c.obj.iv[19] = local[12];
	local[11]= argv[0]->c.obj.iv[3];
	local[12]= fqv[10];
	local[13]= fqv[11];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	w = argv[0];
	local[0]= w;
XitemBLK1991:
	ctx->vsp=local; return(local[0]);}

/*:submenu*/
static pointer XitemM2009button_item_submenu(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2012;}
	local[0]= NIL;
XitemENT2012:
XitemENT2011:
	if (n>3) maerror();
	if (local[0]==NIL) goto XitemIF2013;
	argv[0]->c.obj.iv[19] = local[0];
	local[1]= argv[0]->c.obj.iv[19];
	goto XitemIF2014;
XitemIF2013:
	local[1]= NIL;
XitemIF2014:
	w = argv[0]->c.obj.iv[19];
	local[0]= w;
XitemBLK2010:
	ctx->vsp=local; return(local[0]);}

/*:active-color*/
static pointer XitemM2015button_item_active_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2018;}
	local[0]= NIL;
XitemENT2018:
XitemENT2017:
	if (n>3) maerror();
	if (local[0]==NIL) goto XitemIF2019;
	argv[0]->c.obj.iv[20] = local[0];
	local[1]= argv[0]->c.obj.iv[20];
	goto XitemIF2020;
XitemIF2019:
	local[1]= NIL;
XitemIF2020:
	w = argv[0]->c.obj.iv[20];
	local[0]= w;
XitemBLK2016:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer XitemM2021button_item_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[3]));
	local[2]= fqv[33];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,5,local+0); /*send-message*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)XitemF1951make_topleft_edge_polygon(ctx,5,local+0); /*make-topleft-edge-polygon*/
	argv[0]->c.obj.iv[24] = w;
	local[0]= argv[0];
	local[1]= fqv[32];
	local[2]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XitemBLK2022:
	ctx->vsp=local; return(local[0]);}

/*:label*/
static pointer XitemM2023button_item_label(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2027;}
	local[0]= NIL;
XitemENT2027:
	if (n>=4) { local[1]=(argv[3]); goto XitemENT2026;}
	local[1]= makeint((eusinteger_t)10L);
XitemENT2026:
XitemENT2025:
	if (n>4) maerror();
	if (local[0]==NIL) goto XitemIF2028;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= local[0];
	local[5]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+6;
	w=(*ftab[0])(ctx,2,local+4,&ftab[0],fqv[9]); /*textdots*/
	argv[0]->c.obj.iv[17] = w;
	local[4]= local[1];
	local[5]= argv[0]->c.obj.iv[17];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)10L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MAX(ctx,2,local+4); /*max*/
	local[2] = w;
	local[4]= argv[0]->c.obj.iv[17];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[17];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)6L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,3,local+4); /*+*/
	local[3] = w;
	argv[0]->c.obj.iv[16] = local[0];
	local[4]= argv[0];
	local[5]= fqv[33];
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[2]= w;
	goto XitemIF2029;
XitemIF2028:
	local[2]= NIL;
XitemIF2029:
	w = argv[0]->c.obj.iv[16];
	local[0]= w;
XitemBLK2024:
	ctx->vsp=local; return(local[0]);}

/*:draw-label*/
static pointer XitemM2030button_item_draw_label(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2036;}
	local[0]= fqv[25];
XitemENT2036:
	if (n>=4) { local[1]=(argv[3]); goto XitemENT2035;}
	local[1]= argv[0]->c.obj.iv[4];
XitemENT2035:
	if (n>=5) { local[2]=(argv[4]); goto XitemENT2034;}
	local[2]= makeint((eusinteger_t)2L);
XitemENT2034:
	if (n>=6) { local[3]=(argv[5]); goto XitemENT2033;}
	local[3]= NIL;
XitemENT2033:
XitemENT2032:
	if (n>6) maerror();
	local[4]= argv[0];
	local[5]= fqv[34];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[0]->c.obj.iv[5];
	local[9]= argv[0]->c.obj.iv[6];
	local[10]= local[2];
	local[11]= argv[0]->c.obj.iv[23];
	local[12]= argv[0]->c.obj.iv[22];
	local[13]= argv[0]->c.obj.iv[4];
	local[14]= argv[0]->c.obj.iv[24];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,12,local+4); /*send*/
	if (local[3]!=NIL) goto XitemIF2037;
	local[4]= local[0];
	local[5]= fqv[35];
	ctx->vsp=local+6;
	w=(*ftab[2])(ctx,2,local+4,&ftab[2],fqv[36]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	local[4]= local[3];
	goto XitemIF2038;
XitemIF2037:
	local[4]= NIL;
XitemIF2038:
	if (local[3]!=NIL) goto XitemIF2039;
	local[3] = makeint((eusinteger_t)0L);
	local[4]= local[3];
	goto XitemIF2040;
XitemIF2039:
	local[4]= NIL;
XitemIF2040:
	local[4]= argv[0];
	local[5]= fqv[37];
	local[6]= argv[0]->c.obj.iv[5];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[17];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,2,local+7); /*aref*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,3,local+6); /*+*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[6];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[17];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,2,local+8); /*aref*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[17];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,2,local+9); /*aref*/
	local[9]= w;
	local[10]= argv[0]->c.obj.iv[17];
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,2,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[9]= w;
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,4,local+7); /*+*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[38];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[0]= w;
XitemBLK2031:
	ctx->vsp=local; return(local[0]);}

/*:redraw*/
static pointer XitemM2041button_item_redraw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[32];
	local[2]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XitemBLK2042:
	ctx->vsp=local; return(local[0]);}

/*:keypress*/
static pointer XitemM2043button_item_keypress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= NIL;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2044:
	ctx->vsp=local; return(local[0]);}

/*:keyrelease*/
static pointer XitemM2045button_item_keyrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= NIL;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2046:
	ctx->vsp=local; return(local[0]);}

/*:buttonpress*/
static pointer XitemM2047button_item_buttonpress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= argv[0];
	local[4]= fqv[32];
	local[5]= fqv[39];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	argv[0]->c.obj.iv[18] = T;
	local[3]= NIL;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2048:
	ctx->vsp=local; return(local[0]);}

/*:buttonrelease*/
static pointer XitemM2049button_item_buttonrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= loadglobal(fqv[14]);
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,1,local+3,&ftab[3],fqv[40]); /*event-x*/
	local[3]= w;
	local[4]= loadglobal(fqv[14]);
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,1,local+4,&ftab[4],fqv[41]); /*event-y*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[32];
	local[7]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	if (argv[0]->c.obj.iv[18]!=NIL) goto XitemOR2053;
	local[5]= argv[0]->c.obj.iv[7];
	local[6]= loadglobal(fqv[23]);
	ctx->vsp=local+7;
	w=(pointer)DERIVEDP(ctx,2,local+5); /*derivedp*/
	if (w!=NIL) goto XitemOR2053;
	goto XitemIF2051;
XitemOR2053:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[3];
	local[7]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+8;
	w=(pointer)LESSP(ctx,3,local+5); /*<*/
	if (w==NIL) goto XitemIF2051;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[4];
	local[7]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+8;
	w=(pointer)LESSP(ctx,3,local+5); /*<*/
	if (w==NIL) goto XitemIF2051;
	argv[0]->c.obj.iv[18] = NIL;
	if (argv[0]->c.obj.iv[19]==NIL) goto XitemIF2054;
	local[5]= argv[0]->c.obj.iv[19];
	local[6]= fqv[42];
	local[7]= loadglobal(fqv[14]);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,1,local+7,&ftab[5],fqv[43]); /*event-x-root*/
	local[7]= w;
	local[8]= loadglobal(fqv[14]);
	ctx->vsp=local+9;
	w=(*ftab[6])(ctx,1,local+8,&ftab[6],fqv[44]); /*event-y-root*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	goto XitemIF2055;
XitemIF2054:
	local[5]= argv[0];
	local[6]= fqv[45];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
XitemIF2055:
	goto XitemIF2052;
XitemIF2051:
	local[5]= NIL;
XitemIF2052:
	w = local[5];
	if (argv[0]->c.obj.iv[7]==NIL) goto XitemIF2056;
	local[3]= argv[0]->c.obj.iv[7];
	local[4]= fqv[46];
	local[5]= loadglobal(fqv[14]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto XitemIF2057;
XitemIF2056:
	local[3]= NIL;
XitemIF2057:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2050:
	ctx->vsp=local; return(local[0]);}

/*:enternotify*/
static pointer XitemM2058button_item_enternotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	if (argv[0]->c.obj.iv[20]==NIL) goto XitemIF2060;
	local[3]= argv[0];
	local[4]= fqv[32];
	local[5]= fqv[25];
	local[6]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto XitemIF2061;
XitemIF2060:
	local[3]= NIL;
XitemIF2061:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2059:
	ctx->vsp=local; return(local[0]);}

/*:leavenotify*/
static pointer XitemM2062button_item_leavenotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	if (argv[0]->c.obj.iv[20]==NIL) goto XitemIF2064;
	local[3]= argv[0];
	local[4]= fqv[32];
	local[5]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto XitemIF2065;
XitemIF2064:
	local[3]= NIL;
XitemIF2065:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2063:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XitemM2066menu_button_item_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
XitemRST2068:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-5);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[47], &argv[5], n-5, local+1, 1);
	if (n & (1<<0)) goto XitemKEY2069;
	local[1] = NIL;
XitemKEY2069:
	if (n & (1<<1)) goto XitemKEY2070;
	local[2] = NIL;
XitemKEY2070:
	if (n & (1<<2)) goto XitemKEY2071;
	local[3] = fqv[24];
XitemKEY2071:
	local[4]= (pointer)get_sym_func(fqv[2]);
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[3]));
	local[7]= fqv[4];
	local[8]= argv[2];
	local[9]= argv[3];
	local[10]= argv[4];
	local[11]= fqv[48];
	local[12]= local[3];
	local[13]= fqv[29];
	local[14]= fqv[49];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(pointer)APPLY(ctx,12,local+4); /*apply*/
	argv[0]->c.obj.iv[30] = local[1];
	w = argv[0];
	local[0]= w;
XitemBLK2067:
	ctx->vsp=local; return(local[0]);}

/*:label*/
static pointer XitemM2072menu_button_item_label(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2075;}
	local[0]= NIL;
XitemENT2075:
XitemENT2074:
	if (n>3) maerror();
	if (local[0]==NIL) goto XitemIF2076;
	local[1]= argv[0]->c.obj.iv[5];
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[3]));
	local[4]= fqv[50];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SENDMESSAGE(ctx,4,local+2); /*send-message*/
	local[2]= local[1];
	local[3]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+4;
	w=(*ftab[7])(ctx,2,local+2,&ftab[7],fqv[51]); /*/=*/
	if (w==NIL) goto XitemIF2078;
	local[2]= argv[0]->c.obj.iv[7];
	local[3]= fqv[52];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	goto XitemIF2079;
XitemIF2078:
	local[2]= NIL;
XitemIF2079:
	w = local[2];
	local[1]= w;
	goto XitemIF2077;
XitemIF2076:
	local[1]= NIL;
XitemIF2077:
	w = argv[0]->c.obj.iv[16];
	local[0]= w;
XitemBLK2073:
	ctx->vsp=local; return(local[0]);}

/*:popup-menu*/
static pointer XitemM2080menu_button_item_popup_menu(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[32];
	local[2]= fqv[25];
	local[3]= argv[0]->c.obj.iv[4];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[53];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[30];
	local[2]= fqv[42];
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	local[3]= w;
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[7];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[7];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
XitemBLK2081:
	ctx->vsp=local; return(local[0]);}

/*:unmap-menu*/
static pointer XitemM2082menu_button_item_unmap_menu(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[32];
	local[2]= fqv[24];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[30];
	local[1]= fqv[54];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
XitemBLK2083:
	ctx->vsp=local; return(local[0]);}

/*:buttonpress*/
static pointer XitemM2084menu_button_item_buttonpress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= argv[0];
	storeglobal(fqv[55],local[3]);
	local[3]= argv[0]->c.obj.iv[7];
	local[4]= fqv[56];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[0];
	local[4]= fqv[57];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2085:
	ctx->vsp=local; return(local[0]);}

/*:buttonrelease*/
static pointer XitemM2086menu_button_item_buttonrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= loadglobal(fqv[55]);
	if (argv[0]!=local[3]) goto XitemIF2088;
	local[3]= NIL;
	storeglobal(fqv[55],local[3]);
	local[3]= argv[0];
	local[4]= fqv[58];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= argv[0];
	local[4]= fqv[45];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	goto XitemIF2089;
XitemIF2088:
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[3]));
	local[5]= fqv[46];
	local[6]= loadglobal(fqv[14]);
	ctx->vsp=local+7;
	w=(pointer)SENDMESSAGE(ctx,4,local+3); /*send-message*/
	local[3]= w;
XitemIF2089:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2087:
	ctx->vsp=local; return(local[0]);}

/*:enternotify*/
static pointer XitemM2090menu_button_item_enternotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= loadglobal(fqv[14]);
	local[4]= T;
	ctx->vsp=local+5;
	w=(*ftab[8])(ctx,2,local+3,&ftab[8],fqv[59]); /*event-pressed*/
	if (w==NIL) goto XitemIF2092;
	local[3]= argv[0]->c.obj.iv[7];
	local[4]= fqv[56];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto XitemIF2093;
XitemIF2092:
	local[3]= NIL;
XitemIF2093:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2091:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XitemM2094text_item_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
XitemRST2096:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-5);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[60], &argv[5], n-5, local+1, 1);
	if (n & (1<<0)) goto XitemKEY2097;
	local[1] = loadglobal(fqv[1]);
XitemKEY2097:
	if (n & (1<<1)) goto XitemKEY2098;
	local[2] = makeint((eusinteger_t)20L);
XitemKEY2098:
	if (n & (1<<2)) goto XitemKEY2099;
	local[3] = NIL;
XitemKEY2099:
	if (n & (1<<3)) goto XitemKEY2100;
	local[4] = makeint((eusinteger_t)0L);
XitemKEY2100:
	local[5]= argv[2];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[0])(ctx,2,local+5,&ftab[0],fqv[9]); /*textdots*/
	argv[0]->c.obj.iv[17] = w;
	local[5]= fqv[61];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[0])(ctx,2,local+5,&ftab[0],fqv[9]); /*textdots*/
	local[5]= w;
	local[6]= local[5];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	local[7]= local[5];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,2,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[7]= local[5];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,2,local+7); /*aref*/
	local[7]= w;
	local[8]= local[2];
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= (pointer)get_sym_func(fqv[2]);
	local[10]= argv[0];
	local[11]= *(ovafptr(argv[1],fqv[3]));
	local[12]= fqv[4];
	local[13]= argv[2];
	local[14]= argv[3];
	local[15]= argv[4];
	local[16]= fqv[6];
	local[17]= argv[0]->c.obj.iv[17];
	local[18]= makeint((eusinteger_t)2L);
	ctx->vsp=local+19;
	w=(pointer)AREF(ctx,2,local+17); /*aref*/
	local[17]= w;
	local[18]= makeint((eusinteger_t)8L);
	local[19]= local[8];
	local[20]= makeint((eusinteger_t)4L);
	ctx->vsp=local+21;
	w=(pointer)PLUS(ctx,4,local+17); /*+*/
	local[17]= w;
	local[18]= fqv[7];
	local[19]= local[6];
	local[20]= makeint((eusinteger_t)6L);
	ctx->vsp=local+21;
	w=(pointer)PLUS(ctx,2,local+19); /*+*/
	local[19]= w;
	local[20]= local[0];
	ctx->vsp=local+21;
	w=(pointer)APPLY(ctx,12,local+9); /*apply*/
	local[9]= fqv[27];
	local[10]= argv[0];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)XitemF1950replace_key_arg(ctx,3,local+9); /*replace-key-arg*/
	local[0] = w;
	local[9]= fqv[26];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)XitemF1950replace_key_arg(ctx,3,local+9); /*replace-key-arg*/
	local[0] = w;
	local[9]= loadglobal(fqv[62]);
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= (pointer)get_sym_func(fqv[13]);
	local[11]= local[9];
	local[12]= fqv[4];
	local[13]= fqv[27];
	local[14]= argv[0];
	local[15]= fqv[63];
	local[16]= T;
	local[17]= fqv[8];
	local[18]= local[1];
	local[19]= fqv[64];
	local[20]= local[2];
	local[21]= fqv[65];
	local[22]= makeint((eusinteger_t)1L);
	local[23]= fqv[29];
	local[24]= fqv[66];
	local[25]= fqv[67];
	local[26]= argv[3];
	local[27]= fqv[68];
	local[28]= argv[4];
	local[29]= local[0];
	ctx->vsp=local+30;
	w=(pointer)APPLY(ctx,20,local+10); /*apply*/
	w = local[9];
	argv[0]->c.obj.iv[19] = w;
	local[9]= argv[0]->c.obj.iv[19];
	local[10]= fqv[69];
	local[11]= argv[0]->c.obj.iv[17];
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,2,local+11); /*aref*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)4L);
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= argv[0]->c.obj.iv[19];
	local[10]= fqv[70];
	local[11]= fqv[71];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	if (local[3]==NIL) goto XitemIF2101;
	local[9]= argv[0];
	local[10]= fqv[72];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	goto XitemIF2102;
XitemIF2101:
	local[9]= NIL;
XitemIF2102:
	local[9]= argv[0];
	local[10]= fqv[73];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	w = argv[0];
	local[0]= w;
XitemBLK2095:
	ctx->vsp=local; return(local[0]);}

/*:redraw*/
static pointer XitemM2103text_item_redraw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[32];
	local[2]= makeint((eusinteger_t)1L);
	local[3]= makeint((eusinteger_t)4L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[19];
	local[1]= fqv[73];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
XitemBLK2104:
	ctx->vsp=local; return(local[0]);}

/*:getstring*/
static pointer XitemM2105text_item_getstring(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[19];
	local[1]= fqv[74];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XitemBLK2106:
	ctx->vsp=local; return(local[0]);}

/*:value*/
static pointer XitemM2107text_item_value(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2111;}
	local[0]= NIL;
XitemENT2111:
	if (n>=4) { local[1]=(argv[3]); goto XitemENT2110;}
	local[1]= NIL;
XitemENT2110:
XitemENT2109:
	if (n>4) maerror();
	local[2]= NIL;
	local[3]= NIL;
	w = local[0];
	if (!isstring(w)) goto XitemIF2112;
	local[4]= argv[0]->c.obj.iv[19];
	local[5]= fqv[75];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[19];
	local[5]= fqv[76];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XitemIF2113;
XitemIF2112:
	local[4]= NIL;
XitemIF2113:
	local[4]= argv[0]->c.obj.iv[19];
	local[5]= fqv[74];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[3] = w;
	if (local[1]==NIL) goto XitemIF2114;
	local[4]= argv[0];
	local[5]= fqv[45];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XitemIF2115;
XitemIF2114:
	local[4]= NIL;
XitemIF2115:
	w = local[3];
	local[0]= w;
XitemBLK2108:
	ctx->vsp=local; return(local[0]);}

/*:leavenotify*/
static pointer XitemM2116text_item_leavenotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= argv[0]->c.obj.iv[19];
	local[4]= fqv[77];
	local[5]= loadglobal(fqv[14]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2117:
	ctx->vsp=local; return(local[0]);}

/*:enternotify*/
static pointer XitemM2118text_item_enternotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= argv[0]->c.obj.iv[19];
	local[4]= fqv[78];
	local[5]= loadglobal(fqv[14]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2119:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XitemM2120slider_item_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
XitemRST2122:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-5);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[79], &argv[5], n-5, local+1, 1);
	if (n & (1<<0)) goto XitemKEY2123;
	local[1] = makeflt(0.0000000000000000000000e+00);
XitemKEY2123:
	if (n & (1<<1)) goto XitemKEY2124;
	local[2] = makeflt(1.0000000000000000000000e+00);
XitemKEY2124:
	if (n & (1<<2)) goto XitemKEY2125;
	local[3] = NIL;
XitemKEY2125:
	if (n & (1<<3)) goto XitemKEY2126;
	local[4] = NIL;
XitemKEY2126:
	if (n & (1<<4)) goto XitemKEY2127;
	local[5] = NIL;
XitemKEY2127:
	if (n & (1<<5)) goto XitemKEY2128;
	local[6] = fqv[80];
XitemKEY2128:
	if (n & (1<<6)) goto XitemKEY2129;
	local[7] = loadglobal(fqv[1]);
XitemKEY2129:
	if (n & (1<<7)) goto XitemKEY2130;
	local[8] = makeint((eusinteger_t)100L);
XitemKEY2130:
	if (n & (1<<8)) goto XitemKEY2131;
	local[9] = makeint((eusinteger_t)0L);
XitemKEY2131:
	if (n & (1<<9)) goto XitemKEY2132;
	local[10] = local[1];
XitemKEY2132:
	if (n & (1<<10)) goto XitemKEY2133;
	local[11] = T;
XitemKEY2133:
	argv[0]->c.obj.iv[21] = local[10];
	argv[0]->c.obj.iv[24] = local[6];
	argv[0]->c.obj.iv[32] = NIL;
	local[12]= argv[0];
	local[13]= fqv[81];
	local[14]= local[1];
	local[15]= local[4];
	local[16]= local[2];
	local[17]= local[5];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,6,local+12); /*send*/
	local[12]= argv[2];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(*ftab[0])(ctx,2,local+12,&ftab[0],fqv[9]); /*textdots*/
	argv[0]->c.obj.iv[17] = w;
	local[12]= NIL;
	local[13]= local[6];
	local[14]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,3,local+12); /*format*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[0])(ctx,1,local+12,&ftab[0],fqv[9]); /*textdots*/
	argv[0]->c.obj.iv[29] = w;
	local[12]= fqv[82];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(*ftab[0])(ctx,2,local+12,&ftab[0],fqv[9]); /*textdots*/
	argv[0]->c.obj.iv[33] = w;
	local[12]= argv[0]->c.obj.iv[33];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)AREF(ctx,2,local+12); /*aref*/
	argv[0]->c.obj.iv[33] = w;
	local[12]= (pointer)get_sym_func(fqv[2]);
	local[13]= argv[0];
	local[14]= *(ovafptr(argv[1],fqv[3]));
	local[15]= fqv[4];
	local[16]= argv[2];
	local[17]= argv[3];
	local[18]= argv[4];
	local[19]= fqv[26];
	local[20]= local[9];
	local[21]= fqv[6];
	local[22]= argv[0]->c.obj.iv[17];
	local[23]= makeint((eusinteger_t)2L);
	ctx->vsp=local+24;
	w=(pointer)AREF(ctx,2,local+22); /*aref*/
	local[22]= w;
	local[23]= argv[0]->c.obj.iv[33];
	local[24]= argv[0]->c.obj.iv[22];
	ctx->vsp=local+25;
	w=(pointer)LENGTH(ctx,1,local+24); /*length*/
	local[24]= w;
	local[25]= argv[0]->c.obj.iv[23];
	ctx->vsp=local+26;
	w=(pointer)LENGTH(ctx,1,local+25); /*length*/
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[24]= (pointer)((eusinteger_t)local[24] + (eusinteger_t)w);
	ctx->vsp=local+25;
	w=(pointer)TIMES(ctx,2,local+23); /***/
	local[23]= w;
	local[24]= argv[0]->c.obj.iv[29];
	local[25]= makeint((eusinteger_t)2L);
	ctx->vsp=local+26;
	w=(pointer)AREF(ctx,2,local+24); /*aref*/
	local[24]= w;
	local[25]= local[8];
	local[26]= makeint((eusinteger_t)60L);
	ctx->vsp=local+27;
	w=(pointer)PLUS(ctx,5,local+22); /*+*/
	local[22]= w;
	local[23]= fqv[7];
	local[24]= makeint((eusinteger_t)10L);
	local[25]= argv[0]->c.obj.iv[17];
	local[26]= makeint((eusinteger_t)0L);
	ctx->vsp=local+27;
	w=(pointer)AREF(ctx,2,local+25); /*aref*/
	local[25]= w;
	local[26]= argv[0]->c.obj.iv[17];
	local[27]= makeint((eusinteger_t)1L);
	ctx->vsp=local+28;
	w=(pointer)AREF(ctx,2,local+26); /*aref*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)PLUS(ctx,3,local+24); /*+*/
	local[24]= w;
	local[25]= fqv[8];
	local[26]= local[7];
	local[27]= local[0];
	ctx->vsp=local+28;
	w=(pointer)APPLY(ctx,16,local+12); /*apply*/
	local[12]= argv[0]->c.obj.iv[17];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)AREF(ctx,2,local+12); /*aref*/
	local[12]= w;
	local[13]= argv[0]->c.obj.iv[29];
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,2,local+13); /*aref*/
	local[13]= w;
	local[14]= argv[0]->c.obj.iv[33];
	local[15]= argv[0]->c.obj.iv[22];
	ctx->vsp=local+16;
	w=(pointer)LENGTH(ctx,1,local+15); /*length*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	local[15]= makeint((eusinteger_t)17L);
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,4,local+12); /*+*/
	argv[0]->c.obj.iv[25] = w;
	local[12]= makeint((eusinteger_t)3L);
	local[13]= argv[0]->c.obj.iv[17];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,2,local+13); /*aref*/
	local[13]= w;
	local[14]= argv[0]->c.obj.iv[17];
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(pointer)AREF(ctx,2,local+14); /*aref*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	argv[0]->c.obj.iv[26] = w;
	argv[0]->c.obj.iv[27] = local[8];
	argv[0]->c.obj.iv[28] = makeint((eusinteger_t)3L);
	local[12]= argv[0];
	local[13]= fqv[83];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	argv[0]->c.obj.iv[31] = w;
	local[12]= makeint((eusinteger_t)5L);
	local[13]= argv[0]->c.obj.iv[17];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,2,local+13); /*aref*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	argv[0]->c.obj.iv[30] = w;
	local[12]= argv[0];
	local[13]= fqv[84];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= argv[0];
	local[13]= fqv[73];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	w = argv[0];
	local[0]= w;
XitemBLK2121:
	ctx->vsp=local; return(local[0]);}

/*:new-range*/
static pointer XitemM2134slider_item_new_range(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	argv[0]->c.obj.iv[19] = argv[2];
	argv[0]->c.obj.iv[20] = argv[4];
	w = argv[3];
	if (isstring(w)) goto XitemIF2136;
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[24];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	argv[3] = w;
	local[0]= argv[3];
	goto XitemIF2137;
XitemIF2136:
	local[0]= NIL;
XitemIF2137:
	argv[0]->c.obj.iv[22] = argv[3];
	w = argv[5];
	if (isstring(w)) goto XitemIF2138;
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[24];
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	argv[5] = w;
	local[0]= argv[5];
	goto XitemIF2139;
XitemIF2138:
	local[0]= NIL;
XitemIF2139:
	argv[0]->c.obj.iv[23] = argv[5];
	w = argv[0]->c.obj.iv[23];
	local[0]= w;
XitemBLK2135:
	ctx->vsp=local; return(local[0]);}

/*:continuous-notify*/
static pointer XitemM2140slider_item_continuous_notify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[34];
	argv[0]->c.obj.iv[34] = argv[2];
	w = local[0];
	local[0]= w;
XitemBLK2141:
	ctx->vsp=local; return(local[0]);}

/*:redraw*/
static pointer XitemM2142slider_item_redraw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[85];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[86];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[12];
	local[2]= makeint((eusinteger_t)3L);
	local[3]= argv[0]->c.obj.iv[30];
	local[4]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[12];
	local[2]= makeint((eusinteger_t)13L);
	local[3]= argv[0]->c.obj.iv[17];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[29];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,3,local+2); /*+*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[30];
	local[4]= argv[0]->c.obj.iv[22];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[12];
	local[2]= makeint((eusinteger_t)23L);
	local[3]= argv[0]->c.obj.iv[17];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[29];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[33];
	local[6]= argv[0]->c.obj.iv[22];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[27];
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,5,local+2); /*+*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[30];
	local[4]= argv[0]->c.obj.iv[23];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[87];
	local[2]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XitemBLK2143:
	ctx->vsp=local; return(local[0]);}

/*:display-value*/
static pointer XitemM2144slider_item_display_value(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2147;}
	local[0]= argv[0]->c.obj.iv[21];
XitemENT2147:
XitemENT2146:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[19];
	local[2]= argv[0]->c.obj.iv[20];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)MIN(ctx,2,local+2); /*min*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAX(ctx,2,local+1); /*max*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)EUSFLOAT(ctx,1,local+1); /*float*/
	local[0] = w;
	w = argv[0]->c.obj.iv[20];
	if (!isint(w)) goto XitemIF2148;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)ROUND(ctx,1,local+1); /*round*/
	local[0] = w;
	local[1]= local[0];
	goto XitemIF2149;
XitemIF2148:
	local[1]= NIL;
XitemIF2149:
	local[1]= argv[0];
	local[2]= fqv[12];
	local[3]= makeint((eusinteger_t)7L);
	local[4]= argv[0]->c.obj.iv[17];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[30];
	local[5]= NIL;
	local[6]= argv[0]->c.obj.iv[24];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,3,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
XitemBLK2145:
	ctx->vsp=local; return(local[0]);}

/*:value*/
static pointer XitemM2150slider_item_value(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2154;}
	local[0]= NIL;
XitemENT2154:
	if (n>=4) { local[1]=(argv[3]); goto XitemENT2153;}
	local[1]= NIL;
XitemENT2153:
XitemENT2152:
	if (n>4) maerror();
	if (local[0]==NIL) goto XitemIF2155;
	local[2]= argv[0];
	local[3]= fqv[87];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[86];
	local[4]= argv[0]->c.obj.iv[31];
	local[5]= argv[0];
	local[6]= fqv[83];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[83];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	argv[0]->c.obj.iv[31] = w;
	argv[0]->c.obj.iv[21] = local[0];
	local[2]= argv[0]->c.obj.iv[21];
	goto XitemIF2156;
XitemIF2155:
	local[2]= NIL;
XitemIF2156:
	if (local[1]==NIL) goto XitemIF2157;
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[3]));
	local[4]= fqv[45];
	local[5]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+6;
	w=(pointer)SENDMESSAGE(ctx,4,local+2); /*send-message*/
	local[2]= w;
	goto XitemIF2158;
XitemIF2157:
	local[2]= NIL;
XitemIF2158:
	w = argv[0]->c.obj.iv[21];
	local[0]= w;
XitemBLK2151:
	ctx->vsp=local; return(local[0]);}

/*:nob-x*/
static pointer XitemM2159slider_item_nob_x(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2162;}
	local[0]= argv[0]->c.obj.iv[21];
XitemENT2162:
XitemENT2161:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[25];
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,1,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[27];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[20];
	local[4]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,1,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[0]= w;
XitemBLK2160:
	ctx->vsp=local; return(local[0]);}

/*:inside-nob-p*/
static pointer XitemM2163slider_item_inside_nob_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[31];
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[31];
	local[3]= makeint((eusinteger_t)7L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LSEQP(ctx,3,local+0); /*<=*/
	local[0]= w;
	if (w==NIL) goto XitemAND2165;
	local[0]= argv[0]->c.obj.iv[26];
	local[1]= makeint((eusinteger_t)5L);
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[26];
	local[3]= makeint((eusinteger_t)5L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LSEQP(ctx,3,local+0); /*<=*/
	local[0]= w;
XitemAND2165:
	w = local[0];
	local[0]= w;
XitemBLK2164:
	ctx->vsp=local; return(local[0]);}

/*:draw-bar-rectangle*/
static pointer XitemM2166slider_item_draw_bar_rectangle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[88];
	local[2]= argv[0]->c.obj.iv[25];
	local[3]= argv[0]->c.obj.iv[26];
	local[4]= makeint((eusinteger_t)5L);
	local[5]= argv[0]->c.obj.iv[27];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[28];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	local[0]= w;
XitemBLK2167:
	ctx->vsp=local; return(local[0]);}

/*:draw-nob-rectangle*/
static pointer XitemM2168slider_item_draw_nob_rectangle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2172;}
	local[0]= argv[0]->c.obj.iv[31];
XitemENT2172:
	if (n>=4) { local[1]=(argv[3]); goto XitemENT2171;}
	local[1]= argv[0]->c.obj.iv[31];
XitemENT2171:
XitemENT2170:
	if (n>4) maerror();
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= fqv[28];
	local[4]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[89];
	local[4]= local[0];
	local[5]= argv[0]->c.obj.iv[26];
	local[6]= makeint((eusinteger_t)5L);
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)7L);
	local[7]= makeint((eusinteger_t)13L);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= fqv[28];
	local[4]= loadglobal(fqv[90]);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[85];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[89];
	local[4]= local[1];
	local[5]= argv[0]->c.obj.iv[26];
	local[6]= makeint((eusinteger_t)5L);
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)7L);
	local[7]= makeint((eusinteger_t)13L);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[0]= w;
XitemBLK2169:
	ctx->vsp=local; return(local[0]);}

/*:buttonpress*/
static pointer XitemM2173slider_item_buttonpress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= loadglobal(fqv[14]);
	ctx->vsp=local+4;
	w=(*ftab[9])(ctx,1,local+3,&ftab[9],fqv[91]); /*event-pos*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[92];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	if (w==NIL) goto XitemIF2175;
	local[4]= loadglobal(fqv[14]);
	ctx->vsp=local+5;
	w=(*ftab[9])(ctx,1,local+4,&ftab[9],fqv[91]); /*event-pos*/
	argv[0]->c.obj.iv[32] = w;
	local[4]= argv[0]->c.obj.iv[32];
	goto XitemIF2176;
XitemIF2175:
	local[4]= NIL;
XitemIF2176:
	w = local[4];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2174:
	ctx->vsp=local; return(local[0]);}

/*:compute-value*/
static pointer XitemM2177slider_item_compute_value(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= loadglobal(fqv[14]);
	ctx->vsp=local+4;
	w=(*ftab[9])(ctx,1,local+3,&ftab[9],fqv[91]); /*event-pos*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[25];
	local[5]= makeint((eusinteger_t)3L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,3,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)EUSFLOAT(ctx,1,local+3); /*float*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[19];
	local[5]= argv[0]->c.obj.iv[19];
	local[6]= local[3];
	local[7]= argv[0]->c.obj.iv[27];
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[20];
	local[8]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+7;
	w=(pointer)XitemF1949clump(ctx,3,local+4); /*clump*/
	local[4]= w;
	w = local[4];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2178:
	ctx->vsp=local; return(local[0]);}

/*:motionnotify*/
static pointer XitemM2179slider_item_motionnotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	if (argv[0]->c.obj.iv[32]==NIL) goto XitemIF2181;
	local[3]= argv[0];
	local[4]= fqv[72];
	local[5]= argv[0];
	local[6]= fqv[93];
	local[7]= loadglobal(fqv[14]);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[34];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto XitemIF2182;
XitemIF2181:
	local[3]= NIL;
XitemIF2182:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2180:
	ctx->vsp=local; return(local[0]);}

/*:buttonrelease*/
static pointer XitemM2183slider_item_buttonrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	if (argv[0]->c.obj.iv[32]==NIL) goto XitemIF2185;
	argv[0]->c.obj.iv[32] = NIL;
	local[3]= argv[0];
	local[4]= fqv[72];
	local[5]= argv[0];
	local[6]= fqv[93];
	local[7]= loadglobal(fqv[14]);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= T;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto XitemIF2186;
XitemIF2185:
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[3]));
	local[5]= fqv[46];
	local[6]= loadglobal(fqv[14]);
	ctx->vsp=local+7;
	w=(pointer)SENDMESSAGE(ctx,4,local+3); /*send-message*/
	local[3]= w;
XitemIF2186:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2184:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XitemM2187choice_item_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
XitemRST2189:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-5);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[94], &argv[5], n-5, local+1, 1);
	if (n & (1<<0)) goto XitemKEY2190;
	local[1] = loadglobal(fqv[19]);
XitemKEY2190:
	if (n & (1<<1)) goto XitemKEY2191;
	local[2] = fqv[95];
XitemKEY2191:
	if (n & (1<<2)) goto XitemKEY2192;
	local[3] = NIL;
XitemKEY2192:
	if (n & (1<<3)) goto XitemKEY2193;
	local[4] = makeint((eusinteger_t)0L);
XitemKEY2193:
	if (n & (1<<4)) goto XitemKEY2194;
	local[5] = makeint((eusinteger_t)13L);
XitemKEY2194:
	if (n & (1<<5)) goto XitemKEY2195;
	local[6] = makeint((eusinteger_t)0L);
XitemKEY2195:
	if (n & (1<<6)) goto XitemKEY2196;
	local[7] = NIL;
XitemKEY2196:
	if (n & (1<<7)) goto XitemKEY2197;
	local[8] = NIL;
XitemKEY2197:
	if (n & (1<<8)) goto XitemKEY2198;
	local[9] = NIL;
XitemKEY2198:
	if (n & (1<<9)) goto XitemKEY2199;
	local[10] = NIL;
XitemKEY2199:
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= (pointer)get_sym_func(fqv[96]);
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)MAPCAR(ctx,2,local+14); /*mapcar*/
	argv[0]->c.obj.iv[19] = w;
	argv[0]->c.obj.iv[20] = local[4];
	local[14]= local[5];
	local[15]= local[14];
	w = argv[0];
	w->c.obj.iv[23] = local[15];
	if (local[3]!=NIL) goto XitemIF2200;
	local[14]= local[1];
	local[15]= fqv[97];
	local[16]= fqv[8];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[3] = w;
	local[14]= local[3];
	goto XitemIF2201;
XitemIF2200:
	local[14]= NIL;
XitemIF2201:
	local[14]= argv[2];
	local[15]= local[3];
	ctx->vsp=local+16;
	w=(*ftab[0])(ctx,2,local+14,&ftab[0],fqv[9]); /*textdots*/
	argv[0]->c.obj.iv[17] = w;
	local[14]= NIL;
	local[15]= local[2];
XitemWHL2202:
	if (local[15]==NIL) goto XitemWHX2203;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.cdr;
	w = local[16];
	local[14] = w;
	local[16]= local[14];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(*ftab[0])(ctx,2,local+16,&ftab[0],fqv[9]); /*textdots*/
	local[16]= w;
	local[17]= makeint((eusinteger_t)2L);
	ctx->vsp=local+18;
	w=(pointer)AREF(ctx,2,local+16); /*aref*/
	local[16]= w;
	w = local[13];
	ctx->vsp=local+17;
	local[13] = cons(ctx,local[16],w);
	goto XitemWHL2202;
XitemWHX2203:
	local[16]= NIL;
XitemBLK2204:
	w = NIL;
	local[14]= local[13];
	ctx->vsp=local+15;
	w=(pointer)NREVERSE(ctx,1,local+14); /*nreverse*/
	local[14]= (pointer)get_sym_func(fqv[2]);
	local[15]= argv[0];
	local[16]= *(ovafptr(argv[1],fqv[3]));
	local[17]= fqv[4];
	local[18]= argv[2];
	local[19]= argv[3];
	local[20]= argv[4];
	local[21]= fqv[27];
	local[22]= local[1];
	local[23]= fqv[26];
	local[24]= local[6];
	local[25]= fqv[6];
	local[26]= argv[0]->c.obj.iv[17];
	local[27]= makeint((eusinteger_t)2L);
	ctx->vsp=local+28;
	w=(pointer)AREF(ctx,2,local+26); /*aref*/
	local[26]= w;
	local[27]= (pointer)get_sym_func(fqv[98]);
	local[28]= local[13];
	ctx->vsp=local+29;
	w=(pointer)APPLY(ctx,2,local+27); /*apply*/
	local[27]= w;
	local[28]= local[2];
	ctx->vsp=local+29;
	w=(pointer)LENGTH(ctx,1,local+28); /*length*/
	local[28]= w;
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)5L)); i=intval(local[28]);
		local[28]=(makeint(i * j));}
	local[29]= makeint((eusinteger_t)20L);
	ctx->vsp=local+30;
	w=(pointer)PLUS(ctx,4,local+26); /*+*/
	local[26]= w;
	local[27]= fqv[7];
	local[28]= makeint((eusinteger_t)10L);
	local[29]= local[5];
	local[30]= argv[0]->c.obj.iv[17];
	local[31]= makeint((eusinteger_t)0L);
	ctx->vsp=local+32;
	w=(pointer)AREF(ctx,2,local+30); /*aref*/
	local[30]= w;
	local[31]= argv[0]->c.obj.iv[17];
	local[32]= makeint((eusinteger_t)1L);
	ctx->vsp=local+33;
	w=(pointer)AREF(ctx,2,local+31); /*aref*/
	local[31]= w;
	ctx->vsp=local+32;
	w=(pointer)PLUS(ctx,4,local+28); /*+*/
	local[28]= w;
	local[29]= fqv[8];
	local[30]= local[3];
	local[31]= fqv[29];
	local[32]= local[7];
	local[33]= fqv[99];
	ctx->vsp=local+34;
	w=(*ftab[10])(ctx,2,local+32,&ftab[10],fqv[100]); /*union*/
	local[32]= w;
	local[33]= local[0];
	ctx->vsp=local+34;
	w=(pointer)APPLY(ctx,20,local+14); /*apply*/
	local[14]= argv[0]->c.obj.iv[17];
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)AREF(ctx,2,local+14); /*aref*/
	local[14]= w;
	local[15]= argv[0]->c.obj.iv[17];
	local[16]= makeint((eusinteger_t)1L);
	ctx->vsp=local+17;
	w=(pointer)AREF(ctx,2,local+15); /*aref*/
	local[15]= w;
	local[16]= local[5];
	local[17]= makeint((eusinteger_t)2L);
	ctx->vsp=local+18;
	w=(pointer)QUOTIENT(ctx,2,local+16); /*/*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,3,local+14); /*+*/
	local[12] = w;
	local[14]= makeint((eusinteger_t)5L);
	local[15]= argv[0]->c.obj.iv[17];
	local[16]= makeint((eusinteger_t)2L);
	ctx->vsp=local+17;
	w=(pointer)AREF(ctx,2,local+15); /*aref*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,2,local+14); /*+*/
	local[14]= w;
	local[15]= NIL;
	local[16]= NIL;
	local[17]= argv[0]->c.obj.iv[19];
XitemWHL2205:
	if (local[17]==NIL) goto XitemWHX2206;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17] = (w)->c.cons.cdr;
	w = local[18];
	local[16] = w;
	local[18]= local[16];
	local[19]= local[14];
	local[20]= argv[0]->c.obj.iv[17];
	local[21]= makeint((eusinteger_t)0L);
	ctx->vsp=local+22;
	w=(pointer)AREF(ctx,2,local+20); /*aref*/
	local[20]= w;
	local[21]= makeint((eusinteger_t)3L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)LIST(ctx,2,local+19); /*list*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)NCONC(ctx,2,local+18); /*nconc*/
	local[18]= makeint((eusinteger_t)4L);
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13] = (w)->c.cons.cdr;
	w = local[19];
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)PLUS(ctx,2,local+18); /*+*/
	local[15] = w;
	local[18]= local[16];
	local[19]= local[15];
	local[20]= makeint((eusinteger_t)2L);
	ctx->vsp=local+21;
	w=(pointer)QUOTIENT(ctx,2,local+19); /*/*/
	local[19]= w;
	local[20]= local[14];
	local[21]= local[5];
	local[22]= makeint((eusinteger_t)2L);
	ctx->vsp=local+23;
	w=(pointer)QUOTIENT(ctx,2,local+21); /*/*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)MINUS(ctx,1,local+21); /*-*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,3,local+19); /*+*/
	local[19]= w;
	local[20]= local[12];
	ctx->vsp=local+21;
	w=(pointer)MKINTVECTOR(ctx,2,local+19); /*integer-vector*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)NCONC(ctx,2,local+18); /*nconc*/
	local[18]= local[14];
	local[19]= local[15];
	ctx->vsp=local+20;
	w=(pointer)PLUS(ctx,2,local+18); /*+*/
	local[14] = w;
	goto XitemWHL2205;
XitemWHX2206:
	local[18]= NIL;
XitemBLK2207:
	w = NIL;
	local[14]= argv[0];
	local[15]= fqv[73];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= argv[0];
	local[15]= fqv[101];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	w = argv[0];
	local[0]= w;
XitemBLK2188:
	ctx->vsp=local; return(local[0]);}

/*:draw-label*/
static pointer XitemM2208choice_item_draw_label(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2211;}
	local[0]= argv[0];
	local[1]= fqv[5];
	ctx->vsp=local+2;
	w=(pointer)GETPROP(ctx,2,local+0); /*get*/
	local[0]= w;
XitemENT2211:
XitemENT2210:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[37];
	local[3]= makeint((eusinteger_t)3L);
	local[4]= argv[0];
	local[5]= fqv[7];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
XitemBLK2209:
	ctx->vsp=local; return(local[0]);}

/*:redraw*/
static pointer XitemM2212choice_item_redraw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[32];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[19];
XitemWHL2214:
	if (local[1]==NIL) goto XitemWHX2215;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= argv[0];
	local[3]= fqv[37];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[102];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[11])(ctx,1,local+4,&ftab[11],fqv[103]); /*fourth*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[23];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	goto XitemWHL2214;
XitemWHX2215:
	local[2]= NIL;
XitemBLK2216:
	w = NIL;
	local[0]= argv[0];
	local[1]= fqv[101];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
XitemBLK2213:
	ctx->vsp=local; return(local[0]);}

/*:value*/
static pointer XitemM2217choice_item_value(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2221;}
	local[0]= NIL;
XitemENT2221:
	if (n>=4) { local[1]=(argv[3]); goto XitemENT2220;}
	local[1]= NIL;
XitemENT2220:
XitemENT2219:
	if (n>4) maerror();
	if (local[0]==NIL) goto XitemIF2222;
	local[2]= argv[0];
	local[3]= fqv[101];
	local[4]= argv[0]->c.obj.iv[20];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	argv[0]->c.obj.iv[20] = local[0];
	local[2]= argv[0]->c.obj.iv[20];
	goto XitemIF2223;
XitemIF2222:
	local[2]= NIL;
XitemIF2223:
	if (local[1]==NIL) goto XitemIF2224;
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[3]));
	local[4]= fqv[45];
	local[5]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+6;
	w=(pointer)SENDMESSAGE(ctx,4,local+2); /*send-message*/
	local[2]= w;
	goto XitemIF2225;
XitemIF2224:
	local[2]= NIL;
XitemIF2225:
	w = argv[0]->c.obj.iv[20];
	local[0]= w;
XitemBLK2218:
	ctx->vsp=local; return(local[0]);}

/*:draw-active-button*/
static pointer XitemM2226choice_item_draw_active_button(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2230;}
	local[0]= argv[0]->c.obj.iv[20];
XitemENT2230:
	if (n>=4) { local[1]=(argv[3]); goto XitemENT2229;}
	local[1]= argv[0]->c.obj.iv[20];
XitemENT2229:
XitemENT2228:
	if (n>4) maerror();
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= fqv[28];
	local[4]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[104];
	local[4]= argv[0]->c.obj.iv[19];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[11])(ctx,1,local+4,&ftab[11],fqv[103]); /*fourth*/
	local[4]= w;
	local[5]= fqv[105];
	ctx->vsp=local+6;
	w=(pointer)VPLUS(ctx,2,local+4); /*v+*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[23];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= fqv[28];
	local[4]= loadglobal(fqv[90]);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[104];
	local[4]= argv[0]->c.obj.iv[19];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[11])(ctx,1,local+4,&ftab[11],fqv[103]); /*fourth*/
	local[4]= w;
	local[5]= fqv[106];
	ctx->vsp=local+6;
	w=(pointer)VPLUS(ctx,2,local+4); /*v+*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[23];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[0]= w;
XitemBLK2227:
	ctx->vsp=local; return(local[0]);}

/*:choice*/
static pointer XitemM2231choice_item_choice(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= loadglobal(fqv[14]);
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,1,local+3,&ftab[3],fqv[40]); /*event-x*/
	local[3]= w;
	local[4]= loadglobal(fqv[14]);
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,1,local+4,&ftab[4],fqv[41]); /*event-y*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[19];
	local[6]= makeint((eusinteger_t)0L);
XitemWHL2233:
	if (local[5]==NIL) goto XitemWHX2234;
	local[7]= local[3];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(*ftab[11])(ctx,1,local+8,&ftab[11],fqv[103]); /*fourth*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,2,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ABS(ctx,1,local+7); /*abs*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[23];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto XitemIF2236;
	w = local[6];
	ctx->vsp=local+7;
	unwind(ctx,local+0);
	local[0]=w;
	goto XitemBLK2232;
	goto XitemIF2237;
XitemIF2236:
	local[7]= NIL;
XitemIF2237:
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[6] = w;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[7];
	goto XitemWHL2233;
XitemWHX2234:
	local[7]= NIL;
XitemBLK2235:
	w = NIL;
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2232:
	ctx->vsp=local; return(local[0]);}

/*:buttonpress*/
static pointer XitemM2238choice_item_buttonpress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= argv[0];
	local[4]= fqv[107];
	local[5]= loadglobal(fqv[14]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	argv[0]->c.obj.iv[21] = w;
	local[3]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2239:
	ctx->vsp=local; return(local[0]);}

/*:buttonrelease*/
static pointer XitemM2240choice_item_buttonrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= argv[0];
	local[4]= fqv[107];
	local[5]= loadglobal(fqv[14]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	if (local[3]==NIL) goto XitemIF2242;
	local[4]= local[3];
	if (argv[0]->c.obj.iv[21]!=local[4]) goto XitemIF2242;
	local[4]= argv[0];
	local[5]= fqv[72];
	local[6]= argv[0]->c.obj.iv[21];
	local[7]= T;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	argv[0]->c.obj.iv[21] = NIL;
	local[4]= argv[0]->c.obj.iv[21];
	goto XitemIF2243;
XitemIF2242:
	local[4]= argv[0];
	local[5]= *(ovafptr(argv[1],fqv[3]));
	local[6]= fqv[46];
	local[7]= loadglobal(fqv[14]);
	ctx->vsp=local+8;
	w=(pointer)SENDMESSAGE(ctx,4,local+4); /*send-message*/
	local[4]= w;
XitemIF2243:
	w = local[4];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2241:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XitemM2244joystick_item_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
XitemRST2246:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-5);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[108], &argv[5], n-5, local+1, 1);
	if (n & (1<<0)) goto XitemKEY2247;
	local[1] = makeint((eusinteger_t)5L);
XitemKEY2247:
	if (n & (1<<1)) goto XitemKEY2248;
	local[2] = NIL;
XitemKEY2248:
	if (n & (1<<2)) goto XitemKEY2249;
	local[3] = T;
XitemKEY2249:
	if (n & (1<<3)) goto XitemKEY2250;
	local[4] = makeflt(-1.0000000000000000000000e+00);
XitemKEY2250:
	if (n & (1<<4)) goto XitemKEY2251;
	local[5] = makeflt(1.0000000000000000000000e+00);
XitemKEY2251:
	if (n & (1<<5)) goto XitemKEY2252;
	local[6] = makeflt(-1.0000000000000000000000e+00);
XitemKEY2252:
	if (n & (1<<6)) goto XitemKEY2253;
	local[7] = makeflt(1.0000000000000000000000e+00);
XitemKEY2253:
	local[8]= (pointer)get_sym_func(fqv[2]);
	local[9]= argv[0];
	local[10]= *(ovafptr(argv[1],fqv[3]));
	local[11]= fqv[4];
	local[12]= argv[2];
	local[13]= argv[3];
	local[14]= argv[4];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(pointer)APPLY(ctx,8,local+8); /*apply*/
	local[8]= argv[0]->c.obj.iv[5];
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	argv[0]->c.obj.iv[24] = w;
	local[8]= argv[0]->c.obj.iv[6];
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	argv[0]->c.obj.iv[25] = w;
	argv[0]->c.obj.iv[26] = argv[0]->c.obj.iv[24];
	argv[0]->c.obj.iv[27] = argv[0]->c.obj.iv[25];
	argv[0]->c.obj.iv[30] = local[2];
	local[8]= local[4];
	local[9]= local[8];
	w = argv[0];
	w->c.obj.iv[20] = local[9];
	local[8]= local[6];
	local[9]= local[8];
	w = argv[0];
	w->c.obj.iv[21] = local[9];
	local[8]= local[5];
	local[9]= local[8];
	w = argv[0];
	w->c.obj.iv[22] = local[9];
	local[8]= local[7];
	local[9]= local[8];
	w = argv[0];
	w->c.obj.iv[23] = local[9];
	local[8]= local[1];
	local[9]= local[8];
	w = argv[0];
	w->c.obj.iv[19] = local[9];
	local[8]= local[3];
	local[9]= local[8];
	w = argv[0];
	w->c.obj.iv[34] = local[9];
	local[8]= local[4];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	local[9]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	argv[0]->c.obj.iv[28] = w;
	local[8]= local[6];
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	local[9]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	argv[0]->c.obj.iv[29] = w;
	local[8]= local[5];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+10;
	w=(pointer)EUSFLOAT(ctx,1,local+9); /*float*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	argv[0]->c.obj.iv[32] = w;
	local[8]= local[7];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+10;
	w=(pointer)EUSFLOAT(ctx,1,local+9); /*float*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	argv[0]->c.obj.iv[33] = w;
	argv[0]->c.obj.iv[31] = NIL;
	local[8]= argv[0];
	local[9]= fqv[73];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	w = argv[0];
	local[0]= w;
XitemBLK2245:
	ctx->vsp=local; return(local[0]);}

/*:redraw*/
static pointer XitemM2254joystick_item_redraw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[109];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[110];
	local[2]= argv[0]->c.obj.iv[28];
	local[3]= argv[0]->c.obj.iv[29];
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
XitemBLK2255:
	ctx->vsp=local; return(local[0]);}

/*:draw-circles*/
static pointer XitemM2256joystick_item_draw_circles(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= makeint((eusinteger_t)8L);
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[6];
	local[2]= makeint((eusinteger_t)8L);
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= fqv[10];
	local[4]= fqv[11];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[111];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[5];
	local[7]= argv[0]->c.obj.iv[6];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeflt(6.2831853071795862319959e+00);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,8,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[111];
	local[4]= local[0];
	local[5]= local[1];
	local[6]= argv[0]->c.obj.iv[5];
	local[7]= makeflt(7.5000000000000000000000e-01);
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[6];
	local[8]= makeflt(7.5000000000000000000000e-01);
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ROUND(ctx,1,local+7); /*round*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeflt(6.2831853071795862319959e+00);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,8,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[111];
	local[4]= makeint((eusinteger_t)2L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= makeint((eusinteger_t)2L);
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[5];
	local[7]= makeflt(5.2000000000000001776357e-01);
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)CEILING(ctx,1,local+6); /*ceiling*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[6];
	local[8]= makeflt(5.2000000000000001776357e-01);
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)CEILING(ctx,1,local+7); /*ceiling*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeflt(6.2831853071795862319959e+00);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,8,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[111];
	local[4]= makeint((eusinteger_t)3L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= makeint((eusinteger_t)3L);
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[5];
	local[7]= makeflt(2.7000000000000001776357e-01);
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)CEILING(ctx,1,local+6); /*ceiling*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[6];
	local[8]= makeflt(2.7000000000000001776357e-01);
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)CEILING(ctx,1,local+7); /*ceiling*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeflt(6.2831853071795862319959e+00);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,8,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[74];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[0]->c.obj.iv[6];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[5];
	local[7]= argv[0]->c.obj.iv[6];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[74];
	local[4]= argv[0]->c.obj.iv[5];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[5];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[74];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[0]->c.obj.iv[6];
	local[6]= argv[0]->c.obj.iv[5];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[74];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[5];
	local[7]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	w = argv[0];
	local[0]= w;
XitemBLK2257:
	ctx->vsp=local; return(local[0]);}

/*:xy*/
static pointer XitemM2258joystick_item_xy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2262;}
	local[0]= argv[0]->c.obj.iv[28];
XitemENT2262:
	if (n>=4) { local[1]=(argv[3]); goto XitemENT2261;}
	local[1]= argv[0]->c.obj.iv[29];
XitemENT2261:
XitemENT2260:
	if (n>4) maerror();
	local[2]= argv[0]->c.obj.iv[5];
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[22];
	local[5]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ROUND(ctx,1,local+2); /*round*/
	argv[0]->c.obj.iv[26] = w;
	local[2]= argv[0]->c.obj.iv[6];
	local[3]= argv[0]->c.obj.iv[6];
	local[4]= local[1];
	local[5]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[23];
	local[6]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ROUND(ctx,1,local+2); /*round*/
	argv[0]->c.obj.iv[27] = w;
	w = argv[0]->c.obj.iv[27];
	local[0]= w;
XitemBLK2259:
	ctx->vsp=local; return(local[0]);}

/*:draw-stick*/
static pointer XitemM2263joystick_item_draw_stick(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2268;}
	local[0]= argv[0]->c.obj.iv[28];
XitemENT2268:
	if (n>=4) { local[1]=(argv[3]); goto XitemENT2267;}
	local[1]= argv[0]->c.obj.iv[29];
XitemENT2267:
	if (n>=5) { local[2]=(argv[4]); goto XitemENT2266;}
	local[2]= T;
XitemENT2266:
XitemENT2265:
	if (n>5) maerror();
	local[3]= argv[0];
	local[4]= fqv[75];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= argv[0];
	local[4]= fqv[109];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= argv[0];
	local[4]= fqv[112];
	local[5]= local[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= argv[0];
	local[4]= fqv[113];
	local[5]= argv[0]->c.obj.iv[26];
	local[6]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[27];
	local[7]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[19];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[19];
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeflt(6.2831853071795862319959e+00);
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,8,local+3); /*send*/
	argv[0]->c.obj.iv[28] = local[0];
	argv[0]->c.obj.iv[29] = local[1];
	w = argv[0]->c.obj.iv[29];
	local[0]= w;
XitemBLK2264:
	ctx->vsp=local; return(local[0]);}

/*:value*/
static pointer XitemM2269joystick_item_value(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2274;}
	local[0]= NIL;
XitemENT2274:
	if (n>=4) { local[1]=(argv[3]); goto XitemENT2273;}
	local[1]= NIL;
XitemENT2273:
	if (n>=5) { local[2]=(argv[4]); goto XitemENT2272;}
	local[2]= NIL;
XitemENT2272:
XitemENT2271:
	if (n>5) maerror();
	if (local[0]==NIL) goto XitemIF2275;
	if (local[1]==NIL) goto XitemIF2275;
	local[3]= argv[0]->c.obj.iv[20];
	local[4]= argv[0]->c.obj.iv[22];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)MIN(ctx,2,local+4); /*min*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MAX(ctx,2,local+3); /*max*/
	local[0] = w;
	local[3]= argv[0]->c.obj.iv[21];
	local[4]= argv[0]->c.obj.iv[23];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)MIN(ctx,2,local+4); /*min*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MAX(ctx,2,local+3); /*max*/
	local[1] = w;
	local[3]= argv[0];
	local[4]= fqv[110];
	local[5]= local[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto XitemIF2276;
XitemIF2275:
	local[3]= NIL;
XitemIF2276:
	if (local[2]==NIL) goto XitemIF2277;
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[3]));
	local[5]= fqv[45];
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SENDMESSAGE(ctx,5,local+3); /*send-message*/
	local[3]= w;
	goto XitemIF2278;
XitemIF2277:
	local[3]= NIL;
XitemIF2278:
	local[3]= argv[0]->c.obj.iv[28];
	local[4]= argv[0]->c.obj.iv[29];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[0]= w;
XitemBLK2270:
	ctx->vsp=local; return(local[0]);}

/*:buttonpress*/
static pointer XitemM2279joystick_item_buttonpress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	local[3]= loadglobal(fqv[14]);
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,1,local+3,&ftab[3],fqv[40]); /*event-x*/
	local[3]= w;
	local[4]= loadglobal(fqv[14]);
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,1,local+4,&ftab[4],fqv[41]); /*event-y*/
	local[4]= w;
	local[5]= local[3];
	local[6]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= local[4];
	local[7]= argv[0]->c.obj.iv[27];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	local[7]= local[5];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= local[6];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SQRT(ctx,1,local+7); /*sqrt*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto XitemIF2281;
	argv[0]->c.obj.iv[31] = T;
	local[7]= argv[0]->c.obj.iv[31];
	goto XitemIF2282;
XitemIF2281:
	local[7]= NIL;
XitemIF2282:
	w = local[7];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2280:
	ctx->vsp=local; return(local[0]);}

/*:value-from-event*/
static pointer XitemM2283joystick_item_value_from_event(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	if (n>=4) { local[3]=(argv[3]); goto XitemENT2286;}
	local[3]= argv[0]->c.obj.iv[34];
XitemENT2286:
XitemENT2285:
	if (n>4) maerror();
	local[4]= loadglobal(fqv[14]);
	ctx->vsp=local+5;
	w=(*ftab[3])(ctx,1,local+4,&ftab[3],fqv[40]); /*event-x*/
	local[4]= w;
	local[5]= loadglobal(fqv[14]);
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,1,local+5,&ftab[4],fqv[41]); /*event-y*/
	local[5]= w;
	local[6]= local[4];
	local[7]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[27];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[7]= w;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= argv[0]->c.obj.iv[28];
	local[11]= local[6];
	local[12]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[8] = w;
	local[10]= argv[0]->c.obj.iv[29];
	local[11]= local[7];
	local[12]= argv[0]->c.obj.iv[33];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[9] = w;
	local[10]= argv[0];
	local[11]= fqv[72];
	local[12]= local[8];
	local[13]= local[9];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,5,local+10); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	unbindx(ctx,1);
	w = local[4];
	local[0]= w;
XitemBLK2284:
	ctx->vsp=local; return(local[0]);}

/*:motionnotify*/
static pointer XitemM2287joystick_item_motionnotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	if (argv[0]->c.obj.iv[31]==NIL) goto XitemIF2289;
	local[3]= argv[0];
	local[4]= fqv[114];
	local[5]= loadglobal(fqv[14]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto XitemIF2290;
XitemIF2289:
	local[3]= NIL;
XitemIF2290:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2288:
	ctx->vsp=local; return(local[0]);}

/*:buttonrelease*/
static pointer XitemM2291joystick_item_buttonrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[14],w);
	if (argv[0]->c.obj.iv[31]==NIL) goto XitemIF2293;
	argv[0]->c.obj.iv[31] = NIL;
	if (argv[0]->c.obj.iv[30]==NIL) goto XitemCON2296;
	local[3]= argv[0];
	local[4]= fqv[72];
	local[5]= argv[0]->c.obj.iv[20];
	local[6]= argv[0]->c.obj.iv[22];
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[21];
	local[7]= argv[0]->c.obj.iv[23];
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[7]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= T;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,5,local+3); /*send*/
	local[3]= w;
	goto XitemCON2295;
XitemCON2296:
	if (argv[0]->c.obj.iv[34]!=NIL) goto XitemCON2297;
	local[3]= argv[0];
	local[4]= fqv[114];
	local[5]= loadglobal(fqv[14]);
	local[6]= T;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto XitemCON2295;
XitemCON2297:
	local[3]= NIL;
XitemCON2295:
	goto XitemIF2294;
XitemIF2293:
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[3]));
	local[5]= fqv[46];
	local[6]= loadglobal(fqv[14]);
	ctx->vsp=local+7;
	w=(pointer)SENDMESSAGE(ctx,4,local+3); /*send-message*/
	local[3]= w;
XitemIF2294:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XitemBLK2292:
	ctx->vsp=local; return(local[0]);}

/*:create-bitmap-from-file*/
static pointer XitemM2298bitmap_button_item_create_bitmap_from_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[115]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= loadglobal(fqv[115]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= loadglobal(fqv[116]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= loadglobal(fqv[115]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= loadglobal(fqv[115]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(*ftab[12])(ctx,1,local+5,&ftab[12],fqv[117]); /*probe-file*/
	if (w!=NIL) goto XitemIF2300;
	local[5]= NIL;
	local[6]= fqv[118];
	local[7]= loadglobal(fqv[119]);
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	argv[2] = w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(*ftab[12])(ctx,1,local+5,&ftab[12],fqv[117]); /*probe-file*/
	if (w!=NIL) goto XitemIF2302;
	local[5]= fqv[120];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SIGERROR(ctx,2,local+5); /*error*/
	local[5]= w;
	goto XitemIF2303;
XitemIF2302:
	local[5]= NIL;
XitemIF2303:
	goto XitemIF2301;
XitemIF2300:
	local[5]= NIL;
XitemIF2301:
	local[5]= loadglobal(fqv[121]);
	local[6]= loadglobal(fqv[121]);
	ctx->vsp=local+7;
	w=(*ftab[13])(ctx,1,local+6,&ftab[13],fqv[122]); /*defaultrootwindow*/
	local[6]= w;
	local[7]= argv[2];
	local[8]= local[0];
	local[9]= local[1];
	local[10]= local[2];
	local[11]= local[3];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(*ftab[14])(ctx,8,local+5,&ftab[14],fqv[123]); /*readbitmapfile*/
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[15])(ctx,1,local+5,&ftab[15],fqv[115]); /*c-int*/
	argv[0]->c.obj.iv[26] = w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(*ftab[15])(ctx,1,local+5,&ftab[15],fqv[115]); /*c-int*/
	argv[0]->c.obj.iv[27] = w;
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[16])(ctx,1,local+5,&ftab[16],fqv[116]); /*c-long*/
	argv[0]->c.obj.iv[25] = w;
	w = argv[0]->c.obj.iv[25];
	local[0]= w;
XitemBLK2299:
	ctx->vsp=local; return(local[0]);}

/*:redraw*/
static pointer XitemM2304bitmap_button_item_redraw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[32];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
XitemBLK2305:
	ctx->vsp=local; return(local[0]);}

/*:draw-label*/
static pointer XitemM2306bitmap_button_item_draw_label(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XitemENT2311;}
	local[0]= fqv[24];
XitemENT2311:
	if (n>=4) { local[1]=(argv[3]); goto XitemENT2310;}
	local[1]= argv[0]->c.obj.iv[4];
XitemENT2310:
	if (n>=5) { local[2]=(argv[4]); goto XitemENT2309;}
	local[2]= makeint((eusinteger_t)2L);
XitemENT2309:
XitemENT2308:
	if (n>5) maerror();
	local[3]= argv[0];
	local[4]= fqv[34];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= argv[0]->c.obj.iv[5];
	local[8]= argv[0]->c.obj.iv[6];
	local[9]= local[2];
	local[10]= argv[0]->c.obj.iv[23];
	local[11]= argv[0]->c.obj.iv[22];
	local[12]= argv[0]->c.obj.iv[4];
	local[13]= argv[0]->c.obj.iv[24];
	local[14]= local[0];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,12,local+3); /*send*/
	local[3]= loadglobal(fqv[121]);
	local[4]= argv[0]->c.obj.iv[25];
	local[5]= argv[0]->c.obj.iv[2];
	local[6]= argv[0]->c.obj.iv[3]->c.obj.iv[2];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= argv[0]->c.obj.iv[26];
	local[10]= argv[0]->c.obj.iv[27];
	local[11]= makeint((eusinteger_t)2L);
	local[12]= makeint((eusinteger_t)2L);
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(*ftab[17])(ctx,11,local+3,&ftab[17],fqv[124]); /*copyplane*/
	local[0]= w;
XitemBLK2307:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XitemM2312bitmap_button_item_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
XitemRST2314:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-5);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[125], &argv[5], n-5, local+1, 1);
	if (n & (1<<0)) goto XitemKEY2315;
	local[1] = NIL;
XitemKEY2315:
	if (n & (1<<1)) goto XitemKEY2316;
	local[2] = NIL;
XitemKEY2316:
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[0];
	local[7]= fqv[126];
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	if (local[1]!=NIL) goto XitemIF2317;
	local[6]= argv[0]->c.obj.iv[26];
	local[7]= makeint((eusinteger_t)4L);
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	goto XitemIF2318;
XitemIF2317:
	local[6]= local[1];
XitemIF2318:
	local[4] = local[6];
	if (local[2]!=NIL) goto XitemIF2319;
	local[6]= argv[0]->c.obj.iv[27];
	local[7]= makeint((eusinteger_t)4L);
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	goto XitemIF2320;
XitemIF2319:
	local[6]= local[2];
XitemIF2320:
	local[5] = local[6];
	local[6]= (pointer)get_sym_func(fqv[2]);
	local[7]= argv[0];
	local[8]= *(ovafptr(argv[1],fqv[3]));
	local[9]= fqv[4];
	local[10]= argv[2];
	local[11]= argv[3];
	local[12]= argv[4];
	local[13]= fqv[6];
	local[14]= local[4];
	local[15]= fqv[7];
	local[16]= local[5];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)APPLY(ctx,12,local+6); /*apply*/
	local[6]= argv[2];
	local[7]= local[6];
	w = argv[0];
	w->c.obj.iv[16] = local[7];
	w = local[6];
	w = argv[0];
	local[0]= w;
XitemBLK2313:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___Xitem(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[127];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto XitemIF2321;
	local[0]= fqv[128];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[129],w);
	goto XitemIF2322;
XitemIF2321:
	local[0]= fqv[130];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
XitemIF2322:
	local[0]= fqv[131];
	local[1]= fqv[132];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[133]); /*require*/
	local[0]= fqv[134];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[55];
	local[1]= fqv[135];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto XitemIF2323;
	local[0]= fqv[55];
	local[1]= fqv[135];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[55];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto XitemIF2325;
	local[0]= fqv[55];
	local[1]= fqv[136];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XitemIF2326;
XitemIF2325:
	local[0]= NIL;
XitemIF2326:
	local[0]= fqv[55];
	goto XitemIF2324;
XitemIF2323:
	local[0]= NIL;
XitemIF2324:
	ctx->vsp=local+0;
	compfun(ctx,fqv[137],module,XitemF1949clump,fqv[138]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[139],module,XitemF1950replace_key_arg,fqv[140]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM1959panel_item_create,fqv[4],fqv[141],fqv[142]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM1968panel_item_draw_label,fqv[32],fqv[141],fqv[143]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM1970panel_item_notify,fqv[45],fqv[141],fqv[144]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM1977panel_item_keypress,fqv[145],fqv[141],fqv[146]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM1979panel_item_keyrelease,fqv[147],fqv[141],fqv[148]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM1981panel_item_buttonpress,fqv[149],fqv[141],fqv[150]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM1983panel_item_motionnotify,fqv[151],fqv[141],fqv[152]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM1985panel_item_enternotify,fqv[78],fqv[141],fqv[153]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM1987panel_item_leavenotify,fqv[77],fqv[141],fqv[154]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[155],module,XitemF1951make_topleft_edge_polygon,fqv[156]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM1990button_item_create,fqv[4],fqv[157],fqv[158]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2009button_item_submenu,fqv[159],fqv[157],fqv[160]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2015button_item_active_color,fqv[161],fqv[157],fqv[162]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2021button_item_resize,fqv[33],fqv[157],fqv[163]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2023button_item_label,fqv[50],fqv[157],fqv[164]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2030button_item_draw_label,fqv[32],fqv[157],fqv[165]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2041button_item_redraw,fqv[73],fqv[157],fqv[166]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2043button_item_keypress,fqv[145],fqv[157],fqv[167]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2045button_item_keyrelease,fqv[147],fqv[157],fqv[168]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2047button_item_buttonpress,fqv[149],fqv[157],fqv[169]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2049button_item_buttonrelease,fqv[46],fqv[157],fqv[170]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2058button_item_enternotify,fqv[78],fqv[157],fqv[171]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2062button_item_leavenotify,fqv[77],fqv[157],fqv[172]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2066menu_button_item_create,fqv[4],fqv[173],fqv[174]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2072menu_button_item_label,fqv[50],fqv[173],fqv[175]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2080menu_button_item_popup_menu,fqv[57],fqv[173],fqv[176]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2082menu_button_item_unmap_menu,fqv[58],fqv[173],fqv[177]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2084menu_button_item_buttonpress,fqv[149],fqv[173],fqv[178]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2086menu_button_item_buttonrelease,fqv[46],fqv[173],fqv[179]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2090menu_button_item_enternotify,fqv[78],fqv[173],fqv[180]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2094text_item_create,fqv[4],fqv[181],fqv[182]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2103text_item_redraw,fqv[73],fqv[181],fqv[183]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2105text_item_getstring,fqv[184],fqv[181],fqv[185]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2107text_item_value,fqv[72],fqv[181],fqv[186]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2116text_item_leavenotify,fqv[77],fqv[181],fqv[187]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2118text_item_enternotify,fqv[78],fqv[181],fqv[188]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2120slider_item_create,fqv[4],fqv[189],fqv[190]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2134slider_item_new_range,fqv[81],fqv[189],fqv[191]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2140slider_item_continuous_notify,fqv[84],fqv[189],fqv[192]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2142slider_item_redraw,fqv[73],fqv[189],fqv[193]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2144slider_item_display_value,fqv[87],fqv[189],fqv[194]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2150slider_item_value,fqv[72],fqv[189],fqv[195]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2159slider_item_nob_x,fqv[83],fqv[189],fqv[196]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2163slider_item_inside_nob_p,fqv[92],fqv[189],fqv[197]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2166slider_item_draw_bar_rectangle,fqv[85],fqv[189],fqv[198]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2168slider_item_draw_nob_rectangle,fqv[86],fqv[189],fqv[199]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2173slider_item_buttonpress,fqv[149],fqv[189],fqv[200]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2177slider_item_compute_value,fqv[93],fqv[189],fqv[201]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2179slider_item_motionnotify,fqv[151],fqv[189],fqv[202]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2183slider_item_buttonrelease,fqv[46],fqv[189],fqv[203]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2187choice_item_create,fqv[4],fqv[204],fqv[205]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2208choice_item_draw_label,fqv[32],fqv[204],fqv[206]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2212choice_item_redraw,fqv[73],fqv[204],fqv[207]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2217choice_item_value,fqv[72],fqv[204],fqv[208]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2226choice_item_draw_active_button,fqv[101],fqv[204],fqv[209]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2231choice_item_choice,fqv[107],fqv[204],fqv[210]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2238choice_item_buttonpress,fqv[149],fqv[204],fqv[211]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2240choice_item_buttonrelease,fqv[46],fqv[204],fqv[212]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2244joystick_item_create,fqv[4],fqv[213],fqv[214]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2254joystick_item_redraw,fqv[73],fqv[213],fqv[215]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2256joystick_item_draw_circles,fqv[109],fqv[213],fqv[216]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2258joystick_item_xy,fqv[112],fqv[213],fqv[217]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2263joystick_item_draw_stick,fqv[110],fqv[213],fqv[218]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2269joystick_item_value,fqv[72],fqv[213],fqv[219]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2279joystick_item_buttonpress,fqv[149],fqv[213],fqv[220]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2283joystick_item_value_from_event,fqv[114],fqv[213],fqv[221]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2287joystick_item_motionnotify,fqv[151],fqv[213],fqv[222]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2291joystick_item_buttonrelease,fqv[46],fqv[213],fqv[223]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2298bitmap_button_item_create_bitmap_from_file,fqv[126],fqv[224],fqv[225]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2304bitmap_button_item_redraw,fqv[73],fqv[224],fqv[226]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2306bitmap_button_item_draw_label,fqv[32],fqv[224],fqv[227]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XitemM2312bitmap_button_item_create,fqv[4],fqv[224],fqv[228]);
	local[0]= fqv[229];
	local[1]= fqv[230];
	ctx->vsp=local+2;
	w=(*ftab[19])(ctx,2,local+0,&ftab[19],fqv[231]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<20; i++) ftab[i]=fcallx;
}

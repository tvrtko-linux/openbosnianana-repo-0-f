/* ./Xscroll.c :  entry=Xscroll */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "Xscroll.h"
#pragma init (register_Xscroll)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___Xscroll();
extern pointer build_quote_vector();
static int register_Xscroll()
  { add_module_initializer("___Xscroll", ___Xscroll);}


/*:create*/
static pointer XscrollM2965xscroll_bar_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XscrollRST2967:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[0], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto XscrollKEY2968;
	local[1] = NIL;
XscrollKEY2968:
	if (n & (1<<1)) goto XscrollKEY2969;
	local[2] = NIL;
XscrollKEY2969:
	if (n & (1<<2)) goto XscrollKEY2970;
	local[3] = NIL;
XscrollKEY2970:
	if (local[2]!=NIL) goto XscrollIF2971;
	if (local[1]==NIL) goto XscrollIF2973;
	local[4]= local[1];
	local[5]= fqv[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)15L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	goto XscrollIF2974;
XscrollIF2973:
	local[4]= makeint((eusinteger_t)150L);
XscrollIF2974:
	local[2] = local[4];
	local[4]= local[2];
	goto XscrollIF2972;
XscrollIF2971:
	local[4]= NIL;
XscrollIF2972:
	local[4]= (pointer)get_sym_func(fqv[2]);
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[3]));
	local[7]= fqv[4];
	local[8]= fqv[5];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= fqv[6];
	local[11]= makeint((eusinteger_t)3855L);
	local[12]= fqv[7];
	local[13]= local[1];
	local[14]= fqv[1];
	local[15]= local[2];
	local[16]= local[0];
	ctx->vsp=local+17;
	w=(pointer)APPLY(ctx,13,local+4); /*apply*/
	local[4]= argv[0];
	local[5]= fqv[8];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	argv[0]->c.obj.iv[5] = w;
	local[4]= argv[0];
	local[5]= fqv[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	argv[0]->c.obj.iv[6] = w;
	local[4]= makeint((eusinteger_t)3L);
	local[5]= argv[0]->c.obj.iv[5];
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(pointer)MIN(ctx,2,local+5); /*min*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= makeint((eusinteger_t)4L);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	argv[0]->c.obj.iv[12] = w;
	argv[0]->c.obj.iv[13] = argv[0]->c.obj.iv[12];
	argv[0]->c.obj.iv[14] = argv[0]->c.obj.iv[12];
	local[4]= argv[0]->c.obj.iv[6];
	local[5]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+6;
	w=(pointer)GREATERP(ctx,2,local+4); /*>*/
	argv[0]->c.obj.iv[15] = w;
	if (local[1]==NIL) goto XscrollIF2975;
	local[4]= argv[0];
	local[5]= fqv[9];
	if (argv[0]->c.obj.iv[15]==NIL) goto XscrollIF2977;
	local[6]= local[1];
	local[7]= fqv[8];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[5];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,3,local+6); /*-*/
	local[6]= w;
	goto XscrollIF2978;
XscrollIF2977:
	local[6]= makeint((eusinteger_t)0L);
XscrollIF2978:
	if (argv[0]->c.obj.iv[15]==NIL) goto XscrollIF2979;
	local[7]= makeint((eusinteger_t)0L);
	goto XscrollIF2980;
XscrollIF2979:
	local[7]= local[1];
	local[8]= fqv[1];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[6];
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,3,local+7); /*-*/
	local[7]= w;
XscrollIF2980:
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto XscrollIF2976;
XscrollIF2975:
	local[4]= NIL;
XscrollIF2976:
	local[4]= argv[0];
	local[5]= fqv[10];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[11];
	local[6]= makeflt(0.0000000000000000000000e+00);
	local[7]= makeflt(9.9999999999999977795540e-02);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = argv[0];
	local[0]= w;
XscrollBLK2966:
	ctx->vsp=local; return(local[0]);}

/*:draw-pattern*/
static pointer XscrollM2981xscroll_bar_draw_pattern(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[12];
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+7;
	w=(pointer)SUB1(ctx,1,local+6); /*1-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[12];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+5;
	w=(pointer)SUB1(ctx,1,local+4); /*1-*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[5];
	local[6]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+7;
	w=(pointer)SUB1(ctx,1,local+6); /*1-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[12];
	local[3]= argv[0]->c.obj.iv[5];
	local[4]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+5;
	w=(pointer)SUB1(ctx,1,local+4); /*1-*/
	local[4]= w;
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[12];
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[6];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[6];
	local[7]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[12];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[6];
	local[5]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[5];
	local[6]= argv[0]->c.obj.iv[6];
	local[7]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[12];
	local[3]= argv[0]->c.obj.iv[5];
	local[4]= argv[0]->c.obj.iv[6];
	local[5]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	local[5]= local[0];
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[0]= w;
XscrollBLK2982:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer XscrollM2983xscroll_bar_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[3]));
	local[2]= fqv[13];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,5,local+0); /*send-message*/
	local[0]= argv[0];
	local[1]= fqv[14];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[5] = argv[2];
	argv[0]->c.obj.iv[6] = argv[3];
	local[0]= argv[0];
	local[1]= fqv[10];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
XscrollBLK2984:
	ctx->vsp=local; return(local[0]);}

/*:move-handle*/
static pointer XscrollM2985xscroll_bar_move_handle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XscrollENT2989;}
	local[0]= makeflt(0.0000000000000000000000e+00);
XscrollENT2989:
	if (n>=4) { local[1]=(argv[3]); goto XscrollENT2988;}
	local[1]= makeflt(9.9999999999999977795540e-02);
XscrollENT2988:
XscrollENT2987:
	if (n>4) maerror();
	if (argv[0]->c.obj.iv[15]==NIL) goto XscrollIF2990;
	local[2]= argv[0];
	local[3]= fqv[15];
	local[4]= fqv[16];
	local[5]= argv[0]->c.obj.iv[13];
	local[6]= fqv[1];
	local[7]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[2]= w;
	goto XscrollIF2991;
XscrollIF2990:
	local[2]= argv[0];
	local[3]= fqv[15];
	local[4]= fqv[17];
	local[5]= argv[0]->c.obj.iv[13];
	local[6]= fqv[8];
	local[7]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[2]= w;
XscrollIF2991:
	if (argv[0]->c.obj.iv[15]==NIL) goto XscrollIF2992;
	local[2]= argv[0]->c.obj.iv[6];
	goto XscrollIF2993;
XscrollIF2992:
	local[2]= argv[0]->c.obj.iv[5];
XscrollIF2993:
	local[3]= makeint((eusinteger_t)2L);
	local[4]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	local[3]= local[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ROUND(ctx,1,local+3); /*round*/
	argv[0]->c.obj.iv[14] = w;
	local[3]= local[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[2] = w;
	local[3]= argv[0]->c.obj.iv[12];
	local[4]= local[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ROUND(ctx,1,local+4); /*round*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	argv[0]->c.obj.iv[13] = w;
	if (argv[0]->c.obj.iv[15]==NIL) goto XscrollIF2994;
	local[3]= argv[0];
	local[4]= fqv[18];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[13];
	local[7]= argv[0]->c.obj.iv[5];
	local[8]= argv[0]->c.obj.iv[14];
	local[9]= loadglobal(fqv[19]);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,7,local+3); /*send*/
	local[3]= w;
	goto XscrollIF2995;
XscrollIF2994:
	local[3]= argv[0];
	local[4]= fqv[18];
	local[5]= argv[0]->c.obj.iv[13];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= argv[0]->c.obj.iv[14];
	local[8]= argv[0]->c.obj.iv[6];
	local[9]= loadglobal(fqv[19]);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,7,local+3); /*send*/
	local[3]= w;
XscrollIF2995:
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,0,local+3,&ftab[0],fqv[20]); /*xflush*/
	local[0]= w;
XscrollBLK2986:
	ctx->vsp=local; return(local[0]);}

/*:hit-region*/
static pointer XscrollM2996xscroll_bar_hit_region(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[21],w);
	local[3]= loadglobal(fqv[21]);
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,1,local+3,&ftab[1],fqv[22]); /*event-x*/
	local[3]= w;
	local[4]= loadglobal(fqv[21]);
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,1,local+4,&ftab[2],fqv[23]); /*event-y*/
	local[4]= w;
	local[5]= NIL;
	local[6]= NIL;
	if (argv[0]->c.obj.iv[15]==NIL) goto XscrollIF2998;
	local[5] = local[4];
	local[6] = argv[0]->c.obj.iv[6];
	local[7]= local[6];
	goto XscrollIF2999;
XscrollIF2998:
	local[5] = local[3];
	local[6] = argv[0]->c.obj.iv[5];
	local[7]= local[6];
XscrollIF2999:
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w!=NIL) goto XscrollOR3002;
	local[7]= argv[0]->c.obj.iv[5];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w!=NIL) goto XscrollOR3002;
	local[7]= local[4];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w!=NIL) goto XscrollOR3002;
	local[7]= argv[0]->c.obj.iv[6];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w!=NIL) goto XscrollOR3002;
	goto XscrollCON3001;
XscrollOR3002:
	local[7]= fqv[24];
	goto XscrollCON3000;
XscrollCON3001:
	local[7]= local[5];
	local[8]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto XscrollCON3003;
	local[7]= fqv[25];
	goto XscrollCON3000;
XscrollCON3003:
	local[7]= local[5];
	local[8]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto XscrollCON3004;
	local[7]= fqv[26];
	goto XscrollCON3000;
XscrollCON3004:
	local[7]= local[5];
	local[8]= argv[0]->c.obj.iv[13];
	local[9]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto XscrollCON3005;
	local[7]= fqv[27];
	goto XscrollCON3000;
XscrollCON3005:
	local[7]= local[5];
	local[8]= local[6];
	local[9]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto XscrollCON3006;
	local[7]= fqv[28];
	goto XscrollCON3000;
XscrollCON3006:
	local[7]= local[5];
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto XscrollCON3007;
	local[7]= fqv[29];
	goto XscrollCON3000;
XscrollCON3007:
	local[7]= NIL;
	goto XscrollCON3000;
XscrollCON3008:
	local[7]= NIL;
XscrollCON3000:
	w = local[7];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XscrollBLK2997:
	ctx->vsp=local; return(local[0]);}

/*:buttonpress*/
static pointer XscrollM3009xscroll_bar_buttonpress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[21],w);
	local[3]= argv[0];
	local[4]= fqv[10];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= argv[0];
	local[4]= fqv[30];
	local[5]= loadglobal(fqv[21]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= local[3];
	if (fqv[27]!=local[4]) goto XscrollIF3011;
	local[4]= loadglobal(fqv[21]);
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,1,local+4,&ftab[2],fqv[23]); /*event-y*/
	argv[0]->c.obj.iv[16] = w;
	local[4]= argv[0]->c.obj.iv[16];
	goto XscrollIF3012;
XscrollIF3011:
	local[4]= local[3];
	if (fqv[25]!=local[4]) goto XscrollIF3013;
	local[4]= argv[0]->c.obj.iv[7];
	local[5]= fqv[31];
	local[6]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XscrollIF3014;
XscrollIF3013:
	local[4]= local[3];
	if (fqv[29]!=local[4]) goto XscrollIF3015;
	local[4]= argv[0]->c.obj.iv[7];
	local[5]= fqv[31];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XscrollIF3016;
XscrollIF3015:
	local[4]= local[3];
	if (fqv[26]!=local[4]) goto XscrollIF3017;
	local[4]= argv[0]->c.obj.iv[7];
	local[5]= fqv[31];
	local[6]= argv[0]->c.obj.iv[7];
	local[7]= fqv[32];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XscrollIF3018;
XscrollIF3017:
	local[4]= local[3];
	if (fqv[28]!=local[4]) goto XscrollIF3019;
	local[4]= argv[0]->c.obj.iv[7];
	local[5]= fqv[31];
	local[6]= argv[0]->c.obj.iv[7];
	local[7]= fqv[32];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XscrollIF3020;
XscrollIF3019:
	if (T==NIL) goto XscrollIF3021;
	local[4]= NIL;
	goto XscrollIF3022;
XscrollIF3021:
	local[4]= NIL;
XscrollIF3022:
XscrollIF3020:
XscrollIF3018:
XscrollIF3016:
XscrollIF3014:
XscrollIF3012:
	w = local[4];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XscrollBLK3010:
	ctx->vsp=local; return(local[0]);}

/*:motionnotify*/
static pointer XscrollM3023xscroll_bar_motionnotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[21],w);
	if (argv[0]->c.obj.iv[16]==NIL) goto XscrollIF3025;
	local[3]= loadglobal(fqv[21]);
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,1,local+3,&ftab[1],fqv[22]); /*event-x*/
	local[3]= w;
	local[4]= loadglobal(fqv[21]);
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,1,local+4,&ftab[2],fqv[23]); /*event-y*/
	local[4]= w;
	local[5]= local[4];
	local[6]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)EUSFLOAT(ctx,1,local+5); /*float*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[6];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= local[5];
	ctx->vsp=local+7;
	w=(pointer)ABS(ctx,1,local+6); /*abs*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[7];
	local[8]= fqv[33];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)GREQP(ctx,2,local+6); /*>=*/
	if (w==NIL) goto XscrollIF3027;
	local[6]= argv[0]->c.obj.iv[7];
	local[7]= fqv[31];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	argv[0]->c.obj.iv[16] = local[4];
	local[6]= argv[0]->c.obj.iv[16];
	goto XscrollIF3028;
XscrollIF3027:
	local[6]= NIL;
XscrollIF3028:
	w = local[6];
	local[3]= w;
	goto XscrollIF3026;
XscrollIF3025:
	local[3]= NIL;
XscrollIF3026:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XscrollBLK3024:
	ctx->vsp=local; return(local[0]);}

/*:buttonrelease*/
static pointer XscrollM3029xscroll_bar_buttonrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[21],w);
	argv[0]->c.obj.iv[16] = NIL;
	local[3]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XscrollBLK3030:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XscrollM3031xhorizontal_scroll_bar_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XscrollRST3033:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[34], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto XscrollKEY3034;
	local[1] = NIL;
XscrollKEY3034:
	if (n & (1<<1)) goto XscrollKEY3035;
	local[2] = NIL;
XscrollKEY3035:
	if (local[2]!=NIL) goto XscrollIF3036;
	if (local[1]==NIL) goto XscrollIF3038;
	local[3]= local[1];
	local[4]= fqv[8];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)15L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	goto XscrollIF3039;
XscrollIF3038:
	local[3]= makeint((eusinteger_t)100L);
XscrollIF3039:
	local[2] = local[3];
	local[3]= local[2];
	goto XscrollIF3037;
XscrollIF3036:
	local[3]= NIL;
XscrollIF3037:
	local[3]= (pointer)get_sym_func(fqv[2]);
	local[4]= argv[0];
	local[5]= *(ovafptr(argv[1],fqv[3]));
	local[6]= fqv[4];
	local[7]= fqv[8];
	local[8]= local[2];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)APPLY(ctx,7,local+3); /*apply*/
	w = argv[0];
	local[0]= w;
XscrollBLK3032:
	ctx->vsp=local; return(local[0]);}

/*:draw-pattern*/
static pointer XscrollM3040xhorizontal_scroll_bar_draw_pattern(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[6];
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[12];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[0];
	local[5]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+6;
	w=(pointer)SUB1(ctx,1,local+5); /*1-*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[12];
	local[3]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+4;
	w=(pointer)SUB1(ctx,1,local+3); /*1-*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+6;
	w=(pointer)SUB1(ctx,1,local+5); /*1-*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[12];
	local[3]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+4;
	w=(pointer)SUB1(ctx,1,local+3); /*1-*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[6];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[12];
	local[3]= argv[0]->c.obj.iv[5];
	local[4]= local[0];
	local[5]= argv[0]->c.obj.iv[5];
	local[6]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[12];
	local[3]= argv[0]->c.obj.iv[5];
	local[4]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[0]->c.obj.iv[5];
	local[6]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[12];
	local[3]= argv[0]->c.obj.iv[5];
	local[4]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[6];
	local[5]= argv[0]->c.obj.iv[5];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[14];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0]= w;
XscrollBLK3041:
	ctx->vsp=local; return(local[0]);}

/*:buttonpress*/
static pointer XscrollM3042xhorizontal_scroll_bar_buttonpress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[21],w);
	local[3]= argv[0];
	local[4]= fqv[10];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= argv[0];
	local[4]= fqv[30];
	local[5]= loadglobal(fqv[21]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= local[3];
	if (fqv[27]!=local[4]) goto XscrollIF3044;
	local[4]= loadglobal(fqv[21]);
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,1,local+4,&ftab[1],fqv[22]); /*event-x*/
	argv[0]->c.obj.iv[16] = w;
	local[4]= argv[0]->c.obj.iv[16];
	goto XscrollIF3045;
XscrollIF3044:
	local[4]= local[3];
	if (fqv[25]!=local[4]) goto XscrollIF3046;
	local[4]= argv[0]->c.obj.iv[7];
	local[5]= fqv[35];
	local[6]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XscrollIF3047;
XscrollIF3046:
	local[4]= local[3];
	if (fqv[29]!=local[4]) goto XscrollIF3048;
	local[4]= argv[0]->c.obj.iv[7];
	local[5]= fqv[35];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XscrollIF3049;
XscrollIF3048:
	local[4]= local[3];
	if (fqv[26]!=local[4]) goto XscrollIF3050;
	local[4]= argv[0]->c.obj.iv[7];
	local[5]= fqv[35];
	local[6]= argv[0]->c.obj.iv[7];
	local[7]= fqv[36];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XscrollIF3051;
XscrollIF3050:
	local[4]= local[3];
	if (fqv[28]!=local[4]) goto XscrollIF3052;
	local[4]= argv[0]->c.obj.iv[7];
	local[5]= fqv[35];
	local[6]= argv[0]->c.obj.iv[7];
	local[7]= fqv[36];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XscrollIF3053;
XscrollIF3052:
	if (T==NIL) goto XscrollIF3054;
	local[4]= NIL;
	goto XscrollIF3055;
XscrollIF3054:
	local[4]= NIL;
XscrollIF3055:
XscrollIF3053:
XscrollIF3051:
XscrollIF3049:
XscrollIF3047:
XscrollIF3045:
	w = local[4];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XscrollBLK3043:
	ctx->vsp=local; return(local[0]);}

/*:motionnotify*/
static pointer XscrollM3056xhorizontal_scroll_bar_motionnotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[21],w);
	if (argv[0]->c.obj.iv[16]==NIL) goto XscrollIF3058;
	local[3]= loadglobal(fqv[21]);
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,1,local+3,&ftab[1],fqv[22]); /*event-x*/
	local[3]= w;
	local[4]= loadglobal(fqv[21]);
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,1,local+4,&ftab[2],fqv[23]); /*event-y*/
	local[4]= w;
	local[5]= local[3];
	local[6]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)EUSFLOAT(ctx,1,local+5); /*float*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[5];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= local[5];
	ctx->vsp=local+7;
	w=(pointer)ABS(ctx,1,local+6); /*abs*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[7];
	local[8]= fqv[37];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)GREQP(ctx,2,local+6); /*>=*/
	if (w==NIL) goto XscrollIF3060;
	local[6]= argv[0]->c.obj.iv[7];
	local[7]= fqv[35];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	argv[0]->c.obj.iv[16] = local[3];
	local[6]= argv[0]->c.obj.iv[16];
	goto XscrollIF3061;
XscrollIF3060:
	local[6]= NIL;
XscrollIF3061:
	w = local[6];
	local[3]= w;
	goto XscrollIF3059;
XscrollIF3058:
	local[3]= NIL;
XscrollIF3059:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XscrollBLK3057:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___Xscroll(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[38];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto XscrollIF3062;
	local[0]= fqv[39];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[40],w);
	goto XscrollIF3063;
XscrollIF3062:
	local[0]= fqv[41];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
XscrollIF3063:
	local[0]= fqv[42];
	local[1]= fqv[43];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[44]); /*require*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,XscrollM2965xscroll_bar_create,fqv[4],fqv[45],fqv[46]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XscrollM2981xscroll_bar_draw_pattern,fqv[10],fqv[45],fqv[47]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XscrollM2983xscroll_bar_resize,fqv[13],fqv[45],fqv[48]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XscrollM2985xscroll_bar_move_handle,fqv[11],fqv[45],fqv[49]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XscrollM2996xscroll_bar_hit_region,fqv[30],fqv[45],fqv[50]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XscrollM3009xscroll_bar_buttonpress,fqv[51],fqv[45],fqv[52]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XscrollM3023xscroll_bar_motionnotify,fqv[53],fqv[45],fqv[54]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XscrollM3029xscroll_bar_buttonrelease,fqv[55],fqv[45],fqv[56]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XscrollM3031xhorizontal_scroll_bar_create,fqv[4],fqv[57],fqv[58]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XscrollM3040xhorizontal_scroll_bar_draw_pattern,fqv[10],fqv[57],fqv[59]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XscrollM3042xhorizontal_scroll_bar_buttonpress,fqv[51],fqv[57],fqv[60]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XscrollM3056xhorizontal_scroll_bar_motionnotify,fqv[53],fqv[57],fqv[61]);
	local[0]= fqv[62];
	local[1]= fqv[63];
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[64]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<5; i++) ftab[i]=fcallx;
}

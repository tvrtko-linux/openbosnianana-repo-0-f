/*
 * libedataserverui4.h
 *
 * This library is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library. If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef LIBEDATASERVERUI4_H
#define LIBEDATASERVERUI4_H

#define __LIBEDATASERVERUI_H_INSIDE__

#include <libedataserverui4/e-buffer-tagger.h>
#include <libedataserverui4/e-cell-renderer-color.h>
#include <libedataserverui4/e-certificate-widget.h>
#include <libedataserverui4/e-credentials-prompter.h>
#include <libedataserverui4/e-credentials-prompter-impl.h>
#include <libedataserverui4/e-credentials-prompter-impl-oauth2.h>
#include <libedataserverui4/e-credentials-prompter-impl-password.h>
#include <libedataserverui4/e-reminders-widget.h>
#include <libedataserverui4/e-trust-prompt.h>
#include <libedataserverui4/e-webdav-discover-widget.h>

#undef __LIBEDATASERVERUI_H_INSIDE__

#endif /* LIBEDATASERVERUI4_H */

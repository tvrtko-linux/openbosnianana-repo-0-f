#!/bin/sh
# test for fastaclean utility

PROGRAM="/usr/bin/fastaclean"
INPUTFILE="./data/protein/calm.human.protein.fasta"

$PROGRAM -p TRUE $INPUTFILE

exit $?


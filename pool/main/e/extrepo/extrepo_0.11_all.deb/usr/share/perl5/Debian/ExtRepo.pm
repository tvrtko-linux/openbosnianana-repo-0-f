package Debian::ExtRepo;

our $VERSION;

$VERSION = "0.1";

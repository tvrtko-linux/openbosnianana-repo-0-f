Authors
-------

eyeD3 is written and maintained by:

  * Travis Shirk <travis@pobox.com>

and has been contributed to by (ordered by date of first contribution):

  * Ryan Finnie <ryan@finnie.org>
  * Henning Kiel <henning.kiel@rwth-aachen.de>
  * Knight Walker <kwalker@kobran.org>
  * Todd Zullinger <tmz@pobox.com>
  * Aaron VonderHaar <avh4@users.sourceforge.net>
  * Alexander Thomas <dr-lex@dr-lex.34sp.com>
  * Michael Schout <mschout@gkg.net>
  * Renaud Saint-Gratien <rsg@nerim.net>
  * David Grant <davidgrant@gmail.com>
  * Gergan Penkov <gergan@gmail.com>
  * Stephen Fairchild <sfairchild@bethere.co.uk>
  * Ville Skyttä <ville.skytta@iki.fi>
  * Ben Isaacs <me@ben-xo.com>
  * Neil Schemenauer <nas@arctrix.com>
  * Otávio Pontes <otaviobp@gmail.com>
  * Nathaniel Clark <nate@misrule.us>
  * Hans Meine <hmeine@users.noreply.github.com>
  * Hans Petter Jansson <hpj@copyleft.no>
  * Sebastian Patschorke <sludgefeast@users.noreply.github.com>
  * Bouke Versteegh <info@boukeversteegh.nl>
  * gaetano-guerriero <x.guerriero@tin.it>
  * mafro <github@mafro.net>
  * Gabriel Diego Teixeira <gabrieldiegoteixeira@gmail.com>
  * Chris Newton <redshodan@gmail.com>
  * Thomas Klausner <tk@giga.or.at>
  * Tim Gates <tim.gates@iress.com>
  * chamatht <chamatht@gmail.com>
  * grun <grunseid@gmail.com>
  * guiweber <guillaume.web@gmail.com>
  * zhu <zhumumu@gmail.com>

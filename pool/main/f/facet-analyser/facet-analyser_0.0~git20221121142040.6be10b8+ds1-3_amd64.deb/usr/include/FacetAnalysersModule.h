
#ifndef FACETANALYSERS_EXPORT_H
#define FACETANALYSERS_EXPORT_H

#ifdef FACETANALYSERS_STATIC_DEFINE
#  define FACETANALYSERS_EXPORT
#  define FACETANALYSERS_NO_EXPORT
#else
#  ifndef FACETANALYSERS_EXPORT
#    ifdef FacetAnalysers_EXPORTS
        /* We are building this library */
#      define FACETANALYSERS_EXPORT 
#    else
        /* We are using this library */
#      define FACETANALYSERS_EXPORT 
#    endif
#  endif

#  ifndef FACETANALYSERS_NO_EXPORT
#    define FACETANALYSERS_NO_EXPORT 
#  endif
#endif

#ifndef FACETANALYSERS_DEPRECATED
#  define FACETANALYSERS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef FACETANALYSERS_DEPRECATED_EXPORT
#  define FACETANALYSERS_DEPRECATED_EXPORT FACETANALYSERS_EXPORT FACETANALYSERS_DEPRECATED
#endif

#ifndef FACETANALYSERS_DEPRECATED_NO_EXPORT
#  define FACETANALYSERS_DEPRECATED_NO_EXPORT FACETANALYSERS_NO_EXPORT FACETANALYSERS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef FACETANALYSERS_NO_DEPRECATED
#    define FACETANALYSERS_NO_DEPRECATED
#  endif
#endif

/* VTK-HeaderTest-Exclude: FacetAnalysersModule.h */

/* Include ABI Namespace */
#include "vtkABINamespace.h"

#endif /* FACETANALYSERS_EXPORT_H */

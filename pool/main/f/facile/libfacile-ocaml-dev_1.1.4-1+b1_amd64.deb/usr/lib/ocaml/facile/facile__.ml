(** @canonical Facile.Fcl_alldiff *)
module Fcl_alldiff = Facile__Fcl_alldiff


(** @canonical Facile.Fcl_arith *)
module Fcl_arith = Facile__Fcl_arith


(** @canonical Facile.Fcl_boolean *)
module Fcl_boolean = Facile__Fcl_boolean


(** @canonical Facile.Fcl_conjunto *)
module Fcl_conjunto = Facile__Fcl_conjunto


(** @canonical Facile.Fcl_cstr *)
module Fcl_cstr = Facile__Fcl_cstr


(** @canonical Facile.Fcl_data *)
module Fcl_data = Facile__Fcl_data


(** @canonical Facile.Fcl_debug *)
module Fcl_debug = Facile__Fcl_debug


(** @canonical Facile.Fcl_domain *)
module Fcl_domain = Facile__Fcl_domain


(** @canonical Facile.Fcl_expr *)
module Fcl_expr = Facile__Fcl_expr


(** @canonical Facile.Fcl_fdArray *)
module Fcl_fdArray = Facile__Fcl_fdArray


(** @canonical Facile.Fcl_float *)
module Fcl_float = Facile__Fcl_float


(** @canonical Facile.Fcl_gcc *)
module Fcl_gcc = Facile__Fcl_gcc


(** @canonical Facile.Fcl_genesis *)
module Fcl_genesis = Facile__Fcl_genesis


(** @canonical Facile.Fcl_goals *)
module Fcl_goals = Facile__Fcl_goals


(** @canonical Facile.Fcl_interval *)
module Fcl_interval = Facile__Fcl_interval


(** @canonical Facile.Fcl_invariant *)
module Fcl_invariant = Facile__Fcl_invariant


(** @canonical Facile.Fcl_linear *)
module Fcl_linear = Facile__Fcl_linear


(** @canonical Facile.Fcl_misc *)
module Fcl_misc = Facile__Fcl_misc


(** @canonical Facile.Fcl_nonlinear *)
module Fcl_nonlinear = Facile__Fcl_nonlinear


(** @canonical Facile.Fcl_opti *)
module Fcl_opti = Facile__Fcl_opti


(** @canonical Facile.Fcl_reify *)
module Fcl_reify = Facile__Fcl_reify


(** @canonical Facile.Fcl_setDomain *)
module Fcl_setDomain = Facile__Fcl_setDomain


(** @canonical Facile.Fcl_sorting *)
module Fcl_sorting = Facile__Fcl_sorting


(** @canonical Facile.Fcl_stak *)
module Fcl_stak = Facile__Fcl_stak


(** @canonical Facile.Fcl_var *)
module Fcl_var = Facile__Fcl_var

module FacterDB
  module Version
    STRING = '1.12.1'
  end
end

"""Holder of the fades version number."""

VERSION = (9, 0, 1)
__version__ = '.'.join([str(x) for x in VERSION])

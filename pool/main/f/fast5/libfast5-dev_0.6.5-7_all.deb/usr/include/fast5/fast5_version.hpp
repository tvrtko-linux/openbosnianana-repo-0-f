#ifndef __FAST5_VERSION_HPP
#define __FAST5_VERSION_HPP

namespace fast5
{

namespace
{

static char const * const version = "0.6.4";

}

}

#endif

#!/bin/sh

## a script to test the annotation scripts ann_*.pl
## acc_examples contains:
# P09488  -- new NCBI format
# sp|P09488 --more traditional format
# up|P09488|GSTM1_HUMAN
# SP:GSTM1_HUMAN P09488  ---ebi searches with accession
# SP:GSTM1_HUMAN -- ebi searches without accession
##

if [ ! "$1" = '' ]; then
   script_file=$1
else
   script_file=/usr/share/fasta3/scripts/ann_script_list
fi

if [ ! "$1" = '' ]; then
   ex_file=$1
else
   ex_file=/usr/share/fasta3/scripts/acc_examples
fi

while read -r script ; do
  while read -r acc_type ; do
      echo "${script}" "${acc_type}"
      "${script}" "${acc_type}"
  done < ${ex_file}
  echo '***DONE***'  "$script" "$(date)"
done < ${script_file}

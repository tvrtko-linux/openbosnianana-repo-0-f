import pyfastaq

def run(description):
    print(pyfastaq.__version__)

var annotated_dup =
[
    [ "eprosima", "namespaceeprosima.html", [
      [ "fastcdr", "namespaceeprosima_1_1fastcdr.html", [
        [ "exception", "namespaceeprosima_1_1fastcdr_1_1exception.html", [
          [ "BadParamException", "classeprosima_1_1fastcdr_1_1exception_1_1_bad_param_exception.html", "classeprosima_1_1fastcdr_1_1exception_1_1_bad_param_exception" ],
          [ "Exception", "classeprosima_1_1fastcdr_1_1exception_1_1_exception.html", "classeprosima_1_1fastcdr_1_1exception_1_1_exception" ],
          [ "NotEnoughMemoryException", "classeprosima_1_1fastcdr_1_1exception_1_1_not_enough_memory_exception.html", "classeprosima_1_1fastcdr_1_1exception_1_1_not_enough_memory_exception" ]
        ] ],
        [ "_FastBuffer_iterator", "classeprosima_1_1fastcdr_1_1___fast_buffer__iterator.html", "classeprosima_1_1fastcdr_1_1___fast_buffer__iterator" ],
        [ "Cdr", "classeprosima_1_1fastcdr_1_1_cdr.html", "classeprosima_1_1fastcdr_1_1_cdr" ],
        [ "FastBuffer", "classeprosima_1_1fastcdr_1_1_fast_buffer.html", "classeprosima_1_1fastcdr_1_1_fast_buffer" ],
        [ "FastCdr", "classeprosima_1_1fastcdr_1_1_fast_cdr.html", "classeprosima_1_1fastcdr_1_1_fast_cdr" ]
      ] ]
    ] ]
];
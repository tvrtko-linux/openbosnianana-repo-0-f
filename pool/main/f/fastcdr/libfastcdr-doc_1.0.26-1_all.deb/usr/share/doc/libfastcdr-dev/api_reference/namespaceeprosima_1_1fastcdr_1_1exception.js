var namespaceeprosima_1_1fastcdr_1_1exception =
[
    [ "BadParamException", "classeprosima_1_1fastcdr_1_1exception_1_1_bad_param_exception.html", "classeprosima_1_1fastcdr_1_1exception_1_1_bad_param_exception" ],
    [ "Exception", "classeprosima_1_1fastcdr_1_1exception_1_1_exception.html", "classeprosima_1_1fastcdr_1_1exception_1_1_exception" ],
    [ "NotEnoughMemoryException", "classeprosima_1_1fastcdr_1_1exception_1_1_not_enough_memory_exception.html", "classeprosima_1_1fastcdr_1_1exception_1_1_not_enough_memory_exception" ]
];
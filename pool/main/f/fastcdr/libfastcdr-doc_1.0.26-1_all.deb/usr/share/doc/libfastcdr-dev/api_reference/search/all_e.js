var searchData=
[
  ['raise_0',['raise',['../classeprosima_1_1fastcdr_1_1exception_1_1_bad_param_exception.html#a05fa0dbb9670de92ab00a301d3e676b5',1,'eprosima::fastcdr::exception::BadParamException::raise()'],['../classeprosima_1_1fastcdr_1_1exception_1_1_exception.html#a5bba35e213e4448a45ff7301fd5f488b',1,'eprosima::fastcdr::exception::Exception::raise()'],['../classeprosima_1_1fastcdr_1_1exception_1_1_not_enough_memory_exception.html#a550d4dd2d9f91cca41b9d5950a25d86d',1,'eprosima::fastcdr::exception::NotEnoughMemoryException::raise()']]],
  ['read_5fencapsulation_1',['read_encapsulation',['../classeprosima_1_1fastcdr_1_1_cdr.html#a5d858ba05edd25a5450de4f86f22f59d',1,'eprosima::fastcdr::Cdr']]],
  ['reserve_2',['reserve',['../classeprosima_1_1fastcdr_1_1_fast_buffer.html#a3087a0ee5510201d92eb5df277c04044',1,'eprosima::fastcdr::FastBuffer']]],
  ['reset_3',['reset',['../classeprosima_1_1fastcdr_1_1_cdr.html#ad20897c5c8bd47f5d4005989bead0e55',1,'eprosima::fastcdr::Cdr::reset()'],['../classeprosima_1_1fastcdr_1_1_fast_cdr.html#ad20897c5c8bd47f5d4005989bead0e55',1,'eprosima::fastcdr::FastCdr::reset()']]],
  ['resetalignment_4',['resetAlignment',['../classeprosima_1_1fastcdr_1_1_cdr.html#afc07e0ab8accea3f55c5b4a90416166f',1,'eprosima::fastcdr::Cdr']]],
  ['resize_5',['resize',['../classeprosima_1_1fastcdr_1_1_fast_buffer.html#a2dbec4c9bc4a78d870a88b8032187f8c',1,'eprosima::fastcdr::FastBuffer']]],
  ['rmemcopy_6',['rmemcopy',['../classeprosima_1_1fastcdr_1_1___fast_buffer__iterator.html#a8662ec618f26fa1527245d8a2d93ce3c',1,'eprosima::fastcdr::_FastBuffer_iterator']]]
];

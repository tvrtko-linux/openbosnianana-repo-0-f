var searchData=
[
  ['notenoughmemoryexception_0',['NotEnoughMemoryException',['../classeprosima_1_1fastcdr_1_1exception_1_1_not_enough_memory_exception.html#a725ff05883af92e83fa128315914090d',1,'eprosima::fastcdr::exception::NotEnoughMemoryException::NotEnoughMemoryException(const char *const &amp;message) noexcept'],['../classeprosima_1_1fastcdr_1_1exception_1_1_not_enough_memory_exception.html#a6a76452bda1a3bd4931a1988f77f8e25',1,'eprosima::fastcdr::exception::NotEnoughMemoryException::NotEnoughMemoryException(const NotEnoughMemoryException &amp;ex) noexcept']]]
];

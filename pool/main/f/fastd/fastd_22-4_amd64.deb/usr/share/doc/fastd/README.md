For more information, see the [documentation](https://fastd.readthedocs.io/) and
the [project wiki](https://github.com/NeoRaider/fastd/wiki).

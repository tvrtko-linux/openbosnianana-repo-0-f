/* $Id$
 *
 * Common base type declarations.
 *
 * Copyright (C) 2008-2009 FAUmachine Team <info@faumachine.org>.
 * This program is free software. You can redistribute it and/or modify it
 * under the terms of the GNU General Public License, either version 2 of
 * the License, or (at your option) any later version. See COPYING.
 */

#ifndef __BASE_TYPES_H_INCLUDED
#define __BASE_TYPES_H_INCLUDED

#include <stdint.h>

/** representation of universal integer inside the compiler/interpreter. */
typedef int64_t universal_integer;
/** representation of universal real inside the compiler/interpreter */
typedef double universal_real;

#endif /* __BASE_TYPES_H_INCLUDED */

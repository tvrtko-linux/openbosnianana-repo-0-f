## Fcitx-Sayura

Fcitx-Sayura is a Sinhala input method for Fcitx input method framework ported from IBus-Sayura.

### License

Fcitx-Sayura is a free software released under GPLv2.

### Install (From Source)

    $git clone git@github.com:yuyichao/fcitx-sayura.git

    $cd fcitx-sayura
    $mkdir -p build
    $cd build
    $cmake .. -DCMAKE_INSTALL_PREFIX=/usr
    $make
    #make install

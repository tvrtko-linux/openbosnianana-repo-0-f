/************************************************************************
 * This program is free software; you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation; either version 2 of the License, or    *
 * (at your option) any later version.                                  *
 *                                                                      *
 * This program is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
 * GNU General Public License for more details.                         *
 *                                                                      *
 * You should have received a copy of the GNU General Public License    *
 * along with this program; if not, write to the                        *
 * Free Software Foundation, Inc.,                                      *
 * 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA.             *
 ************************************************************************/

#ifndef __FCITX_MODULE_FCITX_CLASSIC_UI_API_H
#define __FCITX_MODULE_FCITX_CLASSIC_UI_API_H

#include <stdint.h>
#include <stdarg.h>
#include <fcitx-utils/utils.h>
#include <fcitx/instance.h>
#include <fcitx/addon.h>
#include <fcitx/module.h>
#include "classicuiinterface.h"

#ifdef __cplusplus
extern "C" {
#endif

DEFINE_GET_ADDON("fcitx-classic-ui", ClassicUI)

DEFINE_GET_AND_INVOKE_FUNC(ClassicUI, LoadImage, 0)
static inline cairo_surface_t*
FcitxClassicUILoadImage(FcitxInstance *instance, const char* _arg0, boolean* _arg1)
{
    void *result = NULL;
    FCITX_DEF_CAST_TO_PTR(arg0, const char*, _arg0);
    FCITX_DEF_CAST_TO_PTR(arg1, boolean*, _arg1);
    FCITX_DEF_MODULE_ARGS(args, arg0, arg1);
    result = FcitxClassicUIInvokeLoadImage(instance, args);
    FCITX_RETURN_FROM_PTR(cairo_surface_t*, result);
}

DEFINE_GET_AND_INVOKE_FUNC(ClassicUI, GetKeyboardFontColor, 1)
static inline FcitxConfigColor*
FcitxClassicUIGetKeyboardFontColor(FcitxInstance *instance)
{
    void *result = NULL;
    FCITX_DEF_MODULE_ARGS(args);
    result = FcitxClassicUIInvokeGetKeyboardFontColor(instance, args);
    FCITX_RETURN_FROM_PTR(FcitxConfigColor*, result);
}

DEFINE_GET_AND_INVOKE_FUNC(ClassicUI, GetFont, 2)
static inline char**
FcitxClassicUIGetFont(FcitxInstance *instance)
{
    void *result = NULL;
    FCITX_DEF_MODULE_ARGS(args);
    result = FcitxClassicUIInvokeGetFont(instance, args);
    FCITX_RETURN_FROM_PTR(char**, result);
}


#ifdef __cplusplus
}
#endif

#endif

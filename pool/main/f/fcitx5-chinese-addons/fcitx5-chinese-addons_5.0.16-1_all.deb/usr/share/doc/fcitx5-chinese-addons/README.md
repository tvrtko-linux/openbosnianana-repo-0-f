Chinese related addon for fcitx5
================================================
This provides pinyin and table input method support for fcitx5. Released
under LGPL-2.1+.

im/pinyin/emoji.txt is derived from Unicode CLDR with modification.

[![Jenkins Build Status](https://img.shields.io/jenkins/s/https/jenkins.fcitx-im.org/job/fcitx5-chinese-addons.svg)](https://jenkins.fcitx-im.org/job/fcitx5-chinese-addons/)

[![Coverity Scan Status](https://img.shields.io/coverity/scan/11995.svg)](https://scan.coverity.com/projects/fcitx-fcitx5-chinese-addons)

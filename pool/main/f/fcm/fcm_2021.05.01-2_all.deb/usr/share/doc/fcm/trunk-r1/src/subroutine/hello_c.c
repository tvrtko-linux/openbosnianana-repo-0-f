#include <stdio.h>

void hello_c_() {
    printf ("%s\n", "hello_c: Hello World!");
}

\ this example demonstrates the use of FCODE-TIME and FCODE-DATE

fcode-version2
    ." This program was tokenized on " 
    fcode-date type
    ." at "
    fcode-time type
fcode-end


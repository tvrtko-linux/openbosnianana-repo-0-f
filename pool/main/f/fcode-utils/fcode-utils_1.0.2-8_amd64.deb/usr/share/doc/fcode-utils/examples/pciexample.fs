hex
tokenizer[ 1011 0019 200 23 ]tokenizer ( -- vid did classid revision )

pci-revision \ this has to be called somewhere before pci-end

pci-header
    fcode-version2
	" pci driver sample." type
    fcode-end
pci-end

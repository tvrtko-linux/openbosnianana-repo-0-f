version1

dup dup 

1 case
1 of " foo" endof
3 of " bar" endof
4 of " blubb" endof
endcase
offset16
1 case
1 of " foo" endof
3 of " bar" endof
4 of " blubb" endof
endcase


fcode-end

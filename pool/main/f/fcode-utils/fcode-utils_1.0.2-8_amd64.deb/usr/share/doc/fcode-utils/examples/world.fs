fcode-version2
headers

external
\ main and only function 
: world
 " Hello World!"(0A)"(0A)Forth is alife."(0A)" type
 0 exit
 ;

headers

world

fcode-end

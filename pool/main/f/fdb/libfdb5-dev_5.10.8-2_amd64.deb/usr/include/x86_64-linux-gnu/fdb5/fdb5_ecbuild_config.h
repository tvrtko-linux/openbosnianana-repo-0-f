/*
 * (C) Copyright 2011- ECMWF.
 *
 * This software is licensed under the terms of the Apache Licence Version 2.0
 * which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
 * In applying this licence, ECMWF does not waive the privileges and immunities
 * granted to it by virtue of its status as an intergovernmental organisation nor
 * does it submit to any jurisdiction.
 */

#ifndef FDB5_ecbuild_config_h
#define FDB5_ecbuild_config_h

/* ecbuild info */

#ifndef ECBUILD_VERSION_STR
#define ECBUILD_VERSION_STR "3.7.0"
#endif
#ifndef ECBUILD_VERSION
#define ECBUILD_VERSION "3.7.0"
#endif
#ifndef ECBUILD_MACROS_DIR
#define ECBUILD_MACROS_DIR  "/usr/share/ecbuild/cmake"
#endif

/* config info */

#define FDB5_OS_NAME          "Linux-5.10.0-17-amd64"
#define FDB5_OS_BITS          64
#define FDB5_OS_BITS_STR      "64"
#define FDB5_OS_STR           "linux.64"
#define FDB5_OS_VERSION       "5.10.0-17-amd64"
#define FDB5_SYS_PROCESSOR    "x86_64"

#define FDB5_BUILD_TIMESTAMP  "20220901193316"
#define FDB5_BUILD_TYPE       "Release"

#define FDB5_C_COMPILER_ID      "GNU"
#define FDB5_C_COMPILER_VERSION "12.2.0"

#define FDB5_CXX_COMPILER_ID      "GNU"
#define FDB5_CXX_COMPILER_VERSION "12.2.0"

#define FDB5_C_COMPILER       "/usr/bin/cc"
#define FDB5_C_FLAGS          "-g -O2 -ffile-prefix-map=/build/fdb-Y6vInG/fdb-5.10.8=. -fstack-protector-strong -Wformat -Werror=format-security -Wdate-time -D_FORTIFY_SOURCE=2 -pipe -O3 -DNDEBUG"

#define FDB5_CXX_COMPILER     "/usr/bin/c++"
#define FDB5_CXX_FLAGS        "-g -O2 -ffile-prefix-map=/build/fdb-Y6vInG/fdb-5.10.8=. -fstack-protector-strong -Wformat -Werror=format-security -Wdate-time -D_FORTIFY_SOURCE=2 -pipe -Wall -Wextra -Wno-unused-parameter -Wno-unused-variable -Wno-sign-compare -O3 -DNDEBUG"

/* Needed for finding per package config files */

#define FDB5_INSTALL_DIR       "/usr"
#define FDB5_INSTALL_BIN_DIR   "/usr/bin"
#define FDB5_INSTALL_LIB_DIR   "/usr/lib/x86_64-linux-gnu"
#define FDB5_INSTALL_DATA_DIR  "/usr/share/fdb5"

#define FDB5_DEVELOPER_SRC_DIR "/build/fdb-Y6vInG/fdb-5.10.8"
#define FDB5_DEVELOPER_BIN_DIR "/build/fdb-Y6vInG/fdb-5.10.8/debian/build"

/* Fortran support */

#if 0

#define FDB5_Fortran_COMPILER_ID      ""
#define FDB5_Fortran_COMPILER_VERSION ""

#define FDB5_Fortran_COMPILER ""
#define FDB5_Fortran_FLAGS    ""

#endif

#endif /* FDB5_ecbuild_config_h */

REXML::Security.entity_expansion_text_limit *= 10

class Feed2Imap
  VERSION = "1.3.3"
end

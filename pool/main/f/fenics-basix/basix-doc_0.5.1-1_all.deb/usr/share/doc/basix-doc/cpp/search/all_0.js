var searchData=
[
  ['apply_5fdof_5ftransformation_0',['apply_dof_transformation',['../classbasix_1_1FiniteElement.html#a3ca0ec2ad9bf3d411eda9ddb726e7a36',1,'basix::FiniteElement']]],
  ['apply_5fdof_5ftransformation_5fto_5ftranspose_1',['apply_dof_transformation_to_transpose',['../classbasix_1_1FiniteElement.html#aab23dfeab963e78324ca1289415f0c9b',1,'basix::FiniteElement']]],
  ['apply_5finverse_5fdof_5ftransformation_2',['apply_inverse_dof_transformation',['../classbasix_1_1FiniteElement.html#ac90fbcbad98ed8ca7c9b4cb3893f03e2',1,'basix::FiniteElement']]],
  ['apply_5finverse_5fdof_5ftransformation_5fto_5ftranspose_3',['apply_inverse_dof_transformation_to_transpose',['../classbasix_1_1FiniteElement.html#a07ac360ea0da25bbdc031cf0823ead45',1,'basix::FiniteElement']]],
  ['apply_5finverse_5ftranspose_5fdof_5ftransformation_4',['apply_inverse_transpose_dof_transformation',['../classbasix_1_1FiniteElement.html#aecb16a633c466eb8f58393114ed5003b',1,'basix::FiniteElement']]],
  ['apply_5finverse_5ftranspose_5fdof_5ftransformation_5fto_5ftranspose_5',['apply_inverse_transpose_dof_transformation_to_transpose',['../classbasix_1_1FiniteElement.html#a5c8de993f0419ec709f6d429f67d621d',1,'basix::FiniteElement']]],
  ['apply_5fmatrix_6',['apply_matrix',['../namespacebasix_1_1precompute.html#a9b38abb4b995d955dab5c57bd72e526c',1,'basix::precompute']]],
  ['apply_5fmatrix_5fto_5ftranspose_7',['apply_matrix_to_transpose',['../namespacebasix_1_1precompute.html#a8cfeb72b7b259cee451e338edce21dc7',1,'basix::precompute']]],
  ['apply_5fpermutation_8',['apply_permutation',['../namespacebasix_1_1precompute.html#a548a5e395d94a3d43c6342ec1f27b707',1,'basix::precompute']]],
  ['apply_5fpermutation_5fto_5ftranspose_9',['apply_permutation_to_transpose',['../namespacebasix_1_1precompute.html#abb65fb47237e8554ce2531ea4c826946',1,'basix::precompute']]],
  ['apply_5ftranspose_5fdof_5ftransformation_10',['apply_transpose_dof_transformation',['../classbasix_1_1FiniteElement.html#a86eaf8c8ee4801cb444b525aca7849b8',1,'basix::FiniteElement']]],
  ['apply_5ftranspose_5fdof_5ftransformation_5fto_5ftranspose_11',['apply_transpose_dof_transformation_to_transpose',['../classbasix_1_1FiniteElement.html#aa1570da3553496d5c3c9056f16ff4858',1,'basix::FiniteElement']]]
];

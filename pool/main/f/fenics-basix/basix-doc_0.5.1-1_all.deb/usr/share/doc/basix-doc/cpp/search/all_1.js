var searchData=
[
  ['base_5ftransformations_0',['base_transformations',['../classbasix_1_1FiniteElement.html#ae13dc5c1e4e0980929e5a1d6c06aa6fc',1,'basix::FiniteElement']]],
  ['basix_1',['basix',['../namespacebasix.html',1,'']]],
  ['basix_20c_2b_2b_20documentation_2',['Basix C++ documentation',['../index.html',1,'']]],
  ['cell_3',['cell',['../namespacebasix_1_1cell.html',1,'basix']]],
  ['doftransforms_4',['doftransforms',['../namespacebasix_1_1doftransforms.html',1,'basix']]],
  ['element_5',['element',['../namespacebasix_1_1element.html',1,'basix']]],
  ['indexing_6',['indexing',['../namespacebasix_1_1indexing.html',1,'basix']]],
  ['lattice_7',['lattice',['../namespacebasix_1_1lattice.html',1,'basix']]],
  ['maps_8',['maps',['../namespacebasix_1_1maps.html',1,'basix']]],
  ['math_9',['math',['../namespacebasix_1_1math.html',1,'basix']]],
  ['moments_10',['moments',['../namespacebasix_1_1moments.html',1,'basix']]],
  ['polynomials_11',['polynomials',['../namespacebasix_1_1polynomials.html',1,'basix']]],
  ['polyset_12',['polyset',['../namespacebasix_1_1polyset.html',1,'basix']]],
  ['precompute_13',['precompute',['../namespacebasix_1_1precompute.html',1,'basix']]],
  ['quadrature_14',['quadrature',['../namespacebasix_1_1quadrature.html',1,'basix']]]
];

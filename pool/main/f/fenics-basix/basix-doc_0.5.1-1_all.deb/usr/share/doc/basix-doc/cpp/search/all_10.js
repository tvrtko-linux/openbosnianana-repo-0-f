var searchData=
[
  ['unpermute_5fdofs_0',['unpermute_dofs',['../classbasix_1_1FiniteElement.html#af627afd9aeee8237cf7552b4652c437a',1,'basix::FiniteElement']]]
];

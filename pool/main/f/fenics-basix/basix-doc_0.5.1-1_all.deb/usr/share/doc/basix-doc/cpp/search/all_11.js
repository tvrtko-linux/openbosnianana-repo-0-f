var searchData=
[
  ['value_5fshape_0',['value_shape',['../classbasix_1_1FiniteElement.html#a879496da4405a7273ba8045b1299f66b',1,'basix::FiniteElement']]],
  ['version_1',['version',['../namespacebasix.html#a828a385b5588edfe926899536339327e',1,'basix']]],
  ['volume_2',['volume',['../namespacebasix_1_1cell.html#ad9566a2726b1ba0fc4e38f19cd5e72f1',1,'basix::cell']]]
];

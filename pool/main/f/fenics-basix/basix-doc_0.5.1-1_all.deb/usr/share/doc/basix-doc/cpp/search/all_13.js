var searchData=
[
  ['x_0',['x',['../classbasix_1_1FiniteElement.html#a3962070c7d180f128d5814f25bedc12c',1,'basix::FiniteElement']]]
];

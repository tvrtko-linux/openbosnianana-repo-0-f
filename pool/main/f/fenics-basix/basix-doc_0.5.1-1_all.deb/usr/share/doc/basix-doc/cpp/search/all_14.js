var searchData=
[
  ['_7efiniteelement_0',['~FiniteElement',['../classbasix_1_1FiniteElement.html#a8d22cdbee8b090eaee4a441772c94a24',1,'basix::FiniteElement']]]
];

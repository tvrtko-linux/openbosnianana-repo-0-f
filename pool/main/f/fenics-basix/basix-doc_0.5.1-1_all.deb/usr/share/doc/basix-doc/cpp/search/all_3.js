var searchData=
[
  ['degree_0',['degree',['../classbasix_1_1FiniteElement.html#a6c9361216564eb22d899f1e961803392',1,'basix::FiniteElement']]],
  ['dim_1',['dim',['../classbasix_1_1FiniteElement.html#a99d38980ecdf3be924a093b4d2319479',1,'basix::FiniteElement::dim()'],['../namespacebasix_1_1polynomials.html#a7655bcb8ca301816e5b804d08a42089d',1,'basix::polynomials::dim()'],['../namespacebasix_1_1polyset.html#a7c80e7a30e5792671ae60c89844888b4',1,'basix::polyset::dim()']]],
  ['discontinuous_2',['discontinuous',['../classbasix_1_1FiniteElement.html#aebfcc4fdf0ecb92a2ec4f315d221de51',1,'basix::FiniteElement']]],
  ['dof_5ftransformations_5fare_5fidentity_3',['dof_transformations_are_identity',['../classbasix_1_1FiniteElement.html#ac5b7c1db36efbc036b8831e9c0ef7f1a',1,'basix::FiniteElement']]],
  ['dof_5ftransformations_5fare_5fpermutations_4',['dof_transformations_are_permutations',['../classbasix_1_1FiniteElement.html#a46dd5cfd393b08ca5e619c20c63c6ce5',1,'basix::FiniteElement']]],
  ['dot_5',['dot',['../namespacebasix_1_1math.html#a0ca80e007d29041b0f61ae67901d6b65',1,'basix::math']]],
  ['double_5fcontravariant_5fpiola_6',['double_contravariant_piola',['../namespacebasix_1_1maps.html#a75777c183fd61a0b2ae34561a6ba6dbf',1,'basix::maps']]],
  ['double_5fcovariant_5fpiola_7',['double_covariant_piola',['../namespacebasix_1_1maps.html#a89ab429b80f4f66cb849012ba0bd8d1c',1,'basix::maps']]],
  ['dpc_5fvariant_8',['dpc_variant',['../classbasix_1_1FiniteElement.html#aa06a0c9f071d90d6ea452f9afe7c109d',1,'basix::FiniteElement::dpc_variant()'],['../namespacebasix_1_1element.html#a8e196cd0bcdc926110b57d13fa278060',1,'basix::element::dpc_variant()']]],
  ['dual_5fmatrix_9',['dual_matrix',['../classbasix_1_1FiniteElement.html#a5c56bfac8f3a1e05fcc15e354868a3ae',1,'basix::FiniteElement']]]
];

var searchData=
[
  ['geometry_0',['geometry',['../namespacebasix_1_1cell.html#aa867c9676ca4c72b3fd6126e978fa8ad',1,'basix::cell']]],
  ['get_5fdefault_5frule_1',['get_default_rule',['../namespacebasix_1_1quadrature.html#ad2bbc628e9563db03fe73360b45a9fa9',1,'basix::quadrature']]],
  ['get_5fgl_5fpoints_2',['get_gl_points',['../namespacebasix_1_1quadrature.html#a930ddcda38629c6b58912d0e6dd44b01',1,'basix::quadrature']]],
  ['get_5fgll_5fpoints_3',['get_gll_points',['../namespacebasix_1_1quadrature.html#ab9e2e75e873eda405c4e14a85f909195',1,'basix::quadrature']]],
  ['get_5ftensor_5fproduct_5frepresentation_4',['get_tensor_product_representation',['../classbasix_1_1FiniteElement.html#a55b1344636dc8d83c5ca71a9682174c2',1,'basix::FiniteElement']]],
  ['gl_5',['gl',['../namespacebasix_1_1lattice.html#a1c2fc7e0f475c2fc256d726b6354ddf1ace1d5a2480e0f4a2d1c1c7968cc66c13',1,'basix::lattice']]],
  ['gl_5fplus_5fendpoints_6',['gl_plus_endpoints',['../namespacebasix_1_1lattice.html#a1c2fc7e0f475c2fc256d726b6354ddf1a47df9e373abb5620bddfb1f17904d08f',1,'basix::lattice']]],
  ['gll_7',['gll',['../namespacebasix_1_1lattice.html#a1c2fc7e0f475c2fc256d726b6354ddf1a10660da6ff265a52119ff6f7aec5233e',1,'basix::lattice']]]
];

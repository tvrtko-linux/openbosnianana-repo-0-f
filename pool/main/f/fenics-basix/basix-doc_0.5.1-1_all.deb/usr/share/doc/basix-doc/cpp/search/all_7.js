var searchData=
[
  ['has_5ftensor_5fproduct_5ffactorisation_0',['has_tensor_product_factorisation',['../classbasix_1_1FiniteElement.html#a8b653fd5ef231b610abae7fabe96d2d4',1,'basix::FiniteElement']]],
  ['highest_5fcomplete_5fdegree_1',['highest_complete_degree',['../classbasix_1_1FiniteElement.html#a1ec5b8fe7b275dc4ddf373974757a8de',1,'basix::FiniteElement']]],
  ['highest_5fdegree_2',['highest_degree',['../classbasix_1_1FiniteElement.html#a9ce5bdcac7c0acaafe9dcf45c74f1301',1,'basix::FiniteElement']]]
];

var searchData=
[
  ['m_0',['M',['../classbasix_1_1FiniteElement.html#ae48dbe8218a020276179532c55a65f5c',1,'basix::FiniteElement']]],
  ['make_5fdiscontinuous_1',['make_discontinuous',['../namespacebasix_1_1element.html#ac5e1688691bc5e1d5c9580ff0f29c738',1,'basix::element']]],
  ['make_5fdot_5fintegral_5fmoments_2',['make_dot_integral_moments',['../namespacebasix_1_1moments.html#af117c9d9c9ecf8835907baf38ad515bb',1,'basix::moments']]],
  ['make_5fintegral_5fmoments_3',['make_integral_moments',['../namespacebasix_1_1moments.html#a196b9db1b2c4ae65f7622d2b96ab37ac',1,'basix::moments']]],
  ['make_5fnormal_5fintegral_5fmoments_4',['make_normal_integral_moments',['../namespacebasix_1_1moments.html#a65c58363ad3e1cfb9362ff67331d41e0',1,'basix::moments']]],
  ['make_5fquadrature_5',['make_quadrature',['../namespacebasix_1_1quadrature.html#ae782722ffee5da11db37929ae1430b54',1,'basix::quadrature::make_quadrature(const quadrature::type rule, cell::type celltype, int m)'],['../namespacebasix_1_1quadrature.html#a1626e29f62d611667da33e898c76a1bb',1,'basix::quadrature::make_quadrature(cell::type celltype, int m)']]],
  ['make_5ftangent_5fintegral_5fmoments_6',['make_tangent_integral_moments',['../namespacebasix_1_1moments.html#a3f6d20149a80da2362ef10ee4703303c',1,'basix::moments']]],
  ['map_5ffn_7',['map_fn',['../classbasix_1_1FiniteElement.html#ae49d76b6d238bc14f5660d241b645e17',1,'basix::FiniteElement']]],
  ['map_5ftype_8',['map_type',['../classbasix_1_1FiniteElement.html#a4718b4f0231b8287288ca7fb28588977',1,'basix::FiniteElement']]]
];

var searchData=
[
  ['nderivs_0',['nderivs',['../namespacebasix_1_1polyset.html#a7a6e365944a944f005610968ffba2dfc',1,'basix::polyset']]],
  ['none_1',['none',['../namespacebasix_1_1lattice.html#a979fdd52a75d38b44c414f2d5fa13e97a334c4a4c42fdb79d7ebc3e73b517e6f8',1,'basix::lattice']]],
  ['num_5fsub_5fentities_2',['num_sub_entities',['../namespacebasix_1_1cell.html#a2006170ad82ba92eb4554d23c6954f36',1,'basix::cell']]]
];

var searchData=
[
  ['operator_3d_0',['operator=',['../classbasix_1_1FiniteElement.html#a2658eb05d09b176136e27db98ecff7e6',1,'basix::FiniteElement::operator=(const FiniteElement &amp;element)=default'],['../classbasix_1_1FiniteElement.html#a649479b17be0e99b07e543da02c5efca',1,'basix::FiniteElement::operator=(FiniteElement &amp;&amp;element)=default']]],
  ['operator_3d_3d_1',['operator==',['../classbasix_1_1FiniteElement.html#a369c8049d19ca40e09189498feeee720',1,'basix::FiniteElement']]],
  ['outer_2',['outer',['../namespacebasix_1_1math.html#af1899c0ff7a7694c951d52bb23a60cae',1,'basix::math']]]
];

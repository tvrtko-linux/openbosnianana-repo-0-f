var searchData=
[
  ['permute_5fdofs_0',['permute_dofs',['../classbasix_1_1FiniteElement.html#ab4a741f90888d4c9477ee8b7e2754513',1,'basix::FiniteElement']]],
  ['points_1',['points',['../classbasix_1_1FiniteElement.html#a6b6193aeef301ffaf1da69dea0b0f214',1,'basix::FiniteElement']]],
  ['prepare_5fmatrix_2',['prepare_matrix',['../namespacebasix_1_1precompute.html#acfe281d0244a36bc9db3fb9561edda25',1,'basix::precompute']]],
  ['prepare_5fpermutation_3',['prepare_permutation',['../namespacebasix_1_1precompute.html#ae71f1eef2833e390d85773b5018890c4',1,'basix::precompute']]],
  ['pull_5fback_4',['pull_back',['../classbasix_1_1FiniteElement.html#acba1339b521932d8872a74716d19f6e6',1,'basix::FiniteElement']]],
  ['push_5fforward_5',['push_forward',['../classbasix_1_1FiniteElement.html#a9f00687e930074dc5fa0b68c95f2fa64',1,'basix::FiniteElement']]]
];

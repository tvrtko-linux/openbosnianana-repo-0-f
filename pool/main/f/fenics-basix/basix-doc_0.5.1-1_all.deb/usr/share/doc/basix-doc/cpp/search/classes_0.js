var searchData=
[
  ['finiteelement_0',['FiniteElement',['../classbasix_1_1FiniteElement.html',1,'basix']]]
];

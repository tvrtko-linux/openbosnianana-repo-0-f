var searchData=
[
  ['dpc_5fvariant_0',['dpc_variant',['../namespacebasix_1_1element.html#a8e196cd0bcdc926110b57d13fa278060',1,'basix::element']]]
];

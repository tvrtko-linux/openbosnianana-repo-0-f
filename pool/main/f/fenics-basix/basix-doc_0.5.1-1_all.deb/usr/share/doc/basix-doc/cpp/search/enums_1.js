var searchData=
[
  ['family_0',['family',['../namespacebasix_1_1element.html#ada0a7daa08f1923682c927786b8ee007',1,'basix::element']]]
];

var searchData=
[
  ['lagrange_5fvariant_0',['lagrange_variant',['../namespacebasix_1_1element.html#a5d97cf44f3a72fad549a01ab3933b77f',1,'basix::element']]]
];

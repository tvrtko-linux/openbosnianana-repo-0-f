var searchData=
[
  ['simplex_5fmethod_0',['simplex_method',['../namespacebasix_1_1lattice.html#a979fdd52a75d38b44c414f2d5fa13e97',1,'basix::lattice']]]
];

var searchData=
[
  ['type_0',['type',['../namespacebasix_1_1cell.html#a6b9fb94bbe86f3e58ccd241e0e4f2069',1,'basix::cell::type()'],['../namespacebasix_1_1lattice.html#a1c2fc7e0f475c2fc256d726b6354ddf1',1,'basix::lattice::type()'],['../namespacebasix_1_1maps.html#acc2c2d4600630fca6e0967d25d0859e9',1,'basix::maps::type()'],['../namespacebasix_1_1polynomials.html#aa19d49de143e19fc4391ca0cbe35ed65',1,'basix::polynomials::type()'],['../namespacebasix_1_1quadrature.html#a82a315f32dc19f53e75accc21bae8365',1,'basix::quadrature::type()']]]
];

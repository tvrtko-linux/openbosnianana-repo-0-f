var searchData=
[
  ['centroid_0',['centroid',['../namespacebasix_1_1lattice.html#a979fdd52a75d38b44c414f2d5fa13e97a1401e7de3c16108d52d902869a7fb29f',1,'basix::lattice']]],
  ['chebyshev_1',['chebyshev',['../namespacebasix_1_1lattice.html#a1c2fc7e0f475c2fc256d726b6354ddf1a172e4ecb02a864e1e4aa51dcce9d8a47',1,'basix::lattice']]],
  ['chebyshev_5fplus_5fendpoints_2',['chebyshev_plus_endpoints',['../namespacebasix_1_1lattice.html#a1c2fc7e0f475c2fc256d726b6354ddf1a37624ebc4d1e784594a503bb7873b2e1',1,'basix::lattice']]]
];

var searchData=
[
  ['equispaced_0',['equispaced',['../namespacebasix_1_1lattice.html#a1c2fc7e0f475c2fc256d726b6354ddf1a0a12c1098d6c6dd51b73235a703c1a27',1,'basix::lattice']]]
];

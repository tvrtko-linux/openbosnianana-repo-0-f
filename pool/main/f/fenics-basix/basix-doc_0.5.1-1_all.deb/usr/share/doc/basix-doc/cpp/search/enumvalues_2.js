var searchData=
[
  ['gl_0',['gl',['../namespacebasix_1_1lattice.html#a1c2fc7e0f475c2fc256d726b6354ddf1ace1d5a2480e0f4a2d1c1c7968cc66c13',1,'basix::lattice']]],
  ['gl_5fplus_5fendpoints_1',['gl_plus_endpoints',['../namespacebasix_1_1lattice.html#a1c2fc7e0f475c2fc256d726b6354ddf1a47df9e373abb5620bddfb1f17904d08f',1,'basix::lattice']]],
  ['gll_2',['gll',['../namespacebasix_1_1lattice.html#a1c2fc7e0f475c2fc256d726b6354ddf1a10660da6ff265a52119ff6f7aec5233e',1,'basix::lattice']]]
];

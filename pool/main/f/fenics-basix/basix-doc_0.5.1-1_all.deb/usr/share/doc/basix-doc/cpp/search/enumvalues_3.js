var searchData=
[
  ['isaac_0',['isaac',['../namespacebasix_1_1lattice.html#a979fdd52a75d38b44c414f2d5fa13e97a84311803c723cad9fcda143909218a89',1,'basix::lattice']]]
];

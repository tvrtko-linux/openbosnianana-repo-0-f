var searchData=
[
  ['none_0',['none',['../namespacebasix_1_1lattice.html#a979fdd52a75d38b44c414f2d5fa13e97a334c4a4c42fdb79d7ebc3e73b517e6f8',1,'basix::lattice']]]
];

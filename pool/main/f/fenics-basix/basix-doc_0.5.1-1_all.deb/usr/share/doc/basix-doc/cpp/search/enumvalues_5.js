var searchData=
[
  ['warp_0',['warp',['../namespacebasix_1_1lattice.html#a979fdd52a75d38b44c414f2d5fa13e97aa6caec68da0de01267cb9a3540543136',1,'basix::lattice']]]
];

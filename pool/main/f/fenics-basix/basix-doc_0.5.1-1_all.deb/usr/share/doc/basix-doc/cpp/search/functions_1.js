var searchData=
[
  ['base_5ftransformations_0',['base_transformations',['../classbasix_1_1FiniteElement.html#ae13dc5c1e4e0980929e5a1d6c06aa6fc',1,'basix::FiniteElement']]]
];

var searchData=
[
  ['wcoeffs_0',['wcoeffs',['../classbasix_1_1FiniteElement.html#a9295f480358ceb856cf9e61b045b751c',1,'basix::FiniteElement']]]
];

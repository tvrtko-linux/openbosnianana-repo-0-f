var searchData=
[
  ['eigh_0',['eigh',['../namespacebasix_1_1math.html#a06382fe468de26fc8cc4c1af86ef4bc0',1,'basix::math']]],
  ['entity_5fclosure_5fdofs_1',['entity_closure_dofs',['../classbasix_1_1FiniteElement.html#a69d5b83865b234bc08f3675a5a6ccb0d',1,'basix::FiniteElement']]],
  ['entity_5fdofs_2',['entity_dofs',['../classbasix_1_1FiniteElement.html#a572bc37d493eb6a9f2183b76f14cec20',1,'basix::FiniteElement']]],
  ['entity_5ftransformations_3',['entity_transformations',['../classbasix_1_1FiniteElement.html#a056bdf81657a17a2de95947b9ad12a36',1,'basix::FiniteElement']]],
  ['eye_4',['eye',['../namespacebasix_1_1math.html#ae909d6d05ecf7c924f0cbfdf05d220b7',1,'basix::math']]]
];

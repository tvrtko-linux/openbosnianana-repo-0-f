var searchData=
[
  ['idx_0',['idx',['../namespacebasix_1_1indexing.html#aee955bbd20bb422bca33e4654b7d7e46',1,'basix::indexing::idx(int p)'],['../namespacebasix_1_1indexing.html#a28712f2b2fea490471919a415164e37e',1,'basix::indexing::idx(int p, int q)'],['../namespacebasix_1_1indexing.html#a6cd7c5bb3dad69d721cbdbbc3d5b20c7',1,'basix::indexing::idx(int p, int q, int r)']]],
  ['interpolation_5fis_5fidentity_1',['interpolation_is_identity',['../classbasix_1_1FiniteElement.html#adacde51327c7da17f2da16f3ace3f3a2',1,'basix::FiniteElement']]],
  ['interpolation_5fmatrix_2',['interpolation_matrix',['../classbasix_1_1FiniteElement.html#ad7a9930d71935bcf4b559a433d53e2d0',1,'basix::FiniteElement']]],
  ['interpolation_5fnderivs_3',['interpolation_nderivs',['../classbasix_1_1FiniteElement.html#a5e08d22679a1f54e8bf128909b535879',1,'basix::FiniteElement']]],
  ['is_5fsingular_4',['is_singular',['../namespacebasix_1_1math.html#aa8d291ebdc364ea419c351980efc0732',1,'basix::math']]]
];

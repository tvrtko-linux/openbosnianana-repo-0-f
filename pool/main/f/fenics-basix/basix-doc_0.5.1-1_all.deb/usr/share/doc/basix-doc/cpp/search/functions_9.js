var searchData=
[
  ['l2_5fpiola_0',['l2_piola',['../namespacebasix_1_1maps.html#a13f1ce96ede39475013645566d1ee15e',1,'basix::maps']]],
  ['lagrange_5fvariant_1',['lagrange_variant',['../classbasix_1_1FiniteElement.html#a277701eea33cb029f3b0b3b3be2b4de2',1,'basix::FiniteElement']]]
];

var searchData=
[
  ['nderivs_0',['nderivs',['../namespacebasix_1_1polyset.html#a7a6e365944a944f005610968ffba2dfc',1,'basix::polyset']]],
  ['num_5fsub_5fentities_1',['num_sub_entities',['../namespacebasix_1_1cell.html#a2006170ad82ba92eb4554d23c6954f36',1,'basix::cell']]]
];

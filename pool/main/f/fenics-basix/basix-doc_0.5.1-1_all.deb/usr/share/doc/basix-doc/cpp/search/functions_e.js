var searchData=
[
  ['solve_0',['solve',['../namespacebasix_1_1math.html#a79d4e77c0512b20e7e1571b3634d878a',1,'basix::math']]],
  ['sub_5fentity_5fconnectivity_1',['sub_entity_connectivity',['../namespacebasix_1_1cell.html#a98b2aebaf61e060096e7bb0f7d131a29',1,'basix::cell']]],
  ['sub_5fentity_5fgeometry_2',['sub_entity_geometry',['../namespacebasix_1_1cell.html#a4ab908741cff4faa01dfc4ec40492c3c',1,'basix::cell']]],
  ['sub_5fentity_5ftype_3',['sub_entity_type',['../namespacebasix_1_1cell.html#a4969dbd91b9a39f335d687ec0e502624',1,'basix::cell']]],
  ['subentity_5ftypes_4',['subentity_types',['../namespacebasix_1_1cell.html#a5dd8a1c86ba94d84a5a01cef49e0948c',1,'basix::cell']]]
];

var searchData=
[
  ['basix_0',['basix',['../namespacebasix.html',1,'']]],
  ['cell_1',['cell',['../namespacebasix_1_1cell.html',1,'basix']]],
  ['doftransforms_2',['doftransforms',['../namespacebasix_1_1doftransforms.html',1,'basix']]],
  ['element_3',['element',['../namespacebasix_1_1element.html',1,'basix']]],
  ['indexing_4',['indexing',['../namespacebasix_1_1indexing.html',1,'basix']]],
  ['lattice_5',['lattice',['../namespacebasix_1_1lattice.html',1,'basix']]],
  ['maps_6',['maps',['../namespacebasix_1_1maps.html',1,'basix']]],
  ['math_7',['math',['../namespacebasix_1_1math.html',1,'basix']]],
  ['moments_8',['moments',['../namespacebasix_1_1moments.html',1,'basix']]],
  ['polynomials_9',['polynomials',['../namespacebasix_1_1polynomials.html',1,'basix']]],
  ['polyset_10',['polyset',['../namespacebasix_1_1polyset.html',1,'basix']]],
  ['precompute_11',['precompute',['../namespacebasix_1_1precompute.html',1,'basix']]],
  ['quadrature_12',['quadrature',['../namespacebasix_1_1quadrature.html',1,'basix']]]
];

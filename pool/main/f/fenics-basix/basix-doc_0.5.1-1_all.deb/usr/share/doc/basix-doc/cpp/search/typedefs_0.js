var searchData=
[
  ['cmdspan2_5ft_0',['cmdspan2_t',['../namespacebasix_1_1element.html#ab3e5f850cf3b008e85e42ecbe5c1fa92',1,'basix::element']]],
  ['cmdspan4_5ft_1',['cmdspan4_t',['../namespacebasix_1_1element.html#aa5c3b33286a52a98a26d4cd888357da6',1,'basix::element']]]
];

var searchData=
[
  ['u_0',['U',['../dc/de4/classdolfinx_1_1io_1_1ADIOS2Writer.html#adaaaa7a484339df79650c7a78510f62f',1,'dolfinx::io::ADIOS2Writer']]],
  ['unpermute_5fdofs_1',['unpermute_dofs',['../d9/d35/classdolfinx_1_1fem_1_1CoordinateElement.html#aedf17006185eabfc2da59f5a5375bda6',1,'dolfinx::fem::CoordinateElement::unpermute_dofs()'],['../df/d27/classdolfinx_1_1fem_1_1FiniteElement.html#a48d57d0cf067fa94b0aba2d16f6d001d',1,'dolfinx::fem::FiniteElement::unpermute_dofs()']]],
  ['update_5flogical_5fedgefunction_2',['update_logical_edgefunction',['../d9/dd6/namespacedolfinx_1_1refinement.html#a8f408853de0c4089662f870b0be10e5e',1,'dolfinx::refinement']]],
  ['utils_2eh_3',['utils.h',['../d9/dc0/fem_2utils_8h.html',1,'']]]
];

var searchData=
[
  ['x_0',['X',['../d2/db9/classdolfinx_1_1fem_1_1Expression.html#aa48d13e4bc92f15345cd4f42f8ebae3e',1,'dolfinx::fem::Expression']]],
  ['x_1',['x',['../d7/d76/classdolfinx_1_1fem_1_1Function.html#acb314edbd326192e9528426af6c60837',1,'dolfinx::fem::Function::x() const'],['../d7/d76/classdolfinx_1_1fem_1_1Function.html#ac5217d65bd860038efcdfbfa673b82ca',1,'dolfinx::fem::Function::x()'],['../d8/dfb/classdolfinx_1_1mesh_1_1Geometry.html#a88a236b2bc5548db3c81377c6831c3cf',1,'dolfinx::mesh::Geometry::x() const'],['../d8/dfb/classdolfinx_1_1mesh_1_1Geometry.html#a6658c09df06e8eeff31cd9c7dfaaedcb',1,'dolfinx::mesh::Geometry::x()']]],
  ['xdmffile_2',['XDMFFile',['../d9/d9e/classdolfinx_1_1io_1_1XDMFFile.html',1,'XDMFFile'],['../d9/d9e/classdolfinx_1_1io_1_1XDMFFile.html#a166209f57ac2c3dbab59907f35003566',1,'dolfinx::io::XDMFFile::XDMFFile()']]]
];

var searchData=
[
  ['adios2writer_0',['ADIOS2Writer',['../dc/de4/classdolfinx_1_1io_1_1ADIOS2Writer.html',1,'dolfinx::io']]],
  ['adjacencylist_1',['AdjacencyList',['../df/d84/classdolfinx_1_1graph_1_1AdjacencyList.html',1,'dolfinx::graph']]]
];

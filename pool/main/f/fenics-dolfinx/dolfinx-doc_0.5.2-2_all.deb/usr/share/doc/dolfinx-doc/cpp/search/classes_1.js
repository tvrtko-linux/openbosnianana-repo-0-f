var searchData=
[
  ['boundingboxtree_0',['BoundingBoxTree',['../d1/ddc/classdolfinx_1_1geometry_1_1BoundingBoxTree.html',1,'dolfinx::geometry']]]
];

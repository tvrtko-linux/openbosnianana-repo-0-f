var searchData=
[
  ['dependent_5ffalse_0',['dependent_false',['../df/ddb/structdolfinx_1_1MPI_1_1dependent__false.html',1,'dolfinx::MPI']]],
  ['dirichletbc_1',['DirichletBC',['../db/d9f/classdolfinx_1_1fem_1_1DirichletBC.html',1,'dolfinx::fem']]],
  ['dofmap_2',['DofMap',['../d2/d3c/classdolfinx_1_1fem_1_1DofMap.html',1,'dolfinx::fem']]]
];

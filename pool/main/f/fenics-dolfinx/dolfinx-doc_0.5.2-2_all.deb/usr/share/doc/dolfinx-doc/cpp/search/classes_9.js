var searchData=
[
  ['krylovsolver_0',['KrylovSolver',['../d2/dde/classdolfinx_1_1la_1_1petsc_1_1KrylovSolver.html',1,'dolfinx::la::petsc']]]
];

var searchData=
[
  ['newtonsolver_0',['NewtonSolver',['../d7/d9a/classdolfinx_1_1nls_1_1petsc_1_1NewtonSolver.html',1,'dolfinx::nls::petsc']]]
];

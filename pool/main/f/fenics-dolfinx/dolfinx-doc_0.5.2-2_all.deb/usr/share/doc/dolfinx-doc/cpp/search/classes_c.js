var searchData=
[
  ['operator_0',['Operator',['../db/d4b/classdolfinx_1_1la_1_1petsc_1_1Operator.html',1,'dolfinx::la::petsc']]]
];

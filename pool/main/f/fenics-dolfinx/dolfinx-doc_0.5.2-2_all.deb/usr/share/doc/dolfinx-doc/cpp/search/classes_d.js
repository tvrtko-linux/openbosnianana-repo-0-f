var searchData=
[
  ['scatterer_0',['Scatterer',['../de/d43/classdolfinx_1_1common_1_1Scatterer.html',1,'dolfinx::common']]],
  ['slepceigensolver_1',['SLEPcEigenSolver',['../d0/d6d/classdolfinx_1_1la_1_1SLEPcEigenSolver.html',1,'dolfinx::la']]],
  ['sparsitypattern_2',['SparsityPattern',['../d5/df9/classdolfinx_1_1la_1_1SparsityPattern.html',1,'dolfinx::la']]]
];

var searchData=
[
  ['assemblytype_0',['AssemblyType',['../de/d18/classdolfinx_1_1la_1_1petsc_1_1Matrix.html#ae78d8b657a736791820b89c5483bdb88',1,'dolfinx::la::petsc::Matrix']]]
];

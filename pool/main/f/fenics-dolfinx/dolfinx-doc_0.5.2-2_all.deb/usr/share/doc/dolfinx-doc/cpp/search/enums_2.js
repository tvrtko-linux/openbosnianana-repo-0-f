var searchData=
[
  ['diagonaltype_0',['DiagonalType',['../dd/d7d/namespacedolfinx_1_1mesh.html#a5fb0494804cb9b4baeeff5b9027a8dfd',1,'dolfinx::mesh']]]
];

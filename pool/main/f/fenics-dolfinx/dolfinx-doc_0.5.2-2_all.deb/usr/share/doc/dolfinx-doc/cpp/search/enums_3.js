var searchData=
[
  ['encoding_0',['Encoding',['../d9/d9e/classdolfinx_1_1io_1_1XDMFFile.html#afb0564821f132bfe74508af8349a0faa',1,'dolfinx::io::XDMFFile']]]
];

var searchData=
[
  ['ghostmode_0',['GhostMode',['../dd/d7d/namespacedolfinx_1_1mesh.html#a38d109d131f3180f43267fcf9fe9c4c4',1,'dolfinx::mesh']]]
];

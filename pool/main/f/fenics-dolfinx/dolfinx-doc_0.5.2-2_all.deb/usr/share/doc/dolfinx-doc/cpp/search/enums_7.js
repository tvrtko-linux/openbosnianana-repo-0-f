var searchData=
[
  ['reduction_0',['Reduction',['../db/d97/classdolfinx_1_1Table.html#a536aaa97b969b0acd31603703012bbff',1,'dolfinx::Table']]],
  ['refinementoptions_1',['RefinementOptions',['../df/dfe/namespacedolfinx_1_1refinement_1_1plaza.html#a0630bc7b4a33916d468340fc053dea88',1,'dolfinx::refinement::plaza']]]
];

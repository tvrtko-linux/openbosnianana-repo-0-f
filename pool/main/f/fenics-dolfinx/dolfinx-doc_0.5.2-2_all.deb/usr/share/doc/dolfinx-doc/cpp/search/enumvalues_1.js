var searchData=
[
  ['exterior_5ffacet_0',['exterior_facet',['../d8/dbf/namespacedolfinx_1_1fem.html#ac00c421a0f3a4e925538ebc7a05f2962ab8e8c532206d46c91883de739daed213',1,'dolfinx::fem']]]
];

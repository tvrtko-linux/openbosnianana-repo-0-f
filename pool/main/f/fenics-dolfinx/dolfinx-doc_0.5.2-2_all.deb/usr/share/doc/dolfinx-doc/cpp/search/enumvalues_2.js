var searchData=
[
  ['interior_5ffacet_0',['interior_facet',['../d8/dbf/namespacedolfinx_1_1fem.html#ac00c421a0f3a4e925538ebc7a05f2962a55142ac49a379bbdd12dd3fe2e8bcbdf',1,'dolfinx::fem']]]
];

var searchData=
[
  ['vertex_0',['vertex',['../d8/dbf/namespacedolfinx_1_1fem.html#ac00c421a0f3a4e925538ebc7a05f2962a2b5bc093b09bd81f51de433bde9d202a',1,'dolfinx::fem']]]
];

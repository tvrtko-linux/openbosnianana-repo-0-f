var searchData=
[
  ['kernel_0',['kernel',['../df/d02/classdolfinx_1_1fem_1_1Form.html#a6532f14fc7aff179bad82efbdc19e7d6',1,'dolfinx::fem::Form']]],
  ['krylov_5fiterations_1',['krylov_iterations',['../d7/d9a/classdolfinx_1_1nls_1_1petsc_1_1NewtonSolver.html#a0faedd324e1fa18636a1dc488be3467a',1,'dolfinx::nls::petsc::NewtonSolver']]],
  ['krylovsolver_2',['KrylovSolver',['../d2/dde/classdolfinx_1_1la_1_1petsc_1_1KrylovSolver.html#abf3581e19446b66c3ac0ad8218270ca4',1,'dolfinx::la::petsc::KrylovSolver::KrylovSolver(MPI_Comm comm)'],['../d2/dde/classdolfinx_1_1la_1_1petsc_1_1KrylovSolver.html#a81ea3356f5cb498329ebc63a2128507c',1,'dolfinx::la::petsc::KrylovSolver::KrylovSolver(KSP ksp, bool inc_ref_count)'],['../d2/dde/classdolfinx_1_1la_1_1petsc_1_1KrylovSolver.html#a42862338613d723e9df5002ae3fa0c37',1,'dolfinx::la::petsc::KrylovSolver::KrylovSolver(KrylovSolver &amp;&amp;solver)']]],
  ['ksp_3',['ksp',['../d2/dde/classdolfinx_1_1la_1_1petsc_1_1KrylovSolver.html#a600c040db0ff046efd440961526b0f6f',1,'dolfinx::la::petsc::KrylovSolver']]]
];

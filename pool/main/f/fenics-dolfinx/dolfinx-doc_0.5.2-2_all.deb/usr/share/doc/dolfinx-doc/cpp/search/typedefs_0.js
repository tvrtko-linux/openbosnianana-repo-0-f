var searchData=
[
  ['allocator_5ftype_0',['allocator_type',['../dc/dfa/classdolfinx_1_1la_1_1MatrixCSR.html#a1b9340a5b56dce81fa182aee8c64e363',1,'dolfinx::la::MatrixCSR::allocator_type()'],['../d2/d0b/classdolfinx_1_1la_1_1Vector.html#a1b9340a5b56dce81fa182aee8c64e363',1,'dolfinx::la::Vector::allocator_type()']]]
];

var searchData=
[
  ['partition_5ffn_0',['partition_fn',['../d9/d69/namespacedolfinx_1_1graph.html#a762d023211be837448a62f229e1bc4a8',1,'dolfinx::graph']]]
];

var searchData=
[
  ['scalar_5ftype_0',['scalar_type',['../d2/db9/classdolfinx_1_1fem_1_1Expression.html#ae879758ab49a8cd7f2302f96a9e9dd0c',1,'dolfinx::fem::Expression::scalar_type()'],['../df/d02/classdolfinx_1_1fem_1_1Form.html#ae879758ab49a8cd7f2302f96a9e9dd0c',1,'dolfinx::fem::Form::scalar_type()']]]
];

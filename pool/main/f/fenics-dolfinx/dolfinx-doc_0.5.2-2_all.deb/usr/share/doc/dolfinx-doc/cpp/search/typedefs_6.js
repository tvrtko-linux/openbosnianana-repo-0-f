var searchData=
[
  ['u_0',['U',['../dc/de4/classdolfinx_1_1io_1_1ADIOS2Writer.html#adaaaa7a484339df79650c7a78510f62f',1,'dolfinx::io::ADIOS2Writer']]]
];

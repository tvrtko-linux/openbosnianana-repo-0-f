var searchData=
[
  ['convergence_5fcriterion_0',['convergence_criterion',['../d7/d9a/classdolfinx_1_1nls_1_1petsc_1_1NewtonSolver.html#a8ea088fa97a10dfa359ad00ec6fadabb',1,'dolfinx::nls::petsc::NewtonSolver']]]
];

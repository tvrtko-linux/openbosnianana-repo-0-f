var searchData=
[
  ['default_5fencoding_0',['default_encoding',['../d9/d9e/classdolfinx_1_1io_1_1XDMFFile.html#a3f3dc6c8f679e3d3e73926f3d162cfc6',1,'dolfinx::io::XDMFFile']]]
];

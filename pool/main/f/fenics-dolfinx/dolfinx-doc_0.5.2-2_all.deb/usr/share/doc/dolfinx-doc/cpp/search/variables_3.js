var searchData=
[
  ['error_5fon_5fnonconvergence_0',['error_on_nonconvergence',['../d7/d9a/classdolfinx_1_1nls_1_1petsc_1_1NewtonSolver.html#ad1cb4f57b6eed3ac4ddf36e6d5c18346',1,'dolfinx::nls::petsc::NewtonSolver']]]
];

var searchData=
[
  ['max_5fit_0',['max_it',['../d7/d9a/classdolfinx_1_1nls_1_1petsc_1_1NewtonSolver.html#af0156dc2ee0edcde49c6441d56705291',1,'dolfinx::nls::petsc::NewtonSolver']]]
];

var searchData=
[
  ['relaxation_5fparameter_0',['relaxation_parameter',['../d7/d9a/classdolfinx_1_1nls_1_1petsc_1_1NewtonSolver.html#a0ee867c8196bc0edfe2283064defa1f8',1,'dolfinx::nls::petsc::NewtonSolver']]],
  ['report_1',['report',['../d7/d9a/classdolfinx_1_1nls_1_1petsc_1_1NewtonSolver.html#aaef1fcd30c74cb739b8e9f9c31a44b93',1,'dolfinx::nls::petsc::NewtonSolver']]],
  ['rtol_2',['rtol',['../d7/d9a/classdolfinx_1_1nls_1_1petsc_1_1NewtonSolver.html#a4587afeee8941ba7c208b3690a3eeaa7',1,'dolfinx::nls::petsc::NewtonSolver']]]
];

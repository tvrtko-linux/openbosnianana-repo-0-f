var searchData=
[
  ['shape_0',['shape',['../d6/d06/classdolfinx_1_1fem_1_1Constant.html#ae9c7e7e2afb8b3b1fc20432d727feb42',1,'dolfinx::fem::Constant']]]
];

#pragma once

#define DOLFINX_VERSION_RELEASE 
#define DOLFINX_VERSION_MAJOR   0
#define DOLFINX_VERSION_MINOR   5
#define DOLFINX_VERSION_MICRO   
#define DOLFINX_VERSION_STRING  "0.5.2"
#define DOLFINX_VERSION_GIT     "debian_1:0.5.2-2+b1"
#define UFCX_SIGNATURE          "da4f06cb7b24fd71359bedaeafbca801c698ea33"

#ifndef FXDLL_VERSION

/*
 * Identificador de la version soportada de plugins
 * Debera cambiar cada vez que se modifiquen las cabeceras
 * usadas para los plugins.
 */

#define FXDLL_VERSION 0x0001

#endif

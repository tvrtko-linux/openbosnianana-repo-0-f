Common utilities used in all FEST modules.

To prevent this project to include everything even the kitchen sink, the scope of this project is to contain utilities needed in two or more FEST modules. 

For more details please visit [FEST's home page](http://fest.easytesting.org).
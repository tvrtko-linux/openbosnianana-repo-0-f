# Matinfo

`matinfo` lists the content of a compiled material as output by `matc`. This tool is meant to be
used for debug purpose only.

## Usage

```
$ matinfo [options] <material file>
```

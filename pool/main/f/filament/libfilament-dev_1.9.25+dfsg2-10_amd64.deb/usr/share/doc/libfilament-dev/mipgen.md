# mipgen

`mipgen` generates mipmaps for an image down to the 1x1 level.

## Usage

```
$ mipgen [options] <input_file> <output_pattern>
```

Run `mipgen --help` for more information about available options.

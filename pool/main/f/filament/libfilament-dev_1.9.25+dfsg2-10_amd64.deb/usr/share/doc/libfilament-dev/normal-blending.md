# Normal Blending

`normal_blending` is a simple tool that can be used to combine two normal maps in a single texture.

This tool uses the blending technique called _Reoriented Normal Mapping_ which offers mathematically
correct results (as opposed to common techniques such as linear or overlay blending).

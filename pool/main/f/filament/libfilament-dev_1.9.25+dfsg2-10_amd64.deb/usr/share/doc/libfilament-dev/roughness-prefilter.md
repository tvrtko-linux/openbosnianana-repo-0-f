# Roughness Prefilter

`roughness_prefilter` is a simple tool that can be used to generate a pre-filtered roughness map
from a normal map. The input roughness can either be a constant or a roughness map. The output can
be used to reduce shading aliasing.

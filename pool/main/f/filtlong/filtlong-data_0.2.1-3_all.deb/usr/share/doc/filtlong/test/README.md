# Filtlong tests

Filtlong comes with a few automated tests to help with development and spotting bugs. Unlike Filtlong itself, which is written in C++, the tests are written in Python3, so you'll need that installed to run them.

To run the tests, execute this command from Filtlong's root directory:
```
python3 -m unittest
```

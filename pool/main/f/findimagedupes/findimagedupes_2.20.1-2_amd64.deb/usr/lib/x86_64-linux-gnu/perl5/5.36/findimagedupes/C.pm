#! /usr/bin/perl
package findimagedupes::C;

use Inline
	C => 'DATA',
	NAME => 'findimagedupes::C',
	VERSION => '0.01',
	CCFLAGSEX => ' -D_FORTIFY_SOURCE=2'
		. ' -fstack-protector-strong'
		. ' -Wformat'
		. ' -Werror=format-security',
	LDDLFLAGS => '-shared -Wl,-z,relro -Wl,-z,now',
;

our $VERSION = '0.01';
1;

__DATA__

__C__

/* efficient bit-comparison */

#include <stdint.h>
#include <string.h>

#define LOOKUP_SIZE 65536
#define FP_CHUNKS 16

typedef uint16_t FP[FP_CHUNKS];

void diffbits (SV* oldfiles, SV* newfiles, unsigned int threshold, unsigned limit) {
	FP *the_data, *a, *b;
	unsigned int lookup[LOOKUP_SIZE];
	unsigned int i, j, k, m, bits, old, new;
	HV *oldhash;
	HE *oldhash_entry;
	HV *newhash;
	HE *newhash_entry;
	unsigned int numkeys = 0;
	SV *sv_val;
	Inline_Stack_Vars;

	if ((threshold<0) || (threshold>256)) {
		croak("ridiculous threshold specified");
	}

	/* pack fingerprints into C array */
	/* partly lifted from Inline::C-Cookbook */

	if (! SvROK(newfiles)) {
		croak("newfiles is not a reference");
	}
	newhash = (HV *)SvRV(newfiles);
	new = hv_iterinit(newhash);

	if (! SvROK(oldfiles)) {
		croak("oldfiles is not a reference");
	}
	oldhash = (HV *)SvRV(oldfiles);
	old = hv_iterinit(oldhash);

	numkeys = new+old;
	if (numkeys<2) {
		/* minor optimization: return without doing anything */
		/* malloc(0) could be bad... */
		Inline_Stack_Void;
	}
	the_data = (FP *)malloc(numkeys*sizeof(FP));
	if (!the_data) {
		croak("malloc failed");
	}

	for (i = 0; i<new; i++) {
		newhash_entry = hv_iternext(newhash);
		sv_val = hv_iterval(newhash, newhash_entry);
		memcpy(the_data+i, SvPV(sv_val, PL_na), sizeof(FP));
	}
	for (i = new; i<numkeys; i++) {
		oldhash_entry = hv_iternext(oldhash);
		sv_val = hv_iterval(oldhash, oldhash_entry);
		memcpy(the_data+i, SvPV(sv_val, PL_na), sizeof(FP));
	}

	/* initialise lookup table */
	/* cf. https://graphics.stanford.edu/~seander/bithacks.html */
	for (i=0; i<LOOKUP_SIZE; i++) {
		lookup[i] = lookup[i/2] + (i&1);
	}

	/* look for matches */
	Inline_Stack_Reset;
	for (a=the_data, i=0, m=(limit>0 ? new : numkeys-1); i<m; a++, i++) {
		for (b=a+1, j=i+1; j<numkeys; b++, j++) {
			for (bits=0, k=0; k<FP_CHUNKS; k++) {
				bits += lookup[(*a)[k]^(*b)[k]];
				if (bits > threshold) goto abortmatch;
			}
			/* if (bits <= threshold) */ {
				Inline_Stack_Push(sv_2mortal(newSViv(i)));
				Inline_Stack_Push(sv_2mortal(newSViv(j)));
				Inline_Stack_Push(sv_2mortal(newSViv(bits)));
			}
abortmatch:;
		}
	}
	Inline_Stack_Done;

	/* clean up */
	free(the_data);
}


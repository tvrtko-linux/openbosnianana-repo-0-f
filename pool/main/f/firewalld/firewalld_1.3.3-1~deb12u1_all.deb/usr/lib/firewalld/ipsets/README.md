Location for built-in ipsets

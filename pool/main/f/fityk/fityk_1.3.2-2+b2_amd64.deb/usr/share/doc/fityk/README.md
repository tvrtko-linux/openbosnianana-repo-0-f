
Website:      http://fityk.nieto.pl  
Wiki:         https://github.com/wojdyr/fityk/wiki  
Code:         https://github.com/wojdyr/fityk  
Manual:       http://fityk.readthedocs.org/en/latest/  
Discussions:  http://groups.google.com/group/fityk-users/  
Building from Source: Read the INSTALL file
[![GitHub CI](https://github.com/wojdyr/fityk/workflows/CI/badge.svg)](https://github.com/wojdyr/fityk/actions)
[![AppVeyor CI](https://ci.appveyor.com/api/projects/status/q2vmyiya4vril835?svg=true)](https://ci.appveyor.com/project/wojdyr/fityk)  
Citing in academic papers: [J. Appl. Cryst. 43, 1126 (2010)](http://dx.doi.org/10.1107/S0021889810030499) ([reprint](http://wojdyr.github.io/fityk-JAC-10-reprint.pdf))  
Contact: wojdyr@gmail.com  

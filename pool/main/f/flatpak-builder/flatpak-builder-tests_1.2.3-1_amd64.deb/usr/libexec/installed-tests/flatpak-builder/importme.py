import sys
foo = "first   "

#!/usr/bin/python2

import importme
print importme.foo

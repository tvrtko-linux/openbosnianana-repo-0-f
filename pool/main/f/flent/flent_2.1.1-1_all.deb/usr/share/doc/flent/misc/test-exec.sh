#!/bin/sh

echo "{\"args\": \"$@\"}"

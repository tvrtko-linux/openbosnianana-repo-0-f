# -*- coding: UTF-8 -*-

import os
VERSION='2.1.1'
DATA_DIR=os.path.dirname(__file__)

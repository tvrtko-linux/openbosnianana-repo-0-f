"""For tests"""

__version__ = '0.1'

#!/bin/sh
echo "Example data file"

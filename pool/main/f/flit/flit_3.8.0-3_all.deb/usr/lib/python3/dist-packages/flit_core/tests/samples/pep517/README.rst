This contains a nön-ascii character

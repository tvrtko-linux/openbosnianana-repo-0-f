module Fontcustom
  class Error < StandardError
  end
end

# Beteckna

Beteckna is a geometrical and humanist sans serif typeface family.

License: Beteckna font family is released under the [GNU GPL v.3 with Embedded Font Exception](/LICENCE)

Designers: See [AUTHORS](/AUTHORS) for full attribution.

Version: 0.5

The Beteckna font family is meant to conform to the [Open Type Specification](http://www.microsoft.com/typography/otspec/)

The current version of Beteckna is edited with [Birdfont](https://github.com/johanmattssonm/birdfont). Future versions will be incorporated into the [UFO font specification](https://github.com/unified-font-object/ufo-spec).

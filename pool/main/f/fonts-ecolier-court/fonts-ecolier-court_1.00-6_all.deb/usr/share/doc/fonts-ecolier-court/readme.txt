

Ecolier lignes court is released under the OFL (Open Font Licence): http://scripts.sil.org/OFL
Please read the use conditions of the fonts detailed above.

The author provides these fonts to everyone free of charge and disclaims any responsability concerning possible problems.

These fonts have been created by Jean-Marie Douteau
e-mail: douteau.ecolier@orange.fr
website: http://perso.orange.fr/jm.douteau/


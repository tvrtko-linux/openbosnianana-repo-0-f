==Konatu Description==

This is TrueTypeFont where BitmapFont is embedded. 
It was confirmed to use it with Haiku R1/Alpha1(VMware), Windows2000, and Ubuntu 9.10

***Do'nt install Zeta!
***This file might be generated an error. 

===licence===

This work is licensed under a 
Creative Commons Attribution-Share Alike 3.0 License.

	http://creativecommons.org/licenses/by-sa/3.0/

===Author===

BY:MASUDA mitiya

Mail:mitimasu@gmail.com

Please use Japanese or easy peacy English.


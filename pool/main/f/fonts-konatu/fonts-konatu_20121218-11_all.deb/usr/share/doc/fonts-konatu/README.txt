==Konatu Description==

This is TrueTypeFont where BitmapFont is embedded. 
It was confirmed to use it with Windows XP, and Ubuntu 12.10

===licence===

This work is licensed under The MIT License.

* http://opensource.org/licenses/mit-license.php

===Author===

BY:MASUDA mitiya

Mail:mitimasu@gmail.com

Please use Japanese or easy peacy English.


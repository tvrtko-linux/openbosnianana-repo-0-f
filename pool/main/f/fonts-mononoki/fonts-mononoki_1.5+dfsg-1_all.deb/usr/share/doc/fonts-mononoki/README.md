# mononoki

> A font for programming and code review.

For a closer look [http://madmalik.github.io/mononoki/](http://madmalik.github.io/mononoki/).

## Installation

[Download mononoki.zip](https://github.com/madmalik/mononoki/releases/download/1.5/mononoki.zip) and unpack it.
* [macOS](http://support.apple.com/kb/HT2509)
* [Windows](http://windows.microsoft.com/en-us/windows-vista/install-or-uninstall-fonts)
* Linux/Unix - distro dependent, I hope you know how to install it

## Old version

If you prefer the predecessor to mononoki, please look into the branch monoOne.


## Credit

Box drawing characters created with [box drawing](https://github.com/adobe-type-tools/box-drawing).

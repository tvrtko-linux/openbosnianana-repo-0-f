Sawarabi Mincho

o  What is this?

Sawarabi Mincho is a Japanese Mincho font, which is released under the 
Creative Commons Attribution License, or SIL Open Font License.
See the following URL for the details of the license.

Creative Commons Attribution License:
http://creativecommons.org/licenses/by/3.0/

SIL Open Font License:
sil-open-font-license.txt

o  Attention

This font has already main hiragana, katakana, ruled lines, and 
so on, but has not yet had enough kanji glyphs, being under developing.
It has 3,481 kanji at this version.
Please open 'README_ja.txt' file with the UTF-8 encoding, if you want 
to see the list of all kanji it has.

This font is provided without warranty.

Copyright (C) 2008-2022 mshio <mshio@users.osdn.me>

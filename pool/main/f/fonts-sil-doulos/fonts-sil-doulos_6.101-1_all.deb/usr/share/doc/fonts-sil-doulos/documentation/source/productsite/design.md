
Doulos is very similar to Times/Times New Roman, but only has a single face - regular. It is intended for use alongside other Times-like fonts where a range of styles (italic, bold) is not needed.
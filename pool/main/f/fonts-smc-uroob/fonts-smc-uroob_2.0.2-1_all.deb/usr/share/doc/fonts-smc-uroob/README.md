Uroob Font
============

Uroob is Malayalam heading style font designed by Hussain K H. 
This bold weight font was released in 2015 and Latin glyphs were added in 2016. 

Uroob is a thick ornamental font. Its basic orthography is rectangular but carries
rounded corners of Malayalam characters. Though it is an even thickness font, 
joining of round and straight stems normally forms a thin part. It is a vertical
tall font giving more space in x-height so that parts over x-height seem squeezed.
Uroob is best suited for headings, titles, book covers, posters and signboards.

The font is named after famous Malayalam writer P. C. Kuttikrishnan, pen named 'Uroob'.

The font is maintained by Swathanthra Malayalam Computing project. 
Source code is available at https://gitlab.com/smc/uroob/

Building from source
--------------------
1. Install fontforge and python-fontforge
2. Install the python libraries required for build script:
    ```
    pip install -r tools/requirements.txt
    ```
3. Build the ttf, woff, woff2 files: 
   ``` 
   make
   ```

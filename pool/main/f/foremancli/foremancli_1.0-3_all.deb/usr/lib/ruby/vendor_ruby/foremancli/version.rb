module Foremancli
  VERSION = '1.0'
end

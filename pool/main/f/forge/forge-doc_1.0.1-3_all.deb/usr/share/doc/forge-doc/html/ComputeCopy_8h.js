var ComputeCopy_8h =
[
    [ "GfxHandle", "structGfxHandle.htm", "structGfxHandle" ],
    [ "ComputeResourceHandle", "ComputeCopy_8h.htm#a160b6c9800d06caf50586d67439790c3", null ],
    [ "BufferType", "ComputeCopy_8h.htm#adf8e136713c0691010d2bec6ba63e9cf", [
      [ "FORGE_IMAGE_BUFFER", "ComputeCopy_8h.htm#adf8e136713c0691010d2bec6ba63e9cfa11ea1ee65fc38c2123afa0a33c6ef04a", null ],
      [ "FORGE_VERTEX_BUFFER", "ComputeCopy_8h.htm#adf8e136713c0691010d2bec6ba63e9cfa08d078104055dceac893e4a14c153b2c", null ]
    ] ]
];
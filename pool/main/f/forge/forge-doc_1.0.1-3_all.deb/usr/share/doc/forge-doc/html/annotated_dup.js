var annotated_dup =
[
    [ "forge", "namespaceforge.htm", "namespaceforge" ],
    [ "GfxHandle", "structGfxHandle.htm", "structGfxHandle" ]
];
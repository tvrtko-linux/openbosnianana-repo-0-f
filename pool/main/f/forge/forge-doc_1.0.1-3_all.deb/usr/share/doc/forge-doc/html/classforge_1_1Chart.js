var classforge_1_1Chart =
[
    [ "Chart", "classforge_1_1Chart.htm#aa665bf2a69011d8db5504950a0ac7878", null ],
    [ "Chart", "classforge_1_1Chart.htm#a8edf027a67adbdde0028ac322d2d455d", null ],
    [ "~Chart", "classforge_1_1Chart.htm#a24fab297f9af605060aefb10e94a542d", null ],
    [ "add", "classforge_1_1Chart.htm#ad49651b0aebb65bfb4b1cf870ac367b1", null ],
    [ "add", "classforge_1_1Chart.htm#aba83d8a3481f96419e4ff770670da9d3", null ],
    [ "add", "classforge_1_1Chart.htm#af94280e037e51ab24ad7b1a9d5741264", null ],
    [ "add", "classforge_1_1Chart.htm#ad3f132f6e8fe7f237533011db1e9da56", null ],
    [ "add", "classforge_1_1Chart.htm#aabdefeac2a7e59ee824afef4e566bbb6", null ],
    [ "get", "classforge_1_1Chart.htm#a1978336a92b9e23c7a14ff1369a37090", null ],
    [ "getAxesLimits", "classforge_1_1Chart.htm#a4ac38acc4eb7459307170d05b47274fc", null ],
    [ "getChartType", "classforge_1_1Chart.htm#a8dc4c3c502a6db3f7734375f6852ed4b", null ],
    [ "histogram", "classforge_1_1Chart.htm#ad020b4df2f68ddfb4057ab1cc9dc41bc", null ],
    [ "image", "classforge_1_1Chart.htm#a7d0a34f959a67a33ba7f4a1b79b96fc3", null ],
    [ "plot", "classforge_1_1Chart.htm#a8e7caa3cd226b829bd4c1ca5a938bec6", null ],
    [ "render", "classforge_1_1Chart.htm#a0f520c8aebac2f0f891ce8fa727e1714", null ],
    [ "setAxesLabelFormat", "classforge_1_1Chart.htm#ac06e37addad02ef99b9b65c32cf993a0", null ],
    [ "setAxesLimits", "classforge_1_1Chart.htm#a88e6960288c03aecbc6d47ef92cbec02", null ],
    [ "setAxesTitles", "classforge_1_1Chart.htm#aa0fe71ff5413a2e8a4bcfc64538ef074", null ],
    [ "setLegendPosition", "classforge_1_1Chart.htm#a8c03b892a0a3c1a989e2c9b4d12f4367", null ],
    [ "surface", "classforge_1_1Chart.htm#a360551677aab492011650112d6b31ea7", null ],
    [ "vectorField", "classforge_1_1Chart.htm#a56d43faa368874b2e13f718546882e32", null ]
];
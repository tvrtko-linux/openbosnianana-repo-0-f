var classforge_1_1Histogram =
[
    [ "Histogram", "classforge_1_1Histogram.htm#a8a56250d1471d85d6e82cb13fafd1cf3", null ],
    [ "Histogram", "classforge_1_1Histogram.htm#aeec8b1d47263e8f26db87d0bd45f9686", null ],
    [ "Histogram", "classforge_1_1Histogram.htm#a84deb9f140c2baaa6eedb459bfbe07e1", null ],
    [ "~Histogram", "classforge_1_1Histogram.htm#a4768fd035ecd222e12769c6a21cce831", null ],
    [ "alphas", "classforge_1_1Histogram.htm#acce1129878218e8da269bc1149a184ac", null ],
    [ "alphasSize", "classforge_1_1Histogram.htm#ac248736a53c7fc199a24e5e30f3197fa", null ],
    [ "colors", "classforge_1_1Histogram.htm#ad3170bfaae56062c20b4b840e89b6c18", null ],
    [ "colorsSize", "classforge_1_1Histogram.htm#ac5e4d2faad5a4b77e3c2233d680e65c1", null ],
    [ "get", "classforge_1_1Histogram.htm#a273675d18ae742844459c709246207d5", null ],
    [ "setColor", "classforge_1_1Histogram.htm#a4223cf126e117578e63c8fd29059c78d", null ],
    [ "setColor", "classforge_1_1Histogram.htm#a271035707dc73d59303b43c0654167a2", null ],
    [ "setLegend", "classforge_1_1Histogram.htm#a841659a9bd508773863b33efaa4e2cf5", null ],
    [ "vertices", "classforge_1_1Histogram.htm#a0489cb338aeeb4a051689d4d08f6aa52", null ],
    [ "verticesSize", "classforge_1_1Histogram.htm#a45c0b02d22ed759e90b7819883c57821", null ]
];
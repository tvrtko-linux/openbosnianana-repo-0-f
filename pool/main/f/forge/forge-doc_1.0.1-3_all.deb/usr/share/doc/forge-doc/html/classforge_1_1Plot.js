var classforge_1_1Plot =
[
    [ "Plot", "classforge_1_1Plot.htm#a855b1938229806de2e775e4e3c62edd6", null ],
    [ "Plot", "classforge_1_1Plot.htm#ab690b2f1e09affaaceab9074d25ca872", null ],
    [ "Plot", "classforge_1_1Plot.htm#a104801283317e9f6fdc9d36894c516dc", null ],
    [ "~Plot", "classforge_1_1Plot.htm#a96133e108822b91cbf71421900205b28", null ],
    [ "alphas", "classforge_1_1Plot.htm#acce1129878218e8da269bc1149a184ac", null ],
    [ "alphasSize", "classforge_1_1Plot.htm#ac248736a53c7fc199a24e5e30f3197fa", null ],
    [ "colors", "classforge_1_1Plot.htm#ad3170bfaae56062c20b4b840e89b6c18", null ],
    [ "colorsSize", "classforge_1_1Plot.htm#ac5e4d2faad5a4b77e3c2233d680e65c1", null ],
    [ "get", "classforge_1_1Plot.htm#af6a9390251ce2cb84fdf99361772681f", null ],
    [ "radii", "classforge_1_1Plot.htm#ac2ce0483608ce361ab0c452feb042c74", null ],
    [ "radiiSize", "classforge_1_1Plot.htm#a93db2b82d83c1dd4ca1bd21fca9c86a7", null ],
    [ "setColor", "classforge_1_1Plot.htm#a8e14e7f09511e4042e65b78e5b0ba0fc", null ],
    [ "setColor", "classforge_1_1Plot.htm#a271035707dc73d59303b43c0654167a2", null ],
    [ "setLegend", "classforge_1_1Plot.htm#a841659a9bd508773863b33efaa4e2cf5", null ],
    [ "setMarkerSize", "classforge_1_1Plot.htm#a8e8008385b6d430b4defe1d5082dbd7d", null ],
    [ "vertices", "classforge_1_1Plot.htm#a0489cb338aeeb4a051689d4d08f6aa52", null ],
    [ "verticesSize", "classforge_1_1Plot.htm#a45c0b02d22ed759e90b7819883c57821", null ]
];
var classforge_1_1Surface =
[
    [ "Surface", "classforge_1_1Surface.htm#a9df677ac558dc952ef2f26d6d66a1a0f", null ],
    [ "Surface", "classforge_1_1Surface.htm#abdaddd9b2ceccef52ba64157efdfa8bf", null ],
    [ "Surface", "classforge_1_1Surface.htm#ae3211208a46580fec223900f3d502f47", null ],
    [ "~Surface", "classforge_1_1Surface.htm#a999478ecc7b13b0a9254a24356079d54", null ],
    [ "alphas", "classforge_1_1Surface.htm#acce1129878218e8da269bc1149a184ac", null ],
    [ "alphasSize", "classforge_1_1Surface.htm#ac248736a53c7fc199a24e5e30f3197fa", null ],
    [ "colors", "classforge_1_1Surface.htm#ad3170bfaae56062c20b4b840e89b6c18", null ],
    [ "colorsSize", "classforge_1_1Surface.htm#ac5e4d2faad5a4b77e3c2233d680e65c1", null ],
    [ "get", "classforge_1_1Surface.htm#af8136bd6905286c4776a8974a38d5d7b", null ],
    [ "setColor", "classforge_1_1Surface.htm#a8e14e7f09511e4042e65b78e5b0ba0fc", null ],
    [ "setColor", "classforge_1_1Surface.htm#a271035707dc73d59303b43c0654167a2", null ],
    [ "setLegend", "classforge_1_1Surface.htm#a841659a9bd508773863b33efaa4e2cf5", null ],
    [ "vertices", "classforge_1_1Surface.htm#a0489cb338aeeb4a051689d4d08f6aa52", null ],
    [ "verticesSize", "classforge_1_1Surface.htm#a45c0b02d22ed759e90b7819883c57821", null ]
];
var exception_8h =
[
    [ "Error", "classforge_1_1Error.htm", "classforge_1_1Error" ],
    [ "fg_err_to_string", "exception_8h.htm#ae497e3d834f5865d14fcef6743af5c18", null ],
    [ "fg_get_last_error", "exception_8h.htm#ab03b5979fac90230276f4d5f0c3cc013", null ]
];
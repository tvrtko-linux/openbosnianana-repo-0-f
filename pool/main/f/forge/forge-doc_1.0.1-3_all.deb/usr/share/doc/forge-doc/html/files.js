var files =
[
    [ "ComputeCopy.h", "ComputeCopy_8h.htm", "ComputeCopy_8h" ],
    [ "chart.h", "chart_8h.htm", "chart_8h" ],
    [ "defines.h", "defines_8h.htm", "defines_8h" ],
    [ "exception.h", "exception_8h.htm", "exception_8h" ],
    [ "font.h", "font_8h.htm", "font_8h" ],
    [ "histogram.h", "histogram_8h.htm", "histogram_8h" ],
    [ "image.h", "image_8h.htm", "image_8h" ],
    [ "plot.h", "plot_8h.htm", "plot_8h" ],
    [ "surface.h", "surface_8h.htm", "surface_8h" ],
    [ "util.h", "util_8h.htm", "util_8h" ],
    [ "vector_field.h", "vector__field_8h.htm", "vector__field_8h" ],
    [ "version.h", "version_8h.htm", "version_8h" ],
    [ "window.h", "window_8h.htm", "window_8h" ],
    [ "forge.h", "forge_8h.htm", null ]
];
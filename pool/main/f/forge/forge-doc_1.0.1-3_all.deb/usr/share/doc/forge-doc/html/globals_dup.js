var globals_dup =
[
    [ "b", "globals.htm", null ],
    [ "c", "globals_c.htm", null ],
    [ "f", "globals_f.htm", null ]
];
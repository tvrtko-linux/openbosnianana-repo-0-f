var group__c__api__functions =
[
    [ "Chart", "group__chart__functions.htm", "group__chart__functions" ],
    [ "Font", "group__font__functions.htm", "group__font__functions" ],
    [ "Histogram", "group__hist__functions.htm", "group__hist__functions" ],
    [ "Image", "group__image__functions.htm", "group__image__functions" ],
    [ "Plot", "group__plot__functions.htm", "group__plot__functions" ],
    [ "Surface", "group__surf__functions.htm", "group__surf__functions" ],
    [ "Utility & Helper Functions", "group__util__functions.htm", "group__util__functions" ],
    [ "Vector Field", "group__vfield__functions.htm", "group__vfield__functions" ],
    [ "Window", "group__win__functions.htm", "group__win__functions" ]
];
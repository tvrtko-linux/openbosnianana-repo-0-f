var group__font__functions =
[
    [ "fg_create_font", "group__font__functions.htm#gab4fd5c0e224cde413fbd33d1f506cbaf", null ],
    [ "fg_load_font_file", "group__font__functions.htm#ga7c71ca2ce6c6f0d74d4600e0562d4f9d", null ],
    [ "fg_load_system_font", "group__font__functions.htm#gaebe6b54dcfcb33571e002081f5a21a7f", null ],
    [ "fg_release_font", "group__font__functions.htm#gaaf85efc3e423c25d0e5a9363c8c43ec2", null ],
    [ "fg_retain_font", "group__font__functions.htm#ga796b1afd5d03c91043e485d4b24d7f00", null ]
];
var hierarchy =
[
    [ "Chart", "classforge_1_1Chart.htm", null ],
    [ "exception", null, [
      [ "Error", "classforge_1_1Error.htm", null ]
    ] ],
    [ "Font", "classforge_1_1Font.htm", null ],
    [ "GfxHandle", "structGfxHandle.htm", null ],
    [ "Histogram", "classforge_1_1Histogram.htm", null ],
    [ "Image", "classforge_1_1Image.htm", null ],
    [ "Plot", "classforge_1_1Plot.htm", null ],
    [ "Surface", "classforge_1_1Surface.htm", null ],
    [ "VectorField", "classforge_1_1VectorField.htm", null ],
    [ "Window", "classforge_1_1Window.htm", null ]
];
var histogram_8h =
[
    [ "Histogram", "classforge_1_1Histogram.htm", "classforge_1_1Histogram" ],
    [ "fg_create_histogram", "group__hist__functions.htm#ga65b8bf8fa60c2e2569e977427bfb492c", null ],
    [ "fg_get_histogram_alpha_buffer", "group__hist__functions.htm#ga5574b44a0a8ac799053dc8e41e0b8b68", null ],
    [ "fg_get_histogram_alpha_buffer_size", "group__hist__functions.htm#ga5a3d84d84918a9a8ed8236679cc5ebb0", null ],
    [ "fg_get_histogram_color_buffer", "group__hist__functions.htm#gaafc0bcccf09af5fbfea7fb22463b4de7", null ],
    [ "fg_get_histogram_color_buffer_size", "group__hist__functions.htm#gaa0676cabd971bc0ac80f03d9963017e5", null ],
    [ "fg_get_histogram_vertex_buffer", "group__hist__functions.htm#ga01b34f7a7de5d66840d19d6da3a37066", null ],
    [ "fg_get_histogram_vertex_buffer_size", "group__hist__functions.htm#ga4dcc07c2f609ad05bbe65cd9ec161deb", null ],
    [ "fg_release_histogram", "group__hist__functions.htm#ga36fa7fcf28c673a6d6e74058129fc5d8", null ],
    [ "fg_retain_histogram", "group__hist__functions.htm#ga6c0d84b42b53ede77d6820cfe8d18154", null ],
    [ "fg_set_histogram_color", "group__hist__functions.htm#ga967a76cfbf41cc46a43bd9349e11a8b9", null ],
    [ "fg_set_histogram_legend", "group__hist__functions.htm#ga0dce330773da81cd714e7b113930fbd1", null ]
];
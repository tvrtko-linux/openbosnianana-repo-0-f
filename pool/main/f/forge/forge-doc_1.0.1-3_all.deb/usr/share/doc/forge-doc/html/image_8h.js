var image_8h =
[
    [ "Image", "classforge_1_1Image.htm", "classforge_1_1Image" ],
    [ "fg_create_image", "group__image__functions.htm#ga96a5b5f6f8033a04f8ff3b8d35a6ef6d", null ],
    [ "fg_get_image_height", "group__image__functions.htm#ga92f5e5990d268ce8bfa1ed5aed00e69a", null ],
    [ "fg_get_image_pixelformat", "group__image__functions.htm#gadf1bdb5e66281e49cd6b98ef2d4dfd58", null ],
    [ "fg_get_image_size", "group__image__functions.htm#gacd9454d2c848440fa15b0f0a0af9f400", null ],
    [ "fg_get_image_type", "group__image__functions.htm#gab5a02f3bceaec6b2be6bfe8ab615d7db", null ],
    [ "fg_get_image_width", "group__image__functions.htm#gaa901be2f89f1e38afda3838aba6acc48", null ],
    [ "fg_get_pixel_buffer", "group__image__functions.htm#gada4d0d584fdf9f362cba1d01b61eb6b9", null ],
    [ "fg_release_image", "group__image__functions.htm#ga6a625ac14f9dae788042841d02de73e1", null ],
    [ "fg_render_image", "group__image__functions.htm#gaa192b1595f21acb3fc140223344049ab", null ],
    [ "fg_retain_image", "group__image__functions.htm#ga2370e2fab2884223061b093413b63979", null ],
    [ "fg_set_image_alpha", "group__image__functions.htm#ga7cc53bb04467bf6adac606ae36daebfe", null ],
    [ "fg_set_image_aspect_ratio", "group__image__functions.htm#ga38ee70f9a95d3eee9ad7b6d722db4cc4", null ]
];
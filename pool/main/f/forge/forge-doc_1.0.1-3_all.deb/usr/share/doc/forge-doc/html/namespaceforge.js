var namespaceforge =
[
    [ "Chart", "classforge_1_1Chart.htm", "classforge_1_1Chart" ],
    [ "Error", "classforge_1_1Error.htm", "classforge_1_1Error" ],
    [ "Font", "classforge_1_1Font.htm", "classforge_1_1Font" ],
    [ "Histogram", "classforge_1_1Histogram.htm", "classforge_1_1Histogram" ],
    [ "Image", "classforge_1_1Image.htm", "classforge_1_1Image" ],
    [ "Plot", "classforge_1_1Plot.htm", "classforge_1_1Plot" ],
    [ "Surface", "classforge_1_1Surface.htm", "classforge_1_1Surface" ],
    [ "VectorField", "classforge_1_1VectorField.htm", "classforge_1_1VectorField" ],
    [ "Window", "classforge_1_1Window.htm", "classforge_1_1Window" ]
];
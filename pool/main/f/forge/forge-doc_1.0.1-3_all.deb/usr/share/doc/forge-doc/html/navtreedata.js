var NAVTREE =
[
  [ "Forge", "index.htm", [
    [ "Overview", "index.htm", null ],
    [ "Modules", "modules.htm", "modules" ],
    [ "Namespaces", null, [
      [ "Namespace List", "namespaces.htm", "namespaces" ],
      [ "Namespace Members", "namespacemembers.htm", [
        [ "All", "namespacemembers.htm", null ],
        [ "Functions", "namespacemembers_func.htm", null ],
        [ "Typedefs", "namespacemembers_type.htm", null ],
        [ "Enumerations", "namespacemembers_enum.htm", null ],
        [ "Enumerator", "namespacemembers_eval.htm", null ]
      ] ]
    ] ],
    [ "Data Structures", "annotated.htm", [
      [ "Data Structures", "annotated.htm", "annotated_dup" ],
      [ "Data Structure Index", "classes.htm", null ],
      [ "Class Hierarchy", "hierarchy.htm", "hierarchy" ],
      [ "Data Fields", "functions.htm", [
        [ "All", "functions.htm", null ],
        [ "Functions", "functions_func.htm", null ],
        [ "Variables", "functions_vars.htm", null ],
        [ "Related Functions", "functions_rela.htm", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.htm", "files" ],
      [ "Globals", "globals.htm", [
        [ "All", "globals.htm", "globals_dup" ],
        [ "Functions", "globals_func.htm", null ],
        [ "Typedefs", "globals_type.htm", null ],
        [ "Enumerations", "globals_enum.htm", null ],
        [ "Enumerator", "globals_eval.htm", null ],
        [ "Macros", "globals_defs.htm", null ]
      ] ]
    ] ],
    [ "Examples", "examples.htm", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"ComputeCopy_8h.htm",
"defines_8h.htm#acfe99d230e216901bd782cc580e4e815",
"group__win__functions.htm#gab01edfd22cb1e2df0d269666be4f642c"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';
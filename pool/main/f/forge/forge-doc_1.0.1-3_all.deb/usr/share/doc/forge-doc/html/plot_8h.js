var plot_8h =
[
    [ "Plot", "classforge_1_1Plot.htm", "classforge_1_1Plot" ],
    [ "fg_create_plot", "group__plot__functions.htm#gaffa0499614393c088aebb973e28b95b2", null ],
    [ "fg_get_plot_alpha_buffer", "group__plot__functions.htm#ga76c63f4c418c340c23bc454557f6adf9", null ],
    [ "fg_get_plot_alpha_buffer_size", "group__plot__functions.htm#gad3ff811f6821ce8cecc9cecfb6968851", null ],
    [ "fg_get_plot_color_buffer", "group__plot__functions.htm#gaf885a4b0109bb50cad30d3e127a4c458", null ],
    [ "fg_get_plot_color_buffer_size", "group__plot__functions.htm#ga4dd623edea423baf0060e54bc8122a52", null ],
    [ "fg_get_plot_radii_buffer", "group__plot__functions.htm#gac0a0420d8b02bb04978b33d6a3dba4f2", null ],
    [ "fg_get_plot_radii_buffer_size", "group__plot__functions.htm#ga10d0d43c29ac5a4db19886d661eb29a2", null ],
    [ "fg_get_plot_vertex_buffer", "group__plot__functions.htm#ga65255ddeb22d8dc44c4ddfad3dcc001c", null ],
    [ "fg_get_plot_vertex_buffer_size", "group__plot__functions.htm#ga87d05602861e08b58f6d49f29feaeea4", null ],
    [ "fg_release_plot", "group__plot__functions.htm#gafe78b77407cd80f8b546bd59f5e2633c", null ],
    [ "fg_retain_plot", "group__plot__functions.htm#gaa03c29b5d6b80ce2e2a1ac138fca8c3a", null ],
    [ "fg_set_plot_color", "group__plot__functions.htm#ga0a884cc68f6d1d829d3657d689f5a12a", null ],
    [ "fg_set_plot_legend", "group__plot__functions.htm#ga0307e6fb1fdc358a1c097ec6eb568aed", null ],
    [ "fg_set_plot_marker_size", "group__plot__functions.htm#ga7988d5ebd327350e1c42ac773219d655", null ]
];
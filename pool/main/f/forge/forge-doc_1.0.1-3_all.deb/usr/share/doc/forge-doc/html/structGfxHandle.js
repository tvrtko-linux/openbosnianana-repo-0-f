var structGfxHandle =
[
    [ "mId", "structGfxHandle.htm#aa4310d1bc8e844fdf803c8e731f00d0e", null ],
    [ "mTarget", "structGfxHandle.htm#a1105cfec301b76086cfffc5fec9b6ee9", null ]
];
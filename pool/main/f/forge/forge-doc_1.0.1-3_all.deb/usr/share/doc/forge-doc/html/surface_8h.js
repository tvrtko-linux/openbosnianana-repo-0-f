var surface_8h =
[
    [ "Surface", "classforge_1_1Surface.htm", "classforge_1_1Surface" ],
    [ "fg_create_surface", "group__surf__functions.htm#ga1aa96efbe12f60ee5240da45d7cf83ab", null ],
    [ "fg_get_surface_alpha_buffer", "group__surf__functions.htm#gab310a49edd0dab0d56d436846545ac7c", null ],
    [ "fg_get_surface_alpha_buffer_size", "group__surf__functions.htm#ga36155cd2b8edd5bda5a1f3ecdaa285b8", null ],
    [ "fg_get_surface_color_buffer", "group__surf__functions.htm#gaa0a7dc2fdf21db567ce7c26682b32390", null ],
    [ "fg_get_surface_color_buffer_size", "group__surf__functions.htm#ga7faf1881724c2e8cc0c3d7d341b1365f", null ],
    [ "fg_get_surface_vertex_buffer", "group__surf__functions.htm#ga1b524434b28e223e22e8a7d8275fef0d", null ],
    [ "fg_get_surface_vertex_buffer_size", "group__surf__functions.htm#ga7e72cd9174bab308c8df4e9594192e00", null ],
    [ "fg_release_surface", "group__surf__functions.htm#ga0dd9ec44628624555ef6f6c815de6325", null ],
    [ "fg_retain_surface", "group__surf__functions.htm#gad3b729c28ac2425c396186deafa392f1", null ],
    [ "fg_set_surface_color", "group__surf__functions.htm#ga07485f9baf7058ab08a8df9108880a4b", null ],
    [ "fg_set_surface_legend", "group__surf__functions.htm#gae40dd79a4cf4b072a1e96db1d74483c5", null ]
];
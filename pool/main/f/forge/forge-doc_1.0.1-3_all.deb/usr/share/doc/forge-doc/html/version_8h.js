var version_8h =
[
    [ "FG_API_VERSION_CURRENT", "version_8h.htm#ab470b0003d84cc5d0da6be9e02a296d2", null ],
    [ "FG_VERSION", "version_8h.htm#a2c35b4310f02ad2f13e144802684c545", null ],
    [ "FG_VERSION_MAJOR", "version_8h.htm#a61dea1ee752736b54a650ac341eb2584", null ],
    [ "FG_VERSION_MINOR", "version_8h.htm#a9ecd1e9eda352ec13b9631c1cd54dd73", null ],
    [ "FG_VERSION_PATCH", "version_8h.htm#a2a9b913cbcb9ffd5b7cda4c8b41f6907", null ]
];
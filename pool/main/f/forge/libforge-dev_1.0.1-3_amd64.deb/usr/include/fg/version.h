/*******************************************************
 * Copyright (c) 2014, ArrayFire
 * All rights reserved.
 *
 * This file is distributed under 3-clause BSD license.
 * The complete license agreement can be obtained at:
 * http://arrayfire.com/licenses/BSD-3-Clause
 ********************************************************/

#pragma once

#define FG_VERSION "1.0.1"
#define FG_VERSION_MAJOR 1
#define FG_VERSION_MINOR 0
#define FG_VERSION_PATCH 1
#define FG_API_VERSION_CURRENT   10

[02:37] <marys> po wpisaniu komendy vhosts wyskakuja vhosty . przy wejsciu
                na shella jest MOTD
[02:38] <marys> wiec mam pytanie
[02:38] <marys> czy w tym i w tym pliku dodaje sie w ten sam sposub kolorki ?
%
[04:55] <marys> co jest zepsute jak zamiast vhosta wyskakuja cyferki ??
%
23:58:37 < marys> sory ze zapytam ale w jakim katalogu sie robilo plik
                  po kturego wpisaniu wyskakiwaly np vhosty ?
%
18:37 -!- Laska`` [sop@shell.arx.pl] has joined #ipv6.pl
18:37 < Laska``> hehehe mozna ipv6 pod winde?
18:38 <@waszi_> hmm a osobowa czy towarowa ? :P
18:38 -!- Laska`` [sop@shell.arx.pl] has left #ipv6.pl [Laska``]
%
[08:22] <siTol> Ravi: z kad tego braina sciagac
%
13:44:34 < user[13]> b|b: uzyj ipv6calc
13:44:35 <@Westbam> 9.3.3.0.2.0.0.0.e.a.0.0.0.1.0.8.e.f.f.3.ip6.int  koleś.
13:45:05 < user[13]> ipv6calc -r 3ffe:8010:ae:2:339::/80
13:45:14 < user[13]> dostaniesz to co napisal Westbam :)
13:45:37 <@Westbam> trzeba mieć też trochę w głowie a nie w /usr/bin/ ;p
13:45:46 < user[13]> ;)
13:46:26 < user[13]> czy jak masz pilota to zeby przelaczyc program
                     podchodzisz do telewizora ? :)
13:46:44 <@Westbam> nie ale jak ci schowam 'start' w windowsie to się
                    pogubisz.
13:46:54 < user[13]> hehe
13:48:13 < user[13]> zalezy jak schowasz :]
13:48:24 <@Westbam> albo wyjmę ci baterie z pilota.
13:48:35 < user[13]> :>
%
18:25:07 >> #ipv6.pl JOIN Valdi_ (admin@pa145.mysliborz.sdi.tpnet.pl)
18:28:46 < Valdi_> zyw ktos ?
18:28:46 < Valdi_> '
18:28:47 < Valdi_> ;}
18:29:58 <@djrzulf> nope
18:30:12 < Valdi_> Huh.
18:30:13 < Valdi_> ;]
18:30:40 < Valdi_> zajmuje sie tutaj ktos ipv6? czy tylko nazwa kanalu jest
                   calkiem przypadkowa ?
18:33:33 <@djrzulf> przypadkowa
%
22:17:32 < user[13]> na polsacie co rok to samo puszczaja
22:17:40 < user[13]> to telewizja dla sklerotykow :>
22:17:58 < user[13]> po roku koles nie pamieta ze to juz bylo w zeszlym roku
22:18:06 < user[13]> i oglada z zaciekawieniem :>
%
22:22:59 < user[13]> co sie stalo z ipv6.pl ?
22:23:21 <@Ravi> myszy zjadły
22:24:26 < user[13]> e
22:25:30 < user[13]> az takie glodne byly ?
22:25:34 <@Ravi> widocznie.
22:25:36 < user[13]> to bede pilnowal zeby mi domu nie zjadly ;>
%
15:36:33 <@chatul> kto mnie szukal i dlaczego ?
15:37:07 <@Ravi> ja, bo chciałem Ci dać buziaka :*
15:37:41 <@Westbam> mhyhyhy
15:38:46 < djrzulf> ostro
15:38:46 < djrzulf> ;]
15:39:00 <@Ravi> Jestem kochankiem werterowskim i przeżywam niespełnioną
                 miłość do Ciebie i djrzulfa.
%

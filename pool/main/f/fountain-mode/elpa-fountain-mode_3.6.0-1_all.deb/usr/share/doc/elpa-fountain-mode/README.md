Fountain Mode
=============

Fountain Mode is a screenwriting program for GNU Emacs using the
Fountain plain text markup format.

For more information about the Fountain format, visit <https://fountain.io>

![screenshot](screenshots/02.png)


Features
--------

 - Support for the Fountain 1.1 specification
 - WYSIWYG auto-align elements (display only, does not modify file
   contents) specific to script format, e.g. screenplay, stageplay or
   user-defined formats
 - Traditional TAB auto-completion writing style
 - Highly accurate pagination calculation
 - Navigation by section, scene, character name, or page
 - Integration with `outline` to fold/cycle visibility of sections,
   scenes and notes
 - Integration with `electric-pair-mode` to insert emphasis delimiters
   with single key (i.e. `*` or `_`)
 - Integration with `imenu` (sections, scene headings, notes)
 - Integration with `auto-insert` for title page metadata
 - Integration with `which-function-mode` to display live-update of current
   page and page count in mode-line
 - Automatically add/remove character `(CONT'D)`
 - Toggle syntax highlighting of each element
 - Toggle visibility of emphasis and syntax markup
 - Optionally display scene numbers in margins
 - Intelligent insertion of page breaks

Most common features are accessible from the menu. For a full list of
functions and key-bindings, type `C-h m`.


Exporting
---------

Earlier versions of Fountain Mode had export functionality, but this was
not very good and is better handled via interfacing with external shell
tools, such as:

 - [afterwriting](https://github.com/ifrost/afterwriting-labs/blob/master/docs/clients.md) (JavaScript)
 - [Wrap](https://github.com/Wraparound/wrap) (Go)
 - [screenplain](https://github.com/vilcans/screenplain) (Python 3)
 - [Textplay](https://github.com/olivertaylor/Textplay) (Ruby, requires PrinceXML for PDF)

The option `fountain-export-command-profiles` provides some shell
commands to interface with these tools, but you are encouraged to edit
or completely replace these to suit your own needs. The format is simple
while still allowing for a lot of flexibility.


Installation
------------

Users of Debian ≥10 and its derivatives (Ubuntu, Pop!_OS, etc. ≥18.04) may install Fountain Mode with the following command:

    sudo apt install elpa-fountain-mode


Development
-----------

If you wish to contribute to or alter Fountain Mode's code, clone the
repository:

    git clone https://github.com/rnkn/fountain-mode.git


Bugs and Feature Requests
-------------------------

To report bugs and feature requests that affect the Debian package,
please use the following method:

    $ sudo apt install reportbug
    $ reportbug elpa-fountain-mode

Known upstream issues are tracked with `FIXME` comments in the source.

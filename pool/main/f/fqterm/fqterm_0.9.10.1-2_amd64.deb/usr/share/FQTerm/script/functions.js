
rand=function(n){ //generate a random number b'w 0-(n-1)
	var t=Math.random();
	return Math.floor(t*n);
}


//fqterm.msgBox(fqterm.getAddress())
//if (!fqterm.isConnected()) fqterm.reconnect()
//fqterm.previewImage("http://img1.kaixin001.com.cn/i2/kaixinlogo.gif")
fqterm.msgBox(fqterm.copyArticle());

dp"随便"做的style sheet
基本包括了所有的可定制元素
请先将.qss文件中的各处image路径改为本机上的路径
然后在偏好中选择.qss文件
如果将偏好中qss文件一项留空，则不会使用sytlesheet，也不会占用任何资源。

Don't modify files in this directory. They are backup files for user configurable data.

If you do want to change settings, please go to:
*nix: $HOME/.fqterm/
win32: $HOME/Application Data/FQTerm/
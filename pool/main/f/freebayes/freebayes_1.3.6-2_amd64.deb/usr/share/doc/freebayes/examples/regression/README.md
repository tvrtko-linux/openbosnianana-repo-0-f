This directory stores output of tests to have them in git and verify
there are no regressions

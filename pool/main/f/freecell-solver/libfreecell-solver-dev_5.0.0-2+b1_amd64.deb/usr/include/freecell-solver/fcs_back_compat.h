/*
 * This file is part of Freecell Solver. It is subject to the license terms in
 * the COPYING.txt file found in the top-level directory of this distribution
 * and at http://fc-solve.shlomifish.org/docs/distro/COPYING.html . No part of
 * Freecell Solver, including this file, may be copied, modified, propagated,
 * or distributed except according to the terms contained in the COPYING file.
 *
 * Copyright (c) 2000 Shlomi Fish
 */

/*
 * fcs_back_compat.h - Backward compatibility control configuration file for
 * Freecell Solver
 *
 * fcs_back_compat.h was auto-generated from fcs_back_compat.h.in . Do not modify directly
*/

#ifndef FC_SOLVE__BACK_COMPAT_H
#define FC_SOLVE__BACK_COMPAT_H

#ifdef __cplusplus
extern "C" {
#endif

/* #undef FCS_BREAK_BACKWARD_COMPAT_1 */
/* #undef FCS_BREAK_BACKWARD_COMPAT_2 */

#ifdef FCS_BREAK_BACKWARD_COMPAT_1
#ifndef FC_SOLVE_IMPLICIT_T_RANK
#define FC_SOLVE_IMPLICIT_T_RANK
#endif
#endif

#ifdef FC_SOLVE_IMPLICIT_T_RANK
#define FC_SOLVE__PASS_T(arg)
#else
#define FC_SOLVE__PASS_T(arg) , arg
#endif

#ifdef FCS_BREAK_BACKWARD_COMPAT_1
#ifndef FC_SOLVE_IMPLICIT_PARSABLE_OUTPUT
#define FC_SOLVE_IMPLICIT_PARSABLE_OUTPUT
#endif
#endif

#ifdef FC_SOLVE_IMPLICIT_PARSABLE_OUTPUT
#define FC_SOLVE__PASS_PARSABLE(arg)
#else
#define FC_SOLVE__PASS_PARSABLE(arg) , arg
#endif

#ifdef FCS_BREAK_BACKWARD_COMPAT_1
#ifndef FC_SOLVE__REMOVE_TRAILING_WHITESPACE_IN_OUTPUT
#define FC_SOLVE__REMOVE_TRAILING_WHITESPACE_IN_OUTPUT
#endif
#endif

#ifdef FCS_BREAK_BACKWARD_COMPAT_1
#ifndef FC_SOLVE__STRICTER_BOARD_PARSING
#define FC_SOLVE__STRICTER_BOARD_PARSING
#endif
#endif

#ifdef FCS_BREAK_BACKWARD_COMPAT_1
#ifndef FC_SOLVE__REMOVE_OLD_API_1
#define FC_SOLVE__REMOVE_OLD_API_1
#endif
#endif

/* #undef FCS_DISABLE_ERROR_STRINGS */

#ifndef FCS_DISABLE_ERROR_STRINGS
#define FCS_WITH_ERROR_STRS
#endif

#ifdef FCS_WITH_ERROR_STRS
#define FCS__DECL_ERR_BUF(var) char var[120];
#define FCS__DECL_ERR_PTR(var) char *var;
#define FCS__PASS_ERR_STR(arg) , arg
#else
#define FCS__DECL_ERR_BUF(var)
#define FCS__DECL_ERR_PTR(var)
#define FCS__PASS_ERR_STR(arg)
#endif

#ifdef FCS_BREAK_BACKWARD_COMPAT_2
// typedef float fc_solve_weighting_float;
// typedef long double fc_solve_weighting_float;
typedef double fc_solve_weighting_float;
#else
typedef double fc_solve_weighting_float;
#endif
#ifdef __cplusplus
}
#endif

#endif    /* #ifndef FC_SOLVE__BACK_COMPAT_H */

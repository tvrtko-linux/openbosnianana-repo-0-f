var indexSectionsWithContent =
{
  0: "_acdefghijlmopqrstv~",
  1: "_acdip",
  2: "f",
  3: "cfg",
  4: "_acdgioprs~",
  5: "acdegijmpqrs",
  6: "_cfgpst",
  7: "_chlpsv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Macros"
};


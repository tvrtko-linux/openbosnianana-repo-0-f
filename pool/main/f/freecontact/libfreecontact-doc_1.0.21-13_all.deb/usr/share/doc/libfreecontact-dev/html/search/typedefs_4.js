var searchData=
[
  ['pairfreq_5ft_0',['pairfreq_t',['../classfreecontact_1_1predictor.html#a5054b4f980d5bd2b7d83404bb7c18e0a',1,'freecontact::predictor']]]
];

var searchData=
[
  ['score_0',['score',['../structfreecontact_1_1contact__t.html#a9b852e178f7b28ac0aa156b658bdd023',1,'freecontact::contact_t']]],
  ['seqcnt_1',['seqcnt',['../classfreecontact_1_1ali__t.html#a0d0fb8987dd3753403178d74c8ac5e04',1,'freecontact::ali_t']]],
  ['shrink_5flambda_2',['shrink_lambda',['../structfreecontact_1_1parset__t.html#a537441daba9deb02f67f0beed007e0b2',1,'freecontact::parset_t']]]
];

# SPDX-License-Identifier: GPL-3.0-or-later
"""
Tests for Freedom Maker.
"""

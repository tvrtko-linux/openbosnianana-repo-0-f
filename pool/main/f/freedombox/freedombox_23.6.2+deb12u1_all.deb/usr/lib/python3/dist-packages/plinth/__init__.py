# SPDX-License-Identifier: AGPL-3.0-or-later
"""
Package init file.
"""

__version__ = '23.6.2'

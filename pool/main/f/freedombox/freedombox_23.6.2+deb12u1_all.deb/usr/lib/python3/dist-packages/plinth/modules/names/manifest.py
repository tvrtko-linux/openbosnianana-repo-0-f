# SPDX-License-Identifier: AGPL-3.0-or-later
"""
Application manifest for names.
"""

backup = {}

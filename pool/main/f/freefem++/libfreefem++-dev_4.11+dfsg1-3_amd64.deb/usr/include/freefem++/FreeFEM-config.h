#ifndef _FREEFEM_CONFIG_H
#define _FREEFEM_CONFIG_H 1
 
/* FreeFEM-config.h. Generated automatically at end of configure. */
/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* build FreeFEM for use by FreeFem++-cs */
/* #undef ENABLE_FFCS */

/* Define to dummy `main' function (if any) required to link to the Fortran
   libraries. */
/* #undef F77_DUMMY_MAIN */

/* Define to a macro mangling the given C identifier (in lower and upper
   case), which must not contain underscores, for linking with Fortran. */
#ifndef FREEFEM_F77_FUNC
#define FREEFEM_F77_FUNC(name,NAME) name ## _
#endif

/* As F77_FUNC, but for C identifiers containing underscores. */
#ifndef FREEFEM_F77_FUNC_
#define FREEFEM_F77_FUNC_(name,NAME) name ## _
#endif

/* Define if F77 and FC dummy `main' functions are identical. */
/* #undef FC_DUMMY_MAIN_EQ_F77 */

/* FreeFem prefix dir */
#ifndef FREEFEM_FF_PREFIX_DIR
#define FREEFEM_FF_PREFIX_DIR "/usr/lib/ff++/4.9"
#endif

/* FreeFem prefix dir */
/* #undef FF_PREFIX_DIR_APPLE */

/* Define to 1 if you have the <Accelerate/cblas.h> header file. */
/* #undef HAVE_ACCELERATE_CBLAS_H */

/* Define to 1 if you have the `acosh' function. */
#ifndef FREEFEM_HAVE_ACOSH
#define FREEFEM_HAVE_ACOSH 1
#endif

/* Define to 1 if you have the `asinh' function. */
#ifndef FREEFEM_HAVE_ASINH
#define FREEFEM_HAVE_ASINH 1
#endif

/* Define to 1 if you have the `atanh' function. */
#ifndef FREEFEM_HAVE_ATANH
#define FREEFEM_HAVE_ATANH 1
#endif

/* Define to 1 if you have the <atlas/cblas.h> header file. */
/* #undef HAVE_ATLAS_CBLAS_H */

/* If umfpack.h is located in UMFPACK subdir */
/* #undef HAVE_BIG_UMFPACK_UMFPACK_H */

/* freecadna is use to evalute the round-off error propagation */
/* #undef HAVE_CADNA */

/* Define to 1 if you have the <cblas.h> header file. */
#ifndef FREEFEM_HAVE_CBLAS_H
#define FREEFEM_HAVE_CBLAS_H 1
#endif

/* Define to 1 if you have the <cstddef> header file. */
#ifndef FREEFEM_HAVE_CSTDDEF
#define FREEFEM_HAVE_CSTDDEF 1
#endif

/* Dynamic loading - not mandatory */
#ifndef FREEFEM_HAVE_DLFCN_H
#define FREEFEM_HAVE_DLFCN_H 1
#endif

/* Define to 1 if you have the `erfc' function. */
#ifndef FREEFEM_HAVE_ERFC
#define FREEFEM_HAVE_ERFC 1
#endif

/* Define to 1 if you have the <fftw3.h> header file. */
#ifndef FREEFEM_HAVE_FFTW3_H
#define FREEFEM_HAVE_FFTW3_H 1
#endif

/* Define to 1 if you have the `getenv' function. */
#ifndef FREEFEM_HAVE_GETENV
#define FREEFEM_HAVE_GETENV 1
#endif

/* Define to 1 if you have the `gettimeofday' function. */
#ifndef FREEFEM_HAVE_GETTIMEOFDAY
#define FREEFEM_HAVE_GETTIMEOFDAY 1
#endif

/* Define to 1 if you have the <GLUT/glut.h> header file. */
/* #undef HAVE_GLUT_GLUT_H */

/* Define to 1 if you have the <GL/glut.h> header file. */
#ifndef FREEFEM_HAVE_GL_GLUT_H
#define FREEFEM_HAVE_GL_GLUT_H 1
#endif

/* Define to 1 if you have the <GL/gl.h> header file. */
#ifndef FREEFEM_HAVE_GL_GL_H
#define FREEFEM_HAVE_GL_GL_H 1
#endif

/* Defined if you have HDF5 support */
#ifndef FREEFEM_HAVE_HDF5
#define FREEFEM_HAVE_HDF5 1
#endif

/* Define to 1 if you have the <inttypes.h> header file. */
#ifndef FREEFEM_HAVE_INTTYPES_H
#define FREEFEM_HAVE_INTTYPES_H 1
#endif

/* Define to 1 if you have the `jn' function. */
#ifndef FREEFEM_HAVE_JN
#define FREEFEM_HAVE_JN 1
#endif

/* Arpack is used for eigenvalue computation */
#ifndef FREEFEM_HAVE_LIBARPACK
#define FREEFEM_HAVE_LIBARPACK 1
#endif

/* Cholmod is used for sparse matrices computations */
#ifndef FREEFEM_HAVE_LIBCHOLMOD
#define FREEFEM_HAVE_LIBCHOLMOD 1
#endif

/* Define to 1 if you have the `dl' library (-ldl). */
#ifndef FREEFEM_HAVE_LIBDL
#define FREEFEM_HAVE_LIBDL 1
#endif

/* Define to 1 if you have the `m' library (-lm). */
#ifndef FREEFEM_HAVE_LIBM
#define FREEFEM_HAVE_LIBM 1
#endif

/* Define to 1 if you have the `rt' library (-lrt). */
#ifndef FREEFEM_HAVE_LIBRT
#define FREEFEM_HAVE_LIBRT 1
#endif

/* UMFPACK */
#ifndef FREEFEM_HAVE_LIBUMFPACK
#define FREEFEM_HAVE_LIBUMFPACK 1
#endif

/* Define to 1 if you have the `mallinfo' function. */
#ifndef FREEFEM_HAVE_MALLINFO
#define FREEFEM_HAVE_MALLINFO 1
#endif

/* Define to 1 if you have the <malloc.h> header file. */
#ifndef FREEFEM_HAVE_MALLOC_H
#define FREEFEM_HAVE_MALLOC_H 1
#endif

/* the MKL intel lib is present for BLAS and LAPACK */
/* #undef HAVE_MKL */

/* mpi_double_complex */
#ifndef FREEFEM_HAVE_MPI_DOUBLE_COMPLEX
#define FREEFEM_HAVE_MPI_DOUBLE_COMPLEX 1
#endif

/* Define to 1 if you have the `mstats' function. */
/* #undef HAVE_MSTATS */

/* Define to 1 if you have the <OpenGL/gl.h> header file. */
/* #undef HAVE_OPENGL_GL_H */

/* Define to 1 if you have the <regex.h> header file. */
#ifndef FREEFEM_HAVE_REGEX_H
#define FREEFEM_HAVE_REGEX_H 1
#endif

/* Define to 1 if you have the `second_' function. */
/* #undef HAVE_SECOND_ */

/* Define to 1 if you have the <semaphore.h> header file. */
#ifndef FREEFEM_HAVE_SEMAPHORE_H
#define FREEFEM_HAVE_SEMAPHORE_H 1
#endif

/* Define to 1 if you have the `srandomdev' function. */
/* #undef HAVE_SRANDOMDEV */

/* Define to 1 if you have the <stddef.h> header file. */
#ifndef FREEFEM_HAVE_STDDEF_H
#define FREEFEM_HAVE_STDDEF_H 1
#endif

/* Define to 1 if you have the <stdint.h> header file. */
#ifndef FREEFEM_HAVE_STDINT_H
#define FREEFEM_HAVE_STDINT_H 1
#endif

/* Define to 1 if you have the <stdio.h> header file. */
#ifndef FREEFEM_HAVE_STDIO_H
#define FREEFEM_HAVE_STDIO_H 1
#endif

/* Define to 1 if you have the <stdlib.h> header file. */
#ifndef FREEFEM_HAVE_STDLIB_H
#define FREEFEM_HAVE_STDLIB_H 1
#endif

/* Define to 1 if you have the <strings.h> header file. */
#ifndef FREEFEM_HAVE_STRINGS_H
#define FREEFEM_HAVE_STRINGS_H 1
#endif

/* Define to 1 if you have the <string.h> header file. */
#ifndef FREEFEM_HAVE_STRING_H
#define FREEFEM_HAVE_STRING_H 1
#endif

/* Define to 1 if you have the <suitesparse/umfpack.h> header file. */
/* #undef HAVE_SUITESPARSE_UMFPACK_H */

/* Define to 1 if you have the `sysconf' function. */
#ifndef FREEFEM_HAVE_SYSCONF
#define FREEFEM_HAVE_SYSCONF 1
#endif

/* Define to 1 if you have the <sys/mman.h> header file. */
#ifndef FREEFEM_HAVE_SYS_MMAN_H
#define FREEFEM_HAVE_SYS_MMAN_H 1
#endif

/* Define to 1 if you have the <sys/stat.h> header file. */
#ifndef FREEFEM_HAVE_SYS_STAT_H
#define FREEFEM_HAVE_SYS_STAT_H 1
#endif

/* Define to 1 if you have the <sys/time.h> header file. */
#ifndef FREEFEM_HAVE_SYS_TIME_H
#define FREEFEM_HAVE_SYS_TIME_H 1
#endif

/* Define to 1 if you have the <sys/types.h> header file. */
#ifndef FREEFEM_HAVE_SYS_TYPES_H
#define FREEFEM_HAVE_SYS_TYPES_H 1
#endif

/* Define to 1 if you have the `tgamma' function. */
#ifndef FREEFEM_HAVE_TGAMMA
#define FREEFEM_HAVE_TGAMMA 1
#endif

/* Define to 1 if you have the `times' function. */
#ifndef FREEFEM_HAVE_TIMES
#define FREEFEM_HAVE_TIMES 1
#endif

/* Define to 1 if you have the <ufsparse/umfpack.h> header file. */
/* #undef HAVE_UFSPARSE_UMFPACK_H */

/* Define to 1 if you have the <umfpack.h> header file. */
#ifndef FREEFEM_HAVE_UMFPACK_H
#define FREEFEM_HAVE_UMFPACK_H 1
#endif

/* Define to 1 if you have the <umfpack/umfpack.h> header file. */
/* #undef HAVE_UMFPACK_UMFPACK_H */

/* Define to 1 if you have the <unistd.h> header file. */
#ifndef FREEFEM_HAVE_UNISTD_H
#define FREEFEM_HAVE_UNISTD_H 1
#endif

/* Name of package */
#ifndef FREEFEM_PACKAGE
#define FREEFEM_PACKAGE "FreeFEM"
#endif

/* Define to the address where bug reports for this package should be sent. */
#ifndef FREEFEM_PACKAGE_BUGREPORT
#define FREEFEM_PACKAGE_BUGREPORT "frederic.hecht@sorbonne-universite.fr"
#endif

/* Define to the full name of this package. */
#ifndef FREEFEM_PACKAGE_NAME
#define FREEFEM_PACKAGE_NAME "FreeFEM"
#endif

/* Define to the full name and version of this package. */
#ifndef FREEFEM_PACKAGE_STRING
#define FREEFEM_PACKAGE_STRING "FreeFEM 4.9"
#endif

/* Define to the one symbol short name of this package. */
#ifndef FREEFEM_PACKAGE_TARNAME
#define FREEFEM_PACKAGE_TARNAME "FreeFEM"
#endif

/* Define to the home page for this package. */
#ifndef FREEFEM_PACKAGE_URL
#define FREEFEM_PACKAGE_URL ""
#endif

/* Define to the version of this package. */
#ifndef FREEFEM_PACKAGE_VERSION
#define FREEFEM_PACKAGE_VERSION "4.9"
#endif

/* the ffglut application for the new graphics */
#ifndef FREEFEM_PROG_FFGLUT
#define FREEFEM_PROG_FFGLUT "ffglut"
#endif

/* A pure windows applications no cygwin dll */
/* #undef PURE_WIN32 */

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#ifndef FREEFEM_STDC_HEADERS
#define FREEFEM_STDC_HEADERS 1
#endif

/* Define to 1 if you can safely include both <sys/time.h> and <time.h>. This
   macro is obsolete. */
#ifndef FREEFEM_TIME_WITH_SYS_TIME
#define FREEFEM_TIME_WITH_SYS_TIME 1
#endif

/* Version number of package */
#ifndef FREEFEM_VERSION
#define FREEFEM_VERSION "4.9"
#endif

/* FreeFEM version as a float */
#ifndef FREEFEM_VersionFreeFem
#define FREEFEM_VersionFreeFem 4.9
#endif

/* FreeFEM build date */
#ifndef FREEFEM_VersionFreeFemDate
#define FREEFEM_VersionFreeFemDate "2023-04-08"
#endif

/* Define to 1 if `lex' declares `yytext' as a `char *' by default, not a
   `char[]'. */
#ifndef FREEFEM_YYTEXT_POINTER
#define FREEFEM_YYTEXT_POINTER 1
#endif
 
/* once: _FREEFEM_CONFIG_H */
#endif

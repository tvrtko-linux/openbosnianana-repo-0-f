// Emacs will be in -*- Mode: c++ -*-
//
// ********** DO NOT REMOVE THIS BANNER **********
//
// SUMMARY: Language for a Finite Element Method
// RELEASE: 2.0     
// USAGE  : You may copy freely these files and use it for    
//          teaching or research. These or part of these may   
//          not be sold or used for a commercial purpose with- 
//          out our consent : fax (33)1 44 27 44 11        
//
// AUTHORS:  C. Prud'homme
// ORG    :          
// E-MAIL :  prudhomm@users.sourceforge.net
//
// ORIG-DATE:     June-94
// LAST-MOD:  5-Apr-02 at 19:43:58 by Christophe Prud'homme
//
// DESCRIPTION:  
/*
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

// DESCRIP-END.
//

#ifndef __RGRAPH_H
#define __RGRAPH_H

namespace fem
{
  void message(char *s);
  void erreur(char *s);
  void *safecalloc(long nb, long size);
  void initgraphique();
  void closegraphique();
  void rattente(int waitm, float = 0, float = 0 );
  void cadre(float xmin,float xmax, float ymin, float ymax);
  void cadreortho(float centrex, float centrey, float rayon);
  void couleur(int c);
  void pointe(float x, float y);
  void rmoveto(float x, float y);
  void rlineto(float x, float y);
  void cercle(float centrex, float centrey, float rayon);
  void execute(char* s);
  void safefree(void** f);
  void reffecran();
  void raffpoly(int n, float *poly);
}
#endif /* __RGRAPH_H */

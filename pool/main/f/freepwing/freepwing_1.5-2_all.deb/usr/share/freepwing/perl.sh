#! /bin/sh

/usr/bin/perl ${1+"$@"}

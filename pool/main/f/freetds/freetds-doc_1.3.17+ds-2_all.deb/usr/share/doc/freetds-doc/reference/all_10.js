var searchData=
[
  ['read_0',['read',['../a01062.html#a2f0be7677a1bf9c730e3c697bfba21c9',1,'tds_input_stream']]],
  ['read_2ec_1',['read.c',['../a00239.html',1,'']]],
  ['read_5fand_5fconvert_2',['read_and_convert',['../a00543.html#ga676c4dee6522815b16fdc8e448e43590',1,'read.c']]],
  ['ref_5fcount_3',['ref_count',['../a00594.html#a812580afdfca53b6d54a7d09938c65c2',1,'dblib_context::ref_count()'],['../a01174.html#a692ccceff71d836df0d084ec26123c2d',1,'tds_cursor::ref_count()'],['../a01182.html#a2798c66fb3c8637c7fb29c6d1efebfa4',1,'tds_dynamic::ref_count()']]],
  ['remote_20procedure_20functions_4',['Remote Procedure functions',['../a00528.html',1,'']]],
  ['res_5finfo_5',['res_info',['../a01182.html#ac736e163c0d4cdbca980a861214d99e7',1,'tds_dynamic']]],
  ['resinfo_6',['resinfo',['../a00590.html#ad49b82677ae277e5d5b0038f522da293',1,'dblib_buffer_row']]],
  ['results_20processing_7',['Results processing',['../a00544.html',1,'']]],
  ['ret_5fstatus_8',['ret_status',['../a01210.html#a355e0b8c6219908747f82cd7482c6efb',1,'tds_socket']]],
  ['retry_5faddr_9',['retry_addr',['../a00742.html',1,'']]],
  ['row_10',['row',['../a00590.html#a015599345b266045d8bd3fac731e4675',1,'dblib_buffer_row']]],
  ['row_5fcount_11',['row_count',['../a01006.html#a8fd44f3c44ae4c83a1bdda0b73776ecd',1,'_hstmt']]],
  ['row_5fdata_12',['row_data',['../a00590.html#a5a057d6bbecfac1a85a9fbcd09eaf3a0',1,'dblib_buffer_row']]],
  ['row_5fstatus_13',['row_status',['../a01006.html#a41dd89b2dc41fe0e747580f6ea807063',1,'_hstmt']]],
  ['rows_5faffected_14',['rows_affected',['../a01210.html#a803e29dabc76d35227f5de2488f29877',1,'tds_socket']]],
  ['rsa_5fpublic_5fkey_15',['rsa_public_key',['../a00758.html',1,'']]],
  ['rtrim_16',['rtrim',['../a00530.html#ga4d5be57b25a0654e2170fd656dc35489',1,'bcp.c']]]
];

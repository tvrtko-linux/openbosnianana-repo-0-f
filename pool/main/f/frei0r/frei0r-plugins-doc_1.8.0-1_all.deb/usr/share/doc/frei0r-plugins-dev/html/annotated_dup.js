var annotated_dup =
[
    [ "f0r_param_color", "structf0r__param__color.html", "structf0r__param__color" ],
    [ "f0r_param_info", "structf0r__param__info.html", "structf0r__param__info" ],
    [ "f0r_param_position", "structf0r__param__position.html", "structf0r__param__position" ],
    [ "f0r_plugin_info", "structf0r__plugin__info.html", "structf0r__plugin__info" ]
];
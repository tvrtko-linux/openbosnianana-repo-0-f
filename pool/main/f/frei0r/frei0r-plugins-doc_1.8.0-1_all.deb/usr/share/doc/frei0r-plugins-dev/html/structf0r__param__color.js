var structf0r__param__color =
[
    [ "b", "structf0r__param__color.html#a44b8f5ddd1fec1973edbff58a63683f9", null ],
    [ "g", "structf0r__param__color.html#a93f2e432efe7db1c8cd39b38241810f9", null ],
    [ "r", "structf0r__param__color.html#aa35e508971f4fae55621e61f70a893ed", null ]
];
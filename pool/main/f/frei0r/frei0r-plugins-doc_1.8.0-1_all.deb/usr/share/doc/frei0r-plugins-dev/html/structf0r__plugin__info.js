var structf0r__plugin__info =
[
    [ "author", "structf0r__plugin__info.html#ac6ad807a9ac439e57e7410dd699add6f", null ],
    [ "color_model", "structf0r__plugin__info.html#a0b1238f47fe6600243e500446568bb4e", null ],
    [ "explanation", "structf0r__plugin__info.html#a9df1154eb490f9ba53bcbd4800a8cc3e", null ],
    [ "frei0r_version", "structf0r__plugin__info.html#aac89e4129172023e153c952259373149", null ],
    [ "major_version", "structf0r__plugin__info.html#a87ea44cd95f93b3c367d3dcec556deb3", null ],
    [ "minor_version", "structf0r__plugin__info.html#abfa71a212ece4e0af3d4a8c3f4fa55ca", null ],
    [ "name", "structf0r__plugin__info.html#a6e9916e14a3871987c66964a89b18c5d", null ],
    [ "num_params", "structf0r__plugin__info.html#a92cf99cadc76b90d2ac908e367c2c92f", null ],
    [ "plugin_type", "structf0r__plugin__info.html#ae57fd00690e5f90609120cff276c3ead", null ]
];
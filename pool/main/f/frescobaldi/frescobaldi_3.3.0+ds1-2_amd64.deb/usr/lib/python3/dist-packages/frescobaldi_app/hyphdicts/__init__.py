"""
In this directory you can place hyphenation dictionaries (with names like
"hyph_nl_NL.dic", e.g. from OpenOffice.org or MySpell), which will then be found
by the Frescobaldi hyphenation dialog (see lyrics.py, hyphendialog.py and
hyphenator.py).
"""

import os

path = os.path.abspath(__path__[0])

del os

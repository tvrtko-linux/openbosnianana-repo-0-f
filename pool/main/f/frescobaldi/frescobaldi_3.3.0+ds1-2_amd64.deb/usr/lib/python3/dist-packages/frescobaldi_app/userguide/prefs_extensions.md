=== Extensions ===

List and (partially) configure installed extensions. See {extending} and
especially {configure}.

#VARS
extending help extending
configure help ext_configuration

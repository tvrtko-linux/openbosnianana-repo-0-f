=== Keyboard Shortcuts ===
    
Here you can add keyboard shortcuts to all commands available. Also the 
[snippets Snippets] or [quickinsert Quick-Insert] buttons that have 
keyboard shortcuts are listed here.

To change a keyboard shortcut, highlight an action in the list
and click the Edit button, or double-click an action.
In the dialog that appears, you can enter up to four shortcuts
for the action by clicking the button and typing the shortcut.

You can define a new scheme by using the New button.


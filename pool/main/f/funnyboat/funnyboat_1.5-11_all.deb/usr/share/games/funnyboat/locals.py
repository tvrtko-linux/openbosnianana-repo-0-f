from pygame.locals import *

# Some variables used throughout the code

NEXTFRAME = USEREVENT + 1
MIN_FIRE_DELAY = 10
SCREEN_WIDTH = 400#320
SCREEN_HEIGHT = 300#240
FPS = 30


class Variables:
    aa = True
    alpha = True
    particles = True
    sound = True    
    music = True
    name = "Funny Boater"
    fullscreen = True

# -*- python -*-

from FusionIcon.interface_gtk import main

# -*- python -*-

from FusionIcon.interface_qt import main

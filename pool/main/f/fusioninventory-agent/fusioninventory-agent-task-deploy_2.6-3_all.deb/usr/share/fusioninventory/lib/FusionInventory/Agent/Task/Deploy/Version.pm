package FusionInventory::Agent::Task::Deploy::Version;

use strict;
use warnings;

use constant VERSION => "2.8";

1;
